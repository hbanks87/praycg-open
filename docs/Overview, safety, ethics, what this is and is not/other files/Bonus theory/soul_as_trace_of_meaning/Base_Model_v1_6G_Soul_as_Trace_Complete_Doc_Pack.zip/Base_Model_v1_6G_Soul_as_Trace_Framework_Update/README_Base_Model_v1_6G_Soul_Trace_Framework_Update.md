# Base Model v1.6G - Soul-as-Trace Framework Update

This pack adds D254-D257 to the recent Base Model document stack.

Core sentence: in the conceptual register, soul names the durable, living trace of meaning in a person.

This pack does not claim that EEG, HRV, respiration, self-report, or PR-AYC-G measures the soul. It formalizes a conceptual translation layer and an associated measurement-ontology guardrail.

Recommended OSF placement: bonus theory / framework integration, not the main empirical front door.
