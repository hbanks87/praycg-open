# CHANGELOG - Base Model v1.6G Soul-as-Trace Framework Update

## Added
- D254 - Soul as Trace of Meaning Framework Layer.
- D255 - Measurement Ontology Addendum for Soul-as-Trace variables.
- D256 - Base Model v1.6G Integration Register.
- D257 - Recent Document Pack Integration Map.
- soul_trace_formula_registry_v1_0.json.

## Corrective constraints
- Replaced "zero ego" and totalizing language with measurable/latent constructs.
- Restricted "soul" to the conceptual register.
- Defined meaning momentum as state-space kinematics, not mechanical momentum.
- Split physiological baseline recovery from organism-state baseline revision.
- Preserved the trace/source distinction: measurement may witness meaning but may not exhaust it.
