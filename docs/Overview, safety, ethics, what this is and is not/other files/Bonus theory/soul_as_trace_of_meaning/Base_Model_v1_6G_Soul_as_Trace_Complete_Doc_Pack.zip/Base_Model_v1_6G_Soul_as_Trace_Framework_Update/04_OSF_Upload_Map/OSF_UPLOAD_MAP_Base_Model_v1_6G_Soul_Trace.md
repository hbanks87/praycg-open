# OSF Upload Map - Base Model v1.6G Soul-as-Trace

Recommended placement:

```text
04_Bonus_Theory_Conceptual_Context/
  D254_Soul_as_Trace_of_Meaning_Framework_Layer_v1_0.pdf
  D254_Soul_as_Trace_of_Meaning_Framework_Layer_v1_0.docx

04_Framework_Integration/
  D255_Measurement_Ontology_Addendum_Soul_as_Trace_v1_0.pdf
  D256_Base_Model_v1_6G_Soul_as_Trace_Integration_Register.pdf
  D257_Recent_Document_Pack_Integration_Map_v1_0.pdf
  Base_Model_v1_6G_Soul_as_Trace_Framework_Update_Compendium.pdf

05_Archive_and_Zips/
  Base_Model_v1_6G_Soul_as_Trace_Complete_Doc_Pack.zip
```

Do not use D254 as the empirical front door. The main front door remains the PR-AYC-G public master theory/protocol, data syntheses, and analysis scripts.
