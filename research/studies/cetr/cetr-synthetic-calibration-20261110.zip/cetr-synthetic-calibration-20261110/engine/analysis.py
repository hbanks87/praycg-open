"""Fixed, sensor-anchored pilot calibration analysis. No outcome-based selection."""
from __future__ import annotations
import argparse, csv, hashlib, html, json
from pathlib import Path
import numpy as np
from scipy.signal import detrend

PLAN = {
    'schema': 'cetr.calibration.analysis.v1',
    'waveform_baseline_seconds': [-0.5, 0.0],
    'waveform_response_seconds': [0.0, 0.5],
    'alpha_baseline_seconds': [-2.0, 0.0],
    'alpha_response_seconds': [0.5, 2.5],
    'alpha_hz': [8.0, 13.0],
    'regions': {'flash': ['O1', 'O2', 'Pz'], 'tone': ['Cz', 'C3', 'C4'],
                'alpha': ['O1', 'O2', 'Pz']},
    'anchor_row_shifts': [-1, 0, 1],
    'minimum_eligible_per_split': {'flash': 30, 'tone': 30, 'alpha': 12},
    'screen_peak_to_peak_uv': 250.0, 'screen_max_step_uv': 100.0,
    'bootstrap_replicates': 1000, 'bootstrap_seed': 20261110,
    'notes': [
        'Minimum counts and voltage screens are pilot policies, not power guarantees or clinical standards.',
        'Whole-pulse waveforms include the response to the 200 ms offset; edges are not separate trials.',
        'Alpha uses two separate 2 s linearly detrended symmetric-Hann periodograms, not induced-alpha isolation.',
        'No channel, timing shift or processing variant is selected for its outcome.',
        'Bootstrap intervals are conditional on this session; quarter-block sensitivity also reports drift.',
        'Sensor threshold crossing is not authenticated physical onset without sensor-delay qualification.',
    ],
}

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def safe(v):
    if isinstance(v, dict): return {str(k): safe(x) for k,x in v.items()}
    if isinstance(v, (list, tuple)): return [safe(x) for x in v]
    if isinstance(v, np.ndarray): return safe(v.tolist())
    if isinstance(v, (np.floating, float)): return float(v) if np.isfinite(v) else None
    if isinstance(v, np.integer): return int(v)
    if isinstance(v, np.bool_): return bool(v)
    return v

def write_json(path, value):
    Path(path).write_text(json.dumps(safe(value), indent=2, allow_nan=False), encoding='utf-8')

def truth(value): return value is True or str(value).lower() in ('true', '1')

def skill(observed, predicted, reference=0.0):
    den = float(np.sum((observed-reference)**2))
    return 1-float(np.sum((observed-predicted)**2))/den if den > 1e-20 else np.nan

def corr(a, b):
    a,b = np.ravel(a),np.ravel(b)
    return float(np.corrcoef(a,b)[0,1]) if np.std(a)>1e-12 and np.std(b)>1e-12 else np.nan

def alpha_power(x, fs):
    x = detrend(x, axis=0, type='linear')
    w = np.hanning(len(x))
    p = abs(np.fft.rfft(x*w[:,None], axis=0))**2 / (fs*np.sum(w*w))
    p[1:-1 if len(x)%2 == 0 else None] *= 2
    freq = np.fft.rfftfreq(len(x), 1/fs)
    return p[(freq>=8)&(freq<13)].sum(axis=0)*(fs/len(x))

def score_endpoint(train, test, bootstrap=1000):
    """Trial axis first. Only the frozen training mean supplies predictions."""
    if not len(train) or not len(test): return {'available': False}
    prediction = train.mean(axis=0)
    constant = float(train.mean())
    out = {'available': True, 'training_trials':len(train), 'validation_trials':len(test),
           'individual_skill_zero':skill(test,prediction),
           'individual_skill_training_constant':skill(test,prediction,constant),
           'average_skill_zero':skill(test.mean(axis=0),prediction),
           'average_correlation':corr(test.mean(axis=0),prediction),
           'individual_rmse':float(np.sqrt(np.mean((test-prediction)**2))),
           'observed_mean':float(test.mean()), 'predicted_mean':float(prediction.mean()),
           'signed_residual_mean':float((test-prediction).mean())}
    rng = np.random.default_rng(PLAN['bootstrap_seed'])
    boot_single,boot_average = [],[]
    for _ in range(bootstrap):
        v = test[rng.integers(len(test),size=len(test))]
        t = train[rng.integers(len(train),size=len(train))]
        boot_single.append(skill(v,prediction))
        boot_average.append(skill(v.mean(axis=0),t.mean(axis=0)))
    def ci(a):
        a = np.asarray(a); a = a[np.isfinite(a)]
        return np.quantile(a,[.025,.975]).tolist() if len(a) else [None,None]
    out['individual_skill_zero_ci95'] = ci(boot_single)
    out['average_skill_zero_ci95'] = ci(boot_average)
    out['validation_quarters'] = [
        {'trials':len(z),'individual_skill_zero':skill(z,prediction),
         'signed_residual_mean':float((z-prediction).mean())}
        for z in np.array_split(test,min(4,len(test))) if len(z)]
    return out

def clock_summary(t, fs):
    d = np.diff(t)
    return {'samples':len(t), 'all_finite':bool(np.isfinite(t).all()),
            'nonpositive_intervals':int(np.sum(d<=0)),
            'gaps_over_three_nominal_samples':int(np.sum(d>3/fs)),
            'median_interval_seconds':float(np.median(d)) if len(d) else None,
            'nominal_rate_hz':fs}

def evaluate(input_npz, metadata_path, events_path, out_dir, bootstrap=1000):
    out_dir=Path(out_dir); out_dir.mkdir(parents=True,exist_ok=True)
    metadata=json.loads(Path(metadata_path).read_text(encoding='utf-8-sig'))
    with np.load(input_npz,allow_pickle=False) as z:
        time=np.asarray(z['time'],float); eeg=np.asarray(z['eeg'],float)
        labels=[str(x) for x in z['channel_labels']]
        extras={k:np.asarray(z[k]) for k in ('eog','emg') if k in z.files}
    if time.ndim!=1 or len(time)<3 or eeg.shape!=(len(time),len(labels)) or len(set(labels))!=len(labels):
        raise ValueError('EEG/time/unique-channel dimensions do not agree')
    for name,value in extras.items():
        if value.ndim==1: extras[name]=value[:,None]
        if extras[name].ndim!=2 or extras[name].shape[0]!=len(time) or extras[name].shape[1]<1:
            raise ValueError('Independent artifact channel dimensions do not agree: '+name)
    fs=float(metadata['nominal_srate'])
    if not np.isfinite(fs) or fs<100 or fs>4000: raise ValueError('Unsupported nominal rate')
    events=list(csv.DictReader(Path(events_path).open(encoding='utf-8-sig',newline='')))
    if not events or len({e['trial_id'] for e in events})!=len(events):
        raise ValueError('Events must have unique trial IDs')
    if any(e['split'] not in ('train','validation') or e['kind'] not in ('flash','tone','alpha') for e in events):
        raise ValueError('Unknown event split or kind')
    if any(e['modality'] != ('audio' if e['kind']=='tone' else 'visual') for e in events):
        raise ValueError('Event kind/modality conflict')
    timed=[]
    for e in events:
        try: event_time=float(e['event_time_s'])
        except (ValueError,KeyError): continue
        if not np.isfinite(event_time): continue
        if truth(e.get('delivery_ok')):
            duration=float(e.get('observed_duration_s','nan'))
            expected_duration=3.0 if e['kind']=='alpha' else .2
            if not np.isfinite(duration) or abs(duration-expected_duration)>.08:
                raise ValueError('Qualified event lacks a compatible measured physical duration: '+e['trial_id'])
        timed.append((e,event_time))
    if any(b[1]<=a[1] for a,b in zip(timed,timed[1:])):
        raise ValueError('Physical event times must be unique and strictly chronological in the frozen order')
    split_order=[e['split'] for e,_ in timed]
    if 'validation' in split_order and 'train' in split_order[split_order.index('validation'):]:
        raise ValueError('Training events must precede all reserved events')
    for (a,at),(b,bt) in zip(timed,timed[1:]):
        duration=float(a.get('observed_duration_s','nan'))
        if np.isfinite(duration) and bt-(at+duration)<2.5-1e-9:
            raise ValueError('Events overlap or lack the fixed quiet history')
    unit_ok=metadata.get('eeg_units')=='uV' and truth(metadata.get('gain_verified'))
    clock=clock_summary(time,fs)
    clock_ok=clock['all_finite'] and clock['nonpositive_intervals']==0 and clock['gaps_over_three_nominal_samples']==0
    if not clock['all_finite'] or clock['nonpositive_intervals']:
        # No sorting, interpolating or silent duplicate removal.
        write_json(out_dir/'invalid_source.json',{'clock':clock,'reason':'Preserve and repair the source clock before event analysis.'})
        raise ValueError('Nonfinite or nonmonotonic source clock; no automatic clock repair is justified')
    qc=[]; arrays={}; summaries=[]
    wave_rel=np.arange(-round(.5*fs),round(.5*fs)+1)
    wave_baseline=wave_rel<0; wave_post=wave_rel>=0
    alpha_rel=np.arange(-round(2*fs),round(2.5*fs))
    alpha_base=alpha_rel<0; alpha_post=alpha_rel>=round(.5*fs)
    arrays['waveform_nominal_offsets_s']=wave_rel[wave_post]/fs
    arrays['alpha_frequencies_hz']=np.fft.rfftfreq(int(alpha_base.sum()),1/fs)
    independent=truth(metadata.get('independent_artifact_channels_verified')) and truth(metadata.get('artifact_units_verified')) and 'eog' in extras and 'emg' in extras
    external_limits=metadata.get('artifact_limits',{})
    independent=independent and all(float(external_limits.get(k,0))>0 for k in ('eog_ptp_uv','emg_rms_uv'))
    for kind in ('flash','tone','alpha'):
        chosen=[e for e in events if e['kind']==kind]
        n=len(chosen); rel=alpha_rel if kind=='alpha' else wave_rel
        nout=1 if kind=='alpha' else int(wave_post.sum())
        for shift in PLAN['anchor_row_shifts']:
            raw=np.full((n,nout,len(labels)),np.nan); linear=raw.copy()
            eligible=np.zeros((n,len(labels)),bool)
            for j,e in enumerate(chosen):
                reasons=[]; anchor=-1
                try: event_time=float(e['event_time_s'])
                except (ValueError,KeyError): event_time=np.nan
                if not np.isfinite(event_time): reasons.append('missing_physical_event')
                else:
                    k=int(np.searchsorted(time,event_time)); candidates=[x for x in (k-1,k) if 0<=x<len(time)]
                    anchor=min(candidates,key=lambda x:abs(time[x]-event_time))+shift
                idx=anchor+rel
                if not truth(e.get('delivery_ok')): reasons.append('delivery_not_qualified')
                if e.get('physical_sensor') not in ('light','audio'): reasons.append('software_only_event')
                if (kind=='tone' and e.get('physical_sensor')!='audio') or (kind!='tone' and e.get('physical_sensor')!='light'):
                    reasons.append('wrong_sensor_modality')
                if anchor<0 or idx[0]<0 or idx[-1]>=len(time): reasons.append('incomplete_source_support')
                base_row={'trial_id':e['trial_id'],'kind':kind,'split':e['split'],'anchor_shift':shift,'anchor_row':anchor}
                if reasons:
                    for label in labels: qc.append(dict(base_row,channel=label,eligible=False,reasons=';'.join(reasons)))
                    continue
                tt=time[idx]; x=eeg[idx]
                if np.max(np.diff(tt))>3/fs or np.max(abs((tt-time[anchor])-rel/fs))>1.5/fs:
                    reasons.append('irregular_source_support')
                ext_bad=False
                if independent:
                    eo=np.asarray(extras['eog'][idx]); em=np.asarray(extras['emg'][idx])
                    if not np.isfinite(eo).all() or not np.isfinite(em).all(): ext_bad=True
                    else:
                        # Independent EMG channel RMS after local linear trend removal; a screen, not source separation.
                        emd=detrend(em,axis=0,type='linear')
                        ext_bad=(np.max(np.ptp(eo,axis=0))>float(external_limits['eog_ptp_uv']) or
                                 np.max(np.sqrt(np.mean(emd**2,axis=0)))>float(external_limits['emg_rms_uv']))
                for c,label in enumerate(labels):
                    why=reasons.copy(); xx=x[:,c]
                    if not np.isfinite(xx).all(): why.append('nonfinite_eeg')
                    ptp=float(np.ptp(xx)); step=float(np.max(abs(np.diff(xx))))
                    if unit_ok and ptp>PLAN['screen_peak_to_peak_uv']: why.append('eeg_peak_to_peak_screen')
                    if unit_ok and step>PLAN['screen_max_step_uv']: why.append('eeg_step_screen')
                    if ext_bad: why.append('independent_artifact_screen')
                    eligible[j,c]=not why
                    qc.append(dict(base_row,channel=label,eligible=not why,reasons=';'.join(why),
                                   peak_to_peak=ptp,max_step=step,voltage_screen_supported=unit_ok,
                                   independent_artifact_screen_supported=independent))
                # Preserve all supported measurements, including excluded events.
                finite_columns=np.flatnonzero(np.isfinite(x).all(axis=0))
                if len(finite_columns):
                    xf=x[:,finite_columns]
                    if kind=='alpha':
                        pb=alpha_power(xf[alpha_base],fs); pp=alpha_power(xf[alpha_post],fs)
                        raw[j,0,finite_columns]=np.log(np.maximum(pp,1e-12)/np.maximum(pb,1e-12)); linear[j]=raw[j]
                    else:
                        raw[j][:,finite_columns]=(xf-xf[wave_baseline].mean(axis=0))[wave_post]
                        xd=detrend(xf,axis=0,type='linear')
                        linear[j][:,finite_columns]=(xd-xd[wave_baseline].mean(axis=0))[wave_post]
            key=f'{kind}_shift{shift:+d}'
            arrays[key+'_observed']=raw; arrays[key+'_detrended']=linear
            arrays[key+'_eligible']=eligible; arrays[key+'_trial_ids']=np.array([e['trial_id'] for e in chosen])
            arrays[key+'_splits']=np.array([e['split'] for e in chosen])
            region=PLAN['regions'][kind]; exists=all(x in labels for x in region)
            outcomes=[('primary_region',[labels.index(x) for x in region])] if exists else []
            outcomes += [(label,[i]) for i,label in enumerate(labels)]
            for outcome,columns in outcomes:
                keep=eligible[:,columns].all(axis=1)
                training=np.array([e['split']=='train' for e in chosen]) & keep
                validation=np.array([e['split']=='validation' for e in chosen]) & keep
                for processing,values in [('raw',raw)]+([] if kind=='alpha' else [('linear_detrend',linear)]):
                    y=values[:,:,columns].mean(axis=2)
                    # Scalar alpha = mean channel log ratios, not log power of an averaged voltage.
                    s=score_endpoint(y[training],y[validation],bootstrap if outcome=='primary_region' else 0)
                    s.update(kind=kind,anchor_shift=shift,processing=processing,outcome=outcome,
                             channels=[labels[i] for i in columns],primary=outcome=='primary_region' and shift==0 and processing=='raw',
                             minimum_count=PLAN['minimum_eligible_per_split'][kind])
                    if s['available']:
                        s['counts_sufficient']=min(s['training_trials'],s['validation_trials'])>=s['minimum_count']
                        if outcome=='primary_region':
                            arrays[key+'_'+processing+'_roi_observed']=y
                            arrays[key+'_'+processing+'_roi_prediction']=np.broadcast_to(y[training].mean(axis=0),y.shape).copy()
                            arrays[key+'_'+processing+'_roi_residual']=y-y[training].mean(axis=0)
                            arrays[key+'_'+processing+'_roi_training_eligible']=training
                            arrays[key+'_'+processing+'_roi_validation_eligible']=validation
                    summaries.append(s)
    primary=[s for s in summaries if s['primary']]
    regions_ok=len(primary)==3
    prereqs={
        'complete_session':truth(metadata.get('session_complete')),
        'same_task_and_fixed_split':truth(metadata.get('same_task_protocol')),
        'recorded_event_sequence_complete':truth(metadata.get('recorded_event_sequence_complete')),
        'physical_delivery_checks':truth(metadata.get('physical_delivery_checks_passed')),
        'source_clock_continuity':bool(clock_ok),
        'documented_acquisition_clock':truth(metadata.get('clock_association_verified')),
        'channel_mapping_reference_gain':all(truth(metadata.get(k)) for k in ('channel_mapping_verified','reference_verified','gain_verified')) and unit_ok,
        'fixed_regions_available':regions_ok,
        'light_sensor_delay_documented':truth(metadata.get('light_sensor_verified')),
        'audio_sensor_delay_documented':truth(metadata.get('audio_sensor_verified')),
        'independent_artifact_screen_available':bool(independent),
    }
    for s in primary:
        available=s['available'] and s.get('counts_sufficient',False)
        s['averaged_response_gate']='supported_in_this_session' if available and (s.get('average_skill_zero_ci95') or [None])[0] is not None and s['average_skill_zero_ci95'][0]>0 else 'not_established'
        s['individual_prediction_gate']='supported_in_this_session' if available and (s.get('individual_skill_zero_ci95') or [None])[0] is not None and s['individual_skill_zero_ci95'][0]>0 else 'not_established'
        shifts=[v for v in summaries if v['kind']==s['kind'] and v['outcome']=='primary_region' and v['processing']=='raw']
        s['all_anchor_shifts_positive']=len(shifts)==3 and all(v.get('individual_skill_zero',-np.inf)>0 for v in shifts)
        sensitivity=next((v for v in summaries if v['kind']==s['kind'] and v['outcome']=='primary_region' and v['processing']=='linear_detrend' and v['anchor_shift']==0),None)
        s['detrended_individual_skill_zero']=sensitivity.get('individual_skill_zero') if sensitivity else None
    result={'schema':'cetr.calibration.validation.v1','recording_id':metadata.get('recording_id','unnamed'),
            'evidence_kind':metadata.get('evidence_kind','real'), 'plan':PLAN, 'clock':clock,
            'acquisition_prerequisites':prereqs,'primary_endpoints':primary,'all_endpoints':summaries,
            'artifact_policy':{'voltage_screen_supported':unit_ok,'independent_screen_supported':independent,
                               'independent_limits':external_limits},
            'transfer_to_movies':'not_tested_by_this_session','meaning_and_delayed_understanding':'not_tested',
            'interpretation':'Conditional within-session prediction is separate from cortical source attribution, movie transfer, and meaning.',
            'bindings':{str(Path(p).name):digest(p) for p in (input_npz,metadata_path,events_path)},
            'bootstrap_replicates':bootstrap}
    result['sample_windows']={'waveform_baseline_samples':int(wave_baseline.sum()),'waveform_response_samples':int(wave_post.sum()),
        'waveform_first_response_s':float(wave_rel[wave_post][0]/fs),'waveform_last_response_s':float(wave_rel[wave_post][-1]/fs),
        'alpha_baseline_samples':int(alpha_base.sum()),'alpha_response_samples':int(alpha_post.sum()),
        'alpha_baseline_bins_hz':np.fft.rfftfreq(int(alpha_base.sum()),1/fs)[(np.fft.rfftfreq(int(alpha_base.sum()),1/fs)>=8)&(np.fft.rfftfreq(int(alpha_base.sum()),1/fs)<13)].tolist()}
    result['qualification']='synthetic_software_test_only' if result['evidence_kind']=='synthetic' else (
        'within_session_prediction_supported' if all(prereqs.values()) and len(primary)==3 and all(s.get('individual_prediction_gate')=='supported_in_this_session' and s.get('all_anchor_shifts_positive') for s in primary) else 'not_qualified')
    np.savez_compressed(out_dir/'measurements_predictions.npz',**arrays)
    fields=sorted(set().union(*(q.keys() for q in qc)))
    with (out_dir/'event_quality.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(qc)
    write_json(out_dir/'analysis_plan.json',PLAN);write_json(out_dir/'validation.json',result)
    render_report(result,out_dir/'REPORT.html')
    return result

def render_report(result,path):
    e=html.escape
    def number(x): return 'Unavailable' if x is None or not np.isfinite(x) else f'{100*x:.2f}%'
    rows=''.join('<tr>'+''.join(f'<td>{e(str(x))}</td>' for x in [s['kind'],s.get('training_trials',0),s.get('validation_trials',0),number(s.get('individual_skill_zero')),number(s.get('average_skill_zero')),s.get('individual_prediction_gate','not_established')])+'</tr>' for s in result['primary_endpoints'])
    gates=''.join(f'<li>{e(k.replace("_"," "))}: <b>{"documented / passed" if v else "not established"}</b></li>' for k,v in result['acquisition_prerequisites'].items())
    page='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CET-R calibration validation</title><style>body{font:17px/1.6 system-ui;margin:auto;max-width:1100px;padding:40px 24px;color:#152b36;background:#f3f6f4}h1{font-size:38px;line-height:1.15}table{border-collapse:collapse;width:100%;background:white}td,th{padding:14px;text-align:left;border-bottom:1px solid #d8e2df}.table{overflow:auto}.label{font-weight:bold;color:#936220}a{color:#08666e}code{overflow-wrap:anywhere}.panel{background:white;padding:24px;border-radius:16px;margin:24px 0}</style><body>'''
    page+=f'<p class="label">CET-R · calibration validation</p><h1>{e(result["recording_id"])}</h1><p><b>{e(result["qualification"].replace("_"," "))}</b></p>'
    page+='<p>Physical timing, response repeatability, individual prediction, transfer and meaning are separate questions. Passing a software test does not establish a biological result.</p>'
    page+=f'<div class="panel"><h2>Fixed primary endpoints</h2><div class="table"><table><thead><tr><th>Measure</th><th>Train</th><th>Reserved</th><th>Individual skill vs zero</th><th>Average skill vs zero</th><th>Individual prediction</th></tr></thead><tbody>{rows}</tbody></table></div><p>Skill compares squared prediction error with zero event-related change. Averaged scores use the reserved mean response; they do not establish individual-response prediction. Confidence intervals and every channel/timing variant are retained in the evidence.</p></div>'
    page+=f'<div class="panel"><h2>Acquisition and delivery prerequisites</h2><ul>{gates}</ul><p>Metadata confirmations document operator checks; they are not independent proof. Sensor crossing times require a documented sensor-to-EEG clock relationship. EEG and independent artifact screens are pilot policies, not proof of cortical origin.</p></div>'
    page+='<div class="panel"><h2>Scope</h2><p>Within-session bootstrap intervals resample trials, not EEG samples. Repeated trials may still share slow drift; fixed validation-quarter results are included. Raw and detrended waveforms are reported separately, without choosing a winner. No CII endpoint is rewritten, and no movie transfer or delayed understanding claim is made.</p><p><a href="validation.json">Full validation evidence</a> · <a href="event_quality.csv">Every trial/channel quality decision</a> · <a href="measurements_predictions.npz">Observed, predicted and signed residual arrays</a> · <a href="analysis_plan.json">Fixed analysis plan</a></p></div></body></html>'
    Path(path).write_text(page,encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',required=True);p.add_argument('--metadata',required=True);p.add_argument('--events',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();result=evaluate(a.input,a.metadata,a.events,a.out)
    print(json.dumps({'qualification':result['qualification'],'report':str(Path(a.out)/'REPORT.html')}))
