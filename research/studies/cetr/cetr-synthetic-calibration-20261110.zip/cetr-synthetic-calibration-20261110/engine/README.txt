FIXED CALIBRATION ANALYSIS CONTRACT

Use the root validate_session.py command for a recorded runner session. It imports
the explicit XDF streams, validates the frozen configuration and schedule, matches
physical sensor events, preserves source timestamps and produces the report.
analysis.py also supports trusted canonical arrays for engineering tests. Canonical
metadata are input assertions and cannot independently authenticate acquisition.

CANONICAL INPUT
recording.npz: time[N], eeg[N,C] in documented microvolts, channel_labels[C].
Optional eog[N,K] and emg[N,K] use independent recorded columns and verified units.
metadata.json: nominal_srate; acquisition/delivery/montage/reference/gain flags;
artifact limits; evidence_kind='synthetic' for generated data. Real source and
configuration bindings are supplied by the XDF importer, not invented by analysis.
events.csv: unique trial_id, block_id, split(train/validation), kind(flash/tone/alpha),
modality(visual/audio), measured event_time_s, observed_duration_s, physical_sensor
(light/audio), delivery_ok. Events follow frozen chronological order with training
before reserved trials and adequate measured quiet history.

PRIMARY MEASUREMENTS
Each pulse is one trial; its onset and offset are not independent observations.
Whole-pulse waveform: raw recorded EEG minus the preceding approximately0.5s mean;
response spans source offsets0 throughround(0.5*rate), inclusive. At125Hz this gives
62 baseline rows and63 response rows ending0.496s. Actual rounding/samplecounts
are exported. Separate full-epoch linear-detrend sensitivity is never selected.

Alpha: baseline offsets-round(2*rate) through-1; response round(.5*rate) through
round(2.5*rate)-1. At125Hz both have250samples (2s); response starts0.496s under
the fixed row-rounding rule. Independently remove a line in each window; multiply
by symmetricHann; one-sided PSD normalized byrate*sum(Hann^2), interior bins doubled.
Sum8<=f<13Hz times frequency spacing. At125Hz/250samples bins are8,8.5,...,12.5Hz.
Naturallog(post/pre) uses floor1e-12. This is coarse band power, not isolated induced
alpha. ROI alpha is the mean of channel logratios, not power of averaged voltage.

Fixed primary regions: flash/alpha O1,O2,Pz; tone Cz,C3,C4, requiring all members.
Every channel, every shift(-1,0,+1source row), and both waveform processing variants
are retained. Secondary channel successes do not replace a failed fixed region.

PREDICTION
Freeze the mean of eligible training trials. Apply it unchanged to reserved trials.
Skill=1-SSE_model/SSE_reference. Primary reference is zero event-related change;
secondary is one scalar mean of the same training responses. For scalar alpha,
the frozen mean and training constant are algebraically identical.

Report individual-trial skill and skill against the reserved mean separately.
Individual uncertainty resamples reserved trials against the frozen template;
averaged-response uncertainty resamples both training and reserved trials.1000
replicates, seed20261110. Intervals are conditional on this session and potentially
optimistic under slow dependence. Four ordered reserved-trial groups expose drift.
Count policy: at least30eligible trials per split for waveform and12for alpha.
Positive lower95%bootstrap bounds support an endpoint within this session only;
they are not a multiple-comparison-corrected general neuroscience confirmation.

SCREENS AND CLAIMS
EEG peak-to-peak250uV and step100uV screens are declared pilot policies applied only
when units/gain are verified. Unknown units remain unsupported. Independent EOG
range and detrended EMG RMS use predeclared setup-specific limits. These screens
cannot establish cortical origin, and no EEG-derived proxy is substituted for an
independent artifact channel. Gross source failures are not silently repaired.

Do not interpret a positive calibration endpoint as a validated movie model or a
measurement of purified meaning. Observed/predicted/signed residual arrays remain
separate; the analysis does not modify NIP, CII or A2/A3 endpoints.

METHOD REFERENCES
Crosse et al.2016: https://pmc.ncbi.nlm.nih.gov/articles/PMC5127806/
LSL synchronization: https://labstreaminglayer.readthedocs.io/info/time_synchronization.html
These support stimulus-response modeling and clock semantics; they do not validate
this new pilot's chosen counts, thresholds or performance.
