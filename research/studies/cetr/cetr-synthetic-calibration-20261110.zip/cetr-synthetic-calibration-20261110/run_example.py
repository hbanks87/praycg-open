"""Generate and analyze the original known-answer synthetic calibration fixture."""
from pathlib import Path
import sys,json,argparse
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'methods_audit'));sys.path.insert(0,str(ROOT/'engine'))
from verify_engine_independent import write_fixture
from analysis import evaluate
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=ROOT/'generated_example');args=parser.parse_args()
dest=args.out.resolve()
if dest.exists():raise SystemExit('Choose a new output directory; refusing to overwrite.')
dest.mkdir(parents=True)
write_fixture(dest/'input')
evaluate(dest/'input/recording.npz',dest/'input/metadata.json',dest/'input/events.csv',dest/'validation',bootstrap=100)
result=json.loads((dest/'validation/validation.json').read_text())
assert result['qualification']=='synthetic_software_test_only'
assert result['transfer_to_movies']=='not_tested_by_this_session'
assert result['meaning_and_delayed_understanding']=='not_tested'
assert len(result['primary_endpoints'])==3
print(json.dumps({'status':'PASS','qualification':result['qualification'],'primary_endpoints':result['primary_endpoints']},indent=2))
