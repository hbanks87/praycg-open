# CET-R synthetic calibration reproduction

This runs the existing November 10 calibration engine and its independent numerical audit using generated signals only. It contains no recorded EEG, derived historical caches, movie assets or participant records.

Python 3.11; from a fresh extracted folder:

```sh
python -m pip install -r requirements.txt
python run_example.py
python methods_audit/verify_engine_independent.py
```

The first command after installation generates 144 synthetic presentations and saves an inspectable input NPZ, metadata, event CSV, predictions and HTML report under `generated_example/`. Every positive hardware attestation in that fixture is explicitly artificial. The second executes the unchanged independent audit, including malformed inputs, no-response controls, an independent eye-channel spike and reserved-outcome perturbation. It expects 155 passing checks and writes `methods_audit/engine_verification.json`.

The model freezes training-average responses, scores reserved trials against zero change and the training constant, exports signed residuals and retains all predefined channels, regions, raw/detrended variants and +/-1 source-row shifts. Alpha uses separate two-second detrended Hann periodograms, 8–13 Hz. The audit independently reconstructs these quantities with SciPy and checks 1e-10 relative/absolute tolerance. QA uses 100 bootstrap draws; production defaults to 1000.

A software PASS must remain `synthetic_software_test_only`. It is not evidence of cortical origin, real stimulus delivery, successful movie transfer, narrative meaning, a CII/NIP endpoint or a human effect. See EXPECTED.json, SOURCE_PROVENANCE.json and NOTICE.md. The accompanying public methodology page separately summarizes the historical Turn Around results; its real-data analysis is not rerun by this bundle.
