# Source and dependency notice

PRAYCG study code and public reproduction helpers by Hoyt Banks, 2026.
The original method filenames and SHA256 identities are retained in SOURCE_PROVENANCE.json.
Original PRAYCG-owned reproduction code follows the MIT terms in the accompanying LICENSE.md. Third-party materials retain their applicable terms.
NumPy and SciPy are separately installed dependencies under their own BSD licenses. They are not vendored here.
No third-party recordings, movie assets, compiler binaries or Python environment are redistributed.
This is research software, not a qualified physiological measurement or clinical instrument.
