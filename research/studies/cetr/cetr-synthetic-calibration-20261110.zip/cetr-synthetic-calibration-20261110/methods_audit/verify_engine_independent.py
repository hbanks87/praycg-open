"""Independent numerical reconstruction plus adverse-input engine checks.

All source samples in this test are generated, not recorded EEG. The producer is
run through its public entry point in a separate process. Expected numerical
values are computed here without importing any producer calculation functions.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import numpy as np
from scipy.signal import periodogram

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
FS = 125.0
LABELS = ["O1", "O2", "Pz", "Cz", "C3", "C4"]


def save_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_fixture(folder):
    folder.mkdir(parents=True, exist_ok=True)
    events, current, ordinal = [], 5.0, 0
    schedule_rng = np.random.default_rng(7151)
    for split in ("train", "validation"):
        for kind, count in (("flash", 30), ("tone", 30), ("alpha", 12)):
            for number in range(count):
                ordinal += 1
                duration = 3.0 if kind == "alpha" else .2
                events.append({"trial_id": f"{split}_{kind}_{number+1:03d}", "trial_ordinal": ordinal,
                               "block_id": f"{split}_{kind}", "split": split, "kind": kind,
                               "modality": "audio" if kind == "tone" else "visual",
                               "event_time_s": current, "duration_s": duration,
                               "observed_duration_s": duration, "sensor_offset_time_s": current + duration,
                               "physical_sensor": "audio" if kind == "tone" else "light", "delivery_ok": True})
                current = round(current + duration + schedule_rng.integers(3000, 4001) / 1000, 6)
    time = np.arange(int((current + 4) * FS)) / FS
    rng = np.random.default_rng(14731)
    eeg = rng.normal(0, .8, (len(time), len(LABELS)))
    for event in events:
        anchor = int(round(event["event_time_s"] * FS))
        if event["kind"] == "alpha":
            for offsets, amplitude in ((np.arange(-250, 0), 3.0), (np.arange(63, 313), 8.0)):
                signal = amplitude * np.sin(2 * np.pi * 10 * offsets / FS)
                eeg[np.ix_(anchor + offsets, np.arange(3))] += signal[:, None]
        else:
            offsets = np.arange(0, 63)
            seconds = offsets / FS
            waveform = 18 * np.exp(-((seconds - .12) / .04) ** 2) - 10 * np.exp(-((seconds - .28) / .06) ** 2)
            columns = np.arange(3) if event["kind"] == "flash" else np.arange(3, 6)
            eeg[np.ix_(anchor + offsets, columns)] += waveform[:, None]
    arrays = {"time": time, "eeg": eeg, "channel_labels": np.array(LABELS),
              "eog": rng.normal(0, .1, (len(time), 1)), "emg": rng.normal(0, .1, (len(time), 1))}
    metadata = {"schema": "cetr.calibration.recording.v1", "recording_id": "SIMULATED_INDEPENDENT_NUMERICAL_AUDIT",
                "evidence_kind": "synthetic", "nominal_srate": FS, "eeg_units": "uV",
                "gain_verified": True, "channel_mapping_verified": True, "reference_verified": True,
                "session_complete": True, "same_task_protocol": True, "recorded_event_sequence_complete": True,
                "physical_delivery_checks_passed": True, "clock_association_verified": True,
                "light_sensor_verified": True, "audio_sensor_verified": True,
                "independent_artifact_channels_verified": True,
                "artifact_units_verified": True,
                "artifact_limits": {"eog_ptp_uv": 200, "emg_rms_uv": 50},
                "test_note": "ALL samples and positive attestations are simulated solely to exercise code paths."}
    np.savez_compressed(folder / "recording.npz", **arrays)
    save_json(folder / "metadata.json", metadata)
    write_events(folder / "events.csv", events)
    return arrays, metadata, events


def write_events(path, events):
    with Path(path).open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(events[0]))
        writer.writeheader()
        writer.writerows(events)


def run_case(folder, output):
    # Calling the public function only changes bootstrap effort for software QA.
    code = "import sys; sys.path.insert(0,sys.argv[1]); from analysis import evaluate; evaluate(sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],bootstrap=100)"
    return subprocess.run([sys.executable, "-c", code, str(ROOT / "engine"), str(folder / "recording.npz"),
                           str(folder / "metadata.json"), str(folder / "events.csv"), str(output)],
                          capture_output=True, text=True)


def remove_line(values):
    coordinate = np.arange(len(values), dtype=float)
    coordinate -= coordinate.mean()
    centered = values - values.mean(axis=0)
    slope = coordinate @ centered / (coordinate @ coordinate)
    return centered - coordinate[:, None] * slope


def independent_alpha(values):
    frequencies, density = periodogram(remove_line(values), fs=FS, window=np.hanning(len(values)),
                                       detrend=False, return_onesided=True, scaling="density", axis=0)
    return density[(frequencies >= 8) & (frequencies < 13)].sum(axis=0) * (FS / len(values))


def independent_score(observed, prediction, reference=0):
    denominator = np.square(observed - reference).sum()
    return 1 - np.square(observed - prediction).sum() / denominator if denominator > 1e-20 else np.nan


def main():
    checks = []
    producer_sha_before = hashlib.sha256((ROOT / "engine" / "analysis.py").read_bytes()).hexdigest()
    def check(name, condition, detail=None):
        checks.append({"name": name, "passed": bool(condition), "detail": detail})

    with tempfile.TemporaryDirectory(prefix="engine_audit_", dir=HERE) as temporary:
        temporary = Path(temporary)
        fixture = temporary / "source"
        arrays, metadata, events = write_fixture(fixture)
        result_path = temporary / "baseline"
        completed = run_case(fixture, result_path)
        if completed.returncode:
            raise RuntimeError(completed.stderr)
        results = json.loads((result_path / "validation.json").read_text())
        with np.load(result_path / "measurements_predictions.npz", allow_pickle=False) as archive:
            measurements = {key: archive[key] for key in archive.files}
        check("synthetic evidence cannot become biological qualification", results["qualification"] == "synthetic_software_test_only")
        check("three fixed primary endpoints", len(results["primary_endpoints"]) == 3)
        check("movie transfer remains untested", results["transfer_to_movies"] == "not_tested_by_this_session")
        check("meaning remains untested", results["meaning_and_delayed_understanding"] == "not_tested")
        expected_values = {}
        for kind in ("flash", "tone", "alpha"):
            selected = [event for event in events if event["kind"] == kind]
            for shift in (-1, 0, 1):
                raw, linear = [], []
                for event in selected:
                    # Full-vector minimization independently resolves nearest
                    # actual sample time, including floating-point half rows.
                    anchor = int(np.argmin(abs(arrays["time"] - float(event["event_time_s"])))) + shift
                    if kind == "alpha":
                        baseline = arrays["eeg"][anchor + np.arange(-250, 0)]
                        response = arrays["eeg"][anchor + np.arange(62, 312)]
                        value = np.log(np.maximum(independent_alpha(response), 1e-12) / np.maximum(independent_alpha(baseline), 1e-12))[None, :]
                        raw.append(value); linear.append(value)
                    else:
                        offsets = np.arange(-62, 63)
                        values = arrays["eeg"][anchor + offsets]
                        value = values - values[:62].mean(axis=0)
                        other = remove_line(values)
                        other -= other[:62].mean(axis=0)
                        raw.append(value[62:]); linear.append(other[62:])
                prefix = f"{kind}_shift{shift:+d}"
                raw, linear = np.array(raw), np.array(linear)
                expected_values[prefix] = (raw, linear, selected)
                check(f"{prefix}: baseline and whole-pulse/power reconstruction", np.allclose(measurements[prefix + "_observed"], raw, rtol=1e-10, atol=1e-10))
                check(f"{prefix}: independent linear-detrend reconstruction", np.allclose(measurements[prefix + "_detrended"], linear, rtol=1e-10, atol=1e-10))
                check(f"{prefix}: clean generated supports eligible", measurements[prefix + "_eligible"].all())
        for index, endpoint in enumerate(results["all_endpoints"]):
            if not endpoint["available"]:
                check(f"endpoint {index}: available fixture", False)
                continue
            prefix = f"{endpoint['kind']}_shift{endpoint['anchor_shift']:+d}"
            raw, linear, selected = expected_values[prefix]
            values = raw if endpoint["processing"] == "raw" else linear
            indices = [LABELS.index(label) for label in endpoint["channels"]]
            data = values[:, :, indices].mean(axis=2)
            train = data[[event["split"] == "train" for event in selected]]
            test = data[[event["split"] == "validation" for event in selected]]
            prediction = train.mean(axis=0)
            expected = {"individual_skill_zero": independent_score(test, prediction),
                        "individual_skill_training_constant": independent_score(test, prediction, train.mean()),
                        "average_skill_zero": independent_score(test.mean(axis=0), prediction),
                        "individual_rmse": float(np.sqrt(np.square(test - prediction).mean())),
                        "observed_mean": test.mean(), "predicted_mean": prediction.mean(),
                        "signed_residual_mean": (test - prediction).mean()}
            check(f"endpoint {index}: independent prediction/skill/residual reconstruction",
                  all(np.isclose(endpoint[name], value, rtol=1e-10, atol=1e-10, equal_nan=True) for name, value in expected.items()))

        def mutate(name, transform, expect_exception=False, expected_qualification=None):
            folder = temporary / name
            folder.mkdir()
            local_arrays = {k: v.copy() for k, v in arrays.items()}
            local_meta = json.loads(json.dumps(metadata))
            local_events = json.loads(json.dumps(events))
            transform(local_arrays, local_meta, local_events)
            np.savez_compressed(folder / "recording.npz", **local_arrays)
            save_json(folder / "metadata.json", local_meta)
            write_events(folder / "events.csv", local_events)
            output = temporary / (name + "_results")
            run = run_case(folder, output)
            if expect_exception:
                check(name + ": adverse input refused", run.returncode != 0, run.stderr.splitlines()[-1] if run.stderr else None)
            else:
                check(name + ": evaluable diagnostic", run.returncode == 0, run.stderr[-200:] if run.returncode else None)
                if run.returncode == 0:
                    document = json.loads((output / "validation.json").read_text())
                    if expected_qualification:
                        check(name + ": qualification withheld", document["qualification"] == expected_qualification)
                    return document, output
            return None, output

        mutate("nonmonotonic_source", lambda a, m, e: a["time"].__setitem__(100, a["time"][99]), expect_exception=True)
        mutate("nonfinite_source", lambda a, m, e: a["time"].__setitem__(100, np.nan), expect_exception=True)
        mutate("duplicate_trial_identity", lambda a, m, e: e[1].__setitem__("trial_id", e[0]["trial_id"]), expect_exception=True)
        mutate("duplicate_physical_event", lambda a, m, e: e[1].__setitem__("event_time_s", e[0]["event_time_s"]), expect_exception=True)
        mutate("reversed_event_order", lambda a, m, e: e.reverse(), expect_exception=True)
        mutate("malformed_independent_channel", lambda a, m, e: a.__setitem__("eog", a["eog"][:-1]), expect_exception=True)
        changed_meta, _ = mutate("unknown_voltage_units", lambda a, m, e: m.__setitem__("eeg_units", "unknown"))
        if changed_meta:
            check("unknown_voltage_units: voltage screen not supported", changed_meta["artifact_policy"]["voltage_screen_supported"] is False)
            check("unknown_voltage_units: acquisition prerequisite fails", changed_meta["acquisition_prerequisites"]["channel_mapping_reference_gain"] is False)
        def null_source(a, m, e):
            rng = np.random.default_rng(82761)
            phase = 2 * np.pi * 10 * a["time"][:, None] + np.arange(len(LABELS))[None, :] * .1
            a["eeg"] = 3 * np.sin(phase) + rng.normal(0, 1, a["eeg"].shape)
        null_result, _ = mutate("continuous_alpha_without_evoked_response", null_source)
        if null_result:
            for endpoint in null_result["primary_endpoints"]:
                lower = endpoint.get("individual_skill_zero_ci95", [None])[0]
                check(f"null carrier with jitter: {endpoint['kind']} individual response not established", lower is not None and lower <= 0 and endpoint["individual_prediction_gate"] == "not_established")
        def artifact_spike(a, m, e):
            anchor = round(float(e[0]["event_time_s"]) * FS)
            a["eog"][anchor, 0] = 500
        artifact_result, _ = mutate("independent_eye_spike", artifact_spike)
        if artifact_result:
            flash = next(endpoint for endpoint in artifact_result["primary_endpoints"] if endpoint["kind"] == "flash")
            check("independent eye spike excludes trial from fixed ROI", flash["training_trials"] == 29 and flash["counts_sufficient"] is False)
            check("independent eye screen exercised", artifact_result["artifact_policy"]["independent_screen_supported"] is True)
        document, output = mutate("validation_only_perturbation", lambda a, m, e: a["eeg"].__setitem__(slice(round(e[72]["event_time_s"] * FS), None), a["eeg"][round(e[72]["event_time_s"] * FS):] * 1.2))
        if document:
            with np.load(output / "measurements_predictions.npz", allow_pickle=False) as modified:
                prediction_keys = [name for name in measurements if name.endswith("_roi_prediction")]
                check("reserved outcomes do not change any frozen prediction", all(np.array_equal(modified[name], measurements[name]) for name in prediction_keys))
        source_bindings = {"engine/analysis.py": hashlib.sha256((ROOT / "engine" / "analysis.py").read_bytes()).hexdigest()}
        check("producer remained unchanged throughout audit", source_bindings["engine/analysis.py"] == producer_sha_before)

    result = {"schema": "cetr.independent.engine.audit.v1", "status": "PASS" if all(item["passed"] for item in checks) else "FAIL",
              "check_count": len(checks), "checks": checks, "source_sha256": source_bindings,
              "scope": "Generated numerical fixtures only; no physiological evidence. Independent baseline, OLS detrend, SciPy periodogram and frozen score reconstruction.",
              "bootstrap_note": "100 replicates for numerical software QA; production default remains 1000."}
    destination = HERE / "engine_verification.json"
    save_json(destination, result)
    print(json.dumps({"status": result["status"], "checks": len(checks), "failures": [item["name"] for item in checks if not item["passed"]], "output": str(destination)}))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
