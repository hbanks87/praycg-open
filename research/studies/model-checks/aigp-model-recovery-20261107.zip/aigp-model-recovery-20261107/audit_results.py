"""Post-run independent audit; added after freeze, never fits or changes data.

All episode forecasts are reconstructed with audit_models.ref_log_components,
which is independent of the candidate C++ kernel. Aggregation below does not
import either analyzer. Run only after production RESULTS.json is complete.
"""
from pathlib import Path
from collections import defaultdict, Counter
import csv, datetime, difflib, hashlib, json, math
import numpy as np
from audit_models import ref_log_components

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'results'
SCENARIOS = ('short_standard','long_standard','more_probes','noisy_measurement',
             'chance_probe','weak_update','near_universal')
GENERATORS = ('S','I','C','F','E')
MODELS = ('S','I','C','IF','F','E')
REGIMES = ('joint','update_only')
ALIASES = {'decoder_admission':'S','ordinary_shared_attention':'S','shared_memory_availability':'S'}
MARGIN = .001

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def check(condition, label):
    if not condition: raise AssertionError(label)
def close(a,b,tol=1e-10):
    return math.isfinite(float(a)) and math.isfinite(float(b)) and abs(float(a)-float(b))<=tol
def verify(mapping):
    check(bool(mapping),'Empty hash mapping')
    for p,h in mapping.items(): check(sha(ROOT/p)==h,'Binding changed: '+p)
def interval(k,n):
    # Direct score-interval quadratic solution, independently arranged.
    z=1.959963984540054
    d=n+z*z
    center=(k+z*z/2)/d
    half=z*math.sqrt(k*(n-k)/n+z*z/4)/d
    return dict(count=k,n=n,rate=k/n,wilson_low95=max(0.,center-half),wilson_high95=min(1.,center+half))
def moments(truth,estimate):
    x=np.asarray(truth,float); y=np.asarray(estimate,float); err=y-x
    mx=math.fsum(x)/len(x); my=math.fsum(y)/len(y)
    dx=x-mx;dy=y-my
    vx=math.fsum(dx*dx);vy=math.fsum(dy*dy)
    varying=math.sqrt(vx/len(x))>1e-12 and math.sqrt(vy/len(y))>1e-12
    corr=math.fsum(dx*dy)/math.sqrt(vx*vy) if varying else None
    return dict(n=len(x),true_mean=mx,fitted_mean=my,bias=math.fsum(err)/len(x),
                rmse=math.sqrt(math.fsum(err*err)/len(x)),mean_absolute_error=math.fsum(abs(err))/len(x),
                pearson_r=corr,association_note='Pearson association' if varying else 'Undefined: constant true or fitted values')
def compare(actual,expected,label='root',tol=1e-10):
    if isinstance(expected,dict):
        check(isinstance(actual,dict) and set(actual)==set(expected),label+' fields')
        for k,v in expected.items(): compare(actual[k],v,label+'.'+k,tol)
    elif isinstance(expected,(list,tuple)):
        check(isinstance(actual,(list,tuple)) and len(actual)==len(expected),label+' length')
        for i,(a,e) in enumerate(zip(actual,expected)): compare(a,e,label+f'[{i}]',tol)
    elif isinstance(expected,(bool,str)) or expected is None:
        check(type(actual)==type(expected) and actual==expected,label+' value')
    else: check(close(actual,expected,tol),label+f' numeric {actual} != {expected}')

def csv_check(name,expected):
    with (OUT/name).open(encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f); actual=list(reader);fields=reader.fieldnames
    check(len(actual)==len(expected),name+' row count')
    if expected: check(set(fields)==set().union(*(x.keys() for x in expected)),name+' field union')
    for i,(a,e) in enumerate(zip(actual,expected)):
        for k in fields:
            value=e.get(k)
            if value is None: check(a[k]=='',f'{name}:{i}:{k} empty')
            elif isinstance(value,bool): check(a[k]==str(value),f'{name}:{i}:{k} bool')
            elif isinstance(value,(float,int,np.number)): check(close(a[k],value),f'{name}:{i}:{k} numeric')
            else: check(a[k]==str(value),f'{name}:{i}:{k} text')
    return len(actual)

def audit():
    check((OUT/'RESULTS.json').exists(),'RESULTS not yet ready')
    frozen=read(ROOT/'FROZEN_MANIFEST.json'); verify(frozen['sha256'])
    status=read(ROOT/'SIMULATION_VALIDATION_STATUS.json'); check(status['status']=='passed','Pre-evaluation status')
    verify(status['sha256'])
    postfit=read(ROOT/'POSTFIT_REVIEW.json');check(postfit['status'].startswith('passed'),'Observed-only audit')
    generation=read(ROOT/'PRODUCTION_GENERATION.json')
    check(generation['frozen_manifest_sha256']==sha(ROOT/'FROZEN_MANIFEST.json'),'Generation freeze')
    verify(generation['manifests_sha256'])
    results=read(OUT/'RESULTS.json')
    compare(results['frozen_sha256'],frozen['sha256'],'RESULTS frozen')
    check(results['validation_status_sha256']==sha(ROOT/'SIMULATION_VALIDATION_STATUS.json'),'RESULTS pre-evaluation hash')
    for name in ('TRAINING_MANIFEST.json','TEST_MANIFEST.json','TRUTH_MANIFEST.json'):
        check(status['sha256'][name]==sha(ROOT/name),'Manifest pre-evaluation pin '+name)
    manifests={key:{x['id']:x for x in read(ROOT/name)} for key,name in
               [('train','TRAINING_MANIFEST.json'),('test','TEST_MANIFEST.json'),('truth','TRUTH_MANIFEST.json')]}
    for m in manifests.values():
        check(len(m)==840,'Manifest count')
        verify({r['input']:r['sha256'] for r in m.values()})
    original=(ROOT/'analyze_results.py').read_text().splitlines()
    amended=(ROOT/'analyze_results_fixed.py').read_text().splitlines()
    changes=[x for x in difflib.ndiff(original,amended) if x.startswith(('- ','+ '))]
    compare(changes,["-     alias_checks, parameter_raw, unidentified_rows, tie_rows = [], [], [], []",
                     "+     alias_checks, parameter_raw, unidentified_rows, tie_rows = [], {}, [], []"],'Minimal analyzer amendment')
    amendment_files=sorted(ROOT.glob('*AMEND*'))
    check(bool(amendment_files),'Missing amendment evidence')
    tables={k:[] for k in ('scores','classifications','pairs','parameters','fit','attempts','unidentified','calibration','aliases')}
    ties=[]; grouped_parameters=defaultdict(lambda:([],[])); cal_unique={}; matched={}
    fit_hashes={};eval_hashes={};max_log_error=0.;max_score_error=0.;max_decomp=0.;max_alias=0.
    independent=raw_failed=selected_failed=0;max_gap=0.;cells=Counter()
    paths=sorted((ROOT/'evaluation').glob('case_*.json'));check(len(paths)==840,'840 evaluation packets')
    for index,path in enumerate(paths):
        packet=read(path);case=path.stem;check(packet['id']==case,'Packet identity')
        fitpath=ROOT/'fitting'/(case+'.json');fit=read(fitpath)
        train=manifests['train'][case];test=manifests['test'][case];truthentry=manifests['truth'][case]
        truth=read(ROOT/truthentry['input']);compare(packet['truth'],truth,'Truth packet '+case)
        for pkey,file,digest in [('fitting_sha256',fitpath,sha(fitpath)),('training_input_sha256',ROOT/train['input'],train['sha256']),
                                ('test_input_sha256',ROOT/test['input'],test['sha256']),('truth_sha256',ROOT/truthentry['input'],truthentry['sha256'])]:
            check(packet[pkey]==digest==sha(file),'Packet binding '+case+' '+pkey)
        check(status['sha256']['fitting/'+case+'.json']==sha(fitpath),'Pre-evaluation fit pin '+case)
        compare(packet['training_fit_metadata'],fit['regimes'],'Fitting metadata '+case)
        scenario=truth['scenario'];generator=truth['generator'];rep=int(truth['replicate'])
        check(scenario in SCENARIOS and generator in GENERATORS,'Declared grid')
        cells[(scenario,generator)]+=1
        base=dict(id=case,scenario=scenario,generator=generator,replicate=rep)
        with np.load(ROOT/train['input'],allow_pickle=False) as data:
            ehat=float(data['ehat']);noise=data['calibration_noise'].tolist();errors=data['calibration_errors'].tolist()
        check(ehat==float(np.clip((sum(errors)+.5)/81,.005,.5))==packet['ehat']==fit['ehat'],'Calibration plug-in '+case)
        check(len(errors)==80 and len(noise)==32,'Calibration counts')
        with np.load(ROOT/test['input'],allow_pickle=False) as data:
            observed={k:data[k].copy() for k in ('load','factor','update','probe')}
        for k,v in observed.items():check(np.array_equal(v,np.asarray(packet['observed'][k])),'Test observation binding '+case)
        n=len(observed['load']);check(n==240==truth['n_test'],'Held-out episode count')
        probes=observed['probe']>=0
        cal=dict(scenario=scenario,replicate=rep,true_e=float(truth['true_parameters']['e']),ehat=ehat,
                 errors=sum(errors),identification_trials=80,zero_update_differences=32)
        tables['calibration'].append({**base,**cal,'error':ehat-cal['true_e']})
        if (scenario,rep) in cal_unique:compare(cal_unique[(scenario,rep)],cal,'Shared calibration')
        else:cal_unique[(scenario,rep)]=cal
        losses={};logs_by_regime={}
        for regime in REGIMES:
            losses[regime]={};logs_by_regime[regime]={}
            for model in MODELS:
                f=fit['regimes'][regime][model];theta=f['theta']
                d={**observed,'ehat':ehat,'calibration_noise':np.asarray(noise)}
                if regime=='update_only':d={**d,'probe':np.full(n,-1,int)}
                reference=ref_log_components(theta,model,d)
                if regime=='joint':expected=np.column_stack((reference,reference[:,0]-reference[:,1]))
                else:expected=reference[:,1,None]
                actual=np.asarray(packet['regimes'][regime][model]['log_components'],float)
                check(actual.shape==expected.shape and np.isfinite(actual).all(),'Finite density shape')
                err=float(np.max(abs(actual-expected)));max_log_error=max(max_log_error,err)
                check(err<=1e-9,'Independent episode likelihood '+case+':'+regime+':'+model)
                logs_by_regime[regime][model]=actual
                # Score with math.fsum, independently of analyzer np.mean.
                values=[-math.fsum(actual[:,j])/n for j in range(actual.shape[1])]
                refvalues=[-math.fsum(expected[:,j])/n for j in range(expected.shape[1])]
                max_score_error=max(max_score_error,max(abs(a-b) for a,b in zip(values,refvalues)))
                if regime=='joint':
                    rec=dict(joint_loss=values[0],update_loss=values[1],probe_marginal_loss=values[2],conditional_probe_loss=values[3])
                    decomp=float(np.max(abs(actual[:,0]-actual[:,1]-actual[:,3])));max_decomp=max(max_decomp,decomp)
                    check(decomp<1e-10 and np.all(abs(actual[~probes,2:])<1e-12),'Proper decomposition/absent probes')
                    check(np.all(actual[:,2:]<=1e-10),'Binary probe log probabilities')
                    loss=values[0]
                else:
                    compare(packet['regimes'][regime][model]['undefined_components'],['joint','probe','conditional'],'Undefined reduced components')
                    rec=dict(joint_loss=None,update_loss=values[0],probe_marginal_loss=None,conditional_probe_loss=None);loss=values[0]
                losses[regime][model]=loss
                tables['scores'].append({**base,'regime':regime,'candidate':model,'main_episodes':n,'probed_episodes':int(probes.sum()),**rec})
                success=bool(f['success']);selected_failed+=int(not success);max_gap=max(max_gap,float(f['success_tie_gap']))
                tables['fit'].append({**base,'regime':regime,'candidate':model,'names':json.dumps(f['names']),'theta':json.dumps(theta),
                                     'nll_total':f['nll_total'],'success':success,'selected_kind':f['selected_kind'],
                                     'objective_minimum':f['objective_minimum'],'success_tie_gap':f['success_tie_gap'],
                                     'reused_from':f.get('reused_from'),'unidentified_parameters':json.dumps(f.get('unidentified_parameters',[]))})
                for name in f.get('unidentified_parameters',[]):tables['unidentified'].append({**base,'regime':regime,'candidate':model,'parameter':name})
                if not f.get('reused_from'):
                    independent+=1
                    for j,a in enumerate(f['attempts']):
                        raw_failed+=int(not bool(a['success']))
                        tables['attempts'].append({**base,'regime':regime,'candidate':model,'attempt':j,
                                                 **{k:json.dumps(v) if isinstance(v,(list,dict)) else v for k,v in a.items()}})
            scores=losses[regime] if regime=='joint' else {'S/I/IF/F':losses[regime]['S'],'C':losses[regime]['C'],'E':losses[regime]['E']}
            low=min(scores.values());within=sorted(k for k,v in scores.items() if v-low<=MARGIN)
            selected=within[0] if len(within)==1 else 'AMBIGUOUS'
            tables['classifications'].append({**base,'regime':regime,'selected':selected,'within_margin':'|'.join(within),'minimum_loss':low})
            ties.append({**base,'regime':regime,'selected':selected,'within_margin':within,'minimum_loss':low})
            if generator in ('S','I'):
                for other in ('I','IF'):
                    difference=losses[regime][other]-losses[regime]['S']
                    winner='S' if difference>MARGIN else 'OTHER' if difference<-MARGIN else 'AMBIGUOUS'
                    correct_label='S' if generator=='S' else 'OTHER'
                    tables['pairs'].append({**base,'regime':regime,'comparison':'S_vs_'+other,'gain_favoring_S':difference,'selected':winner,
                                           'correct':winner==correct_label,'incorrect':winner not in (correct_label,'AMBIGUOUS'),'ambiguous':winner=='AMBIGUOUS'})
        for model in ('S','I','IF','F'):
            a=logs_by_regime['update_only'][model];b=logs_by_regime['update_only']['S']
            max_alias=max(max_alias,float(np.max(abs(a-b))));check(np.array_equal(a,b),'Exact reduced aliases')
        compare(packet['aliases'],ALIASES,'Mechanism alias map')
        tables['aliases'].append({**base,'aliases':ALIASES,'fit_once':True,'distinct_mechanism_identified':False})
        if generator in ('S','I','F'):
            matched_record=dict(update=observed['update'].tolist(),load=observed['load'].tolist(),factor=observed['factor'].tolist(),
                                ehat=ehat,noise=noise,errors=errors,forecast=logs_by_regime['update_only']['S'].tolist())
            if (scenario,rep) in matched:compare(matched[(scenario,rep)],matched_record,'Matched marginal negative control')
            else:matched[(scenario,rep)]=matched_record
        f=fit['regimes']['joint'][generator]
        for name,value in zip(f['names'],f['theta']):
            actual=float(truth['true_parameters'][name]);value=float(value)
            tables['parameters'].append({**base,'regime':'joint','candidate':generator,'parameter':name,'true_value':actual,'fitted_value':value,
                                         'error':value-actual,'selected_model_conditioned':False,
                                         'identified_under_fitted_calibration':name not in f.get('unidentified_parameters',[])})
            x,y=grouped_parameters[(scenario,generator,name)];x.append(actual);y.append(value)
        fit_hashes['fitting/'+case+'.json']=sha(fitpath);eval_hashes[path.relative_to(ROOT).as_posix()]=sha(path)
        if (index+1)%120==0:print(f'Independent forecasts: {index+1}/840',flush=True)
    check(len(cells)==35 and set(cells.values())=={24},'Complete grid and independent denominators')
    confusion=[]
    for regime in REGIMES:
        labels=MODELS if regime=='joint' else ('S/I/IF/F','C','E')
        for scenario in SCENARIOS:
            for generator in GENERATORS:
                group=[r for r in tables['classifications'] if r['scenario']==scenario and r['generator']==generator and r['regime']==regime]
                for selected in (*labels,'AMBIGUOUS'):
                    confusion.append(dict(scenario=scenario,regime=regime,generator=generator,selected=selected,
                                          **interval(sum(r['selected']==selected for r in group),24)))
    pair_summary=[];flat_pairs=[];screens={}
    for scenario in SCENARIOS:
        for regime in REGIMES:
            for comparison in ('S_vs_I','S_vs_IF'):
                directions={}
                for generator in ('S','I'):
                    rows=[r for r in tables['pairs'] if (r['scenario'],r['regime'],r['comparison'],r['generator'])==(scenario,regime,comparison,generator)]
                    check(len(rows)==24,'Pair denominator')
                    d={key:interval(sum(r[key] for r in rows),24) for key in ('correct','incorrect','ambiguous')}
                    directions[generator]=d
                    pair_summary.append(dict(scenario=scenario,regime=regime,comparison=comparison,generator=generator,**d))
                    for outcome in ('correct','incorrect','ambiguous'):
                        flat_pairs.append(dict(scenario=scenario,regime=regime,comparison=comparison,generator=generator,outcome=outcome,**d[outcome]))
                passed=directions['S']['correct']['count']>=20 and directions['I']['correct']['count']>=20 and directions['I']['incorrect']['count']<=2
                screens.setdefault(scenario,{}).setdefault(regime,{})[comparison]=dict(passed=passed,directions=directions,
                   required_correct_count_each_direction=20,maximum_false_S_count_when_I=2,n_per_direction=24)
    params=[]
    for (scenario,generator,name),(x,y) in grouped_parameters.items():
        unident=sum(not r['identified_under_fitted_calibration'] for r in tables['parameters'] if (r['scenario'],r['generator'],r['parameter'])==(scenario,generator,name))
        params.append(dict(scenario=scenario,generator=generator,parameter=name,**moments(x,y),unidentified_fit_count=unident))
    calibration=[]
    for scenario in SCENARIOS:
        rows=[r for r in cal_unique.values() if r['scenario']==scenario];check(len(rows)==24,'Calibration deduplication')
        calibration.append(dict(scenario=scenario,estimated_quantity='effective readout error e',free_model_parameter=False,
                                **moments([r['true_e'] for r in rows],[r['ehat'] for r in rows])))
    reduced=[]
    for r in tables['classifications']:
        if r['regime']=='update_only' and r['generator'] in ('S','C','E'):
            correct='S/I/IF/F' if r['generator']=='S' else r['generator']
            reduced.append({**r,'true_equivalence_class':correct,'correct_class':r['selected']==correct,'ambiguous':r['selected']=='AMBIGUOUS'})
    check(len(reduced)==504 and len(matched)==168,'Unique marginal denominators')
    primary=screens['long_standard']['joint']
    checks={'confusion':confusion,'pairwise_recovery':pair_summary,'design_screens':screens,'within_margin_sets':ties,
            'parameter_recovery':params,'calibration_recovery':calibration,'fitting_packet_sha256':fit_hashes,'evaluation_packet_sha256':eval_hashes,
            'shared_mechanism_aliases':ALIASES,'distinct_gate_mechanism_identified':False,'update_only_unique_dataset_count':504,
            'matched_S_I_F_negative_control_pairs':168,'primary_S_vs_I_passed':primary['S_vs_I']['passed'],
            'primary_IF_robustness_passed':primary['S_vs_IF']['passed'],
            'limited_candidate_design_passed':primary['S_vs_I']['passed'] and primary['S_vs_IF']['passed'],
            'optimizer_diagnostics':dict(fit_records=len(tables['fit']),independent_fit_records=independent,retained_raw_attempts=len(tables['attempts']),
                                          raw_attempt_failures=raw_failed,selected_failures=selected_failed,maximum_success_tie_gap_total_nats=max_gap)}
    for k,v in checks.items():compare(results[k],v,'RESULTS '+k)
    csv_specs=[('case_model_scores.csv',tables['scores']),('classifications.csv',tables['classifications']),('confusion_counts.csv',confusion),
               ('pairwise_decisions.csv',tables['pairs']),('pairwise_recovery_summary.csv',flat_pairs),('true_family_parameter_recovery.csv',tables['parameters']),
               ('parameter_recovery_summary.csv',params),('calibration_by_dataset.csv',tables['calibration']),('calibration_unique_replicates.csv',list(cal_unique.values())),
               ('calibration_recovery_summary.csv',calibration),('fit_parameters_and_status.csv',tables['fit']),('optimizer_attempts.csv',tables['attempts']),
               ('unidentified_parameters.csv',tables['unidentified']),('unidentified_reduced_parameters.csv',[r for r in tables['unidentified'] if r['regime']=='update_only']),
               ('update_only_unique_classifications.csv',reduced)]
    csv_counts={name:csv_check(name,rows) for name,rows in csv_specs}
    compare(read(OUT/'shared_mechanism_aliases.json'),tables['aliases'],'Shared mechanism JSON')
    check(selected_failed==0 and independent==6552 and len(tables['fit'])==10080,'Optimizer totals')
    verify(frozen['sha256']);verify(status['sha256'])
    evidence={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(OUT.glob('*')) if p.is_file()}
    evidence.update({p.relative_to(ROOT).as_posix():sha(p) for p in amendment_files})
    for name in ('audit_results.py','analyze_results.py','analyze_results_fixed.py','POSTFIT_REVIEW.json','FROZEN_MANIFEST.json','SIMULATION_VALIDATION_STATUS.json','PRODUCTION_GENERATION.json'):
        evidence[name]=sha(ROOT/name)
    evidence.update(fit_hashes);evidence.update(eval_hashes)
    return dict(status='passed independent post-run forecast, recovery, export and provenance audit',
                checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),datasets=840,
                fit_records=10080,episode_forecast_comparisons=840*12*240,
                maximum_episode_log_density_error=max_log_error,maximum_mean_loss_error=max_score_error,
                maximum_joint_decomposition_error=max_decomp,maximum_update_only_alias_error=max_alias,
                csv_row_counts=csv_counts,optimizer=checks['optimizer_diagnostics'],primary_screens=primary,
                limited_candidate_design_passed=checks['limited_candidate_design_passed'],
                amendment_review='Exactly one list-to-dictionary accumulator initialization; original frozen analyzer preserved byte-for-byte. No likelihood, fit, score, threshold or recovery formula changed.',
                interpretation='Statistical shared-versus-independent availability recovery only; decoder admission, ordinary shared attention and shared memory remain exact aliases.',
                sha256=evidence)

if __name__=='__main__':
    report=audit()
    (ROOT/'POSTRUN_REVIEW.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    text=[report['status'],f"Datasets: {report['datasets']}; numerical fit records: {report['fit_records']}",
          f"Episode forecasts independently compared: {report['episode_forecast_comparisons']}",
          f"Maximum episode log density error: {report['maximum_episode_log_density_error']:.15g}",
          f"Maximum mean loss error: {report['maximum_mean_loss_error']:.15g}",
          f"CSV rows checked: {sum(report['csv_row_counts'].values())}",
          f"Limited candidate design passed: {report['limited_candidate_design_passed']}",
          report['amendment_review'],report['interpretation']]
    (ROOT/'POSTRUN_REVIEW.txt').write_text('\n'.join(text)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ('sha256','primary_screens','csv_row_counts')},indent=2))
