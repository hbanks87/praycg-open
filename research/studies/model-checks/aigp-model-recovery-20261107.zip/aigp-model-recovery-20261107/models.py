from pathlib import Path
import ctypes,os
import numpy as np
ROOT=Path(__file__).resolve().parent
MODELS=['S','I','C','IF','F','E'];REGIMES=['joint','update_only']
NAMES={m:['p_low','p_high','alpha','sigma'] for m in MODELS}
NAMES['IF']+=['p_report_low','p_report_high'];NAMES['F']+=['rho'];NAMES['E']+=['wrong_sign']
IDS={m:i for i,m in enumerate(MODELS)}
ALIASES={'decoder_admission':'S','ordinary_shared_attention':'S','shared_memory_availability':'S'}
_directory=os.add_dll_directory(str(ROOT/'runtime'))
_dll=ctypes.CDLL(str(ROOT/'runtime'/'recovery_models.dll'))
_fn=_dll.recovery_eval
_fn.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,
 ctypes.c_void_p,ctypes.c_void_p,ctypes.c_double,ctypes.c_int,ctypes.c_int,ctypes.c_double,
 ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p]
_fn.restype=ctypes.c_int
def bounds(model):
    b=[(.005,.995),(.005,.995),(.02,1.2),(.04,1.)]
    return b+([(.005,.995),(.005,.995)] if model=='IF' else [(0.,1.)] if model=='F' else [(0.,.4)] if model=='E' else [])
def prepare_data(d):
    out=dict(d)
    for k,typ in [('load',np.int32),('factor',np.float64),('update',np.float64),('probe',np.int32)]:
        out[k]=np.ascontiguousarray(d[k],dtype=typ)
    n=len(out['load']);assert all(len(out[k])==n for k in ['factor','update','probe'])
    assert np.isin(out['load'],[0,1]).all() and np.isin(out['probe'],[-1,0,1]).all()
    assert np.isfinite(out['update']).all() and np.isfinite(out['factor']).all()
    out['ehat']=float(np.asarray(d['ehat']).item())
    return out
def _evaluate(theta,model,data,regime,calibration,check_gradient=True):
    model=ALIASES.get(model,model);d=prepare_data(data)
    th=np.ascontiguousarray(theta,dtype=np.float64);assert len(th)==len(NAMES[model])
    grad=np.zeros(6);loss=np.zeros(1);logs=np.empty((len(d['load']),3))
    noise=np.asarray(d.get('calibration_noise',[]),dtype=float) if calibration else np.empty(0)
    err=_fn(IDS[model],len(d['load']),d['load'].ctypes.data,d['factor'].ctypes.data,
      d['update'].ctypes.data,d['probe'].ctypes.data,th.ctypes.data,d['ehat'],
      REGIMES.index(regime),len(noise),float(np.dot(noise,noise)),loss.ctypes.data,grad.ctypes.data,logs.ctypes.data)
    if err:raise ValueError(('density failure',model,err))
    assert np.isfinite(logs).all() and np.isfinite(loss).all()
    if check_gradient:assert np.isfinite(grad).all()
    return float(loss[0]),grad[:len(th)],logs
def loss_grad(theta,model,data,regime='joint'):
    loss,grad,_=_evaluate(theta,model,data,regime,True);return loss,grad
def log_components(theta,model,data):return _evaluate(theta,model,data,'joint',False,False)[2]
