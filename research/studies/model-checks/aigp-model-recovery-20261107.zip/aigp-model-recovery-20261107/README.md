# AIGP bounded encoding/updating model recovery

Original November 7 model, generator, fitting, held-out scoring and independent checks. All observations are synthetic. This is an individual-model recovery screen, not a human study or participant sample-size calculation.

The native historical implementation requires Windows x64, Python 3.11 and a C++17 MinGW GCC compiler (original: GCC 15.2.0). No executable is bundled. Install the pinned Python dependencies and build locally:

```sh
python -m pip install -r requirements.txt
python build_kernel.py --compiler g++
python audit_models.py
python driver_preflight.py
```

These are the bounded smoke/reproduction commands actually rerun for this publication: independent density/gradient/marginal/moment/alias checks plus generation, fitting and held-out prediction for nonproduction replicate 999 and hand fixtures. They do not reproduce the 840-dataset operating rates. The optimizer check expects all seven flags true, 21 shared-control unique fits and 9 chance-readout unique fits. The model audit declares its numerical tolerances in `audit_models.py`.

For the full expensive study, continue in that fresh working copy:

```sh
python record_preflight.py
python prepare_full_run.py
python simulate.py
python fit_recovery.py --index 0 --total 1
python audit_models.py --postfit
python validate_fits.py
python evaluate.py
python analyze_results_fixed.py
python audit_results.py
```

This creates a new integrity binding for the public run. It is explicitly not the original prospective freeze or a new preregistration. Algorithm/config bytes are unchanged; compiler output, timestamps, manifest identity and compressed bytes may differ. Do not rerun preflight after creating the binding. Preserve every failed fit and ambiguity. Full historical reproduction was not performed for this public packaging check.

Historical result: 7 scenarios x 5 generating families x 24 replicates = 840 datasets. A winner needs >0.001 nats/main episode. Each direction needs >=20/24 correct and <=2/24 false shared-class selections on independent cases, against both I and flexible IF. None of the seven scenarios passed the complete screen. In the primary scenario S was recovered 21/24, but falsely selected in 6/24 I cases; against IF false shared selection reached 10/24. Update-only S/I/IF/F are exact aliases. Shared admission, ordinary shared attention and shared-memory availability have the same observable law even if recovery improved.

HISTORICAL_RESULTS.json preserves all scenario screen counts, including failures. These are retained historical results, not new packaging-run measurements. The original aggregator remains `analyze_results.py`; the documented sibling fixes only its list/dictionary initializer. AMENDMENT_MANIFEST.json preserves the exact source diff/hashes. SOURCE_PROVENANCE.json identifies the unchanged original inputs. See NOTICE.md.
