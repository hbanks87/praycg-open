"""Create a new integrity binding for a public rerun, never a retrospective preregistration."""
from pathlib import Path
import hashlib,json,datetime
ROOT=Path(__file__).resolve().parent
target=ROOT/'FROZEN_MANIFEST.json'
if target.exists(): raise SystemExit('Use a fresh extracted copy; FROZEN_MANIFEST.json already exists.')
for name in ('main','training_inputs','test_inputs','truth','fitting','evaluation','results'):
    if (ROOT/name).exists(): raise SystemExit('Use a fresh extracted copy: '+name+' already exists.')
paths=sorted([p for p in ROOT.glob('*.py')]+[ROOT/'protocol_config.json',ROOT/'PROTOCOL.txt'])
paths += sorted((ROOT/'runtime').glob('*.dll')) if (ROOT/'runtime').exists() else []
manifest={'scope':'NEW public reproduction integrity binding; NOT the historical prospective freeze or external registration',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'historical_source_provenance_sha256':hashlib.sha256((ROOT/'SOURCE_PROVENANCE.json').read_bytes()).hexdigest(),
 'sha256':{p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
target.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print('Created public rerun binding. Original algorithm/config bytes are unchanged; output provenance will differ.')
