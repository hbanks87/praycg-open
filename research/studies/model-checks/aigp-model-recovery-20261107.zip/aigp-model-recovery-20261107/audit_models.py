"""Independent recovery-screen density/reference audit. No simulated fitting.

The reference integrates latent events directly, using scipy Normal log
densities; it does not call the C++ kernel or use true simulated latent events.
"""
from pathlib import Path
import argparse, datetime, hashlib, importlib, itertools, json, math
import numpy as np
from scipy.special import logsumexp
from scipy.stats import norm
from scipy.integrate import simpson

ROOT=Path(__file__).resolve().parent
FAMILIES=('S','I','C','IF','F','E')
REGIMES=('joint','update_only')
COMMON_NAMES=['p_low','p_high','alpha','sigma']
NAMES={m:COMMON_NAMES+({'IF':['p_report_low','p_report_high'],'F':['rho'],'E':['wrong_sign']}.get(m,[])) for m in FAMILIES}
REF_BOUNDS={m:[(.005,.995),(.005,.995),(.02,1.2),(.04,1.)]+({'IF':[(.005,.995),(.005,.995)],'F':[(0.,1.)],'E':[(0.,.4)]}.get(m,[])) for m in FAMILIES}
LIMITS={'max_log_density':1e-9,'mean_nll':1e-9,'mean_standardized_gradient':1e-5,
        'gradient_relative':2e-6,'density_mass':2e-7,'moment_or_covariance':2e-7,'alias':1e-11}

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def maxabs(x):return float(np.max(np.abs(x),initial=0.))
def data_copy(data):return {k:np.asarray(v).copy() if isinstance(v,(np.ndarray,list,tuple)) else v for k,v in data.items()}
def ref_log_components(theta,model,data):
    """Return columns joint, update marginal, probe marginal; absent probe=0."""
    if model in ('decoder_admission','ordinary_shared_attention','shared_memory_availability'):model='S'
    assert model in FAMILIES and len(theta)==len(NAMES[model])
    p0,p1,alpha,sigma=map(float,theta[:4])
    load=np.asarray(data['load'],int);f=np.asarray(data['factor'],float)
    update=np.asarray(data['update'],float);probe=np.asarray(data['probe'],int)
    e=float(data['ehat']);n=len(load)
    assert load.shape==f.shape==update.shape==probe.shape==(n,)
    assert np.isin(load,[0,1]).all() and np.isin(probe,[-1,0,1]).all()
    assert sigma>0 and 0<=p0<=1 and 0<=p1<=1 and 0<=e<=.5
    p=np.where(load==0,p0,p1);a=alpha*f
    logn0=norm.logpdf(update,loc=0,scale=sigma)
    lognp=norm.logpdf(update,loc=a,scale=sigma)
    lognm=norm.logpdf(update,loc=-a,scale=sigma)
    b0=np.where(probe<0,1.,.5)
    bp=np.where(probe<0,1.,np.where(probe==1,1-e,e))
    bm=np.where(probe<0,1.,np.where(probe==1,e,1-e))
    with np.errstate(divide='ignore'):
        l0=np.log(b0);lp=np.log(bp);lm=np.log(bm)
    def mixture(weights,terms):
        weights=np.broadcast_arrays(*[np.asarray(w,dtype=float) for w in weights])
        assert all(np.all(w>=-1e-14) for w in weights)
        with np.errstate(divide='ignore'):
            logweights=np.log(np.maximum(np.asarray(weights),0))
        return logsumexp(logweights+np.asarray(terms),axis=0)
    common_update=mixture([1-p,p],[logn0,lognp])
    common_probe=mixture([1-p,p],[l0,lp])
    if model=='S':
        joint=mixture([1-p,p],[logn0+l0,lognp+lp]);u=common_update;c=common_probe
    elif model=='I':u=common_update;c=common_probe;joint=u+c
    elif model=='C':
        variance=sigma*sigma+a*a*p*(1-p)
        u=norm.logpdf(update,loc=a*p,scale=np.sqrt(variance));c=common_probe;joint=u+c
    elif model=='IF':
        pr=np.where(load==0,theta[4],theta[5])
        u=common_update;c=mixture([1-pr,pr],[l0,lp]);joint=u+c
    elif model=='F':
        rho=float(theta[4]);v=p*(1-p)
        weights=[(1-p)**2+rho*v,(1-rho)*v,(1-rho)*v,p*p+rho*v]
        joint=mixture(weights,[logn0+l0,logn0+lp,lognp+l0,lognp+lp]);u=common_update;c=common_probe
    elif model=='E':
        w=float(theta[4]);weights=[1-p,p*(1-w),p*w]
        joint=mixture(weights,[logn0+l0,lognp+lp,lognm+lm])
        u=mixture(weights,[logn0,lognp,lognm]);c=mixture(weights,[l0,lp,lm])
    result=np.column_stack((joint,u,c))
    result[probe<0,0]=result[probe<0,1];result[probe<0,2]=0.
    assert np.isfinite(result).all()
    return result

def ref_loss(theta,model,data,regime):
    assert regime in REGIMES
    logs=ref_log_components(theta,model,data)
    selected=logs[:,0 if regime=='joint' else 1]
    noise=np.asarray(data.get('calibration_noise',[]),float)
    return float(-math.fsum(selected)-math.fsum(norm.logpdf(noise,loc=0,scale=theta[3])))

def ref_grad(theta,model,data,regime):
    """Five-point finite differences, with one-sided physical-boundary stencils.

    Gradients are independent of the candidate analytic implementation. Extreme
    vanishing-mixture boundary tails are density-tested separately because a
    fixed-step derivative cannot resolve their arbitrarily small local scale.
    """
    x=np.asarray(theta,float);answer=[]
    for j,(lo,hi) in enumerate(REF_BOUNDS[model]):
        h=1e-5*(hi-lo)
        # Physical domain, rather than numerical fitting bounds.
        physical_lo=0. if j!=3 else 0.
        physical_hi=1. if j in (0,1) or (model=='IF' and j>=4) or (model in ('F','E') and j==4) else math.inf
        def fun(offset):
            xx=x.copy();xx[j]+=offset*h
            return ref_loss(xx,model,data,regime)
        if x[j]-2*h>=physical_lo and x[j]+2*h<=physical_hi and not (j==3 and x[j]-2*h<=0):
            value=(fun(-2)-8*fun(-1)+8*fun(1)-fun(2))/(12*h)
        elif x[j]-2*h<physical_lo:
            value=(-25*fun(0)+48*fun(1)-36*fun(2)+16*fun(3)-3*fun(4))/(12*h)
        else:value=(25*fun(0)-48*fun(-1)+36*fun(-2)-16*fun(-3)+3*fun(-4))/(12*h)
        answer.append(value)
    return np.asarray(answer)

def fixture_data(n=24,e=.12,seed=2026110723):
    rng=np.random.default_rng(seed)
    reliability=np.tile([.9,.65],(n+1)//2)[:n]
    return dict(load=np.tile([0,0,1,1],(n+3)//4)[:n].astype(np.int32),
        factor=np.log(reliability/(1-reliability))/math.log(9),
        update=np.tile([-.12,.08,.22,.54,.35,-.05],(n+5)//6)[:n],
        probe=np.tile([-1,0,1,1,0,1],(n+5)//6)[:n].astype(np.int32),ehat=float(e),
        calibration_noise=rng.normal(0,.25,32))

def moment_check(api,model,theta,load,f,e):
    a=theta[2]*f;sd=theta[3]
    integration_sd=math.sqrt(sd*sd+a*a*theta[load]*(1-theta[load])) if model=='C' else sd
    grid=np.linspace(-abs(a)-9*integration_sd,abs(a)+9*integration_sd,4001)
    data=dict(load=np.full(len(grid),load,dtype=np.int32),factor=np.full(len(grid),f),
              update=grid,probe=np.zeros(len(grid),dtype=np.int32),ehat=e,calibration_noise=np.empty(0))
    zero=np.exp(np.asarray(api.log_components(theta,model,data))[:,0]);data['probe'][:]=1
    one=np.exp(np.asarray(api.log_components(theta,model,data))[:,0])
    density=zero+one;mass=simpson(density,x=grid)
    mean=simpson(grid*density,x=grid);second=simpson(grid*grid*density,x=grid)
    correct=simpson(one,x=grid);cross=simpson(grid*one,x=grid)
    p=theta[load]
    if model=='E':
        w=theta[4];ex=p*(1-2*w);variance_x=p-ex*ex
        expected_mean=a*ex;expected_var=sd*sd+a*a*variance_x
        expected_correct=.5+(.5-e)*ex;expected_cov=a*(.5-e)*variance_x
    else:
        expected_mean=a*p;expected_var=sd*sd+a*a*p*(1-p)
        pr=theta[4+load] if model=='IF' else p
        expected_correct=.5+(.5-e)*pr
        expected_cov=(a*(.5-e)*p*(1-p))*(1 if model=='S' else theta[4] if model=='F' else 0)
    return dict(mass=abs(mass-1),mean=abs(mean-expected_mean),variance=abs(second-mean*mean-expected_var),
                probe_accuracy=abs(correct-expected_correct),covariance=abs(cross-mean*correct-expected_cov),
                expected_conditional_covariance=float(expected_cov))

def prefit_audit():
    api=importlib.import_module('models')
    rng=np.random.default_rng(2026110723);data=fixture_data()
    centers={m:[.78,.43,.5,.27]+({'IF':[.66,.38],'F':[.45],'E':[.15]}.get(m,[])) for m in FAMILIES}
    errors={m:dict(log_density=0.,mean_nll=0.,mean_standardized_gradient=0.,relative_gradient=0.,points=0,boundary_density_points=0) for m in FAMILIES}
    for model in FAMILIES:
        assert api.NAMES[model]==NAMES[model]
        assert list(map(tuple,api.bounds(model)))==REF_BOUNDS[model]
        points=[np.array(centers[model],float)]
        for _ in range(10):
            point=np.array([rng.uniform(lo+.05*(hi-lo),hi-.05*(hi-lo)) for lo,hi in REF_BOUNDS[model]])
            points.append(point)
        # Boundary mixtures have finite likelihoods; derivative tests at zero
        # E-error use moderate-overlap observations rather than singular scales.
        if model in ('F','E'):
            for value in ([0.,1.] if model=='F' else [0.,.4]):
                point=np.array(centers[model]);point[4]=value;points.append(point)
        for point in points:
            actual=np.asarray(api.log_components(point,model,data));expected=ref_log_components(point,model,data)
            err=maxabs(actual-expected);errors[model]['log_density']=max(errors[model]['log_density'],err)
            assert err<=LIMITS['max_log_density'],(model,'density',err)
            for regime in REGIMES:
                loss,gradient=api.loss_grad(point,model,data,regime)
                expected_loss=ref_loss(point,model,data,regime);expected_grad=ref_grad(point,model,data,regime)
                n=len(data['load'])+len(data['calibration_noise'])
                value=abs(loss-expected_loss)/max(1,n);errors[model]['mean_nll']=max(errors[model]['mean_nll'],value)
                width=np.array([hi-lo for lo,hi in REF_BOUNDS[model]])
                standard=maxabs((np.asarray(gradient)-expected_grad)*width/max(1,n))
                relative=maxabs((np.asarray(gradient)-expected_grad)/np.maximum(1,np.maximum(np.abs(gradient),np.abs(expected_grad))))
                errors[model]['mean_standardized_gradient']=max(errors[model]['mean_standardized_gradient'],standard)
                errors[model]['relative_gradient']=max(errors[model]['relative_gradient'],relative)
                assert np.isfinite(loss) and np.isfinite(gradient).all()
                assert value<=LIMITS['mean_nll'] and standard<=LIMITS['mean_standardized_gradient'] and relative<=LIMITS['gradient_relative'],(model,regime,value,standard,relative)
            errors[model]['points']+=1
        stress=fixture_data();stress['update']=np.tile([-.8,-.4,0.,.25,.55,.8],4)
        for bits in itertools.product((0,1),repeat=len(REF_BOUNDS[model])):
            point=[bound[bit] for bound,bit in zip(REF_BOUNDS[model],bits)]
            actual=np.asarray(api.log_components(point,model,stress));expected=ref_log_components(point,model,stress)
            error=maxabs(actual-expected);assert np.isfinite(actual).all() and error<=LIMITS['max_log_density']
            errors[model]['log_density']=max(errors[model]['log_density'],error)
            errors[model]['boundary_density_points']+=1
    # Extremely distant negative observations under E at w=0 retain a finite
    # proper log density, even if the one-sided gradient exceeds float range.
    tail=fixture_data(n=2);tail['update']=np.array([-3.,3.]);tail['factor'][:]=1.
    tail_theta=[.78,.43,.5,.04,0.]
    tail_error=maxabs(np.asarray(api.log_components(tail_theta,'E',tail))-ref_log_components(tail_theta,'E',tail))
    assert tail_error<=LIMITS['max_log_density']
    closure={};base=centers['S']
    for label,model,theta in [('F rho1','F',base+[1.]),('E w0','E',base+[0.])]:
        error=maxabs(np.asarray(api.log_components(base,'S',data))-np.asarray(api.log_components(theta,model,data)))
        closure[label]=error;assert error<=LIMITS['alias'],label
    closure['F rho0 equals I']=maxabs(np.asarray(api.log_components(base,'I',data))-np.asarray(api.log_components(base+[0.],'F',data)))
    assert closure['F rho0 equals I']<=LIMITS['alias']
    alias_errors={}
    assert api.ALIASES=={'decoder_admission':'S','ordinary_shared_attention':'S','shared_memory_availability':'S'}
    for alias in api.ALIASES:
        error=maxabs(np.asarray(api.log_components(base,alias,data))-np.asarray(api.log_components(base,'S',data)))
        assert error==0.;alias_errors[alias]=error
    marginal_errors={}
    base_log=np.asarray(api.log_components(base,'S',data))
    for model,theta in [('I',base),('IF',base+[.2,.9]),('F',base+[.45])]:
        actual=np.asarray(api.log_components(theta,model,data))
        marginal_errors[model]=maxabs(base_log[:,1]-actual[:,1]);assert marginal_errors[model]<=LIMITS['alias']
        same_loss=abs(api.loss_grad(base,'S',data,'update_only')[0]-api.loss_grad(theta,model,data,'update_only')[0])
        assert same_loss<=LIMITS['alias']
    assert maxabs(base_log[:,2]-np.asarray(api.log_components(base,'I',data))[:,2])<=LIMITS['alias']
    collapse={}
    for label,theta,e in [('chance_probe',base,.5),('p0',[0.,0.,.5,.27],.12),('p1',[1.,1.,.5,.27],.12)]:
        dd=data_copy(data);dd['ehat']=e
        error=maxabs(np.asarray(api.log_components(theta,'S',dd))-np.asarray(api.log_components(theta,'I',dd)))
        collapse[label]=error;assert error<=LIMITS['alias']
    # Probe absence cannot contribute a log-density term or affect update loss.
    absent=data_copy(data);absent['probe'][:]=-1
    for model in FAMILIES:
        lc=np.asarray(api.log_components(centers[model],model,absent))
        assert maxabs(lc[:,0]-lc[:,1])<=LIMITS['alias'] and maxabs(lc[:,2])==0.
        alt=data_copy(data);alt['probe']=1-data['probe'];alt['probe'][data['probe']<0]=-1
        v1,g1=api.loss_grad(centers[model],model,data,'update_only')
        v2,g2=api.loss_grad(centers[model],model,alt,'update_only')
        assert v1==v2 and maxabs(np.asarray(g1)-np.asarray(g2))==0.
        extra=data_copy(data);extra.update(true_e=.499,true_sigma=999.,latent_U=np.zeros(len(data['load'])),generator='misleading_oracle',test_update=np.ones(99))
        assert maxabs(np.asarray(api.log_components(centers[model],model,extra))-np.asarray(api.log_components(centers[model],model,data)))==0.
        z1,h1=api.loss_grad(centers[model],model,extra,'joint');z2,h2=api.loss_grad(centers[model],model,data,'joint')
        assert z1==z2 and maxabs(np.asarray(h1)-np.asarray(h2))==0.
    # Sigma is fitted against observable calibration noise, never true sigma.
    calib=fixture_data(n=0);z=np.asarray(calib['calibration_noise'])
    calibration_errors={}
    for model in FAMILIES:
        theta=centers[model];loss,gradient=api.loss_grad(theta,model,calib,'joint')
        expected=-norm.logpdf(z,0,theta[3]).sum();g=np.zeros(len(theta));g[3]=len(z)/theta[3]-np.sum(z*z)/theta[3]**3
        error=max(abs(loss-expected),maxabs(np.asarray(gradient)-g));calibration_errors[model]=error
        assert error<=1e-9,(model,'sigma calibration',error)
    moments={}
    for model in FAMILIES:
        rows=[]
        for load in (0,1):
            for f in (1.,math.log(.65/.35)/math.log(9)):
                row=moment_check(api,model,centers[model],load,f,.12)
                assert row['mass']<=LIMITS['density_mass']
                assert all(v<=LIMITS['moment_or_covariance'] for k,v in row.items() if k not in ('mass','expected_conditional_covariance'))
                rows.append(dict(load=load,factor=f,**row))
        moments[model]=rows
    files=[ROOT/'audit_models.py',ROOT/'models.py',ROOT/'PROTOCOL.txt']
    files.extend(p for p in (ROOT/'runtime').glob('*') if p.is_file())
    result=dict(status='passed independent density, gradient, marginal and measurement audit',
        checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seed=2026110723,
        limits=LIMITS,families=errors,nested_closures=closure,update_only_marginal_errors=marginal_errors,
        exact_collapse_checks=collapse,calibration_sigma_errors=calibration_errors,conditional_moment_checks=moments,
        named_alias_errors=alias_errors,extreme_zero_weight_log_density_error=tail_error,
        oracle_distractor_input_effect=0.,
        aliases='Shared admission, ordinary shared attention and shared-memory availability use the same S density by definition; no unique mechanism is identified.',
        sigma_calibration='Observable zero-update errors enter every candidate total likelihood; identification ehat is a common plug-in estimate, not true generator e.',
        limitations=['Finite fixtures/gradients are not a proof of global optimizer uniqueness.',
          'Calibration uncertainty in ehat is not integrated; finite chance-probe estimates can be below .5.',
          'Covariance checks condition separately on load and reliability; pooled covariance is not a coupling test.',
          'Extremely ill-conditioned vanishing-weight mixture tails need density-only checks rather than unreliable fixed-step gradients.'],
        sha256={p.relative_to(ROOT).as_posix():sha(p) for p in files})
    (ROOT/'MODEL_VALIDATION.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    lines=['INDEPENDENT RECOVERY MEASUREMENT/MODEL CONTRACT AUDIT','',result['status'],
        'Exact latent sums were independently implemented with scipy Normal densities.',
        'All six candidate families, both regimes, finite analytic-gradient checks,',
        'nested closures, marginal identities and sigma calibration were checked.',
        'Conditional density normalization/moments/covariances were numerically',
        'integrated separately for every load/reliability cell.','',
        'Maximum errors by family:']
    lines += [m+': '+json.dumps(v,sort_keys=True) for m,v in errors.items()]
    lines += ['',result['aliases'],result['sigma_calibration'],'',*result['limitations']]
    (ROOT/'MODEL_VALIDATION.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return result

def postfit_audit(partial=False):
    """Validate fitted observed-training records before any test export.

    This function deliberately never opens truth/ or test_inputs/ files, never
    imports the generator, and never invokes optimization.
    """
    api=importlib.import_module('models')
    frozen=json.loads((ROOT/'FROZEN_MANIFEST.json').read_text())
    def verify_frozen():
        for name,h in frozen['sha256'].items():assert sha(ROOT/name)==h,name
    verify_frozen()
    manifest_path=ROOT/'TRAINING_MANIFEST.json';manifest=json.loads(manifest_path.read_text())
    assert len(manifest)==840 and len({x['id'] for x in manifest})==840
    allowed={'load','factor','update','probe','ehat','calibration_noise','calibration_errors'}
    packets={};datasets={};bindings={manifest_path.relative_to(ROOT).as_posix():sha(manifest_path)}
    fingerprints={};origins={};reference_cache={};kernel_cache={}
    def observed_fingerprint(data,include_probe=False):
        h=hashlib.sha256()
        for key in ['load','factor','update','ehat','calibration_noise']+(['probe'] if include_probe else []):
            value=np.ascontiguousarray(data[key]);h.update(key.encode());h.update(value.dtype.str.encode())
            h.update(str(value.shape).encode());h.update(value.tobytes())
        return h.hexdigest()
    for entry in manifest:
        identity=entry['id'];path=ROOT/'fitting'/(identity+'.json')
        if not path.exists():
            assert partial,path
            continue
        source=ROOT/entry['input']
        assert source.resolve().is_relative_to((ROOT/'training_inputs').resolve())
        assert sha(source)==entry['sha256']
        with np.load(source,allow_pickle=False) as z:
            assert set(z.files)==allowed
            data={k:z[k].copy() for k in z.files}
        data['ehat']=float(data['ehat'])
        assert data['calibration_errors'].shape==(80,) and np.isin(data['calibration_errors'],[0,1]).all()
        assert data['calibration_noise'].shape==(32,) and np.isfinite(data['calibration_noise']).all()
        assert data['ehat']==float(np.clip((data['calibration_errors'].sum()+.5)/81,.005,.5))
        n=entry['n_train'];assert n in (120,360)
        assert all(np.asarray(data[k]).shape==(n,) for k in ('load','factor','update','probe'))
        assert np.isin(data['load'],[0,1]).all() and np.isin(data['probe'],[-1,0,1]).all()
        assert np.isfinite(data['factor']).all() and np.isfinite(data['update']).all()
        assert set(np.unique(data['factor']))=={1.,float(np.log(.65/.35)/np.log(.9/.1))}
        for load in (0,1):
            for factor in np.unique(data['factor']):assert int(((data['load']==load)&(data['factor']==factor)).sum())==n//4
        fingerprint=observed_fingerprint(data)
        assert fingerprint==entry['update_fingerprint']
        packet=json.loads(path.read_text())
        assert packet['id']==identity and packet['training_input_sha256']==entry['sha256']
        assert packet['ehat']==data['ehat'] and packet['update_fingerprint']==fingerprint
        assert packet['frozen_manifest_sha256']==sha(ROOT/'FROZEN_MANIFEST.json')
        assert set(packet['regimes'])==set(REGIMES)
        for regime in REGIMES:
            assert set(packet['regimes'][regime])==set(FAMILIES)
            for model,fit in packet['regimes'][regime].items():
                if not fit.get('reused_from'):
                    uid=fit['unique_fit_id'];assert uid==identity+':'+regime+':'+model and uid not in origins
                    origins[uid]=(identity,regime,model,fit)
        datasets[identity]=data;packets[identity]=packet
        fingerprints.setdefault(fingerprint,[]).append(identity)
        bindings[source.relative_to(ROOT).as_posix()]=sha(source)
        bindings[path.relative_to(ROOT).as_posix()]=sha(path)
    assert packets and (partial or len(packets)==840)
    errors={'selected_total_nll':0.,'attempt_total_nll':0.,'selected_log_components':0.,'reused_total_nll':0.}
    fit_count=0;unique_attempt_count=0;raw_failed_attempts=[];selected_failures=[];max_tie=0.;unidentified_counts={}
    for identity,packet in packets.items():
        source_data=datasets[identity]
        for regime in REGIMES:
            data=data_copy(source_data)
            if regime=='update_only':data['probe'][:]=-1
            signature=observed_fingerprint(data,include_probe=True)
            for model in FAMILIES:
                fit=packet['regimes'][regime][model];fit_count+=1
                assert fit['names']==NAMES[model] and len(fit['theta'])==len(NAMES[model])
                theta=np.asarray(fit['theta'],float)
                assert np.isfinite(theta).all()
                assert all(lo-1e-12<=value<=hi+1e-12 for value,(lo,hi) in zip(theta,REF_BOUNDS[model]))
                assert fit['unique_fit_id'] in origins,(identity,regime,model,'missing canonical fit')
                origin_id,origin_regime,origin_model,origin=origins[fit['unique_fit_id']]
                assert regime==origin_regime
                if fit.get('reused_from'):
                    assert fit['reused_from']==fit['unique_fit_id']
                    assert observed_fingerprint(source_data)==observed_fingerprint(datasets[origin_id])
                    if model!=origin_model:
                        assert regime=='update_only' and origin_model=='S' and model in ('I','IF','F')
                        extra=[.5,.5] if model=='IF' else [0.] if model=='F' else []
                        assert fit['theta']==origin['theta']+extra
                    else:assert fit['theta']==origin['theta']
                    assert fit['nll_total']==origin['nll_total'] and fit['success']==origin['success']
                unidentified=[]
                if model=='IF':
                    for load,name in [(0,'p_report_low'),(1,'p_report_high')]:
                        if regime=='update_only' or data['ehat']==.5 or not np.any((data['load']==load)&(data['probe']>=0)):
                            unidentified.append(name)
                elif model=='F' and (regime=='update_only' or data['ehat']==.5 or not np.any(data['probe']>=0)):
                    unidentified=['rho']
                assert fit['unidentified_parameters']==unidentified,(identity,regime,model,fit['unidentified_parameters'],unidentified)
                for name in unidentified:unidentified_counts[regime+':'+model+':'+name]=unidentified_counts.get(regime+':'+model+':'+name,0)+1
                def objective(point):
                    # Algebraically normalize only the known update-only aliases.
                    ref_model='S' if regime=='update_only' and model in ('I','IF','F') else model
                    point=list(point[:4]) if ref_model=='S' and model!='S' else list(point)
                    key=(signature,regime,ref_model,tuple(point))
                    if key not in reference_cache:reference_cache[key]=ref_loss(point,ref_model,data,regime)
                    return reference_cache[key]
                expected=objective(theta)
                delta=abs(expected-fit['nll_total']);errors['selected_total_nll']=max(errors['selected_total_nll'],delta)
                if fit.get('reused_from'):errors['reused_total_nll']=max(errors['reused_total_nll'],abs(expected-origin['nll_total']))
                assert delta<=1e-7,(identity,regime,model,delta)
                if not fit['success']:selected_failures.append((identity,regime,model))
                pool=fit['attempts'];assert pool
                minimum=min(x['nll_total'] for x in pool)
                eligible=[x for x in pool if x['success'] and x['nll_total']<=minimum+1e-8]
                best=min(eligible,key=lambda x:x['nll_total']) if eligible else min(pool,key=lambda x:x['nll_total'])
                assert fit['theta']==best['theta'] and fit['nll_total']==best['nll_total'] and fit['success']==best['success']
                assert fit['selected_kind']==best.get('original_kind',best['kind'])
                assert fit['objective_minimum']==minimum and fit['success_tie_gap']==fit['nll_total']-minimum
                assert 0<=fit['success_tie_gap']<=1e-8;max_tie=max(max_tie,fit['success_tie_gap'])
                for index,attempt in enumerate(pool):
                    delta=abs(objective(attempt['theta'])-attempt['nll_total'])
                    errors['attempt_total_nll']=max(errors['attempt_total_nll'],delta)
                    assert delta<=1e-7,(identity,regime,model,index,delta)
                    if not fit.get('reused_from'):
                        unique_attempt_count+=1
                        if not attempt['success']:raw_failed_attempts.append({'id':identity,'regime':regime,'model':model,'attempt':index,'kind':attempt['kind']})
                ref_model='S' if regime=='update_only' and model in ('I','IF','F') else model
                ref_theta=theta[:4] if ref_model=='S' else theta
                logkey=(signature,ref_model,tuple(ref_theta))
                if logkey not in kernel_cache:
                    actual=np.asarray(api.log_components(ref_theta,ref_model,data))
                    reference=ref_log_components(ref_theta,ref_model,data)
                    kernel_cache[logkey]=maxabs(actual-reference)
                error=kernel_cache[logkey];errors['selected_log_components']=max(errors['selected_log_components'],error)
                assert error<=1e-8
                # Boundary metadata describes raw optimized coordinates; a flat
                # but unidentified joint coordinate can still be at a bound.
                # Reduced embeddings also record their arbitrary raw coordinates,
                # e.g.rho0, while marking those coordinates as unidentified.
                boundary_model=model
                boundary_theta=theta
                expected_boundaries=[name for name,value,(lo,hi) in zip(NAMES[boundary_model],boundary_theta,REF_BOUNDS[boundary_model])
                    if min(abs(value-lo),abs(value-hi))<=1e-6]
                assert fit['boundaries']==expected_boundaries,(identity,regime,model,'boundaries')
    assert not selected_failures,selected_failures
    verify_frozen()
    assert sha(manifest_path)==bindings[manifest_path.relative_to(ROOT).as_posix()]
    for name,h in bindings.items():assert sha(ROOT/name)==h,name
    result=dict(status='passed independent observed-training fit and likelihood audit',partial=partial,
        checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cases=len(packets),fit_records=fit_count,
        unique_optimizations=len(origins),unique_attempts=unique_attempt_count,raw_failed_attempts_retained=raw_failed_attempts,
        selected_failures=selected_failures,maximum_success_tie_gap_total_nats=max_tie,errors=errors,
        update_input_equivalence_groups=len(fingerprints),conditional_unidentified_parameter_counts=unidentified_counts,
        calibration_count_per_case=dict(identification=80,zero_update=32),
        input_access='Observed training NPZ and training manifest only; no truth/test/evaluation files or generator module read.',
        oracle_values_used=False,optimizer_called=False,frozen_hashes_match=True,sha256=bindings,
        fitting_packet_sha256={k:v for k,v in bindings.items() if k.startswith('fitting/')},
        limits='1e-7 total-NLL comparison,1e-8 selected log-component error; successful tie convention1e-8 TOTAL nats.',
        audit_script_sha256=sha(__file__))
    stem='PARTIAL_POSTFIT_REVIEW' if partial else 'POSTFIT_REVIEW'
    (ROOT/(stem+'.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    lines=['INDEPENDENT OBSERVED-TRAINING RECOVERY AUDIT','',result['status'],
        f'{len(packets)} cases;{fit_count} fit records;{len(origins)} unique optimizations;{unique_attempt_count} retained unique attempts.',
        f'{len(raw_failed_attempts)} raw failed attempts retained;0 selected failures.',
        result['input_access'],'Every selected and attempted objective was independently recomputed.',
        'Exact reduced-family reuse, successful-tie minimum selection, bounds,',
        'calibration identity, conditional unidentified coordinates and hashes pass.',
        'Maximum errors: '+json.dumps(errors,sort_keys=True),
        'Maximum successful tie gap,total nats: '+str(max_tie),
        'Conditional unidentified coordinates: '+json.dumps(unidentified_counts,sort_keys=True)]
    (ROOT/(stem+'.txt')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--postfit',action='store_true');parser.add_argument('--partial',action='store_true');args=parser.parse_args()
    result=postfit_audit(args.partial) if args.postfit else prefit_audit()
    print(json.dumps({k:v for k,v in result.items() if k in ('status','families','nested_closures','exact_collapse_checks','calibration_sigma_errors','cases','fit_records','unique_optimizations','unique_attempts','errors','selected_failures','maximum_success_tie_gap_total_nats')},indent=2))
