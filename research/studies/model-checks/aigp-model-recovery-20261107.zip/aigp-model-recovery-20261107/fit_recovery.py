"""Observed-training-only bounded MLE; no truth/test manifest is opened here."""
import argparse,copy,json,datetime,time
import numpy as np
from scipy.optimize import minimize
import models
from run_common import ROOT,MODELS,REGIMES,NAMES,sha,verify_freeze,load_training,model_data,update_fingerprint

assert NAMES==models.NAMES
OPT=dict(maxiter=500,maxfun=12000,maxls=40,ftol=1e-11,gtol=1e-6)
POWELL=dict(maxiter=500,maxfev=12000,xtol=1e-7,ftol=1e-10)
def loss_only(theta,model,data,regime):
    logs=models.log_components(theta,model,data)
    column=0 if regime=='joint' else 1;sigma=float(theta[3]);noise=data['calibration_noise']
    return float(-logs[:,column].sum()+len(noise)*(.5*np.log(2*np.pi)+np.log(sigma))+np.dot(noise,noise)/(2*sigma*sigma))
class GradientOutOfRange(Exception):
    def __init__(self,theta,loss):self.theta=np.asarray(theta).copy();self.loss=float(loss)
def four_starts(data,model,regime):
    sigma=float(np.clip(np.sqrt(np.mean(data['calibration_noise']**2)),.05,.95))
    phat=np.full(2,.5)
    if regime=='joint' and data['ehat']<=.48:
        for load in [0,1]:
            mask=(data['load']==load)&(data['probe']>=0)
            if mask.any():phat[load]=np.clip((data['probe'][mask].mean()-.5)/(.5-data['ehat']),.05,.95)
    alpha=float(np.clip(np.mean(data['update']/data['factor'])/np.mean(phat[data['load']]),.05,1.))
    starts=[[.8,.5,.5,sigma],[.5,.5,.3,sigma],[.95,.85,.7,sigma],phat.tolist()+[alpha,sigma]]
    if model=='IF':starts=[x+x[:2] for x in starts]
    elif model=='F':starts=[x+[v] for x,v in zip(starts,[1.,0.,.5,.5])]
    elif model=='E':starts=[x+[v] for x,v in zip(starts,[0.,.1,.2,.05])]
    return starts
def fit_one(data,model,regime,fit_id,nested=()):
    attempts=[]
    def add(theta,value,success,message,kind,**extra):
        value=float(value);assert np.isfinite(value)
        record=dict(theta=np.asarray(theta).tolist(),nll_total=value,success=bool(success),message=str(message),kind=kind,**extra)
        attempts.append(record)
    def fun(theta):
        try:return models.loss_grad(theta,model,data,regime)
        except AssertionError:
            if model!='E' or theta[-1]!=0:raise
            raise GradientOutOfRange(theta,loss_only(theta,model,data,regime))
    def gradient_attempt(initial,kind):
        try:
            result=minimize(fun,initial,jac=True,method='L-BFGS-B',bounds=models.bounds(model),options=OPT)
            add(result.x,result.fun,result.success,result.message,kind,initial=list(initial),nfev=int(result.nfev),nit=int(result.nit))
        except GradientOutOfRange as error:
            add(error.theta,error.loss,False,'Finite density but unrepresentable E/w0 analytic gradient at a proposal',kind,initial=list(initial),nfev=None,nit=None)
    for theta,source in nested:
        add(theta,loss_only(theta,model,data,regime),source['success'],'exact nested likelihood candidate','nested',source_fit_id=source['unique_fit_id'])
    for initial in four_starts(data,model,regime):
        gradient_attempt(initial,'L-BFGS-B')
    best=min(attempts,key=lambda z:z['nll_total'])
    result=minimize(lambda theta:loss_only(theta,model,data,regime),best['theta'],method='Powell',bounds=models.bounds(model),options=POWELL)
    add(result.x,result.fun,result.success,result.message,'Powell refinement',initial=best['theta'],nfev=int(result.nfev),nit=int(result.nit))
    gradient_attempt(result.x,'final L-BFGS-B')
    minimum=min(z['nll_total'] for z in attempts)
    eligible=[z for z in attempts if z['success'] and z['nll_total']<=minimum+1e-8]
    selected=min(eligible,key=lambda z:z['nll_total']) if eligible else min(attempts,key=lambda z:z['nll_total'])
    theta=selected['theta'];boundaries=[name for name,value,(lo,hi) in zip(NAMES[model],theta,models.bounds(model)) if min(abs(value-lo),abs(value-hi))<=1e-6]
    unidentified=[]
    if regime=='joint':
        if model=='IF':
            unidentified=[name for load,name in enumerate(['p_report_low','p_report_high']) if data['ehat']==.5 or not ((data['load']==load)&(data['probe']>=0)).any()]
        elif model=='F' and (data['ehat']==.5 or not (data['probe']>=0).any()):unidentified=['rho']
    return dict(theta=theta,names=NAMES[model],nll_total=selected['nll_total'],success=selected['success'],
      selected_kind=selected['kind'],objective_minimum=minimum,success_tie_gap=selected['nll_total']-minimum,
      attempts=attempts,reused_from=None,unidentified_parameters=unidentified,boundaries=boundaries,unique_fit_id=fit_id)
def embed_reduced(source,model):
    result=copy.deepcopy(source);result['names']=NAMES[model]
    result['reused_from']=source['unique_fit_id'];result['source_model']='S'
    extras=[.5,.5] if model=='IF' else [0.] if model=='F' else []
    result['theta']=source['theta']+extras
    result['unidentified_parameters']=['p_report_low','p_report_high'] if model=='IF' else ['rho'] if model=='F' else []
    result['boundaries']=[name for name,value,(lo,hi) in zip(NAMES[model],result['theta'],models.bounds(model)) if min(abs(value-lo),abs(value-hi))<=1e-6]
    for attempt in result['attempts']:
        attempt['theta']=attempt['theta']+extras
        if 'initial' in attempt:attempt['initial']=attempt['initial']+extras
        attempt['original_kind']=attempt['kind'];attempt['kind']='reused:'+attempt['kind'];attempt['source_model']='S'
    return result
def fit_case(identity,data,update_cache):
    joint={}
    for model in MODELS:
        nested=[]
        if model=='IF':nested=[(joint['I']['theta']+joint['I']['theta'][:2],joint['I'])]
        elif model=='F':nested=[(joint['S']['theta']+[1.],joint['S']),(joint['I']['theta']+[0.],joint['I'])]
        elif model=='E':nested=[(joint['S']['theta']+[0.],joint['S'])]
        joint[model]=fit_one(model_data(data,'joint'),model,'joint',identity+':joint:'+model,nested)
    fingerprint=update_fingerprint(data)
    if fingerprint in update_cache:
        reduced=copy.deepcopy(update_cache[fingerprint])
        for record in reduced.values():record['reused_from']=record['unique_fit_id']
    else:
        reduced={};d=model_data(data,'update_only')
        for model in ['S','C','E']:
            nested=[(reduced['S']['theta']+[0.],reduced['S'])] if model=='E' else []
            reduced[model]=fit_one(d,model,'update_only',identity+':update_only:'+model,nested)
        update_cache[fingerprint]=copy.deepcopy(reduced)
    update={m:embed_reduced(reduced['S'],m) for m in ['I','IF','F']}
    update.update(reduced)
    return {'joint':joint,'update_only':update}
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--index',type=int,default=0);parser.add_argument('--total',type=int,default=1);args=parser.parse_args()
    freeze_sha=verify_freeze();assert 0<=args.index<args.total
    manifest_path=ROOT/'TRAINING_MANIFEST.json';manifest=json.loads(manifest_path.read_text())
    assert len(manifest)==840 and len({z['id'] for z in manifest})==840
    out=ROOT/'fitting';out.mkdir(exist_ok=True);cache={};done=0
    for entry in manifest:
        if int(entry['update_fingerprint'][:16],16)%args.total!=args.index:continue
        path=ROOT/entry['input'];assert sha(path)==entry['sha256'];data=load_training(path)
        assert len(data['load'])==entry['n_train'] and update_fingerprint(data)==entry['update_fingerprint']
        dest=out/(entry['id']+'.json');assert not dest.exists(),'Preserve prior fit packet.'
        started=time.perf_counter();regimes=fit_case(entry['id'],data,cache)
        record=dict(id=entry['id'],training_input_sha256=sha(path),update_fingerprint=entry['update_fingerprint'],
          ehat=data['ehat'],regimes=regimes,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
          seconds=time.perf_counter()-started,frozen_manifest_sha256=freeze_sha)
        dest.write_text(json.dumps(record,indent=2,allow_nan=False),encoding='utf-8');done+=1
        failures=[regime+':'+m for regime,z in regimes.items() for m,r in z.items() if not r['success']]
        print(f"FIT {entry['id']} worker{args.index} completed{done} failures={failures}",flush=True)
    verify_freeze()
    (out/f'worker_{args.index}_complete.json').write_text(json.dumps(dict(index=args.index,total=args.total,cases=done,status='complete')),encoding='utf-8')
if __name__=='__main__':main()
