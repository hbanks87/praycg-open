"""Frozen arithmetic aggregation for the bounded encoding/update recovery screen.

Reads fitting/evaluation packets only. It never fits a model or calls a simulator.
"""
from pathlib import Path
import csv
import hashlib
import json
import math

import numpy as np

ROOT = Path(__file__).resolve().parent
SCENARIOS = ('short_standard', 'long_standard', 'more_probes', 'noisy_measurement',
             'chance_probe', 'weak_update', 'near_universal')
GENERATORS = ('S', 'I', 'C', 'F', 'E')
CANDIDATES = ('S', 'I', 'C', 'IF', 'F', 'E')
REDUCED_CANDIDATES = ('S/I/IF/F', 'C', 'E')
MARGIN = .001
REPLICATES = 24
AMBIGUOUS = 'AMBIGUOUS'
UPDATE_EQUIVALENT = ('S', 'I', 'IF', 'F')
SHARED_ALIASES = {'decoder_admission': 'S', 'ordinary_shared_attention': 'S',
                  'shared_memory_availability': 'S'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def verify_hashes(mapping, root=ROOT):
    require(bool(mapping), 'Empty evidence hash mapping')
    bad = [k for k, v in mapping.items() if not (root / k).is_file() or sha256(root / k) != v]
    require(not bad, 'Artifact binding changed: ' + ', '.join(bad[:8]))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def write_csv(path, rows, fieldnames=None):
    rows = list(rows)
    names = fieldnames or (list(rows[0]) if rows else [])
    with Path(path).open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=names)
        writer.writeheader()
        writer.writerows(rows)


def wilson(successes, n):
    require(0 <= successes <= n and n > 0, 'Invalid binomial denominator')
    z = 1.959963984540054
    phat = successes / n
    denominator = 1 + z*z/n
    center = (phat + z*z/(2*n)) / denominator
    half = z * math.sqrt(phat*(1-phat)/n + z*z/(4*n*n)) / denominator
    return {'count': successes, 'n': n, 'rate': phat,
            'wilson_low95': max(0., center-half), 'wilson_high95': min(1., center+half)}


def select_models(scores, margin=MARGIN):
    require(bool(scores) and all(math.isfinite(float(x)) for x in scores.values()),
            'Nonfinite or empty held-out score')
    minimum = min(scores.values())
    tied = sorted(k for k, value in scores.items() if float(value) - minimum <= margin)
    require(bool(tied), 'Empty winning set')
    return {'selected': tied[0] if len(tied) == 1 else AMBIGUOUS,
            'within_margin': tied, 'minimum_loss': float(minimum)}


def pair_decision(score_s, score_other, truth):
    difference = float(score_other - score_s)
    selected = 'S' if difference > MARGIN else ('OTHER' if difference < -MARGIN else AMBIGUOUS)
    expected = 'S' if truth == 'S' else 'OTHER'
    return {'gain_favoring_S': difference, 'selected': selected,
            'correct': selected == expected,
            'incorrect': selected not in (expected, AMBIGUOUS),
            'ambiguous': selected == AMBIGUOUS}


def summarize_pair(rows):
    n = len(rows)
    require(n == REPLICATES, 'Pairwise cell has wrong replicate count')
    return {key: wilson(sum(bool(row[key]) for row in rows), n)
            for key in ('correct', 'incorrect', 'ambiguous')}


def recovery_moments(true_values, estimated_values):
    truth = np.asarray(true_values, dtype=float)
    estimate = np.asarray(estimated_values, dtype=float)
    require(truth.shape == estimate.shape and truth.ndim == 1 and len(truth) > 0,
            'Parameter recovery shape mismatch')
    require(np.all(np.isfinite(truth)) and np.all(np.isfinite(estimate)), 'Nonfinite recovery values')
    error = estimate - truth
    varying = np.std(truth) > 1e-12 and np.std(estimate) > 1e-12
    correlation = float(np.corrcoef(truth, estimate)[0, 1]) if varying else None
    return {'n': len(truth), 'true_mean': float(np.mean(truth)), 'fitted_mean': float(np.mean(estimate)),
            'bias': float(np.mean(error)), 'rmse': float(np.sqrt(np.mean(error*error))),
            'mean_absolute_error': float(np.mean(np.abs(error))),
            'pearson_r': correlation,
            'association_note': 'Pearson association' if varying else 'Undefined: constant true or fitted values'}


def classify_confusion(rows, regime):
    labels = CANDIDATES if regime == 'joint' else REDUCED_CANDIDATES
    output = []
    for scenario in SCENARIOS:
        for generator in GENERATORS:
            chosen = [row for row in rows if row['scenario'] == scenario and row['generator'] == generator
                      and row['regime'] == regime]
            require(len(chosen) == REPLICATES, 'Confusion cell has wrong replicate count')
            for selected in (*labels, AMBIGUOUS):
                count = sum(row['selected'] == selected for row in chosen)
                output.append({'scenario': scenario, 'regime': regime, 'generator': generator,
                               'selected': selected, **wilson(count, len(chosen))})
    return output


def arithmetic_preflight():
    require(select_models({'S': 1., 'I': 1.0009})['selected'] == AMBIGUOUS, 'Margin ambiguity check')
    require(select_models({'S': 1., 'I': 1.0011})['selected'] == 'S', 'Strict margin winner check')
    require(select_models({'S': 1., 'I': 1., 'F': 1.0002})['within_margin'] == ['F', 'I', 'S'],
            'Complete nested-closure tie set check')
    require(pair_decision(1., 1.002, 'S')['correct'], 'S-direction check')
    require(pair_decision(1.002, 1., 'I')['correct'], 'I-direction check')
    require(pair_decision(1., 1., 'I')['ambiguous'], 'No arbitrary pair tie breaking')
    require(select_models({'S': 0., 'I': MARGIN})['selected'] == AMBIGUOUS,
            'Inclusive ambiguity at exact margin')
    require(pair_decision(0., MARGIN, 'S')['ambiguous'], 'Strict pair threshold at exact margin')
    result = wilson(0, 24)
    require(result['wilson_low95'] < 1e-14 and abs(result['wilson_high95'] - .13797620467498026) < 1e-12,
            'Wilson zero-success check')
    result = wilson(24, 24)
    require(abs(result['wilson_low95'] - .8620237953250198) < 1e-12 and result['wilson_high95'] > 1-1e-14,
            'Wilson all-success check')
    require(recovery_moments([1, 2], [2, 3])['bias'] == 1., 'Parameter bias check')
    require(recovery_moments([.45, .45], [.4, .5])['pearson_r'] is None, 'Constant truth association check')
    fixture = []
    for scenario in SCENARIOS:
        for generator in GENERATORS:
            for replicate in range(REPLICATES):
                for regime in ('joint', 'update_only'):
                    selected = generator if regime == 'joint' else (
                        'S/I/IF/F' if generator in ('S', 'I', 'F') else generator)
                    fixture.append({'scenario': scenario, 'generator': generator,
                                    'replicate': replicate, 'regime': regime, 'selected': selected})
    counts = classify_confusion(fixture, 'joint') + classify_confusion(fixture, 'update_only')
    require(len(counts) == len(SCENARIOS)*len(GENERATORS)*(7+4), 'Confusion export dimensions')
    for scenario in SCENARIOS:
        for generator in GENERATORS:
            for regime in ('joint', 'update_only'):
                cell = [x for x in counts if x['scenario'] == scenario and x['generator'] == generator
                        and x['regime'] == regime]
                require(sum(x['count'] for x in cell) == 24 and all(x['n'] == 24 for x in cell),
                        'Confusion denominator preservation')
    pair_fixture = [{'correct': j < 20, 'incorrect': 20 <= j < 22, 'ambiguous': j >= 22}
                    for j in range(24)]
    pair_summary = summarize_pair(pair_fixture)
    require(pair_summary['correct']['count'] == 20 and pair_summary['incorrect']['count'] == 2
            and pair_summary['ambiguous']['count'] == 2, '20/24 and 2/24 observed-rate criterion arithmetic')
    return {'status': 'passed arithmetic preflight', 'production_data_read': False,
            'checks': ['strict pair margin', 'full within-margin set', 'ambiguous ties',
                       'Wilson interval endpoints', 'parameter bias', 'constant-truth association',
                       'confusion dimensions and denominators', 'observed-rate criterion counts']}


def aggregate():
    out = ROOT / 'results'
    require(not (out / 'RESULTS.json').exists(), 'Refusing to overwrite final RESULTS.json')
    frozen = read_json(ROOT / 'FROZEN_MANIFEST.json')
    verify_hashes(frozen['sha256'])
    status = read_json(ROOT / 'SIMULATION_VALIDATION_STATUS.json')
    require(status['status'] == 'passed', 'Simulation fitting validation has not passed')
    verify_hashes(status['sha256'])
    generation = read_json(ROOT / 'PRODUCTION_GENERATION.json')
    require(generation['frozen_manifest_sha256'] == sha256(ROOT / 'FROZEN_MANIFEST.json'),
            'Production generated under a different freeze')
    require(status['sha256'].get('PRODUCTION_GENERATION.json') == sha256(ROOT / 'PRODUCTION_GENERATION.json'),
            'Generation record was not bound before evaluation')
    verify_hashes(generation['manifests_sha256'])
    for manifest_name in ('TRAINING_MANIFEST.json', 'TEST_MANIFEST.json', 'TRUTH_MANIFEST.json'):
        require(status['sha256'].get(manifest_name) == sha256(ROOT / manifest_name),
                'Production manifest was not bound before evaluation: ' + manifest_name)
        manifest_rows = read_json(ROOT / manifest_name)
        require(len(manifest_rows) == 840 and len({x['id'] for x in manifest_rows}) == 840,
                'Input manifest count/identity mismatch')
        verify_hashes({x['input']: x['sha256'] for x in manifest_rows})
    paths = sorted((ROOT / 'evaluation').glob('case_*.json'))
    require(len(paths) == len(SCENARIOS)*len(GENERATORS)*REPLICATES, 'Expected exactly 840 evaluation packets')
    score_rows, decision_rows, pair_rows, parameter_rows, fit_rows, attempt_rows = [], [], [], [], [], []
    alias_checks, parameter_raw, unidentified_rows, tie_rows = [], [], [], []
    cells, seen, fit_hashes, evaluation_hashes = {}, set(), {}, {}
    raw_failures, selected_failures, independent_fits, max_tie_gap = 0, 0, 0, 0.
    max_decomposition_error, max_update_alias_error = 0., 0.
    repeated_updates, calibration_unique, calibration_rows = {}, {}, []
    for path in paths:
        packet = read_json(path)
        case_id = packet['id']
        require(case_id == path.stem and case_id not in seen, 'Duplicate/mismatched case identity')
        seen.add(case_id)
        fit_path = ROOT / 'fitting' / (case_id + '.json')
        truth_path = ROOT / 'truth' / (case_id + '.json')
        train_path = ROOT / 'training_inputs' / (case_id + '.npz')
        test_path = ROOT / 'test_inputs' / (case_id + '.npz')
        for key, bound_path in [('fitting_sha256', fit_path), ('truth_sha256', truth_path),
                                ('training_input_sha256', train_path), ('test_input_sha256', test_path)]:
            require(packet[key] == sha256(bound_path), 'Evaluation input binding: ' + case_id + '/' + key)
        fit_relative = fit_path.relative_to(ROOT).as_posix()
        require(status['sha256'].get(fit_relative) == packet['fitting_sha256'], 'Fit not bound before test evaluation')
        fit = read_json(fit_path)
        truth = read_json(truth_path)
        require(fit['id'] == case_id, 'Fit identity mismatch')
        require(fit['training_input_sha256'] == packet['training_input_sha256'], 'Fit training input mismatch')
        require(packet['training_fit_metadata'] == fit['regimes'], 'Evaluation changed fitted parameters/status')
        for key, value in packet['truth'].items():
            require(truth.get(key) == value, 'Evaluation truth metadata mismatch: ' + key)
        scenario, generator, replicate = truth['scenario'], truth['generator'], int(truth['replicate'])
        require(scenario in SCENARIOS and generator in GENERATORS, 'Unknown simulation condition')
        cells.setdefault((scenario, generator), set())
        require(replicate not in cells[(scenario, generator)], 'Duplicate generator/cell replicate')
        cells[(scenario, generator)].add(replicate)
        require(int(truth['n_test']) == 240, 'Unexpected test episode count')
        n = int(truth['n_test'])
        observed = packet['observed']
        with np.load(test_path, allow_pickle=False) as data:
            for name in ('load', 'factor', 'update', 'probe'):
                arr = np.asarray(observed[name])
                require(arr.shape == (n,) and np.array_equal(arr, data[name]), 'Observed held-out identity mismatch')
        with np.load(train_path, allow_pickle=False) as data:
            require(float(packet['ehat']) == float(data['ehat']) == float(fit['ehat']), 'Calibration estimate changed')
            require(len(data['load']) == int(truth['n_train']), 'Training episode count mismatch')
            calibration_noise = data['calibration_noise'].tolist()
            calibration_errors = data['calibration_errors'].tolist()
            require(len(calibration_noise) == 32 and len(calibration_errors) == 80,
                    'Calibration sample counts changed')
            require(set(calibration_errors) <= {0, 1}, 'Invalid readout calibration outcomes')
            expected_ehat = float(np.clip((sum(calibration_errors) + .5) / 81, .005, .5))
            require(float(packet['ehat']) == expected_ehat, 'Readout calibration is not the declared plug-in estimate')
        probes = np.asarray(observed['probe']) >= 0
        require(set(np.asarray(observed['probe']).tolist()) <= {-1, 0, 1}, 'Invalid report outcome')
        base = {'id': case_id, 'scenario': scenario, 'generator': generator, 'replicate': replicate}
        calibration_record = {'scenario': scenario, 'replicate': replicate,
                              'true_e': float(truth['true_parameters']['e']), 'ehat': float(packet['ehat']),
                              'errors': int(sum(calibration_errors)), 'identification_trials': 80,
                              'zero_update_differences': 32}
        calibration_rows.append({**base, **calibration_record,
                                 'error': calibration_record['ehat'] - calibration_record['true_e']})
        if (scenario, replicate) in calibration_unique:
            require(calibration_unique[(scenario, replicate)] == calibration_record,
                    'Generators do not share the declared calibration stream')
        else:
            calibration_unique[(scenario, replicate)] = calibration_record
        losses = {}
        regime_log = {}
        for regime in ('joint', 'update_only'):
            candidate_packets = packet['regimes'][regime]
            fits = fit['regimes'][regime]
            require(set(candidate_packets) == set(CANDIDATES) == set(fits), 'Incomplete candidate family set')
            losses[regime], regime_log[regime] = {}, {}
            for candidate in CANDIDATES:
                f = fits[candidate]
                success = bool(f['success'])
                selected_failures += int(not success)
                gap = float(f['success_tie_gap'])
                require(gap >= -1e-12 and gap <= 1e-8 + 1e-12, 'Selected fit exceeds successful tie rule')
                require(abs(float(f['nll_total']) - float(f['objective_minimum']) - gap) < 1e-7,
                        'Fit objective/tie metadata disagree')
                max_tie_gap = max(max_tie_gap, gap)
                fit_rows.append({**base, 'regime': regime, 'candidate': candidate,
                                 'names': json.dumps(f['names']), 'theta': json.dumps(f['theta']),
                                 'nll_total': f['nll_total'], 'success': success,
                                 'selected_kind': f['selected_kind'], 'objective_minimum': f['objective_minimum'],
                                 'success_tie_gap': gap, 'reused_from': f.get('reused_from'),
                                 'unidentified_parameters': json.dumps(f.get('unidentified_parameters', []))})
                for name in f.get('unidentified_parameters', []):
                    unidentified_rows.append({**base, 'regime': regime, 'candidate': candidate, 'parameter': name})
                if not f.get('reused_from'):
                    independent_fits += 1
                    for j, attempt in enumerate(f['attempts']):
                        raw_failures += int(not bool(attempt['success']))
                        attempt_rows.append({**base, 'regime': regime, 'candidate': candidate,
                                             'attempt': j, **{k: (json.dumps(v) if isinstance(v, (list, dict)) else v)
                                                              for k, v in attempt.items()}})
                arr = np.asarray(candidate_packets[candidate]['log_components'], dtype=float)
                require(arr.shape == (n, 4 if regime == 'joint' else 1) and np.all(np.isfinite(arr)),
                        'Invalid episode log-density matrix')
                regime_log[regime][candidate] = arr
                component = np.mean(arr, axis=0)
                if regime == 'joint':
                    decomposition = float(np.max(np.abs(arr[:, 0] - arr[:, 1] - arr[:, 3])))
                    max_decomposition_error = max(max_decomposition_error, decomposition)
                    require(decomposition <= 1e-10, 'Joint/update/conditional decomposition failed')
                    require(np.all(np.abs(arr[~probes, 2:]) <= 1e-12), 'Unprobed probe score must be zero')
                    require(np.all(arr[:, 2] <= 1e-12) and np.all(arr[:, 3] <= 1e-10),
                            'Binary report log probability is positive')
                    loss = -float(component[0])
                    record = dict(joint_loss=loss, update_loss=-float(component[1]),
                                  probe_marginal_loss=-float(component[2]), conditional_probe_loss=-float(component[3]))
                else:
                    loss = -float(component[0])
                    record = dict(joint_loss=None, update_loss=loss,
                                  probe_marginal_loss=None, conditional_probe_loss=None)
                losses[regime][candidate] = loss
                score_rows.append({**base, 'regime': regime, 'candidate': candidate,
                                   'main_episodes': n, 'probed_episodes': int(probes.sum()), **record})
            for candidate in UPDATE_EQUIVALENT:
                error = float(np.max(np.abs(regime_log['update_only'][candidate] - regime_log['update_only']['S']))) \
                    if regime == 'update_only' else 0.
                max_update_alias_error = max(max_update_alias_error, error)
                require(error == 0., 'Update-only exact aliases differ')
            candidates = losses[regime] if regime == 'joint' else {
                'S/I/IF/F': losses[regime]['S'], 'C': losses[regime]['C'], 'E': losses[regime]['E']}
            selected = select_models(candidates)
            decision_rows.append({**base, 'regime': regime, 'selected': selected['selected'],
                                  'within_margin': '|'.join(selected['within_margin']),
                                  'minimum_loss': selected['minimum_loss']})
            tie_rows.append({**base, 'regime': regime, **selected})
            if generator in ('S', 'I'):
                for other in ('I', 'IF'):
                    decision = pair_decision(losses[regime]['S'], losses[regime][other], generator)
                    pair_rows.append({**base, 'regime': regime, 'comparison': 'S_vs_' + other, **decision})
        aliases = packet['aliases']
        require(aliases == SHARED_ALIASES,
                'Shared mechanism alias mapping changed')
        alias_checks.append({**base, 'aliases': aliases, 'fit_once': True, 'distinct_mechanism_identified': False})
        if generator in ('S', 'I', 'F'):
            pair_key = (scenario, replicate)
            u = {'observed': observed['update'], 'load': observed['load'], 'factor': observed['factor'],
                 'ehat': packet['ehat'], 'calibration_noise': calibration_noise,
                 'calibration_errors': calibration_errors,
                 'reduced_forecast': regime_log['update_only']['S'].tolist()}
            if pair_key in repeated_updates:
                require(repeated_updates[pair_key] == u, 'Common S/I/F update-only data/fit predictions differ')
            else:
                repeated_updates[pair_key] = u
        true_fit = fit['regimes']['joint'][generator]
        require(len(true_fit['theta']) == len(true_fit['names']), 'True-family parameter names mismatch')
        for name, estimated in zip(true_fit['names'], true_fit['theta']):
            require(name in truth['true_parameters'], 'True-family parameter missing from truth: ' + name)
            actual = float(truth['true_parameters'][name])
            parameter_rows.append({**base, 'regime': 'joint', 'candidate': generator,
                                   'parameter': name, 'true_value': actual, 'fitted_value': float(estimated),
                                   'error': float(estimated) - actual, 'selected_model_conditioned': False,
                                   'identified_under_fitted_calibration': name not in true_fit.get('unidentified_parameters', [])})
            parameter_raw.setdefault((scenario, generator, name), ([], []))
            parameter_raw[(scenario, generator, name)][0].append(actual)
            parameter_raw[(scenario, generator, name)][1].append(float(estimated))
        fit_hashes[fit_relative] = packet['fitting_sha256']
        evaluation_hashes[path.relative_to(ROOT).as_posix()] = sha256(path)
    require(len(cells) == len(SCENARIOS)*len(GENERATORS) and all(len(x) == REPLICATES for x in cells.values()),
            'Incomplete generation grid')
    require(len(repeated_updates) == len(SCENARIOS)*REPLICATES,
            'S/I/F common-stream replicate alignment changed')
    require(selected_failures == 0, 'Selected unsuccessful fits block recovery summary')
    confusion = classify_confusion(decision_rows, 'joint') + classify_confusion(decision_rows, 'update_only')
    pair_summary, design_screens = [], {}
    for scenario in SCENARIOS:
        for regime in ('joint', 'update_only'):
            for comparison in ('S_vs_I', 'S_vs_IF'):
                directions = {}
                for generator in ('S', 'I'):
                    chosen = [row for row in pair_rows if row['scenario'] == scenario and row['regime'] == regime
                              and row['comparison'] == comparison and row['generator'] == generator]
                    summary = summarize_pair(chosen)
                    directions[generator] = summary
                    pair_summary.append({'scenario': scenario, 'regime': regime, 'comparison': comparison,
                                         'generator': generator, **summary})
                passed = (directions['S']['correct']['count'] >= 20 and directions['I']['correct']['count'] >= 20
                          and directions['I']['incorrect']['count'] <= 2)
                design_screens.setdefault(scenario, {}).setdefault(regime, {})[comparison] = {
                    'passed': passed, 'directions': directions,
                    'required_correct_count_each_direction': 20, 'maximum_false_S_count_when_I': 2,
                    'n_per_direction': 24}
    primary = design_screens['long_standard']['joint']
    parameter_summary = [{'scenario': scenario, 'generator': generator, 'parameter': name,
                          **recovery_moments(*values),
                          'unidentified_fit_count': sum(not row['identified_under_fitted_calibration']
                              for row in parameter_rows if row['scenario'] == scenario and row['generator'] == generator
                              and row['parameter'] == name)} for (scenario, generator, name), values in parameter_raw.items()]
    calibration_summary = []
    for scenario in SCENARIOS:
        values = [x for x in calibration_unique.values() if x['scenario'] == scenario]
        require(len(values) == REPLICATES, 'Calibration unique-replicate denominator changed')
        calibration_summary.append({'scenario': scenario, 'estimated_quantity': 'effective readout error e',
                                    'free_model_parameter': False,
                                    **recovery_moments([x['true_e'] for x in values], [x['ehat'] for x in values])})
    reduced_unique = []
    for row in decision_rows:
        if row['regime'] != 'update_only' or row['generator'] in ('I', 'F'):
            continue
        expected = 'S/I/IF/F' if row['generator'] == 'S' else row['generator']
        reduced_unique.append({**row, 'true_equivalence_class': expected,
                               'correct_class': row['selected'] == expected,
                               'ambiguous': row['selected'] == AMBIGUOUS})
    require(len(reduced_unique) == len(SCENARIOS)*3*REPLICATES, 'Update-only deduplication mismatch')
    out.mkdir(exist_ok=True)
    write_csv(out / 'case_model_scores.csv', score_rows)
    write_csv(out / 'classifications.csv', decision_rows)
    write_csv(out / 'confusion_counts.csv', confusion)
    write_csv(out / 'pairwise_decisions.csv', pair_rows)
    flat_pairs = []
    for row in pair_summary:
        for metric in ('correct', 'incorrect', 'ambiguous'):
            flat_pairs.append({**{k: row[k] for k in ('scenario', 'regime', 'comparison', 'generator')},
                               'outcome': metric, **row[metric]})
    write_csv(out / 'pairwise_recovery_summary.csv', flat_pairs)
    write_csv(out / 'true_family_parameter_recovery.csv', parameter_rows)
    write_csv(out / 'parameter_recovery_summary.csv', parameter_summary)
    write_csv(out / 'calibration_by_dataset.csv', calibration_rows)
    write_csv(out / 'calibration_unique_replicates.csv', calibration_unique.values())
    write_csv(out / 'calibration_recovery_summary.csv', calibration_summary)
    write_csv(out / 'fit_parameters_and_status.csv', fit_rows)
    write_json(out / 'shared_mechanism_aliases.json', alias_checks)
    if attempt_rows:
        fields = list(dict.fromkeys(k for row in attempt_rows for k in row))
        write_csv(out / 'optimizer_attempts.csv', attempt_rows, fields)
    write_csv(out / 'unidentified_parameters.csv', unidentified_rows,
              ['id', 'scenario', 'generator', 'replicate', 'regime', 'candidate', 'parameter'])
    write_csv(out / 'unidentified_reduced_parameters.csv',
              [row for row in unidentified_rows if row['regime'] == 'update_only'],
              ['id', 'scenario', 'generator', 'replicate', 'regime', 'candidate', 'parameter'])
    write_csv(out / 'update_only_unique_classifications.csv', reduced_unique)
    results = {
        'status': 'complete bounded synthetic recovery screen', 'synthetic_datasets': len(paths),
        'scenarios': list(SCENARIOS), 'generating_families': list(GENERATORS), 'joint_candidates': list(CANDIDATES),
        'update_only_equivalence_classes': list(REDUCED_CANDIDATES), 'replicates_per_scenario_generator': REPLICATES,
        'primary_scenario': 'long_standard', 'margin_nats_per_main_episode': MARGIN,
        'pairwise_recovery': pair_summary, 'design_screens': design_screens,
        'primary_S_vs_I_passed': primary['S_vs_I']['passed'],
        'primary_IF_robustness_passed': primary['S_vs_IF']['passed'],
        'limited_candidate_design_passed': primary['S_vs_I']['passed'] and primary['S_vs_IF']['passed'],
        'confusion': confusion, 'within_margin_sets': tie_rows, 'parameter_recovery': parameter_summary,
        'calibration_recovery': calibration_summary,
        'calibration_recovery_scope': 'Plug-in readout estimate, not a fitted model parameter; deduplicated24 calibration streams per scenario, shared by five generators.',
        'optimizer_diagnostics': {'fit_records': len(fit_rows), 'independent_fit_records': independent_fits,
                                  'retained_raw_attempts': len(attempt_rows), 'raw_attempt_failures': raw_failures,
                                  'selected_failures': selected_failures, 'maximum_success_tie_gap_total_nats': max_tie_gap},
        'score_decomposition_max_error': max_decomposition_error,
        'update_only_alias_max_log_density_error': max_update_alias_error,
        'matched_S_I_F_negative_control_pairs': len(repeated_updates),
        'shared_mechanism_aliases': SHARED_ALIASES,
        'distinct_gate_mechanism_identified': False,
        'update_only_unique_dataset_count': len(reduced_unique),
        'update_only_deduplication': 'S/I/F share observed updates and forecasts within scenario/replicate; retain S once for pooled class rates. Separate generator-row confusion denominators remain24.',
        'intervals': 'Wilson two-sided95% per24 independent replicate seeds in each scenario/generator; exploratory, not pass thresholds or human group sample-size calculations.',
        'parameter_recovery_scope': 'True-generating-family joint fits, not selected-model conditioned; associations undefined for constant truth. Reduced unidentified parameters exported separately.',
        'chance_probe_note': 'True e=.5 gives exact likelihood equivalence if evaluated at e=.5; noisy plug-in calibration can be below.5, so fitted joint S/I scores are not forced to tie.',
        'frozen_sha256': frozen['sha256'], 'validation_status_sha256': sha256(ROOT / 'SIMULATION_VALIDATION_STATUS.json'),
        'fitting_packet_sha256': fit_hashes, 'evaluation_packet_sha256': evaluation_hashes,
        'interpretation_limits': [
            'Simulation recovery separates only the restricted statistical classes under the specified measurement/generation assumptions.',
            'Shared admission, ordinary shared attention and shared-memory availability are exact aliases and cannot identify a distinctive decoder or biological gate.',
            'No human observations or old deterministic gate parameters were fitted; this is not empirical confirmation or literal transfer of the prior Stroop/bandit operation.',
            'No probe reactivity, correlated/bias/rounded ratings or load-dependent readout violations are simulated.',
            'Twenty-four replicates per cell give exploratory recovery rates; the screen is not a human participant sample-size calculation.',
            'Bounded successful optimization and finite numerical checks do not establish unique/global optima or general identifiability.'
        ]}
    verify_hashes(frozen['sha256'])
    verify_hashes(status['sha256'])
    write_json(out / 'RESULTS.json', results)
    print(json.dumps({k: results[k] for k in ('status', 'synthetic_datasets', 'primary_S_vs_I_passed',
                                           'primary_IF_robustness_passed', 'limited_candidate_design_passed')}))


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--preflight', action='store_true')
    args = parser.parse_args()
    if args.preflight:
        result = arithmetic_preflight()
        write_json(ROOT / 'ANALYSIS_PREFLIGHT.json', result)
        print(json.dumps(result))
    else:
        aggregate()
