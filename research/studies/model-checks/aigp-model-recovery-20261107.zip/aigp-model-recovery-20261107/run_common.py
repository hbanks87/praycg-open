"""Input and immutable-analysis checks shared by the simulation drivers."""
from pathlib import Path
import hashlib,json
import numpy as np
ROOT=Path(__file__).resolve().parent
MODELS=['S','I','C','IF','F','E']
REGIMES=['joint','update_only']
NAMES={m:['p_low','p_high','alpha','sigma'] for m in ['S','I','C']}
NAMES['IF']=['p_low','p_high','alpha','sigma','p_report_low','p_report_high']
NAMES['F']=NAMES['S']+['rho'];NAMES['E']=NAMES['S']+['wrong_sign']
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify_freeze():
    freeze=json.loads((ROOT/'FROZEN_MANIFEST.json').read_text())
    for rel,digest in freeze['sha256'].items():assert sha(ROOT/rel)==digest,rel
    return sha(ROOT/'FROZEN_MANIFEST.json')
def update_fingerprint(data):
    h=hashlib.sha256()
    for key in ['load','factor','update','ehat','calibration_noise']:
        value=np.ascontiguousarray(data[key]);h.update(key.encode());h.update(value.dtype.str.encode())
        h.update(str(value.shape).encode());h.update(value.tobytes())
    return h.hexdigest()
def load_training(path):
    allowed={'load','factor','update','probe','ehat','calibration_noise','calibration_errors'}
    with np.load(path,allow_pickle=False) as z:
        assert set(z.files)==allowed,(path,z.files)
        d={k:z[k].copy() for k in z.files}
    d['load']=np.ascontiguousarray(d['load'],dtype=np.int32)
    d['probe']=np.ascontiguousarray(d['probe'],dtype=np.int32)
    for k in ['factor','update','calibration_noise']:d[k]=np.ascontiguousarray(d[k],dtype=np.float64)
    d['ehat']=float(d['ehat'])
    assert d['calibration_errors'].shape==(80,) and np.isin(d['calibration_errors'],[0,1]).all()
    assert d['calibration_noise'].shape==(32,)
    expected=float(np.clip((d['calibration_errors'].sum()+.5)/81,.005,.5))
    assert d['ehat']==expected
    assert len(d['load'])==len(d['factor'])==len(d['update'])==len(d['probe'])
    assert np.isin(d['load'],[0,1]).all() and np.isin(d['probe'],[-1,0,1]).all()
    assert all(np.isfinite(d[k]).all() for k in ['factor','update','calibration_noise'])
    return d
def model_data(data,regime):
    d={k:v for k,v in data.items() if k in ['load','factor','update','probe','ehat','calibration_noise']}
    if regime=='update_only':d=d|{'probe':np.full(len(d['probe']),-1,dtype=np.int32)}
    return d
