"""Bind the newly rerun public diagnostics, without impersonating the historical freeze."""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
a=json.loads((ROOT/'MODEL_VALIDATION.json').read_text());b=json.loads((ROOT/'OPTIMIZER_PREFLIGHT.json').read_text())
assert a['status'].startswith('passed') and b['status']=='passed'
for key in b['checks']: assert b['checks'][key] is True
record={'status':'passed','scope':'Public reproduction preflight; not the historical prospective record',
  'checks':{'MODEL_VALIDATION.json':a['status'],'OPTIMIZER_PREFLIGHT.json':b['status']},
  'sha256':{n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ('MODEL_VALIDATION.json','OPTIMIZER_PREFLIGHT.json')}}
(ROOT/'PREFIT_STATUS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
