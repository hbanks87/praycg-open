"""Bind all generation/fit evidence before opening held-out scores."""
import json,datetime
from run_common import ROOT,sha,verify_freeze
def main():
    freeze=verify_freeze();assert not (ROOT/'SIMULATION_VALIDATION_STATUS.json').exists()
    review=json.loads((ROOT/'POSTFIT_REVIEW.json').read_text())
    assert review['status'].startswith('passed')
    generation=json.loads((ROOT/'PRODUCTION_GENERATION.json').read_text())
    assert generation['cases']==840 and generation['frozen_manifest_sha256']==freeze
    hashes={};ids=None;unique=set();fit_records=0
    for name in ['TRAINING_MANIFEST.json','TEST_MANIFEST.json','TRUTH_MANIFEST.json']:
        entries=json.loads((ROOT/name).read_text());assert len(entries)==840
        present={z['id'] for z in entries};assert len(present)==840
        if ids is None:ids=present
        else:assert ids==present
        assert generation['manifests_sha256'][name]==sha(ROOT/name)
        hashes[name]=sha(ROOT/name)
        for entry in entries:
            assert sha(ROOT/entry['input'])==entry['sha256'],entry['input']
            hashes[entry['input']]=entry['sha256']
    for identity in sorted(ids):
        path=ROOT/'fitting'/(identity+'.json');record=json.loads(path.read_text())
        assert record['id']==identity and record['frozen_manifest_sha256']==freeze
        for regime in record['regimes'].values():
            assert len(regime)==6
            for fit in regime.values():
                assert fit['success'];unique.add(fit['unique_fit_id']);fit_records+=1
        hashes[path.relative_to(ROOT).as_posix()]=sha(path)
    for name in ['PRODUCTION_GENERATION.json','POSTFIT_REVIEW.json','MODEL_VALIDATION.json','PREFIT_STATUS.json']:
        hashes[name]=sha(ROOT/name)
    status=dict(status='passed',checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        synthetic_participant_datasets=840,regimes=2,candidate_families=6,
        fit_records=fit_records,unique_fit_ids=len(unique),selected_failures=0,
        frozen_manifest_sha256=freeze,sha256=hashes,
        scope='All source observations, generator truth records, calibration and fit packets bound before held-out export; no new fitting')
    (ROOT/'SIMULATION_VALIDATION_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    print('Simulation fits validated; all840cases bound before held-out scoring.')
if __name__=='__main__':main()
