#include <cmath>
#include <algorithm>
static constexpr double LOG2PI=1.83787706640934548356;
static double lnnormal(double y,double mu,double variance){return -.5*(LOG2PI+std::log(variance)+(y-mu)*(y-mu)/variance);}
// IDs S0 I1 C2 IF3 F4 E5. Six physical parameters maximum.
static void episode(int model,int load,double f,double d,int c,const double* th,double e,
                    int regime,double* logs,double* grad){
 double p=th[load],alpha=th[2],sigma=th[3],a=alpha*f,var=sigma*sigma;
 double pr=(model==3?th[4+load]:p);
 for(int j=0;j<6;j++)grad[j]=0;
 if(model==2){
   double mu=a*p,v=var+a*a*p*(1-p),z=d-mu;
   double up=lnnormal(d,mu,v),pc=.5+(.5-e)*p;
   double cp=(c<0?0:(c?std::log(pc):std::log1p(-pc)));
   logs[0]=up+cp;logs[1]=up;logs[2]=cp;
   double gm=z/v,gv=.5*(z*z/(v*v)-1/v);
   grad[load]=gm*a+gv*a*a*(1-2*p);
   grad[2]=gm*f*p+gv*2*alpha*f*f*p*(1-p);grad[3]=gv*2*sigma;
   if(regime==0&&c>=0)grad[load]+=(c?1/pc:-1/(1-pc))*(.5-e);
   return;
 }
 double w[4]={},dw[4][6]={},u[4]={},correct[4]={};int k=2;
 w[0]=1-p;w[1]=p;dw[0][load]=-1;dw[1][load]=1;u[1]=1;
 correct[0]=.5;correct[1]=1-e;
 if(model==1||model==3){correct[0]=correct[1]=1;}
 if(model==4){
   k=4;double rho=th[4],t=p*(1-p),dt=1-2*p;
   w[0]=(1-p)*(1-p)+rho*t;w[1]=(1-rho)*t;w[2]=w[1];w[3]=p*p+rho*t;
   dw[0][load]=-2*(1-p)+rho*dt;dw[1][load]=dw[2][load]=(1-rho)*dt;dw[3][load]=2*p+rho*dt;
   dw[0][4]=dw[3][4]=t;dw[1][4]=dw[2][4]=-t;
   u[0]=u[1]=0;u[2]=u[3]=1;
   correct[0]=correct[2]=.5;correct[1]=correct[3]=1-e;
 }
 if(model==5){
   k=3;double err=th[4];w[1]=p*(1-err);w[2]=p*err;
   dw[1][load]=1-err;dw[2][load]=err;dw[1][4]=-p;dw[2][4]=p;
   u[2]=-1;correct[2]=e;
 }
 double norm[4],maxn=-1e300;
 for(int j=0;j<k;j++){norm[j]=lnnormal(d,a*u[j],var);if(w[j]>0)maxn=std::max(maxn,norm[j]);}
 long double sumU=0,sumJ=0,sumC=0,deriv[6]={};
 for(int j=0;j<k;j++){
   long double z=std::exp((long double)norm[j]-maxn);double cp=(c<0?1:(c?correct[j]:1-correct[j]));
   if(model==1||model==3)cp=1;
   sumU+=w[j]*z;sumJ+=w[j]*z*cp;sumC+=w[j]*cp;
   double used=(regime==1?1:cp),dzAlpha=(d-a*u[j])/var*f*u[j];
   double dzSigma=-1/sigma+(d-a*u[j])*(d-a*u[j])/(sigma*var);
   for(int h=0;h<6;h++)deriv[h]+=dw[j][h]*z*used;
   deriv[2]+=w[j]*z*used*dzAlpha;deriv[3]+=w[j]*z*used*dzSigma;
 }
 logs[1]=std::log(sumU)+maxn;
 logs[0]=std::log(sumJ)+maxn;
 logs[2]=(c<0?0:std::log(sumC));
 long double denominator=(regime==1?sumU:sumJ);
 for(int h=0;h<6;h++)grad[h]=deriv[h]/denominator;
 if(model==1||model==3){
   double pc=.5+(.5-e)*pr,cp=(c<0?0:(c?std::log(pc):std::log1p(-pc)));
   logs[2]=cp;logs[0]=logs[1]+cp;
   if(regime==0&&c>=0)grad[model==3?4+load:load]+=(c?1/pc:-1/(1-pc))*(.5-e);
 }
}
extern "C" __declspec(dllexport) int recovery_eval(int model,int n,const int* loads,
 const double* factor,const double* update,const int* probe,const double* theta,double e,
 int regime,int nc,double ss,double* loss,double* gradient,double* logs){
 for(int j=0;j<6;j++)gradient[j]=0;*loss=0;
 if(model<0||model>5||e<0||e>.5||theta[3]<=0)return 1;
 for(int t=0;t<n;t++){
   double g[6],lp[3];episode(model,loads[t],factor[t],update[t],probe[t],theta,e,regime,lp,g);
   double chosen=lp[regime==1?1:0];
   if(!std::isfinite(chosen))return 2;
   *loss-=chosen;
   for(int j=0;j<6;j++)gradient[j]-=g[j];
   for(int j=0;j<3;j++)logs[3*t+j]=lp[j];
 }
 if(nc>0){
   double s=theta[3];*loss+=.5*nc*LOG2PI+nc*std::log(s)+ss/(2*s*s);
   gradient[3]+=nc/s-ss/(s*s*s);
 }
 return 0;
}
