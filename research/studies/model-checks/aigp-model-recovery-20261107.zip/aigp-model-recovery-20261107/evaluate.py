"""Fresh held-out observations; no refitting and no generator-based selection."""
import json,datetime
import numpy as np
import models
from run_common import ROOT,MODELS,sha,verify_freeze,load_training,model_data
def predict_case(fit,d):
    predictions={'joint':{},'update_only':{}}
    for m in MODELS:
        lp=models.log_components(fit['regimes']['joint'][m]['theta'],m,d)
        components=np.column_stack([lp,lp[:,0]-lp[:,1]])
        assert np.isfinite(components).all() and np.max(np.abs(components[d['probe']<0,2:]),initial=0.)<1e-10
        predictions['joint'][m]={'log_components':components.tolist()}
    update=models.log_components(fit['regimes']['update_only']['S']['theta'],'S',model_data(d,'update_only'))[:,1:2]
    for m in ['S','I','IF','F']:
        check=models.log_components(fit['regimes']['update_only'][m]['theta'],m,model_data(d,'update_only'))[:,1:2]
        assert np.max(np.abs(check-update),initial=0.)<=1e-12,'Reduced-likelihood finite-arithmetic check failed.'
        predictions['update_only'][m]={'log_components':update.tolist(),'undefined_components':['joint','probe','conditional']}
    for m in ['C','E']:
        lp=models.log_components(fit['regimes']['update_only'][m]['theta'],m,model_data(d,'update_only'))[:,1:2]
        predictions['update_only'][m]={'log_components':lp.tolist(),'undefined_components':['joint','probe','conditional']}
    return predictions
def main():
    verify_freeze();status=json.loads((ROOT/'SIMULATION_VALIDATION_STATUS.json').read_text())
    assert status['status']=='passed' and status['sha256']
    for rel,digest in status['sha256'].items():assert sha(ROOT/rel)==digest,rel
    out=ROOT/'evaluation';out.mkdir(exist_ok=False)
    training={z['id']:z for z in json.loads((ROOT/'TRAINING_MANIFEST.json').read_text())}
    tests={z['id']:z for z in json.loads((ROOT/'TEST_MANIFEST.json').read_text())}
    truths={z['id']:z for z in json.loads((ROOT/'TRUTH_MANIFEST.json').read_text())}
    assert len(training)==len(tests)==len(truths)==840 and set(training)==set(tests)==set(truths)
    for identity in sorted(training):
        tr=training[identity];te=tests[identity];truth=truths[identity]
        for record in [tr,te,truth]:assert sha(ROOT/record['input'])==record['sha256']
        fitpath=ROOT/'fitting'/(identity+'.json');fit=json.loads(fitpath.read_text())
        assert fit['id']==identity and fit['training_input_sha256']==tr['sha256']
        assert all(z['success'] for fits in fit['regimes'].values() for z in fits.values())
        train=load_training(ROOT/tr['input'])
        with np.load(ROOT/te['input'],allow_pickle=False) as z:
            assert set(z.files)=={'load','factor','update','probe'};d={k:z[k].copy() for k in z.files}
        assert len(d['load'])==te['n_test'];d['ehat']=fit['ehat'];d['calibration_noise']=train['calibration_noise']
        predictions=predict_case(fit,d)
        record=dict(id=identity,fitting_sha256=sha(fitpath),training_input_sha256=tr['sha256'],
          test_input_sha256=te['sha256'],truth_sha256=truth['sha256'],ehat=fit['ehat'],
          observed={k:np.asarray(d[k]).tolist() for k in ['load','factor','update','probe']},
          regimes=predictions,aliases=models.ALIASES,
          truth=json.loads((ROOT/truth['input']).read_text()),training_fit_metadata=fit['regimes'])
        (out/(identity+'.json')).write_text(json.dumps(record,indent=2,allow_nan=False),encoding='utf-8')
    verify_freeze();print('Fresh held-out scores exported for840cases; no fitting or truth-based selection.')
if __name__=='__main__':main()
