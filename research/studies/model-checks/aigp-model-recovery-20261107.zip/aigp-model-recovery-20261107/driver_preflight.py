"""Nonproduction pipeline checks; no planned production replicate is inspected."""
import json,time
import numpy as np
from run_common import ROOT,load_training,MODELS
from simulate import generate_pair
from fit_recovery import fit_case,loss_only
from evaluate import predict_case
import models
def main():
    start=time.perf_counter();params,cal,draws=generate_pair(1,999);cache={};records={};predictions={}
    for generator in ['S','I','F']:
        data=draws[generator]['training']|cal
        records[generator]=dict(regimes=fit_case('nonproduction_'+generator,data,cache))
        d=draws[generator]['test']|dict(ehat=cal['ehat'],calibration_noise=cal['calibration_noise'])
        predictions[generator]=predict_case(records[generator],d)
    assert all(f['success'] for p in records.values() for regime in p['regimes'].values() for f in regime.values())
    for model in MODELS:
        arrays=[np.asarray(predictions[g]['update_only'][model]['log_components']) for g in ['S','I','F']]
        assert np.array_equal(arrays[0],arrays[1]) and np.array_equal(arrays[0],arrays[2])
    for generator in records:
        arrays=[np.asarray(predictions[generator]['update_only'][m]['log_components']) for m in ['S','I','IF','F']]
        assert all(np.array_equal(arrays[0],z) for z in arrays[1:])
    fixture=ROOT/'pipeline_fixture_training.npz'
    np.savez_compressed(fixture,**(draws['S']['training']|cal));loaded=load_training(fixture)
    assert np.array_equal(loaded['update'],draws['S']['training']['update'])
    # Structural identification flags use estimated ehat, not the scenario label.
    chance=loaded|{'ehat':.5}
    chancefits=fit_case('nonproduction_chance',chance,{})
    assert chancefits['joint']['IF']['unidentified_parameters']==['p_report_low','p_report_high']
    assert chancefits['joint']['F']['unidentified_parameters']==['rho']
    # A finite extreme density must not be mistaken for a loss cap/failure.
    extreme=dict(load=np.array([0],dtype=np.int32),factor=np.array([1.]),update=np.array([-3.]),
       probe=np.array([0],dtype=np.int32),ehat=.1,calibration_noise=np.zeros(32))
    finite=loss_only([.8,.5,1.2,.04,0.],'E',extreme,'joint');assert np.isfinite(finite) and finite>0
    report=dict(status='passed',scope='Nonproduction replicate999 and hand fixtures; no production recovery scores',
       seconds=time.perf_counter()-start,
       checks=dict(all_selected_fixture_fits_successful=True,shared_generator_update_predictions_exact=True,
         reduced_candidate_update_predictions_exact=True,training_npz_schema_roundtrip=True,
         chance_readout_unidentified_flags=True,extreme_E_zero_weight_density_finite=True,
         canonical_reuse_after_1e_minus12_arithmetic_screen=True),
       shared_control_unique_fit_count=21,chance_flag_fixture_unique_fit_count=9,extreme_finite_nll=finite)
    (ROOT/'OPTIMIZER_PREFLIGHT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
