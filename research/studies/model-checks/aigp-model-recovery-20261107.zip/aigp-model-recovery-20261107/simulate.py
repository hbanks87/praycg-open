"""Bounded production generator. Truth and test records stay outside training."""
import json,datetime
import numpy as np
from run_common import ROOT,sha,verify_freeze,update_fingerprint
MASTER_SEED=2026110719
GENERATORS=['S','I','C','F','E']
SCENARIOS={
 'short_standard':dict(n_train=120,n_test=240,probe_fraction=.25,sigma=.25,e=.10),
 'long_standard':dict(n_train=360,n_test=240,probe_fraction=.25,sigma=.25,e=.10),
 'more_probes':dict(n_train=360,n_test=240,probe_fraction=.50,sigma=.25,e=.10),
 'noisy_measurement':dict(n_train=360,n_test=240,probe_fraction=.25,sigma=.50,e=.25),
 'chance_probe':dict(n_train=360,n_test=240,probe_fraction=.50,sigma=.25,e=.50),
 'weak_update':dict(n_train=360,n_test=240,probe_fraction=.25,sigma=.50,e=.10,alpha=.04),
 'near_universal':dict(n_train=360,n_test=240,probe_fraction=.50,sigma=.25,e=.10,p_low=.99,p_high=.97)}
STREAMS={'parameters':11,'calibration':12,'training':13,'test':14,'opaque_assignment':15}
def rng_for(scenario_index,replicate,name):
    return np.random.default_rng(np.random.SeedSequence([MASTER_SEED,scenario_index,replicate,STREAMS[name]]))
def parameters(scenario_index,replicate):
    name=list(SCENARIOS)[scenario_index];spec=SCENARIOS[name];rng=rng_for(scenario_index,replicate,'parameters')
    jitter=.03 if name=='near_universal' else .15
    base=np.array([spec.get('p_low',.85),spec.get('p_high',.50)])
    p=1/(1+np.exp(-(np.log(base/(1-base))+rng.normal(0,jitter,2))))
    p=np.clip(p,.006,.994)
    alpha=float(np.clip(spec.get('alpha',.50)*np.exp(rng.normal(0,.15)),.021,1.19))
    sigma=float(np.clip(spec['sigma']*np.exp(rng.normal(0,.08)),.041,.99))
    e=.5 if name=='chance_probe' else float(np.clip(spec['e']+rng.normal(0,.015),.006,.494))
    return dict(p_low=float(p[0]),p_high=float(p[1]),alpha=alpha,sigma=sigma,e=e)
def calibration(scenario_index,replicate,params):
    rng=rng_for(scenario_index,replicate,'calibration')
    errors=(rng.random(80)<params['e']).astype(np.int32)
    ehat=float(np.clip((errors.sum()+.5)/81,.005,.5))
    return dict(calibration_errors=errors,ehat=ehat,calibration_noise=rng.normal(0,params['sigma'],32))
def design_draws(scenario_index,replicate,phase,n,probe_fraction):
    rng=rng_for(scenario_index,replicate,phase)
    assert n%4==0
    factor_low=float(np.log(.65/.35)/np.log(.9/.1))
    cells=np.tile(np.arange(4),n//4);rng.shuffle(cells)
    load=(cells//2).astype(np.int32);factor=np.where(cells%2==0,1.,factor_low)
    mask=np.zeros(n,dtype=bool);mask[rng.permutation(n)[:int(round(probe_fraction*n))]]=True
    return dict(load=load,factor=factor,probed=mask,u=rng.random(n),report=rng.random(n),
      couple=rng.random(n),wrong=rng.random(n),probe_noise=rng.random(n),noise=rng.normal(size=n))
def observed(generator,params,draw):
    p=np.where(draw['load']==0,params['p_low'],params['p_high']);u=draw['u']<p
    a=params['alpha']*draw['factor'];sigma=params['sigma'];e=params['e']
    independent=draw['report']<p
    if generator=='S':report=u
    elif generator in ['I','C']:report=independent
    elif generator=='F':report=np.where(draw['couple']<.45,u,independent)
    elif generator=='E':report=u
    else:raise ValueError(generator)
    wrong=(draw['wrong']<.15)&u if generator=='E' else np.zeros(len(p),dtype=bool)
    if generator=='C':update=a*p+np.sqrt(sigma*sigma+a*a*p*(1-p))*draw['noise']
    else:update=a*u*(1-2*wrong.astype(int))+sigma*draw['noise']
    if generator=='E':correct=np.where(u,np.where(wrong,e,1-e),.5)
    else:correct=np.where(report,1-e,.5)
    probe=np.where(draw['probed'],(draw['probe_noise']<correct).astype(np.int32),-1).astype(np.int32)
    return dict(load=draw['load'].copy(),factor=draw['factor'].copy(),update=update,probe=probe)
def generate_pair(scenario_index,replicate):
    name=list(SCENARIOS)[scenario_index];spec=SCENARIOS[name];params=parameters(scenario_index,replicate)
    cal=calibration(scenario_index,replicate,params)
    phases={phase:design_draws(scenario_index,replicate,phase,spec['n_train' if phase=='training' else 'n_test'],spec['probe_fraction']) for phase in ['training','test']}
    data={g:{phase:observed(g,params,draw) for phase,draw in phases.items()} for g in GENERATORS}
    for phase in phases:
        assert np.array_equal(data['S'][phase]['update'],data['I'][phase]['update'])
        assert np.array_equal(data['S'][phase]['update'],data['F'][phase]['update'])
        if name=='chance_probe':
            assert np.array_equal(data['S'][phase]['probe'],data['I'][phase]['probe'])
            assert np.array_equal(data['S'][phase]['probe'],data['F'][phase]['probe'])
    return params,cal,data
def main():
    freeze_sha=verify_freeze()
    for name in ['training_inputs','test_inputs','truth','fitting','evaluation']:
        assert not (ROOT/name).exists(),f'Preserve existing production evidence: {name}'
    for name in ['training_inputs','test_inputs','truth']:(ROOT/name).mkdir()
    specs=[(si,rep,g) for si in range(len(SCENARIOS)) for rep in range(24) for g in GENERATORS]
    order=np.random.default_rng(np.random.SeedSequence([MASTER_SEED,STREAMS['opaque_assignment']])).permutation(len(specs))
    identities={specs[int(k)]:f'case_{i+1:04d}' for i,k in enumerate(order)}
    train_manifest=[];test_manifest=[];truth_manifest=[]
    for si,name in enumerate(SCENARIOS):
        spec=SCENARIOS[name]
        for rep in range(24):
            params,cal,data=generate_pair(si,rep)
            for generator in GENERATORS:
                identity=identities[(si,rep,generator)]
                train=ROOT/'training_inputs'/(identity+'.npz');test=ROOT/'test_inputs'/(identity+'.npz')
                np.savez_compressed(train,**data[generator]['training'],**cal)
                np.savez_compressed(test,**data[generator]['test'])
                fp=update_fingerprint(data[generator]['training']|cal)
                train_manifest.append(dict(id=identity,input=train.relative_to(ROOT).as_posix(),sha256=sha(train),n_train=spec['n_train'],update_fingerprint=fp))
                test_manifest.append(dict(id=identity,input=test.relative_to(ROOT).as_posix(),sha256=sha(test),n_test=spec['n_test']))
                truth=dict(id=identity,scenario=name,generator=generator,replicate=rep,
                  true_parameters=params|dict(rho=.45 if generator=='F' else None,w=.15 if generator=='E' else None,wrong_sign=.15 if generator=='E' else None),
                  n_train=spec['n_train'],n_test=spec['n_test'],probe_fraction=spec['probe_fraction'],pair_id=f'{name}:{rep:02d}')
                tp=ROOT/'truth'/(identity+'.json');tp.write_text(json.dumps(truth,indent=2,allow_nan=False),encoding='utf-8')
                truth_manifest.append(dict(id=identity,input=tp.relative_to(ROOT).as_posix(),sha256=sha(tp)))
    for name,records in [('TRAINING_MANIFEST.json',train_manifest),('TEST_MANIFEST.json',test_manifest),('TRUTH_MANIFEST.json',truth_manifest)]:
        (ROOT/name).write_text(json.dumps(sorted(records,key=lambda d:d['id']),indent=2),encoding='utf-8')
    record=dict(status='generated',cases=len(specs),master_seed=MASTER_SEED,streams=STREAMS,
      generated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_manifest_sha256=freeze_sha,
      manifests_sha256={n:sha(ROOT/n) for n in ['TRAINING_MANIFEST.json','TEST_MANIFEST.json','TRUTH_MANIFEST.json']},
      update_only_shared_data_check=True,chance_probe_shared_data_check=True,
      scope='Synthetic reset episodes only; no empirical measurement or recovery outcome claim.')
    (ROOT/'PRODUCTION_GENERATION.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    verify_freeze();print('Generated 840 opaque training/test/truth cases with separated manifests.')
if __name__=='__main__':main()
