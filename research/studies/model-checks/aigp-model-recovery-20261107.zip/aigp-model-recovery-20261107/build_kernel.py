"""Build the unchanged Windows native likelihood source. No binary is downloaded."""
from pathlib import Path
import argparse,os,subprocess,json,hashlib
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--compiler',default='g++');args=parser.parse_args()
if os.name!='nt':raise SystemExit('The historical loader/export ABI is Windows-only. No Linux/macOS qualification is claimed.')
target=ROOT/'runtime/recovery_models.dll';target.parent.mkdir(exist_ok=True)
if target.exists():raise SystemExit('Refusing to replace an existing kernel; use a fresh extraction.')
env=os.environ.copy();compiler=Path(args.compiler)
if compiler.parent!=Path('.'):env['PATH']=str(compiler.resolve().parent)+os.pathsep+env.get('PATH','')
flags=['-std=c++17','-O2','-shared','-static-libgcc','-static-libstdc++']
subprocess.run([str(compiler),*flags,str(ROOT/'models.cpp'),'-o',str(target)],check=True,env=env)
version=subprocess.check_output([str(compiler),'--version'],env=env,text=True).splitlines()[0]
record={'compiler':version,'flags':flags,'source_sha256':hashlib.sha256((ROOT/'models.cpp').read_bytes()).hexdigest(),
    'binary_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scope':'Local rebuild, not historical binary identity or bit reproducibility'}
(ROOT/'BUILD.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps(record))
