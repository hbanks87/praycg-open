"""Bounded stationary coherence-proxy observations with exact population ACF.

This newly authored generator is an observation-model study, not a simulator of
gratitude, neurotransmitters or EEG acquisition. Structural parameters belong
to the evaluator and must never be supplied to the measurement estimator.
"""
import numpy as np

PHASES={'calibration':10,'test':20,'preflight':99}
CHANNELS={'initial_x':0,'flip':1,'phase_angles':2,'phase_reset':3,'white':4}


def stream(config,replicate,phase,channel):
    if phase not in PHASES:raise ValueError('Unregistered phase')
    key=[int(config['seed']),PHASES[phase],int(replicate),CHANNELS[channel]]
    return np.random.default_rng(np.random.SeedSequence(key))


def case_spec(config,case):
    if isinstance(case,(int,np.integer)):return config['cases'][int(case)]
    if isinstance(case,str):return next(c for c in config['cases'] if c['name']==case)
    if isinstance(case,dict):return case
    raise TypeError('Case must be index, name or explicit specification')


def generate_material(config,replicate,phase='test'):
    """Always draw longest tables; independent segments share no disturbances."""
    shape=(int(config['segments']),max(config['lengths'])+int(config['stationary_prefix']))
    return dict(
        initial_x=np.where(stream(config,replicate,phase,'initial_x').random(shape[0])<.5,-1.,1.),
        flip=stream(config,replicate,phase,'flip').random(shape),
        phase_angles=stream(config,replicate,phase,'phase_angles').uniform(0.,2*np.pi,size=shape),
        phase_reset=stream(config,replicate,phase,'phase_reset').random(shape),
        white=np.where(stream(config,replicate,phase,'white').random(shape)<.5,-1.,1.))


def telegraph(material,tau,dt):
    """Stationary +/-1 Markov chain: Corr(X_t,X_t+h)=exp(-h*dt/tau)."""
    if tau is None:return np.zeros_like(material['flip'])
    if not tau>0:raise ValueError('Positive decay time required')
    flip_probability=(1-np.exp(-float(dt)/float(tau)))/2
    factors=np.where(material['flip']<flip_probability,-1.,1.)
    factors[:,0]=1.
    return material['initial_x'][:,None]*np.cumprod(factors,axis=1)


def reset_oscillator(material,tau_osc,frequency,dt):
    """Uniform stationary phase, deterministic rotation between uniform resets."""
    if tau_osc is not None and not tau_osc>0:raise ValueError('Positive oscillator decay or null=infinity')
    probability=0. if tau_osc is None else 1-np.exp(-float(dt)/float(tau_osc))
    count=material['phase_angles'].shape[1];time=np.arange(count)[None,:]
    reset=material['phase_reset']<probability
    reset[:,0]=True
    last_reset=np.maximum.accumulate(np.where(reset,time,0),axis=1)
    starting_phase=np.take_along_axis(material['phase_angles'],last_reset,axis=1)
    phase=starting_phase+2*np.pi*float(frequency)*float(dt)*(time-last_reset)
    return np.sqrt(2.)*np.cos(phase)


def causal_mean(values,window):
    """Trailing means; early partial means are discarded before observation."""
    if window<1 or int(window)!=window:raise ValueError('Positive integer window required')
    if window==1:return np.asarray(values,float).copy()
    cumulative=np.concatenate([np.zeros((values.shape[0],1)),np.cumsum(values,axis=1)],axis=1)
    ends=np.arange(1,values.shape[1]+1);starts=np.maximum(0,ends-window)
    return (cumulative[:,ends]-cumulative[:,starts])/(ends-starts)[None,:]


def generate(config,case,replicate,length,phase='test'):
    spec=case_spec(config,case)
    if length not in config['lengths']:raise ValueError('Unregistered sample length')
    if spec['window']-1>config['stationary_prefix']:raise ValueError('Insufficient stationary prefix')
    if any(spec[k]<0 for k in ('a','b','e')):raise ValueError('Nonnegative mixture weights required')
    material=generate_material(config,replicate,phase)
    x=telegraph(material,spec['tau'],config['dt'])
    oscillation=reset_oscillator(material,spec['tau_osc'],spec['actual_frequency'],config['dt'])
    bound=spec['a']+np.sqrt(2.)*spec['b']+spec['e']
    if bound<=0:raise ValueError('No observation signal')
    raw=config['observation_center']+config['observation_half_range']*(spec['a']*x+spec['b']*oscillation+spec['e']*material['white'])/bound
    smoothed=causal_mean(raw,spec['window'])
    start=config['stationary_prefix']
    observed=smoothed[:,start:start+length].copy()
    if not np.isfinite(observed).all():raise ValueError('Nonfinite observation')
    lower=config['observation_center']-config['observation_half_range']
    upper=config['observation_center']+config['observation_half_range']
    if observed.min()<lower-1e-12 or observed.max()>upper+1e-12:raise ValueError('Bounded proxy violated')
    metadata=dict(case=spec['name'],replicate=int(replicate),phase=phase,length=int(length),
        segments=int(config['segments']),segment_ids=list(range(config['segments'])),dt=config['dt'],
        parameters=spec,stationary_prefix=start,material_length=material['white'].shape[1],
        rng_key_scheme='SeedSequence([root,phase,replicate,channel]); independent matrix rows are segments.',
        phase_code=PHASES[phase],observed_bounds=[lower,upper],
        observation_note='Bounded stationary coherence proxy; no raw EEG, neurochemical or gratitude process is modeled.')
    return dict(observed=observed,metadata=metadata)


def population_raw_covariance(config,spec,lags):
    """Covariance before MA, in actual bounded observation units."""
    spec=case_spec(config,spec);h=np.asarray(lags,float);absolute=np.abs(h)*config['dt']
    signal=np.zeros_like(h) if spec['a']==0 else spec['a']**2*np.exp(-absolute/spec['tau'])
    envelope=np.ones_like(h) if spec['tau_osc'] is None else np.exp(-absolute/spec['tau_osc'])
    oscillation=spec['b']**2*envelope*np.cos(2*np.pi*spec['actual_frequency']*h*config['dt'])
    white=spec['e']**2*(h==0)
    bound=spec['a']+np.sqrt(2.)*spec['b']+spec['e']
    if bound<=0:raise ValueError('No observation signal')
    return (config['observation_half_range']/bound)**2*(signal+oscillation+white)


def observed_covariance(config,spec,lags):
    """Exact trailing-window covariance, including cross-window overlap."""
    spec=case_spec(config,spec);lags=np.asarray(lags,float);window=int(spec['window'])
    offsets=np.arange(window);shift=offsets[:,None]-offsets[None,:]
    expanded=lags[...,None,None]+shift
    return population_raw_covariance(config,spec,expanded).mean(axis=(-1,-2))


def population_acf(config,spec,max_lag=None):
    max_lag=config['acf_max_lag'] if max_lag is None else int(max_lag)
    covariance=observed_covariance(config,spec,np.arange(max_lag+1))
    if not np.isfinite(covariance).all() or covariance[0]<=1e-14:
        raise ValueError('Population ACF is undefined for constant/degenerate observations')
    return covariance/covariance[0]


def segment_bootstrap_weights(config,replicate,length,phase='test'):
    """Ordinary bootstrap over independent segments, never time points."""
    if phase not in PHASES:raise ValueError('Unregistered phase')
    key=[int(config['bootstrap_seed']),PHASES[phase],int(replicate),int(length)]
    rng=np.random.default_rng(np.random.SeedSequence(key));n=config['segments']
    weights=rng.multinomial(n,np.full(n,1/n),size=config['bootstrap_replicates'])
    return weights,key


def cells_for_phase(config,phase):
    if phase=='calibration':
        return [(i,config['calibration_length']) for i,spec in enumerate(config['cases']) if spec['name'] in config['calibration_cases']]
    if phase=='test':return [(i,length) for i in range(len(config['cases'])) for length in config['lengths']]
    raise ValueError('Runner phase must be calibration or test')
