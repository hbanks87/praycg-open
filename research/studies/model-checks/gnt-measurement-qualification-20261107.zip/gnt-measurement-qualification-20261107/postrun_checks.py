"""Independent postrun reconstruction; never modifies frozen study inputs."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
from collections import defaultdict
import csv,hashlib,json,math,time
import numpy as np
from scipy.stats import t
import estimators as e
import generator as g
from independent_checks import independent_covariance,independent_observations

ROOT=Path(__file__).resolve().parent
CONFIG=json.loads((ROOT/'protocol_config.json').read_text())
METHODS=('original_signed','initial_positive_prefix','half_life','latent_decay')
CHECK_COUNT=0

def check(label,condition):
    global CHECK_COUNT
    if not bool(condition):raise AssertionError(label)
    CHECK_COUNT+=1

def close(label,actual,expected,atol=1e-9,rtol=1e-9):
    check(label,np.allclose(actual,expected,atol=atol,rtol=rtol,equal_nan=True))

def recursive(label,a,b):
    if isinstance(b,dict):
        check(label+' keys',set(a)==set(b))
        for key in b:recursive(label+'.'+key,a[key],b[key])
    elif isinstance(b,(list,tuple)):
        check(label+' length',len(a)==len(b))
        for index,(x,y) in enumerate(zip(a,b)):recursive(label+'['+str(index)+']',x,y)
    elif b is None or isinstance(b,(str,bool)):
        check(label,a==b)
    else:close(label,a,b)

def finite(x):return x is not None and bool(np.isfinite(x))

def independent_functionals(acf):
    if not np.all(np.isfinite(acf)):return [None,None,None],False,False
    signed=sum((float(a)+float(b))/2 for a,b in zip(acf[:-1],acf[1:]))
    positive=0.;capped=True
    for i in range(1,len(acf)):
        if acf[i]<=0:
            fraction=float(acf[i-1]/(acf[i-1]-acf[i]))
            positive+=float(acf[i-1])*fraction/2;capped=False;break
        positive+=(float(acf[i-1])+float(acf[i]))/2
    half=None
    for i in range(1,len(acf)):
        if acf[i]<=.5:
            half=i-1+float((acf[i-1]-.5)/(acf[i-1]-acf[i]));break
    return [signed,positive,half],capped,half is None

def independent_stats_and_acfs(observations,weights):
    stats=np.empty((16,31,6));acfs=np.empty((len(weights),31))
    for lag in range(31):
        x=observations[:,:observations.shape[1]-lag];y=observations[:,lag:]
        stats[:,lag,:]=np.column_stack([np.full(16,x.shape[1]),np.sum(x,axis=1),np.sum(y,axis=1),
            np.einsum('ij,ij->i',x,x),np.einsum('ij,ij->i',y,y),np.einsum('ij,ij->i',x,y)])
        pooled=weights@stats[:,lag,:]
        n=pooled[:,0];mx=pooled[:,1]/n;my=pooled[:,2]/n
        vx=pooled[:,3]/n-mx*mx;vy=pooled[:,4]/n-my*my
        covariance=pooled[:,5]/n-mx*my
        valid=(vx*n>1e-12)&(vy*n>1e-12)
        acfs[:,lag]=np.nan
        acfs[valid,lag]=np.clip(covariance[valid]/np.sqrt(vx[valid]*vy[valid]),-1,1)
    return stats,acfs

def independent_interval(name,point,boot,reason):
    valid=np.isfinite(boot);positive=valid&(boot>0);minimum=160
    raw=np.quantile(boot[valid],[.025,.975]).tolist() if finite(point) and valid.sum()>=minimum else None
    logci=np.quantile(np.log(boot[positive]),[.025,.975]).tolist() if finite(point) and point>0 and positive.sum()>=minimum else None
    adjusted=None;logadjusted=None
    if name=='latent_decay':
        if raw is not None:adjusted=[max(.25,raw[0]/2**.0625),min(64.,raw[1]*2**.0625)]
        if logci is not None:logadjusted=[max(math.log(.25),logci[0]-.0625*math.log(2)),min(math.log(64),logci[1]+.0625*math.log(2))]
    return dict(name=name,estimate=float(point) if finite(point) else None,raw_ci95=raw,
        log_estimate=math.log(point) if finite(point) and point>0 else None,log_ci95=logci,
        resolution_adjusted_ci95=adjusted,log_resolution_adjusted_ci95=logadjusted,
        bootstrap_finite_count=int(valid.sum()),bootstrap_positive_count=int(positive.sum()),
        bootstrap_invalid_count=int((~valid).sum()),bootstrap_nonpositive_finite_count=int((valid&~positive).sum()),
        minimum_bootstrap_estimates_for_interval=minimum,abstention_reason=reason,
        log_undefined_reason=('point_not_finite' if not finite(point) else 'nonpositive_signed_endpoint' if point<=0 else None),
        raw_interval_unavailable_reason=('point_not_finite' if not finite(point) else 'insufficient_finite_bootstrap' if raw is None else None),
        log_interval_unavailable_reason=('point_not_positive_finite' if not finite(point) or point<=0 else 'insufficient_positive_bootstrap' if logci is None else None))

def rate(count,n):
    z=1.959963984540054
    roots=np.sort(np.roots([n+z*z,-2*count-z*z,count*count/n]))
    return dict(count=int(count),denominator=int(n),rate=count/n,low95=max(0.,float(roots[0])),high95=min(1.,float(roots[1])))

def mean(values):
    values=np.array([v for v in values if finite(v)],float);n=len(values)
    if n==0:return dict(mean=None,low95=None,high95=None,available=0)
    m=float(np.mean(values));half=float(t.ppf(.975,n-1)*np.sqrt(np.sum((values-m)**2)/(n-1)/n)) if n>1 else None
    return dict(mean=m,low95=m-half if half is not None else None,high95=m+half if half is not None else None,available=n)

def coverage(intervals,truth,n):
    intervals=[i for i in intervals if i is not None and len(i)==2 and all(finite(v) for v in i)]
    k=sum(i[0]<=truth<=i[1] for i in intervals) if finite(truth) else None
    return dict(availability=rate(len(intervals),n),unconditional=rate(k,n) if k is not None else None,
        conditional=rate(k,len(intervals)) if k is not None and intervals else None,
        mean_width=mean([hi-lo for lo,hi in intervals]))

def cell_summary(records,mi):
    n=len(records);f=records[0];name=METHODS[mi];truth=f['population_truth'][name]
    methods=[r['methods'][mi] for r in records];points=[m['estimate'] for m in methods]
    errors=[p-truth for p in points if finite(p) and finite(truth)]
    logtruth=math.log(truth) if finite(truth) and truth>0 else None
    return dict(phase=f['phase'],case=f['case'],length=f['length'],method=name,replicates=n,population_truth=truth,
        point_availability=rate(sum(finite(p) for p in points),n),abstention=rate(sum(not finite(p) for p in points),n),
        log_point_availability=rate(sum(finite(p) and p>0 for p in points),n),mean_estimate=mean(points),bias=mean(errors),
        mean_absolute_error=mean([abs(v) for v in errors]),rmse=float(np.sqrt(np.mean(np.array(errors)**2))) if errors else None,
        mean_absolute_relative_error=mean([abs(v)/abs(truth) for v in errors]) if finite(truth) and abs(truth)>1e-12 else mean([]),
        raw_interval=coverage([m['raw_ci95'] for m in methods],truth,n),
        adjusted_interval=coverage([m['resolution_adjusted_ci95'] if name=='latent_decay' else m['raw_ci95'] for m in methods],truth,n),
        log_bias=mean([math.log(p)-logtruth for p in points if finite(p) and p>0 and logtruth is not None]),
        log_interval=coverage([m['log_ci95'] for m in methods],logtruth,n))

POSITIVE=(('clean2','clean8'),('rhythm2','rhythm8'),('noise2','noise8'),('smooth2','smooth8'),('mixed2','mixed8'),('mixed_smooth2','mixed_smooth8'))
NULL=tuple(('clean2',x) for x in ('rhythm2','damped2','noise2','smooth2','mixed2','mixed_smooth2','wrong_reference2'))

def paired_row(before,after,bb,ba,mi):
    b=before['methods'][mi]['estimate'];a=after['methods'][mi]['estimate'];name=METHODS[mi]
    point=math.log(a/b) if finite(a) and finite(b) and a>0 and b>0 else None
    valid=np.isfinite(bb)&np.isfinite(ba)&(bb>0)&(ba>0)
    raw=None;ci=None
    if point is not None and valid.sum()>=160:
        raw=np.quantile(np.log(ba[valid]/bb[valid]),[.025,.975]).tolist()
        expansion=.125*math.log(2) if name=='latent_decay' else 0.
        ci=[raw[0]-expansion,raw[1]+expansion]
    return dict(before=before['case'],after=after['case'],length=before['length'],replicate=before['replicate'],method=name,
        point_logratio=point,raw_ci95=raw,decision_ci95=ci,valid_bootstrap_pairs=int(valid.sum()),
        interval_available=ci is not None,increase_supported=bool(ci is not None and point>=math.log(1.5) and ci[0]>0),
        change_supported=bool(ci is not None and abs(point)>=math.log(1.5) and (ci[0]>0 or ci[1]<0)))

def qualification(cells,changes):
    cells={(c['phase'],c['case'],c['length'],c['method']):c for c in cells}
    changes={(c['before'],c['after'],c['length'],c['method']):c for c in changes}
    decisions=[]
    for case in ('clean2','clean8','offgrid3_3'):
        c=cells['test',case,512,'latent_decay']
        decisions.extend([c['point_availability']['low95']>=.8,
            c['mean_absolute_relative_error']['mean'] is not None and c['mean_absolute_relative_error']['mean']<=.25,
            c['adjusted_interval']['unconditional'] is not None and c['adjusted_interval']['unconditional']['low95']>=.8])
    for before,after in (('clean2','clean8'),('smooth2','smooth8'),('mixed_smooth2','mixed_smooth8')):
        decisions.append(changes[before,after,512,'latent_decay']['increase_support']['low95']>=.8)
    for after in ('rhythm2','noise2','smooth2','mixed_smooth2'):
        c=changes['clean2',after,512,'latent_decay']
        decisions.extend([c['change_support']['high95']<=.1,c['interval_availability']['low95']>=.8])
    for case in ('pure_rhythm','pure_noise','pure_noise_smooth'):
        decisions.append(cells['test',case,512,'latent_decay']['abstention']['low95']>=.8)
    return decisions

def main():
    started=time.time();manifest_bytes=(ROOT/'FROZEN_MANIFEST.json').read_bytes();manifest=json.loads(manifest_bytes)
    fingerprint=hashlib.sha256(manifest_bytes).hexdigest()
    for name,digest in manifest['sha256'].items():check('frozen source hash '+name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest)
    expected=set()
    for phase in ('calibration','test'):
        for index,length in g.cells_for_phase(CONFIG,phase):
            for rep in range(20 if phase=='calibration' else 100):expected.add((phase,CONFIG['cases'][index]['name'],length,rep))
    paths=sorted((ROOT/'main').glob('*/*/replicate_*.json'));check('checkpoint count',len(paths)==3720)
    records={};boots={};groups=defaultdict(list);full_refits=0;point_refits=0;direct_generator_replays=0
    for number,path in enumerate(paths):
        r=json.loads(path.read_text());key=tuple(r[k] for k in ('phase','case','length','replicate'))
        check('unique expected identity '+str(key),key in expected and key not in records)
        check('frozen checkpoint provenance '+str(key),r['frozen_manifest_sha256']==fingerprint)
        spec=CONFIG['cases'][r['case_index']];check('case identity '+str(key),spec['name']==r['case'])
        check('method identity '+str(key),[m['name'] for m in r['methods']]==list(METHODS))
        npzpath=path.parent/r['arrays_file'];check('raw array hash '+str(key),hashlib.sha256(npzpath.read_bytes()).hexdigest()==r['arrays_sha256'])
        with np.load(npzpath) as loaded:z={name:loaded[name] for name in loaded.files}
        observations=z['observed_segments'];check('observed dimensions '+str(key),observations.shape==(16,r['length']))
        check('bounded finite observations '+str(key),np.isfinite(observations).all() and observations.min()>=.05-1e-12 and observations.max()<=.95+1e-12)
        weights,seedkey=g.segment_bootstrap_weights(CONFIG,r['replicate'],r['length'],r['phase'])
        check('resampling provenance '+str(key),r['bootstrap_seed_key']==seedkey)
        stat,acfs=independent_stats_and_acfs(observations,np.vstack([np.ones(16),weights]))
        close('independent sufficient statistics '+str(key),z['segment_statistics'],stat)
        close('independent point ACF '+str(key),z['point_acf'],acfs[0])
        close('independent bootstrap ACF '+str(key),z['bootstrap_acf'],acfs[1:])
        # Endpoint calculations are independent; saved ACF avoids a harmless
        # last-bit Pearson difference changing a crossing exactly at a boundary.
        point,capped,censored=independent_functionals(z['point_acf'])
        independent_boot=np.array([[np.nan if v is None else v for v in independent_functionals(acf)[0]] for acf in z['bootstrap_acf']]).T
        close('independent functional bootstraps '+str(key),z['bootstrap_estimates'][:3],independent_boot)
        fit=e.fit_latent_acfs(z['point_acf'],spec['window']);point_refits+=1
        close('point latent refit '+str(key),r['latent_fit']['profile_sse'],fit['profile_sse'][0])
        close('point raw tau refit '+str(key),r['latent_fit']['raw_tau'],fit['raw_tau'][0])
        close('point weight refit '+str(key),r['latent_fit']['postwindow_variance_weights'],fit['weights'][0])
        check('point gate refit '+str(key),r['latent_fit']['eligible']==bool(fit['eligible'][0]) and r['latent_fit']['reason_code']==int(fit['reason_code'][0]))
        point.append(float(fit['estimate'][0]) if np.isfinite(fit['estimate'][0]) else None)
        rawtau=z['bootstrap_latent_raw_tau'];bw=z['bootstrap_latent_weights'][:,0]
        codes=(bw<.1).astype(int)+2*((rawtau<=.25)|(rawtau>=64)).astype(int)+4*(z['bootstrap_latent_rmse']>.1).astype(int)+8*(z['bootstrap_latent_profile_ratio']>16).astype(int)
        codes[~np.isfinite(z['bootstrap_acf']).all(axis=1)]=16
        close('bootstrap gate reconstruction '+str(key),z['bootstrap_latent_reason_code'],codes,atol=0,rtol=0)
        close('bootstrap gated estimates '+str(key),z['bootstrap_estimates'][3],np.where(codes==0,rawtau,np.nan))
        close('bootstrap relative profile slack '+str(key),z['bootstrap_latent_profile_sse_slack_used'],np.maximum(30*z['bootstrap_latent_rmse']**2,1e-12))
        for mi,name in enumerate(METHODS):
            row=independent_interval(name,point[mi],z['bootstrap_estimates'][mi],r['methods'][mi]['abstention_reason'])
            if name=='initial_positive_prefix':row['horizon_capped']=capped
            if name=='half_life':row['right_censored']=censored
            if name=='latent_decay':row['grid_log2_step']=.125
            recursive('method reconstruction '+str(key)+name,r['methods'][mi],row)
        cov=np.array([independent_covariance(spec,k) for k in range(31)]);population=cov/cov[0]
        close('independent population ACF '+str(key),r['population_acf'],population)
        truths=independent_functionals(population)[0]+[spec['tau'] if spec['a']>0 else None]
        recursive('independent population targets '+str(key),r['population_truth'],dict(zip(METHODS,truths)))
        if r['replicate']==0:
            fresh,arrays=e.fit_dataset(observations,spec['window'],e.ESTIMATOR_DEFAULTS,weights);full_refits+=1
            recursive('complete bootstrap refit methods '+str(key),r['methods'],fresh['methods'])
            for name,values in arrays.items():close('complete bootstrap refit arrays '+str(key)+name,z[name],values)
            shape=(16,516);phase=10 if r['phase']=='calibration' else 20
            def rng(channel):return np.random.default_rng(np.random.SeedSequence([CONFIG['seed'],phase,0,channel]))
            material=dict(initial_x=np.where(rng(0).random(16)<.5,-1.,1.),flip=rng(1).random(shape),
                phase_angles=rng(2).uniform(0,2*np.pi,shape),phase_reset=rng(3).random(shape),white=np.where(rng(4).random(shape)<.5,-1.,1.))
            close('independent observed process replay '+str(key),observations,independent_observations(spec,material,r['length']))
            direct_generator_replays+=1
        records[key]=r;boots[key]=z['bootstrap_estimates'];groups[key[:3]].append(r)
        if (number+1)%300==0:print(json.dumps(dict(audited=number+1,total=len(paths),elapsed=round(time.time()-started,1))),flush=True)
    check('all checkpoint identities present',set(records)==expected)
    result=json.loads((ROOT/'RESULTS.json').read_text())
    cells=[]
    for original in result['cells']:
        group=sorted(groups[original['phase'],original['case'],original['length']],key=lambda r:r['replicate'])
        independent=cell_summary(group,METHODS.index(original['method']));recursive('cell aggregate '+str((original['phase'],original['case'],original['length'],original['method'])),original,independent)
        cells.append(independent)
    check('all cell aggregate count',len(cells)==168)
    changes=[];change_rows=[]
    for before,after in POSITIVE+NULL:
        for length in (64,512):
            for mi,name in enumerate(METHODS):
                rows=[]
                for rep in range(100):
                    kb=('test',before,length,rep);ka=('test',after,length,rep)
                    rows.append(paired_row(records[kb],records[ka],boots[kb][mi],boots[ka][mi],mi))
                change_rows.extend(rows)
                changes.append(dict(before=before,after=after,length=length,method=name,replicates=100,true_latent_change=(before,after) in POSITIVE,
                    mean_logratio=mean([r['point_logratio'] for r in rows]),interval_availability=rate(sum(r['interval_available'] for r in rows),100),
                    increase_support=rate(sum(r['increase_supported'] for r in rows),100),change_support=rate(sum(r['change_supported'] for r in rows),100)))
    recursive('all paired change summaries',result['changes'],changes)
    with (ROOT/'CHANGE_RESULTS.csv').open(newline='',encoding='utf-8') as file:csvrows=list(csv.DictReader(file))
    check('paired CSV count',len(csvrows)==10400)
    for actual,expectedrow in zip(csvrows,change_rows):
        parsed={}
        for key,value in actual.items():
            if key in ('before','after','method'):parsed[key]=value
            elif key in ('raw_ci95','decision_ci95'):parsed[key]=json.loads(value.replace("'",'"')) if value!='' and value!='None' else None
            elif key in ('interval_available','increase_supported','change_supported'):parsed[key]=value=='True'
            elif key in ('length','replicate','valid_bootstrap_pairs'):parsed[key]=int(value)
            else:parsed[key]=float(value) if value else None
        recursive('paired CSV row',parsed,expectedrow)
    decisions=qualification(cells,changes)
    check('qualification count',len(decisions)==23 and len(result['qualification']['checks'])==23)
    check('every qualification decision independently reconstructed',decisions==[c['passed'] for c in result['qualification']['checks']])
    check('overall qualification independently reconstructed',all(decisions)==result['qualification']['passed'])
    for name,digest in manifest['sha256'].items():check('frozen source unchanged after audit '+name,hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest)
    output=dict(passed=True,assertions=CHECK_COUNT,datasets=3720,point_latent_refits=point_refits,
        full_bootstrap_refit_datasets=full_refits,full_bootstrap_refit_selection='replicate 0 in each of 36 test and 6 calibration cells',
        independently_replayed_generator_datasets=direct_generator_replays,
        independently_reconstructed_endpoint_bootstrap_draws=3720*199*3,
        independently_reconstructed_method_intervals=3720*4,independently_reconstructed_cell_summaries=168,
        independently_reconstructed_paired_change_rows=10400,independently_reconstructed_qualification_checks=23,
        qualification_passed=all(decisions),qualification_checks_passed=sum(decisions),frozen_manifest_sha256=fingerprint,
        elapsed_seconds=time.time()-started,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scope='Independent arithmetic reconstruction from saved observations and draws plus frozen-implementation point refits and 42 complete bootstrap refits. Does not reoptimize every bootstrap fit independently.')
    (ROOT/'POSTRUN_CHECKS.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps(output),flush=True)

if __name__=='__main__':main()
