"""Small generated GNT fixture and exact signed-domain/smoothing counterexamples."""
from pathlib import Path
import json,argparse
import numpy as np
import generator as g
import estimators as e
ROOT=Path(__file__).resolve().parent
config=json.loads((ROOT/'protocol_config.json').read_text())
parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,default=ROOT/'generated_example');args=parser.parse_args()
out=args.out.resolve()
if out.exists():raise SystemExit('Choose a fresh output directory.')
out.mkdir(parents=True)
rows=[]
for name in ('clean2','pure_rhythm','pure_noise','pure_noise_smooth'):
    index=next(i for i,s in enumerate(config['cases']) if s['name']==name)
    bundle=g.generate(config,index,731,512,'preflight')
    np.savez_compressed(out/(name+'.npz'),observed=bundle['observed'])
    values=e.population_functionals(g.population_acf(config,name),config['dt'])
    rows.append({'case':name,'population_functionals':values})
by={row['case']:row['population_functionals'] for row in rows}
assert by['pure_rhythm']['original_signed']<0
assert np.isclose(by['pure_noise']['original_signed'],.5)
assert np.isclose(by['pure_noise_smooth']['original_signed'],2.5)
result={'status':'PASS','scope':'Generated observations and exact population functionals, not full estimator operating rates',
  'replicate':731,'phase':'preflight','seed':config['seed'],'rows':rows,
  'original_log_of_periodic_signed_integral':'undefined over real numbers; retained negative, not clipped'}
(out/'summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
