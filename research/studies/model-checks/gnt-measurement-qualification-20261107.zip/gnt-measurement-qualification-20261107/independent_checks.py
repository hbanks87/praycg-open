"""Independent pre-outcome algebra, indexing and estimator handcases.

This file does not run registered calibration/test replicates or inspect any
operating-characteristic outcomes. Simulation generator checks use a separate
reserved phase. Full checks must finish before the prospective freeze.
"""
from pathlib import Path
import copy
import hashlib
import inspect
import json
import math
import numpy as np
from scipy.optimize import minimize
import generator as g

ROOT=Path(__file__).resolve().parent
CONFIG=json.loads((ROOT/'protocol_config.json').read_text())
CHECKS=[]


def check(name,condition):
    if not bool(condition):raise AssertionError(name)
    CHECKS.append(name)


def close(name,actual,expected,atol=2e-12,rtol=2e-12):
    if not np.allclose(actual,expected,atol=atol,rtol=rtol,equal_nan=True):
        raise AssertionError(name+': '+repr(actual)+' != '+repr(expected))
    CHECKS.append(name)


def independent_material(replicate):
    shape=(CONFIG['segments'],max(CONFIG['lengths'])+CONFIG['stationary_prefix'])
    def rng(channel):return np.random.default_rng(np.random.SeedSequence([CONFIG['seed'],99,replicate,channel]))
    return dict(initial_x=np.where(rng(0).random(shape[0])<.5,-1.,1.),
        flip=rng(1).random(shape),phase_angles=rng(2).uniform(0.,2*np.pi,size=shape),
        phase_reset=rng(3).random(shape),white=np.where(rng(4).random(shape)<.5,-1.,1.))


def independent_observations(spec,material,length):
    shape=material['flip'].shape
    x=np.zeros(shape);oscillator=np.zeros(shape)
    x[:,0]=material['initial_x'] if spec['tau'] is not None else 0.
    phi=material['phase_angles'][:,0].copy()
    oscillator[:,0]=np.sqrt(2.)*np.cos(phi)
    for time in range(1,shape[1]):
        if spec['tau'] is not None:
            probability=(1-math.exp(-CONFIG['dt']/spec['tau']))/2
            x[:,time]=np.where(material['flip'][:,time]<probability,-x[:,time-1],x[:,time-1])
        reset_probability=0. if spec['tau_osc'] is None else 1-math.exp(-CONFIG['dt']/spec['tau_osc'])
        phi=np.where(material['phase_reset'][:,time]<reset_probability,
                     material['phase_angles'][:,time],phi+2*np.pi*spec['actual_frequency']*CONFIG['dt'])
        oscillator[:,time]=np.sqrt(2.)*np.cos(phi)
    bound=spec['a']+np.sqrt(2.)*spec['b']+spec['e']
    raw=CONFIG['observation_center']+CONFIG['observation_half_range']*(spec['a']*x+spec['b']*oscillator+spec['e']*material['white'])/bound
    window=spec['window'];start=CONFIG['stationary_prefix']
    out=np.empty((CONFIG['segments'],length))
    for i,time in enumerate(range(start,start+length)):
        out[:,i]=raw[:,time-window+1:time+1].mean(axis=1)
    return out


def independent_covariance(spec,lag):
    def raw(h):
        absolute=abs(h)*CONFIG['dt']
        background=spec['a']**2*math.exp(-absolute/spec['tau']) if spec['a'] else 0.
        damp=1. if spec['tau_osc'] is None else math.exp(-absolute/spec['tau_osc'])
        periodic=spec['b']**2*damp*math.cos(2*math.pi*spec['actual_frequency']*h*CONFIG['dt'])
        white=spec['e']**2 if h==0 else 0.
        scale=CONFIG['observation_half_range']/(spec['a']+math.sqrt(2)*spec['b']+spec['e'])
        return scale*scale*(background+periodic+white)
    return sum(raw(lag+i-j) for i in range(spec['window']) for j in range(spec['window']))/spec['window']**2


def generator_checks():
    expected=('clean2','clean8','rhythm2','rhythm8','damped2','noise2','noise8',
              'smooth2','smooth8','mixed2','mixed8','mixed_smooth2','mixed_smooth8',
              'pure_rhythm','pure_noise','offgrid3_3','wrong_reference2','pure_noise_smooth')
    check('registered cases',tuple(c['name'] for c in CONFIG['cases'])==expected)
    check('registered phases separate',len(set(g.PHASES.values()))==3 and g.PHASES['preflight']==99)
    check('registered cells',len(g.cells_for_phase(CONFIG,'test'))==36 and len(g.cells_for_phase(CONFIG,'calibration'))==6)
    check('calibration cells only declared',set(CONFIG['cases'][i]['name'] for i,n in g.cells_for_phase(CONFIG,'calibration'))==set(CONFIG['calibration_cases']))
    check('all calibration lengths declared',all(n==512 for i,n in g.cells_for_phase(CONFIG,'calibration')))
    material=independent_material(731)
    generated=g.generate_material(CONFIG,731,'preflight')
    for key in material:close('independent seed channel '+key,generated[key],material[key])
    draws=[g.stream(CONFIG,731,phase,'flip').random(8) for phase in ('test','calibration','preflight')]
    check('reserved phase does not reuse registered draws',all(not np.array_equal(draws[i],draws[j]) for i in range(3) for j in range(i)))
    for index,spec in enumerate(CONFIG['cases']):
        name=spec['name'];small=g.generate(CONFIG,index,731,64,'preflight');large=g.generate(CONFIG,index,731,512,'preflight')
        close(name+' longest-prefix observations',small['observed'],large['observed'][:,:64])
        check(name+' shape',large['observed'].shape==(16,512))
        check(name+' bounds',large['observed'].min()>=.05-1e-12 and large['observed'].max()<=.95+1e-12)
        close(name+' independent process reconstruction',large['observed'],independent_observations(spec,material,512),atol=3e-12)
        cov=np.array([independent_covariance(spec,k) for k in range(31)])
        close(name+' independent covariance convolution',g.observed_covariance(CONFIG,spec,np.arange(31)),cov)
        close(name+' exact population ACF',g.population_acf(CONFIG,spec),cov/cov[0])
        close(name+' symmetric covariance',g.observed_covariance(CONFIG,spec,np.arange(-30,31)),
              g.observed_covariance(CONFIG,spec,np.abs(np.arange(-30,31))))
        if spec['a']:
            rho=math.exp(-CONFIG['dt']/spec['tau']);probability=(1-rho)/2
            transition=np.array([[1-probability,probability],[probability,1-probability]])
            close(name+' stationary telegraph distribution',np.array([.5,.5])@transition,[.5,.5])
            close(name+' telegraph decay eigenvector',transition@np.array([1.,-1.]),rho*np.array([1.,-1.]))
        # Integration over four evenly spaced stationary phases is exact for
        # the second-order sinusoidal expression; resets erase phase memory.
        phases=np.arange(4)*np.pi/2
        for lag in (0,1,7,30):
            actual=np.mean(np.sqrt(2)*np.cos(phases)*np.sqrt(2)*np.cos(phases+2*np.pi*spec['actual_frequency']*lag))
            close(name+' stationary oscillator phase integral '+str(lag),actual,math.cos(2*np.pi*spec['actual_frequency']*lag))
    for name,window in [('pure_noise',1),('pure_noise_smooth',5)]:
        expected=np.maximum(window-np.arange(31),0)/window
        close(name+' triangular filtered white-noise ACF',g.population_acf(CONFIG,name),expected)
    for length in CONFIG['lengths']:
        weights,key=g.segment_bootstrap_weights(CONFIG,731,length,'preflight')
        check('bootstrap dimensions '+str(length),weights.shape==(199,16))
        close('bootstrap independent-segment totals '+str(length),weights.sum(axis=1),np.full(199,16))
        check('bootstrap nonnegative integer weights '+str(length),np.all(weights>=0) and np.all(weights==weights.astype(int)))
        check('bootstrap reserved phase '+str(length),key[1]==99)


def estimator_checks():
    import estimators as e
    import run_study as runner
    settings=runner.estimator_settings()
    check('estimator method names',e.METHODS==('original_signed','initial_positive_prefix','half_life','latent_decay'))
    check('whitelist rejects truth metadata',set(e.inference_settings(dict(case='secret',tau=999,a=2)))==set(e.ESTIMATOR_DEFAULTS))
    check('final relative profile rule',settings['profile_relative_slack']==1. and settings['profile_slack_floor']==1e-12 and 'profile_sse_slack' not in settings)
    # Directly concatenate valid lag pairs, never segment boundary pairs.
    observed=np.array([[.1,.2,.5,.3,.8,.7],[.9,.4,.3,.6,.2,.1],[.2,.8,.4,.7,.5,.3]])
    weights=np.array([[1,1,1],[2,0,1],[0,3,0]])
    stats=e.segment_statistics(observed,3)
    acfs=e.acf_from_statistics(stats,weights)
    for wi,w in enumerate(weights):
        for lag in range(4):
            x=np.concatenate([np.tile(row[:len(row)-lag],int(n)) for row,n in zip(observed,w)])
            y=np.concatenate([np.tile(row[lag:],int(n)) for row,n in zip(observed,w)])
            close('independent pooled Pearson '+str((wi,lag)),acfs[wi,lag],np.corrcoef(x,y)[0,1])
    check('constant segments report undefined ACF',np.isnan(e.acf_from_statistics(e.segment_statistics(np.ones((3,6))*.5,3),weights)).all())
    endpoint_cases=[([1,.6,.2,-.2],1.,[1.2,1.25,1.25],False,False),
                    ([1,.6,.2,-.2],2.,[2.4,2.5,2.5],False,False),
                    ([1,-1,-1],1.,[-1.,.25,.25],False,False),
                    ([1,1,1],1.,[2.,2.,None],True,True),
                    ([1,.6,0,.2],1.,[1.2,1.1,7/6],False,False)]
    for index,(acf,dt,expected,capped,censored) in enumerate(endpoint_cases):
        row=e.observed_functionals(acf,dt)
        for name,value in zip(e.METHODS,expected):
            if value is None:check('endpoint censored '+str(index),row['values'][name] is None)
            else:close('endpoint interpolation '+str((index,name)),row['values'][name],value)
        check('prefix flag '+str(index),row['initial_positive_prefix_capped']==capped)
        check('half-life flag '+str(index),row['half_life_right_censored']==censored)
    check('nonfinite endpoint input abstains',all(x is None for x in e.population_functionals([1,np.nan,0]).values()))
    for window in (1,5):
        a=np.maximum(window-np.arange(31),0)/window
        row=e.population_functionals(a)
        close('filtered white integral '+str(window),row['original_signed'],window/2)
        close('filtered white half-life '+str(window),row['half_life'],window/2)
        basis=e.model_basis(window,settings)
        close('declared tau grid '+str(window),basis['tau_grid'],2**np.linspace(-2,6,65))
        check('declared grid pairs '+str(window),len(basis['u'])==455)
        def component(decay,frequency=0.,white=False):
            cov=[]
            for lag in range(31):
                total=0.
                for i in range(window):
                    for j in range(window):
                        h=lag+i-j
                        total+=float(h==0) if white else (1. if math.isinf(decay) else math.exp(-abs(h)/decay))*math.cos(2*math.pi*frequency*h)
                cov.append(total/window**2)
            return np.array(cov)/cov[0]
        for ti in (0,16,32,48,64):close('background basis convolution '+str((window,ti)),basis['backgrounds'][ti],component(basis['tau_grid'][ti]))
        for oi,decay in enumerate(basis['oscillator_values']):close('oscillator basis convolution '+str((window,oi)),basis['oscillators'][oi],component(decay,.025))
        close('noise basis convolution '+str(window),basis['noise'],component(1,white=True))
        # Solve fixed-pair simplexes independently with a general constrained
        # optimizer, including targets whose optimum lies on each edge.
        for ti,oi in ((0,0),(16,6),(32,2),(48,3),(64,6)):
            back=basis['backgrounds'][ti];osc=basis['oscillators'][oi];noise=basis['noise']
            u=(back-noise)[1:];v=(osc-noise)[1:]
            single=dict(tau_grid=np.array([basis['tau_grid'][ti]]),oscillator_values=np.array([basis['oscillator_values'][oi]]),
                noise=noise,u=u[None,:],v=v[None,:],uu=np.array([u@u]),vv=np.array([v@v]),uv=np.array([u@v]))
            targets=[.4*back+.35*osc+.25*noise,1.4*back-.2*osc-.2*noise,
                     -.2*back+.8*osc+.4*noise,.8*back+.8*osc-.6*noise]
            for target_index,target in enumerate(targets):
                fit=e.simplex_fit_batch(target,single)
                def objective(w):return float(np.sum((w[0]*back[1:]+w[1]*osc[1:]+w[2]*noise[1:]-target[1:])**2))
                opt=minimize(objective,np.array([1/3]*3),method='SLSQP',bounds=[(0,1)]*3,
                    constraints=[dict(type='eq',fun=lambda w:w.sum()-1)],options={'ftol':1e-13,'maxiter':1000})
                label=str((window,ti,oi,target_index))
                check('independent optimizer converged '+label,opt.success)
                close('simplex optimal SSE '+label,fit['sse'][0],opt.fun,atol=2e-8,rtol=2e-8)
                close('simplex realized SSE '+label,fit['sse'][0],objective(fit['weights'][0]),atol=3e-11)
                check('simplex feasibility '+label,np.all(fit['weights']>=-1e-12) and abs(fit['weights'].sum()-1)<1e-12)
    lags=np.arange(31)
    exact=np.exp(-lags/4.)
    fit=e.fit_latent_acfs(exact,1,settings)
    check('exact identifiable exponential eligible after analytical repair',fit['eligible'][0])
    close('exact exponential tau recovery',fit['estimate'][0],4.)
    close('exact exponential profile collapses',fit['profile_ratio'][0],1.)
    close('exact fit profile numerical floor',fit['profile_sse_slack_used'][0],1e-12)
    for name,acf,window in [('pure oscillator',np.cos(2*np.pi*.025*lags),1),('pure white',np.r_[1.,np.zeros(30)],1),('averaged pure white',np.maximum(5-lags,0)/5,5)]:
        fit=e.fit_latent_acfs(acf,window,settings)
        check(name+' absent background abstains',not fit['eligible'][0] and np.isnan(fit['estimate'][0]))
        close(name+' profile retains all latent taus',fit['profile_ratio'][0],256.)
        check(name+' all-profile ambiguity reported',bool(fit['reason_code'][0]&8))
    fit=e.fit_latent_acfs(np.stack([np.exp(-lags/.25),np.exp(-lags/64),np.full(31,np.nan)]),1,settings)
    check('lower boundary rejected',bool(fit['reason_code'][0]&2))
    check('upper boundary rejected',bool(fit['reason_code'][1]&2))
    check('nonfinite ACF reason code',fit['reason_code'][2]==16)
    # A deterministic off-grid curve is an algebra check, not a test cell.
    offgrid=e.fit_latent_acfs(np.exp(-lags/3.3),1,settings)
    cutoff=offgrid['sse'][0]+max(offgrid['sse'][0],1e-12)
    admitted=offgrid['tau_grid'][offgrid['profile_sse'][0]<=cutoff]
    close('profile selection uses all tau grid points',offgrid['profile_ratio'][0],admitted.max()/admitted.min())
    # Hand-constructed bootstrap estimates isolate 80% validity and log domain.
    for valid,expected in [(159,False),(160,True)]:
        boot=np.r_[np.linspace(1,3,valid),np.full(199-valid,np.nan)]
        row=e.interval_row('original_signed',2.,boot,settings)
        check('80 percent bootstrap cutoff '+str(valid),(row['raw_ci95'] is not None)==expected and row['minimum_bootstrap_estimates_for_interval']==160)
        if expected:close('percentile endpoint preservation',row['raw_ci95'],np.quantile(boot[np.isfinite(boot)],[.025,.975]))
    row=e.interval_row('original_signed',-2.,np.r_[np.full(160,-2.),np.full(39,np.nan)],settings)
    check('negative signed endpoint retained',row['estimate']==-2. and row['raw_ci95']==[-2.,-2.])
    check('negative signed log remains undefined',row['log_estimate'] is None and row['log_ci95'] is None and row['bootstrap_nonpositive_finite_count']==160)
    row=e.interval_row('original_signed',1.,np.r_[np.ones(159),np.zeros(40)],settings)
    check('finite bootstrap is not positive bootstrap',row['raw_ci95'] is not None and row['log_ci95'] is None and row['bootstrap_positive_count']==159)
    row=e.interval_row('latent_decay',np.nan,np.ones(199),settings)
    check('invalid point prevents all intervals',all(row[k] is None for k in ('raw_ci95','log_ci95','resolution_adjusted_ci95','log_resolution_adjusted_ci95')))
    for point in (.25,4.,64.):
        row=e.interval_row('latent_decay',point,np.full(199,point),settings)
        close('latent raw grid interval '+str(point),row['raw_ci95'],[point,point])
        close('latent half-cell resolution expansion '+str(point),row['resolution_adjusted_ci95'],[max(.25,point/2**.0625),min(64,point*2**.0625)])
        close('latent log resolution expansion '+str(point),row['log_resolution_adjusted_ci95'],[max(math.log(.25),math.log(point)-.0625*math.log(2)),min(math.log(64),math.log(point)+.0625*math.log(2))])
    # End-to-end API exercise on one reserved observation, excluded from all
    # study summaries and never used for operating-characteristic tuning.
    bundle=g.generate(CONFIG,'mixed_smooth2',731,64,'preflight')
    weights,key=g.segment_bootstrap_weights(CONFIG,731,64,'preflight')
    record,arrays=e.fit_dataset(bundle['observed'],5,settings,weights)
    check('end-to-end method serialization',record['bootstrap_method_order']==list(e.METHODS) and len(json.dumps(record,allow_nan=False))>0)
    close('end-to-end point ACF reconstruction',arrays['point_acf'],e.acf_from_statistics(e.segment_statistics(bundle['observed']),np.ones(16))[0])
    check('end-to-end bootstrap dimensions',arrays['bootstrap_estimates'].shape==(4,199) and arrays['bootstrap_acf'].shape==(199,31))
    check('runner no truth at inference interface',"e.fit_dataset(bundle['observed'],spec['window'],settings,weights)" in inspect.getsource(runner.run_worker))


def evaluator_checks():
    import analyze_results as a
    import estimators as e
    for k,n in ((0,100),(50,100),(100,100),(2,3)):
        p=k/n;z=1.959963984540054
        # Wilson bounds solve n(p_hat-p)^2=z^2*p(1-p).
        roots=np.sort(np.roots([n+z*z,-(2*k+z*z),k*k/n]))
        result=a.wilson(k,n)
        close('Wilson quadratic lower '+str((k,n)),result['low95'],max(0,roots[0]))
        close('Wilson quadratic upper '+str((k,n)),result['high95'],min(1,roots[1]))
    result=a.coverage([[0,2],None,[2,3]],1.,3)
    close('coverage unconditional denominator',result['unconditional']['rate'],1/3)
    close('coverage conditional denominator',result['conditional']['rate'],1/2)
    close('interval availability denominator',result['availability']['rate'],2/3)
    result=a.coverage([[0,2],None,[2,3]],None,3)
    check('absent target has no coverage',result['unconditional'] is None and result['conditional'] is None and result['availability']['count']==2)
    def mockrecord(case,point,truth=2.,rep=0):
        return dict(phase='test',case=case,length=512,replicate=rep,
            population_truth={name:truth for name in e.METHODS},
            methods=[e.interval_row(name,point,np.full(199,point),None) for name in e.METHODS])
    before=mockrecord('clean2',2.);after=mockrecord('clean8',8.)
    for method in e.METHODS:
        row=a.change_record(before,after,np.full(199,2.),np.full(199,8.),method)
        expansion=.125*math.log(2) if method=='latent_decay' else 0.
        close('paired log point '+method,row['point_logratio'],math.log(4))
        close('paired log raw interval '+method,row['raw_ci95'],[math.log(4)]*2)
        close('paired full-cell expansion '+method,row['decision_ci95'],[math.log(4)-expansion,math.log(4)+expansion])
        check('positive change detection '+method,row['increase_supported'] and row['change_supported'])
    for valid,expected in [(159,False),(160,True)]:
        row=a.change_record(before,after,np.full(199,2.),np.r_[np.full(valid,8.),np.full(199-valid,np.nan)],'latent_decay')
        check('joint-valid bootstrap cutoff '+str(valid),row['interval_available']==expected and row['increase_supported']==expected)
    row=a.change_record(before,after,np.r_[np.full(159,2.),np.full(40,np.nan)],np.r_[np.full(40,np.nan),np.full(159,8.)],'latent_decay')
    check('paired validity uses intersection',row['valid_bootstrap_pairs']==119 and not row['interval_available'])
    row=a.change_record(before,mockrecord('clean8',np.nan),np.full(199,2.),np.full(199,8.),'latent_decay')
    check('invalid paired point cannot claim change',not row['interval_available'] and not row['change_supported'])
    row=a.change_record(before,mockrecord('clean8',2.8),np.full(199,2.),np.full(199,2.8),'latent_decay')
    check('significance alone is not meaningful increase',row['decision_ci95'][0]>0 and not row['change_supported'])
    row=a.change_record(before,mockrecord('clean8',.5),np.full(199,2.),np.full(199,.5),'latent_decay')
    check('meaningful decrease has no increase claim',row['change_supported'] and not row['increase_supported'])
    rows=[a.change_record(before,after,np.full(199,2.),np.full(199,8.),'latent_decay'),row]
    missing=dict(rows[0],interval_available=False,increase_supported=False,change_supported=False,point_logratio=None)
    summary=a.summarize_changes([rows[0],missing])
    check('power denominator includes unavailable',summary['increase_support']['count']==1 and summary['increase_support']['denominator']==2)
    recs=[mockrecord('clean2',2.),mockrecord('clean2',np.nan),mockrecord('clean2',4.)]
    summary=a.summarize_cell(recs,'latent_decay')
    check('conditional point error keeps availability separate',summary['point_availability']['count']==2 and summary['mean_absolute_error']['available']==2 and summary['mean_absolute_error']['mean']==1.)
    check('unconditional coverage retains unavailable interval',summary['adjusted_interval']['unconditional']['denominator']==3 and summary['adjusted_interval']['unconditional']['count']==1)
    signed=a.summarize_cell([mockrecord('pure_rhythm',-2.,truth=-2.)],'original_signed')
    check('negative own target retains signed coverage and omits log truth',signed['raw_interval']['unconditional']['count']==1 and signed['log_interval']['unconditional'] is None and signed['log_bias']['mean'] is None)
    absent=a.summarize_cell([mockrecord('pure_noise',np.nan,truth=None)],'latent_decay')
    check('absent target evaluates abstention',absent['abstention']['count']==1 and absent['mean_absolute_error']['available']==0 and absent['adjusted_interval']['unconditional'] is None)
    # A fully passing synthetic qualification, then make each individual
    # criterion fail while all remaining criteria stay satisfied.
    cells=[];changes=[];failure_paths=[]
    for case in ('clean2','clean8','offgrid3_3'):
        idx=len(cells)
        cells.append(dict(phase='test',case=case,length=512,method='latent_decay',point_availability=a.wilson(100,100),
            mean_absolute_relative_error=dict(mean=0.),adjusted_interval=dict(unconditional=a.wilson(100,100))))
        failure_paths.extend([('cells',idx,('point_availability','low95'),.79),('cells',idx,('mean_absolute_relative_error','mean'),.26),('cells',idx,('adjusted_interval','unconditional','low95'),.79)])
    for pair in (('clean2','clean8'),('smooth2','smooth8'),('mixed_smooth2','mixed_smooth8')):
        idx=len(changes)
        changes.append(dict(before=pair[0],after=pair[1],length=512,method='latent_decay',increase_support=a.wilson(100,100)))
        failure_paths.append(('changes',idx,('increase_support','low95'),.79))
    for aftercase in ('rhythm2','noise2','smooth2','mixed_smooth2'):
        idx=len(changes)
        changes.append(dict(before='clean2',after=aftercase,length=512,method='latent_decay',change_support=a.wilson(0,100),interval_availability=a.wilson(100,100)))
        failure_paths.extend([('changes',idx,('change_support','high95'),.11),('changes',idx,('interval_availability','low95'),.79)])
    for case in ('pure_rhythm','pure_noise','pure_noise_smooth'):
        idx=len(cells)
        cells.append(dict(phase='test',case=case,length=512,method='latent_decay',abstention=a.wilson(100,100)))
        failure_paths.append(('cells',idx,('abstention','low95'),.79))
    qualification=a.qualify(cells,changes)
    check('all 23 criteria admit fully passing handcase',qualification['passed'] and len(qualification['checks'])==23 and len(failure_paths)==23)
    failed_labels=[]
    for source,index,path,value in failure_paths:
        trial=dict(cells=copy.deepcopy(cells),changes=copy.deepcopy(changes));entry=trial[source][index]
        for part in path[:-1]:entry=entry[part]
        entry[path[-1]]=value
        result=a.qualify(trial['cells'],trial['changes'])
        fails=[c['check'] for c in result['checks'] if not c['passed']]
        check('single criterion is required '+str((source,index,path)),not result['passed'] and len(fails)==1)
        failed_labels.extend(fails)
    check('every qualification criterion independently necessary',len(set(failed_labels))==23)


def main():
    generator_checks();estimator_checks();evaluator_checks()
    sources=['generator.py','estimators.py','protocol_config.json','run_study.py','analyze_results.py',
             'PROTOCOL.txt','independent_checks.py']
    output=dict(passed=True,check_count=len(CHECKS),checks=CHECKS,
        scope='Independent generator/covariance, endpoint, simplex/grid, bootstrap/interval and evaluator handcases; no registered performance study or pilot.',
        study_outcomes_inspected=False,source_sha256={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in sources})
    (ROOT/'PREFLIGHT_CHECKS.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps(dict(passed=True,check_count=len(CHECKS),study_outcomes_inspected=False)))


if __name__=='__main__':main()
