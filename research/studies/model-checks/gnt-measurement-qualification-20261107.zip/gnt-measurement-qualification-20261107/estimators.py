"""Frozen-candidate GNT measurement estimators, without generator truth.

Observed-ACF functionals and a model-dependent latent decay time are explicitly
different estimands. A declared averaging window and reference frequency are
available to the model; true component weights and true decay times are not.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from functools import lru_cache
import math
import numpy as np

METHODS=('original_signed','initial_positive_prefix','half_life','latent_decay')
STATISTICS=('count','sx','sy','sxx','syy','sxy')
ESTIMATOR_DEFAULTS={
    'dt':1.,'max_lag':30,'bootstrap_replicates':199,
    'reference_frequency':1/40,
    'tau_log2_min':-2.,'tau_log2_max':6.,'grid_log2_step':.125,
    'oscillator_decays':[2.,4.,8.,16.,32.,64.,None],
    'background_weight_min':.10,'fit_rmse_max':.10,
    'profile_relative_slack':1.,'profile_slack_floor':1e-12,'profile_ratio_max':16.,
    'bootstrap_min_fraction':.80,'lower_quantile':.025,'upper_quantile':.975,
    'fit_tie_tolerance':1e-12,'variance_numerical_floor':1e-12,
}


def inference_settings(config=None):
    """Whitelisted numerical settings; no case labels or structural truth."""
    if config is None:return dict(ESTIMATOR_DEFAULTS)
    source=config.get('estimator',config)
    return {name:source.get(name,value) for name,value in ESTIMATOR_DEFAULTS.items()}


def segment_statistics(observed,max_lag=30):
    observed=np.asarray(observed,float)
    if observed.ndim!=2 or observed.shape[1]<=max_lag or not np.isfinite(observed).all():
        raise ValueError('Finite segment-by-time observations with length > max_lag required')
    segments,n=observed.shape
    result=np.empty((segments,max_lag+1,len(STATISTICS)),float)
    for lag in range(max_lag+1):
        x=observed[:,:n-lag];y=observed[:,lag:]
        result[:,lag,0]=n-lag
        result[:,lag,1]=x.sum(axis=1);result[:,lag,2]=y.sum(axis=1)
        result[:,lag,3]=(x*x).sum(axis=1);result[:,lag,4]=(y*y).sum(axis=1)
        result[:,lag,5]=(x*y).sum(axis=1)
    return result


def acf_from_statistics(statistics,weights,variance_floor=1e-12):
    """Pooled lagged Pearson correlations after whole-segment resampling."""
    statistics=np.asarray(statistics,float);weights=np.asarray(weights,float)
    if statistics.ndim!=3 or statistics.shape[2]!=6:raise ValueError('Statistic dimensions')
    if weights.ndim==1:weights=weights[None,:]
    if weights.ndim!=2 or weights.shape[1]!=statistics.shape[0] or np.any(weights<0) or np.any(weights.sum(axis=1)<=0):
        raise ValueError('Resampling weights')
    pooled=(weights@statistics.reshape(statistics.shape[0],-1)).reshape(weights.shape[0],statistics.shape[1],6)
    n,sx,sy,sxx,syy,sxy=np.moveaxis(pooled,-1,0)
    vx=sxx-sx*sx/n;vy=syy-sy*sy/n;cov=sxy-sx*sy/n
    valid=(vx>variance_floor)&(vy>variance_floor)
    denominator=np.sqrt(np.maximum(vx,0)*np.maximum(vy,0))
    result=np.full(vx.shape,np.nan)
    np.divide(cov,denominator,out=result,where=valid)
    return np.where(valid,np.clip(result,-1.,1.),np.nan)


def observed_functionals(acf,dt=1.):
    """Three separate finite-grid ACF functionals with declared interpolation."""
    acf=np.asarray(acf,float)
    if acf.ndim!=1 or len(acf)<2:raise ValueError('One-dimensional ACF required')
    if not np.isfinite(acf).all():
        return dict(values={name:None for name in METHODS[:3]},initial_positive_prefix_capped=None,
                    half_life_right_censored=None,reason='nonfinite_acf')
    signed=float(np.trapezoid(acf,dx=dt))
    zero=np.flatnonzero(acf[1:]<=0.)
    if len(zero):
        j=int(zero[0]+1);fraction=float(acf[j-1]/(acf[j-1]-acf[j]))
        positive=float(np.trapezoid(acf[:j],dx=dt)+.5*acf[j-1]*fraction*dt)
        capped=False
    else:positive=signed;capped=True
    half=np.flatnonzero(acf[1:]<=.5)
    if len(half):
        j=int(half[0]+1);fraction=float((acf[j-1]-.5)/(acf[j-1]-acf[j]))
        lifetime=float((j-1+fraction)*dt);censored=False
    else:lifetime=None;censored=True
    return dict(values=dict(original_signed=signed,initial_positive_prefix=positive,half_life=lifetime),
                initial_positive_prefix_capped=capped,half_life_right_censored=censored,reason=None)


def population_functionals(acf,dt=1.):
    return observed_functionals(acf,dt)['values']


def functional_batch(acfs,dt=1.):
    acfs=np.asarray(acfs,float)
    if acfs.ndim==1:acfs=acfs[None,:]
    result=np.full((3,len(acfs)),np.nan);prefix_capped=np.zeros(len(acfs),bool);half_censored=np.zeros(len(acfs),bool)
    for i,acf in enumerate(acfs):
        row=observed_functionals(acf,dt)
        for j,name in enumerate(METHODS[:3]):
            if row['values'][name] is not None:result[j,i]=row['values'][name]
        prefix_capped[i]=row['initial_positive_prefix_capped'] is True
        half_censored[i]=row['half_life_right_censored'] is True
    return result,prefix_capped,half_censored


def _filtered_component(lags,window,decay,frequency=0.,white=False,dt=1.):
    h=np.asarray(lags,float)[:,None,None]+np.arange(window)[None,:,None]-np.arange(window)[None,None,:]
    if white:covariance=(h==0.).astype(float)
    else:
        envelope=np.ones_like(h) if math.isinf(decay) else np.exp(-np.abs(h)*dt/decay)
        covariance=envelope*np.cos(2*np.pi*frequency*h*dt)
    return covariance.mean(axis=(1,2))


@lru_cache(maxsize=32)
def _cached_basis(window,dt,max_lag,frequency,tau_min,tau_max,tau_step,oscillator_decays):
    if not isinstance(window,int) or window<1:raise ValueError('Window must be a positive integer')
    tau_grid=2.**np.arange(tau_min,tau_max+.25*tau_step,tau_step)
    lags=np.arange(max_lag+1)
    backgrounds=[]
    for tau in tau_grid:
        covariance=_filtered_component(lags,window,tau,dt=dt)
        backgrounds.append(covariance/covariance[0])
    noise_covariance=_filtered_component(lags,window,1.,white=True,dt=dt)
    noise=noise_covariance/noise_covariance[0]
    oscillators=[];oscillator_values=[]
    for value in oscillator_decays:
        covariance=_filtered_component(lags,window,value,frequency=frequency,dt=dt)
        # An averaging window may annihilate an undamped exact-period component.
        # Such a zero-variance component cannot have a normalized observed ACF.
        if covariance[0]>1e-12:
            oscillators.append(covariance/covariance[0]);oscillator_values.append(value)
    if not oscillators:raise ValueError('No observable oscillatory component in model grid')
    backgrounds=np.asarray(backgrounds);oscillators=np.asarray(oscillators)
    ti=np.repeat(np.arange(len(tau_grid)),len(oscillators));oi=np.tile(np.arange(len(oscillators)),len(tau_grid))
    background=backgrounds[ti,1:];oscillator=oscillators[oi,1:];base=noise[1:]
    u=background-base;v=oscillator-base
    uu=np.sum(u*u,axis=1);vv=np.sum(v*v,axis=1);uv=np.sum(u*v,axis=1)
    return dict(tau_grid=tau_grid,tau_index=ti,oscillator_index=oi,
        oscillator_values=np.asarray(oscillator_values),backgrounds=backgrounds,oscillators=oscillators,
        noise=noise,u=u,v=v,uu=uu,vv=vv,uv=uv)


def model_basis(window,config=None):
    settings=inference_settings(config)
    oscillator_decays=tuple(np.inf if value is None else float(value) for value in settings['oscillator_decays'])
    return _cached_basis(int(window),float(settings['dt']),int(settings['max_lag']),float(settings['reference_frequency']),
        float(settings['tau_log2_min']),float(settings['tau_log2_max']),float(settings['grid_log2_step']),oscillator_decays)


def simplex_fit_batch(acfs,basis,tie_tolerance=1e-12):
    """Exact constrained two-variable least squares over each three-way simplex.

    For every background/oscillator grid pair, enumerate the unconstrained
    interior and all three boundary edges. Edge clipping includes all vertices.
    """
    acfs=np.asarray(acfs,float)
    if acfs.ndim==1:acfs=acfs[None,:]
    difference=acfs[:,1:]-basis['noise'][None,1:]
    alpha=difference@basis['u'].T;beta=difference@basis['v'].T
    dd=np.sum(difference*difference,axis=1)[:,None]
    uu=basis['uu'][None,:];vv=basis['vv'][None,:];uv=basis['uv'][None,:]
    determinant=uu*vv-uv*uv
    safe=determinant>1e-14
    a=np.divide(alpha*vv-beta*uv,determinant,out=np.zeros_like(alpha),where=safe)
    b=np.divide(beta*uu-alpha*uv,determinant,out=np.zeros_like(beta),where=safe)
    inside=safe&(a>=0.)&(b>=0.)&(a+b<=1.)
    def sse(x,y):
        return np.maximum(dd-2*x*alpha-2*y*beta+x*x*uu+y*y*vv+2*x*y*uv,0.)
    best_sse=np.where(inside,sse(a,b),np.inf);best_a=a.copy();best_b=b.copy()
    edge_a=np.clip(np.divide(alpha,uu,out=np.zeros_like(alpha),where=uu>1e-14),0.,1.)
    edge_b=np.clip(np.divide(beta,vv,out=np.zeros_like(beta),where=vv>1e-14),0.,1.)
    edge_denominator=uu+vv-2*uv
    edge_ab=np.clip(np.divide(alpha-beta-uv+vv,edge_denominator,
        out=np.zeros_like(alpha),where=edge_denominator>1e-14),0.,1.)
    for candidate_a,candidate_b in [(edge_a,np.zeros_like(edge_a)),(np.zeros_like(edge_b),edge_b),(edge_ab,1-edge_ab)]:
        candidate_sse=sse(candidate_a,candidate_b)
        take=candidate_sse<best_sse-tie_tolerance
        best_sse=np.where(take,candidate_sse,best_sse)
        best_a=np.where(take,candidate_a,best_a);best_b=np.where(take,candidate_b,best_b)
    minima=np.min(best_sse,axis=1)
    # np.argmax returns the first true element, giving a stable grid tie order.
    chosen=np.argmax(best_sse<=minima[:,None]+tie_tolerance,axis=1)
    indices=np.arange(len(acfs))
    weights=np.stack([best_a[indices,chosen],best_b[indices,chosen],1-best_a[indices,chosen]-best_b[indices,chosen]],axis=1)
    profile=best_sse.reshape(len(acfs),len(basis['tau_grid']),len(basis['oscillator_values'])).min(axis=2)
    return dict(grid_index=chosen,sse=best_sse[indices,chosen],weights=weights,profile_sse=profile)


def fit_latent_acfs(acfs,window,config=None):
    settings=inference_settings(config);acfs=np.asarray(acfs,float)
    if acfs.ndim==1:acfs=acfs[None,:]
    if acfs.shape[1]!=settings['max_lag']+1:raise ValueError('Model lag length')
    basis=model_basis(window,settings);n=len(acfs)
    output=dict(estimate=np.full(n,np.nan),raw_tau=np.full(n,np.nan),oscillator_decay=np.full(n,np.nan),
        weights=np.full((n,3),np.nan),sse=np.full(n,np.nan),rmse=np.full(n,np.nan),
        profile_min_tau=np.full(n,np.nan),profile_max_tau=np.full(n,np.nan),profile_ratio=np.full(n,np.nan),
        profile_sse_slack_used=np.full(n,np.nan),
        eligible=np.zeros(n,bool),reason_code=np.full(n,16,dtype=int),
        profile_sse=np.full((n,len(basis['tau_grid'])),np.nan),tau_grid=basis['tau_grid'].copy())
    finite=np.isfinite(acfs).all(axis=1);rows=np.flatnonzero(finite)
    if not len(rows):return output
    fit=simplex_fit_batch(acfs[finite],basis,settings['fit_tie_tolerance'])
    chosen=fit['grid_index'];tau=basis['tau_grid'][basis['tau_index'][chosen]]
    oscillator=basis['oscillator_values'][basis['oscillator_index'][chosen]]
    rmse=np.sqrt(fit['sse']/settings['max_lag'])
    profile_slack=np.maximum(settings['profile_relative_slack']*fit['sse'],settings['profile_slack_floor'])
    admissible=fit['profile_sse']<=fit['sse'][:,None]+profile_slack[:,None]
    profile_min=np.min(np.where(admissible,basis['tau_grid'][None,:],np.inf),axis=1)
    profile_max=np.max(np.where(admissible,basis['tau_grid'][None,:],-np.inf),axis=1)
    ratio=profile_max/profile_min
    boundary=(tau<=basis['tau_grid'][0])|(tau>=basis['tau_grid'][-1])
    weak=fit['weights'][:,0]<settings['background_weight_min']
    poor=rmse>settings['fit_rmse_max'];ambiguous=ratio>settings['profile_ratio_max']
    code=weak.astype(int)+2*boundary.astype(int)+4*poor.astype(int)+8*ambiguous.astype(int)
    eligible=code==0
    for name,value in [('raw_tau',tau),('oscillator_decay',oscillator),('weights',fit['weights']),
        ('sse',fit['sse']),('rmse',rmse),('profile_min_tau',profile_min),('profile_max_tau',profile_max),
        ('profile_ratio',ratio),('profile_sse_slack_used',profile_slack),('eligible',eligible),('reason_code',code),('profile_sse',fit['profile_sse'])]:
        output[name][rows]=value
    output['estimate'][rows]=np.where(eligible,tau,np.nan)
    return output


def reason_from_code(code):
    meanings=[(1,'background_variance_weight_below_minimum'),(2,'background_tau_at_grid_boundary'),
              (4,'model_fit_rmse_above_limit'),(8,'profile_too_ambiguous'),(16,'nonfinite_acf')]
    return ';'.join(text for bit,text in meanings if int(code)&bit) or None


def _plain(value):
    return float(value) if np.isfinite(value) else None


def interval_row(name,point,bootstrap,config,abstention_reason=None):
    settings=inference_settings(config);bootstrap=np.asarray(bootstrap,float)
    finite=np.isfinite(bootstrap);positive=finite&(bootstrap>0.)
    minimum=math.ceil(settings['bootstrap_min_fraction']*len(bootstrap))
    raw=None;log_ci=None;adjusted=None;log_adjusted=None
    if np.isfinite(point) and finite.sum()>=minimum:
        raw=np.quantile(bootstrap[finite],[settings['lower_quantile'],settings['upper_quantile']]).tolist()
    if np.isfinite(point) and point>0 and positive.sum()>=minimum:
        log_ci=np.quantile(np.log(bootstrap[positive]),[settings['lower_quantile'],settings['upper_quantile']]).tolist()
    if name=='latent_decay':
        factor=2**(settings['grid_log2_step']/2)
        low=2**settings['tau_log2_min'];high=2**settings['tau_log2_max']
        if raw is not None:adjusted=[max(low,raw[0]/factor),min(high,raw[1]*factor)]
        if log_ci is not None:
            expansion=.5*settings['grid_log2_step']*math.log(2)
            log_adjusted=[max(math.log(low),log_ci[0]-expansion),min(math.log(high),log_ci[1]+expansion)]
    return dict(name=name,estimate=_plain(point),raw_ci95=raw,
        log_estimate=float(math.log(point)) if np.isfinite(point) and point>0 else None,
        log_ci95=log_ci,resolution_adjusted_ci95=adjusted,log_resolution_adjusted_ci95=log_adjusted,
        bootstrap_finite_count=int(finite.sum()),bootstrap_positive_count=int(positive.sum()),
        bootstrap_invalid_count=int((~finite).sum()),bootstrap_nonpositive_finite_count=int(np.sum(finite&~positive)),
        minimum_bootstrap_estimates_for_interval=minimum,abstention_reason=abstention_reason,
        log_undefined_reason=('point_not_finite' if not np.isfinite(point) else 'nonpositive_signed_endpoint' if point<=0 else None),
        raw_interval_unavailable_reason=('point_not_finite' if not np.isfinite(point) else 'insufficient_finite_bootstrap' if raw is None else None),
        log_interval_unavailable_reason=('point_not_positive_finite' if not np.isfinite(point) or point<=0 else 'insufficient_positive_bootstrap' if log_ci is None else None))


def fit_dataset(observed,window,config,bootstrap_weights):
    settings=inference_settings(config);observed=np.asarray(observed,float);weights=np.asarray(bootstrap_weights)
    if weights.shape!=(settings['bootstrap_replicates'],observed.shape[0]):raise ValueError('Bootstrap matrix dimensions')
    stats=segment_statistics(observed,settings['max_lag'])
    all_weights=np.vstack([np.ones((1,observed.shape[0])),weights])
    acfs=acf_from_statistics(stats,all_weights,settings['variance_numerical_floor'])
    values,capped,censored=functional_batch(acfs,settings['dt'])
    latent=fit_latent_acfs(acfs,window,settings)
    values=np.vstack([values,latent['estimate']])
    rows=[]
    for i,name in enumerate(METHODS):
        if name=='latent_decay':reason=reason_from_code(latent['reason_code'][0])
        elif not np.isfinite(acfs[0]).all():reason='nonfinite_acf'
        elif name=='half_life' and censored[0]:reason='no_half_crossing_within_horizon'
        else:reason=None
        row=interval_row(name,values[i,0],values[i,1:],settings,reason)
        if name=='initial_positive_prefix':row['horizon_capped']=bool(capped[0])
        if name=='half_life':row['right_censored']=bool(censored[0])
        if name=='latent_decay':row['grid_log2_step']=settings['grid_log2_step']
        rows.append(row)
    raw_osc=latent['oscillator_decay'][0]
    raw_fit=dict(raw_tau=_plain(latent['raw_tau'][0]),oscillator_decay=_plain(raw_osc),
        oscillator_decay_infinite=bool(np.isinf(raw_osc)),
        postwindow_variance_weights=[_plain(v) for v in latent['weights'][0]],
        sse=_plain(latent['sse'][0]),rmse=_plain(latent['rmse'][0]),
        profile_min_tau=_plain(latent['profile_min_tau'][0]),profile_max_tau=_plain(latent['profile_max_tau'][0]),
        profile_ratio=_plain(latent['profile_ratio'][0]),profile_sse_slack_used=_plain(latent['profile_sse_slack_used'][0]),eligible=bool(latent['eligible'][0]),
        reason_code=int(latent['reason_code'][0]),reason=reason_from_code(latent['reason_code'][0]),
        profile_tau_grid=latent['tau_grid'].tolist(),profile_sse=[_plain(v) for v in latent['profile_sse'][0]])
    record=dict(methods=rows,latent_fit=raw_fit,known_analysis_window=int(window),
        known_reference_frequency=settings['reference_frequency'],segments=observed.shape[0],segment_length=observed.shape[1],
        estimator_settings=settings,bootstrap_method_order=list(METHODS),
        estimand_note='First three endpoints target observed-ACF functionals; latent_decay targets a model-dependent exponential component timescale. They are not interchangeable.')
    arrays=dict(segment_statistics=stats,point_acf=acfs[0],bootstrap_acf=acfs[1:],bootstrap_estimates=values[:,1:],
        bootstrap_latent_raw_tau=latent['raw_tau'][1:],bootstrap_latent_weights=latent['weights'][1:],
        bootstrap_latent_reason_code=latent['reason_code'][1:],bootstrap_latent_rmse=latent['rmse'][1:],
        bootstrap_latent_profile_ratio=latent['profile_ratio'][1:],bootstrap_latent_profile_sse_slack_used=latent['profile_sse_slack_used'][1:])
    return record,arrays
