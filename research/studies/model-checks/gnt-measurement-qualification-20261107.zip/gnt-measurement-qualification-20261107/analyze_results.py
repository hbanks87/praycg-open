"""Frozen evaluation: own-functional accuracy and separate latent change claims."""
from pathlib import Path
import csv,hashlib,json,math
import numpy as np
from scipy.stats import t

ROOT=Path(__file__).resolve().parent
METHODS=('original_signed','initial_positive_prefix','half_life','latent_decay')
CASES=('clean2','clean8','rhythm2','rhythm8','damped2','noise2','noise8','smooth2','smooth8',
       'mixed2','mixed8','mixed_smooth2','mixed_smooth8','pure_rhythm','pure_noise','offgrid3_3','wrong_reference2','pure_noise_smooth')
CALIBRATION=('clean2','clean8','rhythm2','noise2','smooth2','pure_noise')
POSITIVE_PAIRS=(('clean2','clean8'),('rhythm2','rhythm8'),('noise2','noise8'),
                ('smooth2','smooth8'),('mixed2','mixed8'),('mixed_smooth2','mixed_smooth8'))
NULL_PAIRS=tuple(('clean2',name) for name in ('rhythm2','damped2','noise2','smooth2','mixed2','mixed_smooth2','wrong_reference2'))

def finite(x):return x is not None and np.isfinite(x)
def wilson(k,n):
    if not 0<=k<=n or n<=0:raise ValueError('invalid counts')
    z=1.959963984540054;p=k/n;den=1+z*z/n
    center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return dict(count=int(k),denominator=int(n),rate=p,low95=max(0.,center-half),high95=min(1.,center+half))
def mean_interval(values):
    v=np.array([x for x in values if finite(x)],float);n=len(v)
    if not n:return dict(mean=None,low95=None,high95=None,available=0)
    m=float(v.mean());half=float(t.ppf(.975,n-1)*v.std(ddof=1)/math.sqrt(n)) if n>1 else None
    return dict(mean=m,low95=m-half if half is not None else None,high95=m+half if half is not None else None,available=n)
def coverage(intervals,truth,n):
    valid=[v for v in intervals if v is not None and len(v)==2 and all(finite(x) for x in v)]
    covered=sum(lo<=truth<=hi for lo,hi in valid) if finite(truth) else None
    return dict(availability=wilson(len(valid),n),
        unconditional=wilson(covered,n) if covered is not None else None,
        conditional=wilson(covered,len(valid)) if covered is not None and valid else None,
        mean_width=mean_interval([hi-lo for lo,hi in valid]))

def summarize_cell(records,method):
    n=len(records);first=records[0];truth=first['population_truth'][method]
    rows=[next(m for m in r['methods'] if m['name']==method) for r in records]
    point=[m['estimate'] for m in rows];errors=[x-truth for x in point if finite(x) and finite(truth)]
    positive=[finite(x) and x>0 for x in point]
    logtruth=math.log(truth) if finite(truth) and truth>0 else None
    return dict(phase=first['phase'],case=first['case'],length=first['length'],method=method,replicates=n,
        population_truth=truth,point_availability=wilson(sum(finite(x) for x in point),n),
        abstention=wilson(sum(not finite(x) for x in point),n),log_point_availability=wilson(sum(positive),n),
        mean_estimate=mean_interval(point),bias=mean_interval(errors),mean_absolute_error=mean_interval([abs(x) for x in errors]),
        rmse=float(np.sqrt(np.mean(np.square(errors)))) if errors else None,
        mean_absolute_relative_error=mean_interval([abs(x)/abs(truth) for x in errors]) if finite(truth) and abs(truth)>1e-12 else mean_interval([]),
        raw_interval=coverage([m['raw_ci95'] for m in rows],truth,n),
        adjusted_interval=coverage([m['resolution_adjusted_ci95'] if method=='latent_decay' else m['raw_ci95'] for m in rows],truth,n),
        log_bias=mean_interval([math.log(x)-logtruth for x in point if finite(x) and x>0 and logtruth is not None]),
        log_interval=coverage([m['log_ci95'] for m in rows],logtruth,n))

def change_record(before,after,boot_before,boot_after,method):
    ib=next(m for m in before['methods'] if m['name']==method);ia=next(m for m in after['methods'] if m['name']==method)
    b=ib['estimate'];a=ia['estimate'];point=math.log(a/b) if finite(a) and finite(b) and a>0 and b>0 else None
    valid=np.isfinite(boot_before)&np.isfinite(boot_after)&(boot_before>0)&(boot_after>0)
    ci=None;raw=None
    if point is not None and int(valid.sum())>=math.ceil(.8*len(valid)):
        differences=np.log(boot_after[valid]/boot_before[valid]);raw=[float(x) for x in np.quantile(differences,[.025,.975])]
        expansion=.125*math.log(2) if method=='latent_decay' else 0.
        ci=[raw[0]-expansion,raw[1]+expansion]
    increase=bool(ci is not None and point>=math.log(1.5) and ci[0]>0)
    change=bool(ci is not None and abs(point)>=math.log(1.5) and (ci[0]>0 or ci[1]<0))
    return dict(before=before['case'],after=after['case'],length=before['length'],replicate=before['replicate'],method=method,
        point_logratio=point,raw_ci95=raw,decision_ci95=ci,valid_bootstrap_pairs=int(valid.sum()),
        interval_available=ci is not None,increase_supported=increase,change_supported=change)

def summarize_changes(rows):
    f=rows[0];n=len(rows)
    return dict(before=f['before'],after=f['after'],length=f['length'],method=f['method'],replicates=n,
        true_latent_change=(f['before'],f['after']) in POSITIVE_PAIRS,
        mean_logratio=mean_interval([r['point_logratio'] for r in rows]),
        interval_availability=wilson(sum(r['interval_available'] for r in rows),n),
        increase_support=wilson(sum(r['increase_supported'] for r in rows),n),
        change_support=wilson(sum(r['change_supported'] for r in rows),n))

def qualify(cells,changes):
    checks=[]
    def add(label,value,passed,criterion):checks.append(dict(check=label,value=value,criterion=criterion,passed=bool(passed)))
    for case in ('clean2','clean8','offgrid3_3'):
        c=next(x for x in cells if x['phase']=='test' and x['case']==case and x['length']==512 and x['method']=='latent_decay')
        a=c['point_availability'];e=c['mean_absolute_relative_error'];v=c['adjusted_interval']['unconditional']
        add(case+' point availability',a,a['low95']>=.8,'lower Wilson95 >= .80')
        add(case+' absolute relative error',e,e['mean'] is not None and e['mean']<=.25,'conditional mean <= .25')
        add(case+' unconditional adjusted interval coverage',v,v is not None and v['low95']>=.8,'lower Wilson95 >= .80')
    for pair in (('clean2','clean8'),('smooth2','smooth8'),('mixed_smooth2','mixed_smooth8')):
        c=next(x for x in changes if (x['before'],x['after'])==pair and x['length']==512 and x['method']=='latent_decay')
        v=c['increase_support'];add(' -> '.join(pair)+' power',v,v['low95']>=.8,'lower Wilson95 >= .80')
    for after in ('rhythm2','noise2','smooth2','mixed_smooth2'):
        c=next(x for x in changes if x['before']=='clean2' and x['after']==after and x['length']==512 and x['method']=='latent_decay')
        v=c['change_support'];add('clean2 -> '+after+' false latent change',v,v['high95']<=.1,'upper Wilson95 <= .10')
        v=c['interval_availability'];add('clean2 -> '+after+' usable comparison',v,v['low95']>=.8,'lower Wilson95 >= .80')
    for case in ('pure_rhythm','pure_noise','pure_noise_smooth'):
        c=next(x for x in cells if x['phase']=='test' and x['case']==case and x['length']==512 and x['method']=='latent_decay')
        v=c['abstention'];add(case+' absent-target abstention',v,v['low95']>=.8,'lower Wilson95 >= .80')
    assert len(checks)==23
    return dict(passed=all(c['passed'] for c in checks),checks=checks,
        scope='Qualification of this revised latent-decay estimator under specified synthetic observation assumptions; no gratitude or biological validation.')

def verify_freeze():
    raw=(ROOT/'FROZEN_MANIFEST.json').read_bytes();manifest=json.loads(raw)
    for name,digest in manifest['sha256'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Frozen input changed: '+name)
    return hashlib.sha256(raw).hexdigest()

def main():
    fingerprint=verify_freeze();records={};arrays={};expected=set()
    for phase in ('calibration','test'):
        for case in (CALIBRATION if phase=='calibration' else CASES):
            for length in ((512,) if phase=='calibration' else (64,512)):
                for rep in range(20 if phase=='calibration' else 100):expected.add((phase,case,length,rep))
    for path in sorted((ROOT/'main').glob('*/*/replicate_*.json')):
        record=json.loads(path.read_text());key=tuple(record[k] for k in ('phase','case','length','replicate'))
        assert key in expected and key not in records and record['frozen_manifest_sha256']==fingerprint
        assert [m['name'] for m in record['methods']]==list(METHODS)
        npzpath=path.parent/record['arrays_file']
        assert hashlib.sha256(npzpath.read_bytes()).hexdigest()==record['arrays_sha256']
        with np.load(npzpath) as z:arrays[key]=z['bootstrap_estimates'].copy()
        records[key]=record
    assert set(records)==expected
    cells=[];rows=[]
    for phase in ('calibration','test'):
        for case in (CALIBRATION if phase=='calibration' else CASES):
            for length in ((512,) if phase=='calibration' else (64,512)):
                group=[records[phase,case,length,r] for r in range(20 if phase=='calibration' else 100)]
                cells.extend(summarize_cell(group,m) for m in METHODS)
    changes=[]
    for before,after in POSITIVE_PAIRS+NULL_PAIRS:
        for length in (64,512):
            for mi,method in enumerate(METHODS):
                group=[]
                for rep in range(100):
                    kb=('test',before,length,rep);ka=('test',after,length,rep)
                    row=change_record(records[kb],records[ka],arrays[kb][mi],arrays[ka][mi],method)
                    rows.append(row);group.append(row)
                changes.append(summarize_changes(group))
    result=dict(test_dataset_count=3600,calibration_dataset_count=120,method_rows=4*len(records),
        independent_test_replicate_clusters=100,cells=cells,changes=changes,qualification=qualify(cells,changes),
        interpretation='Observed-ACF functionals and latent decay are different targets. Nuisance-driven endpoint changes are legitimate functional changes and are misleading only if attributed to unchanged latent persistence.',
        uncertainty='Cellwise Monte Carlo intervals; cells share seeds. Undefined values remain unavailable. Bootstrap intervals are conditional/approximate and latent grid-resolution expansion is reported separately.')
    (ROOT/'RESULTS.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    flat=[]
    for key,r in sorted(records.items()):
        for m in r['methods']:
            flat.append(dict(phase=r['phase'],case=r['case'],length=r['length'],replicate=r['replicate'],method=m['name'],
                population_truth=r['population_truth'][m['name']],estimate=m['estimate'],log_estimate=m['log_estimate'],
                raw_ci95=json.dumps(m['raw_ci95']),adjusted_ci95=json.dumps(m.get('resolution_adjusted_ci95',m['raw_ci95'])),
                bootstrap_finite_count=m['bootstrap_finite_count'],bootstrap_positive_count=m['bootstrap_positive_count']))
    for name,data in [('ESTIMATE_RESULTS.csv',flat),('CHANGE_RESULTS.csv',rows)]:
        with (ROOT/name).open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
    table=[]
    for c in cells:
        table.append(dict(phase=c['phase'],case=c['case'],length=c['length'],method=c['method'],truth=c['population_truth'],
            availability=c['point_availability']['rate'],log_availability=c['log_point_availability']['rate'],
            bias=c['bias']['mean'],mean_absolute_relative_error=c['mean_absolute_relative_error']['mean'],rmse=c['rmse'],
            raw_interval_availability=c['raw_interval']['availability']['rate'],
            raw_unconditional_coverage=c['raw_interval']['unconditional']['rate'] if c['raw_interval']['unconditional'] else None,
            adjusted_unconditional_coverage=c['adjusted_interval']['unconditional']['rate'] if c['adjusted_interval']['unconditional'] else None))
    with (ROOT/'CELL_RESULTS.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    verify_freeze();print(json.dumps(dict(datasets=len(records),qualification=result['qualification']),indent=2))

if __name__=='__main__':main()
