# GNT coherence-lifetime measurement qualification

This preserves the November 7 synthetic generator, estimators, qualification rules and independent checks. It is not a gratitude/neurochemical result or EEG experiment. Time is measured in abstract ticks.

Python 3.11; from a fresh extracted folder:

```sh
python -m pip install -r requirements.txt
python run_example.py
python independent_checks.py
```

The example generates four 16 x 512 artificial observation matrices from reserved preflight replicate 731. It verifies that the valid period-40 process has a negative signed ACF integral (about -6.3531 ticks), making the original real logarithm undefined. Smoothing white noise changes its observed signed integral from 0.5 to 2.5 ticks. These are exact domain/measurement counterexamples, not estimates of biological persistence.

The unchanged independent suite checks generator/covariance reconstruction, segment/bootstrap handling, estimator handcases and all 23 qualification criteria individually. Passing software checks is distinct from the failed historical measurement qualification. See the recorded PUBLIC_VERIFICATION.json for the actual fresh check count.

Full reproduction (not rerun during public packaging) uses the original config: 120 calibration plus 3,600 test datasets, 199 bootstrap draws per dataset. After the bounded checks, in a fresh copy:

```sh
python prepare_full_run.py
python run_study.py --phase calibration --index 0 --total 1
python run_study.py --phase test --index 0 --total 1
python analyze_results.py
python postrun_checks.py
```

The public preparation makes a new integrity binding and does not claim to recreate the original prospective freeze. Algorithms, scenario seeds, thresholds and counts are unchanged; elapsed metadata, compressed arrays and provenance fingerprints can differ. Complete calibration before test generation. Use a separate extraction to preserve any prior results.

Historical qualification failed: 10/23 requirements passed. HISTORICAL_RESULTS.json retains every check/value/criterion. The replacement latent-decay estimator did not establish reliable general-purpose coherence lifetime. Correct observed summaries can change with smoothing without a change in the latent background process. Preserve unavailable/undefined estimates and interval coverage failures; never turn missingness into success. SOURCE_PROVENANCE.json retains exact original source hashes; NOTICE.md covers dependencies and scope.
