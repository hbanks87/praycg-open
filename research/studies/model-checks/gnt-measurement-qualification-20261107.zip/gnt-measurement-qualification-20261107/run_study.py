"""Frozen two-phase runner with observed segments and every bootstrap estimate."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['OMP_NUM_THREADS']='1'
from pathlib import Path
import argparse,hashlib,json,time,traceback
import numpy as np
import generator as g
import estimators as e

ROOT=Path(__file__).resolve().parent
CONFIG=json.loads((ROOT/'protocol_config.json').read_text())


def atomic_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp')
    temp.write_text(json.dumps(value,indent=2,allow_nan=False),encoding='utf-8');temp.replace(path)


def atomic_npz(path,arrays):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp')
    with temp.open('wb') as f:np.savez_compressed(f,**arrays)
    temp.replace(path)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_freeze():
    path=ROOT/'FROZEN_MANIFEST.json';manifest=json.loads(path.read_text())
    for name,digest in manifest['sha256'].items():
        if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Frozen source changed: '+name)
    for name in ('generator.py','estimators.py','protocol_config.json','run_study.py'):
        if name not in manifest['sha256']:raise RuntimeError('Numerical input was not frozen: '+name)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def estimator_settings():
    settings=dict(e.ESTIMATOR_DEFAULTS)
    expected={'dt':CONFIG['dt'],'max_lag':CONFIG['acf_max_lag'],
              'bootstrap_replicates':CONFIG['bootstrap_replicates'],
              'reference_frequency':CONFIG['reference_frequency'],
              'grid_log2_step':CONFIG['grid_log2_step']}
    for key,value in expected.items():
        if settings[key]!=value:raise RuntimeError('Estimator/generator declaration mismatch: '+key)
    return settings


def checkpoint_paths(phase,spec,length,replicate):
    folder=ROOT/'main'/phase/f'{spec["name"]}__n{length}'
    return folder/f'replicate_{replicate:03d}.json',folder/f'replicate_{replicate:03d}.npz'


def validate_checkpoint(path,arraypath,fingerprint,phase,case_index,length,replicate):
    record=json.loads(path.read_text())
    identity=(record['phase'],record['case_index'],record['length'],record['replicate'])
    if identity!=(phase,case_index,length,replicate):raise RuntimeError('Checkpoint identity mismatch')
    if record.get('frozen_manifest_sha256')!=fingerprint:raise RuntimeError('Stale checkpoint provenance')
    if record['arrays_file']!=arraypath.name or hashlib.sha256(arraypath.read_bytes()).hexdigest()!=record['arrays_sha256']:
        raise RuntimeError('Checkpoint array integrity mismatch')
    if {m['name'] for m in record['methods']}!=set(e.METHODS) or len(record['methods'])!=len(e.METHODS):
        raise RuntimeError('Checkpoint methods missing/duplicated')
    return record


def require_calibration_complete(fingerprint):
    for index,length in g.cells_for_phase(CONFIG,'calibration'):
        spec=CONFIG['cases'][index]
        for replicate in range(CONFIG['calibration_replicates']):
            path,arraypath=checkpoint_paths('calibration',spec,length,replicate)
            if not path.exists():raise RuntimeError('Complete frozen calibration phase before test phase')
            validate_checkpoint(path,arraypath,fingerprint,'calibration',index,length,replicate)


def run_worker(phase,index,total):
    fingerprint=verify_freeze();settings=estimator_settings()
    if not 0<=index<total:raise ValueError('Invalid worker index')
    if phase=='test':require_calibration_complete(fingerprint)
    cells=g.cells_for_phase(CONFIG,phase)
    replicates=CONFIG['calibration_replicates'] if phase=='calibration' else CONFIG['test_replicates']
    start=time.time();completed=0;reused=0
    for cell_index,(case_index,length) in enumerate(cells):
        if cell_index%total!=index:continue
        spec=CONFIG['cases'][case_index]
        population_acf=g.population_acf(CONFIG,spec)
        population_values=e.population_functionals(population_acf,CONFIG['dt'])
        population_values=dict(population_values)
        population_values['latent_decay']=spec['tau'] if spec['a']>0 else None
        for replicate in range(replicates):
            path,arraypath=checkpoint_paths(phase,spec,length,replicate)
            try:
                if path.exists():
                    validate_checkpoint(path,arraypath,fingerprint,phase,case_index,length,replicate)
                    reused+=1;continue
                bundle=g.generate(CONFIG,case_index,replicate,length,phase)
                weights,key=g.segment_bootstrap_weights(CONFIG,replicate,length,phase)
                # Only observed segments, known analysis window, declared estimator
                # settings and segment-resampling weights cross this interface.
                record,arrays=e.fit_dataset(bundle['observed'],spec['window'],settings,weights)
                arrays=dict(arrays);arrays['observed_segments']=bundle['observed']
                digest=atomic_npz(arraypath,arrays)
                record.update(phase=phase,case=spec['name'],case_index=case_index,length=length,
                    replicate=replicate,known_window=spec['window'],segments=CONFIG['segments'],
                    generator_metadata=bundle['metadata'],population_acf=population_acf.tolist(),
                    population_truth=population_values,latent_tau_defined=spec['a']>0,
                    bootstrap_seed_key=key,arrays_file=arraypath.name,arrays_sha256=digest,
                    estimator_method_order=list(e.METHODS),frozen_manifest_sha256=fingerprint)
                atomic_json(path,record);completed+=1
            except Exception as exc:
                atomic_json(ROOT/'execution'/f'ERROR_{phase}_{index}_{spec["name"]}_{length}_{replicate}.json',
                    dict(error=repr(exc),traceback=traceback.format_exc(),phase=phase,case=spec['name'],
                         length=length,replicate=replicate,frozen_manifest_sha256=fingerprint))
                raise
        print(f'Completed {phase}/{spec["name"]}, n={length}; worker {index}; elapsed {time.time()-start:.1f}s',flush=True)
    if verify_freeze()!=fingerprint:raise RuntimeError('Frozen manifest changed during run')
    atomic_json(ROOT/'execution'/f'{phase}_worker_{index}_complete.json',dict(phase=phase,index=index,total=total,
        completed_datasets=completed,reused_datasets=reused,elapsed_seconds=time.time()-start,
        frozen_manifest_sha256=fingerprint))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['calibration','test'],required=True)
    parser.add_argument('--index',type=int,default=0);parser.add_argument('--total',type=int,default=1)
    args=parser.parse_args();run_worker(args.phase,args.index,args.total)
