"""Synthetic arithmetic demonstration. No automatic content grading or runner."""
from pathlib import Path
import json

def summarize(rows):
    out = dict(planned=len(rows), correct=0, incorrect=0, uncertain=0, missing=0, unscored=0)
    for row in rows:
        code, present = row['score'], bool(row['response'].strip())
        if code not in ('0', '1', 'U', 'M', ''):
            raise ValueError('Invalid score code')
        if not present:
            if code not in ('M', ''):
                raise ValueError('A blank answer must remain missing')
            out['missing'] += 1
        elif code == 'M':
            raise ValueError('A nonempty answer cannot be missing')
        else:
            out[{'0':'incorrect', '1':'correct', 'U':'uncertain', '':'unscored'}[code]] += 1
    denominator = out['correct'] + out['incorrect']
    out['accuracy_scored_only_percent'] = 100*out['correct']/denominator if denominator else None
    return out

if __name__ == '__main__':
    data = json.loads(Path(__file__).with_name('SYNTHETIC_EXAMPLE.json').read_text(encoding='utf-8'))
    order = list(range(len(data['reveal_units'])))
    rotated = [order[0], *order[2:-1], order[1], order[-1]]
    assert rotated == data['reordered_order']
    result = summarize(data['scoring_rows'])
    result['digit_sum'] = sum(data['digits_by_presentation_position'])
    assert result == data['expected'], (result, data['expected'])
    print(json.dumps({'status':'PASS_SYNTHETIC_ARITHMETIC_ONLY', 'result':result}, indent=2))
