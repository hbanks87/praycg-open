PRAYCG public protocol companion: decoder-gate-pilot

Extract the whole ZIP, then run: python reproduce.py
Python 3.11 or later; standard library only. No installation, network, hardware or participant data required.
The script reads only its bundled synthetic example and prints known-answer arithmetic.
It does not grade natural-language responses, run a study, synthesize media, or validate a theory.
The exact protocol/settings snapshot is reference metadata; the new synthetic example is a distinct illustration.
Original code: MIT. Original documentation/example metadata: CC BY 4.0. See LICENSE.md.
See the adjacent repository PROTOCOL.md and SOURCES_AND_RIGHTS.md for the study and rights boundaries.
