"""Known-answer synthetic scoring and inventory arithmetic; no media or acquisition."""
from pathlib import Path
import hashlib
import json
from statistics import mean

def primary(ratings):
    if len(ratings) != 4 or any(len(pair) != 2 for pair in ratings):
        raise ValueError('Four double-rated items are required')
    for pair in ratings:
        for score in pair:
            if score is not None and (type(score) is not int or not 0 <= score <= 3):
                raise ValueError('Ratings must be integer 0-3 or missing')
    if any(score is None for pair in ratings for score in pair):
        return None
    return mean(mean(pair) for pair in ratings)

def arm_summary(records, arm):
    scores = [primary(r['ratings']) for r in records if r['arm'] == arm]
    if not scores:
        raise ValueError('Both assigned arms are required')
    present = [s for s in scores if s is not None]
    missing = len(scores) - len(present)
    return {'assigned':len(scores), 'observed':len(present), 'missing':missing,
            'observed_mean':mean(present) if present else None,
            'bounds':[sum(present)/len(scores), (sum(present)+3*missing)/len(scores)]}

if __name__ == '__main__':
    data = json.loads(Path(__file__).with_name('SYNTHETIC_EXAMPLE.json').read_text(encoding='utf-8'))
    c = arm_summary(data['synthetic_assigned_records'], 'coherent')
    d = arm_summary(data['synthetic_assigned_records'], 'disrupted')
    geometry = data['geometry']
    seconds_per_frame = geometry['frame_rate_denominator']/geometry['frame_rate_numerator']
    result = {
        'primary_scores':[primary(r['ratings']) for r in data['synthetic_assigned_records']],
        'observed_difference':c['observed_mean']-d['observed_mean'],
        'all_assigned_difference_bounds':[c['bounds'][0]-d['bounds'][1],c['bounds'][1]-d['bounds'][0]],
        'fixed_stimulus_quiet_seconds':round((geometry['context_frames']+geometry['ending_frames'])*seconds_per_frame+geometry['baseline_s']+geometry['preending_s']+geometry['washout_s'],6)
    }
    assert result == data['expected'], (result, data['expected'])
    assert sorted(data['disrupted_order']) == data['coherent_order'] == list(range(12))
    assert data['disrupted_order'][0] == 0 and data['disrupted_order'][-1] == 11
    assert geometry['segment_frames']*12 == geometry['context_frames']
    hashes = [hashlib.sha256(label.encode()).hexdigest() for label in data['segment_labels']]
    inventory = {arm:[hashes[i] for i in data[arm+'_order']] for arm in ('coherent','disrupted')}
    ending_hash = hashlib.sha256(data['shared_ending'].encode()).hexdigest()
    print(json.dumps({'status':'PASS_SYNTHETIC_ARITHMETIC_ONLY', 'result':result,
                     'arms':{'coherent':c,'disrupted':d}, 'synthetic_segment_hashes':inventory,
                     'shared_synthetic_ending_sha256':ending_hash}, indent=2))
