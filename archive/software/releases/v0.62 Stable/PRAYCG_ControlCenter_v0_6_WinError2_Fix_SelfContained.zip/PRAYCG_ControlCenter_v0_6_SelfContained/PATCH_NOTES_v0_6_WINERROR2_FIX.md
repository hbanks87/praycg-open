# PRAYCG Control Center v0.6 - WinError 2 Launch Fix

## What was fixed

v0.5 could raise:

```text
[WinError 2] The system cannot find the file specified
```

when launching a Python-based PRAYCG tool, even when the selected script existed.

The most likely cause was that v0.5 used `shlex.split()` on the configured Python executable. On Windows, this can corrupt backslash paths such as:

```text
C:\Users\...\python.exe
```

or any Python path with spaces. The resulting command no longer points to a real executable, so Windows reports WinError 2.

## v0.6 changes

- Replaced direct `shlex.split()` calls for the Python executable with a Windows-safe command builder.
- `Use Bundled Paths` now also resets the Python executable to the interpreter currently running the Control Center.
- Added a `Use Current Python` button in Settings.
- Batch/CMD launch commands now route through `cmd.exe /c` on Windows.
- File-not-found launch errors now display the exact command that failed and recommend `Settings -> Use Current Python`.

## Recommended recovery steps

1. Extract v0.6 to a short path, e.g. `C:\PRAYCG_CC_v06\`.
2. Start `run_PRAYCG_ControlCenter_v0_6.bat`.
3. Open `Settings`.
4. Click `Use Bundled Paths`.
5. Click `Use Current Python` if any launch error remains.
6. Click `Save Settings`.
7. Try launching MediaPrep again.

LabRecorder and PsychoPy are still external programs and must be installed/auto-found or selected manually.
