# PRAYCG Control Center v0.6 — Self-Contained Software Release

This ZIP is a self-contained PRAYCG software bundle for GitHub/public use. It includes the Control Center plus the current PRAYCG software tree it points to.

## Start here

1. Extract this ZIP to a short path, for example:

```text
C:\PRAYCG_CC_v05\
```

2. Run:

```bat
run_PRAYCG_ControlCenter_v0_6.bat
```

3. In the Control Center, open **Settings** and click:

```text
Use Bundled Paths
```

This points MediaPrep, the PRAYCG2.0 runner, Master Suite, Visualizer, Offline Interpreter, BrainFlow, Polar, and Vernier paths to the bundled tools.

4. Use **Auto-find ALL** only for external applications:

```text
PsychoPy / PsychoPy Coder
LabRecorder
```

Those are not bundled.

## Bundled current tools

```text
tools/MediaPrep_StimulusFingerprint_v1_8
tools/ProtocolRunner_PRAYCG2_0
tools/MasterComprehensiveSuite_v1_5_6_CURRENT
tools/Offline_Master_Interpreter_v1_5_6
tools/Acquisition/BrainFlow_EEGOnly_Home_Bridge_v1_0
tools/Acquisition/BrainFlow_ALS_PT19_Bridge_v1_4
tools/Acquisition/Polar_H10_to_LSL
tools/Acquisition/Vernier_Respiration_to_LSL
```

## Why v0.6 exists

v0.4 had Auto-Find, but it did not include the software package that the settings should point to. v0.6 fixes that by packaging the Control Center and the current software together.

## Important boundary

This is exploratory research software. It is not a medical device, not diagnostic software, and not proof of consciousness, OSM biology, memory formation, or any metaphysical mechanism.

## Windows note

The ZIP uses short internal paths. Extract it to a short folder path to avoid Windows path-length problems.

## v0.6 WinError 2 fix

If v0.5 produced `[WinError 2] The system cannot find the file specified` while launching MediaPrep or another Python tool, use v0.6. Then open Settings and click:

```text
Use Bundled Paths
Use Current Python
Save Settings
```

This resets stale v0.5 path settings and avoids Windows path corruption.
