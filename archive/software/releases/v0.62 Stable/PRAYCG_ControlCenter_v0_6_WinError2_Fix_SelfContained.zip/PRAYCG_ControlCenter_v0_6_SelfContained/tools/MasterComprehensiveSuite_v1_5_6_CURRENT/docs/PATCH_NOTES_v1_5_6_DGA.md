# Patch Notes - PRAYCG Unified Master Suite v1.5.6 DGA

Added:

- `scripts/praycg_decoder_gate_availability_module_v1_5_6.py`
- `docs/DGA_Decoder_Gate_Availability_Method_v1_5_6.md`
- DGA overlay output support through `dga_visual_overlay.csv`
- DGA gate-adjusted MRED anchor table support

No existing modules were removed. A-MRED / MRED-Peak / MRED-Resolution remains the boxed primary path. DGA is an interpretive module for access/availability/gate dissociation.
