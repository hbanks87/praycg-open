# PRAYCG Unified Master Suite v1.5.6 - DGA

Current addition: DGA_v0.1 - Decoder Gate Availability / Gate Dissociation.

Example:

```bat
py -3.11 scripts\praycg_decoder_gate_availability_module_v1_5_6.py ^
  --analysis-folder "C:\PRAYCG\analysis_outputs\MyRun_MasterComprehensive" ^
  --sidecar-folder "C:\PRAYCG\acquisition\MyRun" ^
  --run-label "MyRun" ^
  --out-dir "C:\PRAYCG\analysis_outputs\MyRun_MasterComprehensive"
```

DGA is not a proof module. It estimates semantic access, decoder availability, emotional/integrative impact, extraction load, and confound load.
