@echo off
setlocal
cd /d "%~dp0"
echo Installing common PRAYCG Python dependencies into your active Python 3.11 environment...
py -3.11 -m pip install --upgrade pip
py -3.11 -m pip install numpy scipy pandas matplotlib opencv-python moviepy pylsl pyxdf mne pyyaml pillow
py -3.11 -m pip install brainflow bleak godirect psychopy
pause
