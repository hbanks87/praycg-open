# External apps not bundled

This package includes the PRAYCG Python scripts and current software tree, but it does not bundle external applications that must be installed separately:

- PsychoPy / PsychoPy Coder
- LabRecorder
- OpenBCI drivers / FTDI or board drivers
- Python 3.11

Use Control Center -> Settings -> Auto-find ALL to locate PsychoPy and LabRecorder after installing them.

The PRAYCG runner is currently safest when opened from PsychoPy Coder. Control Center v0.6 defaults to the PsychoPy-safe runner mode.
