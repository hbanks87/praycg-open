# 01 - Hardware Setup and Safety SOP

## 1.1 Hardware list

Minimum PRAYCG2.0 acquisition stack:

- A stimulus laptop capable of fullscreen playback.
- OpenBCI Cyton + Daisy with USB dongle.
- OpenBCI gelfree electrode cap, HPTA adapters, saline solution, Hydro-link inserts, reference and ground connections.
- ALS-PT19 or equivalent analog light sensor for physical display timing.
- Vernier Go Direct Respiration Belt or equivalent respiration stream.
- Polar H10 or equivalent R-R interval stream.
- LabRecorder for XDF recording.
- Optional enclosure/Box/Faraday chamber for environmental consistency.

## 1.2 The Box / Stasis Chamber

The Box is an environmental-control apparatus. Its purpose is to reduce uncontrolled environmental noise and standardize the measurement setting. It is not a medical device and not a proof device.

### Build/inspection steps

1. **Inspect the physical frame.** Confirm that the frame is stable, cannot collapse, and provides a clear exit path.
2. **Inspect the floor.** If a conductive floor or mesh is used, make sure there is a dielectric layer between participant and any conductive surface.
3. **Inspect seams.** Conductive mesh seams should be mechanically overlapped and electrically continuous if the enclosure is intended to function as a Faraday shield.
4. **Grounding review.** Any earth-ground rod, building-ground connection, or lightning/surge concern should be reviewed by a qualified person. Do not improvise mains-ground wiring.
5. **Cable pass-throughs.** Route power, USB, sensor, and display cables so they do not create trip hazards or exert pull on sensors.
6. **Ventilation and comfort.** Verify temperature, air flow, chair stability, lighting, and emergency exit.
7. **Device power.** Prefer battery-powered acquisition equipment. Keep mains adapters and power strips outside the participant’s direct contact area when possible.
8. **Documentation.** Photograph the final layout, cable paths, and equipment placement before each major hardware revision.

### Pre-run Box checklist

```text
[ ] Clear participant exit path
[ ] No exposed conductor near participant skin
[ ] No trip hazards
[ ] Chair stable
[ ] Screen visible and centered
[ ] ALS sensor taped over timing square
[ ] Cap leads strain-relieved
[ ] Respiration belt not too tight
[ ] Polar H10 comfortable
[ ] Laptop volume checked
[ ] LabRecorder save path checked
```

## 1.3 OpenBCI Cyton + Daisy

### Physical setup

1. Charge or install the battery pack.
2. Seat the Daisy module on the Cyton carefully and check pin alignment.
3. Insert the OpenBCI USB dongle into the acquisition laptop.
4. Turn on the board and confirm the board/dongle connection.
5. Identify the COM port before opening any acquisition script.
6. Do **not** open the OpenBCI GUI while BrainFlow is using the same COM port.

### Reference and BIAS convention

1. Use the Cyton+Daisy Y-splitter to gang the bottom SRB pins of Cyton and Daisy.
2. Connect the single end of the Y-splitter to the cap REF location.
3. Connect the bottom BIAS pin of the Cyton to the cap GND location.
4. Connect channels 1-8 to Cyton bottom pins N1P-N8P.
5. Connect channels 9-16 to Daisy bottom pins N1P-N8P.
6. Photograph or physically trace the map before marking the channel map as confirmed.

### PRAYCG16 channel map discipline

Use the same fixed channel order every run unless a new version is explicitly created. If you change the electrode-to-channel map, save a new channel map file and do not compare ROI-weighted outputs to old runs without caution.

## 1.4 OpenBCI gelfree cap

### Prepare the cap

1. Make saline solution according to the cap guide: fill beaker with water, mix in salt, and soak Hydro-link inserts.
2. Place the cap on the subject’s head and align 10-20 landmarks.
3. Insert soaked Hydro-link inserts into the electrode holders.
4. Connect REF and GND before connecting analysis channels.
5. Connect the planned 16 channel electrodes to Cyton/Daisy pins.
6. Check that cables have slack and are not pulling the cap.
7. If using OpenBCI GUI only for impedance preview, close the GUI before starting BrainFlow.

### Signal check

1. Run a short OpenBCI/BrainFlow test.
2. Look for obvious flatlines, saturated channels, repeated packet issues, or huge motion artifacts.
3. Ask the subject to blink, clench jaw, and relax; observe whether frontal/temporal artifact channels respond as expected.
4. Save a screenshot or log of the channel map and signal sanity check.

## 1.5 ALS-PT19 light sensor

### KISS wiring used by the current PRAYCG BrainFlow ALS bridge

```text
ALS-PT19 +      -> Cyton DVDD / 3V3
ALS-PT19 -      -> Cyton GND
ALS-PT19 OUT    -> Cyton D12 / A6
```

Default analog AUX channel in the bridge:

```text
--als-aux-channel 1
```

because the script maps analog channels as:

```text
0 = A5 / D11
1 = A6 / D12  <- ALS-PT19 default
2 = A7 / D13
```

### Placement

1. Run MediaPrep with fullscreen ALS start pulse or timing-square pulse enabled.
2. Tape the ALS sensor directly over the timing square/pulse region.
3. Use black electrical tape or an opaque shroud so room light does not dominate the signal.
4. Confirm the sensor does not cover the number cue or a critical narrative region.
5. Run the ALS watchdog before the real protocol.

### Pass rule

Target, Override, and Control should all produce a visible pulse at video start, with no full-duration clipping and no missed start pulse.

## 1.6 Vernier Go Direct Respiration Belt

### Setup

1. Charge the belt before first use.
2. Power it on and confirm the LED is active.
3. Place it around the chest or abdomen over clothing.
4. For best results, position the sensor box just below the sternum.
5. Tighten until the tension indicator is green. Loosen if it turns red.
6. Connect to Graphical Analysis or the PRAYCG Vernier LSL bridge if available.
7. Confirm respiration force/rate stream is visible before starting LabRecorder.

### Run check

1. Ask the subject to breathe normally for 30-60 seconds.
2. Confirm the signal rises on inhalation and falls on exhalation.
3. Confirm it is not flat and not saturated.
4. Mark it as available or unavailable before running analysis.

## 1.7 Polar H10

### Setup

1. Wet the strap electrode areas.
2. Attach the H10 sensor to the strap.
3. Place strap snugly around the chest, below the pectoral muscles.
4. Pair to your Polar/LSL streamer, not to a phone app that will monopolize the sensor.
5. Confirm heart rate and R-R interval notifications are being received.
6. Confirm the LSL stream appears before recording.

### Run check

1. Verify stable HR and R-R intervals for at least 60 seconds.
2. Re-seat the strap if HR is zero, implausible, or intermittent.
3. Keep the phone Bluetooth connection off unless it is the intended capture device.

## 1.8 Hardware shutdown

1. Stop LabRecorder.
2. Stop PRAYCG runner.
3. Stop BrainFlow bridge and confirm it releases the COM port.
4. Stop Polar/Vernier streamers.
5. Turn off OpenBCI board.
6. Remove cap, remove Hydro-link inserts, rinse/dry according to cap instructions.
7. Dry and store the ALS sensor and cables.
8. Charge Polar/Vernier if needed.
