# 05 - BrainFlow, ALS Streamer, LSL, and LabRecorder SOP

## 5.1 Core rule

Do not run the OpenBCI GUI and BrainFlow bridge at the same time. Both want exclusive control of the OpenBCI COM port.

## 5.2 Start BrainFlow ALS bridge

Open Command Prompt:

```bat
cd /d C:\PRAYCG\software\BrainFlow_ALS_v1_4
.venv\Scripts\activate
```

Identify the OpenBCI dongle port:

```bat
python scripts\praycg_identify_openbci_port_v1_4.py --watch
```

Start the bridge, replacing `COM3` with your actual port:

```bat
python scripts\praycg_openbci_brainflow_als_pt19_bridge_v1_4.py ^
  --board cyton-daisy ^
  --serial-port COM3 ^
  --enable-analog-aux ^
  --publish-als-stream ^
  --confirmed-channel-map
```

Expected LSL streams from the bridge:

```text
obci_eeg1              EEG, 16 channels
OpenBCIAnalogAux       raw analog AUX, 3 channels
ALS_PT19_Timing        extracted ALS timing stream
OpenBCIStatusMarkers   heartbeat/status markers
```

## 5.3 Confirm LSL stream visibility

In a second Command Prompt:

```bat
cd /d C:\PRAYCG\software\BrainFlow_ALS_v1_4
.venv\Scripts\activate
python scripts\praycg_list_lsl_streams_v1_4.py
```

Expected minimum streams before running the protocol:

```text
obci_eeg1
OpenBCIAnalogAux
ALS_PT19_Timing
OpenBCIStatusMarkers
```

After starting PRAYCG2.0, you should also see:

```text
StasisMarkers
```

If Polar/Vernier are running, expect their streams too.

## 5.4 ALS pulse watchdog

Run this before the real recording:

```bat
python scripts\praycg_als_pt19_light_watchdog_v1_4.py --duration 30 --expected-pulses 1
```

Then play the first 10 seconds of Target video. You want a strong rise and return to baseline. Repeat or inspect Control and Override if possible.

## 5.5 Start Polar H10 streamer

1. Put on the Polar H10 and verify skin contact.
2. Run your Polar-to-LSL script or approved app.
3. Confirm a stream such as `PolarHRV`, `PolarH10`, or `PolarH10_RR` appears.
4. Confirm HR and R-R intervals are nonzero and plausible.

If the Polar stream does not appear, close phone apps that may own the Bluetooth connection, rewet strap, and restart the streamer.

## 5.6 Start Vernier respiration streamer

1. Fit and turn on the Go Direct Respiration Belt.
2. Use Graphical Analysis or your Vernier-to-LSL bridge.
3. Confirm respiration force/rate data are updating.
4. Confirm a stream such as `VernierRespirationBelt` appears in LSL.

## 5.7 Start PRAYCG2.0 until StasisMarkers are online

Run:

```bat
cd /d C:\PRAYCG\software\PRAYCG2_0_Runner
.venv\Scripts\activate
python scripts\run_PRAYCG2_0_ConsolidatedSelfReport.py
```

Load media files and configuration, then stop at the point where the runner indicates StasisMarkers are online and LabRecorder should be started.

## 5.8 Configure LabRecorder

1. Open `LabRecorder.exe`.
2. Click **Update** until all streams appear.
3. Select:

```text
StasisMarkers
obci_eeg1
OpenBCIAnalogAux
ALS_PT19_Timing
OpenBCIStatusMarkers
PolarHRV / PolarH10 / RR stream, if available
VernierRespirationBelt, if available
```

4. Set Study Root:

```text
C:\PRAYCG\acquisition\<RunName>\
```

5. Set a filename template:

```text
sub-P001_ses-S001_task-PRAYCG_run-001.xdf
```

6. Press **Start** before the protocol sequence begins.
7. Do not close streamer terminals during recording.

## 5.9 Confirm recording quality during run

During setup and baseline, quickly confirm:

```text
[ ] LabRecorder timer is running
[ ] StasisMarkers selected
[ ] EEG selected
[ ] ALS selected
[ ] Polar selected if used
[ ] Vernier selected if used
[ ] No streamer terminal has crashed
```

## 5.10 Stop recording

1. Let PRAYCG2.0 finish and write final logs.
2. Press **Stop** in LabRecorder.
3. Confirm the XDF file exists and has nonzero size.
4. Stop streamer scripts.
5. Copy or move all logs into the acquisition folder.
