# 07 - Master Comprehensive Analysis Suite SOP

## 7.1 Required analysis inputs

Minimum:

```text
XDF file from LabRecorder
PRAYCG events JSON or CSV
Cue schedule JSON
Output folder
```

Strongly recommended:

```text
Run config media-selection JSON
Predeclared anchor JSON/CSV
StimulusFingerprint qc folder
MRED familiarity CSV
MRED scene map CSV
Annotation windows CSV
Self-report JSON files
Confound report JSON files
```

## 7.2 Start the Master Suite GUI

```bat
cd /d C:\PRAYCG\software\MasterSuite_v1_5_5
.venv\Scripts\activate
python scripts\praycg_master_comprehensive_suite_gui_v1_4.py
```

## 7.3 Select inputs in the GUI

1. Select XDF.
2. Select event log JSON or CSV.
3. Select cue schedule JSON.
4. Select predeclared anchor JSON if available.
5. Select StimulusFingerprint folder:

```text
<MediaPrep output>\qc\
```

6. Select familiarity CSV if available.
7. Select scene map CSV if available.
8. Choose output root:

```text
C:\PRAYCG\analysis_outputs\<RunName>\
```

9. Enable full supported suite or the boxed recommended path.

## 7.4 Boxed recommended analysis path

```text
Timing/QC
StimulusFingerprint/CET-R
Artifact/confound gates
A-MRED / MRED-Peak-Resolution
```

Secondary outputs:

```text
NIP/BIT/CII/IAQ
TTI
NUPI
Baseline1 vs Baseline2
```

Exploratory outputs:

```text
KHT-topo
NAST
EET
MRED-ITP/ACG/OCU
OCM025/RSM/CVB/SquintProxy
LSO/SPM if subtitle condition exists
```

## 7.5 Expected output folder

```text
<Master Suite output folder>\
  tables\
    *_time_resolved_feature_frame.csv
    *_amred_anchor_endpoint_table.csv
    mred_peak_resolution_anchor_table.csv
    mred_peak_resolution_run_summary.csv
    *_tti_global_summary.csv
    *_nupi_run_summary.csv
    *_cii_anchor_integrals.csv
    *_cet_residualization_model_summary.csv
    *_mred_itp_anchor_summary.csv
    *_visual_overlay*.csv
  reports\
    offline_interpretation\
  figures\
  logs\
```

## 7.6 Run MRED-Peak / Resolution manually

```bat
python scripts\praycg_mred_peak_resolution_module_v1_5_5.py ^
  --analysis-folder "C:\PRAYCG\analysis_outputs\<RunName>"
```

## 7.7 Run offline interpreter

```bat
python scripts\praycg_offline_interpretive_report_generator_v1_5_5.py ^
  --analysis-folder "C:\PRAYCG\analysis_outputs\<RunName>" ^
  --auto-run-mred-peak-resolution ^
  --run-label "<RunName>"
```

Outputs:

```text
reports\offline_interpretation\offline_interpretive_report.md
reports\offline_interpretation\offline_interpretive_report.txt
reports\offline_interpretation\offline_interpretive_report_summary.json
```

## 7.8 Run visualizer

Public/TSC render:

```bat
python scripts\praycg_master_sync_visualizer_v1_3_5.py ^
  --render-mode public_tsc ^
  --condition target ^
  --xdf "C:\path\to\run.xdf" ^
  --analysis-out "C:\PRAYCG\analysis_outputs\<RunName>" ^
  --video "C:\path\to\stimulus_target_cued.mp4" ^
  --out "C:\PRAYCG\analysis_outputs\<RunName>\visualizer\target_public_tsc.mp4"
```

Lab diagnostic render:

```bat
python scripts\praycg_master_sync_visualizer_v1_3_5.py ^
  --render-mode lab ^
  --condition target ^
  --xdf "C:\path\to\run.xdf" ^
  --analysis-out "C:\PRAYCG\analysis_outputs\<RunName>" ^
  --video "C:\path\to\stimulus_target_cued.mp4" ^
  --out "C:\PRAYCG\analysis_outputs\<RunName>\visualizer\target_lab_diagnostic.mp4"
```

The visualizer creates sidecars such as `features_used.csv`, `events_used.csv`, and a render report. Use them for debugging what actually appeared in the video.
