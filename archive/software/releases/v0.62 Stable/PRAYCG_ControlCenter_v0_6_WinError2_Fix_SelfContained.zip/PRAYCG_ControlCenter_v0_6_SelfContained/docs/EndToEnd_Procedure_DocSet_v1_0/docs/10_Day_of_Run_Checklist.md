# 10 - Day-of-Run Checklist

## Before participant/session

```text
[ ] MediaPrep output exists
[ ] Target video checked
[ ] Override video checked
[ ] Control video checked
[ ] Control audio unintelligible
[ ] Visual watermark/source-stamp QC passed
[ ] Cue schedule JSON/CSV present
[ ] Anchor JSON present and locked or labeled estimated
[ ] StimulusFingerprint qc folder present
[ ] BrainFlow environment opens
[ ] LabRecorder opens
[ ] Polar charged
[ ] Vernier charged
[ ] OpenBCI battery charged
[ ] Cap sponges/saline prepared
[ ] ALS sensor taped and shrouded
[ ] Box/room clear and safe
```

## Stream startup order

```text
1. BrainFlow ALS bridge
2. Polar H10 stream
3. Vernier respiration stream
4. PRAYCG2.0 runner up to StasisMarkers online
5. LabRecorder update/select streams/start recording
6. Continue PRAYCG2.0 protocol
```

## LabRecorder selected streams

```text
[ ] StasisMarkers
[ ] obci_eeg1
[ ] OpenBCIAnalogAux
[ ] ALS_PT19_Timing
[ ] OpenBCIStatusMarkers
[ ] PolarHRV / PolarH10 stream
[ ] VernierRespirationBelt stream
```

## After run

```text
[ ] Stop LabRecorder
[ ] Confirm XDF file exists and is nonzero size
[ ] Save/copy events CSV/JSON
[ ] Save run_config_media_selection.json
[ ] Save self-report JSON files
[ ] Save confound report JSON files
[ ] Save cue schedule JSON/CSV
[ ] Save anchor JSON/CSV
[ ] Save StimulusFingerprint qc folder
[ ] Stop streamers
[ ] Clean cap and hardware
[ ] Back up run folder
```
