# 00 - Start Here: The Whole PRAYCG Pipeline in One Page

## One-sentence workflow

Choose a legally usable, emotionally coherent 3-4.5 minute stimulus; run it through MediaPrep v1.8; verify Target, Override, Control, anchors, cue schedule, ALS timing, and stimulus fingerprints; start BrainFlow/OpenBCI, ALS, Polar, Vernier, and StasisMarkers streams; record everything in LabRecorder as XDF; run PRAYCG2.0; then run the Master Comprehensive Suite and offline interpreter.

## The end-to-end sequence

1. **Select media.** Choose a stimulus with a clear narrative arc, legal/public-use path, suitable duration, low sensory overload, no unavoidable subtitles/watermarks, and plausible predeclared anchors.
2. **Create a stimulus project folder.** Keep the raw source separate from generated outputs.
3. **Run MediaPrep v1.8.** Generate Target, Contextual Override, phase-scrambled Control, cue schedule JSON/CSV, draft anchor files, and StimulusFingerprint/CET/EET QC files.
4. **Run manual media QC.** Watch Target, Override, and Control. Confirm Target/Override match, Control is unintelligible, visual cleanup is acceptable, and the ALS start pulse is visible.
5. **Lock anchors.** Use final rendered Target time, not source-video time. Create `*_LOCKED.json` before the acquisition whenever possible.
6. **Install and set up hardware.** Prepare the Box, OpenBCI gelfree cap, Cyton+Daisy, ALS-PT19, Vernier respiration belt, and Polar H10.
7. **Start streamers.** Run BrainFlow ALS bridge first, then Polar and Vernier streamers if used. Confirm LSL streams are visible.
8. **Start PRAYCG2.0 runner.** Load Control, Target, Override, cue schedule JSON, and locked anchor JSON. Confirm channel map and safe-fit display.
9. **Start LabRecorder.** Select all streams and begin recording after the runner’s StasisMarkers stream is online and before the protocol begins.
10. **Run the protocol.** Complete Baseline 1, Control, Washout 1, Target, Washout 2, Override, Washout 3, final reflection Baseline 2, and final master report.
11. **Stop recording and organize files.** Keep XDF, event logs, self-report JSONs, cue schedule, anchor JSON, MediaPrep QC, and StimulusFingerprint QC together.
12. **Run Master Comprehensive Analysis Suite.** Provide XDF, event log, cue schedule, anchors, StimulusFingerprint folder, familiarity CSV, scene map CSV, and output folder.
13. **Run offline interpreter and visualizer.** Generate plain-language interpretation and synchronized MP4 review if needed.
14. **Grade claim level.** Strict confirmatory requires locked anchors, timing QC, artifact gates, Target > Control, Target > Override, and no confound explanation.

## Current boxed analysis pathway

```text
BOXED PRIMARY PATH:
  Timing/QC
  + StimulusFingerprint/CET-R
  + artifact/confound gates
  -> A-MRED / MRED-Peak-Resolution

SECONDARY:
  NIP / BIT / CII / IAQ
  TTI
  NUPI
  Baseline1 vs Baseline2

EXPLORATORY / CONVERGENCE:
  KHT-topo
  NAST
  EET
  MRED-ITP / ACG / OCU
  OCM025 / RSM / CVB / SquintProxy
  LSO / Subtitle Override when applicable
```
