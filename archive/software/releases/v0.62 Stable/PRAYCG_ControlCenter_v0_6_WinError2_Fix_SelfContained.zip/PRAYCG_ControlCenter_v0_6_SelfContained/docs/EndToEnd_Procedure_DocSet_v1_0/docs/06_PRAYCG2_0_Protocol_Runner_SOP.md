# 06 - PRAYCG2.0 Protocol Runner SOP

## 6.1 Inputs required by PRAYCG2.0

```text
Control video: stimulus_control_cued_phase_scrambled_*.mp4
Target video: stimulus_target_cued_*.mp4
Override video: stimulus_override_cued_*.mp4
Cue schedule JSON: cue_schedule_*.json
Predeclared anchor JSON: *_LOCKED.json preferred
Participant ID
Session ID
Run label
Baseline/washout durations
Safe-fit display settings
Channel-map confirmation
```

## 6.2 Start runner

```bat
cd /d C:\PRAYCG\software\PRAYCG2_0_Runner
.venv\Scripts\activate
python scripts\run_PRAYCG2_0_ConsolidatedSelfReport.py
```

## 6.3 Media selection tab

1. Select Control video.
2. Select Target video.
3. Select Contextual Override video.
4. Select cue schedule JSON.
5. Select predeclared anchor JSON.
6. Confirm Target and Override hash identity if the runner reports it.
7. Confirm cue count and expected sum.
8. Confirm the anchor file hash is recorded.

## 6.4 Display and timing tab

Recommended settings:

```text
Fullscreen: true
Movie display mode: safe_fit
Safe-fit fraction: 0.94
Stillness reset: 8 seconds
Baseline: 120 seconds
Washout: 120 seconds
Final reflection Baseline 2: enabled, 120 seconds
Pre-run display/audio calibration: enabled
Per-phase confound reports: enabled
Override RSM report: enabled
```

## 6.5 Channel map tab

1. Use the PRAYCG16 fixed channel map only if the wiring has been physically traced or photographed.
2. Mark channel map as confirmed only when true.
3. If channel confidence is not locked, analysis may run but ROI-weighted interpretation should be cautioned.

## 6.6 Run sequence

The default PRAYCG2.0 sequence is:

```text
Setup
Pre-run display/audio calibration
Baseline 1
Control instruction
Control video
Washout 1
Control core report + gated confound detail
Target instruction
Target video
Washout 2
Target core report + gated confound detail
Override instruction
Override video
Washout 3
Override core report + Override task report + gated confound detail
Final reflection instruction
Baseline 2
Final master report
End
```

## 6.7 Self-report boundary

Self-report contextualizes the physiological data. It should be used as an independent evidence stream, not as proof of internal state or mechanism.

## 6.8 Output files

The runner typically writes:

```text
PRAYCG_v2_0_<participant>_<session>_<run>_<timestamp>_events.csv
PRAYCG_v2_0_<participant>_<session>_<run>_<timestamp>_events.json
..._events_run_config_media_selection.json
..._events_channel_map.csv
..._events_predeclared_anchors.csv
..._events_prerun_display_audio_calibration.json
..._events_CONTROL_1_AFTER_WASHOUT_1_core_report.json
..._events_TARGET_1_AFTER_WASHOUT_2_core_report.json
..._events_OVERRIDE_1_AFTER_WASHOUT_3_core_report.json
..._events_OVERRIDE_1_AFTER_WASHOUT_3_override_task_report.json
..._events_final_master_report.json
..._events_*_confound_report.json
```

Keep these files with the XDF.
