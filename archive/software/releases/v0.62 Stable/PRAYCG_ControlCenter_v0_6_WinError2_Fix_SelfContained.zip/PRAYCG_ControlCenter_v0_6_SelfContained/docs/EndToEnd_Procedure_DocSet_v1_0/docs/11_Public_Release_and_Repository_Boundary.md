# 11 - Public Release and Repository Boundary

## What can go on GitHub

```text
Code
README files
templates
synthetic demo data
public-safe derived example tables
non-copyright media recipe scripts
hardware build docs
analysis module docs
formulas and method descriptions
```

## What should not go on GitHub

```text
Copyrighted movie clips
Raw XDF from private/self-runs unless deliberately released
Private self-report details
Access tokens
Local passwords
Unredacted participant identifiers
Large binary archives better suited for OSF
```

## What can go on OSF

```text
Frozen ZIP releases
Derived pilot reports
Synthetic demo media
Public-safe example data
Software snapshots
Protocol documents
QC checklists
```

## Labeling examples

```text
Gold-plated but not gold-record:
  best current public-safe demonstration, but not confirmatory.

Runner-registered estimated-anchor pilot:
  anchor loaded, but times not frame-verified.

Frame-verified locked-anchor run:
  anchor times verified on final rendered MP4 and loaded before acquisition.

Exploratory / future-freeze:
  event discovered or refined after analysis.
```

## Public wording

Use:

```text
PRAYCG is an exploratory open-source protocol and analysis architecture for testing state-locked narrative psychophysiology.
```

Do not use:

```text
PRAYCG proves consciousness.
PRAYCG proves OSM biology.
PRAYCG proves memory topology.
PRAYCG proves thermodynamics of meaning.
```
