# 03 - Media Procurement and Stimulus Selection SOP

## 3.1 Legal and ethical selection rules

1. Prefer public-domain, Creative Commons, self-created, or licensed stimuli.
2. Do not upload copyrighted movie clips to GitHub or OSF.
3. If using copyrighted material privately, do not redistribute it with the public repository.
4. Keep the public repository focused on code, templates, synthetic demos, and derived/deidentified outputs.
5. Record source URL, license, duration, and attribution information.

## 3.2 PRAYCG stimulus target profile

Recommended first-pass stimulus:

```text
Duration: 3.0 to 4.5 minutes
Structure: clear beginning, buildup, turn, release
Sound: intelligible dialogue or emotionally meaningful audio
Video: no unavoidable subtitles/watermarks
Pacing: not too chaotic, not too static
Sensory confounds: avoid strobes, rapid flashes, extreme volume swings
Meaning: likely to produce recognition, resolution, awe, repair, grief, or attachment
Novelty: record whether the subject has seen it before
```

## 3.3 Stimulus archetypes

Use the stimulus type to predefine the expected endpoint:

```text
MRED-Peak candidate:
  acute revelation, recognition shock, awe, irreversible line, sudden relational turn.

MRED-Resolution candidate:
  closure, forgiveness, repair, reunion, homecoming, grief release.

Recognition-only candidate:
  familiar scene, meaningful but already known, low novelty.

Override/task-burden candidate:
  visually complex clip where cue addition is difficult.
```

## 3.4 Anchor planning without spoiling novelty

If the subject must remain blind:

1. A separate reviewer or script creates neutral anchor IDs.
2. The subject does not read descriptions.
3. The runner loads `*_BLIND_*_LOCKED.json` or `*_ESTIMATED.json` before acquisition.
4. After the run, reveal the scene map and update interpretation.

For strict confirmatory work:

1. Anchors must be measured on the final rendered Target MP4.
2. Anchor file must be loaded into PRAYCG2.0 before the run.
3. The runner must record the anchor file hash.
4. Anchor status must be recorded as `frame_verified_locked`, not merely `estimated`.

## 3.5 Procurement record template

```text
Project name:
Stimulus title:
Source URL/path:
License/public-use status:
Downloaded by:
Date downloaded:
Raw filename:
Raw duration:
Target excerpt start/end:
Has subtitles/watermark/logo:
Audio language:
Prior subject familiarity:
Planned anchor strategy:
Public sharing allowed? yes/no
Notes:
```
