# 02 - Software Installation and Folder Layout

## 2.1 Recommended Windows folder layout

Use short paths to avoid Windows path-length problems.

```text
C:\PRAYCG\
  software\
    MediaPrep_v1_8\
    PRAYCG2_0_Runner\
    BrainFlow_ALS_v1_4\
    MasterSuite_v1_5_5\
    LabRecorder\
  stimuli\
  acquisition\
  analysis_inputs\
  analysis_outputs\
  exports\
```

Do not bury the project under long `Downloads\...\...` folders. Long paths were already enough to break earlier release ZIP extraction.

## 2.2 Install Python

1. Install Python 3.11 or 3.12 from python.org.
2. During install, check **Add Python to PATH**.
3. Open Command Prompt and verify:

```bat
py -3.11 --version
```

If that fails, try:

```bat
py --version
```

## 2.3 Install MediaPrep v1.8

```bat
cd /d C:\PRAYCG\software\MediaPrep_v1_8
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_PRAYCG_MediaPrep_Protocol_v1_6S.txt
python -m pip install -r requirements_PRAYCG_MediaPrep_StimulusFingerprint_v1_8.txt
```

If the requirements filenames differ in your release folder, run:

```bat
dir requirements*.txt
```

then install each listed requirements file.

## 2.4 Install BrainFlow ALS bridge

```bat
cd /d C:\PRAYCG\software\BrainFlow_ALS_v1_4
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_brainflow_als_pt19_v1_4.txt
python scripts\praycg_check_brainflow_install_v1_4.py
```

## 2.5 Install PRAYCG2.0 runner

```bat
cd /d C:\PRAYCG\software\PRAYCG2_0_Runner
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_PRAYCG2_0.txt
```

Run test:

```bat
python scripts\run_PRAYCG2_0_ConsolidatedSelfReport.py
```

Close it after confirming the GUI opens.

## 2.6 Install Master Comprehensive Suite

```bat
cd /d C:\PRAYCG\software\MasterSuite_v1_5_5
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements*.txt
```

If Windows does not expand `requirements*.txt`, install each requirement file shown by:

```bat
dir requirements*.txt
```

## 2.7 Install LabRecorder

1. Download LabRecorder for Windows from the Lab Streaming Layer/App-LabRecorder release page.
2. Extract into:

```text
C:\PRAYCG\software\LabRecorder\
```

3. Launch `LabRecorder.exe` once to confirm it opens.
4. Set your study root to:

```text
C:\PRAYCG\acquisition\
```

## 2.8 Optional: create run folders before each session

For a run named `Field_Run2`:

```bat
mkdir C:\PRAYCG\stimuli\Field_Run2
mkdir C:\PRAYCG\acquisition\Field_Run2
mkdir C:\PRAYCG\analysis_inputs\Field_Run2
mkdir C:\PRAYCG\analysis_outputs\Field_Run2
```
