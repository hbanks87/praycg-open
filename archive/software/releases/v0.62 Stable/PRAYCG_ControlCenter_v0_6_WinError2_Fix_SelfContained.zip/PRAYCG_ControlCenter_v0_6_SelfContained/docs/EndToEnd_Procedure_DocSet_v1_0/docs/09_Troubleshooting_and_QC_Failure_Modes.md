# 09 - Troubleshooting and QC Failure Modes

## 9.1 OpenBCI COM port cannot open

Likely cause: another program owns the port.

Fix:

```text
[ ] Close OpenBCI GUI
[ ] Close Arduino serial monitor
[ ] Close old BrainFlow terminals
[ ] Unplug/replug dongle
[ ] Re-run COM identifier
```

## 9.2 ALS stream flat

Check:

```text
[ ] ALS OUT -> D12/A6
[ ] ALS + -> DVDD/3V3
[ ] ALS - -> GND
[ ] --enable-analog-aux was used
[ ] --publish-als-stream was used
[ ] --als-aux-channel 1 for D12/A6
[ ] Sensor is over timing square
[ ] Sensor is shrouded from room light
[ ] Video contains start pulse
```

## 9.3 LabRecorder does not show stream

1. Click **Update**.
2. Confirm streamer terminal is still running.
3. Confirm no VPN/firewall is blocking local multicast.
4. Restart LabRecorder after streams are already active.
5. Run LSL stream listing script.

## 9.4 Control audio is intelligible

Do not use the run as clean. Mark it:

```text
PILOT ONLY / CONTROL AUDIO FAIL
```

Regenerate Control with stricter audio scrambling or choose a different source.

## 9.5 Anchor file not loaded

If no anchor file was loaded into the runner, the result may still be scientifically interesting, but it is not runner-registered confirmatory.

Correct label:

```text
conceptually predeclared / not runner-registered
```

or:

```text
exploratory / future-freeze candidate
```

## 9.6 Estimated anchor file loaded

If the anchor file was loaded but not frame-verified:

```text
runner-registered estimated-anchor pilot
```

not:

```text
strict frame-verified confirmatory
```

## 9.7 Gamma artifact concern

Never interpret gamma alone. Gamma is an artifact-sensitive work-signal proxy. Require artifact gates, theta/topological carryover, condition specificity, and CET-R/stimulus controls.

## 9.8 Missing feature table

Run Master Comprehensive Suite. The visualizer sidecar `features_used.csv` is not a substitute for the canonical feature table.

## 9.9 Missing MRED familiarity or scene map CSV

Copy the template and fill it manually. These are analysis covariates, not raw acquisition outputs.

## 9.10 Field run timing caution example

A run may be useful but not confirmatory if:

```text
[ ] anchor file was estimated, not frame-verified
[ ] ALS start pulse did not pass all branches
[ ] continuous stream timing required reconstruction
```

The correct posture is to keep the run as pilot-positive or hypothesis-generating and rerun with stricter timing.
