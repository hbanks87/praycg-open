# PRAYCG End-to-End Procedure Doc Set v1.0

This package contains a practical SOP from media procurement to Master Comprehensive analysis.

Main file:

```text
PRAYCG_End_to_End_Procedure_Manual_v1_0.pdf
PRAYCG_End_to_End_Procedure_Manual_v1_0.docx
PRAYCG_End_to_End_Procedure_Manual_v1_0.md
```

Individual modular docs are in `docs/`.

Checklists are in `checklists/`.
