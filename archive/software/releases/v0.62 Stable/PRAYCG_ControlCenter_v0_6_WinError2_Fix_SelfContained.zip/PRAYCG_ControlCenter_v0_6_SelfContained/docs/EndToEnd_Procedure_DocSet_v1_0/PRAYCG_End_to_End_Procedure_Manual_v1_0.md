
# PRAYCG End-to-End Procedure Manual v1.0

**Full workflow from media procurement to Master Comprehensive analysis**  
Prepared for the PRAYCG2.0 / MediaPrep v1.8 / Master Comprehensive Suite v1.5.5+ workflow.  
Date: 2026-08-18

## Claim boundary

PRAYCG is an exploratory psychophysiology protocol and open-source methods architecture. It does not prove consciousness, memory biology, clinical efficacy, OSM biology, microtubules, biophotons, or metaphysical claims. It asks a narrower empirical question: when meaning is accessible, does the body-brain system show a measurable state trajectory that differs from matched sensory control and from the same intact story under analytic task stance?

## Safety boundary

This manual is not medical advice, clinical guidance, or an electrical-safety certification. Follow manufacturer manuals for all hardware. Do not connect any participant or biosensing lead directly to building ground, mains power, or an untested Faraday enclosure. Any earth-grounding, mains wiring, or enclosure modification should be inspected by a qualified electrician or competent safety reviewer.


# 00 - Start Here: The Whole PRAYCG Pipeline in One Page

## One-sentence workflow

Choose a legally usable, emotionally coherent 3-4.5 minute stimulus; run it through MediaPrep v1.8; verify Target, Override, Control, anchors, cue schedule, ALS timing, and stimulus fingerprints; start BrainFlow/OpenBCI, ALS, Polar, Vernier, and StasisMarkers streams; record everything in LabRecorder as XDF; run PRAYCG2.0; then run the Master Comprehensive Suite and offline interpreter.

## The end-to-end sequence

1. **Select media.** Choose a stimulus with a clear narrative arc, legal/public-use path, suitable duration, low sensory overload, no unavoidable subtitles/watermarks, and plausible predeclared anchors.
2. **Create a stimulus project folder.** Keep the raw source separate from generated outputs.
3. **Run MediaPrep v1.8.** Generate Target, Contextual Override, phase-scrambled Control, cue schedule JSON/CSV, draft anchor files, and StimulusFingerprint/CET/EET QC files.
4. **Run manual media QC.** Watch Target, Override, and Control. Confirm Target/Override match, Control is unintelligible, visual cleanup is acceptable, and the ALS start pulse is visible.
5. **Lock anchors.** Use final rendered Target time, not source-video time. Create `*_LOCKED.json` before the acquisition whenever possible.
6. **Install and set up hardware.** Prepare the Box, OpenBCI gelfree cap, Cyton+Daisy, ALS-PT19, Vernier respiration belt, and Polar H10.
7. **Start streamers.** Run BrainFlow ALS bridge first, then Polar and Vernier streamers if used. Confirm LSL streams are visible.
8. **Start PRAYCG2.0 runner.** Load Control, Target, Override, cue schedule JSON, and locked anchor JSON. Confirm channel map and safe-fit display.
9. **Start LabRecorder.** Select all streams and begin recording after the runner’s StasisMarkers stream is online and before the protocol begins.
10. **Run the protocol.** Complete Baseline 1, Control, Washout 1, Target, Washout 2, Override, Washout 3, final reflection Baseline 2, and final master report.
11. **Stop recording and organize files.** Keep XDF, event logs, self-report JSONs, cue schedule, anchor JSON, MediaPrep QC, and StimulusFingerprint QC together.
12. **Run Master Comprehensive Analysis Suite.** Provide XDF, event log, cue schedule, anchors, StimulusFingerprint folder, familiarity CSV, scene map CSV, and output folder.
13. **Run offline interpreter and visualizer.** Generate plain-language interpretation and synchronized MP4 review if needed.
14. **Grade claim level.** Strict confirmatory requires locked anchors, timing QC, artifact gates, Target > Control, Target > Override, and no confound explanation.

## Current boxed analysis pathway

```text
BOXED PRIMARY PATH:
  Timing/QC
  + StimulusFingerprint/CET-R
  + artifact/confound gates
  -> A-MRED / MRED-Peak-Resolution

SECONDARY:
  NIP / BIT / CII / IAQ
  TTI
  NUPI
  Baseline1 vs Baseline2

EXPLORATORY / CONVERGENCE:
  KHT-topo
  NAST
  EET
  MRED-ITP / ACG / OCU
  OCM025 / RSM / CVB / SquintProxy
  LSO / Subtitle Override when applicable
```

---

# 01 - Hardware Setup and Safety SOP

## 1.1 Hardware list

Minimum PRAYCG2.0 acquisition stack:

- A stimulus laptop capable of fullscreen playback.
- OpenBCI Cyton + Daisy with USB dongle.
- OpenBCI gelfree electrode cap, HPTA adapters, saline solution, Hydro-link inserts, reference and ground connections.
- ALS-PT19 or equivalent analog light sensor for physical display timing.
- Vernier Go Direct Respiration Belt or equivalent respiration stream.
- Polar H10 or equivalent R-R interval stream.
- LabRecorder for XDF recording.
- Optional enclosure/Box/Faraday chamber for environmental consistency.

## 1.2 The Box / Stasis Chamber

The Box is an environmental-control apparatus. Its purpose is to reduce uncontrolled environmental noise and standardize the measurement setting. It is not a medical device and not a proof device.

### Build/inspection steps

1. **Inspect the physical frame.** Confirm that the frame is stable, cannot collapse, and provides a clear exit path.
2. **Inspect the floor.** If a conductive floor or mesh is used, make sure there is a dielectric layer between participant and any conductive surface.
3. **Inspect seams.** Conductive mesh seams should be mechanically overlapped and electrically continuous if the enclosure is intended to function as a Faraday shield.
4. **Grounding review.** Any earth-ground rod, building-ground connection, or lightning/surge concern should be reviewed by a qualified person. Do not improvise mains-ground wiring.
5. **Cable pass-throughs.** Route power, USB, sensor, and display cables so they do not create trip hazards or exert pull on sensors.
6. **Ventilation and comfort.** Verify temperature, air flow, chair stability, lighting, and emergency exit.
7. **Device power.** Prefer battery-powered acquisition equipment. Keep mains adapters and power strips outside the participant’s direct contact area when possible.
8. **Documentation.** Photograph the final layout, cable paths, and equipment placement before each major hardware revision.

### Pre-run Box checklist

```text
[ ] Clear participant exit path
[ ] No exposed conductor near participant skin
[ ] No trip hazards
[ ] Chair stable
[ ] Screen visible and centered
[ ] ALS sensor taped over timing square
[ ] Cap leads strain-relieved
[ ] Respiration belt not too tight
[ ] Polar H10 comfortable
[ ] Laptop volume checked
[ ] LabRecorder save path checked
```

## 1.3 OpenBCI Cyton + Daisy

### Physical setup

1. Charge or install the battery pack.
2. Seat the Daisy module on the Cyton carefully and check pin alignment.
3. Insert the OpenBCI USB dongle into the acquisition laptop.
4. Turn on the board and confirm the board/dongle connection.
5. Identify the COM port before opening any acquisition script.
6. Do **not** open the OpenBCI GUI while BrainFlow is using the same COM port.

### Reference and BIAS convention

1. Use the Cyton+Daisy Y-splitter to gang the bottom SRB pins of Cyton and Daisy.
2. Connect the single end of the Y-splitter to the cap REF location.
3. Connect the bottom BIAS pin of the Cyton to the cap GND location.
4. Connect channels 1-8 to Cyton bottom pins N1P-N8P.
5. Connect channels 9-16 to Daisy bottom pins N1P-N8P.
6. Photograph or physically trace the map before marking the channel map as confirmed.

### PRAYCG16 channel map discipline

Use the same fixed channel order every run unless a new version is explicitly created. If you change the electrode-to-channel map, save a new channel map file and do not compare ROI-weighted outputs to old runs without caution.

## 1.4 OpenBCI gelfree cap

### Prepare the cap

1. Make saline solution according to the cap guide: fill beaker with water, mix in salt, and soak Hydro-link inserts.
2. Place the cap on the subject’s head and align 10-20 landmarks.
3. Insert soaked Hydro-link inserts into the electrode holders.
4. Connect REF and GND before connecting analysis channels.
5. Connect the planned 16 channel electrodes to Cyton/Daisy pins.
6. Check that cables have slack and are not pulling the cap.
7. If using OpenBCI GUI only for impedance preview, close the GUI before starting BrainFlow.

### Signal check

1. Run a short OpenBCI/BrainFlow test.
2. Look for obvious flatlines, saturated channels, repeated packet issues, or huge motion artifacts.
3. Ask the subject to blink, clench jaw, and relax; observe whether frontal/temporal artifact channels respond as expected.
4. Save a screenshot or log of the channel map and signal sanity check.

## 1.5 ALS-PT19 light sensor

### KISS wiring used by the current PRAYCG BrainFlow ALS bridge

```text
ALS-PT19 +      -> Cyton DVDD / 3V3
ALS-PT19 -      -> Cyton GND
ALS-PT19 OUT    -> Cyton D12 / A6
```

Default analog AUX channel in the bridge:

```text
--als-aux-channel 1
```

because the script maps analog channels as:

```text
0 = A5 / D11
1 = A6 / D12  <- ALS-PT19 default
2 = A7 / D13
```

### Placement

1. Run MediaPrep with fullscreen ALS start pulse or timing-square pulse enabled.
2. Tape the ALS sensor directly over the timing square/pulse region.
3. Use black electrical tape or an opaque shroud so room light does not dominate the signal.
4. Confirm the sensor does not cover the number cue or a critical narrative region.
5. Run the ALS watchdog before the real protocol.

### Pass rule

Target, Override, and Control should all produce a visible pulse at video start, with no full-duration clipping and no missed start pulse.

## 1.6 Vernier Go Direct Respiration Belt

### Setup

1. Charge the belt before first use.
2. Power it on and confirm the LED is active.
3. Place it around the chest or abdomen over clothing.
4. For best results, position the sensor box just below the sternum.
5. Tighten until the tension indicator is green. Loosen if it turns red.
6. Connect to Graphical Analysis or the PRAYCG Vernier LSL bridge if available.
7. Confirm respiration force/rate stream is visible before starting LabRecorder.

### Run check

1. Ask the subject to breathe normally for 30-60 seconds.
2. Confirm the signal rises on inhalation and falls on exhalation.
3. Confirm it is not flat and not saturated.
4. Mark it as available or unavailable before running analysis.

## 1.7 Polar H10

### Setup

1. Wet the strap electrode areas.
2. Attach the H10 sensor to the strap.
3. Place strap snugly around the chest, below the pectoral muscles.
4. Pair to your Polar/LSL streamer, not to a phone app that will monopolize the sensor.
5. Confirm heart rate and R-R interval notifications are being received.
6. Confirm the LSL stream appears before recording.

### Run check

1. Verify stable HR and R-R intervals for at least 60 seconds.
2. Re-seat the strap if HR is zero, implausible, or intermittent.
3. Keep the phone Bluetooth connection off unless it is the intended capture device.

## 1.8 Hardware shutdown

1. Stop LabRecorder.
2. Stop PRAYCG runner.
3. Stop BrainFlow bridge and confirm it releases the COM port.
4. Stop Polar/Vernier streamers.
5. Turn off OpenBCI board.
6. Remove cap, remove Hydro-link inserts, rinse/dry according to cap instructions.
7. Dry and store the ALS sensor and cables.
8. Charge Polar/Vernier if needed.

---

# 02 - Software Installation and Folder Layout

## 2.1 Recommended Windows folder layout

Use short paths to avoid Windows path-length problems.

```text
C:\PRAYCG\
  software\
    MediaPrep_v1_8\
    PRAYCG2_0_Runner\
    BrainFlow_ALS_v1_4\
    MasterSuite_v1_5_5\
    LabRecorder\
  stimuli\
  acquisition\
  analysis_inputs\
  analysis_outputs\
  exports\
```

Do not bury the project under long `Downloads\...\...` folders. Long paths were already enough to break earlier release ZIP extraction.

## 2.2 Install Python

1. Install Python 3.11 or 3.12 from python.org.
2. During install, check **Add Python to PATH**.
3. Open Command Prompt and verify:

```bat
py -3.11 --version
```

If that fails, try:

```bat
py --version
```

## 2.3 Install MediaPrep v1.8

```bat
cd /d C:\PRAYCG\software\MediaPrep_v1_8
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_PRAYCG_MediaPrep_Protocol_v1_6S.txt
python -m pip install -r requirements_PRAYCG_MediaPrep_StimulusFingerprint_v1_8.txt
```

If the requirements filenames differ in your release folder, run:

```bat
dir requirements*.txt
```

then install each listed requirements file.

## 2.4 Install BrainFlow ALS bridge

```bat
cd /d C:\PRAYCG\software\BrainFlow_ALS_v1_4
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_brainflow_als_pt19_v1_4.txt
python scripts\praycg_check_brainflow_install_v1_4.py
```

## 2.5 Install PRAYCG2.0 runner

```bat
cd /d C:\PRAYCG\software\PRAYCG2_0_Runner
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_PRAYCG2_0.txt
```

Run test:

```bat
python scripts\run_PRAYCG2_0_ConsolidatedSelfReport.py
```

Close it after confirming the GUI opens.

## 2.6 Install Master Comprehensive Suite

```bat
cd /d C:\PRAYCG\software\MasterSuite_v1_5_5
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements*.txt
```

If Windows does not expand `requirements*.txt`, install each requirement file shown by:

```bat
dir requirements*.txt
```

## 2.7 Install LabRecorder

1. Download LabRecorder for Windows from the Lab Streaming Layer/App-LabRecorder release page.
2. Extract into:

```text
C:\PRAYCG\software\LabRecorder\
```

3. Launch `LabRecorder.exe` once to confirm it opens.
4. Set your study root to:

```text
C:\PRAYCG\acquisition\
```

## 2.8 Optional: create run folders before each session

For a run named `Field_Run2`:

```bat
mkdir C:\PRAYCG\stimuli\Field_Run2
mkdir C:\PRAYCG\acquisition\Field_Run2
mkdir C:\PRAYCG\analysis_inputs\Field_Run2
mkdir C:\PRAYCG\analysis_outputs\Field_Run2
```

---

# 03 - Media Procurement and Stimulus Selection SOP

## 3.1 Legal and ethical selection rules

1. Prefer public-domain, Creative Commons, self-created, or licensed stimuli.
2. Do not upload copyrighted movie clips to GitHub or OSF.
3. If using copyrighted material privately, do not redistribute it with the public repository.
4. Keep the public repository focused on code, templates, synthetic demos, and derived/deidentified outputs.
5. Record source URL, license, duration, and attribution information.

## 3.2 PRAYCG stimulus target profile

Recommended first-pass stimulus:

```text
Duration: 3.0 to 4.5 minutes
Structure: clear beginning, buildup, turn, release
Sound: intelligible dialogue or emotionally meaningful audio
Video: no unavoidable subtitles/watermarks
Pacing: not too chaotic, not too static
Sensory confounds: avoid strobes, rapid flashes, extreme volume swings
Meaning: likely to produce recognition, resolution, awe, repair, grief, or attachment
Novelty: record whether the subject has seen it before
```

## 3.3 Stimulus archetypes

Use the stimulus type to predefine the expected endpoint:

```text
MRED-Peak candidate:
  acute revelation, recognition shock, awe, irreversible line, sudden relational turn.

MRED-Resolution candidate:
  closure, forgiveness, repair, reunion, homecoming, grief release.

Recognition-only candidate:
  familiar scene, meaningful but already known, low novelty.

Override/task-burden candidate:
  visually complex clip where cue addition is difficult.
```

## 3.4 Anchor planning without spoiling novelty

If the subject must remain blind:

1. A separate reviewer or script creates neutral anchor IDs.
2. The subject does not read descriptions.
3. The runner loads `*_BLIND_*_LOCKED.json` or `*_ESTIMATED.json` before acquisition.
4. After the run, reveal the scene map and update interpretation.

For strict confirmatory work:

1. Anchors must be measured on the final rendered Target MP4.
2. Anchor file must be loaded into PRAYCG2.0 before the run.
3. The runner must record the anchor file hash.
4. Anchor status must be recorded as `frame_verified_locked`, not merely `estimated`.

## 3.5 Procurement record template

```text
Project name:
Stimulus title:
Source URL/path:
License/public-use status:
Downloaded by:
Date downloaded:
Raw filename:
Raw duration:
Target excerpt start/end:
Has subtitles/watermark/logo:
Audio language:
Prior subject familiarity:
Planned anchor strategy:
Public sharing allowed? yes/no
Notes:
```

---

# 04 - MediaPrep v1.8 and StimulusFingerprint SOP

## 4.1 Purpose

MediaPrep creates the three stimulus arms and the stimulus-side QC files. It prepares media; it does not certify physiological claims.

Generated arms:

```text
Target: intact cue-embedded narrative watched naturally.
Contextual Override: same cue-embedded video as Target, different instructions.
Control: phase-scrambled version generated from cue-embedded Target.
```

## 4.2 Run MediaPrep GUI

```bat
cd /d C:\PRAYCG\software\MediaPrep_v1_8
.venv\Scripts\activate
py -3.11 scripts\run_PRAYCG_MediaPrep_v1_8.py
```

If your active Python is already inside the venv:

```bat
python scripts\run_PRAYCG_MediaPrep_v1_8.py
```

## 4.3 Recommended MediaPrep settings

```text
Project name: short, no spaces if possible
Input video: final raw source excerpt MP4
Output root: C:\PRAYCG\stimuli\<RunName>\MediaPrep_Output
Cue seed: fixed project seed unless intentionally changed
Cue interval: 3.0 s
Cue display duration: 0.85 s
Cue position: upper_right
Contrast-protected badge: enabled
Fullscreen ALS start pulse: enabled
Generate DRAFT anchor schedule: enabled
Run StimulusFingerprint after media generation: enabled
```

## 4.4 Expected MediaPrep outputs

Typical output folder:

```text
<project>_MediaPrep_v1_8_<timestamp>\
  stimulus_master_cleaned_<project>_v1_8.mp4
  stimulus_target_cued_<project>_v1_8.mp4
  stimulus_override_cued_<project>_v1_8.mp4
  stimulus_control_cued_phase_scrambled_<project>_v1_8.mp4
  cue_schedule_<project>_v1_8.json
  cue_schedule_<project>_v1_8.csv
  predeclared_anchors_<project>_DRAFT.json
  predeclared_anchors_<project>_DRAFT.csv
  ANCHOR_LOCK_CHECKLIST_<project>.md
  qc\
    stimulus_exogenous_regressor_frame_all_conditions.csv
    cet_regressors_all_conditions.csv
    stimulus_rhythm_summary_all_conditions.csv
    stimulus_dominant_frequency_timeseries_all_conditions.csv
    anchor_stimulus_rhythm_vectors_all_conditions.csv
    stimulusfingerprint_branch_status.csv
    stimulusfingerprint_error_log.json
    stimulusfingerprint_cet_eet_manifest.json
    stimulusfingerprint_cet_eet_report.md
```

## 4.5 Manual video QC

Open all three generated videos.

```text
[ ] Target plays full length
[ ] Override plays full length
[ ] Control plays full length
[ ] Target and Override are visually identical except instructions differ outside video
[ ] Target and Override SHA-256 match if designed to be identical
[ ] Control is phase-scrambled and not narratively recognizable
[ ] Cue badge is visible and not too small
[ ] Cue badge does not cover a critical face/line when avoidable
[ ] Fullscreen or timing-square ALS pulse appears at start
[ ] No readable watermark/source stamp remains unless intentionally documented
```

## 4.6 Manual control-audio QC

Listen to the full Control using the same speaker/headphone settings as the protocol.

Pass only if:

```text
[ ] No recognizable spoken words
[ ] No intelligible sentence fragments
[ ] No distinct melody that reveals the source
[ ] Loudness/envelope broadly tracks original
[ ] Sounds like speech-shaped/scene-shaped noise, not dialogue
```

## 4.7 Lock anchors

Use final rendered Target time, not source-video time.

```bat
python scripts\praycg_anchor_lock_finalizer_v1_7A.py ^
  --draft "C:\path\to\predeclared_anchors_<project>_DRAFT.json"
```

The finalizer writes:

```text
predeclared_anchors_<project>_LOCKED.json
predeclared_anchors_<project>_LOCKED.csv
predeclared_anchors_<project>_LOCKED_manifest.json
```

Load the `*_LOCKED.json` in PRAYCG2.0. If the file is estimated or not frame-verified, mark the run as pilot/estimated-anchor rather than strict confirmatory.

## 4.8 Rerun StimulusFingerprint on existing folder

```bat
py -3.11 scripts\praycg_batch_stimulus_fingerprint_v1_8.py ^
  --mediaprep-folder "C:\PRAYCG\stimuli\<RunName>\MediaPrep_Output\<project>_MediaPrep_v1_8_<timestamp>" ^
  --project-name "<RunName>"
```

The branch status file should report PASS for Control, Target, and Override before you rely on full CET-R.

---

# 05 - BrainFlow, ALS Streamer, LSL, and LabRecorder SOP

## 5.1 Core rule

Do not run the OpenBCI GUI and BrainFlow bridge at the same time. Both want exclusive control of the OpenBCI COM port.

## 5.2 Start BrainFlow ALS bridge

Open Command Prompt:

```bat
cd /d C:\PRAYCG\software\BrainFlow_ALS_v1_4
.venv\Scripts\activate
```

Identify the OpenBCI dongle port:

```bat
python scripts\praycg_identify_openbci_port_v1_4.py --watch
```

Start the bridge, replacing `COM3` with your actual port:

```bat
python scripts\praycg_openbci_brainflow_als_pt19_bridge_v1_4.py ^
  --board cyton-daisy ^
  --serial-port COM3 ^
  --enable-analog-aux ^
  --publish-als-stream ^
  --confirmed-channel-map
```

Expected LSL streams from the bridge:

```text
obci_eeg1              EEG, 16 channels
OpenBCIAnalogAux       raw analog AUX, 3 channels
ALS_PT19_Timing        extracted ALS timing stream
OpenBCIStatusMarkers   heartbeat/status markers
```

## 5.3 Confirm LSL stream visibility

In a second Command Prompt:

```bat
cd /d C:\PRAYCG\software\BrainFlow_ALS_v1_4
.venv\Scripts\activate
python scripts\praycg_list_lsl_streams_v1_4.py
```

Expected minimum streams before running the protocol:

```text
obci_eeg1
OpenBCIAnalogAux
ALS_PT19_Timing
OpenBCIStatusMarkers
```

After starting PRAYCG2.0, you should also see:

```text
StasisMarkers
```

If Polar/Vernier are running, expect their streams too.

## 5.4 ALS pulse watchdog

Run this before the real recording:

```bat
python scripts\praycg_als_pt19_light_watchdog_v1_4.py --duration 30 --expected-pulses 1
```

Then play the first 10 seconds of Target video. You want a strong rise and return to baseline. Repeat or inspect Control and Override if possible.

## 5.5 Start Polar H10 streamer

1. Put on the Polar H10 and verify skin contact.
2. Run your Polar-to-LSL script or approved app.
3. Confirm a stream such as `PolarHRV`, `PolarH10`, or `PolarH10_RR` appears.
4. Confirm HR and R-R intervals are nonzero and plausible.

If the Polar stream does not appear, close phone apps that may own the Bluetooth connection, rewet strap, and restart the streamer.

## 5.6 Start Vernier respiration streamer

1. Fit and turn on the Go Direct Respiration Belt.
2. Use Graphical Analysis or your Vernier-to-LSL bridge.
3. Confirm respiration force/rate data are updating.
4. Confirm a stream such as `VernierRespirationBelt` appears in LSL.

## 5.7 Start PRAYCG2.0 until StasisMarkers are online

Run:

```bat
cd /d C:\PRAYCG\software\PRAYCG2_0_Runner
.venv\Scripts\activate
python scripts\run_PRAYCG2_0_ConsolidatedSelfReport.py
```

Load media files and configuration, then stop at the point where the runner indicates StasisMarkers are online and LabRecorder should be started.

## 5.8 Configure LabRecorder

1. Open `LabRecorder.exe`.
2. Click **Update** until all streams appear.
3. Select:

```text
StasisMarkers
obci_eeg1
OpenBCIAnalogAux
ALS_PT19_Timing
OpenBCIStatusMarkers
PolarHRV / PolarH10 / RR stream, if available
VernierRespirationBelt, if available
```

4. Set Study Root:

```text
C:\PRAYCG\acquisition\<RunName>\
```

5. Set a filename template:

```text
sub-P001_ses-S001_task-PRAYCG_run-001.xdf
```

6. Press **Start** before the protocol sequence begins.
7. Do not close streamer terminals during recording.

## 5.9 Confirm recording quality during run

During setup and baseline, quickly confirm:

```text
[ ] LabRecorder timer is running
[ ] StasisMarkers selected
[ ] EEG selected
[ ] ALS selected
[ ] Polar selected if used
[ ] Vernier selected if used
[ ] No streamer terminal has crashed
```

## 5.10 Stop recording

1. Let PRAYCG2.0 finish and write final logs.
2. Press **Stop** in LabRecorder.
3. Confirm the XDF file exists and has nonzero size.
4. Stop streamer scripts.
5. Copy or move all logs into the acquisition folder.

---

# 06 - PRAYCG2.0 Protocol Runner SOP

## 6.1 Inputs required by PRAYCG2.0

```text
Control video: stimulus_control_cued_phase_scrambled_*.mp4
Target video: stimulus_target_cued_*.mp4
Override video: stimulus_override_cued_*.mp4
Cue schedule JSON: cue_schedule_*.json
Predeclared anchor JSON: *_LOCKED.json preferred
Participant ID
Session ID
Run label
Baseline/washout durations
Safe-fit display settings
Channel-map confirmation
```

## 6.2 Start runner

```bat
cd /d C:\PRAYCG\software\PRAYCG2_0_Runner
.venv\Scripts\activate
python scripts\run_PRAYCG2_0_ConsolidatedSelfReport.py
```

## 6.3 Media selection tab

1. Select Control video.
2. Select Target video.
3. Select Contextual Override video.
4. Select cue schedule JSON.
5. Select predeclared anchor JSON.
6. Confirm Target and Override hash identity if the runner reports it.
7. Confirm cue count and expected sum.
8. Confirm the anchor file hash is recorded.

## 6.4 Display and timing tab

Recommended settings:

```text
Fullscreen: true
Movie display mode: safe_fit
Safe-fit fraction: 0.94
Stillness reset: 8 seconds
Baseline: 120 seconds
Washout: 120 seconds
Final reflection Baseline 2: enabled, 120 seconds
Pre-run display/audio calibration: enabled
Per-phase confound reports: enabled
Override RSM report: enabled
```

## 6.5 Channel map tab

1. Use the PRAYCG16 fixed channel map only if the wiring has been physically traced or photographed.
2. Mark channel map as confirmed only when true.
3. If channel confidence is not locked, analysis may run but ROI-weighted interpretation should be cautioned.

## 6.6 Run sequence

The default PRAYCG2.0 sequence is:

```text
Setup
Pre-run display/audio calibration
Baseline 1
Control instruction
Control video
Washout 1
Control core report + gated confound detail
Target instruction
Target video
Washout 2
Target core report + gated confound detail
Override instruction
Override video
Washout 3
Override core report + Override task report + gated confound detail
Final reflection instruction
Baseline 2
Final master report
End
```

## 6.7 Self-report boundary

Self-report contextualizes the physiological data. It should be used as an independent evidence stream, not as proof of internal state or mechanism.

## 6.8 Output files

The runner typically writes:

```text
PRAYCG_v2_0_<participant>_<session>_<run>_<timestamp>_events.csv
PRAYCG_v2_0_<participant>_<session>_<run>_<timestamp>_events.json
..._events_run_config_media_selection.json
..._events_channel_map.csv
..._events_predeclared_anchors.csv
..._events_prerun_display_audio_calibration.json
..._events_CONTROL_1_AFTER_WASHOUT_1_core_report.json
..._events_TARGET_1_AFTER_WASHOUT_2_core_report.json
..._events_OVERRIDE_1_AFTER_WASHOUT_3_core_report.json
..._events_OVERRIDE_1_AFTER_WASHOUT_3_override_task_report.json
..._events_final_master_report.json
..._events_*_confound_report.json
```

Keep these files with the XDF.

---

# 07 - Master Comprehensive Analysis Suite SOP

## 7.1 Required analysis inputs

Minimum:

```text
XDF file from LabRecorder
PRAYCG events JSON or CSV
Cue schedule JSON
Output folder
```

Strongly recommended:

```text
Run config media-selection JSON
Predeclared anchor JSON/CSV
StimulusFingerprint qc folder
MRED familiarity CSV
MRED scene map CSV
Annotation windows CSV
Self-report JSON files
Confound report JSON files
```

## 7.2 Start the Master Suite GUI

```bat
cd /d C:\PRAYCG\software\MasterSuite_v1_5_5
.venv\Scripts\activate
python scripts\praycg_master_comprehensive_suite_gui_v1_4.py
```

## 7.3 Select inputs in the GUI

1. Select XDF.
2. Select event log JSON or CSV.
3. Select cue schedule JSON.
4. Select predeclared anchor JSON if available.
5. Select StimulusFingerprint folder:

```text
<MediaPrep output>\qc\
```

6. Select familiarity CSV if available.
7. Select scene map CSV if available.
8. Choose output root:

```text
C:\PRAYCG\analysis_outputs\<RunName>\
```

9. Enable full supported suite or the boxed recommended path.

## 7.4 Boxed recommended analysis path

```text
Timing/QC
StimulusFingerprint/CET-R
Artifact/confound gates
A-MRED / MRED-Peak-Resolution
```

Secondary outputs:

```text
NIP/BIT/CII/IAQ
TTI
NUPI
Baseline1 vs Baseline2
```

Exploratory outputs:

```text
KHT-topo
NAST
EET
MRED-ITP/ACG/OCU
OCM025/RSM/CVB/SquintProxy
LSO/SPM if subtitle condition exists
```

## 7.5 Expected output folder

```text
<Master Suite output folder>\
  tables\
    *_time_resolved_feature_frame.csv
    *_amred_anchor_endpoint_table.csv
    mred_peak_resolution_anchor_table.csv
    mred_peak_resolution_run_summary.csv
    *_tti_global_summary.csv
    *_nupi_run_summary.csv
    *_cii_anchor_integrals.csv
    *_cet_residualization_model_summary.csv
    *_mred_itp_anchor_summary.csv
    *_visual_overlay*.csv
  reports\
    offline_interpretation\
  figures\
  logs\
```

## 7.6 Run MRED-Peak / Resolution manually

```bat
python scripts\praycg_mred_peak_resolution_module_v1_5_5.py ^
  --analysis-folder "C:\PRAYCG\analysis_outputs\<RunName>"
```

## 7.7 Run offline interpreter

```bat
python scripts\praycg_offline_interpretive_report_generator_v1_5_5.py ^
  --analysis-folder "C:\PRAYCG\analysis_outputs\<RunName>" ^
  --auto-run-mred-peak-resolution ^
  --run-label "<RunName>"
```

Outputs:

```text
reports\offline_interpretation\offline_interpretive_report.md
reports\offline_interpretation\offline_interpretive_report.txt
reports\offline_interpretation\offline_interpretive_report_summary.json
```

## 7.8 Run visualizer

Public/TSC render:

```bat
python scripts\praycg_master_sync_visualizer_v1_3_5.py ^
  --render-mode public_tsc ^
  --condition target ^
  --xdf "C:\path\to\run.xdf" ^
  --analysis-out "C:\PRAYCG\analysis_outputs\<RunName>" ^
  --video "C:\path\to\stimulus_target_cued.mp4" ^
  --out "C:\PRAYCG\analysis_outputs\<RunName>\visualizer\target_public_tsc.mp4"
```

Lab diagnostic render:

```bat
python scripts\praycg_master_sync_visualizer_v1_3_5.py ^
  --render-mode lab ^
  --condition target ^
  --xdf "C:\path\to\run.xdf" ^
  --analysis-out "C:\PRAYCG\analysis_outputs\<RunName>" ^
  --video "C:\path\to\stimulus_target_cued.mp4" ^
  --out "C:\PRAYCG\analysis_outputs\<RunName>\visualizer\target_lab_diagnostic.mp4"
```

The visualizer creates sidecars such as `features_used.csv`, `events_used.csv`, and a render report. Use them for debugging what actually appeared in the video.

---

# 08 - Template Files, Analysis Inputs, and Where to Find Them

## 8.1 The four files people confuse

```text
MRED familiarity CSV  -> manual analysis covariate
MRED scene map CSV    -> anchor/scene interpretation map
Annotation CSV        -> review/visualization bridge
Feature table CSV     -> generated by Master Comprehensive Suite
```

## 8.2 MRED familiarity CSV

Purpose: tells MRED whether each anchor was novel, familiar, anticipated, personally resonant, or meaningful-but-already-known.

Where to find template:

```text
MasterSuite_v1_5_5\templates\mred_familiarity_covariates_template.csv
```

Field-specific templates may exist, for example:

```text
FieldOfDreams_CatchScene_MRED_familiarity_covariates_TEMPLATE.csv
```

Typical columns:

```text
anchor_id
prior_exposure_0_9
scene_remembered_0_9
beat_anticipated_0_9
new_insight_0_9
unexpectedness_0_9
current_life_connection_0_9
meaningful_but_already_known_0_9
autobiographical_resonance_0_9
cringe_score_0_9
notes
```

How to create:

1. Copy the template to:

```text
C:\PRAYCG\analysis_inputs\<RunName>\<RunName>_MRED_familiarity_covariates.csv
```

2. Fill one row per anchor.
3. Keep `anchor_id` exactly identical to the anchor JSON.
4. If a subject was blinded, fill after the run.

## 8.3 MRED scene map CSV

Purpose: maps each anchor ID to rendered time, scene label, MRED role, endpoint type, and claim status.

Where to find template:

```text
MasterSuite_v1_5_5\templates\mred_scene_map_template.csv
```

Typical columns:

```text
anchor_id
condition_scope
rendered_time_sec
scene_label
scene_description
predicted_mred_quadrant
a_mred_role
primary_endpoint_use
claim_level
expected_direction
notes
```

How to create:

1. Copy the template to:

```text
C:\PRAYCG\analysis_inputs\<RunName>\<RunName>_MRED_scene_map.csv
```

2. Copy anchor IDs and rendered times from the locked anchor file.
3. Use neutral labels for blinded runs.
4. Use revealed descriptions only after the run if novelty must be preserved.

## 8.4 Annotation CSV

Purpose: creates human-readable windows for review, visualizer overlays, and reports.

Typical columns:

```text
anchor_id
condition
start_sec
end_sec
time_sec
label
claim_level
category
notes
```

How to create:

1. Start from anchor schedule or scene map.
2. For each anchor, define window:

```text
start_sec = rendered_time_sec - pre_window_sec
end_sec   = rendered_time_sec + post_window_sec
```

3. Create rows for Target, Control, and Override if needed.
4. Save as:

```text
C:\PRAYCG\analysis_inputs\<RunName>\<RunName>_annotation_windows_PREDECLARED.csv
```

After analysis, the Master Suite or report package may create a review version with nearest events and module results.

## 8.5 Feature table CSV

Purpose: time-resolved physiology features used by modules and visualizer.

Generated by:

```text
Master Comprehensive Analysis Suite
```

Typical location:

```text
<Master Suite output folder>\tables\<run>_time_resolved_feature_frame.csv
```

Search command:

```bat
dir /s /b *time_resolved_feature_frame*.csv
```

Important: do not manually create the feature table. If it is missing, run or rerun the Master Suite.

## 8.6 StimulusFingerprint files

Generated by MediaPrep v1.8 inside:

```text
<MediaPrep output folder>\qc\
```

Key files:

```text
stimulus_exogenous_regressor_frame_all_conditions.csv
cet_regressors_all_conditions.csv
stimulus_rhythm_summary_all_conditions.csv
stimulus_dominant_frequency_timeseries_all_conditions.csv
anchor_stimulus_rhythm_vectors_all_conditions.csv
stimulusfingerprint_branch_status.csv
stimulusfingerprint_error_log.json
stimulusfingerprint_cet_eet_manifest.json
stimulusfingerprint_cet_eet_report.md
```

## 8.7 Search commands

```bat
dir /s /b *familiarity*.csv
dir /s /b *scene_map*.csv
dir /s /b *annotation*.csv
dir /s /b *time_resolved_feature_frame*.csv
dir /s /b *stimulus_exogenous_regressor*.csv
```

---

# 09 - Troubleshooting and QC Failure Modes

## 9.1 OpenBCI COM port cannot open

Likely cause: another program owns the port.

Fix:

```text
[ ] Close OpenBCI GUI
[ ] Close Arduino serial monitor
[ ] Close old BrainFlow terminals
[ ] Unplug/replug dongle
[ ] Re-run COM identifier
```

## 9.2 ALS stream flat

Check:

```text
[ ] ALS OUT -> D12/A6
[ ] ALS + -> DVDD/3V3
[ ] ALS - -> GND
[ ] --enable-analog-aux was used
[ ] --publish-als-stream was used
[ ] --als-aux-channel 1 for D12/A6
[ ] Sensor is over timing square
[ ] Sensor is shrouded from room light
[ ] Video contains start pulse
```

## 9.3 LabRecorder does not show stream

1. Click **Update**.
2. Confirm streamer terminal is still running.
3. Confirm no VPN/firewall is blocking local multicast.
4. Restart LabRecorder after streams are already active.
5. Run LSL stream listing script.

## 9.4 Control audio is intelligible

Do not use the run as clean. Mark it:

```text
PILOT ONLY / CONTROL AUDIO FAIL
```

Regenerate Control with stricter audio scrambling or choose a different source.

## 9.5 Anchor file not loaded

If no anchor file was loaded into the runner, the result may still be scientifically interesting, but it is not runner-registered confirmatory.

Correct label:

```text
conceptually predeclared / not runner-registered
```

or:

```text
exploratory / future-freeze candidate
```

## 9.6 Estimated anchor file loaded

If the anchor file was loaded but not frame-verified:

```text
runner-registered estimated-anchor pilot
```

not:

```text
strict frame-verified confirmatory
```

## 9.7 Gamma artifact concern

Never interpret gamma alone. Gamma is an artifact-sensitive work-signal proxy. Require artifact gates, theta/topological carryover, condition specificity, and CET-R/stimulus controls.

## 9.8 Missing feature table

Run Master Comprehensive Suite. The visualizer sidecar `features_used.csv` is not a substitute for the canonical feature table.

## 9.9 Missing MRED familiarity or scene map CSV

Copy the template and fill it manually. These are analysis covariates, not raw acquisition outputs.

## 9.10 Field run timing caution example

A run may be useful but not confirmatory if:

```text
[ ] anchor file was estimated, not frame-verified
[ ] ALS start pulse did not pass all branches
[ ] continuous stream timing required reconstruction
```

The correct posture is to keep the run as pilot-positive or hypothesis-generating and rerun with stricter timing.

---

# 10 - Day-of-Run Checklist

## Before participant/session

```text
[ ] MediaPrep output exists
[ ] Target video checked
[ ] Override video checked
[ ] Control video checked
[ ] Control audio unintelligible
[ ] Visual watermark/source-stamp QC passed
[ ] Cue schedule JSON/CSV present
[ ] Anchor JSON present and locked or labeled estimated
[ ] StimulusFingerprint qc folder present
[ ] BrainFlow environment opens
[ ] LabRecorder opens
[ ] Polar charged
[ ] Vernier charged
[ ] OpenBCI battery charged
[ ] Cap sponges/saline prepared
[ ] ALS sensor taped and shrouded
[ ] Box/room clear and safe
```

## Stream startup order

```text
1. BrainFlow ALS bridge
2. Polar H10 stream
3. Vernier respiration stream
4. PRAYCG2.0 runner up to StasisMarkers online
5. LabRecorder update/select streams/start recording
6. Continue PRAYCG2.0 protocol
```

## LabRecorder selected streams

```text
[ ] StasisMarkers
[ ] obci_eeg1
[ ] OpenBCIAnalogAux
[ ] ALS_PT19_Timing
[ ] OpenBCIStatusMarkers
[ ] PolarHRV / PolarH10 stream
[ ] VernierRespirationBelt stream
```

## After run

```text
[ ] Stop LabRecorder
[ ] Confirm XDF file exists and is nonzero size
[ ] Save/copy events CSV/JSON
[ ] Save run_config_media_selection.json
[ ] Save self-report JSON files
[ ] Save confound report JSON files
[ ] Save cue schedule JSON/CSV
[ ] Save anchor JSON/CSV
[ ] Save StimulusFingerprint qc folder
[ ] Stop streamers
[ ] Clean cap and hardware
[ ] Back up run folder
```

---

# 11 - Public Release and Repository Boundary

## What can go on GitHub

```text
Code
README files
templates
synthetic demo data
public-safe derived example tables
non-copyright media recipe scripts
hardware build docs
analysis module docs
formulas and method descriptions
```

## What should not go on GitHub

```text
Copyrighted movie clips
Raw XDF from private/self-runs unless deliberately released
Private self-report details
Access tokens
Local passwords
Unredacted participant identifiers
Large binary archives better suited for OSF
```

## What can go on OSF

```text
Frozen ZIP releases
Derived pilot reports
Synthetic demo media
Public-safe example data
Software snapshots
Protocol documents
QC checklists
```

## Labeling examples

```text
Gold-plated but not gold-record:
  best current public-safe demonstration, but not confirmatory.

Runner-registered estimated-anchor pilot:
  anchor loaded, but times not frame-verified.

Frame-verified locked-anchor run:
  anchor times verified on final rendered MP4 and loaded before acquisition.

Exploratory / future-freeze:
  event discovered or refined after analysis.
```

## Public wording

Use:

```text
PRAYCG is an exploratory open-source protocol and analysis architecture for testing state-locked narrative psychophysiology.
```

Do not use:

```text
PRAYCG proves consciousness.
PRAYCG proves OSM biology.
PRAYCG proves memory topology.
PRAYCG proves thermodynamics of meaning.
```

---

# Appendix - Evidence and source basis

This manual is based on the current PRAYCG2.0 runner, MediaPrep/StimulusFingerprint v1.8, BrainFlow ALS bridge v1.4, Master Comprehensive Suite v1.5.5+, and the project QC/manual files. External hardware steps should always be checked against the current official manufacturer documentation.
