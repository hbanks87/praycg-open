# 04 - MediaPrep v1.8 and StimulusFingerprint SOP

## 4.1 Purpose

MediaPrep creates the three stimulus arms and the stimulus-side QC files. It prepares media; it does not certify physiological claims.

Generated arms:

```text
Target: intact cue-embedded narrative watched naturally.
Contextual Override: same cue-embedded video as Target, different instructions.
Control: phase-scrambled version generated from cue-embedded Target.
```

## 4.2 Run MediaPrep GUI

```bat
cd /d C:\PRAYCG\software\MediaPrep_v1_8
.venv\Scripts\activate
py -3.11 scripts\run_PRAYCG_MediaPrep_v1_8.py
```

If your active Python is already inside the venv:

```bat
python scripts\run_PRAYCG_MediaPrep_v1_8.py
```

## 4.3 Recommended MediaPrep settings

```text
Project name: short, no spaces if possible
Input video: final raw source excerpt MP4
Output root: C:\PRAYCG\stimuli\<RunName>\MediaPrep_Output
Cue seed: fixed project seed unless intentionally changed
Cue interval: 3.0 s
Cue display duration: 0.85 s
Cue position: upper_right
Contrast-protected badge: enabled
Fullscreen ALS start pulse: enabled
Generate DRAFT anchor schedule: enabled
Run StimulusFingerprint after media generation: enabled
```

## 4.4 Expected MediaPrep outputs

Typical output folder:

```text
<project>_MediaPrep_v1_8_<timestamp>\
  stimulus_master_cleaned_<project>_v1_8.mp4
  stimulus_target_cued_<project>_v1_8.mp4
  stimulus_override_cued_<project>_v1_8.mp4
  stimulus_control_cued_phase_scrambled_<project>_v1_8.mp4
  cue_schedule_<project>_v1_8.json
  cue_schedule_<project>_v1_8.csv
  predeclared_anchors_<project>_DRAFT.json
  predeclared_anchors_<project>_DRAFT.csv
  ANCHOR_LOCK_CHECKLIST_<project>.md
  qc\
    stimulus_exogenous_regressor_frame_all_conditions.csv
    cet_regressors_all_conditions.csv
    stimulus_rhythm_summary_all_conditions.csv
    stimulus_dominant_frequency_timeseries_all_conditions.csv
    anchor_stimulus_rhythm_vectors_all_conditions.csv
    stimulusfingerprint_branch_status.csv
    stimulusfingerprint_error_log.json
    stimulusfingerprint_cet_eet_manifest.json
    stimulusfingerprint_cet_eet_report.md
```

## 4.5 Manual video QC

Open all three generated videos.

```text
[ ] Target plays full length
[ ] Override plays full length
[ ] Control plays full length
[ ] Target and Override are visually identical except instructions differ outside video
[ ] Target and Override SHA-256 match if designed to be identical
[ ] Control is phase-scrambled and not narratively recognizable
[ ] Cue badge is visible and not too small
[ ] Cue badge does not cover a critical face/line when avoidable
[ ] Fullscreen or timing-square ALS pulse appears at start
[ ] No readable watermark/source stamp remains unless intentionally documented
```

## 4.6 Manual control-audio QC

Listen to the full Control using the same speaker/headphone settings as the protocol.

Pass only if:

```text
[ ] No recognizable spoken words
[ ] No intelligible sentence fragments
[ ] No distinct melody that reveals the source
[ ] Loudness/envelope broadly tracks original
[ ] Sounds like speech-shaped/scene-shaped noise, not dialogue
```

## 4.7 Lock anchors

Use final rendered Target time, not source-video time.

```bat
python scripts\praycg_anchor_lock_finalizer_v1_7A.py ^
  --draft "C:\path\to\predeclared_anchors_<project>_DRAFT.json"
```

The finalizer writes:

```text
predeclared_anchors_<project>_LOCKED.json
predeclared_anchors_<project>_LOCKED.csv
predeclared_anchors_<project>_LOCKED_manifest.json
```

Load the `*_LOCKED.json` in PRAYCG2.0. If the file is estimated or not frame-verified, mark the run as pilot/estimated-anchor rather than strict confirmatory.

## 4.8 Rerun StimulusFingerprint on existing folder

```bat
py -3.11 scripts\praycg_batch_stimulus_fingerprint_v1_8.py ^
  --mediaprep-folder "C:\PRAYCG\stimuli\<RunName>\MediaPrep_Output\<project>_MediaPrep_v1_8_<timestamp>" ^
  --project-name "<RunName>"
```

The branch status file should report PASS for Control, Target, and Override before you rely on full CET-R.
