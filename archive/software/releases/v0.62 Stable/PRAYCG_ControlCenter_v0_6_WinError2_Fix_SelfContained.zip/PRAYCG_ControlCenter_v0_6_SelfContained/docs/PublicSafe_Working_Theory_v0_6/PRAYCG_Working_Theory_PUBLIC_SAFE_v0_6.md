# PRAYCG Public-Safe Working Theoretical Paper v0.6

An open, public-facing research manuscript for the PRAYCG protocol and Master Comprehensive Analysis Suite. This version is designed for GitHub/OSF release. It removes private file paths, raw biosignal data, direct participant identifiers beyond author attribution, and any redistribution of copyrighted stimulus media. It is comprehensive, but intentionally bounded: it describes a protocol, software architecture, theory of measurement, and exploratory pilot-derived hypotheses, not a finished empirical proof.

> **Document status.** Public research draft. Exploratory methods architecture and hypothesis framework only. This document does not claim proof of consciousness, a soul, clinical effect, quantum biology, microtubular memory, biophotonic memory, or a molecular hidden variable visible in scalp EEG. It is written to make the protocol inspectable, criticizable, and reproducible by others.

**Table: Public release metadata**

| Field | Value |
| --- | --- |
| Project | PRAYCG - Participatory / PR-AYC-G narrative psychophysiology protocol |
| Current public version | v0.6 public-safe working theory |
| Companion software | PRAYCG2.0 runner, MediaPrep/StimulusFingerprint v1.8, Master Comprehensive Suite v1.5.6+ |
| Primary proposed endpoint | A-MRED / MRED-Peak-Resolution after timing, artifact, confound, and stimulus-rhythm gates |
| Secondary layers | NIP, TTI, NUPI, DGA, Baseline2 recovery, offline interpreter |
| Exploratory layers | KHT-topo, NAST, EET, MRED-ITP, ACG, OCU, OCM/RSM/CVB/SquintProxy, LSO |
| Public data posture | Derived tables, synthetic demo, documentation, code. No copyrighted film files and no raw private XDF unless explicitly deidentified and permitted. |

## 1. Abstract

PRAYCG is an open-source psychophysiology protocol and analysis architecture for testing whether accessible narrative meaning has measurable timing, shape, and physiological consequence beyond low-level sensory entrainment and beyond analytic task stance. The protocol compares three branches generated from a common source stimulus: a phase-scrambled sensory-control branch designed to damage recognizable narrative meaning while preserving low-level audiovisual drive; an intact target narrative watched naturally; and the same intact cue-embedded narrative viewed under an analytic contextual-override task. The software stack includes MediaPrep, cue scheduling, anchor registration, StimulusFingerprint/CET-R, LSL event logging, OpenBCI-compatible acquisition, optional autonomic/respiration streams, PRAYCG2.0 self-report and confound reports, and a Master Comprehensive Analysis Suite with QC, artifact, MRED, immersion, reception/extraction, update-polarity, decoder-gate, and offline interpretation modules.

The current theoretical compression centers on A-MRED: an anchor-locked meaning-recognition and delayed-integration endpoint that must pass Target-specificity, Control comparison, Override comparison, artifact/confound vetoes, and stimulus-rhythm residualization before interpretation. Secondary modules distinguish acute meaning peaks from delayed resolution, model narrative update polarity, and estimate decoder-gate availability. Pilot self-runs have not established a confirmatory result, but they motivate several working hypotheses: meaning recognition and integration can dissociate; peak-like meaning and resolution-like meaning may have distinct physiological shapes; analytic extraction can reroute rather than simply erase meaning; sensory clarity and emotional impact can dissociate; and meaning appears to require access conditions, including sensory access, prior state-space, personal relevance, autonomic availability, and low enough task/confound burden. PRAYCG is therefore best understood as a theory and toolchain for studying availability: whether a living system is available to decode, receive, integrate, and be changed by meaning.

## 2. Public claim boundary

The first obligation of the public release is claim discipline. PRAYCG is not a consciousness detector. It is not a clinical device. It does not measure love, soul, moral worth, memory formation, or hidden cellular machinery. It is an experimental and software architecture for turning naturalistic meaning into a falsifiable timing problem.

- Permitted current claim: PRAYCG is an exploratory three-arm psychophysiology protocol and open-source analysis stack for testing state-locked narrative meaning under controls.
- Permitted current claim: the suite can generate auditable feature tables, event-lock candidates, stimulus-regressor controls, visualizer artifacts, and offline interpretive summaries.
- Permitted current claim: pilot runs motivate hypotheses about recognition/integration dissociation, peak/resolution profiles, sensory access, and decoder-gate availability.
- Not permitted: current evidence proves consciousness, OSM biology, microtubular memory, biophotonic memory, quantum biology, clinical efficacy, or literal thermodynamic heat/energy transfer from a story.
- Not permitted: scalp EEG gamma is treated as a biomarker of meaning by itself. Gamma-like features are artifact-sensitive candidate work-signal proxies only.
- Not permitted: self-report proves internal state or physiology. Self-report is an independent evidence stream that can constrain interpretation.

> **Plain-language boundary.** PRAYCG asks whether meaning has timing, shape, and physiological consequence. It does not claim that the measured trace exhausts the meaning.

## 3. Why PRAYCG exists

Naturalistic neuroscience already recognizes that movies and stories can synchronize viewers through shared sensory structure, attention, pacing, faces, speech, music, and affect. PRAYCG does not deny this. It depends on that insight. The central question is narrower: after accounting for light, sound, motion, cuts, cue timing, task stance, respiration, artifact, and self-report confounds, does accessible narrative meaning produce a state trajectory that differs from sensory drive alone and from the same narrative under analytic extraction?

The project began as a question about whether meaning and empathy leave measurable traces. It has since narrowed into a metrological architecture: compare a meaning-damaged sensory control, an intact receptive target, and the same intact stimulus under analytic override. The point is not that each module is a proof. The point is that each module guards against a specific failure mode.

## 4. The three-arm protocol

The strongest PRAYCG design compares the same source material in three ways. This is the non-negotiable architecture for serious runs.

**Table: Core PRAYCG branch design**

| Branch | What is shown | Participant stance | Main question |
| --- | --- | --- | --- |
| Phase-scrambled sensory-control | A phase-scrambled version of the cue-embedded target. Low-level audiovisual timing and cue energy are preserved as much as possible while recognizable story is damaged. | Watch normally. | Is the response explainable by light, sound, motion, cuts, cue rhythm, audiovisual envelope, or artifact? |
| Target | The intact cue-embedded narrative stimulus. | Watch naturally and allow the story to land. | What happens when meaning is accessible and the subject is receptive? |
| Contextual Override | The same intact cue-embedded narrative as Target. | Perform an analytic task, such as running-sum number-cue addition. | What changes when the same sensory/semantic object is processed under extraction rather than reception? |

> **Why Control stays.** The phase-scrambled branch should not be called meaningless. It is a meaning-damaged sensory-entrainment control. It may still produce visual tracking, auditory entrainment, boredom, irritation, confusion, effort, artifact, or affect. Its purpose is not to be physiologically zero; its purpose is to preserve the sensory attack surface while damaging narrative recognition.

## 5. Temporal structure of a PRAYCG2.0 run

A full PRAYCG2.0 run is organized around baseline, branch exposure, washout, brief reports, and a final reflective baseline. The final reflective baseline is not a pure Target endpoint; it is a cumulative after-state of the entire run. This distinction became important after later pilot runs, because Target absorption, Override semantic clarification, and post-run reflection can all contribute to Baseline2.

**Table: Recommended PRAYCG2.0 sequence**

| Stage | Purpose |
| --- | --- |
| Pre-run calibration | Check cue visibility, display/audio confidence, current fatigue/discomfort, and known confounds. |
| Baseline 1 | Estimate initial physiological state before stimulus exposure. |
| Control + Washout 1 | Measure sensory-control response and immediate carryover. |
| Target + Washout 2 | Measure receptive intact-narrative response and carryover. |
| Override + Washout 3 | Measure analytic/extraction stance on the same intact narrative. |
| Final reflection baseline / Baseline2 | Measure cumulative reflective after-state after comparing the branches. |
| Final master report | Collect comparative self-report after Baseline2 so report-writing does not contaminate the baseline. |

## 6. Hardware and acquisition architecture

The public hardware architecture is intentionally ordinary. PRAYCG does not require exotic sensors to be useful as a methods protocol. A typical build uses OpenBCI Cyton+Daisy for EEG, a gelfree or gel-based cap, optional ALS-PT19 photodiode/photoresistor timing channel, Polar H10 R-R intervals, Vernier respiration belt, Lab Streaming Layer streams, and LabRecorder/XDF recording. Optional upgrades include EOG/EMG, motion, pupilometry, and higher-resolution acquisition.

**Table: Hardware layer and claim boundaries**

| Hardware / stream | Role in the model | Claim boundary |
| --- | --- | --- |
| OpenBCI EEG | Measures scalp-level electrical activity used for spectral, topological, and event-lock proxies. | Does not directly measure microtubules, biophotons, cellular memory, or consciousness. |
| ALS-PT19 / photodiode timing | Validates physical display timing and branch-onset pulses. | Belongs to external input u(t), not biological hidden state Y(t). |
| Polar H10 / ECG/R-R | Supports HR, HRV, RMSSD, SDNN, API-A, recovery, and autonomic context. | Autonomic markers are indirect state proxies, not psychological proof. |
| Vernier respiration belt | Controls for breathing as a common driver of HRV and EEG rhythms. | Respiration can explain or confound apparent neural/autonomic coupling. |
| EOG/EMG, recommended | Improves artifact rejection for blink, eye movement, jaw, forehead, and muscle gamma. | Critical for stronger gamma interpretation. |

## 7. MediaPrep and stimulus provenance

MediaPrep creates the stimulus files and cue schedule. It does not certify meaning or neural effects. The public release treats MediaPrep as a provenance and stimulus-QC tool: it records file hashes, generates Target and Override from the same cue-embedded video, generates Control from the cue-embedded Target, creates cue schedule JSON/CSV files, and can create StimulusFingerprint regressors for CET-R.

- Target and Contextual Override must be generated from the same cue-embedded video. Only instructions should differ.
- The phase-scrambled Control should be generated from the cue-embedded Target, not from a separate branch, so cue timing and low-level cue energy are represented in Control.
- Control audio requires human QC. Automated scrambling cannot certify that no recognizable words, sentence fragments, or music-derived narrative cues remain.
- The ALS timing square validates display timing only; it is not biological photonic data.
- For confirmation-grade anchors, estimated anchor times must be frame-verified on the final rendered Target MP4 and saved as a LOCKED anchor JSON before acquisition.

**Stimulus provenance identity rule**

```text
H(Target video) = H(Override video)
H(Control video) != H(Target video)
Control = PhaseScramble(Target_cue_embedded)
```

H denotes a cryptographic hash such as SHA-256. Target and Override must be physically identical media files if the only intended difference is participant stance.

## 8. Master Comprehensive Analysis Suite tier map

The public-facing suite should not present every module as equally confirmatory. The suite is intentionally broad because it is a research workbench. The future confirmatory pathway is narrower.

**Table: Current public module tiers**

| Tier | Modules | Role |
| --- | --- | --- |
| Boxed primary path | Timing/QC + StimulusFingerprint/CET-R + artifact/confound gates -> A-MRED / MRED-Peak-Resolution | The recommended future endpoint pathway. |
| Secondary interpretation | NIP/BIT/CII/IAQ, TTI, NUPI, DGA, Baseline1-vs-Baseline2 | Summarize immersion, reception/extraction, update polarity, and gate availability. |
| Exploratory / convergence | KHT-topo, NAST, EET, MRED-ITP, ACG, OCU, OCM025, RSM, CVB, SquintProxy, LSO | Generate hypotheses, expose confounds, support convergence, or motivate future studies. |
| Visualization/reporting | MasterSync Visualizer, offline interpretive report generator | Audit synchronization and produce local plain-language interpretation. |

> **Recommended compression.** For public release and future replication, the clean phrase is: A-MRED is the endpoint; NIP and TTI are summaries; CET-R and artifacts are guards; DGA and NUPI explain profile shape; KHT/EET/ITP are exploratory convergence layers.

## 9. Core notation

The following notation is used throughout the public theory. These are operational definitions for scalp-level and autonomic analysis, not direct claims about cellular mechanism.

**Table: Core notation**

| Symbol | Operational meaning |
| --- | --- |
| u(t) | External stimulus vector: video, audio, luminance, motion, cuts, cue train, ALS pulse, task instruction. |
| x(t) | Observed physiological state vector: EEG features, HR/HRV, respiration, artifact, optional EOG/EMG. |
| Y_topo(t) | Human-scale inferred network-state topology proxy. Not cellular OSM. |
| MR_j | Meaning-recognition proxy at anchor j. |
| ENC_j | Delayed integration/carryover proxy after anchor j. |
| QC_j | Timing, artifact, confound, and stimulus-regressor validity gate for anchor j. |
| X_b | Extraction/task burden in branch b. |
| SA_b | Semantic-access estimate in branch b. |
| DA_b | Decoder availability estimate in branch b. |

## 10. Artifact and confound score

ArtifactScore is a veto and penalty layer. It is not an interpretation layer. Its job is to prevent beautiful stories from being mistaken for jaw tension, blink contamination, line noise, motion, packet loss, or poor contact.

**ArtifactScore**

```text
Artifact(t) = mean_z(
  p2p_EEG(t),
  high_frequency_sentinel(t),
  line_noise_sentinel(t),
  blink_or_fp_sentinel(t),
  dropout_or_flatline_sentinel(t),
  motion_or_contact_sentinel(t)
)

Penalty_A(t) = exp(-lambda_A * max(0, Artifact(t)))
```

The exact sentinels depend on available streams. With EOG/EMG, ocular and muscle terms should be explicit. Without them, scalp gamma claims remain strongly cautioned.

## 11. Meaning Recognition / Encoding Dissociation (MRED)

MRED is the central theory that meaning recognition and integration/carryover can dissociate. A system can recognize a meaningful pattern without performing a new integration. A system can also show slow resolution or afterglow without a dramatic peak. MRED therefore separates a recognition term from a delayed integration term.

**Recognition proxy**

```text
MR_j = z(TSP_j)
     + z(MeaningGamma_resid_j)
     + z(NIP_attention_j)
     - z(Artifact_j)
     - z(SensoryDrive_j)
```

TSP and MeaningGamma are candidate recognition/work-signal features. The residual form is preferred after CET-R removes modeled audio/visual/cue drive.

**Encoding / integration proxy**

```text
ENC_j = z(ThetaHandoff_j)
      + z(TopologyCarryover_j)
      + z(BaselineEcho_j)
      + z(RegulatoryCarryover_j)
      - z(Artifact_j)
```

ENC is not proof of memory formation. It is a delayed integration/carryover proxy.

**MRED quadrant**

```text
MR_HIGH_ENC_HIGH  -> recognition + integration candidate
MR_HIGH_ENC_LOW   -> recognition without detected integration
MR_LOW_ENC_HIGH   -> non-semantic carryover, confound, delayed state, or unmodeled process
MR_LOW_ENC_LOW    -> no detected event under current thresholds
```

## 12. A-MRED: anchor-locked primary endpoint

A-MRED is the proposed primary endpoint for future confirmation-grade PRAYCG studies. It is deliberately stricter than a single gamma spike, theta increase, or positive self-report.

**A-MRED pass rule**

```text
A-MRED_j = 1[MR_T,j > theta_MR]
         * 1[ENC_T,j > theta_ENC]
         * 1[MR_T,j > MR_C,j + delta]
         * 1[MR_T,j > MR_O,j + delta]
         * 1[ENC_T,j > ENC_C,j + delta]
         * 1[ENC_T,j > ENC_O,j + delta]
         * 1[QC_j = PASS]
```

T = Target, C = Control, O = Override. If any gate fails, the event is not confirmation-grade.

- Anchor must be locked before acquisition and loaded into the runner.
- Target must show recognition and delayed integration.
- Target must exceed phase-scrambled Control.
- Target must exceed analytic Override.
- Artifact/confound/timing/CET-R gates must pass.
- Self-report may support or challenge the interpretation, but cannot substitute for the endpoint.

## 13. MRED-Peak and MRED-Resolution

Pilot data motivated a cleaner distinction between acute meaning peaks and delayed resolution. Some stimuli appear as sharp recognition/integration candidates; others look more like reflective closure, regulatory recovery, or afterglow. Both are legitimate hypotheses, but they should not be mixed into one endpoint.

**MRED-Peak score**

```text
MREDPeak_j = clip_plus(MR_T,j)
           * clip_plus(ENC_T,j)
           * Specificity_j
           * QC_j
```

Best for acute recognition shocks, revelation, awe, or narrative turning points.

**MRED-Resolution score**

```text
MREDResolution_j = clip_plus(MR_T,j)
                 * clip_plus(RDI_T,j)
                 * clip_plus(Echo_B2,j)
                 * Specificity_j
                 * QC_j
```

Best for closure, repair, forgiveness, relational resolution, or delayed afterglow. Baseline2 is cumulative and must be interpreted cautiously.

## 14. NIP, BIT, CII, and IAQ

The Narrative Immersion Proxy layer translates attention-plus-resonance language into auditable macroscopic features. It does not claim to measure dopamine, oxytocin, or a proprietary immersion construct.

**Semantic attention and integration density**

```text
A_sem(t) = clip_plus(w_G z(MeaningGamma_resid(t))
                   + w_T z(TSP(t))
                   + w_N z(NAST(t))
                   - w_A z(Artifact(t)))

R_int(t) = clip_plus(w_theta z(ThetaCarryover(t))
                   + w_topo z(TopologyCarryover(t))
                   + w_API z(API_A(t))
                   - w_A z(Artifact(t)))

I(t) = A_sem(t)^alpha * R_int(t + lag)^beta * Penalty(t)
```

**Continuous Immersion Index**

```text
CII(W) = (1 / |W|) * integral_{t in W} I(t) dt
```

CII is duration-normalized so longer scenes do not automatically score higher.

**Bivariate Immersion Threshold**

```text
BIT_j = 1[A_j > theta_A]
      * 1[R_j > theta_R]
      * 1[Artifact_j < A_max]
      * 1[Specificity_j = PASS]
```

BIT uses an AND-gate so attention alone cannot mask lack of delayed integration.

**Immersion Attenuation Quotient**

```text
IAQ(W) = 1 - (CII_Override(W) + eps) / (CII_Target(W) + eps)
```

A positive IAQ suggests analytic Override attenuated the continuous immersion proxy, provided Target and Override had equal sensory access.

## 15. TTI: reception/extraction tradeoff

TTI asks whether the same intact narrative is received as meaning or extracted as task material. It is a Target-vs-Override contrast, not a moral score.

**Thermodynamic Task Interference / reception-extraction index**

```text
TTI = w_MR z(MR_T - MR_O)
    + w_ENC z(ENC_T - ENC_O)
    + w_API z(API_T - API_O)
    + w_X z(X_O - X_T)
    - w_A z(Artifact_T + Artifact_O)
    - w_C z(Confound_T + Confound_O)
```

High TTI means the Target branch looked more receptive and the Override branch looked more extractive under the available proxies.

## 16. NUPI: Narrative Update Polarity Index

NUPI separates two possible shapes of meaning: accommodative load and resolutive recovery. It does not measure heat, ATP, or literal thermodynamic energy. It is a profile classifier.

**NUPI**

```text
ALI = mean(semantic_intensity,
           target_specificity,
           complexity_perturbation,
           TTI,
           primary_endpoint_support)

RDI = mean(Baseline2_regulation,
           Baseline2_semantic_echo,
           EET_afterstate_echo,
           self_report_echo)

NUPI = RDI - ALI
```

NUPI > 0 suggests resolutive-recovery tilt. NUPI < 0 suggests accommodative-load tilt. NUPI cannot be graded cleanly without adequate after-state data.

## 17. DGA: Decoder Gate Availability

DGA is the most recent theory update. It models meaning as a gated interaction between external semantic access and an already-structured internal state-space. It arose because one pilot run showed a dissociation: the branch with stronger emotional absorption did not have the clearest audio, while the branch with clearer semantic access occurred under analytic task load. This motivated the idea that semantic clarity and emotional integration are separable gates.

**Branch-level gate variables**

```text
SA_b = 1 - mean(AudioComprehensionDifficulty,
                SpeakerVolumeDifficulty,
                ExternalNoiseIntrusion,
                AudioVideoSyncProblem) / 9

DA_b = mean(Meaning,
            Absorption,
            EmotionalAfterglow,
            StoryActiveWashout) / 9

EI_b = mean(Absorption,
            EmotionalAfterglow,
            StoryActiveWashout) / 9

X_b = max(core_TaskExtractionLoad,
          Override_task_burden) / 9

C_b = max(core_ConfoundBurden,
          detailed_confound_mean) / 9
```

**Decoder gate availability**

```text
D_gate,b = sigmoid(2.0*SA_b + 1.4*DA_b + 1.1*EI_b
                   - 1.2*X_b - 1.8*C_b - 0.75)
```

D_gate is an interpretation proxy. It is not a literal neural gate and not a proof of internal mechanism.

**Gate Dissociation Index**

```text
GDI = mean(SA_Override - SA_Target,
           EI_Target - EI_Override,
           X_Override - X_Target,
           C_Target - C_Override)
```

A high GDI suggests semantic access and emotional integration dissociated across branches.

> **DGA hypothesis.** A stimulus does not create meaning in an empty system. It acts as a key against a persistent learned state-space. Meaning recognition depends on sensory access, prior geometry, personal relevance, regulated availability, and low enough extraction/confound burden.

## 18. Phase-scrambled Control doctrine

The phase-scrambled Control must remain in serious PRAYCG studies. The data to date do not prove that Control is subjectively or physiologically meaningless. They suggest that Control generally does not behave like an intact Target when the Target is meaningfully received. That is a different and more rigorous claim.

Modern neuroscience is right that shared stimulus structure can entrain brains. PRAYCG is not a rejection of sensory-entrainment science. It is built on it. The Control branch is the wall that lets the analysis ask whether anything remains after low-level stimulus timing, sensory energy, cue rhythm, and artifact have been modeled.

- Use Control for any publication-facing, TSC-facing, OSF-facing, or A-MRED confirmation attempt.
- Skip Control only for hardware shakedown, ALS tests, visualizer tests, or PRAYCG-lite demos where no meaning-vs-entrainment claim is made.
- Do not call Control meaningless. Call it phase-scrambled sensory-control or meaning-damaged sensory-control.
- A nonzero Control response is informative; it may reflect sensory entrainment, load, boredom, visual tracking, irritation, artifact, or the failure of scrambling to remove semantic cues.

## 19. CET, CET-R, and EET

CET estimates whether EEG/physiology tracks the exogenous cinematic forcing function. CET-R residualizes PRAYCG features against stimulus-side regressors. EET asks whether scene-like state vectors echo into washout or Baseline2. Together, they defend against the critique that results are just film rhythm.

**Stimulus regressor model**

```text
u(t) = [audio_envelope(t), luminance(t), visual_change(t),
        optical_flow_proxy(t), cut_train(t), cue_train(t), flash_proxy(t)]

Y_feature(t) = beta_0 + beta^T u(t - tau) + epsilon(t)

ResidualFeature(t) = epsilon(t)
```

MRED/NIP/TTI should be interpreted preferentially on residualized or stimulus-modeled features when regressors are available.

**Endogenous Echo Tracking**

```text
Echo(W_anchor, W_after) = cosine_similarity(StateVector_anchor,
                                             StateVector_after)
```

EET is not memory replay proof. It is state-vector resemblance after the stimulus.

## 20. MRED-ITP, ACG, and OCU

The information-thermodynamic proxy layer tests whether MRED events show complexity perturbation/settlement and ocular attention-release timing. This layer is exploratory and is especially sensitive to artifact and missing EOG/EMG.

**Algorithmic Complexity Gate**

```text
C_LZ(t) = LZC(symbolize(X(W_t))) / E[LZC(shuffle(symbolize(X(W_t))))]

DeltaC_strike,j = C_peak,j - C_pre,j
DeltaC_settle,j = C_post,j - C_peak,j

ACG_j = 1[DeltaC_strike,j > theta_up]
      * 1[DeltaC_settle,j < -theta_down]
      * 1[Artifact_j < A_max]
```

Lempel-Ziv-style complexity is a compressibility/diversity proxy, not thermodynamic entropy.

**Ocular-Cognitive Unloading**

```text
BlinkSuppression_j = z(BR_baseline - BR_hold,j)
BlinkRelease_j     = z(BR_release,j - BR_hold,j)

OCU_j = 0.45 z(BlinkSuppression_j)
      + 0.45 z(BlinkRelease_j)
      + 0.10 z(EventBoundary_j)
      - 0.25 z_plus(Artifact_j)
```

Blink timing can indicate attentional hold/release, but not memory encoding by itself.

## 21. Topo-OSM and the OSM-CELL quarantine

The public-facing theory now separates human-scale Topo-OSM from cellular OSM hypotheses. Topo-OSM is a human-scale network-state/topological interpretation layer. It asks whether meaning changes the shape or trajectory of macroscopic EEG/autonomic state-space. OSM-CELL remains quarantined until direct cellular, molecular, optical, or structural evidence exists.

**Human-scale Topo-OSM proxy**

```text
Y_topo(t) = Phi[A_theta(t), A_gamma(t), A_alpha(t),
                TSP(t), API_A(t), Resp(t), Artifact(t), u(t)]
```

Y_topo is inferred from measured physiology and stimulus vectors. It is not a cellular hidden variable.

**Memory-refresh attractor, quarantined mechanism layer**

```text
M(t) = [P(t), B(t), W(t), Z(t), R(t)]
R_memory = K_refresh / lambda_eff

R_memory > 1 -> trace persistence possible
R_memory < 1 -> trace decay expected
```

This belongs to conditional memory theory. It does not claim that scalp EEG verifies molecular refresh.

## 22. Rung 0 / Opto-PING synthetic identifiability

The Opto-PING/Rung 0 work belongs to the synthetic identifiability layer. It asks whether a hidden reciprocal coupling loop could be detected when simulated data contain such a loop and whether the model stays quiet on null data. It does not prove biological OSM or human EEG mechanism.

**Synthetic reciprocal loop summary**

```text
E(t) <-> Y(t)
K_loop = eta_E * zeta_E
K = sqrt(eta_E * zeta_E)
```

Detecting K in synthetic data validates the radar under known conditions. It does not prove the biological target exists.

## 23. Self-report and neurophenomenology

PRAYCG2.0 reduces self-report burden while preserving first-person data as an independent evidence stream. Self-report is used to constrain interpretation, identify confounds, and compare branch experience. It is not a substitute for physiology, and physiology is not a replacement for lived experience.

**First-person report bridge**

```text
Report_{i,k} = alpha + beta_Pi Pi_{i,k} + beta_g g_{i,k}
             + beta_K K_{i,k} - beta_M M_{i,k}
             - beta_Gamma Gamma_{i,k}
             + beta_mood Mood_{i,k} + beta_arousal Arousal_{i,k}
             + u_i + epsilon_{i,k}
```

The report model tests structured correspondence between reports and model components after mood/arousal controls.

## 24. Pilot-derived archetypes

The public paper should not present pilot self-runs as confirmatory. They are calibration and hypothesis-generation cases. To remain public safe, this section summarizes archetypes rather than raw private data. Copyrighted media are not redistributed.

**Table: Pilot-derived hypothesis archetypes**

| Archetype | Working interpretation | Endpoint status |
| --- | --- | --- |
| Recognition-dominant | A meaningful stimulus may produce recognition without clear new integration, especially when familiar or already encoded. | Hypothesis-generating; not a strict endpoint. |
| Acute peak / high-load-with-recovery | A stimulus may produce a sharp Target-specific meaning-recognition/integration candidate followed by recovery. | Best aligned with MRED-Peak; still requires locked anchors and QC. |
| Resolutive recovery | A stimulus may look less like a spike and more like delayed reflective closure, afterglow, and regulatory recovery. | Best aligned with MRED-Resolution/NUPI/RDI. |
| Decoder-gate dissociation | Semantic clarity and emotional integration can split across branches when sensory access, task stance, and confounds differ. | Motivates DGA; not a clean A-MRED result by itself. |

## 25. What the project may have discovered so far

The following are not proven claims. They are the current working hypotheses made visible by the protocol, software, and pilot failures/successes.

- Meaning recognition and meaning integration can dissociate. A subject can recognize meaningful geometry without showing clean delayed integration under current proxies.
- Peak-like meaning and resolution-like meaning appear to have different physiological shapes. Some events strike sharply; others settle slowly into afterglow.
- Analytic extraction does not simply erase meaning. It can reroute, delay, tax, or alter the route by which meaning is accessed.
- Sensory clarity and emotional impact are separable. Clearer semantic access can occur in one branch while stronger emotional absorption occurs in another.
- Meaning requires access conditions. Sensory access, prior state-space, personal relevance, autonomic availability, low task burden, and low confound load all matter.
- Baseline2 may be one of the most important windows for integration, but it is cumulative and cannot be attributed to Target alone without stronger design.
- The phase-scrambled Control remains essential because sensory entrainment and meaning integration are not the same construct.
- The suite is increasingly a theory of availability: whether a living system is available to decode, receive, and be changed by meaning.

## 26. Novelty map

The novelty of PRAYCG should not be framed as proving that stories affect physiology. That is already obvious and broadly supported. The novelty is the combination of control architecture, endpoint compression, stimulus provenance, and interpretive humility.

**Table: Public novelty map**

| Novel contribution | Public-safe description |
| --- | --- |
| Three-arm same-stimulus design | Combines phase-scrambled sensory-control, intact receptive Target, and same-intact analytic Override. |
| A-MRED endpoint compression | Reduces a large module suite into a stricter anchor-locked recognition-plus-integration endpoint. |
| Peak vs Resolution distinction | Separates acute semantic-impact events from delayed closure/recovery profiles. |
| DGA | Models meaning as external access interacting with persistent internal decoder state, rather than as stimulus transfer alone. |
| NUPI | Classifies narrative update polarity as accommodative-load versus resolutive-recovery proxy. |
| StimulusFingerprint/CET-R guard | Explicitly models luminance, audio, cuts, motion, cue train, and other exogenous drivers. |
| Offline interpreter | Turns module outputs into a local plain-English report for open-source users. |
| Claim-boundary discipline | Explicitly separates protocol evidence, mechanism hypotheses, and philosophical extrapolation. |

## 27. Falsification and negative controls

A useful protocol must be able to kill its own claims. PRAYCG should weaken or reject meaning interpretations under the following conditions.

- Phase-scrambled Control produces the same A-MRED / MRED-Peak / MRED-Resolution pattern as Target.
- Contextual Override produces equal or stronger integration than Target despite matched sensory access and higher extraction load.
- CET-R explains the apparent effect using luminance, audio envelope, cuts, motion, cue rhythm, or flash regressors.
- Artifact, blink, jaw/EMG, electrode motion, line noise, packet loss, or respiration explains the effect.
- Time-reversed labels, random anchors, shuffled labels, pseudo-events, or circularly shifted stimuli produce comparable results.
- Self-report contradicts the intended state strongly enough that the physiological interpretation becomes implausible.
- Replications with new subjects, locked anchors, EOG/EMG, and clean timing fail to reproduce the pattern.

## 28. Confirmation-grade decision rule

The strongest future PRAYCG result would not be a single impressive plot. It would be a chain of gates.

**Minimal confirmation-grade rule**

```text
ConfirmationCandidate =
  LockedAnchorFile
  * CleanBranchMarkers
  * ALS_or_validated_display_timing_PASS
  * TargetOverrideHashMatch
  * ControlFromCueEmbeddedTarget_PASS
  * StimulusFingerprint_CETR_PASS
  * ArtifactConfoundGate_PASS
  * A-MRED_PASS
  * ReplicationPlanned
```

If any term is zero, the result may still be useful, but it should be labeled pilot, exploratory, or timing/confound-cautioned.

## 29. Public repository boundary

The GitHub repository should contain code, documentation, templates, synthetic data, public-safe derived tables, and public-domain/CC0 demo fixtures. It should not contain copyrighted stimulus media, raw private XDF files, personally identifying health data, or unredacted self-report.

**Table: Public repository boundary**

| Allowed for GitHub | Avoid / use OSF or private storage instead |
| --- | --- |
| Source code, docs, templates, checklists | Raw participant XDF/physiology unless explicitly deidentified and consented for release |
| Synthetic demo media and synthetic demo outputs | Copyrighted movie clips or extracted scene media |
| Public-safe derived tables and example reports | Private self-report text with identifying details |
| Formula reports and module guides | Secrets, tokens, local private paths, personal medical notes |
| Upload scripts and folder maps | Large binaries better suited to OSF release archives |

## 30. Next study design

The next serious PRAYCG study should prioritize fewer endpoints, cleaner hardware controls, and stronger replication logic rather than more modules.

- Use A-MRED / MRED-Peak-Resolution as the primary endpoint.
- Frame-lock anchor JSON files on the final rendered Target MP4 before acquisition.
- Improve ALS timing with a physical holder, a longer white pulse or barcode pulse, and a live pre-run PASS/FAIL check.
- Use controlled headphones or a quiet environment so Target and Override have equal semantic audio access.
- Add EOG/EMG for gamma and ocular/muscle artifact control.
- Run full StimulusFingerprint v1.8+ and CET-R residualization.
- Keep phase-scrambled Control for any confirmation-grade run.
- Use group replication and leave-one-subject/stimulus sensitivity where possible.
- Publish negative and failed runs with clear reason codes.

## 31. Conclusion

PRAYCG is becoming less a claim about a hidden substrate and more a disciplined theory of availability. The protocol asks whether a living system is available to decode, receive, and integrate meaning under load. Its strongest public contribution is an open, auditable method for separating sensory entrainment, semantic access, receptive absorption, analytic extraction, delayed integration, and after-state recovery. The current data do not prove the grand theory. They do something more useful at this stage: they show where the theory must become stricter.

> **Final public-safe thesis.** Meaning is not merely stimulus energy. Meaning is stimulus structure passing through an available decoder, under specific sensory, autobiographical, autonomic, and task-state conditions. PRAYCG is an open protocol for testing that proposition without pretending the trace exhausts the meaning.

## Appendix A. Glossary

**Table: Glossary**

| Term | Public-safe meaning |
| --- | --- |
| A-MRED | Anchor-locked MRED primary endpoint candidate. |
| MRED | Meaning Recognition / Encoding Dissociation. |
| MRED-Peak | Acute event-like recognition/integration profile. |
| MRED-Resolution | Delayed closure/recovery/afterglow profile. |
| DGA | Decoder Gate Availability; branch-level access/availability model. |
| NUPI | Narrative Update Polarity Index; accommodative-load vs resolutive-recovery classifier. |
| TTI | Reception/extraction tradeoff between Target and Override. |
| CET-R | Residualization against exogenous stimulus rhythm and cue regressors. |
| EET | Endogenous Echo Tracking; state-vector resemblance into washout/Baseline2. |
| Topo-OSM | Human-scale network topology interpretation layer, not cellular OSM proof. |
| OSM-CELL | Quarantined cellular/mechanism hypothesis requiring direct evidence. |

## Appendix B. Output file map

**Table: Public-safe output file map**

| File family | Generated by | Public-safe role |
| --- | --- | --- |
| cue_schedule_*.json / .csv | MediaPrep | Cue timing and expected-sum provenance. |
| predeclared_anchors_*_LOCKED.json | AnchorPrep / human frame verification | Confirmation-grade anchor input when verified before acquisition. |
| stimulus_exogenous_regressor_frame_all_conditions.csv | StimulusFingerprint | CET-R stimulus-regressor input. |
| *_time_resolved_feature_frame.csv | Master Comprehensive Suite | Main physiology feature table. |
| amred_anchor_endpoint_table.csv | A-MRED module | Primary endpoint table. |
| mred_peak_resolution_anchor_table.csv | MRED Peak/Resolution module | Endpoint-compression table. |
| dga_branch_gate_table.csv | DGA module | Branch-level semantic/access/availability summary. |
| offline_interpretive_report.md/.txt | Offline interpreter | Local plain-English interpretation for users. |

## Appendix C. AI-use and authorship disclosure

This public draft is AI-assisted. The conceptual architecture, experimental direction, software decisions, run execution, curation, acceptance/rejection of analyses, and final release decisions are human-directed by the project author. AI assistance was used for drafting, organization, coding support, report generation, and language refinement. Public release should preserve an AI-use disclosure and invite independent review.

## Appendix D. Citation and source note

This public-safe manuscript is derived from the PRAYCG working theory, protocol notes, module reports, formula reports, public-release documentation, and deidentified summaries of exploratory self-runs. It deliberately removes private local paths, raw XDF data, copyrighted media, and any claim that pilot data establish a biological mechanism. Scientific citations should be expanded in a later manuscript version using primary literature on naturalistic neuroscience, sensory entrainment, predictive processing, EEG artifacts, HRV/respiration, LSL timing, and open science methods.
