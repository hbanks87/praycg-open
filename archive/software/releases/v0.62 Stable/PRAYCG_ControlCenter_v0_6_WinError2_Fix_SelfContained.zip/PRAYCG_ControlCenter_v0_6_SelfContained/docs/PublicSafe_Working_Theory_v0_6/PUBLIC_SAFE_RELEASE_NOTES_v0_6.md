# Public-safe release notes v0.6

This version is intended for open repository use. It emphasizes the following boundaries:

1. PRAYCG is exploratory psychophysiology and open-source methods architecture.
2. A-MRED is proposed as a future confirmation-grade endpoint only when timing, anchor, artifact, confound, and CET-R gates pass.
3. Phase-scrambled Control is retained as a meaning-damaged sensory-control branch, not assumed to be physiologically zero.
4. DGA is a secondary interpretation layer for semantic access and decoder availability; it is not a proof of internal mechanism.
5. Topo-OSM is a human-scale topology interpretation; OSM-CELL remains quarantined until direct cellular evidence exists.
6. The document is AI-assisted and should receive human review before public release.
