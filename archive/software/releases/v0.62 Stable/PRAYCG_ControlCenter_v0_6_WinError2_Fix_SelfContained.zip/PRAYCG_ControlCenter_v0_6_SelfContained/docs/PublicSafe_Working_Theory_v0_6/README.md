# PRAYCG Working Theory Public-Safe v0.6

This folder contains a public-safe GitHub/OSF version of the PRAYCG working theoretical paper.

Included files:

- `PRAYCG_Working_Theory_PUBLIC_SAFE_v0_6.md` - Markdown version for GitHub.
- `PRAYCG_Working_Theory_PUBLIC_SAFE_v0_6.docx` - editable Word version.
- `PRAYCG_Working_Theory_PUBLIC_SAFE_v0_6.pdf` - rendered PDF version.
- `PUBLIC_SAFE_RELEASE_NOTES_v0_6.md` - release notes and exclusions.

Public-safe exclusions:

- No copyrighted stimulus video is included.
- No raw XDF or raw physiological data is included.
- No private local file paths are included inside the manuscript body.
- No private participant identifiers or private self-report records are included.
- Pilot findings are summarized as archetypes rather than confirmatory data.

Recommended repository location:

`docs/theory/PRAYCG_Working_Theory_PUBLIC_SAFE_v0_6.md`

Recommended claim label:

`Public research draft - exploratory protocol and software architecture only.`
