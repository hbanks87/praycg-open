# Changelog

## v1.0 - Public-safe master theory and protocol

- Consolidated current PRAYCG theory and protocol into one GitHub-ready document.
- Added phase-scrambled Control doctrine: Control is a meaning-damaged sensory-control, not a physiologically dead branch.
- Added PRAYCG2.0 protocol timeline and final reflection baseline.
- Added MediaPrep, anchor, acquisition, LSL, ALS/PT19, Polar H10, Vernier respiration, and LabRecorder sections.
- Added Master Comprehensive Suite tier map: primary, secondary, exploratory/convergence.
- Added formulas and public-safe interpretation for MRED, A-MRED, MRED-Peak, MRED-Resolution, NIP, TTI, NUPI, DGA, CET-R, and Topo-OSM quarantine.
- Added confirmation-grade decision rule.
- Added public release and ethics boundaries.
