# PRAYCG Master Theory and Protocol - Public v1.0

This package contains a public-safe master theory and protocol document for the PRAYCG open-source repository.

Files:

- `PRAYCG_Master_Theory_and_Protocol_PUBLIC_v1_0.md` - GitHub Markdown version
- `PRAYCG_Master_Theory_and_Protocol_PUBLIC_v1_0.docx` - editable manuscript
- `PRAYCG_Master_Theory_and_Protocol_PUBLIC_v1_0.pdf` - PDF version
- `GITHUB_UPLOAD_NOTES.md` - suggested repository location and release notes

Document boundary: exploratory methods architecture only. Not a clinical tool, not a diagnostic system, and not proof of consciousness, OSM biology, molecular memory, or metaphysical claims.
