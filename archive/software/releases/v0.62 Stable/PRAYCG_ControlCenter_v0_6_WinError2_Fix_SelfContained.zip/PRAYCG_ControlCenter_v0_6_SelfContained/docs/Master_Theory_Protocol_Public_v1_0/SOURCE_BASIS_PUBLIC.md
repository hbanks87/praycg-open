# Source basis for this public-safe master document

This public-safe master theory and protocol document consolidates the current PRAYCG open-method materials into a single GitHub-facing document.

Source categories used:

- PRAYCG2.0 runner behavior and event-log structure.
- MediaPrep / StimulusFingerprint doctrine and output maps.
- ALS/PT19 timing-square checklist and control-audio QC doctrine.
- Vernier respiration and Polar H10 LSL stream scripts.
- Master Comprehensive Analysis Suite module hierarchy through v1.5.6 DGA.
- Public-safe theory drafts and claim-boundary documents.
- Pilot interpretation categories from Arrival, Contact, Field of Dreams, and Eternal Sunshine, treated only as hypothesis-generating archetypes.

Excluded from this public-safe package:

- raw XDF recordings;
- copyrighted stimulus media;
- unredacted private self-report logs;
- private local path examples beyond generic examples;
- any claim that pilot data are confirmation-grade evidence.
