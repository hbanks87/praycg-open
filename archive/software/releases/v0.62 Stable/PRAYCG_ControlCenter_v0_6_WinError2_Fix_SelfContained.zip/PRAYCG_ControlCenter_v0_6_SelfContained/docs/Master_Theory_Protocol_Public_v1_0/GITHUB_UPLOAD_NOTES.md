# GitHub upload notes

Suggested location in the `praycg-open` repository:

```text
docs/PRAYCG_Master_Theory_and_Protocol_PUBLIC_v1_0.md
docs/PRAYCG_Master_Theory_and_Protocol_PUBLIC_v1_0.pdf
docs/PRAYCG_Master_Theory_and_Protocol_PUBLIC_v1_0.docx
```

Suggested README link text:

```markdown
- [Master Theory and Protocol](docs/PRAYCG_Master_Theory_and_Protocol_PUBLIC_v1_0.md)
```

Do not upload copyrighted stimulus clips or raw private XDF data with this document.
