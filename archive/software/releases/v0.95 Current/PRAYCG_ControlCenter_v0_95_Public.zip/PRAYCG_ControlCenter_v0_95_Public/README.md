# PRAYCG Control Center v0.95 Public

PRAYCG Control Center is a Windows dashboard for organizing, launching, monitoring, and reviewing the PRAYCG research workflow. v0.95 retains v0.94's hash-locked protocol library, CAI/SID, continuous-autonomic, and prospective-study tools, and adds the frozen exploratory **Micro Handoff v0.1** raw-EEG candidate.

## Start here

1. Extract the complete ZIP to a normal folder; do not run from a ZIP preview.
2. Install Python 3.11 if needed.
3. Run `INSTALL_PRAYCG_REQUIREMENTS_v0_95.bat` once.
4. Run `run_PRAYCG_ControlCenter_v0_95.bat`.
5. In Settings, choose **Use Bundled Paths**, locate external PsychoPy and LabRecorder installations, and save.
6. Select a stimulus and run folder. The Control Center passes that active context to MediaPrep, Master Suite, chained analysis, HOC-R, the Visualizer, the Interpreter, and the new exploratory tools.

PsychoPy and LabRecorder are external and are not bundled.

## Standard workflow

- PRAYCG3 v3.0: original fixed-order three-prong protocol.
- PRAYCG4 v4.0: fixed-order four-branch protocol with ShotOrder after the completed PhaseScrambled washout/report.
- SMG v1.0: conditional Semantic Meaning Gradient acquisition module.
- MediaPrep / Stimulus Fingerprint v1.9 ShotOrder.
- Master Comprehensive Suite v1.6.1 chain with v1.6.0 canonical core.
- MasterSync Visualizer v1.4.0 and Offline Interpreter v1.6.0.
- BrainFlow EEG-only and EEG+ALS bridges, Polar H10, Vernier respiration, signal-quality, barcode, holder-placement, and optional 30-second acquisition-validation tools.

The Running Tools panel has a visible Close control on every process row, along with log, force-close, folder, and restart actions.

## New exploratory analysis section

The Analysis tab now has a visibly separate **Exploratory Analysis** area:

- **CAI/SID v0.2 readiness preflight:** finds a plausible feature frame and verifies protocol/conditions, unique blocks, monotonic timestamps and gaps, Baseline 1, required columns, branch coverage, artifact sentinels, ALS status, legacy adapter grade, and availability of autonomic, DGA, ShotOrder, and anchor evidence. It reports `PASS`, `CAUTION`, or `INELIGIBLE` with reasons.
- **CAI/SID v0.2 launcher:** requires a non-ineligible preflight and links to branch summaries, contrasts, warnings, validation, and readiness reports. The candidate uses the corrected positive loop, equal-weight primary support, hard-QC missingness, and separate DGA/context gating.
- **Continuous Autonomic / RespDualPath v1.0:** exports beat events, interpolation-flagged HR, beat-derived rolling HRV, respiration rate/depth/phase/velocity, sigh/hold candidates, an artifact path, HR-respiration coupling with circular-shift nulls, and coverage/QC reports.
- **Micro Handoff v0.1:** reads raw XDF EEG, computes prespecified temporal-gamma and theta state estimates on a 25 ms output grid, evaluates a fixed 100–1000 ms lag bank, and reports coordination, directional positive handoff, activation-weighted density, hard-QC missingness, declared nulls, and descriptive condition contrasts. The selected run, resolved XDF, preferred analysis folder, and output location are passed automatically.

CAI means **Controlled Access-Integration Index**. It is a bounded, unitless proxy—not a probability, consciousness measurement, clinical result, or proof of narrative reception. Micro Handoff is an EEG temporal-gamma/theta coordination proxy—not a direct measurement of consciousness, proof of 40 Hz perceptual frames, clinical result, or validated “consciousness RPM” gauge. Autonomic, DGA, and Micro Handoff outputs do not enter primary CAI, and none of these exploratory outputs changes Master Suite eligibility or primary conclusions.

The public Micro Handoff folder includes its mathematical specification, locked configuration, hashes, synthetic acceptance plan, unit tests, and summary evidence from a 14-check raw-signal synthetic validation. Historical biosignals and historical output tables are deliberately excluded from the public archive.

## Prospective study package

The Prospective Study Console provides ten separately identified, fixed-sequence PRAYCG3/PRAYCG4 candidate runners generated from Williams counterbalancing: six for the three-condition protocol and four for the four-condition protocol. Each assigned sequence remains immutable during a run. The candidates retain Baseline 1, a washout and report after every branch, Baseline 2/final reflection, and the final report. They add recognition, comprehension, confidence, narrative-coherence, and structured subjective outcomes that remain independent of CAI construction.

The package also includes deterministic participant/stimulus assignment, runner-registered ALS barcode requirements, a barcode placement script-location test requirement, complete input hashing, blinded operational-feasibility auditing, illustrative sample-size simulation, an OSF preregistration draft, and a prospective Gates 7–10 promotion audit.

The public PRAYCG3/PRAYCG4 modules are unchanged. Counterbalanced candidates are separately labeled prospective extensions.

## Evidence-sensitive limitations

The included synthetic dry-runs validate software behavior only. No human feasibility pilot, confirmatory study, real-hardware ALS test, ethics/consent review, or OSF registration was performed during packaging. The prospective template intentionally reports missing real stimulus/anchor inputs and remains `TEMPLATE_NOT_COLLECTION_READY`. Illustrative variance inputs are not a final sample-size determination.

CAI/SID remains `EXPLORATORY`. It may be considered for `STANDARD_SECONDARY` only after a frozen prospective pipeline establishes held-out criterion validity, reliability/calibration, and complete bounded/null reporting. Micro Handoff v0.1 remains `EXPLORATORY_DEVELOPMENT_CANDIDATE`; synthetic PASS establishes software behavior only, and the historical evaluation does not justify construct promotion. Null and reversed results must be reported without post-hoc archetype rescue.

## Public-release boundary

The ZIP excludes participant data, private biosignals, copyrighted research media, source PDFs supplied privately, credentials, local settings, and live acquisition logs. Synthetic software-validation examples are plainly labeled and contain no participant evidence.

Approved author: Hoyt Banks  
Contact: hoytbanks@gmail.com  
GitHub: https://github.com/hbanks87/praycg-open  
OSF: https://osf.io/8n75v/overview?view_only=928f1fa1974b40e89252101d0ba356d3

See `LICENSE.md`, `DISCLAIMER.md`, `RELEASE_NOTES_v0_95.md`, and `BUILD_VALIDATION_v0_95.json` before public or research use.
