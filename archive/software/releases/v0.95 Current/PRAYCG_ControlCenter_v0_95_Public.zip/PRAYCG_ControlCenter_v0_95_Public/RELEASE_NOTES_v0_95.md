# PRAYCG Control Center v0.95 Public Release Notes

Release date: 2026-09-01

v0.95 adds **Micro Handoff v0.1** as an isolated exploratory raw-EEG module. It preserves v0.94's standard protocol library, acquisition safeguards, Master Suite chain, CAI/SID v0.2, continuous-autonomic tools, and prospective study package.

## Micro Handoff v0.1

- Freezes a prespecified temporal-gamma-to-theta coordination candidate before historical condition summaries are interpreted.
- Uses a 25 ms output cadence while explicitly retaining longer causal spectral windows; the output cadence is not claimed as 25 ms spectral resolution.
- Estimates temporal gamma at T5/T6 and theta integration at Pz/P3/P4/T5/T6 using a fixed 16-channel map.
- Uses Baseline 1 robust normalization only, with no full-run normalization fallback.
- Separates three quantities: state coordination, directional positive handoff, and activation-weighted coordination density.
- Prevents jointly low signals from counting as positive handoff; low-low can agree but supplies little or no activation-weighted support.
- Uses a fixed, equal-weight 100–1000 ms lag bank rather than selecting a condition-specific winning lag.
- Treats hard-artifact and timestamp-gap windows as missing rather than zero.
- Reports circular-shift, phase-randomized, block-label, and artifact-matched checks with explicit limitations.
- Records frozen configuration, specification, implementation, test, and synthetic-summary hashes.

## Synthetic acceptance

The raw-signal synthetic suite passed all 14 declared checks. A planted 500 ms handoff was recovered at 600 ms, within the declared ±100 ms tolerance introduced by causal estimation windows. The suite also verified low-low, stationary high-high, reverse-direction, independent, artifact, timestamp-gap, null, and deterministic-repeat behavior.

Synthetic PASS verifies internal computational behavior. It does not establish biological validity, consciousness measurement, clinical utility, 40 Hz perceptual frames, or a valid “consciousness RPM” construct.

## Control Center integration

- Adds a **Micro Handoff v0.1** button to the visibly isolated Exploratory Analysis panel.
- Automatically passes the selected run folder, resolved XDF when available, preferred analysis folder, and a run-specific exploratory output folder.
- Adds the tool to bundled-path rebasing and Settings.
- Adds an explicit exploratory registration: no automatic chain execution, no effect on Master Suite eligibility, no effect on primary conclusions, and no promotion based on retrospective results.
- Updates the public launcher, installer, configuration schema, manifests, and regression coverage to v0.95.

## Historical evaluation boundary

The frozen candidate was evaluated on the available historical archive outside the public package. Of 24 unique XDF recordings, 6 were computationally eligible with caution. Directional Target-minus-Control handoff was mixed around zero; no recording passed both time-structure null families. Activation-weighted Target density was descriptively higher in 5 of 6 eligible runs, but that output is not directional handoff and is confounded by repeated single-participant, stimulus, order, acquisition, and historical-software differences.

The appropriate status is **software-valid, construct-unvalidated, retrospectively mixed**. Historical raw data and result tables are excluded from the public ZIP.

## Retained scientific boundaries

Micro Handoff remains separate from CAI/SID and from the Master Suite primary chain. Promotion requires frozen prospective multi-participant/multi-stimulus testing, independent outcomes, reliability and calibration, declared null convergence, and replication. Passing software tests does not validate narrative reception, consciousness, diagnosis, or a biological, quantum, or metaphysical mechanism.
