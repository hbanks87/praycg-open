#!/usr/bin/env python3
"""
PRAYCG Control Center v0.8 - ALS Holder Calibration Mode

Displays a movable runner-level white square/barcode area so the user can align a
3D-printed ALS/PT19 holder to actual physical-screen coordinates. Optionally samples
an LSL stream/channel live and saves the calibrated coordinate profile.

This is a timing/QC aid only. It validates physical screen timing geometry, not biology.
"""
from __future__ import annotations
import argparse, json, os, sys, time, threading
from datetime import datetime, timezone
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

try:
    from pylsl import StreamInlet, resolve_byprop
except Exception:
    StreamInlet = None
    resolve_byprop = None

class LSLReader:
    def __init__(self, stream_name: str, channel_index_1based: int):
        self.stream_name = stream_name
        self.channel_index = channel_index_1based
        self.latest = None
        self.running = False
        self.status = 'LSL not started'
        self.inlet = None

    def start(self):
        if StreamInlet is None:
            self.status = 'pylsl not installed'
            return
        self.running = True
        th = threading.Thread(target=self._run, daemon=True)
        th.start()

    def _run(self):
        try:
            self.status = f'resolving {self.stream_name}...'
            streams = resolve_byprop('name', self.stream_name, timeout=5.0)
            if not streams:
                self.status = f'stream not found: {self.stream_name}'
                return
            self.inlet = StreamInlet(streams[0], max_buflen=3)
            self.status = 'connected'
            while self.running:
                sample, ts = self.inlet.pull_sample(timeout=0.25)
                if sample is None:
                    continue
                idx = self.channel_index - 1 if self.channel_index > 0 else len(sample) - 1
                if 0 <= idx < len(sample):
                    self.latest = float(sample[idx])
        except Exception as e:
            self.status = f'error: {e}'

class App(tk.Tk):
    def __init__(self, args):
        super().__init__()
        self.args = args
        self.title('PRAYCG ALS Holder Calibration v0.8')
        self.attributes('-fullscreen', args.fullscreen)
        self.configure(bg='black')
        self.size_px = args.size_px
        self.margin = args.margin_px
        self.x = args.x if args.x is not None else max(40, self.winfo_screenwidth() - self.size_px - self.margin)
        self.y = args.y if args.y is not None else max(40, self.winfo_screenheight() - self.size_px - self.margin)
        self.reader = LSLReader(args.stream_name, args.channel_index)
        self.reader.start()
        self.canvas = tk.Canvas(self, bg='black', highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)
        self.label = tk.Label(self.canvas, text='', bg='black', fg='white', font=('Segoe UI', 14))
        self.label_id = self.canvas.create_window(10, 10, anchor='nw', window=self.label)
        self.rect = None
        self.bind('<Escape>', lambda e: self.destroy())
        self.bind('<Left>', lambda e: self.move(-args.step_px,0))
        self.bind('<Right>', lambda e: self.move(args.step_px,0))
        self.bind('<Up>', lambda e: self.move(0,-args.step_px))
        self.bind('<Down>', lambda e: self.move(0,args.step_px))
        self.bind('<Shift-Left>', lambda e: self.move(-1,0))
        self.bind('<Shift-Right>', lambda e: self.move(1,0))
        self.bind('<Shift-Up>', lambda e: self.move(0,-1))
        self.bind('<Shift-Down>', lambda e: self.move(0,1))
        self.bind('+', lambda e: self.resize(10))
        self.bind('=', lambda e: self.resize(10))
        self.bind('-', lambda e: self.resize(-10))
        self.bind('<space>', lambda e: self.flash_barcode())
        self.bind('s', lambda e: self.save_profile())
        self.bind('S', lambda e: self.save_profile())
        self.after(100, self.redraw)

    def move(self, dx, dy):
        self.x = max(0, min(self.winfo_screenwidth()-self.size_px, self.x+dx))
        self.y = max(0, min(self.winfo_screenheight()-self.size_px, self.y+dy))
        self.redraw()

    def resize(self, d):
        self.size_px = max(20, min(600, self.size_px + d))
        self.redraw()

    def redraw(self):
        self.canvas.delete('pulse')
        self.canvas.create_rectangle(self.x, self.y, self.x+self.size_px, self.y+self.size_px, fill='white', outline='white', tags='pulse')
        latest = 'NA' if self.reader.latest is None else f'{self.reader.latest:.3f}'
        self.label.config(text=(
            'ALS Holder Calibration v0.8\n'
            'Arrow keys move | Shift+Arrow fine move | +/- resize | SPACE barcode | S save | ESC quit\n'
            f'x={self.x} y={self.y} size={self.size_px}  stream={self.args.stream_name} ch={self.args.channel_index} latest={latest}\n'
            f'LSL status: {self.reader.status}'
        ))
        self.after(250, self.redraw)

    def flash_barcode(self):
        # display long-short barcode at current coordinate without trying to record it here
        seq = [(0,0.5), (1,2.0), (0,0.5), (1,0.75), (0,1.0)]
        def run():
            for val, dur in seq:
                self.canvas.delete('pulse')
                color = 'white' if val else 'black'
                outline = 'white' if val else 'black'
                self.canvas.create_rectangle(self.x, self.y, self.x+self.size_px, self.y+self.size_px, fill=color, outline=outline, tags='pulse')
                self.update()
                time.sleep(dur)
            self.redraw()
        threading.Thread(target=run, daemon=True).start()

    def save_profile(self):
        out = Path(self.args.out).expanduser()
        out.parent.mkdir(parents=True, exist_ok=True)
        profile = {
            'schema': 'PRAYCG_ALS_holder_profile_v0_8',
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'holder_name': self.args.holder_name,
            'screen_width_px': self.winfo_screenwidth(),
            'screen_height_px': self.winfo_screenheight(),
            'overlay_x_px': int(self.x),
            'overlay_y_px': int(self.y),
            'overlay_size_px': int(self.size_px),
            'stream_name': self.args.stream_name,
            'channel_index_1based': self.args.channel_index,
            'latest_sample_at_save': self.reader.latest,
            'barcode_pattern_sec': {'black_pre':0.5,'white_A':2.0,'black_gap':0.5,'white_B':0.75,'black_post':1.0},
            'boundary': 'Physical display-timing holder calibration only; not a biological signal claim.'
        }
        out.write_text(json.dumps(profile, indent=2), encoding='utf-8')
        messagebox.showinfo('Saved', f'ALS holder profile saved:\n{out}')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--stream-name', default='obci_eeg1')
    ap.add_argument('--channel-index', type=int, default=-1, help='1-based channel index, -1 means last sample channel')
    ap.add_argument('--size-px', type=int, default=220)
    ap.add_argument('--margin-px', type=int, default=40)
    ap.add_argument('--step-px', type=int, default=10)
    ap.add_argument('--x', type=int, default=None)
    ap.add_argument('--y', type=int, default=None)
    ap.add_argument('--holder-name', default='Laptop_ALS_PT19_holder_openscadfile2')
    ap.add_argument('--out', default=str(Path.home()/ 'PRAYCG_ALS_holder_profile_v0_8.json'))
    ap.add_argument('--windowed', action='store_true')
    args=ap.parse_args()
    args.fullscreen = not args.windowed
    App(args).mainloop()
if __name__ == '__main__':
    main()
