#!/usr/bin/env python3
"""Protocol-library discovery, structural validation, and immutable lock helpers."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple


MODULE_SCHEMA = "PRAYCG_ProtocolModule_v1_0"
LOCK_SCHEMA = "PRAYCG_ProtocolLock_v1_0"
ENGINE_VERSION = "3.0"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def load_protocol_module(path: Path, library_root: Path) -> Dict[str, Any]:
    path = Path(path).expanduser().resolve()
    library_root = Path(library_root).expanduser().resolve()
    protocol_root = (library_root / "protocols").resolve()
    if not path.is_file() or not _within(path, protocol_root):
        raise ValueError(f"Protocol manifest must be a file inside {protocol_root}: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or payload.get("schema") != MODULE_SCHEMA:
        raise ValueError(f"Unsupported protocol schema in {path.name}")
    for key in ("protocol_id", "protocol_version", "display_name", "runner_entry", "engine_version", "branches", "integrity_constraints", "scientific_boundary"):
        if key not in payload:
            raise ValueError(f"{path.name} is missing required field: {key}")
    if str(payload["engine_version"]) != ENGINE_VERSION:
        raise ValueError(f"{path.name} requires engine {payload['engine_version']}; expected {ENGINE_VERSION}")
    if payload.get("branch_order_fixed") is not True:
        raise ValueError(f"{path.name} must declare branch_order_fixed=true")
    branches = payload.get("branches")
    if not isinstance(branches, list) or not branches:
        raise ValueError(f"{path.name} has no protocol branches")
    phases: set[str] = set()
    report_phases: set[str] = set()
    media_keys: set[str] = set()
    for index, branch in enumerate(branches, start=1):
        if not isinstance(branch, dict):
            raise ValueError(f"{path.name} branch {index} must be an object")
        for key in ("phase", "condition_role", "media_key", "media_label", "instruction", "cue_mode", "washout_phase", "report_phase", "branch_type", "rating_items"):
            if key not in branch:
                raise ValueError(f"{path.name} branch {index} is missing {key}")
        phase = str(branch["phase"]).strip()
        if not phase or phase in phases:
            raise ValueError(f"{path.name} contains a blank or duplicate branch phase: {phase!r}")
        report_phase = str(branch["report_phase"]).strip()
        if not report_phase or report_phase in report_phases:
            raise ValueError(f"{path.name} contains a blank or duplicate report phase: {report_phase!r}")
        phases.add(phase)
        report_phases.add(report_phase)
        media_key = str(branch["media_key"]).strip()
        if not media_key:
            raise ValueError(f"{path.name} branch {phase} has a blank media_key")
        media_keys.add(media_key)
        if str(branch["cue_mode"]) not in {"none", "ignore", "working_memory_sum"}:
            raise ValueError(f"{path.name} has unsupported cue_mode in {phase}")
        ratings = branch.get("rating_items")
        if not isinstance(ratings, list) or not ratings or any(not str(value).strip() for value in ratings):
            raise ValueError(f"{path.name} branch {phase} has no rating_items")
    required_media = {str(value) for value in payload.get("integrity_constraints", {}).get("required_media_keys", [])}
    if not required_media.issubset(media_keys):
        raise ValueError(f"{path.name} requires media keys not used by a branch: {sorted(required_media - media_keys)}")
    runner = (library_root / str(payload["runner_entry"])).resolve()
    if not runner.is_file() or runner.suffix.lower() != ".py" or not _within(runner, library_root / "scripts"):
        raise ValueError(f"Runner entry must be a Python file inside the library scripts folder: {runner}")
    return {
        "manifest_path": str(path),
        "manifest_sha256": sha256_file(path),
        "runner_path": str(runner),
        "runner_sha256": sha256_file(runner),
        "protocol_id": str(payload["protocol_id"]),
        "protocol_version": str(payload["protocol_version"]),
        "display_name": str(payload["display_name"]),
        "short_description": str(payload.get("short_description", "")),
        "branch_count": len(branches),
        "branch_order": [str(branch["phase"]) for branch in branches],
        "scientific_boundary": str(payload["scientific_boundary"]),
        "module": payload,
    }


def discover_protocol_modules(library_root: Path) -> Tuple[List[Dict[str, Any]], List[str]]:
    library_root = Path(library_root).expanduser().resolve()
    records: List[Dict[str, Any]] = []
    errors: List[str] = []
    for path in sorted((library_root / "protocols").glob("*.json")):
        if path.name == "protocol_module_schema_v1_0.json":
            continue
        try:
            records.append(load_protocol_module(path, library_root))
        except Exception as exc:
            errors.append(f"{path.name}: {exc}")
    records.sort(key=lambda record: (record["protocol_id"].lower(), record["protocol_version"]))
    counts: Dict[Tuple[str, str], int] = {}
    for record in records:
        identity = (record["protocol_id"].casefold(), record["protocol_version"])
        counts[identity] = counts.get(identity, 0) + 1
    duplicates = {identity for identity, count in counts.items() if count > 1}
    if duplicates:
        for protocol_id, protocol_version in sorted(duplicates):
            errors.append(f"Duplicate protocol identity is not allowed: {protocol_id} v{protocol_version}")
        records = [
            record for record in records
            if (record["protocol_id"].casefold(), record["protocol_version"]) not in duplicates
        ]
    return records, errors


def write_protocol_lock(record: Dict[str, Any], lock_path: Path) -> Dict[str, Any]:
    lock_path = Path(lock_path).expanduser().resolve()
    lock = {
        "schema": LOCK_SCHEMA,
        "locked_unix_time": time.time(),
        "protocol_id": record["protocol_id"],
        "protocol_version": record["protocol_version"],
        "display_name": record["display_name"],
        "manifest_path": record["manifest_path"],
        "manifest_sha256": record["manifest_sha256"],
        "runner_path": record["runner_path"],
        "runner_sha256": record["runner_sha256"],
        "branch_count": record["branch_count"],
        "branch_order": record["branch_order"],
        "scientific_boundary": record["scientific_boundary"],
    }
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = lock_path.with_suffix(lock_path.suffix + ".tmp")
    temporary.write_text(json.dumps(lock, indent=2), encoding="utf-8")
    temporary.replace(lock_path)
    return lock


def validate_protocol_lock(lock_path: Path, library_root: Path) -> Dict[str, Any]:
    lock_path = Path(lock_path).expanduser().resolve()
    if not lock_path.is_file():
        raise FileNotFoundError("No protocol is locked.")
    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    if not isinstance(lock, dict) or lock.get("schema") != LOCK_SCHEMA:
        raise ValueError("Protocol lock has an unsupported schema.")
    record = load_protocol_module(Path(str(lock.get("manifest_path", ""))), library_root)
    checks = {
        "protocol_id": record["protocol_id"] == str(lock.get("protocol_id", "")),
        "protocol_version": record["protocol_version"] == str(lock.get("protocol_version", "")),
        "manifest_sha256": record["manifest_sha256"] == str(lock.get("manifest_sha256", "")),
        "runner_path": Path(record["runner_path"]).resolve() == Path(str(lock.get("runner_path", ""))).expanduser().resolve(),
        "runner_sha256": record["runner_sha256"] == str(lock.get("runner_sha256", "")),
        "branch_order": record["branch_order"] == lock.get("branch_order"),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ValueError("Locked protocol no longer matches the library: " + ", ".join(failed))
    return {**lock, "validation": "PASS", "record": record}
