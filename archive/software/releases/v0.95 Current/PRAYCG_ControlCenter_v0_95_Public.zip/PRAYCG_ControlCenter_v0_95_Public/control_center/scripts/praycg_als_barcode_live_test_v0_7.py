#!/usr/bin/env python3
"""PRAYCG ALS Barcode Live Test v0.7.

Displays the PRAYCG2.2 long/short ALS barcode and optionally records one LSL channel
from a live stream to classify PASS / WEAK / CLIPPED / MISSING.

Default barcode:
  black 0.50 s -> white A 2.00 s -> black gap 0.50 s -> white B 0.75 s -> black post 1.00 s

This is a setup/QC tool. It is not a biological measurement endpoint.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


def _import_pylsl():
    try:
        from pylsl import StreamInlet, resolve_byprop, local_clock
        return StreamInlet, resolve_byprop, local_clock
    except Exception:
        return None, None, None


def robust_median(xs: List[float]) -> float:
    vals = sorted(x for x in xs if math.isfinite(x))
    if not vals:
        return float('nan')
    n = len(vals)
    return vals[n//2] if n % 2 else 0.5 * (vals[n//2-1] + vals[n//2])


def percentile(xs: List[float], q: float) -> float:
    vals = sorted(x for x in xs if math.isfinite(x))
    if not vals:
        return float('nan')
    idx = int(round((len(vals)-1) * q))
    return vals[max(0, min(idx, len(vals)-1))]


class LSLRecorder:
    def __init__(self, stream_name: str, channel_index_1based: int, duration_sec: float, out_dir: Path):
        self.stream_name = stream_name
        self.channel_index_1based = channel_index_1based
        self.duration_sec = duration_sec
        self.out_dir = out_dir
        self.samples: List[Tuple[float, float]] = []
        self.error: Optional[str] = None
        self.started_lsl: Optional[float] = None

    def run(self) -> None:
        StreamInlet, resolve_byprop, local_clock = _import_pylsl()
        if StreamInlet is None:
            self.error = 'pylsl not installed; displayed barcode only.'
            return
        try:
            streams = resolve_byprop('name', self.stream_name, timeout=5.0)
            if not streams:
                self.error = f'LSL stream not found: {self.stream_name}'
                return
            inlet = StreamInlet(streams[0], max_buflen=10)
            self.started_lsl = float(local_clock())
            deadline = time.time() + self.duration_sec
            while time.time() < deadline:
                sample, ts = inlet.pull_sample(timeout=0.05)
                if sample is None:
                    continue
                if self.channel_index_1based == -1:
                    idx = len(sample) - 1
                else:
                    idx = max(0, min(len(sample)-1, self.channel_index_1based - 1))
                try:
                    val = float(sample[idx])
                except Exception:
                    val = float('nan')
                self.samples.append((float(ts), val))
        except Exception as exc:
            self.error = repr(exc)


def classify_samples(samples: List[Tuple[float, float]], design: Dict[str, float]) -> Dict[str, Any]:
    if not samples:
        return {'status': 'NO_DATA', 'reason': 'No LSL samples were recorded.'}
    t0 = samples[0][0]
    times = [t - t0 for t, _ in samples]
    vals = [v for _, v in samples]
    total = design['black_pre'] + design['white_a'] + design['black_gap'] + design['white_b'] + design['black_post']
    def seg(start: float, end: float) -> List[float]:
        return [v for t, v in zip(times, vals) if start <= t < end and math.isfinite(v)]
    b1 = seg(0, design['black_pre'])
    a = seg(design['black_pre'], design['black_pre'] + design['white_a'])
    gap_start = design['black_pre'] + design['white_a']
    g = seg(gap_start, gap_start + design['black_gap'])
    b_start = gap_start + design['black_gap']
    b = seg(b_start, b_start + design['white_b'])
    post = seg(b_start + design['white_b'], total)
    med_b1 = robust_median(b1)
    med_a = robust_median(a)
    med_g = robust_median(g)
    med_b = robust_median(b)
    med_post = robust_median(post)
    finite = [x for x in vals if math.isfinite(x)]
    span = (max(finite) - min(finite)) if finite else float('nan')
    black_ref = robust_median(b1 + g + post)
    white_ref = robust_median(a + b)
    amp = white_ref - black_ref if math.isfinite(white_ref) and math.isfinite(black_ref) else float('nan')
    p99 = percentile(finite, .99) if finite else float('nan')
    p01 = percentile(finite, .01) if finite else float('nan')
    clipped = False
    if finite and span > 0:
        near_top = sum(1 for x in finite if x >= p99 - 1e-12) / len(finite)
        clipped = near_top > 0.95
    score = 0.0
    for w in [(med_a, med_b1), (med_a, med_g), (med_b, med_g), (med_b, med_post)]:
        if all(math.isfinite(x) for x in w):
            score += max(0.0, w[0] - w[1])
    if clipped:
        status = 'CLIPPED'
    elif math.isfinite(amp) and amp > max(1e-6, 0.10 * max(abs(span), 1e-6)) and score > 0:
        status = 'PASS'
    elif math.isfinite(amp) and amp > 0:
        status = 'WEAK'
    else:
        status = 'MISSING'
    return {
        'status': status,
        'n_samples': len(samples),
        'span': span,
        'amplitude_white_minus_black': amp,
        'median_black_pre': med_b1,
        'median_white_a': med_a,
        'median_gap': med_g,
        'median_white_b': med_b,
        'median_post': med_post,
        'clipped': clipped,
        'barcode_score_raw': score,
        'duration_recorded_sec': times[-1] - times[0] if len(times) > 1 else 0,
    }


def display_tk_barcode(args: argparse.Namespace, design: Dict[str, float]) -> None:
    import tkinter as tk
    root = tk.Tk()
    root.title('PRAYCG ALS Barcode Live Test v0.7')
    if args.fullscreen:
        root.attributes('-fullscreen', True)
    else:
        root.geometry('900x600')
    root.configure(bg='black')
    w = root.winfo_screenwidth()
    h = root.winfo_screenheight()
    canvas = tk.Canvas(root, bg='black', highlightthickness=0)
    canvas.pack(fill='both', expand=True)
    size = int(args.size_px)
    margin = int(args.margin_px)
    pos = args.pulse_position.lower()
    if pos == 'fullscreen':
        rect = (0, 0, w, h)
    else:
        x1 = margin if 'left' in pos else w - margin - size
        y1 = margin if ('upper' in pos or 'top' in pos) else h - margin - size
        rect = (x1, y1, x1 + size, y1 + size)
    schedule = [
        ('black_pre', False, design['black_pre']),
        ('white_a', True, design['white_a']),
        ('black_gap', False, design['black_gap']),
        ('white_b', True, design['white_b']),
        ('black_post', False, design['black_post']),
    ]
    def show_segment(i: int = 0):
        canvas.delete('all')
        if i >= len(schedule):
            root.destroy()
            return
        name, white, dur = schedule[i]
        if white:
            canvas.create_rectangle(*rect, fill='white', outline='white')
        canvas.create_text(w/2, 40, fill='gray80', text=f'ALS barcode test: {name} ({dur:.2f}s)')
        root.after(int(dur * 1000), lambda: show_segment(i+1))
    root.bind('<Escape>', lambda e: root.destroy())
    root.after(250, show_segment)
    root.mainloop()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--stream-name', default='obci_eeg1')
    ap.add_argument('--channel-index', type=int, default=-1, help='1-based channel index; -1 = last channel')
    ap.add_argument('--out-dir', default='als_pulse_tests')
    ap.add_argument('--fullscreen', action='store_true')
    ap.add_argument('--pulse-position', default='lower_right', choices=['lower_right','lower_left','upper_right','upper_left','fullscreen'])
    ap.add_argument('--size-px', type=int, default=180)
    ap.add_argument('--margin-px', type=int, default=40)
    ap.add_argument('--black-pre-sec', type=float, default=0.50)
    ap.add_argument('--white-a-sec', type=float, default=2.00)
    ap.add_argument('--black-gap-sec', type=float, default=0.50)
    ap.add_argument('--white-b-sec', type=float, default=0.75)
    ap.add_argument('--black-post-sec', type=float, default=1.00)
    args = ap.parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    design = {'black_pre': args.black_pre_sec, 'white_a': args.white_a_sec, 'black_gap': args.black_gap_sec, 'white_b': args.white_b_sec, 'black_post': args.black_post_sec}
    total = sum(design.values()) + 1.0
    rec = LSLRecorder(args.stream_name, args.channel_index, total, out_dir)
    th = threading.Thread(target=rec.run, daemon=True)
    th.start()
    display_tk_barcode(args, design)
    th.join(timeout=max(0.1, total + 1.0))
    result = classify_samples(rec.samples, design)
    result.update({
        'schema': 'PRAYCG_ALS_Barcode_Live_Test_v0_7',
        'created_utc': datetime.utcnow().isoformat() + 'Z',
        'stream_name': args.stream_name,
        'channel_index_1based': args.channel_index,
        'display_mode': 'tkinter_fullscreen' if args.fullscreen else 'tkinter_windowed',
        'pulse_position': args.pulse_position,
        'size_px': args.size_px,
        'margin_px': args.margin_px,
        'design': design,
        'lsl_error': rec.error,
        'boundary': 'ALS barcode validates physical display timing only; it is not a biological endpoint.'
    })
    path = out_dir / f'als_barcode_live_test_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
    path.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
    print(f'Wrote: {path}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
