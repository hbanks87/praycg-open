#!/usr/bin/env python3
"""Optional 30-second PRAYCG acquisition validation.

This utility is intentionally independent of protocol-runner arming.  It records
short LSL samples, presents a small black/white ALS barcode when run with the GUI,
and writes transparent JSON, Markdown, and per-channel CSV diagnostics.

The 0-100 contact index is a documented engineering heuristic.  It is not an
impedance measurement, medical assessment, or guarantee that a run is valid.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import threading
import time
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

try:
    from pylsl import StreamInlet, local_clock, resolve_byprop
except Exception as exc:  # pragma: no cover - deployment guard
    raise SystemExit("pylsl is required for the acquisition preflight: " + repr(exc))


TOOL_VERSION = "1.0"
SCHEMA = "PRAYCG_Acquisition_Preflight_v1_0"


@dataclass
class Capture:
    name: str
    nominal_rate_hz: float
    channel_count: int
    samples: List[List[float]]
    timestamps: List[float]
    error: str = ""


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default


def resolve_one(name: str, timeout: float = 4.0):
    streams = resolve_byprop("name", name, timeout=timeout)
    return streams[0] if streams else None


def capture_stream(name: str, duration: float, ready: threading.Event, start: threading.Event) -> Capture:
    info = resolve_one(name)
    if info is None:
        ready.set()
        return Capture(name, 0.0, 0, [], [], f"LSL stream not found: {name}")
    nominal = _finite(info.nominal_srate())
    channels = int(info.channel_count())
    inlet = StreamInlet(info, max_buflen=max(15, int(duration + 10)), recover=True)
    try:
        inlet.open_stream(timeout=3.0)
    except TypeError:
        inlet.open_stream()
    ready.set()
    start.wait(timeout=10.0)
    samples: List[List[float]] = []
    stamps: List[float] = []
    deadline = local_clock() + duration
    while local_clock() < deadline:
        chunk, ts = inlet.pull_chunk(timeout=0.20, max_samples=512)
        if chunk:
            samples.extend([[float(x) for x in row] for row in chunk])
            stamps.extend(float(x) for x in ts)
    try:
        inlet.close_stream()
    except Exception:
        pass
    return Capture(name, nominal, channels, samples, stamps)


def record_pair(eeg_name: str, als_name: str, duration: float) -> Tuple[Capture, Capture]:
    ready_eeg = threading.Event()
    ready_als = threading.Event()
    start = threading.Event()
    results: Dict[str, Capture] = {}

    def worker(key: str, name: str, ready: threading.Event) -> None:
        results[key] = capture_stream(name, duration, ready, start)

    t1 = threading.Thread(target=worker, args=("eeg", eeg_name, ready_eeg), daemon=True)
    t2 = threading.Thread(target=worker, args=("als", als_name, ready_als), daemon=True)
    t1.start(); t2.start()
    ready_eeg.wait(6.0); ready_als.wait(6.0)
    start.set()
    t1.join(duration + 12.0); t2.join(duration + 12.0)
    return (
        results.get("eeg", Capture(eeg_name, 0.0, 0, [], [], "EEG capture did not finish")),
        results.get("als", Capture(als_name, 0.0, 0, [], [], "ALS capture did not finish")),
    )


def timestamp_metrics(stamps: np.ndarray, nominal_rate: float) -> Dict[str, Any]:
    if stamps.size < 2:
        return {
            "sample_count": int(stamps.size), "duration_sec": 0.0, "effective_rate_hz": 0.0,
            "monotonic_violations": 0, "duplicate_timestamps": 0, "max_gap_sec": None,
            "large_gap_count": 0,
        }
    diffs = np.diff(stamps)
    positive = diffs[diffs > 0]
    duration = float(stamps[-1] - stamps[0])
    effective = float((stamps.size - 1) / duration) if duration > 0 else 0.0
    expected_dt = 1.0 / nominal_rate if nominal_rate > 0 else (float(np.median(positive)) if positive.size else 0.0)
    large_limit = max(0.050, expected_dt * 2.5) if expected_dt > 0 else 0.050
    return {
        "sample_count": int(stamps.size),
        "duration_sec": duration,
        "effective_rate_hz": effective,
        "monotonic_violations": int(np.sum(diffs < 0)),
        "duplicate_timestamps": int(np.sum(diffs == 0)),
        "max_gap_sec": float(np.max(positive)) if positive.size else None,
        "large_gap_count": int(np.sum(positive > large_limit)),
        "large_gap_threshold_sec": large_limit,
    }


def eeg_channel_metrics(samples: np.ndarray, saturation_uv: float = 100000.0) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if samples.ndim != 2:
        return rows
    for idx in range(samples.shape[1]):
        x = samples[:, idx].astype(float, copy=False)
        finite = np.isfinite(x)
        xf = x[finite]
        if xf.size:
            diffs = np.diff(xf)
            std = float(np.std(xf))
            p2p = float(np.ptp(xf))
            med_abs_step = float(np.median(np.abs(diffs))) if diffs.size else 0.0
            flat_fraction = float(np.mean(np.abs(diffs) < 1e-6)) if diffs.size else 1.0
            saturation_fraction = float(np.mean(np.abs(xf) >= saturation_uv))
        else:
            std = p2p = med_abs_step = 0.0
            flat_fraction = saturation_fraction = 1.0
        flags: List[str] = []
        if xf.size == 0 or std < 0.5 or p2p < 2.0 or flat_fraction > 0.98:
            flags.append("flat_or_disconnected")
        if std > 150.0:
            flags.append("high_noise_scale")
        if saturation_fraction > 0.001:
            flags.append("saturation_or_rail")
        if finite.size and float(np.mean(finite)) < 0.999:
            flags.append("nonfinite_samples")
        rows.append({
            "channel_index_1based": idx + 1,
            "finite_fraction": float(np.mean(finite)) if finite.size else 0.0,
            "std_uv": std,
            "peak_to_peak_uv": p2p,
            "median_abs_step_uv": med_abs_step,
            "flat_step_fraction": flat_fraction,
            "saturation_fraction": saturation_fraction,
            "flags": flags,
        })
    return rows


def als_metrics(capture: Capture) -> Dict[str, Any]:
    if not capture.samples:
        return {"available": False, "pulse_visible": False, "reason": capture.error or "no ALS samples"}
    a = np.asarray(capture.samples, dtype=float)
    x = a[:, 0] if a.ndim == 2 else a.reshape(-1)
    x = x[np.isfinite(x)]
    if x.size < 10:
        return {"available": True, "pulse_visible": False, "reason": "too few finite ALS samples", "sample_count": int(x.size)}
    p05, p50, p95 = [float(v) for v in np.percentile(x, [5, 50, 95])]
    span = p95 - p05
    threshold = (p05 + p95) / 2.0
    states = x > threshold
    transitions = int(np.sum(states[1:] != states[:-1]))
    noise = float(np.median(np.abs(x - np.median(x)))) * 1.4826
    contrast_to_noise = span / max(noise, 1e-9)
    low_plateau = float(np.mean(x <= p05 + max(1e-9, span * 0.02)))
    high_plateau = float(np.mean(x >= p95 - max(1e-9, span * 0.02)))
    visible = bool(span > max(1e-6, abs(p50) * 0.01) and transitions >= 2 and contrast_to_noise >= 2.0)
    return {
        "available": True,
        "sample_count": int(x.size),
        "p05": p05, "median": p50, "p95": p95, "robust_span": span,
        "transition_count": transitions, "robust_noise": noise,
        "contrast_to_noise": contrast_to_noise, "pulse_visible": visible,
        "observed_polarity": "positive_for_white_candidate" if p95 > p05 else "undetermined",
        "low_plateau_fraction": low_plateau, "high_plateau_fraction": high_plateau,
        "interpretation": "Screen-pulse visibility heuristic; verify placement and waveform visually before research use.",
    }


def analyze(eeg: Capture, als: Capture, expected_rate: float, require_als: bool) -> Dict[str, Any]:
    stamps = np.asarray(eeg.timestamps, dtype=float)
    timing = timestamp_metrics(stamps, expected_rate or eeg.nominal_rate_hz)
    data = np.asarray(eeg.samples, dtype=float) if eeg.samples else np.empty((0, max(0, eeg.channel_count)))
    channels = eeg_channel_metrics(data)
    als_result = als_metrics(als)
    reasons_fail: List[str] = []
    reasons_warn: List[str] = []
    n = timing["sample_count"]
    effective = float(timing["effective_rate_hz"] or 0.0)
    expected = float(expected_rate or eeg.nominal_rate_hz or 0.0)
    rate_error = abs(effective - expected) / expected if expected > 0 else 0.0
    if eeg.error or n < max(10, int(expected * 5)):
        reasons_fail.append(eeg.error or "insufficient EEG samples")
    if timing["monotonic_violations"]:
        reasons_fail.append("EEG timestamps are not monotonic")
    if expected and rate_error > 0.20:
        reasons_fail.append("effective EEG rate differs from expected by more than 20%")
    elif expected and rate_error > 0.05:
        reasons_warn.append("effective EEG rate differs from expected by more than 5%")
    if timing["large_gap_count"]:
        reasons_warn.append("one or more large EEG timestamp gaps were detected")
    bad_channels = [row for row in channels if row["flags"]]
    if channels and len(bad_channels) > max(1, len(channels) // 4):
        reasons_fail.append("more than 25% of EEG channels have flat/noise/saturation/missingness flags")
    elif bad_channels:
        reasons_warn.append("one or more EEG channels need contact/noise review")
    if require_als and not als_result.get("available"):
        reasons_fail.append("required ALS stream was not available")
    elif require_als and not als_result.get("pulse_visible"):
        reasons_fail.append("required ALS black/white pulse was not clearly visible")
    elif als_result.get("available") and not als_result.get("pulse_visible"):
        reasons_warn.append("ALS stream was present but pulse visibility was weak")

    score = 100.0
    score -= min(30.0, rate_error * 100.0)
    score -= 30.0 if timing["monotonic_violations"] else 0.0
    score -= min(15.0, timing["large_gap_count"] * 3.0)
    if channels:
        score -= 35.0 * (len(bad_channels) / len(channels))
    if require_als and not als_result.get("pulse_visible"):
        score -= 20.0
    score = int(round(max(0.0, min(100.0, score))))
    status = "FAIL" if reasons_fail else ("WARN" if reasons_warn else "PASS")
    return {
        "schema": SCHEMA,
        "tool_version": TOOL_VERSION,
        "created_unix": time.time(),
        "status": status,
        "contact_quality_index_0_100": score,
        "contact_index_scope": "Engineering heuristic only; not electrode impedance or a medical measurement.",
        "eeg": {"stream": asdict(eeg), "timing": timing, "expected_rate_hz": expected, "rate_error_fraction": rate_error, "channels": channels},
        "als": {"required": require_als, "stream_name": als.name, **als_result},
        "fail_reasons": reasons_fail,
        "warning_reasons": reasons_warn,
        "runner_arming_effect": "none; this is a separate optional validation tool",
    }


def write_report(report: Dict[str, Any], out_dir: Path) -> Dict[str, str]:
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    stem = f"PRAYCG_acquisition_preflight_v1_0_{stamp}"
    json_path = out_dir / f"{stem}.json"
    md_path = out_dir / f"{stem}.md"
    csv_path = out_dir / f"{stem}_channels.csv"
    json_path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        fields = ["channel_index_1based", "finite_fraction", "std_uv", "peak_to_peak_uv", "median_abs_step_uv", "flat_step_fraction", "saturation_fraction", "flags"]
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader()
        for row in report["eeg"]["channels"]:
            clean = dict(row); clean["flags"] = ";".join(clean["flags"]); writer.writerow(clean)
    lines = [
        "# PRAYCG 30-Second Acquisition Validation",
        "",
        f"- Status: **{report['status']}**",
        f"- Contact-quality index: **{report['contact_quality_index_0_100']}/100** (engineering proxy; not impedance)",
        f"- EEG samples: {report['eeg']['timing']['sample_count']}",
        f"- Effective EEG rate: {report['eeg']['timing']['effective_rate_hz']:.3f} Hz",
        f"- Timestamp monotonic violations: {report['eeg']['timing']['monotonic_violations']}",
        f"- Large gaps: {report['eeg']['timing']['large_gap_count']}",
        f"- ALS required: {report['als']['required']}",
        f"- ALS pulse visible: {report['als'].get('pulse_visible', False)}",
        "",
        "## Fail reasons",
        "",
        *([f"- {x}" for x in report["fail_reasons"]] or ["- None"]),
        "",
        "## Warnings",
        "",
        *([f"- {x}" for x in report["warning_reasons"]] or ["- None"]),
        "",
        "This report does not arm or block the PRAYCG runner. Review the raw metrics and placement before a research run.",
    ]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"json": str(json_path), "markdown": str(md_path), "channels_csv": str(csv_path)}


def run_validation(eeg_name: str, als_name: str, duration: float, expected_rate: float, require_als: bool, out_dir: Path, context: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], Dict[str, str]]:
    eeg, als = record_pair(eeg_name, als_name, duration)
    report = analyze(eeg, als, expected_rate, require_als)
    report["placement_test"] = context or {}
    return report, write_report(report, out_dir)


def run_gui(args: argparse.Namespace) -> int:
    import tkinter as tk
    from tkinter import messagebox, ttk

    root = tk.Tk(); root.title("PRAYCG 30-Second Acquisition Validation v1.0"); root.geometry("760x520")
    main = ttk.Frame(root, padding=14); main.pack(fill="both", expand=True)
    eeg_var = tk.StringVar(value=args.eeg_stream)
    als_var = tk.StringVar(value=args.als_stream)
    require_var = tk.BooleanVar(value=args.require_als)
    status_var = tk.StringVar(value="Ready. Start the acquisition bridge first, then run this optional check.")
    ttk.Label(main, text="Optional 30-second validation", font=("Segoe UI", 15, "bold")).pack(anchor="w")
    ttk.Label(main, text="Checks effective rate, timestamps, flat/noisy/saturated channels, data completeness, and ALS pulse visibility. It does not arm or block the protocol runner.", wraplength=710).pack(anchor="w", pady=(4, 12))
    form = ttk.Frame(main); form.pack(fill="x")
    ttk.Label(form, text="EEG stream").grid(row=0, column=0, sticky="w", pady=3); ttk.Entry(form, textvariable=eeg_var, width=34).grid(row=0, column=1, sticky="ew", pady=3)
    ttk.Label(form, text="ALS stream").grid(row=1, column=0, sticky="w", pady=3); ttk.Entry(form, textvariable=als_var, width=34).grid(row=1, column=1, sticky="ew", pady=3)
    ttk.Checkbutton(form, text="Require ALS pulse visibility", variable=require_var).grid(row=2, column=1, sticky="w", pady=3)
    form.columnconfigure(1, weight=1)
    ttk.Label(main, textvariable=status_var, foreground="#1f4e79", wraplength=710).pack(anchor="w", pady=12)
    output = tk.Text(main, height=12, wrap="word", state="disabled"); output.pack(fill="both", expand=True)
    button = ttk.Button(main, text="Run 30-Second Validation"); button.pack(anchor="e", pady=(10, 0))
    pulse_win: List[Optional[tk.Toplevel]] = [None]
    pulse_context: Dict[str, Any] = {}

    def set_output(text: str) -> None:
        output.config(state="normal"); output.delete("1.0", "end"); output.insert("end", text); output.config(state="disabled")

    def close_pulse() -> None:
        if pulse_win[0] is not None:
            try: pulse_win[0].destroy()
            except Exception: pass
            pulse_win[0] = None

    def present_pulses() -> None:
        win = tk.Toplevel(root); pulse_win[0] = win
        win.configure(bg="black"); win.attributes("-fullscreen", True); win.attributes("-topmost", True)
        canvas = tk.Canvas(win, bg="black", highlightthickness=0); canvas.pack(fill="both", expand=True)
        win.update_idletasks(); w, h = win.winfo_width(), win.winfo_height()
        rect = canvas.create_rectangle(w-220, h-220, w-40, h-40, fill="black", outline="black")
        profile = Path(args.placement_profile).expanduser() if args.placement_profile else None
        profile_hash = None
        if profile is not None and profile.is_file():
            digest = hashlib.sha256(); digest.update(profile.read_bytes()); profile_hash = digest.hexdigest()
        pulse_context.update({
            "test_kind": "fullscreen_barcode_location_and_visibility",
            "screen_identifier": "tk_primary_screen",
            "screen_resolution_px": [w, h],
            "screen_width_mm_estimate": float(win.winfo_screenmmwidth()),
            "screen_height_mm_estimate": float(win.winfo_screenmmheight()),
            "tk_pixels_per_inch": float(win.winfo_fpixels("1i")),
            "barcode_rectangle_px_left_top_right_bottom": [w-220, h-220, w-40, h-40],
            "barcode_position": "lower_right",
            "placement_profile": str(profile) if profile is not None else None,
            "placement_profile_sha256": profile_hash,
            "pulse_schedule_ms": [[2000, "white"], [4000, "black"], [4750, "white"], [5500, "black"], [11000, "white"], [13000, "black"], [13750, "white"], [14500, "black"], [20000, "white"], [22000, "black"], [22750, "white"], [23500, "black"]],
        })
        # Repeat long/short pulses so the ALS check is robust to startup latency.
        sequence = [(2000, "white"), (4000, "black"), (4750, "white"), (5500, "black"),
                    (11000, "white"), (13000, "black"), (13750, "white"), (14500, "black"),
                    (20000, "white"), (22000, "black"), (22750, "white"), (23500, "black")]
        for delay, color in sequence:
            win.after(delay, lambda c=color: canvas.itemconfigure(rect, fill=c, outline=c))
        win.bind("<Escape>", lambda _e: close_pulse())

    def done(report: Dict[str, Any], paths: Dict[str, str]) -> None:
        close_pulse(); button.config(state="normal")
        status_var.set(f"Completed: {report['status']} — contact-quality index {report['contact_quality_index_0_100']}/100")
        detail = [f"Status: {report['status']}", f"Contact-quality index: {report['contact_quality_index_0_100']}/100", ""]
        detail += ["FAIL: " + x for x in report["fail_reasons"]]
        detail += ["WARN: " + x for x in report["warning_reasons"]]
        detail += ["", "Reports:", paths["markdown"], paths["json"], paths["channels_csv"]]
        set_output("\n".join(detail))
        messagebox.showinfo("Acquisition validation complete", f"Status: {report['status']}\nIndex: {report['contact_quality_index_0_100']}/100\n\nReport:\n{paths['markdown']}")

    def failed(exc: Exception) -> None:
        close_pulse(); button.config(state="normal"); status_var.set("Validation failed to run."); set_output(repr(exc)); messagebox.showerror("Validation error", repr(exc))

    def start_test() -> None:
        button.config(state="disabled"); status_var.set("Recording 30 seconds… remain still while the screen barcode flashes."); set_output("Capturing LSL streams…")
        present_pulses()
        def work() -> None:
            try:
                report, paths = run_validation(eeg_var.get().strip(), als_var.get().strip(), 30.0, args.expected_rate, require_var.get(), Path(args.out_dir), pulse_context)
                root.after(0, lambda: done(report, paths))
            except Exception as exc:
                root.after(0, lambda: failed(exc))
        threading.Thread(target=work, daemon=True).start()

    button.config(command=start_test)
    root.protocol("WM_DELETE_WINDOW", lambda: (close_pulse(), root.destroy()))
    root.mainloop(); return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Optional PRAYCG 30-second EEG/ALS acquisition validation")
    p.add_argument("--eeg-stream", default="obci_eeg1")
    p.add_argument("--als-stream", default="ALS_PT19_Timing")
    p.add_argument("--duration", type=float, default=30.0)
    p.add_argument("--expected-rate", type=float, default=125.0)
    p.add_argument("--out-dir", default="praycg_acquisition_preflight_reports")
    p.add_argument("--require-als", action="store_true")
    p.add_argument("--placement-profile", default="")
    p.add_argument("--gui", action="store_true")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    if args.gui:
        return run_gui(args)
    report, paths = run_validation(args.eeg_stream, args.als_stream, max(5.0, args.duration), args.expected_rate, args.require_als, Path(args.out_dir), {"placement_profile": args.placement_profile or None, "screen_pulses": False})
    print(json.dumps({"status": report["status"], "contact_quality_index_0_100": report["contact_quality_index_0_100"], "reports": paths}, indent=2))
    return 0 if report["status"] != "FAIL" else 2


if __name__ == "__main__":
    raise SystemExit(main())
