#!/usr/bin/env python3
"""Control Center v0.92 GUI wrapper for the HOC-R ShotOrder module."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parents[2]
TARGET = ROOT / "tools" / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_shotorder_hocr_module_v1_6_0.py"


class App(tk.Tk):
    def __init__(self, analysis_folder: str = "", feature_csv: str = "", out_dir: str = ""):
        super().__init__()
        self.title("PRAYCG HOC-R ShotOrder Module v0.92")
        self.geometry("920x540")
        self.folder_var = tk.StringVar(value=analysis_folder)
        self.feature_csv = feature_csv
        self.requested_out = out_dir
        self.proc = None
        self.out = ""
        ttk.Label(self, text="HOC-R ShotOrder Structural-Control Audit", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=10, pady=(10, 4))
        ttk.Label(
            self,
            text="Uses a Master Comprehensive output to evaluate Target-vs-PhaseScrambled, Target-vs-ShotOrder, and Target-vs-Override contrasts. Prefilled paths must still be reviewed before Run HOC-R is clicked.",
            wraplength=880,
        ).pack(anchor="w", padx=10)
        row = ttk.Frame(self); row.pack(fill="x", padx=10, pady=8)
        ttk.Entry(row, textvariable=self.folder_var).pack(side="left", fill="x", expand=True)
        ttk.Button(row, text="Browse", command=self.pick).pack(side="left", padx=4)
        buttons = ttk.Frame(self); buttons.pack(fill="x", padx=10)
        ttk.Button(buttons, text="Run HOC-R", command=self.run).pack(side="left")
        ttk.Button(buttons, text="Stop", command=self.stop).pack(side="left", padx=6)
        ttk.Button(buttons, text="Open output", command=self.open_out).pack(side="left", padx=6)
        self.status = tk.StringVar(value="Analysis folder prefilled; review it, then click Run HOC-R." if analysis_folder else "No folder selected.")
        ttk.Label(self, textvariable=self.status).pack(anchor="w", padx=10, pady=4)
        self.text = tk.Text(self, wrap="word"); self.text.pack(fill="both", expand=True, padx=10, pady=10)

    def log(self, message: str) -> None:
        self.text.insert("end", message); self.text.see("end"); self.update_idletasks()

    def pick(self) -> None:
        folder = filedialog.askdirectory(title="Select Master Comprehensive analysis folder")
        if folder:
            self.folder_var.set(folder)
        self.status.set(self.folder_var.get() or "No folder selected.")

    def run(self) -> None:
        if not TARGET.exists():
            return messagebox.showerror("Script missing", str(TARGET))
        folder = self.folder_var.get().strip()
        if not folder:
            return messagebox.showwarning("No folder", "Select an analysis folder first.")
        canonical = Path(folder) / "tables" / "praycg_analysis_frame_v1_6_0.csv"
        if not canonical.is_file():
            return messagebox.showerror("Not a canonical core output", f"Missing:\n{canonical}")
        self.out = self.requested_out or str(Path(folder) / "hocr_shotorder_v1_6_0")
        cmd = [sys.executable, str(TARGET), "--analysis-folder", folder, "--out-dir", self.out]
        if self.feature_csv:
            cmd += ["--feature-csv", self.feature_csv]
        self.log(">>> " + subprocess.list2cmdline(cmd) + "\n")

        def worker() -> None:
            self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in self.proc.stdout or []:
                self.after(0, self.log, line)
            rc = self.proc.wait()
            self.after(0, self.log, f"\nExited with code {rc}\n")

        threading.Thread(target=worker, daemon=True).start()

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate(); self.log("\nTerminate requested.\n")

    def open_out(self) -> None:
        if self.out and Path(self.out).exists():
            os.startfile(self.out) if sys.platform.startswith("win") else subprocess.Popen(["xdg-open", self.out])
        else:
            messagebox.showinfo("No output yet", "Run the module first.")


def main() -> None:
    parser = argparse.ArgumentParser(description="PRAYCG Control Center v0.92 HOC-R GUI")
    parser.add_argument("--analysis-folder", default="")
    parser.add_argument("--feature-csv", default="")
    parser.add_argument("--out-dir", default="")
    args = parser.parse_args()
    App(args.analysis_folder, args.feature_csv, args.out_dir).mainloop()


if __name__ == "__main__":
    main()
