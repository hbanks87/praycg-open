#!/usr/bin/env python3
"""PRAYCG Control Center v0.92 Master Suite GUI launcher with input prefill."""
from __future__ import annotations
import runpy, sys, traceback
from datetime import datetime
from pathlib import Path
try:
    import tkinter as tk
    from tkinter import messagebox
except Exception:
    tk = None; messagebox = None
ROOT = Path(__file__).resolve().parents[2]
TARGET = ROOT / "tools" / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_master_comprehensive_suite_v1_6_0.py"
LOG = ROOT / "logs" / "control_center" / f"master_suite_launcher_v0_92_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"

def show_error(title, msg):
    print(f"{title}\n{msg}", file=sys.stderr)
    if messagebox:
        r=tk.Tk(); r.withdraw(); messagebox.showerror(title,msg); r.destroy()

def main() -> int:
    if not TARGET.exists():
        show_error("Master Suite not found", f"Bundled Master Suite GUI was not found:\n{TARGET}")
        return 2
    try:
        sys.path.insert(0, str(TARGET.parent))
        # Preserve Control Center prefill arguments. The scientific engine still
        # waits for the user to click Run inside the Master Suite GUI.
        sys.argv=[str(TARGET)] + sys.argv[1:]
        runpy.run_path(str(TARGET), run_name="__main__")
        return 0
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 0
        if code not in (0, None):
            raise
        return int(code or 0)
    except Exception:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        tb=traceback.format_exc(); LOG.write_text(tb, encoding='utf-8')
        show_error("Master Suite launch failed", f"Master Suite crashed before or during GUI launch.\n\nLog:\n{LOG}\n\n{tb[-2500:]}")
        return 1
if __name__ == '__main__':
    raise SystemExit(main())
