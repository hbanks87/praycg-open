#!/usr/bin/env python3
"""Control Center v0.92 GUI wrapper for ALS barcode detector v1.5.8."""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parents[2]
TARGET = ROOT / "tools" / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_als_barcode_detector_v1_5_8.py"


class App(tk.Tk):
    def __init__(self, folder: str = "", xdf: str = "", events_json: str = "", out_dir: str = "", stream_name: str = "obci_eeg1", channel_index: int = -1):
        super().__init__()
        self.title("PRAYCG ALS Barcode Detector v0.92")
        self.geometry("940x590")
        self.folder_var = tk.StringVar(value=folder)
        self.xdf_var = tk.StringVar(value=xdf)
        self.events_var = tk.StringVar(value=events_json)
        self.out_requested = out_dir
        self.proc = None
        self.out = ""
        ttk.Label(self, text="ALS Barcode Detector", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=10, pady=(10, 4))
        ttk.Label(self, text="Validates PRAYCG2.2 long/short display-timing barcodes from the selected run. Prefilled paths are reviewable and the detector does not start automatically.", wraplength=900).pack(anchor="w", padx=10)
        self._row("Run/analysis folder", self.folder_var, True)
        self._row("XDF", self.xdf_var, False)
        self._row("Events JSON", self.events_var, False)
        opts = ttk.Frame(self); opts.pack(fill="x", padx=10, pady=(0, 6))
        ttk.Label(opts, text="LSL stream name:").pack(side="left")
        self.stream = tk.StringVar(value=stream_name); ttk.Entry(opts, textvariable=self.stream, width=18).pack(side="left", padx=4)
        ttk.Label(opts, text="ALS channel index (-1 auto/last):").pack(side="left", padx=(12, 0))
        self.chan = tk.StringVar(value=str(channel_index)); ttk.Entry(opts, textvariable=self.chan, width=8).pack(side="left", padx=4)
        buttons = ttk.Frame(self); buttons.pack(fill="x", padx=10, pady=4)
        ttk.Button(buttons, text="Run detector", command=self.run).pack(side="left")
        ttk.Button(buttons, text="Stop", command=self.stop).pack(side="left", padx=6)
        ttk.Button(buttons, text="Open output", command=self.open_out).pack(side="left", padx=6)
        self.status = tk.StringVar(value="Run inputs prefilled; review them, then click Run detector." if folder else "No folder selected.")
        ttk.Label(self, textvariable=self.status).pack(anchor="w", padx=10)
        self.text = tk.Text(self, wrap="word"); self.text.pack(fill="both", expand=True, padx=10, pady=10)

    def _row(self, label: str, variable: tk.StringVar, folder: bool) -> None:
        row = ttk.Frame(self); row.pack(fill="x", padx=10, pady=3)
        ttk.Label(row, text=label, width=20).pack(side="left")
        ttk.Entry(row, textvariable=variable).pack(side="left", fill="x", expand=True)

        def pick() -> None:
            value = filedialog.askdirectory(title=f"Select {label}") if folder else filedialog.askopenfilename(title=f"Select {label}")
            if value:
                variable.set(value)

        ttk.Button(row, text="Browse", command=pick).pack(side="left", padx=4)

    def log(self, message: str) -> None:
        self.text.insert("end", message); self.text.see("end"); self.update_idletasks()

    def run(self) -> None:
        if not TARGET.exists():
            return messagebox.showerror("Script missing", str(TARGET))
        folder = self.folder_var.get().strip()
        if not folder:
            return messagebox.showwarning("No folder", "Select a run or analysis folder first.")
        self.out = self.out_requested or str(Path(folder) / "als_barcode_detector_v1_5_8")
        cmd = [sys.executable, str(TARGET), "--analysis-folder", folder, "--out-dir", self.out, "--stream-name", self.stream.get(), "--channel-index", self.chan.get()]
        if self.xdf_var.get().strip():
            cmd += ["--xdf", self.xdf_var.get().strip()]
        if self.events_var.get().strip():
            cmd += ["--events-json", self.events_var.get().strip()]
        self.log(">>> " + subprocess.list2cmdline(cmd) + "\n")

        def worker() -> None:
            self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in self.proc.stdout or []:
                self.after(0, self.log, line)
            rc = self.proc.wait(); self.after(0, self.log, f"\nExited with code {rc}\n")

        threading.Thread(target=worker, daemon=True).start()

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate(); self.log("\nTerminate requested.\n")

    def open_out(self) -> None:
        if self.out and Path(self.out).exists():
            os.startfile(self.out) if sys.platform.startswith("win") else subprocess.Popen(["xdg-open", self.out])
        else:
            messagebox.showinfo("No output yet", "Run the detector first.")


def main() -> None:
    parser = argparse.ArgumentParser(description="PRAYCG Control Center v0.92 ALS barcode GUI")
    parser.add_argument("--folder", default="")
    parser.add_argument("--xdf", default="")
    parser.add_argument("--events-json", default="")
    parser.add_argument("--out-dir", default="")
    parser.add_argument("--stream-name", default="obci_eeg1")
    parser.add_argument("--channel-index", type=int, default=-1)
    args = parser.parse_args()
    App(args.folder, args.xdf, args.events_json, args.out_dir, args.stream_name, args.channel_index).mainloop()


if __name__ == "__main__":
    main()
