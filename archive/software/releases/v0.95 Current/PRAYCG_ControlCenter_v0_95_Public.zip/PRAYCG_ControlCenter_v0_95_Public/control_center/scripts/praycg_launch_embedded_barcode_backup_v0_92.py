#!/usr/bin/env python3
"""Small GUI wrapper for optional MP4-embedded ALS barcode backup."""
from __future__ import annotations
import subprocess, sys, threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parents[2]
TARGET = ROOT / "tools" / "MediaPrep_StimulusFingerprint_v1_9_SHOTORDER" / "scripts" / "praycg_embedded_als_barcode_backup_v1_8B.py"

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('PRAYCG MP4 ALS Barcode Backup v0.92'); self.geometry('820x520')
        self.files=[]; self.proc=None; self.out_dir=''
        ttk.Label(self, text='Optional MP4-embedded ALS barcode backup', font=('Segoe UI',14,'bold')).pack(anchor='w', padx=10, pady=(10,4))
        ttk.Label(self, text='This is a backup media-file pulse. PRAYCG2.2 runner-level ALS barcode remains the preferred timing channel. Select one or more MP4s, then run.', wraplength=780).pack(anchor='w', padx=10)
        row=ttk.Frame(self); row.pack(fill='x', padx=10, pady=8)
        ttk.Button(row, text='Select MP4 files', command=self.pick).pack(side='left')
        ttk.Button(row, text='Run backup barcode script', command=self.run).pack(side='left', padx=6)
        ttk.Button(row, text='Stop running job', command=self.stop).pack(side='left', padx=6)
        ttk.Button(row, text='Open output folder', command=self.open_out).pack(side='left', padx=6)
        self.status=tk.StringVar(value='No files selected.'); ttk.Label(self, textvariable=self.status).pack(anchor='w', padx=10)
        self.text=tk.Text(self, wrap='word'); self.text.pack(fill='both', expand=True, padx=10, pady=10)
    def log(self,msg): self.text.insert('end', msg); self.text.see('end'); self.update_idletasks()
    def pick(self):
        self.files=list(filedialog.askopenfilenames(title='Select MP4s for embedded barcode backup', filetypes=[('MP4','*.mp4')]))
        self.status.set(f'{len(self.files)} MP4 file(s) selected.')
    def run(self):
        if not TARGET.exists(): return messagebox.showerror('Script missing', str(TARGET))
        if not self.files: return messagebox.showwarning('No files', 'Select MP4 files first.')
        out=Path(self.files[0]).parent / 'als_barcode_backup_v1_8B'; self.out_dir=str(out)
        cmd=[sys.executable, str(TARGET), '--input', *self.files, '--out-dir', str(out)]
        self.log('>>> '+' '.join(cmd)+'\n')
        def worker():
            self.proc=subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in self.proc.stdout or []: self.log(line)
            rc=self.proc.wait(); self.log(f'\nExited with code {rc}\n')
        threading.Thread(target=worker, daemon=True).start()
    def stop(self):
        if self.proc and self.proc.poll() is None: self.proc.terminate(); self.log('\nTerminate requested.\n')
    def open_out(self):
        if self.out_dir and Path(self.out_dir).exists():
            import os; os.startfile(self.out_dir) if sys.platform.startswith('win') else subprocess.Popen(['xdg-open', self.out_dir])
        else: messagebox.showinfo('No output yet','Run the job first.')
if __name__=='__main__': App().mainloop()
