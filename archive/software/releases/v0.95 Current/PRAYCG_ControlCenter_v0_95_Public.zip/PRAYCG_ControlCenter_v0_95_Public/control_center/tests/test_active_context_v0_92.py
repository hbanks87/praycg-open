#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))

from praycg_active_context_v1_0 import readiness, resolve_analysis_outputs, resolve_raw_run  # noqa: E402


class ActiveContextTests(unittest.TestCase):
    def test_json_event_log_is_preferred_over_matching_csv(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            (root / "run.xdf").write_bytes(b"xdf")
            (root / "subject_events.json").write_text("[]", encoding="utf-8")
            (root / "subject_events.csv").write_text("marker\n", encoding="utf-8")
            resolved = resolve_raw_run(root)
            self.assertEqual(resolved["xdf"]["status"], "RESOLVED")
            self.assertEqual(resolved["events"]["status"], "RESOLVED")
            self.assertTrue(resolved["events"]["path"].endswith("events.json"))

    def test_multiple_xdfs_are_ambiguous(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            (root / "a.xdf").write_bytes(b"a")
            (root / "b.xdf").write_bytes(b"b")
            resolved = resolve_raw_run(root)
            self.assertEqual(resolved["xdf"]["status"], "AMBIGUOUS")
            self.assertEqual(len(resolved["xdf"]["candidates"]), 2)

    def test_core_and_chain_require_provenance_match(self):
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            run = root / "run"; analysis = root / "analysis"
            run.mkdir(); analysis.mkdir()
            xdf = run / "run.xdf"; xdf.write_bytes(b"xdf")
            events = run / "run_events.json"; events.write_text("[]", encoding="utf-8")
            run_record = resolve_raw_run(run)

            core = analysis / "core"
            (core / "tables").mkdir(parents=True)
            (core / "config").mkdir()
            (core / "tables" / "praycg_analysis_frame_v1_6_0.csv").write_text("segment\n", encoding="utf-8")
            (core / "config" / "run_config.json").write_text(json.dumps({"xdf_path": str(xdf), "event_log_path": str(events)}), encoding="utf-8")
            chain = analysis / "chain"; chain.mkdir()
            (chain / "chain_manifest.json").write_text(json.dumps({"core_analysis_folder": str(core)}), encoding="utf-8")

            outputs = resolve_analysis_outputs(analysis, run_record, run)
            self.assertEqual(outputs["core"]["status"], "RESOLVED")
            self.assertEqual(outputs["chain"]["status"], "RESOLVED")
            context = {"stimulus": {}, "run": run_record, "analysis": outputs}
            gates = readiness(context)
            self.assertEqual(gates["chain"]["status"], "READY")
            self.assertEqual(gates["interpreter"]["status"], "READY")


if __name__ == "__main__":
    unittest.main()
