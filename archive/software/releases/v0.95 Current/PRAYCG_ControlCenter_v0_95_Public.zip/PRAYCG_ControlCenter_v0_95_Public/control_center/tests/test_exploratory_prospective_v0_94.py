from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd


PACKAGE = Path(__file__).resolve().parents[2]
CAI = PACKAGE / "tools" / "CAI_SID_Exploratory_v0_2"
PROS = PACKAGE / "tools" / "Prospective_Study_Package_v0_1"


def load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ExploratoryProspectiveTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.core = load("cai_core_v02", CAI / "scripts" / "praycg_cai_sid_v0_2.py")
        cls.ready = load("cai_ready_v02", CAI / "scripts" / "praycg_cai_readiness_preflight_v0_2.py")

    def test_corrected_loop_cannot_reward_jointly_low_inputs(self) -> None:
        result = self.core.corrected_loop_product([0.1, 0.49, 0.8], [0.1, 0.49, 0.8])
        np.testing.assert_allclose(result[:2], [0.0, 0.0])
        self.assertGreater(result[2], 0.0)

    def test_primary_configuration_is_equal_weight_and_exploratory(self) -> None:
        config = json.loads((CAI / "config" / "analysis_config_v0_2.json").read_text(encoding="utf-8"))
        self.assertEqual(config["status"], "EXPLORATORY_FROZEN_CANDIDATE")
        self.assertIn("not a probability", config["claim_boundary"])
        self.assertEqual(config["forbidden_primary_inputs"], ["expected_archetype", "condition_specific_autonomic_constant", "run_specific_classifier"])

    def test_readiness_generates_core_compatible_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            n = 80
            condition = ["BASELINE_1"] * 40 + ["TARGET_1"] * 40
            frame = pd.DataFrame({
                "time_lsl": np.arange(n, dtype=float), "condition": condition, "block_id": ["B1"] * 40 + ["T1"] * 40,
                "meaninggamma_score": np.linspace(-1, 1, n), "tsp_z": np.linspace(-0.5, 0.5, n),
                "theta_integration_z": np.linspace(-0.4, 0.6, n), "nas_score": np.linspace(-0.3, 0.7, n),
                "alpha_posterior_z": np.linspace(-0.2, 0.8, n), "artifact_score": np.zeros(n),
                "taskgamma_score": np.zeros(n), "hf_jaw_45_55_z": np.zeros(n),
            })
            frame.to_csv(root / "praycg_analysis_frame_test.csv", index=False)
            result = self.ready.run_preflight(root, root, root / "out")
            self.assertNotEqual(result["status"], "INELIGIBLE")
            manifest = json.loads(Path(result["generated_run_manifest"]).read_text(encoding="utf-8"))
            self.assertEqual(len(manifest["runs"]), 1)
            self.assertEqual(manifest["runs"][0]["time"], "time_lsl")
            self.assertNotIn("time", manifest["runs"][0]["columns"])

    def test_prospective_catalog_has_ten_fixed_sequence_variants(self) -> None:
        catalog = json.loads((PROS / "config" / "prospective_protocol_catalog_v0_1.json").read_text(encoding="utf-8"))
        self.assertEqual(len(catalog["records"]), 10)
        self.assertEqual(sum(row["base_protocol_id"] == "PRAYCG3" for row in catalog["records"]), 6)
        self.assertEqual(sum(row["base_protocol_id"] == "PRAYCG4" for row in catalog["records"]), 4)
        for path in (PROS / "protocols").glob("*.json"):
            protocol = json.loads(path.read_text(encoding="utf-8"))
            self.assertTrue(protocol["branch_order_fixed"])
            self.assertEqual(protocol["baseline_phase"], "BASELINE_1")
            self.assertEqual(protocol["final_reflection_phase"], "BASELINE_2_REFLECTION")
            self.assertTrue(all(branch.get("washout_phase") and branch.get("report_phase") for branch in protocol["branches"]))
            self.assertTrue(all("IndependentRecognition" in branch["rating_items"] for branch in protocol["branches"]))

    def test_counterbalance_is_period_and_first_order_balanced(self) -> None:
        catalog = json.loads((PROS / "config" / "prospective_protocol_catalog_v0_1.json").read_text(encoding="utf-8"))
        for base in ["PRAYCG3", "PRAYCG4"]:
            orders = [row["order"] for row in catalog["records"] if row["base_protocol_id"] == base]
            conditions = sorted(set(orders[0]))
            period_counts = {(condition, period): 0 for condition in conditions for period in range(len(conditions))}
            transition_counts = {(left, right): 0 for left in conditions for right in conditions if left != right}
            for order in orders:
                for period, condition in enumerate(order):
                    period_counts[(condition, period)] += 1
                for left, right in zip(order, order[1:]):
                    transition_counts[(left, right)] += 1
            self.assertEqual(len(set(period_counts.values())), 1)
            self.assertEqual(len(set(transition_counts.values())), 1)

    def test_default_promotion_audit_remains_exploratory(self) -> None:
        evidence = json.loads((PROS / "config" / "promotion_evidence_INPUT_TEMPLATE_v0_1.json").read_text(encoding="utf-8"))
        self.assertFalse(any(evidence[key] for key in ["prospective_frozen_pipeline_executed", "held_out_criterion_validity_established", "reliability_and_calibration_established", "claim_boundary_and_null_reporting_complete"]))
        audit = json.loads((PROS / "validation" / "promotion_audit" / "promotion_audit_v0_1.json").read_text(encoding="utf-8"))
        self.assertEqual(audit["current_grade"], "EXPLORATORY")
        self.assertFalse(audit["promotion_allowed"])


if __name__ == "__main__":
    unittest.main()
