from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path


PACKAGE = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE / "control_center" / "scripts"
MICRO = PACKAGE / "tools" / "Micro_Handoff_v0_1"
sys.path.insert(0, str(SCRIPTS))

from praycg_control_center_v0_95 import APP_VERSION, CONFIG_SCHEMA, bundled_tool_paths, default_config  # noqa: E402


class MicroHandoffIntegrationTests(unittest.TestCase):
    def test_control_center_version_and_schema(self) -> None:
        self.assertEqual(APP_VERSION, "0.95")
        self.assertEqual(CONFIG_SCHEMA, "PRAYCG_ControlCenter_Config_v0_95")

    def test_bundled_micro_handoff_launcher_resolves(self) -> None:
        path = Path(bundled_tool_paths()["micro_handoff_gui"])
        self.assertTrue(path.is_file(), path)
        self.assertEqual(path.name, "praycg_micro_handoff_gui_v0_1.py")
        self.assertEqual(default_config()["tools"]["micro_handoff_gui"], str(path))

    def test_frozen_candidate_records_synthetic_pass(self) -> None:
        frozen = json.loads((MICRO / "config" / "MICRO_HANDOFF_v0_1_FROZEN_CANDIDATE.json").read_text(encoding="utf-8"))
        self.assertEqual(frozen["version"], "0.1.0")
        self.assertIn("FROZEN_AFTER_SYNTHETIC_PASS", frozen["status"])
        self.assertEqual(frozen["synthetic_validation"]["status"], "PASS")

    def test_registration_cannot_change_primary_results(self) -> None:
        registration = json.loads((MICRO / "config" / "master_suite_exploratory_registration_v0_1.json").read_text(encoding="utf-8"))
        self.assertEqual(registration["master_suite_primary_eligibility_effect"], "NONE")
        self.assertEqual(registration["primary_conclusion_effect"], "NONE")
        self.assertFalse(registration["automatic_chain_execution"])
        self.assertFalse(registration["promotion_allowed"])
        self.assertIn("not a direct measure", registration["claim_boundary"])

    def test_public_synthetic_evidence_is_summary_only(self) -> None:
        evidence = MICRO / "examples" / "synthetic_validation_summary"
        self.assertTrue((evidence / "SYNTHETIC_VALIDATION_REPORT.md").is_file())
        self.assertTrue((evidence / "synthetic_validation_summary.json").is_file())
        forbidden = {".xdf", ".edf", ".bdf", ".npz", ".npy"}
        self.assertEqual([path for path in evidence.rglob("*") if path.suffix.lower() in forbidden], [])


if __name__ == "__main__":
    unittest.main()
