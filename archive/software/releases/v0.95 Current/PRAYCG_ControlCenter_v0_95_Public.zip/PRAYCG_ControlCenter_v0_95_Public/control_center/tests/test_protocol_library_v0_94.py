from __future__ import annotations

import json
import py_compile
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
LIBRARY = PACKAGE_ROOT / "tools" / "ProtocolRunner_ModuleLibrary_v1_0"
sys.path.insert(0, str(SCRIPTS))

from praycg_protocol_library_v1_0 import (  # noqa: E402
    discover_protocol_modules,
    validate_protocol_lock,
    write_protocol_lock,
)


class ProtocolLibraryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.records, self.errors = discover_protocol_modules(LIBRARY)
        self.by_id = {record["protocol_id"]: record for record in self.records}

    def test_exact_public_module_set_and_no_discovery_errors(self) -> None:
        self.assertEqual(self.errors, [])
        self.assertEqual(set(self.by_id), {"PRAYCG3", "PRAYCG4", "SMG"})

    def test_praycg3_preserves_original_three_prong_order(self) -> None:
        self.assertEqual(
            self.by_id["PRAYCG3"]["branch_order"],
            ["CONTROL_1", "TARGET_1", "CONTEXTUAL_OVERRIDE_1"],
        )

    def test_praycg4_inserts_shotorder_after_control_washout_report(self) -> None:
        record = self.by_id["PRAYCG4"]
        self.assertEqual(
            record["branch_order"],
            ["CONTROL_1", "SHOT_ORDER_SCRAMBLE_1", "TARGET_1", "CONTEXTUAL_OVERRIDE_1"],
        )
        control, shot = record["module"]["branches"][:2]
        self.assertEqual(control["washout_phase"], "WASHOUT_1")
        self.assertEqual(control["report_phase"], "CONTROL_1_AFTER_WASHOUT_1")
        self.assertEqual(shot["phase"], "SHOT_ORDER_SCRAMBLE_1")

    def test_smg_does_not_reuse_phase_scrambled_control_media_key(self) -> None:
        record = self.by_id["SMG"]
        self.assertEqual(
            record["branch_order"],
            ["SEMANTIC_ZERO_1", "HIGH_MEANING_TARGET_1", "ARITHMETIC_OVERRIDE_1"],
        )
        self.assertEqual(record["module"]["branches"][0]["media_key"], "semantic_zero_video")
        self.assertIn("semantic_zero_video", record["module"]["integrity_constraints"]["required_media_keys"])
        self.assertEqual(record["module"]["theory_proposed_indices"]["status"], "conditional_unvalidated_operationalization")

    def test_lock_validates_then_fails_after_manifest_change(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            copied_library = Path(temp_dir) / "ProtocolRunner_ModuleLibrary_v1_0"
            shutil.copytree(LIBRARY, copied_library)
            records, errors = discover_protocol_modules(copied_library)
            self.assertEqual(errors, [])
            chosen = next(record for record in records if record["protocol_id"] == "PRAYCG4")
            lock_path = Path(temp_dir) / "lock.json"
            write_protocol_lock(chosen, lock_path)
            self.assertEqual(validate_protocol_lock(lock_path, copied_library)["validation"], "PASS")
            manifest = Path(chosen["manifest_path"])
            payload = json.loads(manifest.read_text(encoding="utf-8"))
            payload["short_description"] += " changed"
            manifest.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "manifest_sha256"):
                validate_protocol_lock(lock_path, copied_library)

    def test_all_new_python_entry_points_compile(self) -> None:
        paths = [
            SCRIPTS / "praycg_control_center_v0_95.py",
            SCRIPTS / "praycg_protocol_library_v1_0.py",
            *sorted((LIBRARY / "scripts").glob("*.py")),
        ]
        for path in paths:
            py_compile.compile(str(path), doraise=True)


if __name__ == "__main__":
    unittest.main()
