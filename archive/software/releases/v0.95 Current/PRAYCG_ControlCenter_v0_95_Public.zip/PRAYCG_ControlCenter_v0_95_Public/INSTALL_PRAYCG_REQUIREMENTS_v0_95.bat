@echo off
setlocal
cd /d "%~dp0"
set "PRAYCG_REQUIREMENTS=requirements_PRAYCG_v0_95.txt"

echo ============================================================
echo PRAYCG Control Center v0.95 dependency installer
echo ============================================================
echo.

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" goto local_python311

where py >nul 2>nul
if not errorlevel 1 goto python_launcher

where python >nul 2>nul
if not errorlevel 1 goto path_python

echo ERROR: Python was not found. Install Python 3.11 and try again.
goto failed

:local_python311
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto failed
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" -m pip install -r "%PRAYCG_REQUIREMENTS%"
if errorlevel 1 goto failed
goto verify_local

:python_launcher
py -3.11 -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto failed
py -3.11 -m pip install -r "%PRAYCG_REQUIREMENTS%"
if errorlevel 1 goto failed
py -3.11 -c "import moviepy, imageio, imageio_ffmpeg, cv2, numpy, scipy, pylsl, pyxdf; from brainflow.board_shim import BoardShim; print('Dependency check passed, including pylsl, pyxdf, and BrainFlow.')"
if errorlevel 1 goto failed
goto success

:path_python
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 goto failed
python -m pip install -r "%PRAYCG_REQUIREMENTS%"
if errorlevel 1 goto failed
python -c "import moviepy, imageio, imageio_ffmpeg, cv2, numpy, scipy, pylsl, pyxdf; from brainflow.board_shim import BoardShim; print('Dependency check passed, including pylsl, pyxdf, and BrainFlow.')"
if errorlevel 1 goto failed
goto success

:verify_local
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" -c "import moviepy, imageio, imageio_ffmpeg, cv2, numpy, scipy, pylsl, pyxdf; from brainflow.board_shim import BoardShim; print('Dependency check passed, including pylsl, pyxdf, and BrainFlow.')"
if errorlevel 1 goto failed

:success
echo.
echo SUCCESS. You can now run run_PRAYCG_ControlCenter_v0_95.bat.
goto finished

:failed
echo.
echo INSTALL FAILED. Keep the visible error message for diagnosis.

:finished
pause
endlocal
