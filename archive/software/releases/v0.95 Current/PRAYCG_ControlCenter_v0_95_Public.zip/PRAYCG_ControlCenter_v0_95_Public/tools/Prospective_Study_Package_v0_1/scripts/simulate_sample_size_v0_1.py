#!/usr/bin/env python3
"""Simulation-based planning for three crossed participant/stimulus contrasts."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variance-input", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    spec = json.loads(args.variance_input.read_text(encoding="utf-8"))
    rng = np.random.default_rng(int(spec.get("seed", 20260906)))
    simulations = int(spec.get("simulations", 5000))
    alpha_family = float(spec.get("family_alpha", 0.05))
    alpha_conservative = alpha_family / 3.0
    zcrit = float(norm.ppf(1 - alpha_conservative / 2))
    participant_condition_sd = float(spec["participant_condition_sd"])
    stimulus_condition_sd = float(spec["stimulus_condition_sd"])
    residual_sd = float(spec["residual_sd"])
    stimuli = int(spec["stimuli"])
    effects = [float(x) for x in spec["minimum_detectable_effects"]]
    rows = []
    for participants in spec.get("participant_grid", list(range(12, 121, 4))):
        n = int(participants)
        # Contrast variance under a crossed random-intercept/random-slope
        # approximation. Factor 2 represents two condition-specific deviations.
        se = np.sqrt(2 * participant_condition_sd**2 / n + 2 * stimulus_condition_sd**2 / stimuli + 2 * residual_sd**2 / (n * stimuli))
        for effect in effects:
            estimates = rng.normal(effect, se, simulations)
            power = float(np.mean(np.abs(estimates / se) > zcrit))
            rows.append({"participants": n, "stimuli": stimuli, "effect": effect, "standard_error": se, "power_conservative_three_test": power})
    table = pd.DataFrame(rows)
    args.out.mkdir(parents=True, exist_ok=True)
    table.to_csv(args.out / "sample_size_simulation_v0_1.csv", index=False)
    recommendations = []
    for effect in effects:
        eligible = table[(table.effect == effect) & (table.power_conservative_three_test >= 0.80)]
        recommendations.append({"effect": effect, "minimum_participants_for_80pct_if_any": int(eligible.participants.min()) if not eligible.empty else None})
    payload = {
        "schema": "PRAYCG_SimulationSampleSizePlan_v0_1", "generated_utc": datetime.now(timezone.utc).isoformat(),
        "input_status": spec.get("status"), "simulations": simulations, "multiplicity": "two-sided Bonferroni alpha 0.05/3 used conservatively for planning; registered analysis uses Holm",
        "recommendations": recommendations,
        "boundary": "If the variance input is illustrative rather than derived from blinded feasibility data, these are scenarios, not a final sample-size determination.",
    }
    (args.out / "sample_size_simulation_v0_1.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps(payload, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
