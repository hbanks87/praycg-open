#!/usr/bin/env python3
"""Hash and freeze a prospective PRAYCG study configuration."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_path(raw: str, config_path: Path, package_root: Path) -> Path:
    expanded = raw.replace("{PACKAGE_ROOT}", str(package_root)).replace("{CONFIG_DIR}", str(config_path.parent))
    path = Path(expanded).expanduser()
    return path.resolve() if path.is_absolute() else (config_path.parent / path).resolve()


def portable_path(path: Path, package_root: Path) -> str:
    try:
        return "{PACKAGE_ROOT}/" + str(path.resolve().relative_to(package_root.resolve())).replace("\\", "/")
    except (OSError, ValueError):
        return str(path.resolve())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-config", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--template-only", action="store_true", help="Record missing placeholders without declaring the package collection-ready.")
    args = parser.parse_args()
    config_path = args.study_config.resolve()
    config: Dict[str, Any] = json.loads(config_path.read_text(encoding="utf-8"))
    package_root = Path(__file__).resolve().parents[1]
    records = []
    missing = []
    hash_inputs = list(config.get("hash_inputs", []))
    catalog_path = package_root / "config" / "prospective_protocol_catalog_v0_1.json"
    if catalog_path.is_file():
        catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
        for candidate in catalog.get("records", []):
            hash_inputs.extend([
                {"role": "assigned_protocol_manifest", "logical_id": candidate.get("protocol_id"), "path": "{PACKAGE_ROOT}/" + str(candidate.get("protocol_path")), "required": True},
                {"role": "assigned_runner_entry", "logical_id": candidate.get("protocol_id"), "path": "{PACKAGE_ROOT}/" + str(candidate.get("runner_path")), "required": True},
            ])
    for item in hash_inputs:
        path = resolve_path(str(item["path"]), config_path, package_root)
        display = str(item["path"]) if str(item["path"]).startswith("REPLACE_WITH_") else portable_path(path, package_root)
        record = {"role": item.get("role"), "logical_id": item.get("logical_id"), "path": display, "required": bool(item.get("required", True)), "exists": path.is_file()}
        if path.is_file():
            record.update({"sha256": sha256(path), "size_bytes": path.stat().st_size})
        elif record["required"]:
            missing.append(record)
        records.append(record)
    payload = {
        "schema": "PRAYCG_ProspectiveStudyFreeze_v0_1", "generated_utc": datetime.now(timezone.utc).isoformat(),
        "study_id": config.get("study_id"), "candidate_version": config.get("candidate_version"),
        "configuration_path": portable_path(config_path, package_root), "configuration_sha256": sha256(config_path),
        "status": "TEMPLATE_NOT_COLLECTION_READY" if args.template_only else ("FROZEN_COLLECTION_READY" if not missing else "FREEZE_FAILED_MISSING_INPUTS"),
        "records": records, "missing_required": missing,
        "boundary": "A hash freeze establishes file identity, not scientific validity, data quality, preregistration, or ethical approval.",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(json.dumps({"status": payload["status"], "files": len(records), "missing_required": len(missing), "out": str(args.out.resolve())}, indent=2))
    return 0 if args.template_only or not missing else 2


if __name__ == "__main__":
    raise SystemExit(main())
