# PRAYCG Prospective Study Package v0.1

This package prepares separately versioned PRAYCG3 and PRAYCG4 prospective candidates without changing the public fixed-order legacy modules. It provides immutable Williams-sequence runner variants, a deterministic assignment template, complete file-hash freezing, blinded feasibility QC, simulation-based sample-size scenarios, an OSF preregistration draft, and a Gates 7–10 promotion audit.

The generated PRAYCG3/PRAYCG4 runners retain Baseline 1, a washout and report after every branch, Baseline 2/final reflection, and the final report. The prospective branch reports add recognition, comprehension, confidence, narrative-coherence, and structured subjective outcomes that are not inputs to CAI. Existing runner ALS barcode registration applies to every video phase.

## Required human stages

The included synthetic dry-run validates software paths and audit logic only. It is not participant evidence. Before collection, replace all media/anchor placeholders, run the ALS barcode placement script-location test on the real apparatus, complete blinded feasibility collection, derive variance inputs, finalize the model and thresholds, obtain required ethics/consent approvals, and register the frozen protocol on OSF.

CAI/SID remains `EXPLORATORY`. A file hash proves identity, not validity. Counterbalancing reduces systematic order imbalance but does not eliminate carryover or other confounding.
