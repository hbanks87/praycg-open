# Blinded Feasibility Pilot Audit

**Status: PASS**

Operational feasibility only. No condition-level CAI or validity outcome was inspected, selected, or optimized.

## Checks

- PASS — runner_completion: 1.0000 (minimum 0.95)
- PASS — report_completion: 0.9583 (minimum 0.95)
- PASS — eeg_coverage: 0.9069 (minimum 0.8)
- PASS — cardiac_coverage: 0.8845 (minimum 0.75)
- PASS — respiration_coverage: 0.8918 (minimum 0.75)
- PASS — median_als_sync_error_ms: 6.5857 (maximum 20.0)
- PASS — median_missing_fraction: 0.0582 (maximum 0.15)
- PASS — median_burden_minutes: 42.7223 (maximum 60.0)

Model-estimability screen: `True`
