#!/usr/bin/env python3
"""Blinded operational feasibility audit; intentionally excludes condition outcomes."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd


REQUIRED = [
    "participant_id", "stimulus_id", "protocol_id", "sequence_id", "runner_completed",
    "als_sync_error_ms", "eeg_valid_fraction", "cardiac_valid_fraction",
    "respiration_valid_fraction", "burden_minutes", "report_complete", "missing_fraction",
]


def make_synthetic(path: Path, n: int = 12, stimuli: int = 2) -> None:
    """Create data-quality-only records; no condition labels or outcomes are generated."""
    rng = np.random.default_rng(20260905)
    rows = []
    for participant in range(1, n + 1):
        for stimulus in range(1, stimuli + 1):
            protocol = "PRAYCG3" if participant % 2 else "PRAYCG4"
            sequences = 6 if protocol == "PRAYCG3" else 4
            rows.append({
                "participant_id": f"SYN_P{participant:03d}", "stimulus_id": f"SYN_S{stimulus:02d}",
                "protocol_id": protocol, "sequence_id": f"SEQ{((participant + stimulus - 2) % sequences) + 1:02d}",
                "runner_completed": int(rng.random() > 0.02), "als_sync_error_ms": max(0.3, rng.normal(7.0, 3.0)),
                "eeg_valid_fraction": np.clip(rng.normal(0.91, 0.04), 0, 1),
                "cardiac_valid_fraction": np.clip(rng.normal(0.88, 0.06), 0, 1),
                "respiration_valid_fraction": np.clip(rng.normal(0.89, 0.05), 0, 1),
                "burden_minutes": max(1.0, rng.normal(42.0, 4.0)),
                "report_complete": int(rng.random() > 0.03), "missing_fraction": np.clip(rng.normal(0.06, 0.025), 0, 1),
            })
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False)


def audit(frame: pd.DataFrame) -> dict:
    missing_columns = [column for column in REQUIRED if column not in frame.columns]
    forbidden = [column for column in frame.columns if any(token in column.lower() for token in ["cai", "condition_effect", "target_minus", "winner", "archetype"])]
    if missing_columns or forbidden:
        return {"status": "INELIGIBLE", "missing_columns": missing_columns, "forbidden_unblinded_columns": forbidden, "checks": []}
    numeric = frame.copy()
    for column in REQUIRED[4:]:
        numeric[column] = pd.to_numeric(numeric[column], errors="coerce")
    checks = [
        ("runner_completion", float(numeric.runner_completed.mean()), 0.95, "minimum"),
        ("report_completion", float(numeric.report_complete.mean()), 0.95, "minimum"),
        ("eeg_coverage", float(numeric.eeg_valid_fraction.mean()), 0.80, "minimum"),
        ("cardiac_coverage", float(numeric.cardiac_valid_fraction.mean()), 0.75, "minimum"),
        ("respiration_coverage", float(numeric.respiration_valid_fraction.mean()), 0.75, "minimum"),
        ("median_als_sync_error_ms", float(numeric.als_sync_error_ms.median()), 20.0, "maximum"),
        ("median_missing_fraction", float(numeric.missing_fraction.median()), 0.15, "maximum"),
        ("median_burden_minutes", float(numeric.burden_minutes.median()), 60.0, "maximum"),
    ]
    check_rows = []
    for name, value, threshold, direction in checks:
        passed = value >= threshold if direction == "minimum" else value <= threshold
        check_rows.append({"name": name, "value": value, "threshold": threshold, "direction": direction, "passed": bool(passed)})
    participants = int(frame.participant_id.nunique())
    stimuli = int(frame.stimulus_id.nunique())
    protocols = sorted(map(str, frame.protocol_id.dropna().unique()))
    sequence_counts = frame.groupby("protocol_id").sequence_id.nunique().to_dict()
    model_estimable = participants >= 8 and stimuli >= 2 and all(int(sequence_counts.get(protocol, 0)) >= 2 for protocol in protocols)
    status = "PASS" if all(row["passed"] for row in check_rows) and model_estimable else "CAUTION"
    return {
        "status": status, "rows": len(frame), "participants": participants, "stimuli": stimuli,
        "protocols": protocols, "sequence_counts": sequence_counts, "model_estimability_screen": model_estimable,
        "checks": check_rows, "missing_columns": [], "forbidden_unblinded_columns": [],
        "boundary": "Operational feasibility only. No condition-level CAI or validity outcome was inspected, selected, or optimized.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--make-synthetic", action="store_true")
    parser.add_argument("--synthetic-participants", type=int, default=12)
    args = parser.parse_args()
    input_path = args.input or (args.out / "synthetic_feasibility_input.csv")
    if args.make_synthetic:
        make_synthetic(input_path, args.synthetic_participants)
    if not input_path.is_file():
        parser.error("--input is required unless --make-synthetic is used")
    result = audit(pd.read_csv(input_path))
    package_root = Path(__file__).resolve().parents[1]
    try:
        input_display = "{PACKAGE_ROOT}/" + str(input_path.resolve().relative_to(package_root)).replace("\\", "/")
    except (OSError, ValueError):
        input_display = str(input_path.resolve())
    result.update({"schema": "PRAYCG_BlindedFeasibilityAudit_v0_1", "generated_utc": datetime.now(timezone.utc).isoformat(), "input": input_display})
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "feasibility_audit_v0_1.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    lines = ["# Blinded Feasibility Pilot Audit", "", f"**Status: {result['status']}**", "", result.get("boundary", ""), "", "## Checks", ""]
    for row in result.get("checks", []):
        lines.append(f"- {'PASS' if row['passed'] else 'CAUTION'} — {row['name']}: {row['value']:.4f} ({row['direction']} {row['threshold']})")
    lines += ["", f"Model-estimability screen: `{result.get('model_estimability_screen')}`", ""]
    (args.out / "FEASIBILITY_AUDIT_REPORT_v0_1.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"status": result["status"], "report": str((args.out / 'FEASIBILITY_AUDIT_REPORT_v0_1.md').resolve())}, indent=2))
    return 2 if result["status"] == "INELIGIBLE" else 0


if __name__ == "__main__":
    raise SystemExit(main())
