#!/usr/bin/env python3
"""Audit prospective CAI/SID promotion Gates 7-10 without post-hoc rescue."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


GATES = {
    "G7": "prospective_frozen_pipeline_executed",
    "G8": "held_out_criterion_validity_established",
    "G9": "reliability_and_calibration_established",
    "G10": "claim_boundary_and_null_reporting_complete",
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    evidence = json.loads(args.evidence.read_text(encoding="utf-8"))
    gate_rows = []
    for gate, field in GATES.items():
        value = evidence.get(field)
        passed = value is True
        gate_rows.append({"gate": gate, "field": field, "passed": passed, "evidence_paths": evidence.get("evidence_paths", {}).get(gate, [])})
    all_pass = all(row["passed"] for row in gate_rows)
    payload = {
        "schema": "PRAYCG_CAISID_PromotionAudit_v0_1", "generated_utc": datetime.now(timezone.utc).isoformat(),
        "current_grade": "STANDARD_SECONDARY" if all_pass else "EXPLORATORY",
        "promotion_allowed": all_pass, "gates": gate_rows,
        "post_hoc_archetype_rescue_allowed": False,
        "boundary": "Promotion requires affirmative prospective evidence for every gate. Missing, null, or ambiguous evidence is not converted to a pass.",
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "promotion_audit_v0_1.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    lines = ["# CAI/SID Prospective Promotion Audit", "", f"**Current grade: {payload['current_grade']}**", "", payload["boundary"], ""]
    for row in gate_rows:
        lines.append(f"- {row['gate']}: {'PASS' if row['passed'] else 'NOT ESTABLISHED'} — `{row['field']}`")
    (args.out / "PROMOTION_AUDIT_REPORT_v0_1.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"grade": payload["current_grade"], "promotion_allowed": all_pass}, indent=2))
    # A completed audit that correctly retains EXPLORATORY is not a software
    # error. Promotion status is carried in the report, not the process code.
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
