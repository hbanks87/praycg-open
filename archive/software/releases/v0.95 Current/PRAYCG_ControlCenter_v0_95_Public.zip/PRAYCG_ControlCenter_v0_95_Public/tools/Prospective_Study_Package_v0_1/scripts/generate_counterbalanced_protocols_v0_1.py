#!/usr/bin/env python3
"""Generate immutable, counterbalanced PRAYCG3/PRAYCG4 candidate modules.

The public PRAYCG3 and PRAYCG4 modules remain unchanged and fixed-order. This
script creates separately identified prospective variants. Each participant is
assigned one already-fixed sequence; order is never changed during a run.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List


VERSION = "0.1.0"
INDEPENDENT_ITEMS = [
    "IndependentRecognition", "IndependentComprehension", "RecognitionConfidence",
    "ComprehensionConfidence", "NarrativeCoherence", "SubjectiveMeaning",
    "Absorption", "EmotionalAfterglow", "StoryActiveWashout", "TaskExtractionLoad", "ConfoundBurden",
]
RATING_PROMPTS = {
    "IndependentRecognition": "How much recognizable content could you identify in this block? Use only what you experienced in this block.",
    "IndependentComprehension": "How well could you state what happened or how the presented parts related?",
    "RecognitionConfidence": "How confident are you in your recognition judgment?",
    "ComprehensionConfidence": "How confident are you in your comprehension judgment?",
    "NarrativeCoherence": "How coherent was the larger temporal or narrative sequence?",
    "SubjectiveMeaning": "How personally meaningful did the block feel? This is subjective report, not proof of reception.",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def williams_orders(n: int) -> List[List[int]]:
    """Return a first-order-balanced Williams design (2n sequences for odd n)."""
    if n < 2:
        return [list(range(n))]
    base = [0]
    low, high = 1, n - 1
    while len(base) < n:
        base.append(low)
        low += 1
        if len(base) < n:
            base.append(high)
            high -= 1
    orders = [[(value + shift) % n for value in base] for shift in range(n)]
    if n % 2:
        orders += [list(reversed(order)) for order in orders]
    return orders


def rewrite_phase_scrambled(module: Dict[str, Any]) -> Dict[str, Any]:
    module = copy.deepcopy(module)
    for branch in module["branches"]:
        if branch.get("condition_role") == "phase_scrambled_control":
            branch["phase"] = "PHASE_SCRAMBLED_1"
            branch["analysis_alias"] = "PHASE_SCRAMBLED_1"
            branch["washout_phase"] = "PHASE_SCRAMBLED_WASHOUT_1"
            branch["report_phase"] = "PHASE_SCRAMBLED_1_AFTER_WASHOUT_1"
    module["integrity_constraints"]["runner_registered_als_barcode_events_required"] = True
    module["integrity_constraints"]["all_inputs_hashed_before_collection"] = True
    module["rating_prompts"] = RATING_PROMPTS
    for branch in module["branches"]:
        branch["rating_items"] = list(INDEPENDENT_ITEMS)
    return module


def runner_text(protocol_filename: str, protocol_id: str) -> str:
    return f'''#!/usr/bin/env python3
"""Locked prospective runner entry for {protocol_id}."""
import sys
from pathlib import Path

TOOLS_ROOT = Path(__file__).resolve().parents[3]
ENGINE_ROOT = TOOLS_ROOT / "ProtocolRunner_ModuleLibrary_v1_0" / "scripts"
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))
from praycg_protocol_engine_v3_0 import run_full_experiment

if __name__ == "__main__":
    run_full_experiment(Path(__file__).resolve().parents[2] / "protocols" / "{protocol_filename}")
'''


def build(source_path: Path, package_root: Path, base_id: str) -> List[Dict[str, Any]]:
    source = rewrite_phase_scrambled(json.loads(source_path.read_text(encoding="utf-8")))
    protocols = package_root / "protocols"
    runners = package_root / "scripts" / "runners"
    protocols.mkdir(parents=True, exist_ok=True)
    runners.mkdir(parents=True, exist_ok=True)
    branches = source["branches"]
    outputs: List[Dict[str, Any]] = []
    for sequence_index, order in enumerate(williams_orders(len(branches)), start=1):
        candidate = copy.deepcopy(source)
        candidate_id = f"{base_id}P_SEQ{sequence_index:02d}"
        candidate["protocol_id"] = candidate_id
        candidate["protocol_version"] = f"{source['protocol_version']}.prospective-v0.1"
        candidate["module_revision"] = "prospective-0.1"
        candidate["display_name"] = f"{base_id} prospective counterbalance sequence {sequence_index:02d}"
        candidate["short_description"] = "Frozen prospective candidate. Sequence is assigned by a Williams counterbalance schedule and then remains immutable within the run."
        candidate["base_protocol_id"] = base_id
        candidate["counterbalance"] = {"design": "Williams first-order balanced", "sequence_index": sequence_index, "zero_based_order": order}
        candidate["branches"] = [copy.deepcopy(branches[i]) for i in order]
        candidate["analysis_contract"]["expected_conditions"] = [b["analysis_alias"] for b in candidate["branches"]]
        candidate["analysis_contract"]["primary_cai_contrasts"] = [
            "TARGET_1-PHASE_SCRAMBLED_1",
            "TARGET_1-SHOT_ORDER_SCRAMBLE_1" if base_id == "PRAYCG4" else "NOT_APPLICABLE_PRAYCG3",
            "TARGET_1-CONTEXTUAL_OVERRIDE_1",
        ]
        candidate["analysis_contract"]["independent_outcomes_not_used_to_construct_cai"] = INDEPENDENT_ITEMS[:6]
        filename = f"{candidate_id}_v0_1.json"
        runner_name = f"run_{candidate_id}_v0_1.py"
        candidate["runner_entry"] = f"scripts/runners/{runner_name}"
        candidate["scientific_boundary"] = (
            "Prospective candidate only. Counterbalancing reduces systematic order confounding but does not eliminate carryover, demand, stimulus, measurement, or model error. "
            "CAI remains an exploratory proxy until prospective reliability and criterion validity are established."
        )
        protocol_path = protocols / filename
        runner_path = runners / runner_name
        runner_path.write_text(runner_text(filename, candidate_id), encoding="utf-8")
        protocol_path.write_text(json.dumps(candidate, indent=2), encoding="utf-8")
        outputs.append({
            "base_protocol_id": base_id, "protocol_id": candidate_id, "sequence_index": sequence_index,
            "order": [b["analysis_alias"] for b in candidate["branches"]],
            "protocol_path": str(protocol_path.relative_to(package_root)).replace("\\", "/"), "protocol_sha256": sha256(protocol_path),
            "runner_path": str(runner_path.relative_to(package_root)).replace("\\", "/"), "runner_sha256": sha256(runner_path),
        })
    return outputs


def write_schedule(records: List[Dict[str, Any]], out_path: Path, participants: int, stimuli: int) -> None:
    grouped: Dict[str, List[Dict[str, Any]]] = {}
    for record in records:
        grouped.setdefault(record["base_protocol_id"], []).append(record)
    rows = []
    for base_id, variants in grouped.items():
        variants.sort(key=lambda item: item["sequence_index"])
        for participant in range(1, participants + 1):
            for stimulus in range(1, stimuli + 1):
                # Stimulus offset prevents every stimulus from occupying the same
                # sequence within a participant while remaining deterministic.
                record = variants[(participant - 1 + stimulus - 1) % len(variants)]
                rows.append({
                    "participant_id": f"P{participant:03d}", "stimulus_id": f"S{stimulus:03d}",
                    "base_protocol_id": base_id, "assigned_protocol_id": record["protocol_id"],
                    "sequence_index": record["sequence_index"], "condition_order": " > ".join(record["order"]),
                    "protocol_sha256": record["protocol_sha256"], "runner_sha256": record["runner_sha256"],
                })
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--protocol-library", type=Path)
    parser.add_argument("--participants", type=int, default=24)
    parser.add_argument("--stimuli", type=int, default=4)
    args = parser.parse_args()
    package_root = args.package_root.resolve()
    tools_root = package_root.parent
    library = (args.protocol_library or (tools_root / "ProtocolRunner_ModuleLibrary_v1_0")).resolve()
    records = []
    records += build(library / "protocols" / "PRAYCG3_original_three_prong_v1_0.json", package_root, "PRAYCG3")
    records += build(library / "protocols" / "PRAYCG4_shotorder_four_branch_v1_0.json", package_root, "PRAYCG4")
    manifest = {"schema": "PRAYCG_ProspectiveProtocolCatalog_v0_1", "version": VERSION, "records": records}
    (package_root / "config").mkdir(parents=True, exist_ok=True)
    (package_root / "config" / "prospective_protocol_catalog_v0_1.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    write_schedule(records, package_root / "config" / "counterbalance_schedule_TEMPLATE_v0_1.csv", args.participants, args.stimuli)
    print(json.dumps({"protocol_variants": len(records), "catalog": str((package_root / 'config' / 'prospective_protocol_catalog_v0_1.json').resolve())}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
