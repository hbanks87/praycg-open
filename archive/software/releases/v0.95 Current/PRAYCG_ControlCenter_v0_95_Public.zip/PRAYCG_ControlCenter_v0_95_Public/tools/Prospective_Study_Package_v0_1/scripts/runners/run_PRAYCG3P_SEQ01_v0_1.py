#!/usr/bin/env python3
"""Locked prospective runner entry for PRAYCG3P_SEQ01."""
import sys
from pathlib import Path

TOOLS_ROOT = Path(__file__).resolve().parents[3]
ENGINE_ROOT = TOOLS_ROOT / "ProtocolRunner_ModuleLibrary_v1_0" / "scripts"
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))
from praycg_protocol_engine_v3_0 import run_full_experiment

if __name__ == "__main__":
    run_full_experiment(Path(__file__).resolve().parents[2] / "protocols" / "PRAYCG3P_SEQ01_v0_1.json")
