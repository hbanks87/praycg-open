# Standalone usage — Interpreter v1.6.0

The offline interpreter accepts a v1.6.0 core output, a completed v1.6.1 chained-analysis folder, or its `workspace` folder. Exact registered artifacts are selected from the canonical tables location; duplicate paths are retained as warnings rather than selected heuristically.

## GUI

```bat
py -3.11 scripts\praycg_offline_interpretive_report_gui_v1_6_0.py
```

## Command line

```bat
py -3.11 scripts\praycg_offline_interpretive_report_generator_v1_6_0.py ^
  --analysis-folder "C:\PRAYCG\analysis\MyRun_MasterComprehensive" ^
  --run-label "MyRun" ^
  --profile all ^
  --auto-run-mred-peak-resolution
```

The output will be written under:

```text
<resolved-data-root>\reports\offline_interpretation_v1_6_0\
```
