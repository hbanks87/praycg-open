# Offline Master Interpreter Method v1.6.0

The Interpreter is deterministic and offline. It does not use a language model. It first builds `PRAYCG_AnalysisArtifactIndex_v1_0`, then builds `PRAYCG_EvidenceLedger_v1_0`, and only then renders prose.

## Artifact selection

- Registered exact filenames are preferred in the resolved canonical `workspace/tables` or `tables` directory.
- Duplicate paths are recorded with hashes and warnings; they do not replace the canonical selection.
- Malformed CSV/JSON, missing data, and unsupported schemas remain separate states.
- A completed chain manifest and `module_status.json` files are authoritative when available.

## Gate lattice

`PASS`, `EXPLORATORY_ONLY`, `FAIL_PRIMARY_GATE`, `NOT_GRADABLE_MISSING_INPUT`, `NOT_APPLICABLE_PROTOCOL`, and `SOFTWARE_ERROR` are preserved. A result table from a blocked module may be inventoried for debugging but cannot become a positive interpretive statement.

Strict primary language also requires `run_eligibility.strict_interpretation_allowed=true`. Passing software and QC gates is necessary but does not prove an effect or mechanism.

## Evidence ledger

Each claim records its tier, module and module state, exact source path/hash/columns/rows, quantitative value when recognized, coverage or uncertainty, counterevidence, limitations, and final claim status. Technical, research, and public-safe reports are different presentations of this same ledger.

Optional cross-run review requires matching canonical analysis-frame schema, columns, and condition/branch sets. Eligibility and suite-version differences are reported. No automatic pooling is performed; compatible structure is not itself replication.

## Scientific boundary

The Interpreter does not prove consciousness, private experience, memory formation, OSM or hidden-Y biology, clinical effects, or literal thermodynamic entropy. Self-report is contextual evidence. HOC-R and other confound checks can reduce specific alternative explanations but cannot establish a preferred mechanism.
