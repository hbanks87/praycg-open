# PRAYCG Offline Master Interpreter v1.6.0

This is a standalone, GitHub-uploadable subset of the PRAYCG Master Comprehensive Suite.

It reads a core or completed chained Master Comprehensive analysis folder, builds a deterministic artifact index and evidence ledger, and writes three report profiles from the same gated claims:

```text
reports/offline_interpretation_v1_6_0/offline_interpretive_report_technical.md
reports/offline_interpretation_v1_6_0/offline_interpretive_report_research.md
reports/offline_interpretation_v1_6_0/offline_interpretive_report_public.md
reports/offline_interpretation_v1_6_0/evidence_ledger_v1_0.json
reports/offline_interpretation_v1_6_0/praycg_analysis_artifact_index_v1_0.json
```

It is not an AI model and does not require internet access.

## What it can summarize

The interpreter uses registered exact filenames and reads run eligibility, the chain manifest, and module-status files before describing tables, including:

```text
A-MRED
MRED-Peak / MRED-Resolution
DGA / Decoder Gate Availability
NUPI
TTI
CII/NIP
CET/EET
MRED-ITP
OCM/RSM
Baseline1 vs Baseline2
ALS/timing QC
stream inventory
phase summaries
```

It distinguishes pass, primary-gate failure, missing input, protocol non-applicability, exploratory completion, software error, malformed input, and absent data. A partial table cannot override its module state.

Optional comparison-run folders receive a canonical schema, column, condition/branch, eligibility, and software-version compatibility review. The Interpreter reports differences but never pools effects automatically.

## GUI use

Run `scripts\praycg_offline_interpretive_report_gui_v1_6_0.py`, validate the selected folder, and then generate the desired profiles. Long work runs in the background and can be cancelled.

## Command-line use

```bat
py -3.11 scripts\praycg_offline_interpretive_report_generator_v1_6_0.py ^
  --analysis-folder "C:\PRAYCG\analysis\MyRun_MasterComprehensive" ^
  --run-label "MyRun" ^
  --profile all ^
  --auto-run-mred-peak-resolution
```

## Boundary

This tool summarizes available PRAYCG module outputs. It does not prove consciousness, memory formation, OSM biology, hidden-Y mechanisms, clinical effects, or literal thermodynamic entropy. Self-report is treated as contextual evidence, not proof of internal state.
