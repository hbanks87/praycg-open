#!/usr/bin/env python3
"""Non-blocking GUI for PRAYCG Offline Master Interpreter v1.6.0."""
from __future__ import annotations

import argparse
import json
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from praycg_artifact_index_v1_0 import build_artifact_index

VERSION="1.6.0"
SCRIPT=Path(__file__).with_name("praycg_offline_interpretive_report_generator_v1_6_0.py")


class App(tk.Tk):
    def __init__(self, defaults=None):
        super().__init__(); self.title(f"PRAYCG Offline Master Interpreter v{VERSION}"); self.geometry("1080x760"); self.minsize(900,650)
        self.analysis=tk.StringVar(); self.outdir=tk.StringVar(); self.comparisons=tk.StringVar(); self.runlabel=tk.StringVar(); self.profile=tk.StringVar(value="all"); self.auto_mred=tk.BooleanVar(value=False); self.status=tk.StringVar(value="Select a core or completed chained-analysis folder.")
        self.events=queue.Queue(); self.worker=None; self.process=None; self.last_outputs={}; self._load_settings(); self._apply_defaults(defaults); self._build(); self.protocol("WM_DELETE_WINDOW",self._close)

    def _apply_defaults(self, defaults):
        """Apply explicit launch context after remembered settings, without running."""
        if defaults is None:return
        if defaults.analysis_folder:
            self.analysis.set(defaults.analysis_folder)
            # A new explicit analysis context must not inherit an output or
            # comparison folder from a previously reviewed run.
            self.outdir.set(defaults.out_dir or "")
            self.comparisons.set(";".join(defaults.comparison_folder or []))
        elif defaults.out_dir:self.outdir.set(defaults.out_dir)
        elif defaults.comparison_folder:self.comparisons.set(";".join(defaults.comparison_folder))
        if defaults.run_label:self.runlabel.set(defaults.run_label)
        if defaults.profile:self.profile.set(defaults.profile)

    def _settings_path(self):
        root=Path(os.environ.get("APPDATA",Path.home()))/"PRAYCG"; return root/"offline_interpreter_v1_6_0_settings.json"

    def _load_settings(self):
        try:
            payload=json.loads(self._settings_path().read_text(encoding="utf-8")); self.analysis.set(payload.get("analysis","")); self.outdir.set(payload.get("outdir","")); self.comparisons.set(payload.get("comparisons","")); self.profile.set(payload.get("profile","all"))
        except Exception: pass

    def _save_settings(self):
        try:
            path=self._settings_path(); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps({"analysis":self.analysis.get(),"outdir":self.outdir.get(),"comparisons":self.comparisons.get(),"profile":self.profile.get()},indent=2),encoding="utf-8")
        except Exception: pass

    def _close(self):
        self._save_settings()
        if self.process and self.process.poll() is None:
            if not messagebox.askyesno("Interpreter running","Stop the running interpreter and close?"): return
            self.process.terminate()
        self.destroy()

    def _row(self,parent,label,var):
        fr=ttk.Frame(parent); fr.pack(fill="x",pady=4); ttk.Label(fr,text=label,width=22).pack(side="left"); ttk.Entry(fr,textvariable=var).pack(side="left",fill="x",expand=True)
        def browse():
            value=filedialog.askdirectory(title=f"Select {label}")
            if value: var.set(value)
        ttk.Button(fr,text="Browse",command=browse).pack(side="left",padx=4)

    def _comparison_row(self,parent):
        fr=ttk.Frame(parent); fr.pack(fill="x",pady=4); ttk.Label(fr,text="Comparison runs",width=22).pack(side="left"); ttk.Entry(fr,textvariable=self.comparisons).pack(side="left",fill="x",expand=True)
        def add():
            value=filedialog.askdirectory(title="Add comparison run folder")
            if value:self.comparisons.set(";".join([x for x in [self.comparisons.get().strip("; "),value] if x]))
        ttk.Button(fr,text="Add Folder",command=add).pack(side="left",padx=4)

    def _build(self):
        pad=ttk.Frame(self,padding=12); pad.pack(fill="both",expand=True)
        ttk.Label(pad,text=f"PRAYCG Offline Master Interpreter v{VERSION}",font=("Arial",16,"bold")).pack(anchor="w")
        ttk.Label(pad,text="Builds a manifest-driven evidence ledger, then produces technical, research, and public-safe reports from the same gated claims. It uses no internet or AI model.",wraplength=1030).pack(anchor="w",pady=(4,8))
        self._row(pad,"Analysis folder",self.analysis); self._row(pad,"Output folder",self.outdir); self._comparison_row(pad)
        ttk.Label(pad,text="Optional comparison folders are separated by semicolons. They receive a schema/condition/version compatibility review; results are never pooled automatically.",wraplength=1030).pack(anchor="w")
        opts=ttk.Frame(pad); opts.pack(fill="x",pady=5); ttk.Label(opts,text="Run label",width=22).pack(side="left"); ttk.Entry(opts,textvariable=self.runlabel,width=30).pack(side="left",padx=(0,12)); ttk.Label(opts,text="Report profile").pack(side="left"); ttk.Combobox(opts,textvariable=self.profile,values=["all","technical","research","public"],state="readonly",width=14).pack(side="left",padx=5)
        ttk.Checkbutton(pad,text="If absent, run the bundled MRED-Peak/Resolution v1.6.0 module first",variable=self.auto_mred).pack(anchor="w",pady=4)
        buttons=ttk.Frame(pad); buttons.pack(fill="x",pady=6)
        self.preview_btn=ttk.Button(buttons,text="Validate Folder / Preview Gates",command=self.preview); self.preview_btn.pack(side="left",padx=3)
        self.run_btn=ttk.Button(buttons,text="Generate Reports",command=self.run); self.run_btn.pack(side="left",padx=3)
        self.cancel_btn=ttk.Button(buttons,text="Cancel",command=self.cancel,state="disabled"); self.cancel_btn.pack(side="left",padx=3)
        ttk.Button(buttons,text="Open Output Folder",command=self.open_output).pack(side="left",padx=3)
        ttk.Button(buttons,text="Open Technical Report",command=self.open_report).pack(side="left",padx=3)
        ttk.Label(pad,textvariable=self.status).pack(anchor="w",pady=3)
        split=ttk.Panedwindow(pad,orient="horizontal"); split.pack(fill="both",expand=True)
        left=ttk.LabelFrame(split,text="Authoritative module states"); right=ttk.LabelFrame(split,text="Activity and validation details"); split.add(left,weight=2); split.add(right,weight=3)
        self.tree=ttk.Treeview(left,columns=("module","status","message"),show="headings"); self.tree.heading("module",text="Module"); self.tree.heading("status",text="Status"); self.tree.heading("message",text="Message"); self.tree.column("module",width=130); self.tree.column("status",width=180); self.tree.column("message",width=330); self.tree.pack(fill="both",expand=True)
        self.log=tk.Text(right,wrap="word"); self.log.pack(fill="both",expand=True)

    def _busy(self,value):
        state="disabled" if value else "normal"; self.preview_btn.configure(state=state); self.run_btn.configure(state=state); self.cancel_btn.configure(state="normal" if value else "disabled")

    def _require_folder(self):
        path=Path(self.analysis.get()).expanduser()
        if not path.is_dir(): messagebox.showwarning("Invalid folder","Select an existing analysis folder."); return None
        return path.resolve()

    def _start_thread(self,kind,func):
        if self.worker and self.worker.is_alive(): return
        self._busy(True); self.status.set("Working...")
        def work():
            try:self.events.put(("done",kind,func()))
            except Exception as exc:self.events.put(("error",kind,str(exc)))
        self.worker=threading.Thread(target=work,daemon=True); self.worker.start(); self.after(100,self._poll)

    def _poll(self):
        try:
            while True:
                item=self.events.get_nowait()
                if item[0]=="done":
                    _,kind,payload=item; self._busy(False); self.status.set("Ready.")
                    if kind=="preview": self._show_preview(payload)
                    else: self._show_result(payload)
                elif item[0]=="error":
                    _,kind,error=item; self._busy(False); self.status.set("Failed."); self.log.insert("end",error+"\n"); messagebox.showerror(f"{kind.title()} failed",error)
        except queue.Empty: pass
        if self.worker and self.worker.is_alive(): self.after(100,self._poll)

    def preview(self):
        path=self._require_folder()
        if path: self._start_thread("preview",lambda:build_artifact_index(path,include_hashes=False))

    def _show_preview(self,index):
        self.tree.delete(*self.tree.get_children())
        for name,row in sorted(index.get("module_statuses",{}).items()): self.tree.insert("","end",values=(name,row.get("status",""),row.get("message","")))
        self.log.delete("1.0","end"); self.log.insert("end",json.dumps({"layout":index.get("layout"),"run":index.get("run"),"status_counts":index.get("status_counts"),"issues":index.get("issues")},indent=2,default=str))
        self.status.set(f"{index.get('layout',{}).get('analysis_kind','unknown')} | interpretation gate: {index.get('interpretation_gate','DIAGNOSTIC_ONLY')}")

    def run(self):
        path=self._require_folder()
        if not path:return
        cmd=[sys.executable,str(SCRIPT),"--analysis-folder",str(path),"--profile",self.profile.get()]
        if self.outdir.get():cmd += ["--out-dir",self.outdir.get()]
        if self.runlabel.get():cmd += ["--run-label",self.runlabel.get()]
        for folder in [x.strip() for x in self.comparisons.get().split(";") if x.strip()]:cmd += ["--comparison-folder",folder]
        if self.auto_mred.get():cmd += ["--auto-run-mred-peak-resolution"]
        self.log.insert("end","Running manifest-driven interpreter...\n"); self._busy(True); self.status.set("Generating reports...")
        def work():
            try:
                self.process=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding="utf-8",errors="replace")
                stdout,stderr=self.process.communicate(); code=self.process.returncode
                if code:return {"error":f"Generator exited with code {code}","stdout":stdout,"stderr":stderr}
                try:return json.loads(stdout)
                except Exception:return {"status":"ok","stdout":stdout,"stderr":stderr}
            finally:self.process=None
        self.worker=threading.Thread(target=lambda:self.events.put(("done","generate",work())),daemon=True); self.worker.start(); self.after(100,self._poll)

    def _show_result(self,result):
        if result.get("error"):
            self.log.insert("end",json.dumps(result,indent=2)+"\n"); messagebox.showerror("Generation failed",result["error"]); return
        self.last_outputs=result.get("outputs",{}); self.log.insert("end",json.dumps(result,indent=2)+"\n"); self.log.see("end"); self.status.set(f"Complete. Interpretation gate: {result.get('interpretation_gate','see report')}"); messagebox.showinfo("Complete","Evidence ledger and selected reports were generated.")

    def cancel(self):
        if self.process and self.process.poll() is None:
            self.process.terminate(); self.status.set("Cancellation requested...")
        else:self.status.set("The current validation step cannot be interrupted safely; it will finish shortly.")

    def _open(self,path):
        try:
            if os.name=="nt":os.startfile(str(path))
            else:messagebox.showinfo("Path",str(path))
        except Exception as exc:messagebox.showerror("Could not open",str(exc))

    def open_output(self):
        target=Path(self.outdir.get()).expanduser() if self.outdir.get() else None
        if target is None and self.last_outputs:
            first=next(iter(self.last_outputs.values()),""); target=Path(first).parent if first else None
        if target:self._open(target.resolve())
        else:messagebox.showinfo("Output folder","Generate a report or select an output folder first.")

    def open_report(self):
        raw=self.last_outputs.get("technical_html") or self.last_outputs.get("technical_markdown")
        if raw and Path(raw).is_file():self._open(Path(raw))
        else:messagebox.showinfo("Technical report","Generate the technical or all profile first.")


def main():
    parser=argparse.ArgumentParser(description="PRAYCG Offline Master Interpreter v1.6.0 GUI")
    parser.add_argument("--analysis-folder",default="")
    parser.add_argument("--out-dir",default="")
    parser.add_argument("--comparison-folder",action="append",default=[])
    parser.add_argument("--run-label",default="")
    parser.add_argument("--profile",default="",choices=("","all","technical","research","public"))
    args=parser.parse_args()
    App(args).mainloop()


if __name__=="__main__":main()
