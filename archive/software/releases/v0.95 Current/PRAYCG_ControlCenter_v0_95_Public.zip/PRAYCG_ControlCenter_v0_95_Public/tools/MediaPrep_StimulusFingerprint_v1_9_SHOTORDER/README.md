# PRAYCG MediaPrep / Stimulus Fingerprint v1.9 ShotOrder

This is the current media-preparation package bundled with PRAYCG Control Center v0.92. v0.92 can prefill the GUI's master MP4, output root, and project name; generation still requires an explicit Run click.

The dashboard launches `scripts/run_PRAYCG_MediaPrep_v1_8.py`, which starts the current MediaPrep GUI and includes the stable audio-stack fixes. The v1.9 ShotOrder workflow is provided by `scripts/praycg_shot_order_scramble_control_v1_9.py` and is also available from the Control Center.

The scripts retained here support media preparation, stimulus fingerprints, anchor locking, embedded ALS barcode backup, CET/EET processing, post-processing, and ShotOrder control. Current workflow and output notes are in `docs`.

MediaPrep prepares media and quality-control artifacts. It does not certify physiology, meaning, an endpoint, or a biological mechanism. Do not include copyrighted media in a public redistribution unless you have permission.
