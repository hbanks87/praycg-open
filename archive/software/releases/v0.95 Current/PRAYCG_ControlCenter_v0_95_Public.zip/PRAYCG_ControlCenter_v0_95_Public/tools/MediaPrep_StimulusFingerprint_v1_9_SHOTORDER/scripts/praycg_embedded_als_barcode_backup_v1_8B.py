#!/usr/bin/env python3
"""PRAYCG MediaPrep backup MP4-embedded ALS barcode v1.8B.

Optional redundancy layer. The preferred timing channel is PRAYCG2.2 runner-level
ALS barcode overlay. This script creates MP4s with a visible long/short barcode
prepended or overlaid at the beginning of a media file when a backup file-level
pulse is desired.

It uses OpenCV for video frames and ffmpeg, if available, to copy/mux audio.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple

try:
    import cv2  # type: ignore
except Exception as exc:
    raise SystemExit("OpenCV is required: pip install opencv-python") from exc


def barcode_frames(fps: float, width: int, height: int, *, position: str, size_px: int, margin_px: int, black_pre: float, white_a: float, black_gap: float, white_b: float, black_post: float):
    import numpy as np
    seq = [(black_pre, False), (white_a, True), (black_gap, False), (white_b, True), (black_post, False)]
    size = size_px if size_px > 0 else max(40, int(min(width, height) * .08))
    margin = margin_px
    if position == 'fullscreen':
        rect = (0,0,width,height)
    else:
        x1 = margin if 'left' in position else width - margin - size
        y1 = margin if ('upper' in position or 'top' in position) else height - margin - size
        rect = (max(0,x1), max(0,y1), min(width,x1+size), min(height,y1+size))
    for dur, white in seq:
        n = max(1, int(round(float(dur) * fps)))
        for _ in range(n):
            frame = np.zeros((height, width, 3), dtype=np.uint8)
            if white:
                x1,y1,x2,y2 = rect
                frame[y1:y2, x1:x2, :] = 255
            yield frame


def run(cmd: List[str]) -> Tuple[int, str]:
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        return p.returncode, p.stdout
    except Exception as exc:
        return 999, repr(exc)


def process_video(src: Path, out: Path, args) -> Dict:
    cap = cv2.VideoCapture(str(src))
    if not cap.isOpened():
        raise RuntimeError(f'Could not open video: {src}')
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1920)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 1080)
    frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        silent = Path(td) / 'silent_barcode_video.mp4'
        writer = cv2.VideoWriter(str(silent), fourcc, fps, (width,height))
        for fr in barcode_frames(fps,width,height,position=args.position,size_px=args.size_px,margin_px=args.margin_px,black_pre=args.black_pre_sec,white_a=args.white_a_sec,black_gap=args.black_gap_sec,white_b=args.white_b_sec,black_post=args.black_post_sec):
            writer.write(fr)
        while True:
            ok, frame = cap.read()
            if not ok: break
            writer.write(frame)
        writer.release(); cap.release()
        ffmpeg = shutil.which('ffmpeg')
        barcode_ms = int(round((args.black_pre_sec+args.white_a_sec+args.black_gap_sec+args.white_b_sec+args.black_post_sec) * 1000))
        if ffmpeg:
            # Delay original audio by the barcode duration so media content begins after the visual barcode.
            # If the source has no audio or ffmpeg fails, fall back to the silent barcode-prepended video.
            cmd = [
                ffmpeg, '-y', '-loglevel', 'error',
                '-i', str(silent), '-i', str(src),
                '-filter_complex', f'[1:a]adelay={barcode_ms}:all=1[a]',
                '-map', '0:v:0', '-map', '[a]',
                '-c:v', 'copy', '-c:a', 'aac', '-shortest', str(out)
            ]
            rc, log = run(cmd)
            if rc == 0 and out.exists() and out.stat().st_size > 0:
                audio_note = f'Original audio delayed by {barcode_ms} ms and muxed with barcode-prepended video.'
            else:
                shutil.copyfile(silent, out)
                audio_note = 'ffmpeg audio mux failed or source had no audio; wrote silent MP4 fallback. ffmpeg log: ' + str(log)[:500]
        else:
            shutil.copyfile(silent, out)
            audio_note = 'ffmpeg not found; wrote silent MP4 fallback.'
    return {'input': str(src), 'output': str(out), 'fps': fps, 'width': width, 'height': height, 'original_frame_count': frame_count, 'barcode_total_sec': args.black_pre_sec+args.white_a_sec+args.black_gap_sec+args.white_b_sec+args.black_post_sec, 'position': args.position, 'size_px': args.size_px, 'margin_px': args.margin_px, 'audio_note': audio_note}


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--input', nargs='+', required=False, help='MP4 files to barcode. If omitted, GUI file picker opens.')
    ap.add_argument('--out-dir', default='')
    ap.add_argument('--suffix', default='_alsbarcode_backup_v1_8B')
    ap.add_argument('--position', default='lower_right', choices=['lower_right','lower_left','upper_right','upper_left','fullscreen'])
    ap.add_argument('--size-px', type=int, default=180)
    ap.add_argument('--margin-px', type=int, default=40)
    ap.add_argument('--black-pre-sec', type=float, default=.50)
    ap.add_argument('--white-a-sec', type=float, default=2.00)
    ap.add_argument('--black-gap-sec', type=float, default=.50)
    ap.add_argument('--white-b-sec', type=float, default=.75)
    ap.add_argument('--black-post-sec', type=float, default=1.00)
    args=ap.parse_args()
    inputs=args.input
    if not inputs:
        import tkinter as tk
        from tkinter import filedialog
        root=tk.Tk(); root.withdraw()
        inputs=list(filedialog.askopenfilenames(title='Select MP4s for optional embedded ALS barcode backup', filetypes=[('MP4','*.mp4')]))
        root.destroy()
    if not inputs:
        print('No input selected.'); return 1
    out_dir=Path(args.out_dir).expanduser() if args.out_dir else Path(inputs[0]).expanduser().parent / 'als_barcode_backup_v1_8B'
    results=[]
    for s in inputs:
        src=Path(s).expanduser(); out=out_dir / f'{src.stem}{args.suffix}.mp4'
        results.append(process_video(src,out,args))
    manifest={'schema':'PRAYCG_MediaPrep_Embedded_ALS_Barcode_Backup_v1_8B','created_utc':datetime.utcnow().isoformat()+'Z','preferred_primary':'PRAYCG2.2 runner-level ALS barcode overlay','results':results,'boundary':'Optional backup pulse only. This tool does not certify empirical endpoints and may produce silent videos unless remuxed.'}
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir/'embedded_als_barcode_backup_manifest_v1_8B.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(json.dumps(manifest, indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
