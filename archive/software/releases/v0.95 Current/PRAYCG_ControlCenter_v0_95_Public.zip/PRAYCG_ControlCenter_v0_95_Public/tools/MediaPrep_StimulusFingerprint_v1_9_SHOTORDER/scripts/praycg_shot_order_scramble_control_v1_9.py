#!/usr/bin/env python3
"""
PRAYCG MediaPrep v1.9 - ShotOrderScramble Structural Control Generator

Creates a high-order structural control by detecting shots, shuffling shot order,
and reassembling the video while preserving local faces/objects/biological motion.
The cue schedule should be applied AFTER shot-order reassembly so Target, Override,
PhaseScrambled, and ShotOrderScramble share the same cue timing.

Public-safe boundary: this is a control-media generator. It does not certify narrative
meaning, physiology, A-MRED, consciousness, OSM biology, or mechanism.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import cv2  # type: ignore
    import numpy as np  # type: ignore
except Exception as exc:
    raise SystemExit("This tool requires opencv-python and numpy. Install with: py -3.11 -m pip install opencv-python numpy") from exc


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def slugify(text: str, default: str = 'stimulus') -> str:
    import re
    text = str(text or '').strip().lower()
    text = re.sub(r'[^a-z0-9._-]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('._-')
    return text or default


def ffmpeg_path(explicit: Optional[str] = None) -> str:
    if explicit:
        return explicit
    return shutil.which('ffmpeg') or 'ffmpeg'


def ffprobe_json(video: Path, ffprobe: Optional[str] = None) -> Dict[str, Any]:
    exe = ffprobe or shutil.which('ffprobe') or 'ffprobe'
    cmd = [exe, '-v', 'error', '-show_streams', '-show_format', '-print_format', 'json', str(video)]
    try:
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True)
        return json.loads(out)
    except Exception as exc:
        return {'error': str(exc), 'cmd': cmd}


def video_props_opencv(path: Path) -> Dict[str, Any]:
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise RuntimeError(f'Could not open video: {path}')
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 0) or 30.0
    frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    duration = frames / fps if fps > 0 else 0.0
    cap.release()
    return {'fps': fps, 'frame_count': frames, 'width': width, 'height': height, 'duration_sec': duration}


@dataclass
class Shot:
    shot_index: int
    start_sec: float
    end_sec: float
    duration_sec: float
    start_frame: int
    end_frame: int
    mean_change: float = 0.0
    shuffled_index: Optional[int] = None


def detect_shots_opencv(video: Path, threshold: float = 27.0, min_shot_sec: float = 0.75, sample_stride: int = 1) -> Tuple[List[Shot], Dict[str, Any]]:
    """Simple content-difference shot detector with robust fallback.

    threshold is interpreted on 0-255 grayscale frame mean absolute difference. This is a fallback
    detector, not a substitute for human QC. PySceneDetect can be used externally if desired.
    """
    props = video_props_opencv(video)
    fps = float(props['fps'])
    total_frames = int(props['frame_count'])
    cap = cv2.VideoCapture(str(video))
    prev_small = None
    diffs: List[Tuple[int, float]] = []
    frame_i = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if frame_i % max(1, sample_stride) == 0:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            small = cv2.resize(gray, (160, 90), interpolation=cv2.INTER_AREA)
            if prev_small is not None:
                diff = float(np.mean(np.abs(small.astype(np.float32) - prev_small.astype(np.float32))))
                diffs.append((frame_i, diff))
            prev_small = small
        frame_i += 1
    cap.release()

    min_gap_frames = max(1, int(round(min_shot_sec * fps)))
    cut_frames: List[int] = [0]
    last_cut = 0
    for idx, diff in diffs:
        if diff >= threshold and idx - last_cut >= min_gap_frames:
            cut_frames.append(idx)
            last_cut = idx
    if total_frames > 0:
        cut_frames.append(total_frames)
    cut_frames = sorted(set([x for x in cut_frames if 0 <= x <= total_frames]))

    shots: List[Shot] = []
    for a, b in zip(cut_frames[:-1], cut_frames[1:]):
        if b <= a:
            continue
        dur = (b - a) / fps
        if dur < min_shot_sec and shots:
            # merge micro-shot into prior segment
            prior = shots[-1]
            prior.end_frame = b
            prior.end_sec = b / fps
            prior.duration_sec = prior.end_sec - prior.start_sec
            continue
        mean_change = float(np.mean([d for i, d in diffs if a <= i < b]) if diffs else 0.0)
        shots.append(Shot(len(shots), a / fps, b / fps, dur, a, b, mean_change))

    if len(shots) < 2:
        # fallback fixed windows
        shots = []
        win = max(min_shot_sec, 2.0)
        t = 0.0
        n = 0
        while t < props['duration_sec'] - 0.05:
            e = min(props['duration_sec'], t + win)
            shots.append(Shot(n, t, e, e - t, int(t * fps), int(e * fps), 0.0))
            t = e
            n += 1
        mode = 'fixed_window_fallback'
    else:
        mode = 'opencv_content_detector'

    diag = {'detector': mode, 'threshold': threshold, 'min_shot_sec': min_shot_sec, 'sample_stride': sample_stride, 'n_diffs': len(diffs), 'n_shots': len(shots), 'video_props': props}
    return shots, diag


def deranged_shuffle(n: int, seed: int, max_attempts: int = 5000) -> Tuple[List[int], Dict[str, Any]]:
    rng = random.Random(seed)
    base = list(range(n))
    if n <= 1:
        return base, {'n_fixed_points': n, 'n_original_adjacent_pairs': max(0, n-1), 'attempts': 0, 'warning': 'too_few_shots'}
    best = None
    best_score = 1e9
    best_diag = {}
    original_pairs = set(zip(base[:-1], base[1:]))
    for attempt in range(1, max_attempts + 1):
        perm = base[:]
        rng.shuffle(perm)
        fixed = sum(1 for i, p in enumerate(perm) if i == p)
        adjacent = sum(1 for a, b in zip(perm[:-1], perm[1:]) if (a, b) in original_pairs)
        score = fixed * 10 + adjacent
        if score < best_score:
            best = perm[:]
            best_score = score
            best_diag = {'n_fixed_points': fixed, 'n_original_adjacent_pairs': adjacent, 'attempts': attempt}
        if fixed == 0 and adjacent == 0:
            break
    return best or base, best_diag


def run_cmd(cmd: List[str], label: str, log: List[Dict[str, Any]]) -> None:
    rec = {'label': label, 'cmd': cmd, 'returncode': None}
    try:
        proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        rec['returncode'] = proc.returncode
        rec['stdout_tail'] = proc.stdout[-4000:]
        if proc.returncode != 0:
            raise RuntimeError(f'{label} failed with code {proc.returncode}\n{proc.stdout[-4000:]}')
    finally:
        log.append(rec)


def extract_segments(input_video: Path, shots: List[Shot], temp_dir: Path, ffmpeg: str, log: List[Dict[str, Any]], crf: int = 18) -> List[Path]:
    segs = []
    for shot in shots:
        out = temp_dir / f'shot_{shot.shot_index:04d}.mp4'
        cmd = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'error', '-ss', f'{shot.start_sec:.6f}', '-to', f'{shot.end_sec:.6f}', '-i', str(input_video), '-map', '0:v:0', '-map', '0:a?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', str(crf), '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-avoid_negative_ts', 'make_zero', str(out)]
        run_cmd(cmd, f'extract_segment_{shot.shot_index:04d}', log)
        segs.append(out)
    return segs


def concat_segments(segs: List[Path], order: List[int], out_video: Path, ffmpeg: str, log: List[Dict[str, Any]]) -> None:
    concat_file = out_video.parent / (out_video.stem + '_concat_list.txt')
    with concat_file.open('w', encoding='utf-8') as f:
        for idx in order:
            safe = str(segs[idx]).replace("\\", "/").replace("'", "\\'")
            f.write(f"file '{safe}'\n")
    # Try stream copy first because segments share encoding parameters.
    cmd1 = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', str(concat_file), '-c', 'copy', str(out_video)]
    try:
        run_cmd(cmd1, 'concat_stream_copy', log)
    except Exception:
        cmd2 = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', str(concat_file), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', str(out_video)]
        run_cmd(cmd2, 'concat_reencode_fallback', log)


def read_cue_schedule(path: Path) -> List[Dict[str, Any]]:
    data = json.loads(path.read_text(encoding='utf-8'))
    if isinstance(data, dict):
        for key in ['cue_events', 'cues', 'events']:
            if isinstance(data.get(key), list):
                return data[key]
        if isinstance(data.get('cue_schedule'), list):
            return data['cue_schedule']
    raise ValueError(f'Could not find cue_events/cues/events list in {path}')


def overlay_cues_ffmpeg(input_video: Path, cue_schedule_json: Path, out_video: Path, ffmpeg: str, log: List[Dict[str, Any]], position: str = 'upper_right') -> Dict[str, Any]:
    cues = read_cue_schedule(cue_schedule_json)
    # Limit drawtext chain size sensibly; PRAYCG clips usually have <150 cues.
    filters = []
    for cue in cues:
        val = str(cue.get('value', cue.get('cue_value', cue.get('number', ''))))
        start = float(cue.get('start_sec', cue.get('start', 0.0)))
        end = float(cue.get('end_sec', cue.get('end', start + float(cue.get('duration_sec', 0.85)))))
        if not val:
            continue
        # fixed PRAYCG upper-right badge. Escape punctuation for ffmpeg.
        text = val.replace("'", "\\'").replace(':', '\\:')
        expr = f"drawtext=text='{text}':x=w-tw-70:y=50:fontsize=64:fontcolor=white:box=1:boxcolor=black@0.45:boxborderw=14:enable='between(t,{start:.3f},{end:.3f})'"
        filters.append(expr)
    if not filters:
        shutil.copy2(input_video, out_video)
        return {'cue_overlay_status': 'NO_CUES_FOUND_COPIED_CLEAN_VIDEO', 'cue_count': 0}
    vf = ','.join(filters)
    cmd = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'error', '-i', str(input_video), '-vf', vf, '-map', '0:a?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', str(out_video)]
    try:
        run_cmd(cmd, 'cue_overlay_drawtext', log)
        return {'cue_overlay_status': 'PASS_FFMPEG_DRAWTEXT', 'cue_count': len(cues)}
    except Exception as exc:
        # drawtext may be disabled in some ffmpeg builds. Keep clean output and warn.
        return {'cue_overlay_status': 'FAILED_FFMPEG_DRAWTEXT_CLEAN_VIDEO_ONLY', 'cue_count': len(cues), 'error': str(exc)}


def make_contact_sheet(input_video: Path, shots: List[Shot], order: List[int], out_jpg: Path, cols: int = 5, thumb_w: int = 240) -> None:
    if not shots:
        return
    cap = cv2.VideoCapture(str(input_video))
    fps = float(cap.get(cv2.CAP_PROP_FPS) or 30.0)
    thumbs = []
    font = cv2.FONT_HERSHEY_SIMPLEX
    for rank, shot_idx in enumerate(order[:min(len(order), 30)]):
        shot = shots[shot_idx]
        mid_frame = int(((shot.start_sec + shot.end_sec) / 2.0) * fps)
        cap.set(cv2.CAP_PROP_POS_FRAMES, mid_frame)
        ok, frame = cap.read()
        if not ok:
            continue
        h, w = frame.shape[:2]
        scale = thumb_w / max(1, w)
        thumb_h = int(h * scale)
        thumb = cv2.resize(frame, (thumb_w, thumb_h), interpolation=cv2.INTER_AREA)
        label = f'{rank:02d}: shot {shot_idx:02d}'
        cv2.rectangle(thumb, (0, 0), (thumb_w, 26), (0, 0, 0), -1)
        cv2.putText(thumb, label, (6, 18), font, 0.55, (255,255,255), 1, cv2.LINE_AA)
        thumbs.append(thumb)
    cap.release()
    if not thumbs:
        return
    max_h = max(t.shape[0] for t in thumbs)
    rows = math.ceil(len(thumbs) / cols)
    sheet = np.zeros((rows * max_h, cols * thumb_w, 3), dtype=np.uint8)
    for i, t in enumerate(thumbs):
        r, c = divmod(i, cols)
        sheet[r*max_h:r*max_h+t.shape[0], c*thumb_w:c*thumb_w+t.shape[1]] = t
    cv2.imwrite(str(out_jpg), sheet)


def write_csv_shots(path: Path, shots: List[Shot], order: List[int]) -> None:
    inverse = {shot_idx: rank for rank, shot_idx in enumerate(order)}
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['shot_index','shuffled_index','start_sec','end_sec','duration_sec','start_frame','end_frame','mean_change'])
        writer.writeheader()
        for s in shots:
            d = asdict(s)
            d['shuffled_index'] = inverse.get(s.shot_index)
            writer.writerow(d)


def qc_verdict(shots: List[Shot], perm_diag: Dict[str, Any]) -> Tuple[str, List[str]]:
    warnings = []
    if len(shots) < 8:
        warnings.append('Few detected shots: shot-order scramble may not adequately destroy narrative order.')
    if len(shots) > 150:
        warnings.append('Very many shots: control may become excessively chaotic/aversive or detection may be over-segmented.')
    max_dur = max([s.duration_sec for s in shots], default=0)
    total = sum(s.duration_sec for s in shots)
    if total and max_dur / total > 0.35:
        warnings.append('One long shot dominates the stimulus; narrative may remain inside that shot.')
    if perm_diag.get('n_fixed_points', 0) > 0:
        warnings.append('Shuffle retained some shots in original positions.')
    if perm_diag.get('n_original_adjacent_pairs', 0) > 0:
        warnings.append('Shuffle retained one or more original adjacent shot pairs.')
    if len(shots) < 4:
        verdict = 'FAIL_TOO_FEW_SHOTS'
    elif warnings:
        verdict = 'PILOT_ONLY_REQUIRES_MANUAL_QC'
    else:
        verdict = 'PASS_AUTOMATED_STRUCTURE_QC_REQUIRES_MANUAL_REVIEW'
    return verdict, warnings



def launch_gui() -> int:
    import tkinter as tk
    from tkinter import filedialog, messagebox
    root = tk.Tk()
    root.title('PRAYCG ShotOrderScramble Generator v1.9')
    root.geometry('760x420')
    vars = {
        'input': tk.StringVar(),
        'cue': tk.StringVar(),
        'out': tk.StringVar(),
        'project': tk.StringVar(value='praycg_stimulus'),
        'seed': tk.StringVar(value='20260724'),
        'threshold': tk.StringVar(value='27.0'),
        'minshot': tk.StringVar(value='0.75')
    }
    def row(label, key, browse=None):
        fr=tk.Frame(root); fr.pack(fill='x', padx=10, pady=4)
        tk.Label(fr, text=label, width=22, anchor='w').pack(side='left')
        tk.Entry(fr, textvariable=vars[key]).pack(side='left', fill='x', expand=True)
        if browse:
            tk.Button(fr, text='Browse', command=browse).pack(side='left', padx=4)
    row('Cleaned master MP4', 'input', lambda: vars['input'].set(filedialog.askopenfilename(filetypes=[('MP4','*.mp4'),('All','*.*')]) or vars['input'].get()))
    row('Cue schedule JSON', 'cue', lambda: vars['cue'].set(filedialog.askopenfilename(filetypes=[('JSON','*.json'),('All','*.*')]) or vars['cue'].get()))
    row('Output folder', 'out', lambda: vars['out'].set(filedialog.askdirectory() or vars['out'].get()))
    row('Project name', 'project')
    row('Shuffle seed', 'seed')
    row('Detection threshold', 'threshold')
    row('Minimum shot sec', 'minshot')
    txt=tk.Text(root, height=9); txt.pack(fill='both', expand=True, padx=10, pady=6)
    txt.insert('end', 'Select a cleaned master MP4, optional cue schedule JSON, and output folder.\nThis should run before cues are applied where possible; cue overlay is then applied to the shuffled control.\n')
    def run_it():
        if not vars['input'].get() or not vars['out'].get():
            messagebox.showwarning('Missing input', 'Select an input MP4 and output folder.')
            return
        cmd_args=['--input', vars['input'].get(), '--out-dir', vars['out'].get(), '--project-name', vars['project'].get(), '--seed', vars['seed'].get(), '--threshold', vars['threshold'].get(), '--min-shot-sec', vars['minshot'].get()]
        if vars['cue'].get(): cmd_args += ['--cue-schedule', vars['cue'].get()]
        txt.insert('end', '\nRunning ShotOrderScramble...\n')
        txt.see('end'); root.update()
        try:
            rc = main(cmd_args)
            txt.insert('end', 'Done. Check output folder.\n')
            messagebox.showinfo('Done', 'ShotOrderScramble generation finished. Check output folder and manual QC report.')
        except Exception as e:
            txt.insert('end', f'ERROR: {e}\n')
            messagebox.showerror('Error', str(e))
    tk.Button(root, text='GENERATE SHOT-ORDER CONTROL', command=run_it, bg='#6b1b1b', fg='white').pack(fill='x', padx=10, pady=6)
    root.mainloop()
    return 0

def main(argv: Optional[List[str]] = None) -> int:
    if argv is None and len(sys.argv) == 1:
        return launch_gui()
    ap = argparse.ArgumentParser(description='PRAYCG MediaPrep v1.9 ShotOrderScramble generator')
    ap.add_argument('--input', required=True, help='Cleaned master MP4, before cue overlay if possible')
    ap.add_argument('--cue-schedule', default='', help='Existing PRAYCG cue schedule JSON to apply after shot shuffle')
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--project-name', default='')
    ap.add_argument('--seed', type=int, default=20260724)
    ap.add_argument('--threshold', type=float, default=27.0)
    ap.add_argument('--min-shot-sec', type=float, default=0.75)
    ap.add_argument('--sample-stride', type=int, default=1)
    ap.add_argument('--audio-policy', choices=['paired_fragmented_audio','clean_video_only_then_manual_audio','speech_shaped_noise_placeholder'], default='paired_fragmented_audio')
    ap.add_argument('--ffmpeg', default='')
    ap.add_argument('--keep-temp', action='store_true')
    args = ap.parse_args(argv)

    inp = Path(args.input).expanduser().resolve()
    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    project = slugify(args.project_name or inp.stem, 'praycg_stimulus')
    ffmpeg = ffmpeg_path(args.ffmpeg)
    log: List[Dict[str, Any]] = []

    if not inp.exists():
        raise SystemExit(f'Input not found: {inp}')
    cue_schedule = Path(args.cue_schedule).expanduser().resolve() if args.cue_schedule else None
    if cue_schedule and not cue_schedule.exists():
        raise SystemExit(f'Cue schedule not found: {cue_schedule}')

    shots, diag = detect_shots_opencv(inp, threshold=args.threshold, min_shot_sec=args.min_shot_sec, sample_stride=args.sample_stride)
    order, perm_diag = deranged_shuffle(len(shots), args.seed)
    for rank, shot_idx in enumerate(order):
        shots[shot_idx].shuffled_index = rank

    clean_out = out_dir / f'stimulus_structural_control_clean_shot_order_scrambled_{project}_v1_9.mp4'
    cued_out = out_dir / f'stimulus_structural_control_cued_shot_order_scrambled_{project}_v1_9.mp4'
    shot_csv = out_dir / f'shot_order_scramble_shot_table_{project}_v1_9.csv'
    manifest_json = out_dir / f'shot_order_scramble_manifest_{project}_v1_9.json'
    report_md = out_dir / f'shot_order_scramble_qc_report_{project}_v1_9.md'
    contact_jpg = out_dir / f'shot_order_scramble_preview_contact_sheet_{project}_v1_9.jpg'

    tmp_context = tempfile.TemporaryDirectory(prefix='praycg_sos_')
    tmp = Path(tmp_context.name)
    try:
        segs = extract_segments(inp, shots, tmp, ffmpeg, log)
        concat_segments(segs, order, clean_out, ffmpeg, log)
    finally:
        if args.keep_temp:
            # preserve by copying into out_dir
            keep = out_dir / 'shot_order_temp_segments'
            if keep.exists(): shutil.rmtree(keep)
            shutil.copytree(tmp, keep)
        tmp_context.cleanup()

    cue_diag: Dict[str, Any] = {'cue_overlay_status': 'NOT_REQUESTED', 'cue_count': 0}
    if cue_schedule:
        cue_diag = overlay_cues_ffmpeg(clean_out, cue_schedule, cued_out, ffmpeg, log)
    else:
        shutil.copy2(clean_out, cued_out)
        cue_diag = {'cue_overlay_status': 'NO_CUE_SCHEDULE_CLEAN_VIDEO_COPIED_AS_CUED_PLACEHOLDER', 'cue_count': 0}

    try:
        make_contact_sheet(inp, shots, order, contact_jpg)
    except Exception as exc:
        log.append({'label':'contact_sheet_failed','error':str(exc)})
    write_csv_shots(shot_csv, shots, order)
    verdict, warnings = qc_verdict(shots, perm_diag)

    manifest = {
        'schema': 'PRAYCG_shot_order_scramble_manifest_v1_9',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'project_name': project,
        'input_cleaned_master': str(inp),
        'input_sha256': sha256_file(inp),
        'output_clean_shot_order_scrambled': str(clean_out),
        'output_cued_shot_order_scrambled': str(cued_out),
        'output_clean_sha256': sha256_file(clean_out) if clean_out.exists() else None,
        'output_cued_sha256': sha256_file(cued_out) if cued_out.exists() else None,
        'cue_schedule_json': str(cue_schedule) if cue_schedule else None,
        'cue_schedule_sha256': sha256_file(cue_schedule) if cue_schedule and cue_schedule.exists() else None,
        'shot_table_csv': str(shot_csv),
        'contact_sheet': str(contact_jpg) if contact_jpg.exists() else None,
        'detector': diag,
        'shuffle': {'seed': args.seed, **perm_diag, 'order': order},
        'audio_policy': args.audio_policy,
        'cue_overlay': cue_diag,
        'qc_verdict': verdict,
        'qc_warnings': warnings,
        'ffmpeg_commands': log,
        'claim_boundary': 'ShotOrderScramble is a high-order structural control. It preserves local visual/social structure better than phase scrambling but does not prove narrative meaning by itself.'
    }
    manifest_json.write_text(json.dumps(manifest, indent=2), encoding='utf-8')

    report = [
        f'# PRAYCG ShotOrderScramble QC Report v1.9', '',
        f'Project: `{project}`',
        f'Created UTC: `{manifest["created_utc"]}`', '',
        '## Outputs',
        f'- Clean shot-order control: `{clean_out}`',
        f'- Cued shot-order control: `{cued_out}`',
        f'- Shot table: `{shot_csv}`',
        f'- Manifest: `{manifest_json}`',
        f'- Preview contact sheet: `{contact_jpg if contact_jpg.exists() else "not generated"}`', '',
        '## Automated QC',
        f'- Verdict: `{verdict}`',
        f'- Detected shots: `{len(shots)}`',
        f'- Fixed points in shuffle: `{perm_diag.get("n_fixed_points")}`',
        f'- Original adjacent pairs retained: `{perm_diag.get("n_original_adjacent_pairs")}`',
        f'- Cue overlay status: `{cue_diag.get("cue_overlay_status")}`', '',
        '## Warnings',
    ]
    if warnings:
        report += [f'- {w}' for w in warnings]
    else:
        report += ['- None from automated QC. Manual review is still required.']
    report += ['', '## Required manual QC',
        '- Watch the shot-order scrambled control and confirm the narrative arc is broken.',
        '- Confirm local faces/bodies/objects/motion are still visible enough to serve as high-order structural control.',
        '- Confirm cue timing and legibility if cue overlay succeeded.',
        '- Confirm audio policy: local fragments may survive, but coherent story reconstruction should fail.',
        '', '## Boundary',
        'This tool prepares a structural control. It does not certify meaning, A-MRED, OSM, consciousness, or mechanism.'
    ]
    report_md.write_text('\n'.join(report) + '\n', encoding='utf-8')
    print(json.dumps({'status':'done', 'manifest':str(manifest_json), 'qc_verdict':verdict, 'n_shots':len(shots)}, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
