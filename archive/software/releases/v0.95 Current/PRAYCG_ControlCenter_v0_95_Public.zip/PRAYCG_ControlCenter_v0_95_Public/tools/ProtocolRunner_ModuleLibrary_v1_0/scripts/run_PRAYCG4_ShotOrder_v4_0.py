#!/usr/bin/env python3
"""PRAYCG4 runner entry point for the four-branch ShotOrder protocol."""
from pathlib import Path

from praycg_protocol_engine_v3_0 import run_full_experiment


if __name__ == "__main__":
    run_full_experiment(Path(__file__).resolve().parents[1] / "protocols" / "PRAYCG4_shotorder_four_branch_v1_0.json")
