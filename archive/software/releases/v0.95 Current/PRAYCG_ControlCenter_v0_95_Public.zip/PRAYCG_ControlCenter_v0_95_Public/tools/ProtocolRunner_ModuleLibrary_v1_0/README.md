# PRAYCG Protocol Runner Module Library v1.0

This library supplies three protocol-specific runner entry points over one shared PsychoPy/LSL engine. Control Center v0.94 discovers the JSON manifests, validates their structure, displays their fixed branch order, and writes a hash lock before launch.

## Included protocols

| Protocol | Fixed acquisition order | Runner entry point |
|---|---|---|
| PRAYCG3 v3.0 | PhaseScrambled Control → Target → Contextual Override | `scripts/run_PRAYCG3_OriginalThreeProng_v3_0.py` |
| PRAYCG4 v4.0 | PhaseScrambled Control → its washout/report → ShotOrderScramble → Target → Contextual Override | `scripts/run_PRAYCG4_ShotOrder_v4_0.py` |
| SMG v1.0 | Semantic-Zero → High-Meaning Target → Arithmetic Override | `scripts/run_SMG_SemanticMeaningGradient_v1_0.py` |

The PRAYCG3 sequence is intended to preserve the latest v0.92 three-prong runner behavior while moving the order and condition definitions into a versioned manifest. That is implementation continuity, not empirical proof of equivalence; a PsychoPy dry run and hardware acceptance test remain required before live acquisition.

## Lock and provenance model

Selection and locking are separate actions. A lock records:

- protocol ID and version;
- exact ordered branch list;
- SHA-256 of the protocol manifest;
- SHA-256 and path of the protocol-specific runner entry file;
- the protocol’s scientific-boundary statement.

Control Center refuses launch if the manifest, runner, identity, or branch order no longer matches the lock. The runner repeats the integrity check, snapshots the module into the run configuration, and writes the hashes into local events and LSL markers.

The lock prevents accidental configuration drift. It does not establish that the design is causally identified, that the stimulus manipulation succeeded, or that the acquisition hardware is valid.

## Protocol-aware media prefill

Control Center can pass unambiguous files from the selected stimulus folder into the runner GUI. Every value is still independently checked by the runner. Missing or ambiguous values stay unresolved.

SMG uses the distinct key `semantic_zero_video`; it will not silently reuse a phase-scrambled control. PRAYCG4 similarly requires a distinct `shot_order_video`. Target and Override must be bit-identical where declared by the module.

## Analysis compatibility

Native protocol phase markers are authoritative. Compatibility aliases are additional markers:

- SMG `SEMANTIC_ZERO_1` → canonical `CONTROL_1`;
- SMG `HIGH_MEANING_TARGET_1` → canonical `TARGET_1`;
- SMG `ARITHMETIC_OVERRIDE_1` → canonical `CONTEXTUAL_OVERRIDE_1`;
- the corresponding washouts map to `WASHOUT_1`, `WASHOUT_2`, and `WASHOUT_3`.

Aliases permit the current core analysis frame to segment the data, but they do not assert construct equivalence. Protocol-specific interpretation must use the native identity and module snapshot. PRAYCG4’s native `SHOT_ORDER_SCRAMBLE_1` and `SHOT_ORDER_WASHOUT_1` are retained by the bundled segment parser so HOC-R can inspect the structural-control branch.

## Scientific boundaries

- All three modules currently have a fixed order. Condition differences are therefore entangled with position, exposure, habituation, fatigue, and possible carryover unless a later design adds defensible counterbalancing or randomization.
- A washout interval is measured data, not proof that state has returned to baseline.
- A successful arithmetic response supports task engagement but does not prove that narrative processing was absent.
- ShotOrder preserves more local high-order content than PhaseScrambling, but transitions, audio treatment, familiarity, and residual low-level differences may remain.
- SMG indices and thresholds are proposed operationalizations. They are not validated instruments or diagnostic criteria.
- EEG/HRV/respiration agreement does not by itself establish consciousness, a quantum or metaphysical mechanism, clinical efficacy, or objective meaning.

See `docs/PROTOCOL_LIBRARY_METHOD_v0_94.md` at the package root for the fuller mathematical and methodological specification.
