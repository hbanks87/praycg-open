#!/usr/bin/env python3
"""Runner entry point for the conditional Semantic Meaning Gradient protocol."""
from pathlib import Path

from praycg_protocol_engine_v3_0 import run_full_experiment


if __name__ == "__main__":
    run_full_experiment(Path(__file__).resolve().parents[1] / "protocols" / "SMG_semantic_meaning_gradient_v1_0.json")
