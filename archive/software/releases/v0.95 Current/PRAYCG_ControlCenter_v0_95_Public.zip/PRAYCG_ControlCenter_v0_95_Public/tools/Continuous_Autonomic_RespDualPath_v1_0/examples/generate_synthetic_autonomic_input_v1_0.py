#!/usr/bin/env python3
"""Generate public-safe synthetic timing data for software validation only."""
from pathlib import Path

import numpy as np
import pandas as pd


root = Path(__file__).resolve().parent / "synthetic_input"
root.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(20260904)
beat_times = [0.0]
ibis = []
while beat_times[-1] < 300.0:
    midpoint = beat_times[-1]
    ibi = 900.0 + 45.0 * np.sin(2 * np.pi * midpoint / 10.0) + rng.normal(0.0, 12.0)
    ibis.append(ibi)
    beat_times.append(beat_times[-1] + ibi / 1000.0)
pd.DataFrame({"time_lsl": beat_times[:-1], "ibi_ms": ibis}).to_csv(root / "synthetic_cardiac_ibi.csv", index=False)

times = np.arange(0.0, 300.0, 0.04)
resp = np.sin(2 * np.pi * 0.20 * times) + 0.08 * rng.normal(size=len(times))
resp += 2.0 * np.exp(-0.5 * ((times - 155.0) / 1.0) ** 2)
pd.DataFrame({"time_lsl": times, "respiration": resp}).to_csv(root / "synthetic_respiration.csv", index=False)
print(root)
