# Continuous Autonomic Arrays / RespDualPath Validation Report

**Status:** PASS  
**Generated:** 2026-09-01T16:38:30.837117Z  
**Boundary:** Exploratory autonomic and respiration measurements; not a consciousness, meaning, diagnostic, or clinical measurement.

## Coverage

- Valid beat fraction: 1.000
- Cardiac display-grid coverage: 1.000
- RMSSD availability: 1.000
- SDNN availability: 1.000
- Respiration coverage: 1.000
- Respiration phase-valid coverage: 1.000

## Coupling

- Best HR-respiration correlation: 0.050153572411392594
- Best lag: 8.5 seconds
- Time-shift empirical diagnostic: 0.9104477611940298

The best-lag search is exploratory and multiplicity-sensitive. HRV was calculated from retained beat events, not the interpolated HR display grid. Respiration physiological events remain available even when their corresponding EEG interpretation receives an artifact caution.
