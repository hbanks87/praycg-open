#!/usr/bin/env python3
"""PRAYCG Continuous Autonomic Arrays and RespDualPath v1.0."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.signal import butter, find_peaks, hilbert, sosfiltfilt


VERSION = "1.0.0"
TOOL_ROOT = Path(__file__).resolve().parents[1]
TIME_ALIASES = ["time_lsl", "lsl_time", "timestamp", "time", "local_clock", "datetime_seconds"]
IBI_ALIASES = ["ibi_ms", "rr_ms", "rr_interval_ms", "ibi", "rr_interval", "rr"]
RESP_ALIASES = ["respiration", "resp", "force", "belt", "value", "sample", "resp_raw"]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def portable_path(path: Path) -> str:
    try:
        return "{AUTONOMIC_TOOL_ROOT}/" + str(path.resolve().relative_to(TOOL_ROOT)).replace("\\", "/")
    except (OSError, ValueError):
        return str(path.resolve())


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def first_column(frame: pd.DataFrame, candidates: Sequence[str]) -> Optional[str]:
    lower = {str(column).lower(): str(column) for column in frame.columns}
    for candidate in candidates:
        if candidate.lower() in lower:
            return lower[candidate.lower()]
    return None


def robust_z(values: Iterable[float]) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    finite = arr[np.isfinite(arr)]
    if not len(finite):
        return np.full(len(arr), np.nan)
    median = float(np.median(finite))
    mad = float(np.median(np.abs(finite - median)))
    scale = mad / 0.67448975 if mad > 0 else float(np.std(finite))
    if not np.isfinite(scale) or scale <= 0:
        return np.zeros(len(arr), dtype=float)
    return (arr - median) / scale


def monotonic_report(times: pd.Series) -> Dict[str, Any]:
    numeric = pd.to_numeric(times, errors="coerce").dropna().to_numpy(float)
    differences = np.diff(numeric)
    return {
        "valid_timestamps": int(len(numeric)),
        "nonmonotonic_count_input_order": int(np.sum(differences < 0)),
        "duplicate_count": int(np.sum(differences == 0)),
        "median_step_sec": float(np.median(differences[differences > 0])) if np.any(differences > 0) else None,
        "maximum_step_sec": float(np.max(differences)) if len(differences) else None,
    }


def load_cardiac(path: Path, config: Dict[str, Any]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    source = pd.read_csv(path)
    time_column = first_column(source, TIME_ALIASES)
    ibi_column = first_column(source, IBI_ALIASES)
    if not time_column or not ibi_column:
        raise ValueError(f"Cardiac CSV requires a time column {TIME_ALIASES} and an IBI/RR column {IBI_ALIASES}")
    report = monotonic_report(source[time_column])
    frame = pd.DataFrame({
        "beat_time_lsl": pd.to_numeric(source[time_column], errors="coerce"),
        "ibi_input": pd.to_numeric(source[ibi_column], errors="coerce"),
    }).dropna(subset=["beat_time_lsl"]).sort_values("beat_time_lsl", kind="mergesort").reset_index(drop=True)
    finite_ibi = frame["ibi_input"].dropna()
    ibi_units = "seconds_converted_to_ms" if len(finite_ibi) and float(finite_ibi.median()) < 10.0 else "milliseconds"
    frame["ibi_ms"] = frame["ibi_input"] * 1000.0 if ibi_units.startswith("seconds") else frame["ibi_input"]
    lower, upper = map(float, config["ibi_valid_ms"])
    frame["ibi_valid"] = frame["ibi_ms"].between(lower, upper, inclusive="both") & frame["ibi_ms"].notna()
    frame["ibi_correction_applied"] = False
    frame["ibi_exclusion_reason"] = np.where(frame["ibi_valid"], "", "outside_declared_range_or_missing")
    frame["ibi_valid_ms"] = frame["ibi_ms"].where(frame["ibi_valid"])
    frame["hr_instant_bpm"] = 60000.0 / frame["ibi_valid_ms"]
    frame["source_row"] = np.arange(len(frame), dtype=int)
    report.update({
        "source_path": portable_path(path),
        "source_sha256": sha256_file(path),
        "time_column": time_column,
        "ibi_column": ibi_column,
        "ibi_units": ibi_units,
        "beat_rows": int(len(frame)),
        "valid_beat_fraction": float(frame["ibi_valid"].mean()) if len(frame) else 0.0,
    })
    return frame, report


def interpolation_grid(times: np.ndarray, rate_hz: float) -> np.ndarray:
    finite = times[np.isfinite(times)]
    if len(finite) < 2:
        return np.array([], dtype=float)
    start = math.ceil(float(np.min(finite)) * rate_hz) / rate_hz
    end = math.floor(float(np.max(finite)) * rate_hz) / rate_hz
    return np.arange(start, end + 0.5 / rate_hz, 1.0 / rate_hz)


def interpolate_with_gap_flags(times: np.ndarray, values: np.ndarray, grid: np.ndarray, maximum_gap: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    valid = np.isfinite(times) & np.isfinite(values)
    source_t, source_x = times[valid], values[valid]
    if len(source_t) < 2 or not len(grid):
        return np.full(len(grid), np.nan), np.zeros(len(grid), dtype=bool), np.full(len(grid), np.nan)
    order = np.argsort(source_t)
    source_t, source_x = source_t[order], source_x[order]
    unique_t, unique_index = np.unique(source_t, return_index=True)
    source_t, source_x = unique_t, source_x[unique_index]
    interpolated = np.interp(grid, source_t, source_x)
    insertion = np.searchsorted(source_t, grid)
    left = np.clip(insertion - 1, 0, len(source_t) - 1)
    right = np.clip(insertion, 0, len(source_t) - 1)
    nearest_distance = np.minimum(np.abs(grid - source_t[left]), np.abs(source_t[right] - grid))
    surrounding_gap = np.abs(source_t[right] - source_t[left])
    usable = (nearest_distance <= maximum_gap) & (surrounding_gap <= 2.0 * maximum_gap)
    interpolated[~usable] = np.nan
    exact = nearest_distance < 1e-6
    return interpolated, usable & ~exact, nearest_distance


def build_cardiac_grid(beats: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    rate = float(config["grid_rate_hz"])
    grid = interpolation_grid(beats["beat_time_lsl"].to_numpy(float), rate)
    hr, interpolation_flag, nearest = interpolate_with_gap_flags(
        beats["beat_time_lsl"].to_numpy(float),
        beats["hr_instant_bpm"].to_numpy(float),
        grid,
        float(config["maximum_hr_interpolation_gap_sec"]),
    )
    return pd.DataFrame({
        "time_lsl": grid,
        "hr_display_bpm": hr,
        "interpolated": interpolation_flag,
        "nearest_valid_beat_distance_sec": nearest,
        "hr_display_valid": np.isfinite(hr),
        "hrv_source": "NOT_FROM_INTERPOLATED_GRID",
    })


def windowed_hrv(beats: pd.DataFrame, centers: np.ndarray, config: Dict[str, Any]) -> pd.DataFrame:
    times = beats["beat_time_lsl"].to_numpy(float)
    ibis = beats["ibi_valid_ms"].to_numpy(float)
    raw_valid = beats["ibi_valid"].to_numpy(bool)
    rmssd_window = float(config["rmssd_window_sec"])
    sdnn_window = float(config["sdnn_window_sec"])
    rows = []
    for center in centers:
        rm_mask_all = (times >= center - rmssd_window / 2.0) & (times <= center + rmssd_window / 2.0)
        rm_values = ibis[rm_mask_all & np.isfinite(ibis)]
        differences = np.diff(rm_values)
        rmssd = float(np.sqrt(np.mean(differences ** 2))) if len(differences) >= int(config["rmssd_minimum_valid_pairs"]) else math.nan
        sd_mask_all = (times >= center - sdnn_window / 2.0) & (times <= center + sdnn_window / 2.0)
        sd_values = ibis[sd_mask_all & np.isfinite(ibis)]
        sdnn = float(np.std(sd_values, ddof=1)) if len(sd_values) >= int(config["sdnn_minimum_valid_beats"]) else math.nan
        pnn50 = float(np.mean(np.abs(np.diff(sd_values)) > 50.0)) if len(sd_values) >= int(config["sdnn_minimum_valid_beats"]) else math.nan
        expected_rm = rmssd_window / (float(np.nanmedian(rm_values)) / 1000.0) if len(rm_values) and np.nanmedian(rm_values) > 0 else math.nan
        coverage = min(1.0, len(rm_values) / expected_rm) if np.isfinite(expected_rm) and expected_rm > 0 else math.nan
        considered = int(rm_mask_all.sum())
        correction_fraction = float(1.0 - raw_valid[rm_mask_all].mean()) if considered else math.nan
        rows.append({
            "time_lsl": center,
            "rmssd_30s_ms": rmssd,
            "rmssd_valid_pairs": int(len(differences)),
            "rmssd_window_coverage": coverage,
            "sdnn_60s_ms": sdnn,
            "pnn50_60s": pnn50,
            "sdnn_valid_beats": int(len(sd_values)),
            "ibi_exclusion_fraction_30s": correction_fraction,
        })
    return pd.DataFrame(rows)


def contiguous_events(mask: np.ndarray, times: np.ndarray, minimum_duration: float, event_type: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if not len(mask):
        return rows
    start: Optional[int] = None
    for index, active in enumerate(np.r_[mask, False]):
        if active and start is None:
            start = index
        elif not active and start is not None:
            end = index - 1
            duration = float(times[end] - times[start]) if end > start else 0.0
            if duration >= minimum_duration:
                rows.append({"event_type": event_type, "start_time_lsl": float(times[start]), "end_time_lsl": float(times[end]), "duration_sec": duration})
            start = None
    return rows


def load_respiration(path: Path, config: Dict[str, Any]) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    source = pd.read_csv(path)
    time_column = first_column(source, TIME_ALIASES)
    value_column = first_column(source, RESP_ALIASES)
    if not time_column or not value_column:
        raise ValueError(f"Respiration CSV requires a time column {TIME_ALIASES} and signal column {RESP_ALIASES}")
    report = monotonic_report(source[time_column])
    raw = pd.DataFrame({
        "time_lsl": pd.to_numeric(source[time_column], errors="coerce"),
        "respiration_raw": pd.to_numeric(source[value_column], errors="coerce"),
    }).dropna(subset=["time_lsl"]).sort_values("time_lsl", kind="mergesort").reset_index(drop=True)
    rate = float(config["grid_rate_hz"])
    grid = interpolation_grid(raw["time_lsl"].to_numpy(float), rate)
    respiration, interpolation_flag, nearest = interpolate_with_gap_flags(
        raw["time_lsl"].to_numpy(float),
        raw["respiration_raw"].to_numpy(float),
        grid,
        float(config["maximum_respiration_interpolation_gap_sec"]),
    )
    valid = np.isfinite(respiration)
    if valid.sum() < max(20, int(rate * 20)):
        raise ValueError("Respiration data do not contain enough valid samples for filtering")
    filled = respiration.copy()
    filled[~valid] = np.interp(grid[~valid], grid[valid], respiration[valid])
    low, high = map(float, config["respiration_band_hz"])
    sos = butter(int(config["respiration_filter_order"]), [low, high], btype="bandpass", fs=rate, output="sos")
    filtered = sosfiltfilt(sos, filled)
    analytic = hilbert(filtered)
    amplitude = np.abs(analytic)
    phase = np.unwrap(np.angle(analytic))
    amplitude_floor = max(float(np.nanmedian(amplitude)) * 0.20, 1e-12)
    velocity = np.gradient(filtered, 1.0 / rate)
    acceleration = np.gradient(velocity, 1.0 / rate)
    rate_bpm = np.gradient(phase, 1.0 / rate) * 60.0 / (2.0 * np.pi)
    rate_bpm = pd.Series(rate_bpm).rolling(max(3, int(rate * 5)), center=True, min_periods=3).median().to_numpy(float)
    rate_low, rate_high = map(float, config["respiration_rate_bpm_bounds"])
    rate_valid = (rate_bpm >= rate_low) & (rate_bpm <= rate_high)
    hold_candidate = valid & ((amplitude < amplitude_floor) | (np.abs(robust_z(velocity)) < 0.05))
    events = contiguous_events(hold_candidate, grid, float(config["hold_minimum_duration_sec"]), "BREATH_HOLD_CANDIDATE")
    hold_mask = np.zeros(len(grid), dtype=bool)
    for event in events:
        hold_mask |= (grid >= event["start_time_lsl"]) & (grid <= event["end_time_lsl"])
    phase_valid = valid & (amplitude >= amplitude_floor) & rate_valid & ~hold_mask
    phase_out = phase.copy()
    phase_out[~phase_valid] = np.nan
    rate_bpm[~phase_valid] = np.nan
    amplitude_z = robust_z(amplitude)
    peak_distance = max(1, int(rate * float(config["sigh_refractory_sec"])))
    peaks, _ = find_peaks(amplitude_z, height=float(config["sigh_robust_z_threshold"]), distance=peak_distance)
    for peak in peaks:
        if valid[peak]:
            events.append({
                "event_type": "SIGH_CANDIDATE",
                "start_time_lsl": float(grid[peak]),
                "end_time_lsl": float(grid[peak]),
                "duration_sec": 0.0,
                "amplitude_robust_z": float(amplitude_z[peak]),
            })
    motion_score = np.maximum(np.abs(robust_z(velocity)), np.abs(robust_z(acceleration)))
    motion_flag = motion_score > float(config["motion_robust_z_threshold"])
    frame = pd.DataFrame({
        "time_lsl": grid,
        "respiration_raw_interpolated": respiration,
        "interpolated": interpolation_flag,
        "nearest_source_distance_sec": nearest,
        "respiration_valid": valid,
        "respiration_filtered": filtered,
        "respiration_phase_rad": phase_out,
        "phase_valid": phase_valid,
        "respiration_rate_bpm": rate_bpm,
        "respiration_depth": 2.0 * amplitude,
        "respiration_depth_robust_z": amplitude_z,
        "respiration_velocity": velocity,
        "respiration_acceleration": acceleration,
        "hold_candidate": hold_mask,
        "sigh_candidate": False,
        "motion_artifact_score": motion_score,
        "respiration_artifact_caution": motion_flag,
    })
    if len(peaks):
        frame.loc[peaks, "sigh_candidate"] = True
    event_frame = pd.DataFrame(events)
    report.update({
        "source_path": portable_path(path),
        "source_sha256": sha256_file(path),
        "time_column": time_column,
        "signal_column": value_column,
        "source_rows": int(len(raw)),
        "grid_rows": int(len(frame)),
        "grid_valid_fraction": float(frame["respiration_valid"].mean()),
        "phase_valid_fraction": float(frame["phase_valid"].mean()),
        "sigh_candidate_count": int(frame["sigh_candidate"].sum()),
        "hold_candidate_count": int((event_frame.get("event_type", pd.Series(dtype=str)) == "BREATH_HOLD_CANDIDATE").sum()),
        "artifact_caution_fraction": float(frame["respiration_artifact_caution"].mean()),
        "filter": {"type": "Butterworth bandpass", "band_hz": [low, high], "order": int(config["respiration_filter_order"]), "application": "zero_phase_offline_sosfiltfilt"},
        "phase_amplitude_floor": amplitude_floor,
    })
    return frame, event_frame, report


def lagged_correlation(x: np.ndarray, y: np.ndarray, lag_samples: int) -> Tuple[float, int]:
    if lag_samples > 0:
        xx, yy = x[:-lag_samples], y[lag_samples:]
    elif lag_samples < 0:
        xx, yy = x[-lag_samples:], y[:lag_samples]
    else:
        xx, yy = x, y
    valid = np.isfinite(xx) & np.isfinite(yy)
    if valid.sum() < 10 or np.std(xx[valid]) <= 1e-12 or np.std(yy[valid]) <= 1e-12:
        return math.nan, int(valid.sum())
    return float(np.corrcoef(xx[valid], yy[valid])[0, 1]), int(valid.sum())


def best_lag_correlation(x: np.ndarray, y: np.ndarray, lags: np.ndarray, rate: float) -> Tuple[float, float, int]:
    candidates = []
    for lag in lags:
        corr, n = lagged_correlation(x, y, int(round(lag * rate)))
        if np.isfinite(corr):
            candidates.append((abs(corr), corr, float(lag), n))
    if not candidates:
        return math.nan, math.nan, 0
    _, corr, lag, n = max(candidates, key=lambda item: item[0])
    return corr, lag, n


def coupling_analysis(cardiac_grid: pd.DataFrame, respiration: pd.DataFrame, config: Dict[str, Any]) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
    rate = float(config["grid_rate_hz"])
    start = max(float(cardiac_grid["time_lsl"].min()), float(respiration["time_lsl"].min()))
    end = min(float(cardiac_grid["time_lsl"].max()), float(respiration["time_lsl"].max()))
    grid = np.arange(math.ceil(start * rate) / rate, math.floor(end * rate) / rate + 0.5 / rate, 1.0 / rate)
    if len(grid) < int(rate * 30):
        return pd.DataFrame(), pd.DataFrame(), {"status": "UNAVAILABLE", "reason": "less than 30 seconds overlap"}
    hr = np.interp(grid, cardiac_grid["time_lsl"], cardiac_grid["hr_display_bpm"])
    resp = np.interp(grid, respiration["time_lsl"], respiration["respiration_filtered"])
    hr_valid = np.interp(grid, cardiac_grid["time_lsl"], cardiac_grid["hr_display_valid"].astype(float)) > 0.5
    resp_valid = np.interp(grid, respiration["time_lsl"], respiration["respiration_valid"].astype(float)) > 0.5
    hr[~hr_valid] = np.nan
    resp[~resp_valid] = np.nan
    lag_low, lag_high = map(float, config["coupling_lag_range_sec"])
    lags = np.arange(lag_low, lag_high + float(config["coupling_lag_step_sec"]) / 2.0, float(config["coupling_lag_step_sec"]))
    centers = np.arange(math.ceil(start), math.floor(end) + 1.0, 1.0)
    half = float(config["coupling_window_sec"]) / 2.0
    rows = []
    for center in centers:
        mask = (grid >= center - half) & (grid <= center + half)
        coverage = float(np.mean(np.isfinite(hr[mask]) & np.isfinite(resp[mask]))) if mask.any() else 0.0
        if coverage >= float(config["coupling_minimum_coverage"]):
            corr, lag, n = best_lag_correlation(hr[mask], resp[mask], lags, rate)
        else:
            corr, lag, n = math.nan, math.nan, 0
        rows.append({"time_lsl": center, "hr_resp_best_correlation": corr, "hr_resp_best_lag_sec": lag, "coupling_pair_count": n, "coupling_coverage": coverage})
    windows = pd.DataFrame(rows)
    observed_corr, observed_lag, observed_n = best_lag_correlation(hr, resp, lags, rate)
    rng = np.random.default_rng(int(config["seed"]))
    minimum_shift = int(round(float(config["coupling_minimum_shift_sec"]) * rate))
    null_rows = []
    for replicate in range(1, int(config["coupling_time_shift_replicates"]) + 1):
        if len(resp) > 2 * minimum_shift:
            shift = int(rng.integers(minimum_shift, len(resp) - minimum_shift + 1))
        else:
            shift = max(1, len(resp) // 2)
        shifted = np.roll(resp, shift)
        corr, lag, n = best_lag_correlation(hr, shifted, lags, rate)
        null_rows.append({"replicate": replicate, "circular_shift_samples": shift, "best_correlation": corr, "best_lag_sec": lag, "pair_count": n})
    nulls = pd.DataFrame(null_rows)
    finite_null = nulls["best_correlation"].abs().dropna().to_numpy(float)
    empirical_p = (1.0 + float(np.sum(finite_null >= abs(observed_corr)))) / (1.0 + len(finite_null)) if len(finite_null) and np.isfinite(observed_corr) else math.nan
    summary = {
        "status": "AVAILABLE" if np.isfinite(observed_corr) else "UNAVAILABLE",
        "overlap_start": start,
        "overlap_end": end,
        "observed_best_correlation": observed_corr,
        "observed_best_lag_sec": observed_lag,
        "observed_pair_count": observed_n,
        "time_shift_replicates": int(len(nulls)),
        "absolute_correlation_upper_tail_empirical_p": empirical_p,
        "boundary": "Exploratory best-lag search with multiplicity caution; not a participant-level significance test.",
    }
    return windows, nulls, summary


def discover_inputs(run_folder: Path) -> Tuple[Optional[Path], Optional[Path]]:
    cardiac: List[Tuple[int, Path]] = []
    respiration: List[Tuple[int, Path]] = []
    for path in run_folder.rglob("*.csv"):
        try:
            sample = pd.read_csv(path, nrows=5)
        except Exception:
            continue
        name = path.name.lower()
        if first_column(sample, TIME_ALIASES) and first_column(sample, IBI_ALIASES):
            cardiac.append((10 + sum(token in name for token in ["polar", "rr", "ibi", "cardiac"]), path))
        if first_column(sample, TIME_ALIASES) and first_column(sample, RESP_ALIASES):
            respiration.append((10 + sum(token in name for token in ["vernier", "resp", "belt"]), path))
    cardiac_path = max(cardiac, default=(0, None), key=lambda item: item[0])[1]
    respiration_path = max(respiration, default=(0, None), key=lambda item: item[0])[1]
    return cardiac_path, respiration_path


def analyze(cardiac_csv: Path, respiration_csv: Path, out_dir: Path, config_path: Path) -> Dict[str, Path]:
    config = load_json(config_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    beats, cardiac_qc = load_cardiac(cardiac_csv, config)
    cardiac_grid = build_cardiac_grid(beats, config)
    respiration, events, respiration_qc = load_respiration(respiration_csv, config)
    overlap_start = max(float(beats["beat_time_lsl"].min()), float(respiration["time_lsl"].min()))
    overlap_end = min(float(beats["beat_time_lsl"].max()), float(respiration["time_lsl"].max()))
    centers = np.arange(math.ceil(overlap_start), math.floor(overlap_end) + 1.0, 1.0)
    hrv = windowed_hrv(beats, centers, config)
    coupling, nulls, coupling_qc = coupling_analysis(cardiac_grid, respiration, config)
    physiology = hrv.copy()
    if len(centers):
        for column in ["respiration_rate_bpm", "respiration_depth", "phase_valid", "respiration_artifact_caution"]:
            values = np.interp(centers, respiration["time_lsl"], respiration[column].astype(float))
            if column == "phase_valid":
                values = values > 0.5
            physiology[column] = values
    if not coupling.empty:
        physiology = physiology.merge(coupling, on="time_lsl", how="left")
    physiology["autonomic_measurement_valid"] = physiology["rmssd_30s_ms"].notna() & physiology["respiration_rate_bpm"].notna()
    artifact_path = respiration[["time_lsl", "respiration_velocity", "respiration_acceleration", "hold_candidate", "sigh_candidate", "motion_artifact_score", "respiration_artifact_caution"]].copy()

    valid_beat_fraction = float(cardiac_qc["valid_beat_fraction"])
    resp_valid_fraction = float(respiration_qc["grid_valid_fraction"])
    if valid_beat_fraction >= 0.90 and resp_valid_fraction >= 0.90 and coupling_qc.get("status") == "AVAILABLE":
        status = "PASS"
    elif valid_beat_fraction >= 0.50 and resp_valid_fraction >= 0.50:
        status = "CAUTION"
    else:
        status = "INELIGIBLE"
    qc = {
        "schema": "PRAYCG_ContinuousAutonomic_QC_v1_0",
        "created_utc": utc_now(),
        "version": VERSION,
        "status": status,
        "claim_boundary": config["claim_boundary"],
        "cardiac": cardiac_qc,
        "respiration": respiration_qc,
        "coupling": coupling_qc,
        "coverage": {
            "cardiac_grid_valid_fraction": float(cardiac_grid["hr_display_valid"].mean()) if len(cardiac_grid) else 0.0,
            "rmssd_available_fraction": float(physiology["rmssd_30s_ms"].notna().mean()) if len(physiology) else 0.0,
            "sdnn_available_fraction": float(physiology["sdnn_60s_ms"].notna().mean()) if len(physiology) else 0.0,
            "respiration_valid_fraction": resp_valid_fraction,
            "phase_valid_fraction": float(respiration_qc["phase_valid_fraction"]),
        },
        "primary_cai_integration": "PROHIBITED_IN_V1_0; outputs remain a separate convergence and artifact layer",
    }
    paths = {
        "beats": out_dir / "cardiac_beats.csv",
        "cardiac_grid": out_dir / "cardiac_grid_4hz.csv",
        "respiration_grid": out_dir / "respiration_grid_4hz.csv",
        "windows": out_dir / "autonomic_windows_1hz.csv",
        "physiology": out_dir / "autonomic_physiology_path_1hz.csv",
        "artifact": out_dir / "respiration_artifact_path_4hz.csv",
        "events": out_dir / "respiration_events.csv",
        "nulls": out_dir / "coupling_time_shift_null.csv",
        "qc": out_dir / "autonomic_qc.json",
        "report": out_dir / "AUTONOMIC_VALIDATION_REPORT.md",
    }
    beats.to_csv(paths["beats"], index=False)
    cardiac_grid.to_csv(paths["cardiac_grid"], index=False)
    respiration.to_csv(paths["respiration_grid"], index=False)
    physiology.to_csv(paths["windows"], index=False)
    physiology.to_csv(paths["physiology"], index=False)
    artifact_path.to_csv(paths["artifact"], index=False)
    events.to_csv(paths["events"], index=False)
    nulls.to_csv(paths["nulls"], index=False)
    paths["qc"].write_text(json.dumps(qc, indent=2), encoding="utf-8")
    report = [
        "# Continuous Autonomic Arrays / RespDualPath Validation Report",
        "",
        f"**Status:** {status}  ",
        f"**Generated:** {qc['created_utc']}  ",
        f"**Boundary:** {config['claim_boundary']}",
        "",
        "## Coverage",
        "",
        f"- Valid beat fraction: {valid_beat_fraction:.3f}",
        f"- Cardiac display-grid coverage: {qc['coverage']['cardiac_grid_valid_fraction']:.3f}",
        f"- RMSSD availability: {qc['coverage']['rmssd_available_fraction']:.3f}",
        f"- SDNN availability: {qc['coverage']['sdnn_available_fraction']:.3f}",
        f"- Respiration coverage: {resp_valid_fraction:.3f}",
        f"- Respiration phase-valid coverage: {qc['coverage']['phase_valid_fraction']:.3f}",
        "",
        "## Coupling",
        "",
        f"- Best HR-respiration correlation: {coupling_qc.get('observed_best_correlation')}",
        f"- Best lag: {coupling_qc.get('observed_best_lag_sec')} seconds",
        f"- Time-shift empirical diagnostic: {coupling_qc.get('absolute_correlation_upper_tail_empirical_p')}",
        "",
        "The best-lag search is exploratory and multiplicity-sensitive. HRV was calculated from retained beat events, not the interpolated HR display grid. Respiration physiological events remain available even when their corresponding EEG interpretation receives an artifact caution.",
    ]
    paths["report"].write_text("\n".join(report) + "\n", encoding="utf-8")
    return paths


def launch_gui(run_folder: Optional[Path], config_path: Path) -> int:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    class App(tk.Tk):
        def __init__(self):
            super().__init__()
            self.title("PRAYCG Continuous Autonomic / RespDualPath v1.0 - Exploratory")
            self.geometry("900x570")
            self.run_var = tk.StringVar(value=str(run_folder or ""))
            self.card_var = tk.StringVar()
            self.resp_var = tk.StringVar()
            default_out = (run_folder / "analysis" / "continuous_autonomic_v1_0") if run_folder else Path.cwd() / "continuous_autonomic_v1_0_output"
            self.out_var = tk.StringVar(value=str(default_out))
            ttk.Label(self, text="Continuous Autonomic Arrays / RespDualPath v1.0", font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=10, pady=(10, 2))
            ttk.Label(self, text="Exploratory physiology and artifact paths. Outputs do not enter primary CAI.", foreground="#7a1f1f").pack(anchor="w", padx=10, pady=(0, 8))
            for label, var, folder in [("Run folder", self.run_var, True), ("Cardiac beat/IBI CSV", self.card_var, False), ("Respiration CSV", self.resp_var, False), ("Output folder", self.out_var, True)]:
                row = ttk.Frame(self); row.pack(fill="x", padx=10, pady=3)
                ttk.Label(row, text=label, width=24).pack(side="left")
                ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=4)
                def browse(target=var, choose_folder=folder):
                    value = filedialog.askdirectory() if choose_folder else filedialog.askopenfilename(filetypes=[("CSV", "*.csv"), ("All", "*.*")])
                    if value: target.set(value)
                ttk.Button(row, text="Browse", command=browse).pack(side="left")
            actions = ttk.Frame(self); actions.pack(fill="x", padx=10, pady=8)
            ttk.Button(actions, text="Discover Inputs", command=self.discover).pack(side="left", padx=3)
            ttk.Button(actions, text="Run Autonomic Analysis", command=self.run_analysis).pack(side="left", padx=3)
            ttk.Button(actions, text="Open Output", command=self.open_output).pack(side="left", padx=3)
            self.text = tk.Text(self, wrap="word"); self.text.pack(fill="both", expand=True, padx=10, pady=8)
            if run_folder:
                self.after(150, self.discover)

        def discover(self):
            folder = Path(self.run_var.get())
            if not folder.is_dir():
                messagebox.showwarning("Run folder", "Choose an existing run folder first.")
                return
            cardiac, respiration = discover_inputs(folder)
            if cardiac: self.card_var.set(str(cardiac))
            if respiration: self.resp_var.set(str(respiration))
            self.text.insert("end", f"Cardiac: {cardiac or 'not found'}\nRespiration: {respiration or 'not found'}\n")

        def run_analysis(self):
            cardiac, respiration, out = Path(self.card_var.get()), Path(self.resp_var.get()), Path(self.out_var.get())
            if not cardiac.is_file() or not respiration.is_file():
                messagebox.showerror("Inputs missing", "Select valid cardiac and respiration CSV files.")
                return
            self.text.insert("end", "Running...\n"); self.update_idletasks()
            def worker():
                try:
                    paths = analyze(cardiac, respiration, out, config_path)
                    self.after(0, lambda: self.text.insert("end", "Complete:\n" + "\n".join(str(value) for value in paths.values()) + "\n"))
                except Exception as exc:
                    self.after(0, lambda: messagebox.showerror("Autonomic analysis failed", str(exc)))
            threading.Thread(target=worker, daemon=True).start()

        def open_output(self):
            path = Path(self.out_var.get())
            path.mkdir(parents=True, exist_ok=True)
            if os.name == "nt": os.startfile(str(path))
            else: messagebox.showinfo("Output", str(path))

    App().mainloop()
    return 0


def main() -> int:
    script_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--gui", action="store_true")
    parser.add_argument("--run-folder", type=Path)
    parser.add_argument("--cardiac-csv", type=Path)
    parser.add_argument("--respiration-csv", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--config", type=Path, default=script_root / "config" / "autonomic_config_v1_0.json")
    args = parser.parse_args()
    if args.gui:
        return launch_gui(args.run_folder, args.config.resolve())
    cardiac, respiration = args.cardiac_csv, args.respiration_csv
    if args.run_folder and (not cardiac or not respiration):
        found_cardiac, found_respiration = discover_inputs(args.run_folder)
        cardiac = cardiac or found_cardiac
        respiration = respiration or found_respiration
    if not cardiac or not respiration or not args.out:
        parser.error("--cardiac-csv, --respiration-csv, and --out are required outside GUI mode")
    paths = analyze(cardiac.resolve(), respiration.resolve(), args.out.resolve(), args.config.resolve())
    print(json.dumps({key: str(value) for key, value in paths.items()}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
