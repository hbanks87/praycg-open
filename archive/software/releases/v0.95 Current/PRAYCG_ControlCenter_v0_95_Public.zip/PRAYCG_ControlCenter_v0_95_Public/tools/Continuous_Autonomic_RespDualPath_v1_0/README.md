# Continuous Autonomic Arrays and RespDualPath v1.0

This exploratory module converts Polar-style beat/IBI events and Vernier-style respiration samples into synchronized continuous arrays while preserving quality, interpolation, and artifact flags.

It produces:

- `cardiac_beats.csv`
- `cardiac_grid_4hz.csv`
- `respiration_grid_4hz.csv`
- `autonomic_windows_1hz.csv`
- `autonomic_physiology_path_1hz.csv`
- `respiration_artifact_path_4hz.csv`
- `respiration_events.csv`
- `coupling_time_shift_null.csv`
- `autonomic_qc.json`
- `AUTONOMIC_VALIDATION_REPORT.md`

The module does not feed condition-coded autonomic values into primary CAI. Interpolated HR is marked explicitly and is never used to manufacture HRV observations. HRV is calculated only from retained valid beat events.

Launch the GUI:

```text
python scripts/praycg_continuous_autonomic_v1_0.py --gui --run-folder C:/path/to/run
```

Or run directly:

```text
python scripts/praycg_continuous_autonomic_v1_0.py --cardiac-csv cardiac.csv --respiration-csv respiration.csv --out output_folder
```

Boundary: exploratory autonomic and respiration measurements; not a consciousness, meaning, diagnostic, or clinical measurement.

