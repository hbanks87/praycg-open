# PRAYCG2.2 Confound Expansion Method v1.5.7

This module update adds five confound-aware interpretation modules to the Master Comprehensive Analysis Suite. These modules do not replace A-MRED, MRED-Peak, or MRED-Resolution. They exist to prevent overinterpretation of apparent Target > Control, Target > Override, or Baseline2 effects.

## Claim boundary

The confound expansion layer does not certify meaning, consciousness, OSM biology, memory formation, or literal thermodynamic mechanism. It asks whether a PRAYCG run remains interpretable after considering high-order visual/social structure, cue-driven spatial attention, fixed-order habituation, afterglow/task-relief ambiguity, and respiration as both artifact and state signal.

## Added modules

### HOC-R_v0.1 — High-Order Control Residualization

Problem addressed: a phase-scrambled Control is a sensory-control branch, not a perfect meaning-null branch. Phase scrambling can destroy faces, object structure, biological motion, and scene layout. Target > Control can therefore reflect high-order visual/social structure, not narrative reception alone.

Primary outputs:

```text
hocr_high_order_control_residualization.csv
```

Interpretation rule:

```text
If face/body/object/AOI regressors are missing, Target > Control must remain high-order-control-cautioned.
```

Recommended future fixes:

```text
shot-order scramble
face-preserved/dialogue-damaged control
non-narrative human-control
face/body/object/AOI regressors in StimulusFingerprint
```

### OSA_v0.1 — Override Spatial Attention / AOI Burden

Problem addressed: the Contextual Override task uses fixed upper-right number cues. Even if Target and Override are bit-identical, visual sampling is not identical. The participant may monitor the cue region rather than the face/action region.

Primary outputs:

```text
osa_override_spatial_attention.csv
```

Interpretation rule:

```text
Target > Override is not pure task-theft if gaze/AOI is unobserved and cue burden is high.
```

Recommended future fixes:

```text
eye tracking
webcam gaze proxy
manual AOI annotations
Cue-Monitor control condition: same video + cue monitoring, no arithmetic
```

### OHC_v0.1 — Order / Habituation / Carryover

Problem addressed: the default sequence Control -> Target -> Override means Override is later in the run and may be affected by repetition suppression, fatigue, or cumulative carryover. A 120-second washout is an after-state measurement, not a full biological reset.

Primary outputs:

```text
ohc_order_habituation_carryover.csv
```

Interpretation rule:

```text
Fixed-order self-runs are exploratory unless branch order is counterbalanced in a future cohort.
```

### AAM_v0.1 — Afterglow Attribution Model

Problem addressed: Baseline2 can reflect narrative afterglow, task-completion relief, fatigue, respiration, and cumulative exposure. It should not be attributed to Target alone.

Primary outputs:

```text
aam_afterglow_attribution.csv
```

Key quantities:

```text
NAI  = Narrative Afterglow Index
TCRI = Task Completion Relief Index
AAM  = NAI - TCRI
```

Interpretation:

```text
AAM > 0: more Target-afterglow-like
AAM < 0: more task-relief-like
AAM near zero: mixed or ambiguous
```

### RespDualPath_v0.1 — Respiratory Artifact / State-Event Split

Problem addressed: a deep breath or sigh can be a valid emotional/autonomic event and also an EEG/HRV confound.

Primary outputs:

```text
resp_dual_path_events.csv
resp_dual_path_summary.csv
```

Interpretation rule:

```text
Preserve respiratory events as state signals.
Penalize clean EEG claims if respiratory events overlap artifact-sensitive windows.
```

## How to run

Command line:

```bat
py -3.11 scripts\praycg_confound_expanded_modules_v1_5_7.py ^
  --analysis-folder "C:\path\to\MasterComprehensiveOutput" ^
  --stimulus-fingerprint-folder "C:\path\to\MediaPrepOutput\qc" ^
  --run-log-folder "C:\path\to\PRAYCG2_0_run_logs"
```

GUI:

```bat
py -3.11 scripts\praycg_confound_expanded_modules_v1_5_7.py --gui
```

From Control Center v0.92:

```text
Analysis tab -> Run Confound Expansion Modules
```

## Outputs

```text
tables/confound_expanded_branch_report_inputs.csv
tables/hocr_high_order_control_residualization.csv
tables/osa_override_spatial_attention.csv
tables/ohc_order_habituation_carryover.csv
tables/aam_afterglow_attribution.csv
tables/resp_dual_path_events.csv
tables/resp_dual_path_summary.csv
tables/confound_expanded_module_summary.csv
tables/confound_expanded_visual_overlay.csv
tables/confound_expanded_interpretation.json
reports/confound_expanded_module_report_v1_5_7.md
```

## Recommended public wording

Use this:

> PRAYCG’s phase-scrambled control is a meaning-damaged sensory control, not a perfect meaning-null condition. The v1.5.7 confound expansion layer explicitly audits high-order visual structure, cue-driven spatial attention, fixed-order habituation, afterglow attribution, and respiration dual-path effects before interpreting candidate endpoints.

Do not use this:

> Target > Control proves meaning.
> Target > Override proves thermodynamic theft.
> Baseline2 proves narrative afterglow.
