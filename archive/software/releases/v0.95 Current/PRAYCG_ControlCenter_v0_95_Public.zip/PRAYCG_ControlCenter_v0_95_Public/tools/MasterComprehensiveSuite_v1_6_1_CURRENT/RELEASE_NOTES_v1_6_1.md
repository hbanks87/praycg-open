# Master Comprehensive Suite v1.6.1 Release Notes

The v1.6.0 canonical analysis frame and endpoint calculations are retained. v1.6.1 updates the chained review and interpretation layer.

## v1.6.1 artifact and interpretation controls

- Adds `PRAYCG_AnalysisArtifactIndex_v1_0`, using registered exact filenames, hashes, selected canonical paths, duplicate warnings, run eligibility, and module-status provenance.
- Writes a preliminary chain manifest before interpretation and refreshes the manifest and artifact index after all modules finish.
- Updates the chain to Offline Interpreter v1.6.0, which creates a structured evidence ledger before producing technical, research, and public-safe reports.
- Adds optional cross-run canonical-schema, condition-set, eligibility, and software-version comparison without automatic effect pooling.
- Prevents failed, missing-input, non-applicable, and software-error modules from being interpreted merely because a partial or stale table exists.
- Adds MasterSync Visualizer v1.4.0 with an interactive timeline, event provenance, HOC-R branch review, gate ribbon, raw/robust scaling, coverage labels, and cancellable background MP4 rendering.

## Inherited v1.6.0 core analysis changes

## Reliability and provenance

- Introduces the canonical `PRAYCG_AnalysisFrame_v1_6_0` table and schema JSON so chained modules consume one documented, non-overlapping frame.
- Excludes overlapping stimulus-style/washout subwindows from that canonical frame to prevent duplicate statistical weighting.
- Preserves unavailable measurements as `NaN`; absent physiology is not converted into a favorable zero.
- Records suite, schema, Python, NumPy, pandas, and SciPy versions in the run manifest.
- Writes explicit HRV stream-selection provenance and rejects respiration-identified candidates.

## Acquisition and spectral gates

- Adds run eligibility based on required phases, EEG coverage, effective sample rate, nominal-rate deviation, and maximum timestamp gap.
- Keeps pre-QC endpoint results but changes strict endpoint status to QC-blocked/exploratory when run eligibility fails.
- Reports high-frequency bands as unavailable when their upper edge is too close to or above the data Nyquist limit.
- Adds time-aligned raw respiration-window features for RespDualPath.

## Baseline 2 and recovery

- Treats `BASELINE_2_REFLECTION` as a distinct recovery segment when it is present.
- Exports Baseline 1 versus Baseline 2 feature and autonomic/respiration deltas.
- Reports Baseline 2 absence explicitly rather than silently substituting a washout or zero.

## Chained modules

- Adds a dependency-aware runner with a new workspace per execution.
- Standardizes module outcomes as pass, primary-gate failure, missing input, protocol-not-applicable, exploratory-only, or software error.
- Prevents MRED-ITP from deleting or writing over its inputs and refuses non-empty output locations.
- Prevents NUPI from selecting similarly named non-CII tables.
- Makes A-MRED respect the core run-QC gate.
- Handles empty anchor tables, absent optional columns, unavailable optional visual penalties, and missing `tabulate` without runtime crashes.

## Validation performed for this build

- All shipped Python entry points compile.
- Five focused unit regressions pass.
- A real Arrival XDF/event run completed with 1,389 canonical rows, validated Polar HRV selection, window-aligned Vernier respiration, strict run eligibility `PASS`, and zero core errors.
- The complete chained run finished with zero `SOFTWARE_ERROR` statuses. Missing anchors were reported as not gradable, the absent ShotOrder branch as not applicable, and ALS timing as a primary-gate failure rather than a software failure.

The validation run and source participant data are not included in the public ZIP.
