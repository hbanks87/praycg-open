#!/usr/bin/env python3
"""Dependency-aware PRAYCG Master Comprehensive Suite v1.6.1 chain runner."""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import shutil
import subprocess
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from praycg_artifact_index_v1_0 import build_artifact_index

HERE = Path(__file__).resolve().parent
VERSION = "1.6.1"


def read_json(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except Exception:
        return {}


def first_existing(paths: Iterable[Path]) -> Optional[Path]:
    for path in paths:
        if path and path.is_file():
            return path.resolve()
    return None


def configured_path(config: Dict[str, Any], key: str) -> Optional[Path]:
    raw = str(config.get("config", config).get(key, "") or "").strip()
    if not raw:
        return None
    path = Path(raw).expanduser()
    return path.resolve() if path.is_file() else None


def copy_inputs(core: Path, workspace: Path) -> None:
    tables = workspace / "tables"
    tables.mkdir(parents=True, exist_ok=False)
    names = [
        "praycg_analysis_frame_v1_6_0.csv",
        "praycg_analysis_frame_v1_6_0.schema.json",
        "run_eligibility.json",
        "run_eligibility_phase_coverage.csv",
        "baseline1_vs_baseline2_feature_summary.csv",
        "baseline1_vs_baseline2_polar_respiration_summary.csv",
        "mred_event_table.csv",
        "candidate_local_kht_analysis.csv",
        "candidate_local_kht_anchor_manifest.csv",
        "events_used.csv",
        "stream_inventory.csv",
        "self_report_ratings_wide.csv",
        "self_report_ratings_long.csv",
        "respiration_segment_summary.csv",
        "hrv_api_segment_summary.csv",
        "hrv_stream_selection.json",
    ]
    for name in names:
        source = core / "tables" / name
        if source.is_file():
            shutil.copy2(source, tables / name)
    for name in ["manifest.json"]:
        source = core / name
        if source.is_file():
            shutil.copy2(source, workspace / name)
    cfg = core / "config" / "run_config.json"
    if cfg.is_file():
        (workspace / "config").mkdir(exist_ok=True)
        shutil.copy2(cfg, workspace / "config" / cfg.name)


def publish_tables(module_dir: Path, workspace_tables: Path) -> None:
    if not module_dir.exists():
        return
    for path in module_dir.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".csv", ".json"}:
            dest = workspace_tables / path.name
            if path.resolve() != dest.resolve():
                shutil.copy2(path, dest)


def write_status(module_dir: Path, payload: Dict[str, Any]) -> None:
    module_dir.mkdir(parents=True, exist_ok=True)
    (module_dir / "module_status.json").write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def run_task(name: str, cmd: List[str], root: Path, output_dir: Path, records: List[Dict[str, Any]], missing: Optional[List[str]] = None) -> Dict[str, Any]:
    if missing:
        payload = {"module": name, "status": "NOT_GRADABLE_MISSING_INPUT", "message": "Required inputs are missing.", "missing": missing, "command": cmd}
        write_status(output_dir, payload)
        records.append(payload)
        return payload
    log_dir = root / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / f"{name}.log"
    env = os.environ.copy()
    env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    started = dt.datetime.now(dt.timezone.utc)
    try:
        completed = subprocess.run(cmd, cwd=str(HERE), env=env, text=True, encoding="utf-8", errors="replace", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
        log_path.write_text(completed.stdout or "", encoding="utf-8")
        if completed.returncode:
            status = "SOFTWARE_ERROR"
            message = f"Module exited with code {completed.returncode}."
        else:
            status = "EXPLORATORY_ONLY"
            message = "Module completed; inspect its scientific gate status."
        payload = {
            "module": name,
            "status": status,
            "message": message,
            "return_code": completed.returncode,
            "started_utc": started.isoformat(),
            "ended_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
            "command": cmd,
            "log": str(log_path),
            "output_dir": str(output_dir),
        }
    except Exception as exc:
        log_path.write_text(traceback.format_exc(), encoding="utf-8")
        payload = {"module": name, "status": "SOFTWARE_ERROR", "message": str(exc), "command": cmd, "log": str(log_path), "output_dir": str(output_dir)}
    write_status(output_dir, payload)
    records.append(payload)
    return payload


def refine_status(record: Dict[str, Any], module_dir: Path, eligibility: Dict[str, Any]) -> None:
    if record.get("status") in {"SOFTWARE_ERROR", "NOT_GRADABLE_MISSING_INPUT"}:
        return
    name = record["module"]
    if name == "amred":
        summary = read_json(module_dir / "amred_primary_endpoint_summary.json")
        if not summary:
            summary = read_json(module_dir / "amred_interpretation.json")
        n = int(summary.get("n_strict_amred_pass", 0) or 0)
        if n > 0 and bool(eligibility.get("strict_interpretation_allowed", False)):
            record.update(status="PASS", message=f"{n} strict A-MRED anchor(s) passed all available gates.")
        elif summary.get("status") == "NO_ANCHORS":
            record.update(status="NOT_GRADABLE_MISSING_INPUT", message="No predeclared anchor file was available.")
        else:
            record.update(status="FAIL_PRIMARY_GATE", message="No strict A-MRED anchor passed.")
    elif name == "als_barcode":
        reports = list(module_dir.rglob("als_barcode_detection_report.json"))
        report = read_json(reports[0]) if reports else {}
        grade = str(report.get("timing_grade", ""))
        record.update(status="PASS" if grade.startswith("TIMING_GRADE_PASS") else "FAIL_PRIMARY_GATE", message=f"ALS timing grade: {grade or 'not returned'}")
    elif name == "shotorder_hocr":
        reports = list(module_dir.rglob("hocr_shotorder_interpretation.json"))
        report = read_json(reports[0]) if reports else {}
        if not report.get("shot_order_present", False):
            record.update(status="NOT_APPLICABLE_PROTOCOL", message="No ShotOrderScramble branch was detected.")
    elif name in {"nip_cet_eet", "nupi"}:
        candidates = list(module_dir.rglob("*interpretation.json"))
        report = read_json(candidates[0]) if candidates else {}
        returned = str(report.get("status", ""))
        if returned in {"NOT_GRADABLE_MISSING_INPUT", "FAIL_PRIMARY_GATE", "PASS", "EXPLORATORY_ONLY"}:
            record["status"] = returned
            record["message"] = f"Module returned {returned}."
    write_status(module_dir, record)


def command(script: str, *args: Any) -> List[str]:
    return [sys.executable, str(HERE / script)] + [str(arg) for arg in args if str(arg) != ""]


def publish_chain_state(root: Path, core: Path, records: List[Dict[str, Any]], eligibility: Dict[str, Any]) -> Dict[str, Any]:
    """Write an authoritative state before and after interpretation.

    The Interpreter can therefore consume module gates instead of attempting to
    infer them from whichever result tables happen to exist.
    """
    matrix = root / "chain_execution_matrix.csv"
    keys = sorted({key for row in records for key in row})
    with matrix.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys)
        writer.writeheader()
        for row in records:
            writer.writerow({key: json.dumps(value) if isinstance(value, (dict, list)) else value for key, value in row.items()})
    summary = {
        "schema": "PRAYCG_ChainManifest_v1_6_1",
        "suite_version": VERSION,
        "analysis_frame_schema": "PRAYCG_AnalysisFrame_v1_6_0",
        "core_analysis_folder": str(core),
        "output_folder": str(root),
        "run_eligibility": eligibility,
        "status_counts": {status: sum(1 for row in records if row.get("status") == status) for status in sorted({str(row.get("status")) for row in records})},
        "modules": records,
        "rule": "Software errors, missing-input states, protocol non-applicability, primary-gate failures, and exploratory completions are distinct outcomes.",
    }
    (root / "chain_manifest.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")
    return summary


def run_chain(args: argparse.Namespace) -> Path:
    core = Path(args.analysis_folder).expanduser().resolve()
    canonical = core / "tables" / "praycg_analysis_frame_v1_6_0.csv"
    if not canonical.is_file():
        raise SystemExit(f"Missing canonical v1.6.0 frame: {canonical}. Run Master Suite v1.6.0 first.")
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    root = Path(args.out_dir).expanduser().resolve() if args.out_dir else core / f"chained_modules_v1_6_1_{stamp}"
    if root.exists() and any(root.iterdir()):
        raise SystemExit(f"Output directory is not empty: {root}")
    root.mkdir(parents=True, exist_ok=True)
    workspace = root / "workspace"
    workspace.mkdir()
    copy_inputs(core, workspace)
    context_snapshot = core / "provenance" / "PRAYCG_ActiveResearchContext_v1_0.json"
    if context_snapshot.is_file():
        (root / "provenance").mkdir(exist_ok=True)
        (workspace / "provenance").mkdir(exist_ok=True)
        shutil.copy2(context_snapshot, root / "provenance" / context_snapshot.name)
        shutil.copy2(context_snapshot, workspace / "provenance" / context_snapshot.name)
    tables = workspace / "tables"
    staged_feature = tables / canonical.name
    config_payload = read_json(core / "config" / "run_config.json")
    eligibility = read_json(core / "tables" / "run_eligibility.json")
    cfg = config_payload.get("config", config_payload)
    anchor = configured_path(config_payload, "predeclared_anchor_file") or first_existing((core / "provenance").glob("*anchor*"))
    annotation = configured_path(config_payload, "annotation_csv") or first_existing([core / "tables" / "stimulus_annotations_used.csv"])
    event_log = configured_path(config_payload, "event_log_path") or first_existing([core / "tables" / "events_used.csv"])
    xdf = configured_path(config_payload, "xdf_path")
    cue_json = configured_path(config_payload, "cue_schedule_json")
    mred_event = first_existing([core / "tables" / "mred_event_table.csv", core / "tables" / "candidate_local_kht_analysis.csv"])
    stream_inventory = first_existing([core / "tables" / "stream_inventory.csv"])
    records: List[Dict[str, Any]] = []
    modules = root / "modules"
    modules.mkdir()

    nip_dir = modules / "nip_cet_eet"
    nip_cmd = command("praycg_nip_cet_eet_modules_v1_6_0.py", "--feature-csv", staged_feature, "--out-dir", nip_dir)
    if mred_event: nip_cmd += ["--event-csv", str(mred_event)]
    if annotation: nip_cmd += ["--annotation-csv", str(annotation)]
    if cue_json: nip_cmd += ["--cue-schedule-json", str(cue_json)]
    rec = run_task("nip_cet_eet", nip_cmd, root, nip_dir, records)
    refine_status(rec, nip_dir, eligibility); publish_tables(nip_dir, tables)

    amred_dir = modules / "amred"
    amred_cmd = command("praycg_amred_endpoint_module_v1_6_0.py", "--analysis-folder", workspace, "--feature-csv", staged_feature, "--out-dir", amred_dir)
    if anchor: amred_cmd += ["--anchor-file", str(anchor)]
    if mred_event: amred_cmd += ["--mred-event-table", str(mred_event)]
    rec = run_task("amred", amred_cmd, root, amred_dir, records, [] if anchor else ["predeclared_anchor_file"])
    refine_status(rec, amred_dir, eligibility); publish_tables(amred_dir, tables)

    tti_dir = modules / "tti"
    rec = run_task("tti", command("praycg_tti_reception_extraction_module_v1_4_8.py", "--analysis-folder", workspace, "--feature-csv", staged_feature, "--out-dir", tti_dir), root, tti_dir, records)
    publish_tables(tti_dir, tables)

    itp_dir = modules / "mred_itp"
    missing_itp = [name for name, value in [("xdf", xdf), ("event_log", event_log), ("annotation", annotation), ("mred_event", mred_event)] if value is None]
    itp_cmd = command("praycg_mred_itp_modules_v1_6_0.py", "--out-dir", itp_dir)
    if not missing_itp:
        itp_cmd += ["--xdf", str(xdf), "--event-log", str(event_log), "--feature-csv", str(staged_feature), "--annotation-csv", str(annotation), "--mred-event-csv", str(mred_event)]
        if stream_inventory: itp_cmd += ["--stream-inventory-csv", str(stream_inventory)]
    rec = run_task("mred_itp", itp_cmd, root, itp_dir, records, missing_itp)
    publish_tables(itp_dir, tables)

    cii = first_existing([tables / "cii_anchor_integrals.csv"])
    nupi_dir = modules / "nupi"
    nupi_cmd = command("praycg_nupi_module_v1_6_0.py", "--analysis-folder", tables, "--profile", args.profile, "--run-name", args.run_label or cfg.get("project_name", "PRAYCG_Run"), "--out-dir", nupi_dir)
    if cii: nupi_cmd += ["--cii-csv", str(cii)]
    rec = run_task("nupi", nupi_cmd, root, nupi_dir, records, [] if cii else ["cii_anchor_integrals.csv"])
    refine_status(rec, nupi_dir, eligibility); publish_tables(nupi_dir, tables)

    peak_dir = modules / "mred_peak_resolution"
    rec = run_task("mred_peak_resolution", command("praycg_mred_peak_resolution_module_v1_6_0.py", "--analysis-folder", workspace, "--out-dir", peak_dir, "--run-label", args.run_label or cfg.get("project_name", "PRAYCG_Run")), root, peak_dir, records)
    publish_tables(peak_dir, tables)

    shot_dir = modules / "shotorder_hocr"
    rec = run_task("shotorder_hocr", command("praycg_shotorder_hocr_module_v1_6_0.py", "--analysis-folder", workspace, "--feature-csv", staged_feature, "--out-dir", shot_dir), root, shot_dir, records)
    refine_status(rec, shot_dir, eligibility); publish_tables(shot_dir, tables)

    dga_dir = modules / "dga"
    rec = run_task("dga", command("praycg_decoder_gate_availability_module_v1_5_6.py", "--analysis-folder", workspace, "--run-label", args.run_label or cfg.get("project_name", "PRAYCG_Run"), "--out-dir", dga_dir, "--data-grade", eligibility.get("status", "")), root, dga_dir, records)
    publish_tables(dga_dir, tables)

    rsm_dir = modules / "confound_rsm"
    rsm_cmd = command("praycg_confound_rsm_modules_v1_4_6.py", "--analysis-folder", workspace, "--out-dir", rsm_dir)
    if event_log: rsm_cmd += ["--event-log", str(event_log)]
    if cue_json: rsm_cmd += ["--cue-schedule-json", str(cue_json)]
    rec = run_task("confound_rsm", rsm_cmd, root, rsm_dir, records); publish_tables(rsm_dir, tables)

    expanded_dir = modules / "confound_expanded"
    rec = run_task("confound_expanded", command("praycg_confound_expanded_modules_v1_5_7.py", "--analysis-folder", workspace, "--out-folder", expanded_dir), root, expanded_dir, records)
    publish_tables(expanded_dir, tables)

    als_dir = modules / "als_barcode"
    als_cmd = command("praycg_als_barcode_detector_v1_5_8.py", "--analysis-folder", workspace, "--out-dir", als_dir)
    if xdf: als_cmd += ["--xdf", str(xdf)]
    rec = run_task("als_barcode", als_cmd, root, als_dir, records, [] if xdf else ["xdf_path"])
    refine_status(rec, als_dir, eligibility); publish_tables(als_dir, tables)

    # Publish the scientific/software states before interpretation so the report
    # cannot promote a gated, missing, non-applicable, or failed module merely
    # because a stale or partial table exists.
    publish_chain_state(root, core, records, eligibility)
    artifact_report = workspace / "reports" / "praycg_analysis_artifact_index_v1_0.json"
    build_artifact_index(root, artifact_report, include_hashes=True)

    offline_dir = modules / "offline_interpretation"
    run_task("offline_interpretation", command("praycg_offline_interpretive_report_generator_v1_6_0.py", "--analysis-folder", root, "--out-dir", offline_dir, "--run-label", args.run_label or cfg.get("project_name", "PRAYCG_Run"), "--profile", "all", "--write-json"), root, offline_dir, records)

    summary = publish_chain_state(root, core, records, eligibility)
    build_artifact_index(root, artifact_report, include_hashes=True)
    print(f"CHAIN_OUTPUT={root}")
    print(json.dumps({"output_folder": str(root), "status_counts": summary["status_counts"]}, indent=2))
    return root


def main() -> None:
    parser = argparse.ArgumentParser(description="PRAYCG Master Comprehensive Suite v1.6.1 dependency-aware chained-module runner")
    parser.add_argument("--analysis-folder", required=True, help="Fresh Master Suite v1.6.0 core output folder")
    parser.add_argument("--out-dir", default="", help="New output directory; must not already exist")
    parser.add_argument("--profile", default="custom", help="NUPI profile label")
    parser.add_argument("--run-label", default="")
    run_chain(parser.parse_args())


if __name__ == "__main__":
    main()
