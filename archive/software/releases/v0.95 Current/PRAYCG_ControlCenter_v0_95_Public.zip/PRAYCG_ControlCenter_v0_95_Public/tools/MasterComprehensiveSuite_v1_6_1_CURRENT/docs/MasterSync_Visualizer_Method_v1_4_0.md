# MasterSync Visualizer Method v1.4.0

MasterSync is an interactive and rendered audit view. It does not calculate or certify PRAYCG endpoints.

## Gate-aware inputs

When an analysis folder is selected, the Visualizer builds `PRAYCG_AnalysisArtifactIndex_v1_0`. The resolved run-eligibility state and chain module statuses appear in the gate ribbon. A closed gate does not hide data needed for troubleshooting; it marks the display as diagnostic and not inference-eligible.

Registered exact event artifacts are loaded before optional legacy discovery. Duplicate paths, file hashes, selected paths, and artifact-index warnings are preserved in the render sidecar.

## Interactive review

- Timeline scrubbing and zoom use a shared time cursor.
- Event selection exposes source path, raw and rendered times, timing repair, scheduled and observed flip times, ALS edge, residual, and confidence when supplied by the event schema.
- Events without a reported duration use a 0.75-second display interval labeled `estimated_default_0.75s`; that interval is not treated as measured timing.
- The HOC-R tab displays the exact Target, PhaseScrambled, ShotOrder, and Override branch summary and contrasts when available.

## Scaling and missingness

Robust-z mode compares waveform shape after median/MAD scaling. It does not preserve absolute amplitude or units. Raw mode retains available source values, but mixed panels may contain unlike units. Both modes show valid-sample coverage. Missing or constant signals are labeled or omitted instead of filled with favorable values.

## Export boundary

MP4, snapshots, event overlays, and visual similarity are explanatory/audit outputs. Formal module tables, gates, uncertainty, and replication remain authoritative. The display does not prove narrative reception, persistent state change, private experience, or biological mechanism.
