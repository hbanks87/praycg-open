from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
SCRIPTS = HERE.parent / "scripts"
sys.path.insert(0, str(SCRIPTS))

import praycg_master_comprehensive_suite_v1_6_0 as core
import praycg_schema_v1_6_0 as schema
import praycg_chain_runner_v1_6_1 as chain


def stream(name: str, kind: str, values, times=None):
    values = np.asarray(values, dtype=float)
    if times is None:
        times = np.arange(len(values), dtype=float)
    return {
        "info": {"name": [name], "type": [kind], "channel_count": ["1"], "nominal_srate": ["1"]},
        "time_stamps": np.asarray(times, dtype=float),
        "time_series": values.reshape(-1, 1),
    }


class SuiteV160Tests(unittest.TestCase):
    def test_hrv_selection_never_uses_respiration(self):
        respiration = stream("VernierRespirationBelt", "Respiration", np.linspace(600, 900, 30))
        polar = stream("PolarHRV", "HRV", np.full(30, 800.0))
        selected, report = core.choose_hrv_stream([respiration, polar])
        self.assertIs(selected, polar)
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["value_mode"], "rr_ms")

    def test_nyquist_ineligible_band_is_missing(self):
        rng = np.random.default_rng(4)
        x = rng.normal(size=(400, 2))
        blocked = core.band_power_from_welch(x, 80.0, (30.0, 45.0))
        allowed = core.band_power_from_welch(x, 125.0, (30.0, 45.0))
        self.assertTrue(np.isnan(blocked).all())
        self.assertTrue(np.isfinite(allowed).all())

    def test_canonical_frame_deduplicates_and_preserves_missingness(self):
        features = pd.DataFrame({
            "segment": ["BASELINE_1", "TARGET_1", "TARGET_1", "BASELINE_2_REFLECTION"],
            "segment_type": ["core", "core", "stimulus_style", "recovery"],
            "window_mid": [1.0, 11.0, 11.0, 21.0],
            "rel_mid_sec": [1.0, 1.0, 1.0, 1.0],
            "MeaningGamma_lgamma_30_45": [1.0, 2.0, 2.0, 3.0],
            "pow_lgamma_30_45_visual_control": [4.0, 5.0, 5.0, 6.0],
            "median_p2p": [10.0, 11.0, 11.0, 12.0],
        })
        frame = schema.canonicalize_feature_frame(features)
        self.assertEqual(len(frame), 3)
        self.assertIn("BASELINE_2_REFLECTION", set(frame["condition"]))
        self.assertTrue(frame["nas_score"].isna().all())
        self.assertTrue(frame["gamma_visual_30_45_z"].notna().all())

    def test_window_respiration_is_aligned_to_each_feature_window(self):
        times = np.arange(0.0, 10.0, 0.1)
        resp = stream("VernierRespirationBelt", "Respiration", np.sin(times), times)
        polar = stream("PolarHRV", "HRV", np.full(len(times), 800.0), times)
        features = pd.DataFrame({"window_start": [0.0, 2.0], "window_end": [2.0, 4.0]})
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp); (out / "tables").mkdir()
            enriched = core.add_window_physiology(features, [polar, resp], out, lambda _message: None)
            self.assertTrue(enriched["resp_signal_window_mean"].notna().all())
            self.assertEqual(set(enriched["resp_signal_stream_name"]), {"VernierRespirationBelt"})

    def test_missing_prerequisite_status_is_not_reclassified_as_gate_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            module_dir = Path(tmp)
            record = {"module": "amred", "status": "NOT_GRADABLE_MISSING_INPUT", "message": "missing"}
            chain.refine_status(record, module_dir, {"strict_interpretation_allowed": True})
            self.assertEqual(record["status"], "NOT_GRADABLE_MISSING_INPUT")


if __name__ == "__main__":
    unittest.main()
