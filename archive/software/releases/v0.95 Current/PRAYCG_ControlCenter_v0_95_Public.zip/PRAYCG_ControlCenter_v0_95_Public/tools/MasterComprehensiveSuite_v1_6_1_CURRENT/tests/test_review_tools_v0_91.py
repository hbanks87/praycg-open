from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

import pandas as pd

HERE=Path(__file__).resolve().parent
SCRIPTS=HERE.parent/"scripts"
sys.path.insert(0,str(SCRIPTS))

import praycg_artifact_index_v1_0 as artifacts
import praycg_master_sync_visualizer_v1_4_0 as visualizer
import praycg_offline_interpretive_report_generator_v1_6_0 as interpreter


class ReviewToolTests(unittest.TestCase):
    def make_chain(self,root:Path,status="FAIL_PRIMARY_GATE") -> Path:
        chain=root/"chained_modules_v1_6_1_test"; tables=chain/"workspace"/"tables"; module=chain/"modules"/"amred"
        tables.mkdir(parents=True); module.mkdir(parents=True)
        (tables/"run_eligibility.json").write_text(json.dumps({"status":"PASS","strict_interpretation_allowed":True,"run_uuid":"test-run"}),encoding="utf-8")
        pd.DataFrame({"A_MRED_pass":[True],"anchor_id":["locked_1"]}).to_csv(tables/"amred_anchor_endpoint_table.csv",index=False)
        pd.DataFrame({"A_MRED_pass":[False],"anchor_id":["stale"]}).to_csv(module/"amred_anchor_endpoint_table.csv",index=False)
        row={"module":"amred","status":status,"message":"test gate"}
        (module/"module_status.json").write_text(json.dumps(row),encoding="utf-8")
        (chain/"chain_manifest.json").write_text(json.dumps({"schema":"PRAYCG_ChainManifest_v1_6_1","modules":[row]}),encoding="utf-8")
        return chain

    def test_index_prefers_canonical_table_and_keeps_duplicate_warning(self):
        with tempfile.TemporaryDirectory() as tmp:
            chain=self.make_chain(Path(tmp)); index=artifacts.build_artifact_index(chain,include_hashes=False)
            entry=index["artifacts"]["amred_anchor"]
            self.assertEqual(Path(entry["selected_path"]).parent.name,"tables")
            self.assertEqual(len(entry["duplicate_paths"]),1)
            self.assertEqual(entry["module_status"],"FAIL_PRIMARY_GATE")

    def test_failed_module_blocks_existing_amred_table(self):
        with tempfile.TemporaryDirectory() as tmp:
            chain=self.make_chain(Path(tmp)); index=artifacts.build_artifact_index(chain,include_hashes=False); issues=[]
            tables={"amred_anchor":interpreter.read_table("amred_anchor",index,issues)}
            claims=interpreter.build_claims(index,tables,issues)
            amred=next(row for row in claims if row["claim_id"]=="AMRED-001")
            self.assertEqual(amred["claim_status"],"NOT_EVALUABLE")

    def test_failed_nip_gate_blocks_partial_cii_and_eet_tables(self):
        with tempfile.TemporaryDirectory() as tmp:
            chain=self.make_chain(Path(tmp)); tables_root=chain/"workspace"/"tables"; module=chain/"modules"/"nip_cet_eet"; module.mkdir()
            pd.DataFrame({"condition":["Target"],"CII":[1.2]}).to_csv(tables_root/"cii_anchor_integrals.csv",index=False)
            row={"module":"nip_cet_eet","status":"FAIL_PRIMARY_GATE","message":"CET gate failed"}
            (module/"module_status.json").write_text(json.dumps(row),encoding="utf-8")
            manifest=json.loads((chain/"chain_manifest.json").read_text(encoding="utf-8")); manifest["modules"].append(row); (chain/"chain_manifest.json").write_text(json.dumps(manifest),encoding="utf-8")
            index=artifacts.build_artifact_index(chain,include_hashes=False); issues=[]; tables={"cii_anchor":interpreter.read_table("cii_anchor",index,issues)}
            claims=interpreter.build_claims(index,tables,issues)
            self.assertTrue(any(item["claim_id"]=="NIPGATE-001" and item["claim_status"]=="NOT_EVALUABLE" for item in claims))
            self.assertFalse(any(item["claim_id"]=="CII-001" for item in claims))

    def test_column_matching_is_exact_not_fuzzy(self):
        frame=pd.DataFrame({"not_really_CII_adjusted":[1.0],"CII":[2.0]})
        self.assertEqual(interpreter.exact_col(frame,"CII"),"CII")
        self.assertIsNone(interpreter.exact_col(frame,"II"))

    def test_visual_event_marks_default_duration_as_estimated(self):
        event=visualizer.event_from_row({"observed_flip_sec":2.0,"label":"locked anchor","timing_confidence":"frame_observed"},"events.csv")
        self.assertIsNotNone(event)
        self.assertEqual(event.timing_basis,"estimated_default_0.75s")
        self.assertEqual(event.observed_flip_sec,2.0)


if __name__=="__main__":unittest.main()
