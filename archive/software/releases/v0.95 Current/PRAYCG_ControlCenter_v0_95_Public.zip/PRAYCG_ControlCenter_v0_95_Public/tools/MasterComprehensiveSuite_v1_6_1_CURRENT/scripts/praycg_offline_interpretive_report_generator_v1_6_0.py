#!/usr/bin/env python3
"""PRAYCG Offline Master Interpreter v1.6.0.

Deterministic, offline, manifest-driven interpretation of Master Comprehensive
Suite outputs. It builds an evidence ledger first and then renders technical,
research, and public-safe reports from the same claims. File existence never
overrides run eligibility, module status, timing gates, or protocol applicability.
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from praycg_artifact_index_v1_0 import artifact_path, build_artifact_index

VERSION = "1.6.0"
SCHEMA = "PRAYCG_OfflineInterpretation_v1_6_0"
LEDGER_SCHEMA = "PRAYCG_EvidenceLedger_v1_0"
BOUNDARY = (
    "This deterministic offline report is an interpretation aid. It does not prove consciousness, "
    "memory formation, OSM or hidden-Y biology, clinical effects, literal thermodynamic entropy, or "
    "private experience. Self-report is contextual evidence. Displayed associations are not mechanisms."
)

BLOCKING_STATES = {"FAIL_PRIMARY_GATE", "NOT_GRADABLE_MISSING_INPUT", "NOT_APPLICABLE_PROTOCOL", "SOFTWARE_ERROR"}


def norm(value: Any) -> str:
    return "".join(ch.lower() for ch in str(value) if ch.isalnum())


def exact_col(df: pd.DataFrame, *aliases: str) -> Optional[str]:
    """Return only an exact normalized alias match; never fuzzy containment."""
    if len(df.columns) == 0:
        return None
    mapping: Dict[str, List[str]] = {}
    for column in df.columns:
        mapping.setdefault(norm(column), []).append(str(column))
    for alias in aliases:
        matches = mapping.get(norm(alias), [])
        if len(matches) == 1:
            return matches[0]
    return None


def finite(value: Any) -> Optional[float]:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None


def fmt(value: Any, digits: int = 3) -> str:
    number = finite(value)
    return f"{number:.{digits}f}" if number is not None else "not available"


def truth(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"true", "1", "yes", "pass", "passed", "y"}


def read_table(key: str, index: Dict[str, Any], issues: List[Dict[str, Any]]) -> pd.DataFrame:
    path = artifact_path(index, key)
    if path is None:
        return pd.DataFrame()
    try:
        frame = pd.read_csv(path)
        if not len(frame.columns):
            issues.append({"severity": "ERROR", "code": "EMPTY_SCHEMA", "artifact": key, "path": str(path)})
            return pd.DataFrame()
        return frame
    except Exception as exc:
        issues.append({"severity": "ERROR", "code": "MALFORMED_CSV", "artifact": key, "path": str(path), "message": str(exc)})
        return pd.DataFrame()


def module_state(index: Dict[str, Any], module: str) -> Tuple[str, str]:
    row = index.get("module_statuses", {}).get(module, {})
    return str(row.get("status", "UNRECORDED")), str(row.get("message", ""))


def evidence_ref(index: Dict[str, Any], key: str, columns: Sequence[str] = (), rows: str = "") -> Dict[str, Any]:
    item = index.get("artifacts", {}).get(key, {})
    return {
        "artifact_key": key,
        "path": item.get("selected_path", ""),
        "sha256": item.get("sha256", ""),
        "columns": list(columns),
        "rows": rows,
    }


def claim(
    claims: List[Dict[str, Any]], claim_id: str, section: str, statement: str,
    status: str, tier: str, module: str, module_status: str,
    evidence: Sequence[Dict[str, Any]] = (), counterevidence: Sequence[str] = (),
    effect: str = "", uncertainty: str = "", limitations: Sequence[str] = (),
) -> None:
    claims.append({
        "claim_id": claim_id,
        "section": section,
        "statement": statement,
        "claim_status": status,
        "tier": tier,
        "module": module,
        "module_status": module_status,
        "effect_or_value": effect,
        "uncertainty_and_coverage": uncertainty,
        "evidence": list(evidence),
        "counterevidence": list(counterevidence),
        "limitations": list(limitations),
    })


def build_claims(index: Dict[str, Any], tables: Dict[str, pd.DataFrame], io_issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    claims: List[Dict[str, Any]] = []
    run = index.get("run", {})
    strict = bool(run.get("strict_interpretation_allowed", False))
    eligibility = str(run.get("eligibility_status") or run.get("eligibility_record_state") or "UNKNOWN")
    gate_status = "SUPPORTED_WITHIN_GATES" if strict else "DIAGNOSTIC_ONLY"
    claim(claims, "QC-001", "Data and QC", f"Run eligibility is `{eligibility}`; strict interpretation is {'allowed' if strict else 'not allowed'}.", gate_status, "primary_gate", "core", "PASS" if strict else eligibility, [evidence_ref(index, "run_eligibility")], limitations=["Eligibility is necessary but not sufficient for a scientific claim."])

    for name, row in sorted(index.get("module_statuses", {}).items()):
        status = str(row.get("status", "UNRECORDED"))
        mapped = "NOT_EVALUABLE" if status in BLOCKING_STATES else ("EXPLORATORY_SIGNAL" if status == "EXPLORATORY_ONLY" else "AVAILABLE")
        claim(claims, f"MOD-{len(claims)+1:03d}", "Module execution matrix", f"{name}: {status}. {row.get('message','')}", mapped, "software_status", name, status, limitations=["A successful process exit does not itself establish a scientific effect."])

    # A-MRED primary endpoint.
    amred = tables.get("amred_anchor", pd.DataFrame())
    amred_status, amred_message = module_state(index, "amred")
    if amred.empty:
        claim(claims, "AMRED-001", "A-MRED primary endpoint", "A-MRED anchor output is unavailable or unreadable.", "NOT_EVALUABLE", "primary", "amred", amred_status, [evidence_ref(index, "amred_anchor")], limitations=[amred_message or "No readable exact-schema artifact."])
    elif amred_status in BLOCKING_STATES:
        claim(claims, "AMRED-001", "A-MRED primary endpoint", f"A-MRED output exists but interpretation is blocked by module state `{amred_status}`.", "NOT_EVALUABLE", "primary", "amred", amred_status, [evidence_ref(index, "amred_anchor")], limitations=[amred_message])
    else:
        pass_col = exact_col(amred, "A_MRED_pass")
        anchor_col = exact_col(amred, "anchor_id")
        valid = int(amred[pass_col].notna().sum()) if pass_col else 0
        passed = int(amred[pass_col].map(truth).sum()) if pass_col else 0
        ids = [str(x) for x in amred.loc[amred[pass_col].map(truth), anchor_col].head(8)] if pass_col and anchor_col else []
        status = "SUPPORTED_WITHIN_GATES" if strict and amred_status == "PASS" and passed > 0 else ("NO_PRIMARY_PASS" if passed == 0 else "DIAGNOSTIC_ONLY")
        statement = f"A-MRED evaluated {len(amred)} anchor row(s); {passed} met the recorded A-MRED pass field."
        if ids: statement += " Recorded passing anchors: " + ", ".join(ids) + "."
        claim(claims, "AMRED-001", "A-MRED primary endpoint", statement, status, "primary", "amred", amred_status, [evidence_ref(index, "amred_anchor", [x for x in [pass_col, anchor_col] if x], "all anchor rows")], uncertainty=f"valid pass fields n={valid}; total rows n={len(amred)}", limitations=["A recorded pass is strongest only with prelocked anchors, valid timing, artifact gates, and replication."])

    peak = tables.get("mred_peak_res_summary", pd.DataFrame())
    peak_status, peak_message = module_state(index, "mred_peak_resolution")
    if peak.empty or peak_status in BLOCKING_STATES:
        claim(claims, "MREDPR-001", "MRED-Peak and Resolution", "MRED-Peak/Resolution compression is not evaluable from an allowed, readable artifact.", "NOT_EVALUABLE", "primary", "mred_peak_resolution", peak_status, [evidence_ref(index, "mred_peak_res_summary")], limitations=[peak_message])
    else:
        row = peak.iloc[0]
        fields = {
            "anchors": exact_col(peak, "anchor_count"),
            "strict peaks": exact_col(peak, "strict_peak_pass_count"),
            "soft peaks": exact_col(peak, "soft_peak_candidate_count"),
            "resolution candidates": exact_col(peak, "resolution_candidate_count"),
        }
        values = {label: fmt(row.get(column)) if column else "not available" for label, column in fields.items()}
        statement = "; ".join(f"{label}: {value}" for label, value in values.items()) + "."
        claim(claims, "MREDPR-001", "MRED-Peak and Resolution", statement, "DESCRIPTIVE_RESULT" if strict else "DIAGNOSTIC_ONLY", "primary", "mred_peak_resolution", peak_status, [evidence_ref(index, "mred_peak_res_summary", [c for c in fields.values() if c], "first summary row")], limitations=["Endpoint compression summarizes other measures; it is not independent replication."])

    # Four-branch ShotOrder HOC-R.
    hocr = tables.get("hocr_contrasts", pd.DataFrame())
    hocr_status, hocr_message = module_state(index, "shotorder_hocr")
    if hocr.empty or hocr_status in BLOCKING_STATES:
        reason = "ShotOrder is not part of this protocol." if hocr_status == "NOT_APPLICABLE_PROTOCOL" else "No allowed exact-schema HOC-R contrast table is available."
        claim(claims, "HOCR-001", "Four-branch structural controls", reason, "NOT_APPLICABLE" if hocr_status == "NOT_APPLICABLE_PROTOCOL" else "NOT_EVALUABLE", "confound", "shotorder_hocr", hocr_status, [evidence_ref(index, "hocr_contrasts")], limitations=[hocr_message])
    else:
        contrast_col = exact_col(hocr, "contrast")
        present_col = exact_col(hocr, "comparator_present")
        frac_col = exact_col(hocr, "positive_metric_fraction")
        metric_cols = [c for c in hocr.columns if str(c).startswith("delta_") and pd.to_numeric(hocr[c], errors="coerce").notna().any()]
        for i, row in hocr.iterrows():
            contrast_name = str(row.get(contrast_col, f"contrast_{i+1}")) if contrast_col else f"contrast_{i+1}"
            present = truth(row.get(present_col)) if present_col else True
            if not present:
                statement = f"{contrast_name}: comparator branch was not detected."
                cstatus = "NOT_APPLICABLE"
            else:
                positive = fmt(row.get(frac_col)) if frac_col else "not available"
                observed = [f"{c}={fmt(row.get(c))}" for c in metric_cols[:8]]
                statement = f"{contrast_name}: comparator present; positive-metric fraction {positive}. " + "; ".join(observed) + "."
                cstatus = "DESCRIPTIVE_RESULT" if strict else "DIAGNOSTIC_ONLY"
            claim(claims, f"HOCR-{i+1:03d}", "Four-branch structural controls", statement, cstatus, "confound", "shotorder_hocr", hocr_status, [evidence_ref(index, "hocr_contrasts", [x for x in [contrast_col, present_col, frac_col] if x] + metric_cols, f"row {i}")], limitations=["Direction across selected proxies is not a causal estimate.", "Target–ShotOrder is interpretable only when ShotOrder is actually present and QC-compatible."])

    # Expanded confound defenses.
    conf = tables.get("confound_summary", pd.DataFrame())
    conf_status, conf_message = module_state(index, "confound_expanded")
    if conf.empty or conf_status in BLOCKING_STATES:
        claim(claims, "CONF-001", "Expanded confound defenses", "The consolidated HOC-R/OSA/OHC/AAM/RespDualPath matrix is unavailable or blocked.", "NOT_EVALUABLE", "confound", "confound_expanded", conf_status, [evidence_ref(index, "confound_summary")], limitations=[conf_message])
    else:
        module_col = exact_col(conf, "module")
        status_col = exact_col(conf, "status")
        caution_col = exact_col(conf, "caution_level")
        action_col = exact_col(conf, "action")
        for i, row in conf.iterrows():
            name = str(row.get(module_col, f"confound_{i+1}")) if module_col else f"confound_{i+1}"
            state = str(row.get(status_col, "UNRECORDED")) if status_col else "UNRECORDED"
            caution = str(row.get(caution_col, "")) if caution_col else ""
            action = str(row.get(action_col, "")) if action_col else ""
            upper = (state + " " + caution).upper()
            cstatus = "CONFOUND_CAUTION" if any(x in upper for x in ["HIGH", "FAIL", "CAUTION", "VETO"]) else "CONFOUND_CHECK_RECORDED"
            claim(claims, f"CONF-{i+1:03d}", "Expanded confound defenses", f"{name}: status `{state}`, caution `{caution}`. {action}", cstatus, "confound", "confound_expanded", conf_status, [evidence_ref(index, "confound_summary", [x for x in [module_col,status_col,caution_col,action_col] if x], f"row {i}")], limitations=["A passed confound screen reduces one alternative explanation; it does not prove the preferred mechanism."])

    # Secondary metrics are recorded quantitatively without directional storytelling.
    tti = tables.get("tti_global", pd.DataFrame())
    tti_status, tti_message = module_state(index, "tti")
    if not tti.empty and tti_status not in BLOCKING_STATES:
        tcol = exact_col(tti, "TTI", "TTI_global", "thermodynamic_theft_composite_index")
        value = fmt(tti.iloc[0].get(tcol)) if tcol else "not available"
        claim(claims, "TTI-001", "Secondary measures", f"The recorded TTI summary value is {value}.", "DESCRIPTIVE_RESULT" if strict else "DIAGNOSTIC_ONLY", "secondary", "tti", tti_status, [evidence_ref(index, "tti_global", [tcol] if tcol else [], "first summary row")], limitations=["Its sign is not labeled Target-favoring without an explicit, versioned contrast definition.", tti_message])

    nupi = tables.get("nupi_summary", pd.DataFrame())
    nupi_status, nupi_message = module_state(index, "nupi")
    if not nupi.empty and nupi_status not in BLOCKING_STATES:
        row=nupi.iloc[0]; parts=[]; cols=[]
        for label,aliases in [("ALI",("ALI",)),("RDI",("RDI",)),("NUPI",("NUPI",)),("classification",("classification",))]:
            c=exact_col(nupi,*aliases)
            if c: parts.append(f"{label}={row.get(c) if label=='classification' else fmt(row.get(c))}"); cols.append(c)
        claim(claims, "NUPI-001", "Secondary measures", "NUPI summary: " + (", ".join(parts) if parts else "recognized metrics not available") + ".", "DESCRIPTIVE_RESULT" if strict else "DIAGNOSTIC_ONLY", "secondary", "nupi", nupi_status, [evidence_ref(index, "nupi_summary", cols, "first summary row")], limitations=[nupi_message])

    nip_status,nip_message=module_state(index,"nip_cet_eet")
    cii = tables.get("cii_anchor", pd.DataFrame())
    if nip_status in BLOCKING_STATES and any(not tables.get(key,pd.DataFrame()).empty for key in ["cii_anchor","cet_model","eet"]):
        claim(claims,"NIPGATE-001","Secondary measures",f"NIP/CII/CET/EET tables exist but interpretation is blocked by module state `{nip_status}`.","NOT_EVALUABLE","secondary","nip_cet_eet",nip_status,[evidence_ref(index,"cii_anchor"),evidence_ref(index,"cet_model"),evidence_ref(index,"eet")],limitations=[nip_message])
    if not cii.empty and nip_status not in BLOCKING_STATES:
        value_col=exact_col(cii,"CII"); condition_col=exact_col(cii,"condition")
        if value_col and condition_col:
            values=pd.to_numeric(cii[value_col],errors="coerce"); valid=cii.assign(_value=values).dropna(subset=["_value"])
            means=valid.groupby(valid[condition_col].astype(str))["_value"].agg(["mean","count"])
            text="; ".join(f"{idx}: mean={row['mean']:.3f}, n={int(row['count'])}" for idx,row in means.iterrows())
            claim(claims,"CII-001","Secondary measures","CII by condition: "+text+".","DESCRIPTIVE_RESULT" if strict else "DIAGNOSTIC_ONLY","secondary","nip_cet_eet",nip_status,[evidence_ref(index,"cii_anchor",[condition_col,value_col],"all valid rows")],uncertainty=f"valid n={len(valid)} of {len(cii)}",limitations=["Group means alone do not provide uncertainty intervals or a causal contrast."])

    cet=tables.get("cet_model",pd.DataFrame())
    if not cet.empty and nip_status not in BLOCKING_STATES:
        metric_cols=[c for c in cet.columns if any(token in norm(c) for token in ["blockedcv","crossvalidated","r2"])]
        parts=[]
        for c in metric_cols[:8]:
            vals=pd.to_numeric(cet[c],errors="coerce").dropna()
            if len(vals): parts.append(f"{c}: mean={vals.mean():.3f}, n={len(vals)}")
        claim(claims,"CET-001","Secondary measures","CET model validation: "+("; ".join(parts) if parts else "no exact R2/CV metric was recognized")+".","DESCRIPTIVE_RESULT" if parts else "NOT_EVALUABLE","secondary","nip_cet_eet",nip_status,[evidence_ref(index,"cet_model",metric_cols,"all valid rows")],limitations=["In-sample fit and blocked cross-validation are not interchangeable."])

    dga=tables.get("dga_summary",pd.DataFrame())
    dga_status,dga_message=module_state(index,"dga")
    if not dga.empty and dga_status not in BLOCKING_STATES:
        row=dga.iloc[0]; parts=[]; cols=[]
        for label,aliases in [("classification",("classification",)),("GDI",("gate_dissociation_index",)),("Target gate",("target_gate",)),("Override gate",("override_gate",))]:
            c=exact_col(dga,*aliases)
            if c: parts.append(f"{label}={row.get(c) if label=='classification' else fmt(row.get(c))}"); cols.append(c)
        claim(claims,"DGA-001","Secondary measures","DGA summary: "+(", ".join(parts) if parts else "recognized fields unavailable")+".","DESCRIPTIVE_RESULT" if strict else "DIAGNOSTIC_ONLY","secondary","dga",dga_status,[evidence_ref(index,"dga_summary",cols,"first summary row")],limitations=["DGA estimates gate availability; it is not proof of a decoder or mechanism.",dga_message])

    eet=tables.get("eet",pd.DataFrame())
    if not eet.empty and nip_status not in BLOCKING_STATES:
        sim=exact_col(eet,"cosine_similarity_state_vector","similarity")
        vals=pd.to_numeric(eet[sim],errors="coerce").dropna() if sim else pd.Series(dtype=float)
        claim(claims,"EET-001","Exploratory and convergence","Maximum recorded EET state-vector similarity is "+(f"{vals.max():.3f}" if len(vals) else "not available")+".","EXPLORATORY_SIGNAL" if len(vals) else "NOT_EVALUABLE","exploratory","nip_cet_eet",nip_status,[evidence_ref(index,"eet",[sim] if sim else [],"all valid rows")],uncertainty=f"valid n={len(vals)}",limitations=["State resemblance is not proof of replay, memory, or persistent causal state change."])

    # Convergence/contradiction audit derived only from already-recorded states.
    als_status,_=module_state(index,"als_barcode")
    amred_claim=next((x for x in claims if x["claim_id"]=="AMRED-001"),None)
    cautions=[x for x in claims if x["claim_status"]=="CONFOUND_CAUTION"]
    contradictions=[]
    if amred_claim and amred_claim["claim_status"]=="SUPPORTED_WITHIN_GATES" and als_status not in {"PASS","UNRECORDED"}:
        contradictions.append(f"A-MRED is recorded as gate-supported while ALS timing status is {als_status}.")
    if amred_claim and amred_claim["claim_status"]=="SUPPORTED_WITHIN_GATES" and cautions:
        contradictions.append(f"A-MRED is recorded as gate-supported while {len(cautions)} expanded confound caution(s) remain.")
    if io_issues:
        contradictions.append(f"{len(io_issues)} artifact read/schema issue(s) were detected.")
    claim(claims,"CONV-001","Convergence and contradiction audit", "No direct gate contradiction was detected among the available records." if not contradictions else " ".join(contradictions), "NO_RECORDED_CONTRADICTION" if not contradictions else "UNRESOLVED_CONTRADICTION", "cross_stream", "interpreter", "PASS" if not contradictions else "CAUTION", counterevidence=contradictions, limitations=["Absence of a detected contradiction is not positive confirmation."])
    return claims


def run_signature(index: Dict[str, Any]) -> Dict[str, Any]:
    frame=artifact_path(index,"analysis_frame"); columns=[]; conditions=[]; error=""
    if frame and frame.is_file():
        try:
            header=pd.read_csv(frame,nrows=0); columns=[str(c) for c in header.columns]
            condition=exact_col(header,"condition")
            if condition:
                conditions=sorted(set(pd.read_csv(frame,usecols=[condition])[condition].dropna().astype(str)))
        except Exception as exc:error=str(exc)
    manifest_path=artifact_path(index,"chain_manifest"); manifest={}
    if manifest_path and manifest_path.is_file():
        try:manifest=json.loads(manifest_path.read_text(encoding="utf-8"))
        except Exception as exc:error=(error+"; " if error else "")+str(exc)
    return {"selected_folder":index.get("layout",{}).get("selected_folder",""),"resolved_data_root":index.get("layout",{}).get("data_root",""),"run_uuid":index.get("run",{}).get("run_uuid",""),"eligibility_status":index.get("run",{}).get("eligibility_status",""),"strict_interpretation_allowed":index.get("run",{}).get("strict_interpretation_allowed",False),"analysis_frame":str(frame) if frame else "","analysis_frame_schema":manifest.get("analysis_frame_schema","PRAYCG_AnalysisFrame_v1_6_0" if frame and frame.name=="praycg_analysis_frame_v1_6_0.csv" else ""),"suite_version":manifest.get("suite_version",""),"columns":columns,"conditions":conditions,"error":error}


def build_comparisons(primary_index: Dict[str, Any], folders: Sequence[str], claims: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    primary=run_signature(primary_index); output=[]
    for i,raw in enumerate(folders):
        other_index=build_artifact_index(Path(raw),include_hashes=True); other=run_signature(other_index); reasons=[]; warnings=[]
        if not primary["analysis_frame"] or not other["analysis_frame"]: reasons.append("canonical analysis frame missing")
        if primary["analysis_frame_schema"] != other["analysis_frame_schema"]: reasons.append("analysis-frame schema differs")
        if primary["columns"] != other["columns"]: reasons.append("canonical column schema differs")
        if primary["conditions"] != other["conditions"]: reasons.append("condition/branch set differs")
        if primary["suite_version"] != other["suite_version"]: warnings.append(f"suite versions differ ({primary['suite_version'] or 'unrecorded'} vs {other['suite_version'] or 'unrecorded'})")
        if not primary["strict_interpretation_allowed"] or not other["strict_interpretation_allowed"]: warnings.append("one or both runs are not strict-interpretation eligible")
        compatible=not reasons
        record={"comparison_index":i+1,"compatible_for_structural_replication_review":compatible,"pooling_performed":False,"blocking_reasons":reasons,"warnings":warnings,"primary":primary,"comparison":other,"comparison_artifact_issues":other_index.get("issues",[])}; output.append(record)
        statement=f"Comparison run `{Path(raw).name}` is {'structurally compatible' if compatible else 'not structurally compatible'} for side-by-side replication review. No automatic pooling was performed."
        if reasons:statement += " Blocking differences: " + "; ".join(reasons) + "."
        if warnings:statement += " Warnings: " + "; ".join(warnings) + "."
        claim(claims,f"XRUN-{i+1:03d}","Cross-run compatibility",statement,"COMPATIBLE_NO_POOLING" if compatible else "INCOMPATIBLE_NO_POOLING","replication","interpreter","PASS" if compatible else "CAUTION",evidence=[{"artifact_key":"analysis_frame","path":other["analysis_frame"],"sha256":other_index.get("artifacts",{}).get("analysis_frame",{}).get("sha256",""),"columns":other["columns"],"rows":"schema and condition inventory"}],limitations=["Compatibility permits comparison; it does not establish replication.","Effect pooling requires a prespecified statistical model and harmonized estimands."])
    return output


def markdown_table(rows: Sequence[Sequence[Any]], headers: Sequence[str]) -> str:
    def clean(value: Any) -> str: return str(value).replace("|","\\|").replace("\n"," ")
    out=["| " + " | ".join(map(clean,headers)) + " |","| " + " | ".join("---" for _ in headers) + " |"]
    out += ["| " + " | ".join(clean(v) for v in row) + " |" for row in rows]
    return "\n".join(out)


def render_report(profile: str, root: Path, run_label: str, index: Dict[str, Any], claims: List[Dict[str, Any]], io_issues: List[Dict[str, Any]]) -> str:
    title={"technical":"Technical Evidence Report","research":"Research Synopsis","public":"Public-Safe Synopsis"}[profile]
    lines=[f"# PRAYCG Offline {title}","",f"Interpreter: `{SCHEMA}` v`{VERSION}`  ",f"Run: `{run_label}`  ",f"Selected folder: `{root}`  ",f"Resolved data root: `{index.get('layout',{}).get('data_root','')}`","","## Boundary","",BOUNDARY,"","## Overall gate","",f"**{index.get('interpretation_gate','DIAGNOSTIC_ONLY')}** — eligibility `{index.get('run',{}).get('eligibility_status','UNKNOWN')}`; strict interpretation `{index.get('run',{}).get('strict_interpretation_allowed',False)}`.",""]
    if profile=="public":
        lines += ["## What this run can support","", "The statements below preserve the same gates as the technical report. Missing, failed, and non-applicable checks are not converted into positive findings.",""]
    sections=[]
    for item in claims:
        if item["section"] not in sections and (profile!="public" or item["section"]!="Module execution matrix"): sections.append(item["section"])
    for section in sections:
        subset=[x for x in claims if x["section"]==section]
        lines += [f"## {section}",""]
        if profile=="technical":
            rows=[]
            for x in subset:
                sources=", ".join(Path(e.get("path","")).name for e in x["evidence"] if e.get("path")) or "none"
                rows.append([x["claim_id"],x["claim_status"],x["module_status"],x["statement"],x["uncertainty_and_coverage"],sources])
            lines += [markdown_table(rows,["Claim","Claim status","Module status","Statement","Coverage/uncertainty","Evidence"]),""]
            for x in subset:
                if x["limitations"] or x["counterevidence"]:
                    lines.append(f"- `{x['claim_id']}` limits: " + "; ".join([v for v in x["limitations"]+x["counterevidence"] if v]))
            lines.append("")
        else:
            for x in subset:
                prefix={"SUPPORTED_WITHIN_GATES":"Gate-supported","DIAGNOSTIC_ONLY":"Diagnostic only","NOT_EVALUABLE":"Not evaluable","NOT_APPLICABLE":"Not applicable","UNRESOLVED_CONTRADICTION":"Unresolved"}.get(x["claim_status"],x["claim_status"].replace("_"," ").title())
                lines.append(f"- **{prefix}:** {x['statement']}")
                if profile=="research" and x["limitations"]: lines.append("  Limit: " + "; ".join(v for v in x["limitations"] if v))
            lines.append("")
    if profile=="technical":
        lines += ["## Artifact-index issues","",markdown_table([[x.get("severity",""),x.get("code",""),x.get("artifact",x.get("path","")),x.get("message","")] for x in index.get("issues",[])+io_issues],["Severity","Code","Artifact/path","Message"]) if index.get("issues",[])+io_issues else "No artifact-index or table-read issues were recorded.",""]
    lines += ["## Interpretation rule","","A module table is described only within its recorded execution status. `FAIL_PRIMARY_GATE`, `NOT_GRADABLE_MISSING_INPUT`, `NOT_APPLICABLE_PROTOCOL`, and `SOFTWARE_ERROR` remain distinct and cannot be rewritten as negative or positive scientific results.",""]
    return "\n".join(lines)


def simple_html(markdown_text: str) -> str:
    body=[]; in_list=False; lines=markdown_text.splitlines(); i=0
    while i < len(lines):
        line=lines[i].rstrip()
        if line.startswith("|"):
            if in_list: body.append("</ul>"); in_list=False
            block=[]
            while i < len(lines) and lines[i].strip().startswith("|"):
                block.append([cell.strip() for cell in lines[i].strip().strip("|").split("|")]); i+=1
            if len(block)>=2:
                body.append("<table><thead><tr>"+"".join(f"<th>{html.escape(cell)}</th>" for cell in block[0])+"</tr></thead><tbody>")
                for row in block[2:]: body.append("<tr>"+"".join(f"<td>{html.escape(cell)}</td>" for cell in row)+"</tr>")
                body.append("</tbody></table>")
            continue
        if line.startswith("# "): body.append(f"<h1>{html.escape(line[2:])}</h1>")
        elif line.startswith("## "): body.append(f"<h2>{html.escape(line[3:])}</h2>")
        elif line.startswith("- "):
            if not in_list: body.append("<ul>"); in_list=True
            body.append(f"<li>{html.escape(line[2:])}</li>")
        else:
            if in_list: body.append("</ul>"); in_list=False
            if line: body.append(f"<p>{html.escape(line)}</p>")
        i+=1
    if in_list: body.append("</ul>")
    return "<!doctype html><meta charset='utf-8'><title>PRAYCG Offline Interpretation</title><style>body{font-family:Segoe UI,Arial;max-width:1200px;margin:2rem auto;padding:0 1rem;line-height:1.45}h1,h2{color:#26384a}code{background:#eee;padding:.1rem .25rem}table{border-collapse:collapse;width:100%;font-size:.9rem}th,td{border:1px solid #bbb;padding:.4rem;vertical-align:top}th{background:#eef2f5;text-align:left}</style>"+"\n".join(body)


def ensure_peak_resolution(root: Path, out_dir: Path) -> Dict[str, Any]:
    script=Path(__file__).with_name("praycg_mred_peak_resolution_module_v1_6_0.py")
    if not script.is_file(): return {"status":"NOT_RUN","message":"Bundled v1.6.0 peak-resolution module is missing."}
    cmd=[sys.executable,str(script),"--analysis-folder",str(root),"--out-dir",str(out_dir)]
    try:
        result=subprocess.run(cmd,capture_output=True,text=True,encoding="utf-8",errors="replace",timeout=180,check=False)
        return {"status":"PASS" if result.returncode==0 else "SOFTWARE_ERROR","return_code":result.returncode,"stdout":result.stdout[-4000:],"stderr":result.stderr[-4000:],"command":cmd}
    except Exception as exc: return {"status":"SOFTWARE_ERROR","message":str(exc),"command":cmd}


def run(args: argparse.Namespace) -> Dict[str, Any]:
    selected=Path(args.analysis_folder).expanduser().resolve()
    preliminary=build_artifact_index(selected,include_hashes=True)
    data_root=Path(preliminary["layout"]["data_root"])
    out_dir=Path(args.out_dir).expanduser().resolve() if args.out_dir else data_root/"reports"/"offline_interpretation_v1_6_0"
    out_dir.mkdir(parents=True,exist_ok=True)
    auto_result={"status":"NOT_REQUESTED"}
    if args.auto_run_mred_peak_resolution and not artifact_path(preliminary,"mred_peak_res_anchor"):
        auto_result=ensure_peak_resolution(data_root,data_root/"tables")
    index_path=out_dir/"praycg_analysis_artifact_index_v1_0.json"
    index=build_artifact_index(selected,index_path,include_hashes=True)
    io_issues:List[Dict[str,Any]]=[]
    keys=["amred_anchor","mred_peak_res_summary","hocr_contrasts","confound_summary","tti_global","nupi_summary","cii_anchor","cet_model","dga_summary","eet"]
    tables={key:read_table(key,index,io_issues) for key in keys}
    claims=build_claims(index,tables,io_issues)
    comparisons=build_comparisons(index,args.comparison_folder or [],claims)
    label=args.run_label or data_root.name
    profiles=["technical","research","public"] if args.profile=="all" else [args.profile]
    outputs:Dict[str,str]={"artifact_index":str(index_path)}
    reports:Dict[str,str]={}
    for profile in profiles:
        text=render_report(profile,selected,label,index,claims,io_issues); reports[profile]=text
        md=out_dir/f"offline_interpretive_report_{profile}.md"; md.write_text(text,encoding="utf-8"); outputs[f"{profile}_markdown"]=str(md)
        if profile=="technical":
            txt=out_dir/"offline_interpretive_report_technical.txt"; txt.write_text(text,encoding="utf-8"); outputs["technical_text"]=str(txt)
            hp=out_dir/"offline_interpretive_report_technical.html"; hp.write_text(simple_html(text),encoding="utf-8"); outputs["technical_html"]=str(hp)
    ledger_json=out_dir/"evidence_ledger_v1_0.json"; ledger_csv=out_dir/"evidence_ledger_v1_0.csv"
    ledger={"schema":LEDGER_SCHEMA,"interpreter_schema":SCHEMA,"run_label":label,"claims":claims,"io_issues":io_issues}
    ledger_json.write_text(json.dumps(ledger,indent=2,ensure_ascii=False,default=str),encoding="utf-8")
    flat=[]
    for item in claims:
        row=dict(item); row["evidence"]=json.dumps(row["evidence"],ensure_ascii=False); row["counterevidence"]=" | ".join(row["counterevidence"]); row["limitations"]=" | ".join(row["limitations"]); flat.append(row)
    if flat:
        with ledger_csv.open("w",newline="",encoding="utf-8") as handle:
            writer=csv.DictWriter(handle,fieldnames=list(flat[0])); writer.writeheader(); writer.writerows(flat)
    outputs.update(evidence_ledger_json=str(ledger_json),evidence_ledger_csv=str(ledger_csv))
    summary={"schema":SCHEMA,"version":VERSION,"analysis_folder":str(selected),"resolved_data_root":str(data_root),"run_label":label,"profile":args.profile,"interpretation_gate":index.get("interpretation_gate"),"run":index.get("run",{}),"status_counts":index.get("status_counts",{}),"claim_status_counts":{s:sum(1 for x in claims if x["claim_status"]==s) for s in sorted({x["claim_status"] for x in claims})},"claims":claims,"cross_run_comparisons":comparisons,"artifact_issues":index.get("issues",[]),"io_issues":io_issues,"auto_peak_resolution":auto_result,"outputs":outputs,"boundary":BOUNDARY}
    if args.write_json:
        summary_path=out_dir/"offline_interpretive_report_summary.json"; summary["outputs"]["summary_json"]=str(summary_path); summary_path.write_text(json.dumps(summary,indent=2,ensure_ascii=False,default=str),encoding="utf-8")
    return summary


def main(argv: Optional[List[str]] = None) -> int:
    parser=argparse.ArgumentParser(description="Offline PRAYCG Master Interpreter v1.6.0 — manifest-driven evidence ledger and reports")
    parser.add_argument("--analysis-folder",required=True,help="Core folder, completed chained-analysis folder, or chained workspace.")
    parser.add_argument("--out-dir",default="")
    parser.add_argument("--run-label",default="")
    parser.add_argument("--profile",choices=["all","technical","research","public"],default="all")
    parser.add_argument("--comparison-folder",action="append",default=[],help="Optional additional run folder. Repeat for compatibility/diff review; no automatic pooling is performed.")
    parser.add_argument("--auto-run-mred-peak-resolution",action="store_true")
    parser.add_argument("--write-json",action=argparse.BooleanOptionalAction,default=True)
    args=parser.parse_args(argv)
    try:
        summary=run(args); print(json.dumps({"status":"ok","interpretation_gate":summary["interpretation_gate"],"claim_status_counts":summary["claim_status_counts"],"outputs":summary["outputs"]},indent=2)); return 0
    except Exception as exc:
        print(json.dumps({"status":"error","message":str(exc)},indent=2),file=sys.stderr); return 1


if __name__=="__main__":
    raise SystemExit(main())
