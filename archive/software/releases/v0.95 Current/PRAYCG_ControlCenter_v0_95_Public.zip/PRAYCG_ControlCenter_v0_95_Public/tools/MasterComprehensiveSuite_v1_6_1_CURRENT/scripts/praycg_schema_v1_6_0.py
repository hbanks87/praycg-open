#!/usr/bin/env python3
"""Canonical feature-frame and status helpers for PRAYCG Suite v1.6.0."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, Optional, Tuple

import numpy as np
import pandas as pd

SCHEMA_VERSION = "PRAYCG_AnalysisFrame_v1_6_0"
STATUS_SCHEMA = "PRAYCG_ModuleStatus_v1_6_0"
VALID_STATUSES = {
    "PASS",
    "FAIL_PRIMARY_GATE",
    "NOT_GRADABLE_MISSING_INPUT",
    "NOT_APPLICABLE_PROTOCOL",
    "EXPLORATORY_ONLY",
    "SOFTWARE_ERROR",
}


def robust_z(values: Iterable[Any]) -> np.ndarray:
    x = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=float)
    finite = np.isfinite(x)
    if not finite.any():
        return np.full(len(x), np.nan)
    med = float(np.nanmedian(x))
    mad = float(np.nanmedian(np.abs(x - med)))
    scale = 1.4826 * mad if mad > 1e-12 else float(np.nanstd(x))
    if not np.isfinite(scale) or scale < 1e-12:
        scale = 1.0
    return (x - med) / scale


def normalize_condition(value: Any) -> str:
    s = str(value or "").upper()
    if "BASELINE_2" in s or "BASELINE2" in s or "FINAL_REFLECTION" in s:
        return "BASELINE_2_REFLECTION"
    if "SHOT" in s or "STRUCTURAL" in s:
        return "SHOT_ORDER_SCRAMBLE_1"
    if "OVERRIDE" in s or "CONTEXTUAL" in s:
        return "CONTEXTUAL_OVERRIDE_1"
    if "TARGET" in s:
        return "TARGET_1"
    if "CONTROL" in s or "PHASE" in s:
        return "CONTROL_1"
    if "WASHOUT_1" in s:
        return "WASHOUT_1"
    if "WASHOUT_2" in s:
        return "WASHOUT_2"
    if "WASHOUT_3" in s:
        return "WASHOUT_3"
    if "BASELINE_1" in s or s == "BASELINE":
        return "BASELINE_1"
    return s


def _first_numeric(df: pd.DataFrame, candidates: Iterable[str]) -> Tuple[pd.Series, str]:
    for col in candidates:
        if col in df.columns:
            values = pd.to_numeric(df[col], errors="coerce")
            if values.notna().any():
                return values, col
    return pd.Series(np.nan, index=df.index, dtype=float), ""


def _z_alias(df: pd.DataFrame, candidates: Iterable[str]) -> Tuple[pd.Series, str]:
    raw, source = _first_numeric(df, candidates)
    if not source:
        return raw, source
    return pd.Series(robust_z(raw), index=df.index), source


def canonicalize_feature_frame(
    features: pd.DataFrame,
    segments: Optional[pd.DataFrame] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    """Return one non-duplicated, versioned frame consumed by chained modules.

    Stimulus-style and washout-split rows overlap the core rows. They are excluded from
    this canonical frame to avoid counting the same EEG samples multiple times.
    """
    metadata = metadata or {}
    if features is None or features.empty:
        return pd.DataFrame(columns=["schema_version", "condition", "condition_offset_sec", "time_lsl"])
    df = features.copy()
    if "segment_type" in df.columns and df["segment_type"].astype(str).isin(["core", "recovery"]).any():
        df = df[df["segment_type"].astype(str).isin(["core", "recovery"])].copy()
    segment_col = "segment" if "segment" in df.columns else "phase" if "phase" in df.columns else "condition" if "condition" in df.columns else None
    if segment_col is None:
        df["segment"] = "UNKNOWN"
        segment_col = "segment"
    df["condition"] = df[segment_col].map(normalize_condition)
    time_source = "window_mid" if "window_mid" in df.columns else "time_lsl" if "time_lsl" in df.columns else "time_sec" if "time_sec" in df.columns else None
    df["time_lsl"] = pd.to_numeric(df[time_source], errors="coerce") if time_source else np.nan

    origins: Dict[str, float] = {}
    if segments is not None and not segments.empty and {"segment", "start"}.issubset(segments.columns):
        for _, row in segments.iterrows():
            start = pd.to_numeric(pd.Series([row.get("start")]), errors="coerce").iloc[0]
            if pd.notna(start):
                origins[normalize_condition(row.get("segment"))] = float(start)
    if "condition_offset_sec" in df.columns:
        supplied = pd.to_numeric(df["condition_offset_sec"], errors="coerce")
    elif "rel_mid_sec" in df.columns:
        supplied = pd.to_numeric(df["rel_mid_sec"], errors="coerce")
    else:
        supplied = pd.Series(np.nan, index=df.index, dtype=float)
    calculated = df["time_lsl"] - df["condition"].map(origins)
    df["condition_offset_sec"] = supplied.where(supplied.notna(), calculated)

    alias_map = {
        "meaninggamma_score": ["MeaningGamma_lgamma_30_45", "MeaningGamma_phys", "MeaningGamma", "pow_lgamma_30_45_primary_content_core"],
        "tsp_z": ["TemporalSemanticProxy_lgamma_30_45", "TemporalSemanticProxy", "pow_lgamma_30_45_posterior_temporal"],
        "nas_score": ["NAST_NAS_z", "NAST_NAS", "nas_score"],
        "alpha_drop_proxy_z": ["alpha_drop_proxy_z", "pow_alpha_8_12_posterior", "pow_alpha_8_12_primary_content_core"],
        "gamma_visual_30_45_z": ["gamma_visual_30_45_z", "pow_lgamma_30_45_visual_control", "pow_lgamma_30_45_visual_core"],
        "theta_integration_z": ["theta_integration_z", "pow_theta_4_8_primary_content_core", "pow_theta_4_8_posterior"],
        "taskgamma_score": ["TaskGamma_lgamma_30_45", "TaskGamma_phys", "TaskGamma"],
        "gamma_pt_30_45_z": ["gamma_pt_30_45_z", "pow_lgamma_30_45_posterior_temporal"],
        "gamma_front_35_40_z": ["gamma_front_35_40_z", "pow_g35_40_frontal"],
    }
    for alias, candidates in alias_map.items():
        values, source = _z_alias(df, candidates)
        if alias == "alpha_drop_proxy_z" and source and "drop" not in source.lower():
            values = -values
        df[alias] = values
        df[f"{alias}_source"] = source
    artifact, artifact_source = _z_alias(df, ["artifact_score", "median_p2p", "artifact_p2p_median", "max_p2p"])
    df["artifact_score"] = artifact
    df["artifact_score_source"] = artifact_source
    df["schema_version"] = SCHEMA_VERSION
    df["suite_version"] = str(metadata.get("suite_version", "1.6.0"))
    df["project_name"] = str(metadata.get("project_name", ""))
    df["run_qc_gate_status"] = str(metadata.get("run_qc_gate_status", "UNKNOWN"))
    df["strict_interpretation_allowed"] = bool(metadata.get("strict_interpretation_allowed", False))
    df["feature_row_valid"] = df["time_lsl"].notna() & df["condition_offset_sec"].notna()
    priority = [
        "schema_version", "suite_version", "project_name", "condition", "condition_offset_sec",
        "time_lsl", "feature_row_valid", "run_qc_gate_status", "strict_interpretation_allowed",
        "meaninggamma_score", "tsp_z", "nas_score", "alpha_drop_proxy_z",
        "gamma_visual_30_45_z", "artifact_score", "theta_integration_z", "taskgamma_score",
        "gamma_pt_30_45_z", "gamma_front_35_40_z",
    ]
    remaining = [c for c in df.columns if c not in priority]
    return df[priority + remaining].reset_index(drop=True)


def export_analysis_frame(
    features: pd.DataFrame,
    segments: Optional[pd.DataFrame],
    output_csv: Path,
    metadata: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    frame = canonicalize_feature_frame(features, segments, metadata)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output_csv, index=False)
    schema_path = output_csv.with_name("praycg_analysis_frame_v1_6_0.schema.json")
    schema_path.write_text(json.dumps({
        "schema": SCHEMA_VERSION,
        "rows": int(len(frame)),
        "columns": list(frame.columns),
        "missing_fraction": {c: float(frame[c].isna().mean()) for c in frame.columns},
        "rule": "Missing measurements remain undefined; no absent physiological measure is replaced with zero.",
    }, indent=2), encoding="utf-8")
    return frame


def export_baseline2_summary(frame: pd.DataFrame, output_csv: Path) -> pd.DataFrame:
    """Export explicit Baseline1-to-Baseline2 deltas required by recovery modules."""
    metrics = [
        "meaninggamma_score", "tsp_z", "nas_score", "alpha_drop_proxy_z",
        "gamma_visual_30_45_z", "artifact_score", "theta_integration_z", "taskgamma_score",
    ]
    rows = []
    for metric in metrics:
        if metric not in frame.columns:
            continue
        b1 = pd.to_numeric(frame.loc[frame["condition"].eq("BASELINE_1"), metric], errors="coerce")
        b2 = pd.to_numeric(frame.loc[frame["condition"].eq("BASELINE_2_REFLECTION"), metric], errors="coerce")
        b1_mean = float(b1.mean()) if b1.notna().any() else np.nan
        b2_mean = float(b2.mean()) if b2.notna().any() else np.nan
        rows.append({
            "metric": metric,
            "baseline1_mean": b1_mean,
            "baseline2_mean": b2_mean,
            "delta_B2_minus_B1": b2_mean - b1_mean if np.isfinite(b1_mean) and np.isfinite(b2_mean) else np.nan,
            "baseline1_n": int(b1.notna().sum()),
            "baseline2_n": int(b2.notna().sum()),
        })
    out = pd.DataFrame(rows)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(output_csv, index=False)
    return out


def write_module_status(path: Path, module: str, status: str, message: str, **details: Any) -> Dict[str, Any]:
    if status not in VALID_STATUSES:
        raise ValueError(f"Invalid module status: {status}")
    payload = {"schema": STATUS_SCHEMA, "module": module, "status": status, "message": message, "details": details}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    return payload
