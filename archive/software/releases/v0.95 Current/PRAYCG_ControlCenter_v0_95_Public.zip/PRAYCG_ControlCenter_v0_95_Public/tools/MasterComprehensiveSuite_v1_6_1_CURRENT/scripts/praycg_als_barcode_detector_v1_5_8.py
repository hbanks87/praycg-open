#!/usr/bin/env python3
"""PRAYCG ALS Barcode Detector v1.5.8.

Detects the PRAYCG2.2 runner-level long/short ALS barcode in XDF-derived
analog/ALS data or in a CSV containing time/value columns. Writes branch timing
QC tables for Master Comprehensive Suite interpretation.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

BRANCHES = ["CONTROL_1", "TARGET_1", "CONTEXTUAL_OVERRIDE_1", "OVERRIDE_1"]
DEFAULT_DESIGN = dict(black_pre=0.50, white_a=2.00, black_gap=0.50, white_b=0.75, black_post=1.00)


def finite(x: Any) -> bool:
    try: return math.isfinite(float(x))
    except Exception: return False


def median(xs: Sequence[float]) -> float:
    vals = sorted(float(x) for x in xs if finite(x))
    if not vals: return float('nan')
    n=len(vals); return vals[n//2] if n%2 else 0.5*(vals[n//2-1]+vals[n//2])


def percentile(xs: Sequence[float], q: float) -> float:
    vals = sorted(float(x) for x in xs if finite(x))
    if not vals: return float('nan')
    return vals[max(0, min(int(round((len(vals)-1)*q)), len(vals)-1))]


def find_file(folder: Path, patterns: Sequence[str]) -> Optional[Path]:
    for pat in patterns:
        hits = sorted(folder.rglob(pat))
        if hits: return hits[0]
    return None


def load_events_json(path: Path) -> List[Dict[str, Any]]:
    data = json.loads(path.read_text(encoding='utf-8'))
    if isinstance(data, list): return [x for x in data if isinstance(x, dict)]
    if isinstance(data, dict):
        for key in ('events','markers','rows'):
            if isinstance(data.get(key), list): return [x for x in data[key] if isinstance(x, dict)]
    return []


def marker_time(ev: Dict[str, Any]) -> Optional[float]:
    for k in ('lsl_time','lsl_timestamp','time','timestamp','ts'):
        if finite(ev.get(k)): return float(ev[k])
    return None


def build_marker_index(events: List[Dict[str, Any]]) -> Dict[str, List[float]]:
    out: Dict[str, List[float]] = {}
    for ev in events:
        marker = str(ev.get('marker',''))
        t = marker_time(ev)
        if marker and t is not None:
            out.setdefault(marker, []).append(t)
    return out


def load_als_csv(path: Path) -> Tuple[List[float], List[float]]:
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    if not rows: return [], []
    cols = rows[0].keys()
    time_col = next((c for c in cols if c.lower() in {'time','time_sec','timestamp','lsl_time','t'}), None)
    val_col = next((c for c in cols if c.lower() in {'als','als_value','value','aux','light','photo','photodiode'}), None)
    if val_col is None:
        candidates = [c for c in cols if c != time_col]
        val_col = candidates[-1] if candidates else None
    if time_col is None or val_col is None: return [], []
    times=[]; vals=[]
    for r in rows:
        if finite(r.get(time_col)) and finite(r.get(val_col)):
            times.append(float(r[time_col])); vals.append(float(r[val_col]))
    return times, vals


def load_xdf_als(path: Path, stream_name: str, channel_index: int) -> Tuple[List[float], List[float], str]:
    try:
        import pyxdf  # type: ignore
    except Exception as exc:
        return [], [], f'pyxdf unavailable: {exc!r}'
    try:
        streams, _ = pyxdf.load_xdf(str(path))
        best = None
        for s in streams:
            name = str(s.get('info',{}).get('name',[''])[0])
            typ = str(s.get('info',{}).get('type',[''])[0])
            if stream_name and name == stream_name:
                best = s; break
            if best is None and ('OpenBCI' in name or 'obci' in name.lower() or typ.upper() in {'EEG','AUX'}):
                best = s
        if best is None: return [], [], 'No EEG/AUX-like XDF stream found.'
        ts = [float(x) for x in best.get('time_stamps', [])]
        data = best.get('time_series', [])
        if len(ts) == 0 or len(data) == 0: return [], [], 'Chosen XDF stream is empty.'
        # channel_index is 1-based; -1 = last channel.
        vals=[]
        for row in data:
            try:
                idx = len(row)-1 if channel_index == -1 else max(0, min(len(row)-1, channel_index-1))
                vals.append(float(row[idx]))
            except Exception:
                vals.append(float('nan'))
        return ts, vals, f'XDF stream={best.get("info",{}).get("name",[""])[0]}; channel_index={channel_index}'
    except Exception as exc:
        return [], [], repr(exc)


def segment(times: Sequence[float], vals: Sequence[float], start: float, end: float) -> List[float]:
    return [v for t,v in zip(times, vals) if start <= t < end and finite(v)]


def score_window(times: List[float], vals: List[float], event_t: float, design: Dict[str,float], search_shift: float = 0.0) -> Dict[str, Any]:
    # Event marker is barcode start. Score absolute segments relative to event_t+shift.
    t0 = event_t + search_shift
    b1s, b1e = t0, t0 + design['black_pre']
    a_s, a_e = b1e, b1e + design['white_a']
    g_s, g_e = a_e, a_e + design['black_gap']
    b_s, b_e = g_e, g_e + design['white_b']
    p_s, p_e = b_e, b_e + design['black_post']
    b1=segment(times,vals,b1s,b1e); a=segment(times,vals,a_s,a_e); g=segment(times,vals,g_s,g_e); b=segment(times,vals,b_s,b_e); post=segment(times,vals,p_s,p_e)
    black = b1 + g + post; white = a + b
    med_black = median(black); med_white = median(white); amp = med_white - med_black if finite(med_white) and finite(med_black) else float('nan')
    finite_vals = [x for x in segment(times, vals, b1s, p_e) if finite(x)]
    span = (max(finite_vals)-min(finite_vals)) if finite_vals else float('nan')
    score=0.0
    for x,y in [(median(a),median(b1)),(median(a),median(g)),(median(b),median(g)),(median(b),median(post))]:
        if finite(x) and finite(y): score += max(0.0, x-y)
    clipped=False
    if finite_vals and finite(span) and span > 0:
        p99=percentile(finite_vals,.99)
        clipped = (sum(1 for x in finite_vals if x >= p99-1e-12)/len(finite_vals)) > .95
    if clipped: status='CLIPPED'
    elif finite(amp) and finite(span) and amp > max(1e-6, .10*max(abs(span),1e-6)) and score>0: status='PASS'
    elif finite(amp) and amp > 0: status='WEAK'
    else: status='MISSING'
    content_start_est = p_e
    return dict(status=status, shift_sec=search_shift, barcode_score_raw=score, amp=amp, span=span, clipped=clipped,
                n_samples=len(finite_vals), t_barcode_start=t0, t_pulse_a_start=a_s, t_pulse_b_start=b_s, t_content_start_est=content_start_est,
                median_black=med_black, median_white=med_white)


def detect_branch(times: List[float], vals: List[float], marker_index: Dict[str,List[float]], branch: str, design: Dict[str,float]) -> Dict[str, Any]:
    keys = [f'{branch}_ALS_BARCODE_START', f'{branch}_ALS_PULSE_A_START']
    event_t = None; source_marker=''
    for k in keys:
        if marker_index.get(k):
            event_t = marker_index[k][0]; source_marker=k; break
    if event_t is None:
        return dict(branch=branch, status='NO_MARKER', reason='No ALS barcode marker found for branch.')
    # Try a small grid of shifts in case event was logged at first white pulse, not barcode start.
    shifts = [0.0, -design['black_pre'], 0.05, -0.05]
    scored = [score_window(times, vals, event_t, design, s) for s in shifts]
    order = {'PASS':0,'WEAK':1,'CLIPPED':2,'MISSING':3}
    best = sorted(scored, key=lambda d: (order.get(d['status'],9), -float(d.get('barcode_score_raw') or 0)))[0]
    content_marker = marker_index.get(f'{branch}_ALS_CONTENT_START') or marker_index.get(f'{branch}_START') or []
    lsl_content = content_marker[0] if content_marker else None
    best.update(branch=branch, source_marker=source_marker, event_lsl=event_t, lsl_content_start=lsl_content)
    if lsl_content is not None and finite(best.get('t_content_start_est')):
        best['als_minus_lsl_content_offset_sec'] = best['t_content_start_est'] - float(lsl_content)
    return best


def write_csv(path: Path, rows: List[Dict[str,Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields=[]
    for r in rows:
        for k in r:
            if k not in fields: fields.append(k)
    with path.open('w', encoding='utf-8', newline='') as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)


def grade(rows: List[Dict[str,Any]]) -> str:
    required = [r for r in rows if r.get('branch') in {'CONTROL_1','TARGET_1','CONTEXTUAL_OVERRIDE_1'}]
    if not required: return 'NO_BARCODE_MARKERS'
    statuses = [r.get('status') for r in required]
    if all(s == 'PASS' for s in statuses): return 'TIMING_GRADE_STRONG'
    if any(s == 'PASS' for s in statuses) and all(s in {'PASS','WEAK','CLIPPED'} for s in statuses): return 'TIMING_GRADE_PARTIAL'
    if any(s in {'PASS','WEAK'} for s in statuses): return 'TIMING_GRADE_WEAK'
    return 'TIMING_GRADE_FAIL_OR_LSL_ONLY'


def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--analysis-folder', default='')
    ap.add_argument('--xdf', default='')
    ap.add_argument('--events-json', default='')
    ap.add_argument('--als-csv', default='')
    ap.add_argument('--out-dir', default='')
    ap.add_argument('--stream-name', default='obci_eeg1')
    ap.add_argument('--channel-index', type=int, default=-1)
    ap.add_argument('--black-pre-sec', type=float, default=.50)
    ap.add_argument('--white-a-sec', type=float, default=2.00)
    ap.add_argument('--black-gap-sec', type=float, default=.50)
    ap.add_argument('--white-b-sec', type=float, default=.75)
    ap.add_argument('--black-post-sec', type=float, default=1.00)
    args=ap.parse_args()
    folder=Path(args.analysis_folder).expanduser() if args.analysis_folder else Path.cwd()
    out=Path(args.out_dir).expanduser() if args.out_dir else folder/'als_barcode_detector_v1_5_8'
    out.mkdir(parents=True, exist_ok=True)
    xdf=Path(args.xdf).expanduser() if args.xdf else find_file(folder, ['*.xdf'])
    evjson=Path(args.events_json).expanduser() if args.events_json else find_file(folder, ['*_events.json','*events*.json'])
    alscsv=Path(args.als_csv).expanduser() if args.als_csv else find_file(folder, ['*als*.csv','*aux*.csv','*light*.csv'])
    events=[]
    if evjson and evjson.exists(): events=load_events_json(evjson)
    marker_idx=build_marker_index(events)
    note=''
    times: List[float]=[]; vals: List[float]=[]
    if alscsv and alscsv.exists():
        times, vals=load_als_csv(alscsv); note=f'ALS CSV={alscsv}'
    elif xdf and xdf.exists():
        times, vals, note=load_xdf_als(xdf, args.stream_name, args.channel_index)
    else:
        note='No ALS CSV or XDF found.'
    design=dict(black_pre=args.black_pre_sec, white_a=args.white_a_sec, black_gap=args.black_gap_sec, white_b=args.white_b_sec, black_post=args.black_post_sec)
    rows=[detect_branch(times, vals, marker_idx, b, design) for b in BRANCHES]
    # Remove duplicate alias if both contextual and override represent same event but keep both for transparency.
    g=grade(rows)
    write_csv(out/'tables'/'als_barcode_qc.csv', rows)
    write_csv(out/'tables'/'als_barcode_branch_offsets.csv', [r for r in rows if 'als_minus_lsl_content_offset_sec' in r or r.get('status')])
    overlay=[]
    for r in rows:
        if finite(r.get('t_barcode_start')):
            overlay.append({'time_sec': r['t_barcode_start'], 'event_type':'als_barcode', 'label': f"{r['branch']} {r['status']}", 'branch': r['branch']})
        if finite(r.get('t_content_start_est')):
            overlay.append({'time_sec': r['t_content_start_est'], 'event_type':'als_content_start_est', 'label': f"{r['branch']} content_est", 'branch': r['branch']})
    write_csv(out/'tables'/'als_barcode_visual_overlay.csv', overlay)
    report={'schema':'PRAYCG_ALS_Barcode_Detector_v1_5_8','created_utc':datetime.utcnow().isoformat()+'Z','analysis_folder':str(folder),'events_json':str(evjson) if evjson else None,'xdf':str(xdf) if xdf else None,'als_csv':str(alscsv) if alscsv else None,'data_note':note,'design':design,'timing_grade':g,'branches':rows,'boundary':'ALS barcode validates display timing only; it does not certify biological endpoints.'}
    (out/'tables'/'als_barcode_detection_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    md=['# PRAYCG ALS Barcode Detection Report v1.5.8','',f'Created UTC: {report["created_utc"]}',f'Timing grade: **{g}**','',f'Data note: `{note}`','', '## Branch results', '']
    for r in rows:
        md.append(f"- {r.get('branch')}: {r.get('status')} score={r.get('barcode_score_raw','')} offset={r.get('als_minus_lsl_content_offset_sec','')}")
    md += ['', 'Boundary: ALS barcode validates physical display timing only; it is not a biological endpoint.']
    (out/'reports').mkdir(exist_ok=True)
    (out/'reports'/'als_barcode_detection_report.md').write_text('\n'.join(md),encoding='utf-8')
    print(json.dumps({'out_dir':str(out),'timing_grade':g}, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
