#!/usr/bin/env python3
"""
PRAYCG Confound-Expanded Modules v1.5.7
HOC-R / OSA / OHC / AAM / RespDualPath

This module is a rule-based, offline post-processing extension for the PRAYCG
Master Comprehensive Analysis Suite. It does not certify meaning or mechanism.
It adds explicit confound-accounting outputs for:
  - high-order visual/social controls not captured by phase scrambling
  - spatial-attention/AOI burden created by fixed cue monitoring
  - order, habituation, and carryover limitations
  - narrative afterglow versus task-completion relief attribution
  - respiratory artifact versus respiratory state-event separation
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

APP_VERSION = "1.5.7"
SCHEMA = "PRAYCG_confound_expanded_modules_v1_5_7"

# ---------------------------------------------------------------------
# Basic utilities
# ---------------------------------------------------------------------

def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_json_load(path: Path) -> Optional[Dict[str, Any]]:
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return None


def safe_csv_load(path: Path) -> Optional[pd.DataFrame]:
    try:
        return pd.read_csv(path)
    except Exception:
        try:
            return pd.read_csv(path, encoding="utf-8-sig")
        except Exception:
            return None


def find_files(root: Path, pats: Sequence[str]) -> List[Path]:
    if not root or not root.exists():
        return []
    out: List[Path] = []
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        name = p.name.lower()
        for pat in pats:
            if pat.lower() in name:
                out.append(p)
                break
    return sorted(out)


def find_first(root: Path, pats: Sequence[str]) -> Optional[Path]:
    hits = find_files(root, pats)
    return hits[0] if hits else None


def coerce_float(x: Any, default: float = np.nan) -> float:
    try:
        if x is None:
            return default
        y = float(x)
        return y if math.isfinite(y) else default
    except Exception:
        return default


def numeric_cols(df: pd.DataFrame) -> List[str]:
    out = []
    for c in df.columns:
        if pd.api.types.is_numeric_dtype(df[c]):
            out.append(c)
    return out


def markdown_table(df: pd.DataFrame) -> str:
    """Render a readable table without requiring pandas' optional tabulate package."""
    try:
        return df.to_markdown(index=False)
    except ImportError:
        return "```text\n" + df.to_string(index=False, na_rep="NA") + "\n```"


def norm01(x: Any, lo: float = 0.0, hi: float = 9.0) -> float:
    y = coerce_float(x)
    if not math.isfinite(y):
        return np.nan
    if hi == lo:
        return np.nan
    return float(max(0.0, min(1.0, (y - lo) / (hi - lo))))


def inv_norm01(x: Any, lo: float = 0.0, hi: float = 9.0) -> float:
    y = norm01(x, lo, hi)
    return np.nan if not math.isfinite(y) else 1.0 - y


def sigmoid(x: float) -> float:
    if not math.isfinite(x):
        return np.nan
    if x >= 50:
        return 1.0
    if x <= -50:
        return 0.0
    return float(1.0 / (1.0 + math.exp(-x)))


def z(v: Sequence[float]) -> np.ndarray:
    a = np.asarray([coerce_float(x) for x in v], dtype=float)
    m = np.nanmean(a) if np.isfinite(a).any() else np.nan
    s = np.nanstd(a) if np.isfinite(a).any() else np.nan
    if not math.isfinite(m) or not math.isfinite(s) or s == 0:
        return np.zeros_like(a, dtype=float)
    return (a - m) / s


def mean_present(vals: Iterable[Any]) -> float:
    arr = [coerce_float(v) for v in vals]
    arr = [v for v in arr if math.isfinite(v)]
    return float(np.mean(arr)) if arr else np.nan


def cosine(a: Sequence[float], b: Sequence[float]) -> float:
    x = np.asarray([coerce_float(v, 0.0) for v in a], dtype=float)
    y = np.asarray([coerce_float(v, 0.0) for v in b], dtype=float)
    if len(x) == 0 or len(x) != len(y):
        return np.nan
    den = float(np.linalg.norm(x) * np.linalg.norm(y))
    if den == 0:
        return np.nan
    return float(np.dot(x, y) / den)


def simple_ols_r2(y: np.ndarray, X: np.ndarray) -> Tuple[float, int, str]:
    # Add intercept and fit by least squares. Returns train R2 only.
    try:
        mask = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
        y2 = y[mask]
        X2 = X[mask]
        if len(y2) < max(10, X2.shape[1] + 3):
            return np.nan, int(len(y2)), "too_few_rows"
        Xd = np.column_stack([np.ones(len(X2)), X2])
        beta, *_ = np.linalg.lstsq(Xd, y2, rcond=None)
        pred = Xd @ beta
        ss_res = float(np.sum((y2 - pred) ** 2))
        ss_tot = float(np.sum((y2 - np.mean(y2)) ** 2))
        if ss_tot <= 0:
            return np.nan, int(len(y2)), "zero_variance_y"
        return float(1.0 - ss_res / ss_tot), int(len(y2)), "ok"
    except Exception as exc:
        return np.nan, 0, f"fit_error:{exc}"


def guess_condition_col(df: pd.DataFrame) -> Optional[str]:
    for c in df.columns:
        cl = c.lower()
        if cl in {"condition", "phase", "branch", "condition_label", "phase_name"}:
            return c
    for c in df.columns:
        if "condition" in c.lower() or "phase" in c.lower():
            return c
    return None


def normalize_condition(x: Any) -> str:
    s = str(x).lower()
    if "target" in s:
        return "target"
    if "override" in s or "contextual" in s:
        return "override"
    if "control" in s:
        return "control"
    if "baseline_2" in s or "baseline2" in s or "final_reflection" in s:
        return "baseline2"
    if "baseline_1" in s or "baseline1" in s:
        return "baseline1"
    if "washout_2" in s or "washout2" in s:
        return "washout2"
    if "washout_3" in s or "washout3" in s:
        return "washout3"
    if "washout_1" in s or "washout1" in s:
        return "washout1"
    return s.strip() or "unknown"


@dataclass
class Inputs:
    analysis_folder: Path
    stimulus_fingerprint_folder: Optional[Path]
    run_log_folder: Optional[Path]
    out_folder: Path
    tables: Path
    reports: Path
    feature_df: Optional[pd.DataFrame]
    feature_path: Optional[Path]
    stim_df: Optional[pd.DataFrame]
    stim_path: Optional[Path]
    run_config: Optional[Dict[str, Any]]
    run_config_path: Optional[Path]
    core_reports: List[Tuple[Path, Dict[str, Any]]]
    confound_reports: List[Tuple[Path, Dict[str, Any]]]
    final_report: Optional[Tuple[Path, Dict[str, Any]]]
    override_task_report: Optional[Tuple[Path, Dict[str, Any]]]


# ---------------------------------------------------------------------
# Input discovery
# ---------------------------------------------------------------------

def discover_inputs(analysis_folder: Path, stim_folder: Optional[Path], run_folder: Optional[Path], out_folder: Optional[Path]) -> Inputs:
    out = out_folder or analysis_folder
    tables = ensure_dir(out / "tables")
    reports = ensure_dir(out / "reports")

    feature_path = None
    for pats in [
        ["praycg_analysis_frame_v1_6_0"],
        ["time_resolved_feature_frame"],
        ["feature_frame"],
        ["nip_mred_component_timeseries"],
        ["features_used"],
    ]:
        feature_path = find_first(analysis_folder, pats)
        if feature_path:
            break
    feature_df = safe_csv_load(feature_path) if feature_path else None

    search_roots = [analysis_folder]
    if stim_folder:
        search_roots.append(stim_folder)
    stim_path = None
    for r in search_roots:
        for pats in [["stimulus_exogenous_regressor_frame_all_conditions"], ["cet_regressors_all_conditions"], ["stimulus_exogenous"]]:
            stim_path = find_first(r, pats)
            if stim_path:
                break
        if stim_path:
            break
    stim_df = safe_csv_load(stim_path) if stim_path else None

    # Run config and reports may live beside events, in analysis input snapshot, or direct run log folder.
    log_roots = [analysis_folder]
    if run_folder:
        log_roots.insert(0, run_folder)
    run_config_path = None
    for r in log_roots:
        run_config_path = find_first(r, ["run_config_media_selection"])
        if run_config_path:
            break
    run_config = safe_json_load(run_config_path) if run_config_path else None

    jsons: List[Path] = []
    for r in log_roots:
        jsons += find_files(r, [".json"])
    seen = set(); uniq = []
    for p in jsons:
        if p not in seen:
            seen.add(p); uniq.append(p)

    core_reports = []
    confound_reports = []
    final_report = None
    override_task_report = None
    for p in uniq:
        name = p.name.lower()
        obj = safe_json_load(p)
        if not isinstance(obj, dict):
            continue
        if "core_report" in name:
            core_reports.append((p, obj))
        elif "confound_report" in name:
            confound_reports.append((p, obj))
        elif "final_master_report" in name:
            final_report = (p, obj)
        elif "override_task_report" in name:
            override_task_report = (p, obj)

    return Inputs(
        analysis_folder=analysis_folder,
        stimulus_fingerprint_folder=stim_folder,
        run_log_folder=run_folder,
        out_folder=out,
        tables=tables,
        reports=reports,
        feature_df=feature_df,
        feature_path=feature_path,
        stim_df=stim_df,
        stim_path=stim_path,
        run_config=run_config,
        run_config_path=run_config_path,
        core_reports=core_reports,
        confound_reports=confound_reports,
        final_report=final_report,
        override_task_report=override_task_report,
    )


def branch_report_table(inp: Inputs) -> pd.DataFrame:
    rows = []
    for p, obj in inp.core_reports:
        ratings = obj.get("ratings", {}) or {}
        branch = str(obj.get("branch_type") or obj.get("branch_label") or obj.get("phase_name") or p.name)
        row = {"source_file": str(p), "report_type": "core", "branch": normalize_condition(branch), "raw_branch": branch}
        for k, v in ratings.items():
            row[k] = coerce_float(v)
        row["scene_note"] = obj.get("scene_note", "")
        rows.append(row)
    for p, obj in inp.confound_reports:
        ratings = obj.get("ratings", {}) or {}
        branch = str(obj.get("branch_label") or obj.get("phase_name") or p.name)
        row = {"source_file": str(p), "report_type": "confound", "branch": normalize_condition(branch), "raw_branch": branch}
        for k, v in ratings.items():
            row[k] = coerce_float(v)
        notes = obj.get("notes", {}) or {}
        row["notes"] = json.dumps(notes, ensure_ascii=False)
        rows.append(row)
    if inp.final_report:
        p, obj = inp.final_report
        ratings = obj.get("ratings", {}) or {}
        row = {"source_file": str(p), "report_type": "final", "branch": "final", "raw_branch": "final"}
        for k, v in ratings.items():
            row[k] = coerce_float(v)
        row["choices"] = json.dumps(obj.get("choices", {}), ensure_ascii=False)
        row["final_scene_note"] = obj.get("final_scene_note", "")
        rows.append(row)
    if inp.override_task_report:
        p, obj = inp.override_task_report
        ratings = obj.get("ratings", {}) or {}
        row = {"source_file": str(p), "report_type": "override_task", "branch": "override", "raw_branch": "override_task"}
        for k, v in ratings.items():
            row[k] = coerce_float(v)
        row["note"] = obj.get("note", "")
        rows.append(row)
    return pd.DataFrame(rows)


def rating(df: pd.DataFrame, branch: str, col: str, report_type: Optional[str] = None) -> float:
    if df is None or df.empty or col not in df.columns:
        return np.nan
    sub = df[df["branch"].eq(branch)]
    if report_type:
        sub = sub[sub["report_type"].eq(report_type)]
    vals = pd.to_numeric(sub[col], errors="coerce").dropna()
    return float(vals.iloc[-1]) if len(vals) else np.nan


# ---------------------------------------------------------------------
# HOC-R: High-Order Control Residualization
# ---------------------------------------------------------------------

def run_hocr(inp: Inputs, rep_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    candidate_outcomes = []
    feature_df = inp.feature_df
    stim_df = inp.stim_df

    if feature_df is not None:
        for c in feature_df.columns:
            lc = c.lower()
            if any(k in lc for k in ["nip", "tsp", "meaninggamma", "mred", "theta", "gamma"]):
                if pd.api.types.is_numeric_dtype(feature_df[c]):
                    candidate_outcomes.append(c)

    regressor_terms = {
        "low_level_visual": ["luminance", "visual_change", "hist", "flow", "motion", "cut", "flash"],
        "low_level_audio": ["audio", "rms", "dbfs", "envelope"],
        "cue_structure": ["cue", "number"],
        "high_order_social_visual": ["face", "body", "biological", "person", "object", "edge", "saliency", "closeup"],
    }

    status = "NO_STIMULUS_REGRESSORS"
    if stim_df is not None and not stim_df.empty:
        status = "STIMULUS_REGRESSORS_FOUND"

    # Column inventory.
    stim_cols = list(stim_df.columns) if stim_df is not None else []
    inv = {group: [] for group in regressor_terms}
    for group, terms in regressor_terms.items():
        for c in stim_cols:
            if any(t in c.lower() for t in terms) and pd.api.types.is_numeric_dtype(stim_df[c]):
                inv[group].append(c)

    high_order_status = "HIGH_ORDER_COLUMNS_PRESENT" if inv["high_order_social_visual"] else "HIGH_ORDER_COLUMNS_MISSING_FACE_BODY_OBJECT_AOI_NOT_MODELED"

    # Fit simple residualization if possible by merging by condition/time-ish columns only if same length.
    fit_results = []
    if feature_df is not None and stim_df is not None and not feature_df.empty and not stim_df.empty:
        # Select regressors from all groups.
        reg_cols = []
        for cols in inv.values():
            reg_cols.extend(cols)
        reg_cols = list(dict.fromkeys(reg_cols))[:24]
        if reg_cols and candidate_outcomes:
            n = min(len(feature_df), len(stim_df))
            X = stim_df[reg_cols].iloc[:n].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
            for outcome in candidate_outcomes[:12]:
                y = pd.to_numeric(feature_df[outcome].iloc[:n], errors="coerce").to_numpy(dtype=float)
                r2, nfit, msg = simple_ols_r2(y, X)
                fit_results.append((outcome, r2, nfit, msg, reg_cols))

    if fit_results:
        for outcome, r2, nfit, msg, reg_cols in fit_results:
            rows.append({
                "module": "HOC-R_v0.1",
                "outcome": outcome,
                "status": status,
                "high_order_status": high_order_status,
                "train_r2": r2,
                "n_rows_fit": nfit,
                "fit_message": msg,
                "low_level_visual_cols": ";".join(inv["low_level_visual"]),
                "low_level_audio_cols": ";".join(inv["low_level_audio"]),
                "cue_cols": ";".join(inv["cue_structure"]),
                "high_order_cols": ";".join(inv["high_order_social_visual"]),
                "interpretation": "Residualization audit only. Target-vs-Control differences remain vulnerable to face/object/biological-motion differences if high-order columns are missing."
            })
    else:
        rows.append({
            "module": "HOC-R_v0.1",
            "outcome": "not_fit",
            "status": status,
            "high_order_status": high_order_status,
            "train_r2": np.nan,
            "n_rows_fit": 0,
            "fit_message": "missing_feature_or_stimulus_regressors_or_no_numeric_overlap",
            "low_level_visual_cols": ";".join(inv["low_level_visual"]),
            "low_level_audio_cols": ";".join(inv["low_level_audio"]),
            "cue_cols": ";".join(inv["cue_structure"]),
            "high_order_cols": ";".join(inv["high_order_social_visual"]),
            "interpretation": "HOC-R incomplete. Phase-scrambled Control is sensory-control, not a face/object/social-structure matched meaning-null."
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------
# OSA: Override Spatial Attention / AOI Burden
# ---------------------------------------------------------------------

def run_osa(inp: Inputs, rep_df: pd.DataFrame) -> pd.DataFrame:
    cfg = ((inp.run_config or {}).get("config") or {})
    cue_summary = ((inp.run_config or {}).get("cue_schedule_summary") or {})
    cue_design = cue_summary.get("cue_design", {}) if isinstance(cue_summary, dict) else {}

    interval = coerce_float(cue_design.get("interval_sec", np.nan))
    duration = coerce_float(cue_design.get("display_duration_sec", np.nan))
    position = cue_design.get("position", "unknown")
    fixed_reason = cue_design.get("fixed_position_reason", "")
    if not math.isfinite(interval):
        interval = np.nan
    if not math.isfinite(duration):
        duration = np.nan
    duty = duration / interval if math.isfinite(duration) and math.isfinite(interval) and interval > 0 else np.nan

    cue_leg = rating(rep_df, "override", "CueLegibilityProblem", "override_task")
    cue_blur = rating(rep_df, "override", "CueBlurOrSmallness", "confound")
    eye_strain = rating(rep_df, "override", "EyeStrainOrSquint", "confound")
    running_stall = rating(rep_df, "override", "RunningSumStall", "override_task")
    task_load = rating(rep_df, "override", "TaskExtractionLoad", "core")

    cue_report_burden = mean_present([norm01(cue_leg), norm01(cue_blur), norm01(eye_strain), norm01(running_stall), norm01(task_load)])
    cue_duty_component = duty if math.isfinite(duty) else np.nan
    osa_score = mean_present([cue_duty_component, cue_report_burden])

    gaze_available = False
    # Look for any gaze/AOI file or columns.
    if find_files(inp.analysis_folder, ["gaze", "eye_tracker", "aoi"]):
        gaze_available = True
    if inp.feature_df is not None:
        if any(any(t in c.lower() for t in ["gaze", "aoi", "fixation", "saccade"]) for c in inp.feature_df.columns):
            gaze_available = True

    flag = bool((math.isfinite(osa_score) and osa_score >= 0.35) and not gaze_available)
    return pd.DataFrame([{
        "module": "OSA_v0.1",
        "cue_position": position,
        "fixed_position_reason": fixed_reason,
        "cue_interval_sec": interval,
        "cue_display_duration_sec": duration,
        "cue_duty_cycle": cue_duty_component,
        "override_cue_legibility_0_9": cue_leg,
        "override_cue_blur_0_9": cue_blur,
        "override_eye_strain_0_9": eye_strain,
        "override_running_sum_stall_0_9": running_stall,
        "override_task_load_0_9": task_load,
        "cue_report_burden_0_1": cue_report_burden,
        "osa_burden_score_0_1": osa_score,
        "gaze_or_aoi_data_found": gaze_available,
        "spatial_attention_confounded_flag": flag,
        "interpretation": "Override differences may reflect cue monitoring, peripheral attention, and foveal sampling differences unless gaze/AOI or cue-monitor controls are available."
    }])


# ---------------------------------------------------------------------
# OHC: Order / Habituation / Carryover
# ---------------------------------------------------------------------

def run_ohc(inp: Inputs, rep_df: pd.DataFrame) -> pd.DataFrame:
    cfg = ((inp.run_config or {}).get("config") or {})
    order = ["control", "target", "override"]
    sequence = "CONTROL_TARGET_OVERRIDE_DEFAULT"
    # Try infer from feature phases order if possible.
    if inp.feature_df is not None and not inp.feature_df.empty:
        cond_col = guess_condition_col(inp.feature_df)
        if cond_col:
            seen = []
            for v in inp.feature_df[cond_col].dropna().tolist():
                c = normalize_condition(v)
                if c in ["control", "target", "override"] and c not in seen:
                    seen.append(c)
            if seen:
                order = seen
                sequence = "_".join(x.upper() for x in seen)

    washout = coerce_float(cfg.get("washout_seconds", np.nan))
    baseline2 = coerce_float(cfg.get("final_reflection_baseline_seconds", np.nan))
    counterbalanced = not (order == ["control", "target", "override"])
    default_risk = 1.0 if order == ["control", "target", "override"] else 0.5
    target_before_override = order.index("target") < order.index("override") if "target" in order and "override" in order else True
    habituation_risk = default_risk if target_before_override else 0.4
    endocrine_reset_assumption_ok = bool(math.isfinite(washout) and washout >= 600)  # conservative long washout
    carryover_risk = 0.8 if not endocrine_reset_assumption_ok else 0.3

    return pd.DataFrame([{
        "module": "OHC_v0.1",
        "sequence_inferred": sequence,
        "branch_order": ">".join(order),
        "counterbalanced_order": counterbalanced,
        "target_before_override": target_before_override,
        "washout_seconds": washout,
        "baseline2_seconds": baseline2,
        "habituation_risk_0_1": habituation_risk,
        "carryover_risk_0_1": carryover_risk,
        "washout_reset_assumption": "NOT_ASSUMED_RESET" if not endocrine_reset_assumption_ok else "LONG_WASHOUT_PARTIAL_RESET_POSSIBLE",
        "sequence_confounded_flag": bool(order == ["control", "target", "override"]),
        "interpretation": "A 120 s washout should be interpreted as an after-state measurement, not a full endocrine/autonomic reset. Fixed Control→Target→Override order cannot isolate task effects from habituation."
    }])


# ---------------------------------------------------------------------
# AAM: Afterglow Attribution Model
# ---------------------------------------------------------------------

def condition_vector(df: pd.DataFrame, condition: str, cols: List[str]) -> List[float]:
    cond_col = guess_condition_col(df)
    if not cond_col:
        return []
    sub = df[df[cond_col].apply(normalize_condition).eq(condition)]
    if sub.empty:
        return []
    vals = []
    for c in cols:
        vals.append(float(pd.to_numeric(sub[c], errors="coerce").mean()))
    return vals


def run_aam(inp: Inputs, rep_df: pd.DataFrame) -> pd.DataFrame:
    feature_df = inp.feature_df
    sim_b2_w2 = np.nan
    sim_b2_w3 = np.nan
    sim_diff = np.nan

    if feature_df is not None and not feature_df.empty:
        cols = []
        for c in numeric_cols(feature_df):
            lc = c.lower()
            if any(k in lc for k in ["tsp", "nip", "theta", "alpha", "meaninggamma", "taskgamma", "hr", "rmssd", "sdnn", "resp"]):
                cols.append(c)
        cols = cols[:30]
        if cols:
            b2 = condition_vector(feature_df, "baseline2", cols)
            w2 = condition_vector(feature_df, "washout2", cols)
            w3 = condition_vector(feature_df, "washout3", cols)
            if b2 and w2:
                sim_b2_w2 = cosine(b2, w2)
            if b2 and w3:
                sim_b2_w3 = cosine(b2, w3)
            if math.isfinite(sim_b2_w2) and math.isfinite(sim_b2_w3):
                sim_diff = sim_b2_w2 - sim_b2_w3

    final_echo = np.nan
    if inp.final_report:
        final_echo = norm01(inp.final_report[1].get("ratings", {}).get("TargetEchoedDuringBaseline2"))
    target_afterglow = norm01(rating(rep_df, "target", "EmotionalAfterglow", "core"))
    target_story_washout = norm01(rating(rep_df, "target", "StoryActiveWashout", "core"))
    override_task_load = norm01(rating(rep_df, "override", "TaskExtractionLoad", "core"))
    task_compliance = norm01(rating(rep_df, "override", "TaskCompliance", "override_task"))
    running_stall = norm01(rating(rep_df, "override", "RunningSumStall", "override_task"))
    resp_conf = mean_present([norm01(rating(rep_df, "target", "ConfoundBurden", "core")), norm01(rating(rep_df, "override", "ConfoundBurden", "core"))])

    # If a similarity cannot be computed, use reports only.
    nai = mean_present([sim_b2_w2 if math.isfinite(sim_b2_w2) else np.nan, final_echo, target_afterglow, target_story_washout])
    tcri = mean_present([override_task_load, task_compliance, running_stall, (sim_b2_w3 if math.isfinite(sim_b2_w3) else np.nan)])
    aam = nai - tcri if math.isfinite(nai) and math.isfinite(tcri) else np.nan
    if not math.isfinite(aam):
        cls = "AAM_NOT_GRADABLE"
    elif aam > 0.20:
        cls = "TARGET_AFTERGLOW_LIKE"
    elif aam < -0.20:
        cls = "TASK_COMPLETION_RELIEF_LIKE"
    else:
        cls = "MIXED_OR_AMBIGUOUS_AFTERGLOW_ATTRIBUTION"

    return pd.DataFrame([{
        "module": "AAM_v0.1",
        "similarity_Baseline2_to_Washout2_Target": sim_b2_w2,
        "similarity_Baseline2_to_Washout3_Override": sim_b2_w3,
        "similarity_target_minus_override": sim_diff,
        "target_echoed_baseline2_0_1": final_echo,
        "target_emotional_afterglow_0_1": target_afterglow,
        "target_story_active_washout_0_1": target_story_washout,
        "override_task_load_0_1": override_task_load,
        "override_task_compliance_0_1": task_compliance,
        "override_running_stall_0_1": running_stall,
        "resp_or_confound_burden_0_1": resp_conf,
        "NAI_narrative_afterglow_index": nai,
        "TCRI_task_completion_relief_index": tcri,
        "AAM_afterglow_minus_task_relief": aam,
        "classification": cls,
        "interpretation": "Baseline2 is cumulative. This model only attributes whether the pattern is more Target-afterglow-like or task-relief-like; it does not prove narrative integration."
    }])


# ---------------------------------------------------------------------
# RespDualPath
# ---------------------------------------------------------------------

def run_resp_dual(inp: Inputs, rep_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    feature_df = inp.feature_df
    rows = []
    summary = []
    resp_cols = []
    if feature_df is not None and not feature_df.empty:
        for c in numeric_cols(feature_df):
            lc = c.lower()
            if any(k in lc for k in ["resp", "breath", "force_n", "force"]):
                resp_cols.append(c)
    # v1.6.0 canonical frames provide a raw-window mean.  Prefer that single
    # dimensionally coherent signal over averaging mean/std/peak-to-peak/slope.
    if feature_df is not None and "resp_signal_window_mean" in feature_df.columns:
        resp_cols = ["resp_signal_window_mean"]
    if feature_df is None or not resp_cols:
        summary.append({
            "module": "RespDualPath_v0.1",
            "status": "NO_RESPIRATION_COLUMNS_FOUND",
            "respiration_columns": "",
            "n_resp_events": 0,
            "interpretation": "Respiration cannot be dual-labeled without a respiration feature/force stream. Vernier raw force should be used when available."
        })
        return pd.DataFrame(rows), pd.DataFrame(summary)

    cond_col = guess_condition_col(feature_df)
    time_col = None
    for c in feature_df.columns:
        if c.lower() in {"time", "time_sec", "t", "sec", "seconds"} or "time" in c.lower():
            if pd.api.types.is_numeric_dtype(feature_df[c]):
                time_col = c; break
    art_col = None
    for c in feature_df.columns:
        if "artifact" in c.lower() and pd.api.types.is_numeric_dtype(feature_df[c]):
            art_col = c; break

    # Composite respiration magnitude/diff.
    rvals = feature_df[resp_cols].apply(pd.to_numeric, errors="coerce").mean(axis=1)
    diff = rvals.diff().abs()
    if diff.dropna().empty:
        threshold = np.nan
    else:
        threshold = float(np.nanmean(diff) + 2.5 * np.nanstd(diff))
    idxs = list(diff[diff > threshold].index) if math.isfinite(threshold) else []
    if len(idxs) > 250:
        idxs = idxs[:250]
    for i in idxs:
        cond = normalize_condition(feature_df.loc[i, cond_col]) if cond_col else "unknown"
        art = coerce_float(feature_df.loc[i, art_col]) if art_col else np.nan
        t = coerce_float(feature_df.loc[i, time_col]) if time_col else np.nan
        artifact_flag = bool(math.isfinite(art) and art > 1.0)
        state_flag = cond in {"washout1", "washout2", "washout3", "baseline2", "target", "override"}
        rows.append({
            "module": "RespDualPath_v0.1",
            "row_index": int(i),
            "time_sec": t,
            "condition": cond,
            "resp_change_magnitude": coerce_float(diff.loc[i]),
            "resp_event_threshold": threshold,
            "artifact_score": art,
            "respiration_artifact_flag": artifact_flag,
            "respiration_state_event_flag": state_flag,
            "interpretation": "Respiration event preserved as state signal but should penalize clean EEG interpretation if overlapping artifact-sensitive windows."
        })

    summary.append({
        "module": "RespDualPath_v0.1",
        "status": "RESPIRATION_COLUMNS_FOUND",
        "respiration_columns": ";".join(resp_cols),
        "n_resp_events": len(rows),
        "n_artifact_flags": sum(1 for r in rows if r["respiration_artifact_flag"]),
        "n_state_event_flags": sum(1 for r in rows if r["respiration_state_event_flag"]),
        "interpretation": "Respiration is treated as both a possible EEG confound and a valid autonomic state channel. Do not automatically discard or automatically validate sigh/breath events."
    })
    return pd.DataFrame(rows), pd.DataFrame(summary)


# ---------------------------------------------------------------------
# Summary/report
# ---------------------------------------------------------------------

def build_summary(hocr, osa, ohc, aam, resp_summary) -> pd.DataFrame:
    rows = []
    def first(df, key, default=np.nan):
        try:
            return df.iloc[0].get(key, default)
        except Exception:
            return default
    rows.append({
        "module": "HOC-R_v0.1",
        "status": first(hocr, "high_order_status", "unknown"),
        "caution_level": "high" if "MISSING" in str(first(hocr, "high_order_status", "")) else "moderate",
        "action": "Add face/body/object/AOI regressors or high-order control branch for stronger Target-vs-Control interpretation."
    })
    rows.append({
        "module": "OSA_v0.1",
        "status": "spatial_attention_confounded" if bool(first(osa, "spatial_attention_confounded_flag", False)) else "spatial_attention_not_flagged_or_not_gradable",
        "caution_level": "high" if bool(first(osa, "spatial_attention_confounded_flag", False)) else "moderate",
        "action": "Add eye tracking, cue-monitor control, or AOI/saliency annotations to separate cue monitoring from arithmetic extraction."
    })
    rows.append({
        "module": "OHC_v0.1",
        "status": first(ohc, "washout_reset_assumption", "unknown"),
        "caution_level": "high" if bool(first(ohc, "sequence_confounded_flag", True)) else "moderate",
        "action": "Counterbalance Target/Override order in future cohorts; interpret washout as after-state, not reset."
    })
    rows.append({
        "module": "AAM_v0.1",
        "status": first(aam, "classification", "unknown"),
        "caution_level": "moderate",
        "action": "Use AAM as attribution support only; Baseline2 is cumulative and cannot prove Target-only afterglow."
    })
    rows.append({
        "module": "RespDualPath_v0.1",
        "status": first(resp_summary, "status", "unknown"),
        "caution_level": "moderate" if "FOUND" in str(first(resp_summary, "status", "")) else "high",
        "action": "Use raw respiration force when available; label respiratory events as both potential confound and potential state event."
    })
    return pd.DataFrame(rows)


def write_report(inp: Inputs, files: Dict[str, Path], summary: pd.DataFrame) -> Path:
    hocr = pd.read_csv(files["hocr"])
    osa = pd.read_csv(files["osa"])
    ohc = pd.read_csv(files["ohc"])
    aam = pd.read_csv(files["aam"])
    resp_sum = pd.read_csv(files["resp_summary"])
    report = []
    report.append("# PRAYCG Confound-Expanded Module Report v1.5.7")
    report.append("")
    report.append(f"Created UTC: `{now_utc()}`")
    report.append("")
    report.append("## Boundary")
    report.append("This report adds confound-aware interpretation layers. It does not certify meaning, consciousness, OSM, memory formation, or mechanism. It is designed to prevent overinterpretation of Target > Control, Target > Override, and Baseline2 after-state claims.")
    report.append("")
    report.append("## Input discovery")
    report.append(f"- Analysis folder: `{inp.analysis_folder}`")
    report.append(f"- Feature table: `{inp.feature_path}`")
    report.append(f"- Stimulus regressors: `{inp.stim_path}`")
    report.append(f"- Run config: `{inp.run_config_path}`")
    report.append(f"- Core reports found: `{len(inp.core_reports)}`")
    report.append(f"- Confound reports found: `{len(inp.confound_reports)}`")
    report.append("")
    report.append("## Module summary")
    report.append(markdown_table(summary))
    report.append("")
    report.append("## HOC-R — High-Order Control Residualization")
    report.append("Phase scrambling is retained as a sensory control, but it is not a perfect face/object/social-structure match. HOC-R audits whether high-order visual/social regressors are present and, where possible, residualizes outcomes against stimulus-side regressors.")
    report.append(markdown_table(hocr.head(10)))
    report.append("")
    report.append("## OSA — Override Spatial Attention")
    report.append("OSA estimates whether fixed upper-right cue monitoring could alter foveal/peripheral sampling and therefore confound Target-vs-Override interpretation.")
    report.append(markdown_table(osa))
    report.append("")
    report.append("## OHC — Order / Habituation / Carryover")
    report.append("OHC explicitly refuses to treat washouts as full biological resets and flags default fixed-order sequence limitations.")
    report.append(markdown_table(ohc))
    report.append("")
    report.append("## AAM — Afterglow Attribution Model")
    report.append("AAM compares Target-afterglow-like evidence with task-completion-relief-like evidence. It treats Baseline2 as cumulative, not Target-only.")
    report.append(markdown_table(aam))
    report.append("")
    report.append("## RespDualPath")
    report.append("RespDualPath labels respiration as both a potential EEG confound and a possible autonomic state event. Deep sighs should be preserved for state interpretation but should penalize clean EEG claims if they overlap artifact-sensitive windows.")
    report.append(markdown_table(resp_sum))
    report.append("")
    report.append("## Future protocol recommendations")
    report.append("- Keep phase-scrambled Control, but add high-order controls where possible: shot-order scramble, face-preserved/dialogue-damaged controls, non-narrative human-control, or face/body/object residualization.")
    report.append("- Add a Cue-Monitor condition to separate cue monitoring from arithmetic/executive extraction.")
    report.append("- Counterbalance Target and Override order in group designs.")
    report.append("- Treat washout as after-state measurement rather than reset.")
    report.append("- Add eye tracking/EOG/EMG and preserve raw respiration force for dual-path interpretation.")
    text = "\n".join(report) + "\n"
    path = inp.reports / "confound_expanded_module_report_v1_5_7.md"
    path.write_text(text, encoding="utf-8")
    return path


def run_all(args: argparse.Namespace) -> Dict[str, Any]:
    analysis_folder = Path(args.analysis_folder).expanduser().resolve()
    stim_folder = Path(args.stimulus_fingerprint_folder).expanduser().resolve() if args.stimulus_fingerprint_folder else None
    run_folder = Path(args.run_log_folder).expanduser().resolve() if args.run_log_folder else None
    out_folder = Path(args.out_folder).expanduser().resolve() if args.out_folder else None
    inp = discover_inputs(analysis_folder, stim_folder, run_folder, out_folder)

    rep_df = branch_report_table(inp)
    branch_path = inp.tables / "confound_expanded_branch_report_inputs.csv"
    rep_df.to_csv(branch_path, index=False)

    hocr = run_hocr(inp, rep_df)
    osa = run_osa(inp, rep_df)
    ohc = run_ohc(inp, rep_df)
    aam = run_aam(inp, rep_df)
    resp_events, resp_summary = run_resp_dual(inp, rep_df)
    summary = build_summary(hocr, osa, ohc, aam, resp_summary)

    files = {
        "branch_inputs": branch_path,
        "hocr": inp.tables / "hocr_high_order_control_residualization.csv",
        "osa": inp.tables / "osa_override_spatial_attention.csv",
        "ohc": inp.tables / "ohc_order_habituation_carryover.csv",
        "aam": inp.tables / "aam_afterglow_attribution.csv",
        "resp_events": inp.tables / "resp_dual_path_events.csv",
        "resp_summary": inp.tables / "resp_dual_path_summary.csv",
        "summary": inp.tables / "confound_expanded_module_summary.csv",
        "visual_overlay": inp.tables / "confound_expanded_visual_overlay.csv",
        "interpretation": inp.tables / "confound_expanded_interpretation.json",
    }
    hocr.to_csv(files["hocr"], index=False)
    osa.to_csv(files["osa"], index=False)
    ohc.to_csv(files["ohc"], index=False)
    aam.to_csv(files["aam"], index=False)
    resp_events.to_csv(files["resp_events"], index=False)
    resp_summary.to_csv(files["resp_summary"], index=False)
    summary.to_csv(files["summary"], index=False)

    # Visual overlay: sparse summary rows. Time-specific only for respiratory events.
    overlay_rows = []
    for _, r in summary.iterrows():
        overlay_rows.append({
            "time_sec": np.nan,
            "category": str(r["module"]),
            "label": str(r["status"]),
            "severity": str(r["caution_level"]),
            "notes": str(r["action"]),
        })
    if not resp_events.empty:
        for _, r in resp_events.head(100).iterrows():
            overlay_rows.append({
                "time_sec": r.get("time_sec", np.nan),
                "category": "RespDualPath_event",
                "label": "resp_artifact" if r.get("respiration_artifact_flag", False) else "resp_state",
                "severity": "caution" if r.get("respiration_artifact_flag", False) else "info",
                "notes": r.get("interpretation", ""),
            })
    pd.DataFrame(overlay_rows).to_csv(files["visual_overlay"], index=False)

    interp = {
        "schema": SCHEMA,
        "version": APP_VERSION,
        "created_utc": now_utc(),
        "analysis_folder": str(analysis_folder),
        "feature_table": str(inp.feature_path) if inp.feature_path else None,
        "stimulus_regressors": str(inp.stim_path) if inp.stim_path else None,
        "run_config": str(inp.run_config_path) if inp.run_config_path else None,
        "module_summary": summary.to_dict(orient="records"),
        "boundary": "Confound-expanded modules add caution and attribution; they do not certify PRAYCG endpoints or mechanisms.",
        "outputs": {k: str(v) for k, v in files.items()},
    }
    files["interpretation"].write_text(json.dumps(interp, indent=2), encoding="utf-8")

    report_path = write_report(inp, files, summary)
    files["report"] = report_path
    print("PRAYCG Confound-Expanded Modules complete.")
    for k, v in files.items():
        print(f"  {k}: {v}")
    return interp


def launch_gui(defaults: Optional[argparse.Namespace] = None) -> None:
    try:
        import tkinter as tk
        from tkinter import ttk, filedialog, messagebox
    except Exception as exc:
        raise SystemExit(f"Tkinter unavailable: {exc}")

    root = tk.Tk()
    root.title("PRAYCG Confound-Expanded Modules v1.5.7")
    root.geometry("820x420")
    vars = {
        "analysis_folder": tk.StringVar(value=str(getattr(defaults, "analysis_folder", "") or "")),
        "stimulus_fingerprint_folder": tk.StringVar(value=str(getattr(defaults, "stimulus_fingerprint_folder", "") or "")),
        "run_log_folder": tk.StringVar(value=str(getattr(defaults, "run_log_folder", "") or "")),
        "out_folder": tk.StringVar(value=str(getattr(defaults, "out_folder", "") or "")),
    }
    frm = ttk.Frame(root); frm.pack(fill="both", expand=True, padx=10, pady=10)
    ttk.Label(frm, text="PRAYCG Confound-Expanded Modules v1.5.7\nHOC-R / OSA / OHC / AAM / RespDualPath", font=("Segoe UI", 12, "bold")).pack(anchor="w")
    rows = ttk.Frame(frm); rows.pack(fill="x", pady=10)
    def row(label, key):
        r = ttk.Frame(rows); r.pack(fill="x", pady=3)
        ttk.Label(r, text=label, width=28).pack(side="left")
        ttk.Entry(r, textvariable=vars[key]).pack(side="left", fill="x", expand=True)
        def browse():
            d = filedialog.askdirectory(title=label)
            if d: vars[key].set(d)
        ttk.Button(r, text="Browse", command=browse).pack(side="left", padx=4)
    row("Analysis output folder", "analysis_folder")
    row("StimulusFingerprint/QC folder", "stimulus_fingerprint_folder")
    row("Run log/self-report folder", "run_log_folder")
    row("Output folder (blank = analysis)", "out_folder")
    txt = tk.Text(frm, height=9, wrap="word"); txt.pack(fill="both", expand=True, pady=8)
    txt.insert("end", "This is a confound-aware interpretation extension. It will not certify meaning or mechanism. It writes tables/ and reports/ outputs into the selected folder.\n")
    def run_clicked():
        if not vars["analysis_folder"].get():
            messagebox.showwarning("Missing folder", "Select an analysis output folder.")
            return
        ns = argparse.Namespace(**{k:v.get() for k,v in vars.items()})
        try:
            interp = run_all(ns)
            messagebox.showinfo("Done", "Confound-expanded modules completed. See tables/ and reports/.")
            txt.insert("end", "\nDone.\n" + json.dumps(interp.get("outputs", {}), indent=2) + "\n")
        except Exception as exc:
            messagebox.showerror("Error", str(exc))
            txt.insert("end", f"\nERROR: {exc}\n")
    ttk.Button(frm, text="Run Confound-Expanded Modules", command=run_clicked).pack(fill="x")
    root.mainloop()


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="PRAYCG Confound-Expanded Modules v1.5.7")
    ap.add_argument("--analysis-folder", help="Master Comprehensive Suite output folder")
    ap.add_argument("--stimulus-fingerprint-folder", default="", help="Optional MediaPrep/StimulusFingerprint QC folder")
    ap.add_argument("--run-log-folder", default="", help="Optional folder containing PRAYCG2.0 event/self-report JSONs")
    ap.add_argument("--out-folder", default="", help="Optional output folder; default is analysis-folder")
    ap.add_argument("--gui", action="store_true", help="Launch a simple GUI")
    return ap.parse_args(argv)


if __name__ == "__main__":
    args = parse_args()
    if args.gui or not args.analysis_folder:
        launch_gui(args)
    else:
        run_all(args)
