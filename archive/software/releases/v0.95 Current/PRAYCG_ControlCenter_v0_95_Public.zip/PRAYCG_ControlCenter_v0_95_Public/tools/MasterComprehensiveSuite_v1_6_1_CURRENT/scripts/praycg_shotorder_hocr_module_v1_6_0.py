#!/usr/bin/env python3
"""
PRAYCG Master Comprehensive Suite v1.6.0 - ShotOrder / HOC-R Support

Ingests Master Suite feature tables and computes Target-vs-PhaseScrambled and
Target-vs-ShotOrderScramble contrasts when a structural control branch is present.

This module is a confound-audit layer. It does not certify narrative meaning, OSM,
consciousness, or mechanism.
"""
from __future__ import annotations
import argparse, csv, json, math, os, re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    import pandas as pd
    import numpy as np
except Exception as exc:
    raise SystemExit('Install pandas and numpy: py -3.11 -m pip install pandas numpy') from exc

CANDIDATE_FEATURE_PATTERNS = ['praycg_analysis_frame_v1_6_0.csv','eeg_window_power_features.csv','*time_resolved_feature_frame*.csv','*feature_frame*.csv','*features_used*.csv','*component_timeseries*.csv']
CORE_METRICS = ['MR','mr','TSP','tsp','MeaningGamma','meaninggamma','meaning_gamma','NIP','nip','CII','cii','ENC','enc','theta_handoff','theta','Theta','KHT','kht','artifact_score','ArtifactScore']


def find_feature_csv(folder: Path) -> Optional[Path]:
    for pat in CANDIDATE_FEATURE_PATTERNS:
        hits = sorted(folder.rglob(pat), key=lambda p: (len(str(p)), str(p)))
        for h in hits:
            if h.is_file():
                return h
    return None


def norm_condition(x: Any) -> str:
    s = str(x or '').lower()
    if 'shot' in s or 'structural' in s or 'sos' in s:
        return 'shot_order_scramble'
    if 'phase' in s or ('control' in s and 'shot' not in s):
        return 'phase_scrambled_control'
    if 'override' in s or 'contextual' in s:
        return 'override'
    if 'target' in s:
        return 'target'
    if 'baseline' in s:
        return 'baseline'
    return s or 'unknown'


def pick_condition_col(df) -> Optional[str]:
    for c in ['condition','branch','phase','phase_name','condition_label','branch_type']:
        if c in df.columns:
            return c
    return None


def metric_cols(df) -> List[str]:
    cols=[]
    for c in df.columns:
        if c.lower() in {'time','time_sec','timestamp','condition','branch','phase','phase_name'}:
            continue
        if not pd.api.types.is_numeric_dtype(df[c]):
            continue
        for pat in CORE_METRICS:
            if pat.lower() in c.lower():
                cols.append(c); break
    # fallback: use a conservative subset of numeric columns if no named metrics
    if not cols:
        num = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
        cols = num[:20]
    return sorted(set(cols))


def branch_summary(df, cond_col, metrics) -> pd.DataFrame:
    work = df.copy()
    work['_branch_norm'] = work[cond_col].map(norm_condition)
    rows=[]
    for branch, g in work.groupby('_branch_norm'):
        if branch in {'baseline','unknown',''}:
            continue
        row={'branch':branch,'n_rows':int(len(g))}
        for m in metrics:
            vals = pd.to_numeric(g[m], errors='coerce')
            row[f'{m}_mean'] = float(vals.mean()) if vals.notna().any() else math.nan
            row[f'{m}_median'] = float(vals.median()) if vals.notna().any() else math.nan
        rows.append(row)
    return pd.DataFrame(rows)


def contrast_rows(summary: pd.DataFrame, metrics: List[str]) -> pd.DataFrame:
    by = {r['branch']: r for _, r in summary.iterrows()}
    contrasts=[]
    target = by.get('target')
    if target is None:
        return pd.DataFrame()
    for comparator in ['phase_scrambled_control','shot_order_scramble','override']:
        comp = by.get(comparator)
        if comp is None:
            contrasts.append({'contrast':f'target_minus_{comparator}','comparator_present':False,'interpretation':'Comparator branch not detected.'})
            continue
        row={'contrast':f'target_minus_{comparator}','comparator_present':True}
        positives=0; total=0
        for m in metrics:
            t=target.get(f'{m}_mean', math.nan); c=comp.get(f'{m}_mean', math.nan)
            try:
                delta=float(t)-float(c)
            except Exception:
                delta=math.nan
            row[f'delta_{m}_mean']=delta
            if not math.isnan(delta):
                total += 1
                # artifact is reversed: lower artifact in target is better, but don't count here
                if 'artifact' not in m.lower() and delta > 0:
                    positives += 1
        row['positive_metric_fraction'] = positives/total if total else math.nan
        if comparator == 'shot_order_scramble':
            row['interpretation'] = 'Structural-defense contrast: Target exceeding ShotOrder is more consistent with narrative-order/temporal meaning than local faces/bodies/motion alone, pending QC.'
        elif comparator == 'phase_scrambled_control':
            row['interpretation'] = 'Sensory-control contrast: Target exceeding PhaseScrambled suggests effects not reducible to low-level scrambled sensory drive alone, pending QC.'
        else:
            row['interpretation'] = 'Task-stance contrast: Target exceeding Override suggests analytic extraction/spatial cue burden may attenuate reception, pending OSA/OHC controls.'
        contrasts.append(row)
    return pd.DataFrame(contrasts)


def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--analysis-folder', required=False, default='')
    ap.add_argument('--feature-csv', default='')
    ap.add_argument('--out-dir', default='')
    ap.add_argument('--gui', action='store_true')
    args=ap.parse_args(argv)
    if args.gui and not args.analysis_folder:
        import tkinter as tk
        from tkinter import filedialog, messagebox
        root=tk.Tk(); root.withdraw()
        folder=filedialog.askdirectory(title='Select Master Comprehensive analysis folder')
        if not folder: return 1
        args.analysis_folder=folder
    folder=Path(args.analysis_folder or '.').resolve()
    feature_csv=Path(args.feature_csv).resolve() if args.feature_csv else find_feature_csv(folder)
    if not feature_csv or not feature_csv.exists():
        raise SystemExit('No feature table found. Use --feature-csv or select an analysis folder containing a time-resolved feature frame.')
    out_dir=Path(args.out_dir).resolve() if args.out_dir else folder/'shotorder_hocr_v1_6_0'
    tables=out_dir/'tables'; reports=out_dir/'reports'
    tables.mkdir(parents=True, exist_ok=True); reports.mkdir(parents=True, exist_ok=True)
    df=pd.read_csv(feature_csv)
    cond=pick_condition_col(df)
    if not cond:
        raise SystemExit('No condition/branch/phase column found in feature table.')
    metrics=metric_cols(df)
    summary=branch_summary(df, cond, metrics)
    contrasts=contrast_rows(summary, metrics)
    summary_path=tables/'hocr_shotorder_branch_summary.csv'; contrasts_path=tables/'hocr_shotorder_branch_contrasts.csv'
    summary.to_csv(summary_path,index=False); contrasts.to_csv(contrasts_path,index=False)
    shot_present='shot_order_scramble' in set(summary.get('branch', []))
    phase_present='phase_scrambled_control' in set(summary.get('branch', []))
    target_present='target' in set(summary.get('branch', []))
    override_present='override' in set(summary.get('branch', []))
    grade = 'HOC_R_STRONG_BRANCH_SET_PRESENT' if all([shot_present, phase_present, target_present, override_present]) else 'HOC_R_PARTIAL_BRANCH_SET'
    interp={
        'schema':'PRAYCG_HOCR_ShotOrder_Module_v1_6_0',
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'feature_csv':str(feature_csv),
        'condition_column':cond,
        'metrics_used':metrics,
        'branches_detected':summary['branch'].tolist() if not summary.empty else [],
        'shot_order_present':shot_present,
        'phase_scrambled_present':phase_present,
        'target_present':target_present,
        'override_present':override_present,
        'hoc_r_grade':grade,
        'outputs':{'branch_summary':str(summary_path),'contrasts':str(contrasts_path)},
        'boundary':'HOC-R ShotOrder support is a confound/structural-control audit only; it does not certify meaning, A-MRED, OSM, consciousness, or mechanism.'
    }
    (tables/'hocr_shotorder_interpretation.json').write_text(json.dumps(interp,indent=2),encoding='utf-8')
    md=[
        '# PRAYCG HOC-R ShotOrder Module Report v1.6.0','',
        f'Feature table: `{feature_csv}`','',
        f'HOC-R grade: `{grade}`','',
        '## Branches detected','',
        ', '.join(interp['branches_detected']) or 'none','',
        '## Interpretation','',
        'This module adds ShotOrderScramble as a high-order structural-control branch. The key future comparison is Target > PhaseScrambled, Target > ShotOrderScramble, and Target > Override at locked anchors after artifact, timing, OSA, OHC, AAM, RespDualPath, and CET-R checks.','',
        '## Boundary','',
        interp['boundary']
    ]
    (reports/'hocr_shotorder_module_report_v1_6_0.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(json.dumps({'status':'done','grade':grade,'out_dir':str(out_dir)},indent=2))
    return 0
if __name__=='__main__':
    raise SystemExit(main())
