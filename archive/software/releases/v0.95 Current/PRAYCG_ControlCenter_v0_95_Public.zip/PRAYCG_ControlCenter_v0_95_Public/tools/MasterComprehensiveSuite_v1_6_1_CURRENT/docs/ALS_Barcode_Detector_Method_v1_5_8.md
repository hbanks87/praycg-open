# ALS Barcode Detector Method v1.5.8

## Purpose

The PRAYCG2.2 runner emits a physical-screen ALS/PT19 barcode before each analyzable video branch. The Master Comprehensive Suite v1.5.8 detector searches the ALS/AUX channel for the expected long-short pulse pattern and reports whether branch onset timing is strong, partial, weak, or LSL-only.

## Default barcode

```text
black pre-guard:  0.50 s
white pulse A:    2.00 s
black gap:        0.50 s
white pulse B:    0.75 s
black post-guard: 1.00 s
```

## Expected markers

```text
<BRANCH>_ALS_BARCODE_START
<BRANCH>_ALS_PULSE_A_START
<BRANCH>_ALS_PULSE_A_END
<BRANCH>_ALS_PULSE_B_START
<BRANCH>_ALS_PULSE_B_END
<BRANCH>_ALS_BARCODE_END
<BRANCH>_ALS_CONTENT_START
<BRANCH>_START
```

`<BRANCH>_START` remains backward-compatible and should still approximate video content onset. `<BRANCH>_ALS_CONTENT_START` explicitly marks the transition from barcode to content.

## Detector logic

The detector robust-normalizes the ALS channel around each branch marker, divides the expected barcode into five segments, and compares median luminance/ALS amplitude across black and white segments.

A branch receives:

```text
PASS      clear long and short white elevations, return to baseline, no full-pulse clipping
WEAK      pattern present but low amplitude/noisy
CLIPPED   the detector sees saturation over too much of the pulse
MISSING   no recognizable long-short pattern
NO_MARKER no barcode marker was found for that branch
```

## Outputs

```text
tables/als_barcode_qc.csv
tables/als_barcode_branch_offsets.csv
tables/als_barcode_detection_report.json
tables/als_barcode_visual_overlay.csv
reports/als_barcode_detection_report.md
```

## Boundary

The ALS barcode validates physical display timing only. It is part of the external input vector and does not certify biological endpoints, MRED, A-MRED, memory formation, OSM biology, or mechanism.
