#!/usr/bin/env python3
"""PRAYCG Analysis Artifact Index v1.0.

Builds one deterministic, provenance-bearing inventory for the Master Suite
Visualizer and Offline Interpreter. Exact registered filenames are preferred;
unregistered files are inventoried but are never silently substituted for a
registered scientific artifact.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "1.0"
SCHEMA = "PRAYCG_AnalysisArtifactIndex_v1_0"

# key: (exact filename, producing module, evidentiary tier, media type)
ARTIFACT_REGISTRY: Dict[str, Tuple[str, str, str, str]] = {
    "chain_manifest": ("chain_manifest.json", "chain", "provenance", "manifest"),
    "analysis_frame": ("praycg_analysis_frame_v1_6_0.csv", "core", "infrastructure", "table"),
    "run_eligibility": ("run_eligibility.json", "core", "primary_gate", "gate"),
    "phase_coverage": ("run_eligibility_phase_coverage.csv", "core", "primary_gate", "table"),
    "module_registry": ("module_registry.csv", "core", "infrastructure", "table"),
    "module_tier": ("module_tier_map.csv", "core", "infrastructure", "table"),
    "stream_inventory": ("stream_inventory.csv", "core", "quality_control", "table"),
    "als_detection": ("als_barcode_detection_report.json", "als_barcode", "primary_gate", "gate"),
    "amred_anchor": ("amred_anchor_endpoint_table.csv", "amred", "primary", "table"),
    "amred_summary": ("amred_primary_endpoint_summary.csv", "amred", "primary", "table"),
    "amred_summary_json": ("amred_primary_endpoint_summary.json", "amred", "primary", "interpretation"),
    "mred_peak_res_anchor": ("mred_peak_resolution_anchor_table.csv", "mred_peak_resolution", "primary", "table"),
    "mred_peak_res_summary": ("mred_peak_resolution_run_summary.csv", "mred_peak_resolution", "primary", "table"),
    "mred_event": ("mred_event_table.csv", "core", "exploratory", "table"),
    "candidate_kht": ("candidate_local_kht_analysis.csv", "core", "exploratory", "table"),
    "tti_global": ("tti_global_summary.csv", "tti", "secondary", "table"),
    "nupi_summary": ("nupi_run_summary.csv", "nupi", "secondary", "table"),
    "cii_anchor": ("cii_anchor_integrals.csv", "nip_cet_eet", "secondary", "table"),
    "cet_model": ("cet_residualization_model_summary.csv", "nip_cet_eet", "secondary", "table"),
    "eet": ("eet_endogenous_echo_tracking.csv", "nip_cet_eet", "exploratory", "table"),
    "mred_itp": ("mred_itp_anchor_summary.csv", "mred_itp", "exploratory", "table"),
    "ocm_rsm": ("rsm_cvb_squint_cue_table.csv", "confound_rsm", "confound", "table"),
    "confound_registry": ("confound_registry.csv", "confound_rsm", "confound", "table"),
    "baseline2": ("baseline1_vs_baseline2_polar_respiration_summary.csv", "core", "secondary", "table"),
    "dga_branch": ("dga_branch_gate_table.csv", "dga", "secondary", "table"),
    "dga_summary": ("dga_gate_dissociation_summary.csv", "dga", "secondary", "table"),
    "dga_anchor": ("dga_gate_adjusted_mred_anchor_table.csv", "dga", "secondary", "table"),
    "hocr_branch": ("hocr_shotorder_branch_summary.csv", "shotorder_hocr", "confound", "table"),
    "hocr_contrasts": ("hocr_shotorder_branch_contrasts.csv", "shotorder_hocr", "confound", "table"),
    "hocr_interpretation": ("hocr_shotorder_interpretation.json", "shotorder_hocr", "confound", "interpretation"),
    "confound_summary": ("confound_expanded_module_summary.csv", "confound_expanded", "confound", "table"),
    "hocr_residual": ("hocr_high_order_control_residualization.csv", "confound_expanded", "confound", "table"),
    "osa": ("osa_override_spatial_attention.csv", "confound_expanded", "confound", "table"),
    "ohc": ("ohc_order_habituation_carryover.csv", "confound_expanded", "confound", "table"),
    "aam": ("aam_afterglow_attribution.csv", "confound_expanded", "confound", "table"),
    "resp_dual": ("resp_dual_path_summary.csv", "confound_expanded", "confound", "table"),
    "selfreport_all": ("praycg2_0_selfreport_all_records.csv", "selfreport", "context", "table"),
    "branch_core": ("praycg2_0_branch_core.csv", "selfreport", "context", "table"),
    "final_master": ("praycg2_0_final_master.csv", "selfreport", "context", "table"),
    "events_used": ("events_used.csv", "core", "provenance", "events"),
    "stimulus_annotations": ("stimulus_annotations_used.csv", "core", "provenance", "events"),
    # Sparse overlays used by the visualizer. Their scientific status is inherited
    # from the module status, never from file existence alone.
    "nip_overlay": ("nip_cet_eet_visual_overlay.csv", "nip_cet_eet", "display", "events"),
    "bit_events": ("bit_event_table.csv", "nip_cet_eet", "display", "events"),
    "amred_overlay": ("amred_visual_overlay.csv", "amred", "display", "events"),
    "nupi_overlay": ("nupi_visual_overlay.csv", "nupi", "display", "events"),
    "peak_overlay": ("mred_peak_resolution_visual_overlay.csv", "mred_peak_resolution", "display", "events"),
    "dga_overlay": ("dga_visual_overlay.csv", "dga", "display", "events"),
    "itp_overlay": ("mred_itp_visual_overlay.csv", "mred_itp", "display", "events"),
    "confound_overlay": ("confound_expanded_visual_overlay.csv", "confound_expanded", "display", "events"),
    "tti_overlay": ("tti_visual_overlay.csv", "tti", "display", "events"),
    "rsm_overlay": ("rsm_visual_overlay.csv", "confound_rsm", "display", "events"),
    "confound_rsm_overlay": ("confound_visual_overlay.csv", "confound_rsm", "display", "events"),
    "mred_overlay": ("mred_visual_overlay.csv", "core", "display", "events"),
}

STATUS_ORDER = {
    "SOFTWARE_ERROR": 0,
    "FAIL_PRIMARY_GATE": 1,
    "NOT_GRADABLE_MISSING_INPUT": 2,
    "NOT_APPLICABLE_PROTOCOL": 3,
    "EXPLORATORY_ONLY": 4,
    "PASS": 5,
}


def _utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_json_state(path: Optional[Path]) -> Tuple[Dict[str, Any], str, str]:
    if path is None or not path.is_file():
        return {}, "MISSING", ""
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(obj, dict):
            return {}, "MALFORMED", "Top-level JSON value is not an object."
        return obj, "OK", ""
    except Exception as exc:
        return {}, "MALFORMED", str(exc)


def _latest_chain(root: Path) -> Optional[Path]:
    candidates = []
    for p in root.glob("chained_modules_v1_6_*"):
        manifest = p / "chain_manifest.json"
        if manifest.is_file():
            candidates.append((manifest.stat().st_mtime, p))
    return max(candidates, default=(0, None))[1]


def resolve_layout(selected: Path) -> Dict[str, Any]:
    selected = selected.expanduser().resolve()
    chain_root: Optional[Path] = None
    data_root = selected
    selection_note = "Selected folder used directly."
    if (selected / "chain_manifest.json").is_file():
        chain_root = selected
        data_root = selected / "workspace" if (selected / "workspace").is_dir() else selected
        selection_note = "Completed chained-analysis folder selected."
    elif selected.name == "workspace" and (selected.parent / "chain_manifest.json").is_file():
        chain_root = selected.parent
        data_root = selected
        selection_note = "Chained workspace selected; parent manifest linked."
    else:
        newest = _latest_chain(selected)
        if newest is not None:
            chain_root = newest
            data_root = newest / "workspace"
            selection_note = f"Newest completed chained analysis selected automatically: {newest.name}."
    tables = data_root / "tables" if (data_root / "tables").is_dir() else data_root
    return {
        "selected_folder": str(selected),
        "analysis_kind": "chained" if chain_root else "core_or_legacy",
        "chain_root": str(chain_root) if chain_root else "",
        "data_root": str(data_root),
        "tables_root": str(tables),
        "selection_note": selection_note,
    }


def _candidate_files(layout: Dict[str, Any], filename: str) -> List[Path]:
    data_root = Path(layout["data_root"])
    chain_root = Path(layout["chain_root"]) if layout.get("chain_root") else None
    ordered: List[Path] = []
    preferred = data_root / "tables" / filename
    if preferred.is_file():
        ordered.append(preferred)
    direct = data_root / filename
    if direct.is_file() and direct not in ordered:
        ordered.append(direct)
    search_roots: Iterable[Path] = [chain_root] if chain_root else [data_root]
    for base in search_roots:
        if base is None or not base.exists():
            continue
        for p in sorted(base.rglob(filename), key=lambda x: str(x).lower()):
            if p.is_file() and p not in ordered:
                ordered.append(p)
    return ordered


def _module_statuses(layout: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], List[Dict[str, Any]]]:
    statuses: Dict[str, Dict[str, Any]] = {}
    issues: List[Dict[str, Any]] = []
    chain_root = Path(layout["chain_root"]) if layout.get("chain_root") else None
    if chain_root:
        manifest, state, error = _read_json_state(chain_root / "chain_manifest.json")
        if state != "OK":
            issues.append({"severity": "ERROR", "code": "CHAIN_MANIFEST_" + state, "message": error})
        for row in manifest.get("modules", []) if isinstance(manifest.get("modules"), list) else []:
            if isinstance(row, dict) and row.get("module"):
                statuses[str(row["module"])] = dict(row)
        modules_root = chain_root / "modules"
        if modules_root.is_dir():
            for status_path in sorted(modules_root.glob("*/module_status.json")):
                payload, state, error = _read_json_state(status_path)
                if state != "OK":
                    issues.append({"severity": "ERROR", "code": "MODULE_STATUS_" + state, "path": str(status_path), "message": error})
                    continue
                name = str(payload.get("module") or status_path.parent.name)
                current = statuses.get(name)
                if current is None or STATUS_ORDER.get(str(payload.get("status")), -1) < STATUS_ORDER.get(str(current.get("status")), -1):
                    statuses[name] = payload
                statuses[name]["status_record_path"] = str(status_path.resolve())
                statuses[name]["status_record_sha256"] = _sha256(status_path)
    return statuses, issues


def build_artifact_index(selected: Path, write_path: Optional[Path] = None, include_hashes: bool = True) -> Dict[str, Any]:
    layout = resolve_layout(selected)
    statuses, issues = _module_statuses(layout)
    tables_root = Path(layout["tables_root"])
    eligibility_path = tables_root / "run_eligibility.json"
    eligibility, eligibility_state, eligibility_error = _read_json_state(eligibility_path)
    if eligibility_state != "OK":
        issues.append({
            "severity": "ERROR" if eligibility_state == "MALFORMED" else "WARNING",
            "code": "RUN_ELIGIBILITY_" + eligibility_state,
            "path": str(eligibility_path),
            "message": eligibility_error or "Run eligibility record was not found.",
        })

    artifacts: Dict[str, Dict[str, Any]] = {}
    for key, (filename, module, tier, media_type) in ARTIFACT_REGISTRY.items():
        candidates = _candidate_files(layout, filename)
        selected_path = candidates[0] if candidates else None
        status = statuses.get(module, {})
        entry: Dict[str, Any] = {
            "key": key,
            "filename": filename,
            "module": module,
            "tier": tier,
            "media_type": media_type,
            "availability": "AVAILABLE" if selected_path else "MISSING",
            "selected_path": str(selected_path) if selected_path else "",
            "duplicate_paths": [str(p) for p in candidates[1:]],
            "module_status": str(status.get("status", "UNRECORDED")),
            "module_message": str(status.get("message", "")),
        }
        if selected_path:
            entry.update(size_bytes=selected_path.stat().st_size, modified_utc=dt.datetime.fromtimestamp(selected_path.stat().st_mtime, dt.timezone.utc).isoformat())
            if include_hashes:
                entry["sha256"] = _sha256(selected_path)
        if len(candidates) > 1:
            issues.append({"severity": "WARNING", "code": "DUPLICATE_ARTIFACT", "artifact": key, "message": f"Selected canonical path and retained {len(candidates)-1} duplicate path(s) in provenance."})
        artifacts[key] = entry

    unregistered: List[Dict[str, Any]] = []
    if tables_root.exists():
        registered_names = {v[0] for v in ARTIFACT_REGISTRY.values()}
        for path in sorted(tables_root.iterdir(), key=lambda p: p.name.lower()):
            if path.is_file() and path.suffix.lower() in {".csv", ".json"} and path.name not in registered_names:
                unregistered.append({"filename": path.name, "path": str(path), "size_bytes": path.stat().st_size})

    strict_allowed = bool(eligibility.get("strict_interpretation_allowed", False))
    eligibility_status = str(eligibility.get("status", eligibility_state))
    index = {
        "schema": SCHEMA,
        "version": VERSION,
        "created_utc": _utc_now(),
        "layout": layout,
        "run": {
            "run_uuid": str(eligibility.get("run_uuid", eligibility.get("immutable_run_uuid", ""))),
            "eligibility_status": eligibility_status,
            "strict_interpretation_allowed": strict_allowed,
            "eligibility_record_state": eligibility_state,
            "eligibility_record_path": str(eligibility_path) if eligibility_path.is_file() else "",
            "eligibility": eligibility,
        },
        "module_statuses": statuses,
        "status_counts": {status: sum(1 for row in statuses.values() if str(row.get("status")) == status) for status in sorted({str(row.get("status")) for row in statuses.values()})},
        "artifacts": artifacts,
        "unregistered_table_files": unregistered,
        "issues": issues,
        "interpretation_gate": "OPEN" if strict_allowed else "DIAGNOSTIC_ONLY",
        "boundary": "Artifact availability and software status do not establish scientific validity. Failed, missing, non-applicable, and software-error states remain distinct.",
    }
    if write_path:
        write_path = write_path.expanduser().resolve()
        write_path.parent.mkdir(parents=True, exist_ok=True)
        write_path.write_text(json.dumps(index, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
        index["written_to"] = str(write_path)
    return index


def artifact_path(index: Dict[str, Any], key: str) -> Optional[Path]:
    raw = index.get("artifacts", {}).get(key, {}).get("selected_path", "")
    return Path(raw) if raw else None


def main() -> int:
    parser = argparse.ArgumentParser(description="PRAYCG deterministic analysis artifact index v1.0")
    parser.add_argument("--analysis-folder", required=True)
    parser.add_argument("--out", default="")
    parser.add_argument("--no-hashes", action="store_true")
    args = parser.parse_args()
    root = Path(args.analysis_folder)
    layout = resolve_layout(root)
    default_out = Path(layout["data_root"]) / "reports" / "praycg_analysis_artifact_index_v1_0.json"
    index = build_artifact_index(root, Path(args.out) if args.out else default_out, include_hashes=not args.no_hashes)
    print(json.dumps({"status": "ok", "output": index.get("written_to", ""), "issues": len(index.get("issues", []))}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
