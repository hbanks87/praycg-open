#!/usr/bin/env python3
"""PRAYCG BrainFlow EEG-only to LSL bridge v1.1.

Publishes EEG with reconstructed per-sample timestamps, preserves non-finite
values as missing, records device/host timing diagnostics, classifies packet
loss/duplicates/order errors, and always emits a final QC artifact.
"""
from __future__ import annotations

import argparse
import csv
import json
import signal
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

ACQUISITION_DIR = Path(__file__).resolve().parents[2]
if str(ACQUISITION_DIR) not in sys.path:
    sys.path.insert(0, str(ACQUISITION_DIR))
from praycg_acquisition_diagnostics_v1_0 import (  # noqa: E402
    atomic_write_json, channel_health, device_timestamp_summary, file_sha256,
    final_qc, reconstruct_lsl_timestamps, software_versions,
)

try:
    from brainflow.board_shim import BoardIds, BoardShim, BrainFlowInputParams
except Exception as exc:  # pragma: no cover
    raise SystemExit("brainflow is required: " + repr(exc))
try:
    from pylsl import StreamInfo, StreamOutlet, local_clock
except Exception as exc:  # pragma: no cover
    raise SystemExit("pylsl is required: " + repr(exc))

BRIDGE_VERSION = "1.1"
SCHEMA = "PRAYCG_BrainFlow_EEGOnly_Bridge_v1_1"
PRAYCG_EEG16_LABELS = [
    ("Fz", "frontal_analytic_lock"), ("Cz", "central_anchor"), ("Pz", "parietal_integration"),
    ("F3", "left_frontal"), ("F4", "right_frontal"), ("C3", "left_central"),
    ("C4", "right_central"), ("P3", "left_parietal"), ("P4", "right_parietal"),
    ("T5", "left_posterior_temporal"), ("T6", "right_posterior_temporal"),
    ("O1", "left_visual_control"), ("O2", "right_visual_control"),
    ("F7", "left_frontal_lateral"), ("F8", "right_frontal_lateral"), ("Oz", "midline_visual_control"),
]


def board_from_label(label: str) -> Tuple[int, str]:
    normalized = str(label).strip().lower().replace("_", "-")
    mapping = {"cyton": ("CYTON_BOARD", "OpenBCI Cyton"), "cyton-daisy": ("CYTON_DAISY_BOARD", "OpenBCI Cyton+Daisy"), "daisy": ("CYTON_DAISY_BOARD", "OpenBCI Cyton+Daisy"), "synthetic": ("SYNTHETIC_BOARD", "BrainFlow Synthetic Board")}
    if normalized in mapping:
        key, pretty = mapping[normalized]
        return int(getattr(BoardIds, key).value), pretty
    try:
        return int(label), f"custom_board_id_{label}"
    except ValueError as exc:
        raise ValueError("--board must be cyton, cyton-daisy, synthetic, or an integer BrainFlow board id") from exc


def list_ports() -> int:
    try:
        from serial.tools import list_ports as serial_ports
    except Exception as exc:
        print("pyserial is required for --list-ports: " + repr(exc)); return 2
    ports = list(serial_ports.comports())
    for port in ports: print(f"{port.device:10s} | {port.description} | {port.hwid}")
    return 0 if ports else 1


def get_row(board_id: int, getter: str) -> Optional[int]:
    try: return int(getattr(BoardShim, getter)(board_id))
    except Exception: return None


def labels_for(n: int, confirmed: bool, custom: str) -> List[Tuple[str, str]]:
    if custom.strip():
        names = [x.strip() for x in custom.split(",") if x.strip()]
        if len(names) != n: raise ValueError(f"--channel-labels supplied {len(names)} labels for {n} EEG channels")
        return [(name, "custom") for name in names]
    if confirmed and n in {8, 16}: return PRAYCG_EEG16_LABELS[:n]
    return [(f"Ch{i+1}", "unconfirmed") for i in range(n)]


def make_eeg_outlet(args: argparse.Namespace, labels: Sequence[Tuple[str, str]], srate: float, source_id: str, board_label: str, board_id: int, run_uuid: str) -> StreamOutlet:
    info = StreamInfo(args.stream_name, args.stream_type, len(labels), srate, "float32", source_id)
    desc = info.desc()
    for key, value in {"manufacturer": "OpenBCI/BrainFlow", "created_by": SCHEMA, "bridge_version": BRIDGE_VERSION, "run_uuid": run_uuid, "board_label": board_label, "board_id": board_id, "serial_port": args.serial_port, "channel_map_confirmed": bool(args.confirmed_channel_map), "timestamp_mode": args.timestamp_mode, "units": "microvolts"}.items():
        desc.append_child_value(key, str(value))
    channels = desc.append_child("channels")
    for index, (label, roi) in enumerate(labels, 1):
        ch = channels.append_child("channel")
        for key, value in {"label": label, "unit": "microvolts", "type": "EEG", "index_1based": index, "roi": roi}.items(): ch.append_child_value(key, str(value))
    return StreamOutlet(info, chunk_size=max(1, args.chunk_size), max_buffered=max(30, args.lsl_buffer_sec))


def make_status_outlet(name: str, source_id: str, run_uuid: str) -> StreamOutlet:
    info = StreamInfo(name, "Markers", 1, 0, "string", source_id + "_status")
    info.desc().append_child_value("created_by", SCHEMA); info.desc().append_child_value("run_uuid", run_uuid)
    return StreamOutlet(info, max_buffered=120)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="OpenBCI BrainFlow EEG-only bridge with provenance and final QC")
    p.add_argument("--board", default="cyton-daisy"); p.add_argument("--serial-port", default=""); p.add_argument("--list-ports", action="store_true")
    p.add_argument("--stream-name", default="obci_eeg1"); p.add_argument("--stream-type", default="EEG"); p.add_argument("--status-stream-name", default="OpenBCIStatusMarkers")
    p.add_argument("--source-id", default=""); p.add_argument("--run-uuid", default=""); p.add_argument("--confirmed-channel-map", action="store_true"); p.add_argument("--channel-labels", default="")
    p.add_argument("--duration", type=float, default=0.0); p.add_argument("--buffer-size", type=int, default=450000); p.add_argument("--lsl-buffer-sec", type=int, default=120); p.add_argument("--chunk-size", type=int, default=8); p.add_argument("--poll-sec", type=float, default=0.02); p.add_argument("--startup-settle-sec", type=float, default=1.0)
    p.add_argument("--timestamp-mode", choices=["reconstructed", "lsl_chunk"], default="reconstructed"); p.add_argument("--saturation-review-uv", type=float, default=100000.0)
    p.add_argument("--log-level", choices=["none", "board", "dev"], default="none"); p.add_argument("--no-status-stream", action="store_true")
    p.add_argument("--log-dir", default="openbci_brainflow_eegonly_logs"); p.add_argument("--stats-json", default="", help="Optional additional copy of final QC JSON")
    p.add_argument("--session-manifest", default="", help="Optional runner/session manifest path to reference"); p.add_argument("--calibration-profile", default="", help="Optional profile hashed into provenance")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parser().parse_args(argv)
    if args.list_ports: return list_ports()
    board_id, board_label = board_from_label(args.board); synthetic = "synthetic" in board_label.lower()
    if not synthetic and not args.serial_port: raise SystemExit("--serial-port is required for Cyton/Cyton-Daisy")
    if args.log_level == "dev": BoardShim.enable_dev_board_logger()
    elif args.log_level == "board": BoardShim.enable_board_logger()
    else: BoardShim.disable_board_logger()

    run_uuid = args.run_uuid.strip() or str(uuid.uuid4())
    source_id = args.source_id.strip() or f"praycg_eegonly_v1_1_{args.board}_{run_uuid.replace('-', '')[:12]}"
    run_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_dir = Path(args.log_dir).expanduser().resolve(); log_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = log_dir / f"eegonly_v1_1_manifest_{run_stamp}_{run_uuid[:8]}.json"; events_path = log_dir / f"eegonly_v1_1_events_{run_stamp}_{run_uuid[:8]}.csv"; diag_path = log_dir / f"eegonly_v1_1_chunk_diagnostics_{run_stamp}_{run_uuid[:8]}.csv"; qc_path = log_dir / f"eegonly_v1_1_final_qc_{run_stamp}_{run_uuid[:8]}.json"
    manifest: Dict[str, Any] = {"schema": SCHEMA + "_manifest", "created_unix": time.time(), "run_uuid": run_uuid, "source_id": source_id, "board": args.board, "board_id": board_id, "board_label": board_label, "serial_port": args.serial_port, "args": vars(args), "software": software_versions(), "session_manifest": args.session_manifest or None, "calibration_profile": args.calibration_profile or None, "calibration_profile_sha256": file_sha256(args.calibration_profile), "state": "CREATED"}
    atomic_write_json(manifest_path, manifest)
    events_f = events_path.open("w", newline="", encoding="utf-8"); event_writer = csv.DictWriter(events_f, fieldnames=["unix_time", "lsl_time", "run_uuid", "event", "details"]); event_writer.writeheader()
    diag_fields = ["unix_time", "lsl_time", "run_uuid", "chunk_index", "samples", "samples_total", "buffer_before", "buffer_after", "effective_rate_hz", "package_first", "package_last", "package_missing", "package_duplicates", "package_out_of_order", "max_timestamp_gap_sec", "device_timestamp_first", "device_timestamp_last", "clock_offset_first_sec", "clock_offset_last_sec", "nonfinite_count", "flat_channel_count", "saturation_count"]
    diag_f = diag_path.open("w", newline="", encoding="utf-8"); diag_writer = csv.DictWriter(diag_f, fieldnames=diag_fields); diag_writer.writeheader()
    status_outlet = None if args.no_status_stream else make_status_outlet(args.status_stream_name, source_id, run_uuid)

    def log(event: str, details: Optional[Dict[str, Any]] = None) -> None:
        payload = {"run_uuid": run_uuid, **(details or {})}; lsl_now = local_clock(); detail_json = json.dumps(payload, sort_keys=True, default=str)
        event_writer.writerow({"unix_time": time.time(), "lsl_time": lsl_now, "run_uuid": run_uuid, "event": event, "details": detail_json}); events_f.flush(); print(f"[{time.strftime('%H:%M:%S')}] {event} {detail_json}", flush=True)
        if status_outlet is not None:
            try: status_outlet.push_sample([event + "|" + detail_json], timestamp=lsl_now, pushthrough=True)
            except TypeError: status_outlet.push_sample([event + "|" + detail_json], timestamp=lsl_now)

    params = BrainFlowInputParams(); params.serial_port = args.serial_port; board = BoardShim(board_id, params)
    stop = {"value": False, "reason": "normal_stop"}
    def stop_handler(signum, _frame) -> None:
        stop["value"] = True; stop["reason"] = f"signal_{signum}"
        try: log("STOP_SIGNAL_RECEIVED", {"signal": signum})
        except Exception: pass
    signal.signal(signal.SIGINT, stop_handler)
    if hasattr(signal, "SIGTERM"): signal.signal(signal.SIGTERM, stop_handler)

    prepared = streaming = False; samples_total = chunks_total = 0; missing_total = duplicates_total = out_of_order_total = 0; nonfinite_total = saturation_total = 0; max_gap = 0.0; max_buffer = 0; last_pkg: Optional[int] = None; last_ts: Optional[float] = None
    start_lsl = local_clock(); error_text = ""; exit_reason = "normal_stop"; return_code = 0
    try:
        log("BRIDGE_STARTING", {"manifest": str(manifest_path), "version": BRIDGE_VERSION}); board.prepare_session(); prepared = True; manifest["state"] = "PREPARED"; atomic_write_json(manifest_path, manifest)
        eeg_rows = [int(x) for x in BoardShim.get_eeg_channels(board_id)]; package_row = get_row(board_id, "get_package_num_channel"); timestamp_row = get_row(board_id, "get_timestamp_channel"); srate = float(BoardShim.get_sampling_rate(board_id)); labels = labels_for(len(eeg_rows), args.confirmed_channel_map, args.channel_labels)
        outlet = make_eeg_outlet(args, labels, srate, source_id, board_label, board_id, run_uuid)
        manifest.update({"sample_rate_hz": srate, "eeg_rows": eeg_rows, "package_row": package_row, "timestamp_row": timestamp_row, "channel_labels": labels, "state": "READY"}); atomic_write_json(manifest_path, manifest)
        log("LSL_EEG_OUTLET_ONLINE", {"stream_name": args.stream_name, "channels": len(eeg_rows), "sample_rate_hz": srate, "source_id": source_id}); log("ALS_PT19_DISABLED_NO_ANALOG_AUX_STREAM")
        board.start_stream(max(1024, args.buffer_size), ""); streaming = True; time.sleep(max(0.0, args.startup_settle_sec)); start_lsl = local_clock(); manifest["state"] = "RUNNING"; atomic_write_json(manifest_path, manifest); log("BRAINFLOW_STREAM_STARTED")
        last_heartbeat = time.time()
        while not stop["value"]:
            if args.duration > 0 and local_clock() - start_lsl >= args.duration: exit_reason = "duration_complete"; log("DURATION_COMPLETE"); break
            buffer_before = int(board.get_board_data_count()); max_buffer = max(max_buffer, buffer_before)
            if buffer_before < max(1, args.chunk_size): time.sleep(max(0.001, args.poll_sec)); continue
            data = board.get_board_data(); buffer_after = int(board.get_board_data_count())
            if data is None or not data.size: continue
            eeg = data[eeg_rows, :].T.astype(np.float32, copy=False); n = int(eeg.shape[0])
            if n <= 0: continue
            packages = np.rint(data[package_row, :]).astype(int) if package_row is not None and 0 <= package_row < data.shape[0] else None; device_ts = data[timestamp_row, :] if timestamp_row is not None and 0 <= timestamp_row < data.shape[0] else None
            stamps, last_pkg, last_ts, counts, chunk_gap = reconstruct_lsl_timestamps(n, srate, packages, last_pkg, last_ts, local_clock())
            if args.timestamp_mode == "reconstructed":
                for sample, stamp in zip(eeg, stamps): outlet.push_sample(sample.tolist(), timestamp=stamp, pushthrough=False)
            else: outlet.push_chunk(eeg.tolist(), timestamp=stamps[-1])
            health = channel_health(eeg, args.saturation_review_uv); samples_total += n; chunks_total += 1; missing_total += counts["missing"]; duplicates_total += counts["duplicates"]; out_of_order_total += counts["out_of_order"]; nonfinite_total += health["nonfinite_count"]; saturation_total += health["saturation_count"]; max_gap = max(max_gap, chunk_gap)
            now_lsl = local_clock(); effective = samples_total / max(1e-9, now_lsl - start_lsl)
            host_unix_last = time.time(); host_unix_first = host_unix_last - (n - 1) / srate
            row = {"unix_time": host_unix_last, "lsl_time": now_lsl, "run_uuid": run_uuid, "chunk_index": chunks_total, "samples": n, "samples_total": samples_total, "buffer_before": buffer_before, "buffer_after": buffer_after, "effective_rate_hz": effective, "package_first": int(packages[0]) if packages is not None and len(packages) else None, "package_last": int(packages[-1]) if packages is not None and len(packages) else None, "package_missing": counts["missing"], "package_duplicates": counts["duplicates"], "package_out_of_order": counts["out_of_order"], "max_timestamp_gap_sec": chunk_gap, **device_timestamp_summary(device_ts, host_unix_first, host_unix_last), "nonfinite_count": health["nonfinite_count"], "flat_channel_count": health["flat_channel_count"], "saturation_count": health["saturation_count"]}
            diag_writer.writerow(row); diag_f.flush()
            if time.time() - last_heartbeat >= 5.0: log("EEG_ONLY_BRIDGE_HEARTBEAT", {"samples_total": samples_total, "effective_rate_hz": round(effective, 3), "missing_total": missing_total, "max_buffer_samples": max_buffer}); last_heartbeat = time.time()
        if stop["value"]: exit_reason = stop["reason"]
        log("BRIDGE_STOPPING", {"samples_total": samples_total, "exit_reason": exit_reason})
    except Exception as exc:
        return_code = 1; exit_reason = "exception"; error_text = repr(exc)
        try: log("BRIDGE_ERROR", {"error": error_text})
        except Exception: print("BRIDGE_ERROR", error_text, file=sys.stderr)
    finally:
        if streaming:
            try: board.stop_stream()
            except Exception: pass
        if prepared:
            try: board.release_session()
            except Exception: pass
        elapsed = max(0.0, local_clock() - start_lsl)
        qc = final_qc(run_uuid=run_uuid, bridge_version=BRIDGE_VERSION, exit_reason=exit_reason, error=error_text, expected_rate_hz=float(manifest.get("sample_rate_hz", 0.0)), samples_total=samples_total, elapsed_sec=elapsed, package_missing=missing_total, duplicates=duplicates_total, out_of_order=out_of_order_total, max_gap_sec=max_gap, nonfinite_count=nonfinite_total, saturation_count=saturation_total, max_buffer_samples=max_buffer)
        atomic_write_json(qc_path, qc)
        if args.stats_json: atomic_write_json(Path(args.stats_json).expanduser(), qc)
        manifest.update({"state": "STOPPED", "stopped_utc": datetime.now(timezone.utc).isoformat(), "exit_reason": exit_reason, "final_qc": str(qc_path), "final_qc_status": qc["status"], "diagnostics_csv": str(diag_path), "events_csv": str(events_path)}); atomic_write_json(manifest_path, manifest)
        try: log("FINAL_QC", {"status": qc["status"], "qc_path": str(qc_path), "exit_reason": exit_reason})
        except Exception: pass
        events_f.close(); diag_f.close(); print(json.dumps({"manifest": str(manifest_path), "final_qc": str(qc_path), "status": qc["status"]}, indent=2), flush=True)
    return return_code


if __name__ == "__main__": raise SystemExit(main())
