#!/usr/bin/env python3
"""Record the frozen CAI/SID v0.2 prospective-candidate decisions and hashes."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


root = Path(__file__).resolve().parents[1]
targets = [
    root / "scripts" / "praycg_cai_sid_v0_2.py",
    root / "scripts" / "praycg_cai_readiness_preflight_v0_2.py",
    root / "scripts" / "praycg_cai_sid_exploratory_gui_v0_2.py",
    root / "config" / "analysis_config_v0_2.json",
    root / "config" / "canonical_feature_schema_v0_2.json",
    root / "docs" / "CAI_SID_MATHEMATICAL_SPECIFICATION_v0_2.md",
    root / "docs" / "CAI_SID_CONSTRUCT_AND_CLAIM_BOUNDARY_v0_2.md",
    root / "docs" / "SOFTWARE_ACCEPTANCE_AND_PROMOTION_GATES_v0_2.md",
]
records = []
for path in targets:
    records.append({"path": str(path.relative_to(root)).replace("\\", "/"), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "size_bytes": path.stat().st_size})
payload = {
    "schema": "PRAYCG_CAISID_FrozenProspectiveCandidate_v0_2",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "candidate": "CAI/SID v0.2", "status": "EXPLORATORY_FROZEN_PROSPECTIVE_CANDIDATE",
    "approval_basis": "Frozen at the project author's direction for prospective evaluation; this is not empirical validation, preregistration, ethics approval, or promotion.",
    "decisions": {
        "name": "Controlled Access-Integration Index",
        "corrected_loop": "K_product_plus = 2*sqrt(max(E-0.5,0)*max(Y_future-0.5,0)); non-estimable correlation supplies no positive support",
        "primary_support": "equal mean of E_plus, Y_plus, and K",
        "primary_penalty": "one minus the equal mean of artifact excess and task-extraction excess",
        "dga_and_contextual_gating": "separate sensitivity output; prohibited from primary CAI",
        "autonomic": "separate convergence/confound layer; prohibited from primary CAI until prospectively validated",
        "invalid_windows": "missing, never zero",
        "claim_boundary": "unitless proxy; not a probability, consciousness measurement, clinical result, or proof of narrative reception",
        "historical_tuning": "stopped at v0.2; any further tuning is a separately labeled v0.3 development candidate"
    },
    "files": records,
}
out = root / "config" / "CAI_SID_v0_2_FROZEN_PROSPECTIVE_CANDIDATE.json"
out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
print(out)
