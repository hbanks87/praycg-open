# CAI/SID v0.2 — Exploratory Frozen Prospective Candidate

CAI means **Controlled Access-Integration Index**. It is a bounded, unitless composite of declared signal features. It is not a probability, direct consciousness measurement, clinical result, or proof of narrative reception.

Use the readiness preflight before analysis. It selects a plausible time-resolved feature frame, records exact legacy adapters, checks protocol/conditions, block identifiers, timestamps, Baseline 1, feature and branch coverage, artifact sentinels, ALS status, and availability of autonomic, DGA, ShotOrder, and anchor evidence. It returns `PASS`, `CAUTION`, or `INELIGIBLE`. A readiness result addresses computation only, not validity or Master Suite eligibility.

The GUI requires a non-ineligible readiness result and links to the branch summary, contrasts, warnings, validation report, and readiness report. Hard-QC invalid windows remain missing. Optional unavailable visual or NIP inputs are not silently converted into positive evidence. DGA/contextual gating and continuous autonomic outputs remain separate from primary CAI.

The freeze manifest records the approved v0.2 decisions and exact code/configuration hashes. Do not tune v0.2 against the four historical runs. Any additional tuning must be a separately labeled v0.3 development candidate.
