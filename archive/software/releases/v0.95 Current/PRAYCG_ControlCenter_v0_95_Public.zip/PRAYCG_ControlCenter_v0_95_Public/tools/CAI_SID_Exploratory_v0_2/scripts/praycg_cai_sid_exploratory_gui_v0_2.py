#!/usr/bin/env python3
"""Non-technical launcher for exploratory CAI/SID v0.2."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from tkinter import BOTH, END, LEFT, RIGHT, X, BooleanVar, StringVar, Tk, filedialog, messagebox, ttk

import pandas as pd


VERSION = "0.2.0"
BOUNDARY = (
    "EXPLORATORY — Controlled Access-Integration Index is a unitless signal proxy. "
    "It is not a probability, consciousness measure, clinical result, or Master Suite eligibility input."
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def reveal(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(str(path))
    if sys.platform == "win32":
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


def write_validation_report(out_dir: Path, readiness: dict) -> Path:
    expected = [
        "cai_sid_v0_2_time_series.csv", "cai_sid_v0_2_branch_summary.csv",
        "cai_sid_v0_2_contrasts.csv", "cai_sid_v0_2_warnings.json",
        "cai_sid_v0_2_adapter_manifest.json", "cai_sid_v0_2_analysis_manifest.json",
    ]
    records = []
    for name in expected:
        path = out_dir / name
        records.append({"file": name, "exists": path.exists(), "size_bytes": path.stat().st_size if path.exists() else 0, "sha256": sha256_file(path) if path.exists() else None})
    branch = out_dir / "cai_sid_v0_2_branch_summary.csv"
    branch_rows = len(pd.read_csv(branch)) if branch.exists() else 0
    passed = all(r["exists"] and r["size_bytes"] > 0 for r in records) and branch_rows > 0
    payload = {
        "schema": "PRAYCG_CAI_SID_ExploratoryValidation_v0_2", "generated_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if passed else "FAIL", "readiness_status": readiness.get("status"),
        "branch_summary_rows": branch_rows, "files": records, "claim_boundary": BOUNDARY,
    }
    json_path = out_dir / "cai_sid_v0_2_validation_report.json"
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    md_path = out_dir / "cai_sid_v0_2_validation_report.md"
    lines = ["# CAI/SID v0.2 Computational Validation Report", "", f"**Status: {payload['status']}**", "", BOUNDARY, "", f"Readiness status: `{payload['readiness_status']}`", f"Branch summary rows: `{branch_rows}`", "", "## Output integrity", ""]
    for record in records:
        lines.append(f"- `{record['file']}` — {'present' if record['exists'] else 'missing'}; {record['size_bytes']} bytes; SHA-256 `{record['sha256']}`")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return md_path


class App:
    def __init__(self, root: Tk, args: argparse.Namespace) -> None:
        self.root = root
        self.root.title("PRAYCG Exploratory CAI/SID v0.2")
        self.root.geometry("1040x720")
        self.tool_root = Path(__file__).resolve().parents[1]
        self.run_var = StringVar(value=args.run_folder or "")
        self.analysis_var = StringVar(value=args.analysis_folder or args.run_folder or "")
        default_parent = Path(args.analysis_folder or args.run_folder).resolve() if (args.analysis_folder or args.run_folder) else Path.cwd()
        self.out_var = StringVar(value=str(default_parent / "Exploratory_CAISID_v0_2"))
        self.status_var = StringVar(value="Readiness has not been checked.")
        self.disable_nip = BooleanVar(value=False)
        self.readiness: dict = {}
        self.process: subprocess.Popen[str] | None = None
        self._build()

    def _build(self) -> None:
        outer = ttk.Frame(self.root, padding=14)
        outer.pack(fill=BOTH, expand=True)
        ttk.Label(outer, text="Exploratory CAI/SID v0.2", font=("Segoe UI", 17, "bold")).pack(anchor="w")
        ttk.Label(outer, text=BOUNDARY, foreground="#8a1c1c", wraplength=990, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(4, 12))

        paths = ttk.LabelFrame(outer, text="Selected data", padding=10)
        paths.pack(fill=X)
        self._path_row(paths, "Run folder", self.run_var, self._browse_run, 0)
        self._path_row(paths, "Analysis folder", self.analysis_var, self._browse_analysis, 1)
        self._path_row(paths, "Exploratory output", self.out_var, self._browse_out, 2)

        readiness = ttk.LabelFrame(outer, text="Required readiness gate", padding=10)
        readiness.pack(fill=X, pady=(10, 0))
        ttk.Label(readiness, textvariable=self.status_var, font=("Segoe UI", 11, "bold")).pack(side=LEFT, padx=(0, 12))
        self.preflight_button = ttk.Button(readiness, text="Run readiness preflight", command=self.run_preflight)
        self.preflight_button.pack(side=RIGHT)

        actions = ttk.Frame(outer)
        actions.pack(fill=X, pady=10)
        self.run_button = ttk.Button(actions, text="Run exploratory CAI/SID", command=self.run_analysis, state="disabled")
        self.run_button.pack(side=LEFT)
        ttk.Checkbutton(actions, text="Disable optional NIP input", variable=self.disable_nip).pack(side=LEFT, padx=12)
        ttk.Button(actions, text="Open output folder", command=lambda: self.open_path(Path(self.out_var.get()))).pack(side=RIGHT)

        links = ttk.LabelFrame(outer, text="Results", padding=8)
        links.pack(fill=X)
        for label, filename in [
            ("Branch summary", "cai_sid_v0_2_branch_summary.csv"),
            ("Contrasts", "cai_sid_v0_2_contrasts.csv"),
            ("Warnings", "cai_sid_v0_2_warnings.json"),
            ("Validation report", "cai_sid_v0_2_validation_report.md"),
            ("Readiness report", "readiness/cai_readiness_preflight_v0_2.md"),
        ]:
            ttk.Button(links, text=label, command=lambda n=filename: self.open_path(Path(self.out_var.get()) / n)).pack(side=LEFT, padx=4)

        log_frame = ttk.LabelFrame(outer, text="Activity", padding=6)
        log_frame.pack(fill=BOTH, expand=True, pady=(10, 0))
        from tkinter import Text
        self.log = Text(log_frame, height=18, wrap="word")
        self.log.pack(fill=BOTH, expand=True)
        self._log("Choose a run folder, then run the readiness preflight. CAI cannot launch when the result is INELIGIBLE.")

    def _path_row(self, parent: ttk.LabelFrame, label: str, var: StringVar, command, row: int) -> None:
        ttk.Label(parent, text=label, width=18).grid(row=row, column=0, sticky="w", pady=3)
        ttk.Entry(parent, textvariable=var).grid(row=row, column=1, sticky="ew", padx=6, pady=3)
        ttk.Button(parent, text="Browse", command=command).grid(row=row, column=2, pady=3)
        parent.columnconfigure(1, weight=1)

    def _browse_run(self) -> None:
        value = filedialog.askdirectory(initialdir=self.run_var.get() or str(Path.cwd()))
        if value:
            self.run_var.set(value)
            if not self.analysis_var.get():
                self.analysis_var.set(value)
            self.out_var.set(str(Path(self.analysis_var.get() or value) / "Exploratory_CAISID_v0_2"))
            self._invalidate()

    def _browse_analysis(self) -> None:
        value = filedialog.askdirectory(initialdir=self.analysis_var.get() or self.run_var.get() or str(Path.cwd()))
        if value:
            self.analysis_var.set(value)
            self.out_var.set(str(Path(value) / "Exploratory_CAISID_v0_2"))
            self._invalidate()

    def _browse_out(self) -> None:
        value = filedialog.askdirectory(initialdir=self.out_var.get() or str(Path.cwd()))
        if value:
            self.out_var.set(value)
            self._invalidate()

    def _invalidate(self) -> None:
        self.readiness = {}
        self.status_var.set("Inputs changed; run readiness again.")
        self.run_button.configure(state="disabled")

    def _log(self, message: str) -> None:
        self.log.insert(END, message.rstrip() + "\n")
        self.log.see(END)

    def open_path(self, path: Path) -> None:
        try:
            reveal(path)
        except Exception as exc:
            messagebox.showerror("Cannot open", str(exc))

    def _run_async(self, command: list[str], callback) -> None:
        def worker() -> None:
            try:
                self.process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
                assert self.process.stdout is not None
                for line in self.process.stdout:
                    self.root.after(0, self._log, line)
                code = self.process.wait()
                self.root.after(0, callback, code)
            except Exception as exc:
                self.root.after(0, self._log, f"ERROR: {exc}")
                self.root.after(0, callback, 99)
        threading.Thread(target=worker, daemon=True).start()

    def run_preflight(self) -> None:
        run = Path(self.run_var.get())
        if not run.is_dir():
            messagebox.showerror("Run folder required", "Select an existing PRAYCG run folder.")
            return
        out = Path(self.out_var.get()) / "readiness"
        command = [sys.executable, str(self.tool_root / "scripts" / "praycg_cai_readiness_preflight_v0_2.py"), "--run-folder", str(run), "--out", str(out)]
        analysis = Path(self.analysis_var.get())
        if analysis.is_dir():
            command += ["--analysis-folder", str(analysis)]
        self.preflight_button.configure(state="disabled")
        self.run_button.configure(state="disabled")
        self.status_var.set("Checking readiness…")
        self._run_async(command, self._preflight_done)

    def _preflight_done(self, code: int) -> None:
        self.preflight_button.configure(state="normal")
        report = Path(self.out_var.get()) / "readiness" / "cai_readiness_preflight_v0_2.json"
        try:
            self.readiness = json.loads(report.read_text(encoding="utf-8"))
        except Exception as exc:
            self.status_var.set("Readiness failed.")
            self._log(f"Could not read readiness result: {exc}")
            return
        status = self.readiness.get("status", "INELIGIBLE")
        self.status_var.set(f"Readiness: {status}")
        if status != "INELIGIBLE":
            self.run_button.configure(state="normal")
        self._log(f"Readiness completed with {status} (process code {code}).")

    def run_analysis(self) -> None:
        status = self.readiness.get("status")
        if status == "INELIGIBLE" or not status:
            messagebox.showerror("Readiness required", "CAI/SID cannot run until preflight is PASS or CAUTION.")
            return
        if status == "CAUTION" and not messagebox.askyesno("Proceed with cautions?", "The run is computationally usable only with documented cautions. Continue exploratory analysis?"):
            return
        manifest = self.readiness.get("generated_run_manifest")
        if not manifest or not Path(manifest).is_file():
            messagebox.showerror("Manifest unavailable", "The readiness manifest is missing. Run preflight again.")
            return
        out = Path(self.out_var.get())
        out.mkdir(parents=True, exist_ok=True)
        command = [sys.executable, str(self.tool_root / "scripts" / "praycg_cai_sid_v0_2.py"), "--config", str(self.tool_root / "config" / "analysis_config_v0_2.json"), "--run-manifest", manifest, "--out", str(out)]
        if self.disable_nip.get():
            command.append("--disable-nip")
        self.run_button.configure(state="disabled")
        self.preflight_button.configure(state="disabled")
        self.status_var.set("Exploratory CAI/SID running…")
        self._run_async(command, self._analysis_done)

    def _analysis_done(self, code: int) -> None:
        self.preflight_button.configure(state="normal")
        self.run_button.configure(state="normal" if self.readiness.get("status") != "INELIGIBLE" else "disabled")
        if code == 0:
            report = write_validation_report(Path(self.out_var.get()), self.readiness)
            self.status_var.set("CAI/SID complete — exploratory only")
            self._log(f"Validation report: {report}")
        else:
            self.status_var.set(f"CAI/SID failed (exit {code})")
            messagebox.showerror("Analysis failed", "See the activity log for details.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-folder")
    parser.add_argument("--analysis-folder")
    parser.add_argument("--control-context-file")
    args = parser.parse_args()
    root = Tk()
    App(root, args)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
