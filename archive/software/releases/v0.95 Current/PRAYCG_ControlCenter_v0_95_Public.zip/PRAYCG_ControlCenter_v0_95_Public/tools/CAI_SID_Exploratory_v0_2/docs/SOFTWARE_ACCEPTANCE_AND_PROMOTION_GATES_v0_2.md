# CAI/SID Software Acceptance and Promotion Gates v0.2

## Levels

- `DEVELOPMENT`: code or specification incomplete.
- `EXPLORATORY`: reproducible retrospective use is allowed with the claim boundary.
- `PROSPECTIVE_CANDIDATE`: algorithm and protocol are frozen before new data.
- `STANDARD_SECONDARY`: independent prospective evidence and software gates pass.

## Required gates

1. **Archive integrity:** supplied developmental artifacts are preserved with hashes.
2. **Portable reproduction:** one documented command regenerates the package outputs from included derived sources without fixed machine paths.
3. **Algorithm-code identity:** equations, configuration, code, and report values agree within declared numerical tolerance.
4. **Automated tests:** mathematical bounds, low-low loop rejection, missingness, irregular time, branch-tail handling, repeated-block isolation, portability, and deterministic reproduction pass.
5. **Complete provenance:** source hashes, adapters, selected columns, reference distributions, configuration, code version, dependency versions, warnings, and exclusions are recorded.
6. **No condition-coded physiology:** primary CAI contains no hand-assigned condition values or expected-archetype rules.
7. **Null behavior:** frozen time-shift/pseudo-event nulls and critical sensitivity checks behave as preregistered.
8. **Independent prospective validity:** a registered study on new participants/stimuli evaluates the frozen endpoint against independent outcomes.
9. **Reliability and calibration:** test-retest or equivalent reliability, held-out performance, uncertainty, and any probabilistic calibration are established.
10. **Public claim compliance:** reports and UI expose the proxy boundary and evidence grade.

## Promotion rule

Failure or non-evaluation of Gates 8 or 9 prevents promotion to `STANDARD_SECONDARY`. Passing software gates alone supports `EXPLORATORY` or, after registration and freezing, `PROSPECTIVE_CANDIDATE` status.

