# CAI/SID Mathematical Specification v0.2

## Reference transformation

For feature `x`, the preferred reference is Baseline 1 within the run:

```text
z_B1(x_t) = 0.67448975 * (x_t - median_B1(x)) / MAD_B1(x)
```

The result is clipped only after transformation to the configured numerical range. If Baseline 1 lacks the minimum observations or a usable scale, the frozen exploratory configuration permits a full-run fallback and records it. A production analysis must fail unless its preregistered fallback rule is satisfied.

Already standardized legacy columns are still re-referenced to Baseline 1 because their original reference frames differ. This produces within-run baseline-deviation units, not population-standardized units.

## Fast and slow components

The frozen exploratory candidate retains the v0.1 feature proportions but renormalizes only over explicitly available positive inputs:

```text
E_latent(t) = weighted_mean(MeaningGamma, TSP, optional NIP) - 0.10 * max(VisualGamma, 0)
E(t) = sigmoid(E_latent(t))

Y_latent(t) = 0.50*ThetaIntegration + 0.30*NAS + 0.20*PosteriorAlpha
Y(t) = sigmoid(Y_latent(t))
```

The canonical adapter and selected source column are included in every manifest.

## Retrospective future integration

For a block instance `b`:

```text
Y_future(t) = mean{Y(s): s is in the same block and t+8 <= s <= t+30}
```

No branch-end median fill is allowed. `Y_future` is missing when the minimum future coverage is unavailable.

## Corrected positive loop

Define positive evidence above the neutral point:

```text
e+(t) = max(E(t) - 0.5, 0)
y+(t) = max(Y_future(t) - 0.5, 0)
K_product+(t) = 2*sqrt(e+(t)*y+(t))
```

This is bounded in `[0,1]` and cannot reward jointly low E and Y.

For an estimable local correlation:

```text
rho+(t) = max(corr_local(E, Y_future), 0)
K(t) = 0.70*K_product+(t) + 0.30*rho+(t)
```

When correlation is not estimable, K equals `K_product+`; missing correlation never becomes positive support.

## Artifact, task, and QC

```text
A(t) = sigmoid(weighted artifact latent)
X(t) = sigmoid(task latent)

A+(t) = clip(2*(A(t)-0.5), 0, 1)
X+(t) = clip(2*(X(t)-0.5), 0, 1)
```

Hard QC is evaluated on standardized artifact sentinels. Failed windows receive `CAI = missing`, not zero. Coverage is a required result.

## Primary exploratory composite

To avoid pretending that hand-selected coefficients are fitted biological constants, v0.2 uses equal weights:

```text
E+(t) = clip(2*(E(t)-0.5), 0, 1)
Y+(t) = clip(2*(Y(t)-0.5), 0, 1)

Support(t) = mean(E+(t), Y+(t), K(t))
Penalty(t) = mean(A+(t), X+(t))

CAI_core(t) = Support(t) * (1 - Penalty(t))
```

`CAI_core` is unitless and bounded in `[0,1]`; it is not a probability. It is missing unless E, Y, K, A, X, and hard QC are valid.

## Contextual reliability gate

When independent DGA inputs are supplied:

```text
Reliability_context = D_gate * (1 - confound_load) * (1 - extraction_load)
CAI_context_gated = CAI_core * Reliability_context
```

This is an attribution-confidence sensitivity output. It must not replace primary CAI or be presented as independent physiological evidence.

## Time summaries

For valid duration `T_valid`:

```text
Mean_CAI = integral(CAI_core dt) / T_valid
CAI_load = integral(CAI_core dt)
CAI_occupancy(tau) = valid time with CAI_core >= tau / T_valid
```

The configured occupancy threshold is exploratory. Rolling summaries use timestamps and a declared time span, not an assumed number of samples.

## Uncertainty

Branch contrasts use moving-block bootstrap intervals with the block length, seed, and replicate count recorded. These intervals describe within-run temporal stability; they do not convert one participant into a population sample.

