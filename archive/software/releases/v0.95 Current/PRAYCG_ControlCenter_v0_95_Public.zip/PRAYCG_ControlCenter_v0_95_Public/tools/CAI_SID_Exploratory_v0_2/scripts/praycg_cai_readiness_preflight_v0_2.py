#!/usr/bin/env python3
"""Read-only readiness preflight for exploratory PRAYCG CAI/SID v0.2.

The preflight never changes Master Suite eligibility.  It selects a plausible
analysis frame, records every adapter decision, and returns PASS, CAUTION, or
INELIGIBLE with machine-readable reasons.
"""
from __future__ import annotations

import argparse
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


VERSION = "0.2.0"
CONDITION_MAP = {
    "BASELINE1": "BASELINE_1", "BASELINE_1": "BASELINE_1",
    "BASELINE2": "BASELINE_2_REFLECTION", "BASELINE_2": "BASELINE_2_REFLECTION",
    "BASELINE_2_REFLECTION": "BASELINE_2_REFLECTION",
    "CONTROL": "CONTROL_1", "CONTROL_1": "CONTROL_1",
    "PHASESCRAMBLED": "PHASE_SCRAMBLED_1", "PHASE_SCRAMBLED": "PHASE_SCRAMBLED_1",
    "PHASE_SCRAMBLED_1": "PHASE_SCRAMBLED_1",
    "SHOTORDER": "SHOTORDER_SCRAMBLE_1", "SHOTORDER_SCRAMBLE": "SHOTORDER_SCRAMBLE_1",
    "SHOTORDER_SCRAMBLE_1": "SHOTORDER_SCRAMBLE_1",
    "TARGET": "TARGET_1", "TARGET_1": "TARGET_1",
    "OVERRIDE": "CONTEXTUAL_OVERRIDE_1", "CONTEXTUAL_OVERRIDE": "CONTEXTUAL_OVERRIDE_1",
    "CONTEXTUAL_OVERRIDE_1": "CONTEXTUAL_OVERRIDE_1",
    "WASHOUT1": "WASHOUT_1", "WASHOUT_1": "WASHOUT_1",
    "WASHOUT2": "WASHOUT_2", "WASHOUT_2": "WASHOUT_2",
    "WASHOUT3": "WASHOUT_3", "WASHOUT_3": "WASHOUT_3",
}

# First alias is the preferred v0.2 name.  Later aliases are explicit legacy
# adapters and therefore produce CAUTION rather than silent equivalence.
ALIASES: Dict[str, List[str]] = {
    "time": ["time_lsl", "lsl_time_center", "time", "window_mid", "timestamp"],
    "condition": ["condition", "phase", "branch", "condition_name"],
    "block": ["block_id", "block_instance_id", "segment", "trial_id"],
    "meaning": ["meaninggamma_score", "meaninggamma_z", "meaning_gamma_proxy", "gamma_meaning_raw_z", "MR_score", "gamma_pt_30_45_z"],
    "tsp": ["tsp_z", "tsp_proxy", "temporal_proxy_lgamma_30_45"],
    "theta": ["theta_integration_z", "theta_integration_proxy", "ENC_score", "theta_primary_z", "theta_midline_z", "theta_4_8_meaning_core"],
    "nas": ["nas_score", "nast_nas_z", "NIP_resonance_integration", "R_int"],
    "alpha": ["alpha_posterior_z", "alpha_posterior_proxy", "alpha_proxy_z", "alpha_posterior", "alpha_drop_proxy_z"],
    "artifact": ["artifact_score", "artifact_penalty", "artifact_z"],
    "task": ["taskgamma_score", "taskgamma_z", "task_gamma_proxy", "task_gamma_z", "gamma_task_raw_z", "theta_task_z"],
    "hf": ["hf_jaw_45_55_z", "hf_45_55_artifact", "fp1_hf_35_55_z", "pow_hf_proxy_45_55_artifact_sentinel", "artifact_z"],
    "p2p": ["p2p_global_z", "global_ptp_z", "p2p_all", "p2p_artifact", "max_p2p", "median_p2p"],
    "visual": ["gamma_visual_30_45_z", "gamma_visual_raw_z", "visual_gamma_z", "visual_gamma_proxy"],
    "nip": ["NIP_resid_density_condition_full_exogenous", "NIP_density", "nip_density"],
}
REQUIRED = ["meaning", "tsp", "theta", "nas", "alpha", "artifact", "task", "hf"]
OPTIONAL = ["p2p", "visual", "nip"]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def canonical_condition(value: Any) -> str:
    text = str(value).strip().upper().replace(" ", "_").replace("-", "_")
    return CONDITION_MAP.get(text, CONDITION_MAP.get(text.replace("_", ""), text))


def pick_alias(columns: Iterable[str], role: str) -> Tuple[Optional[str], Optional[int]]:
    lookup = {str(c).lower(): str(c) for c in columns}
    for index, alias in enumerate(ALIASES[role]):
        if alias.lower() in lookup:
            return lookup[alias.lower()], index
    return None, None


def quick_columns(path: Path) -> List[str]:
    try:
        return list(pd.read_csv(path, nrows=0).columns)
    except Exception:
        return []


def candidate_score(path: Path, columns: List[str]) -> int:
    name = path.name.lower()
    score = 0
    if "praycg_analysis_frame" in name:
        score += 100
    if "canonical" in name or "feature" in name:
        score += 25
    if "summary" in name or "contrast" in name or "null" in name:
        score -= 40
    for role in ["time", "condition"] + REQUIRED:
        if pick_alias(columns, role)[0]:
            score += 5
    try:
        sample = pd.read_csv(path, nrows=1000)
        complete_required = 0
        for role in REQUIRED:
            coverages = [float(pd.to_numeric(sample[c], errors="coerce").notna().mean()) for c in ALIASES[role] if c in sample.columns]
            if max(coverages, default=0.0) >= 0.70:
                complete_required += 1
        score += complete_required * 10
        score += 200 if complete_required == len(REQUIRED) else -200
    except Exception:
        score -= 200
    return score


def pick_usable_alias(frame: pd.DataFrame, role: str) -> Tuple[Optional[str], Optional[int]]:
    """Select the earliest alias with data, not merely an empty placeholder column."""
    lookup = {str(c).lower(): str(c) for c in frame.columns}
    fallback: Tuple[Optional[str], Optional[int]] = (None, None)
    for index, alias in enumerate(ALIASES[role]):
        column = lookup.get(alias.lower())
        if not column:
            continue
        if fallback[0] is None:
            fallback = (column, index)
        if role in {"condition", "block"}:
            coverage = float(frame[column].notna().mean())
        else:
            coverage = float(pd.to_numeric(frame[column], errors="coerce").notna().mean())
        if coverage > 0.0:
            return column, index
    return fallback


def find_frame(run_folder: Path, analysis_folder: Optional[Path]) -> Tuple[Optional[Path], List[Dict[str, Any]]]:
    roots: List[Path] = []
    if analysis_folder and analysis_folder.exists():
        roots.append(analysis_folder)
    if run_folder.exists() and run_folder not in roots:
        roots.append(run_folder)
    examined: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for root in roots:
        for path in root.rglob("*.csv"):
            key = str(path.resolve()).lower()
            if key in seen or path.stat().st_size == 0:
                continue
            seen.add(key)
            cols = quick_columns(path)
            if not cols:
                continue
            examined.append({"path": str(path.resolve()), "score": candidate_score(path, cols), "columns": cols})
    examined.sort(key=lambda item: (item["score"], -len(item["path"])), reverse=True)
    return (Path(examined[0]["path"]) if examined and examined[0]["score"] > 0 else None), examined[:25]


def detect_support_files(run_folder: Path, analysis_folder: Optional[Path]) -> Dict[str, Any]:
    roots = [run_folder] + ([analysis_folder] if analysis_folder and analysis_folder != run_folder else [])
    files: List[Path] = []
    for root in roots:
        if root and root.exists():
            files.extend(p for p in root.rglob("*") if p.is_file())
    names = [p.name.lower() for p in files]
    def matches(*needles: str, suffixes: Optional[set[str]] = None) -> List[str]:
        return [str(p.resolve()) for p in files if any(n in p.name.lower() for n in needles) and (suffixes is None or p.suffix.lower() in suffixes)][:20]
    als = matches("als", "barcode", "lsl_marker")
    autonomic = matches("autonomic_qc", "cardiac_beat", "respiration_array", "respdual")
    dga = matches("dga", "gradient_alignment", suffixes={".csv"})
    anchors = matches("anchor", "alignment_map", suffixes={".json", ".csv"})
    shot = matches("shotorder", "shot_order")
    als_status_values: List[str] = []
    for raw in als:
        path = Path(raw)
        if path.suffix.lower() != ".json":
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if isinstance(payload, dict):
            for key in ["timing_status", "alignment_status", "gate_status", "status"]:
                if payload.get(key) is not None:
                    als_status_values.append(str(payload[key]).upper())
    if any(any(token in value for token in ["FAIL", "INVALID", "INELIGIBLE"]) for value in als_status_values):
        als_timing_status = "FAIL"
    elif any(any(token in value for token in ["CAUTION", "WARN", "ESTIMATED"]) for value in als_status_values):
        als_timing_status = "CAUTION"
    elif any("PASS" in value or "VALID" in value or "LOCKED" in value for value in als_status_values):
        als_timing_status = "PASS"
    else:
        als_timing_status = "AVAILABLE_UNGRADED" if als else "MISSING"
    return {
        "als": {"available": bool(als), "timing_status": als_timing_status, "reported_status_values": sorted(set(als_status_values)), "files": als},
        "autonomic": {"available": bool(autonomic), "files": autonomic},
        "dga": {"available": bool(dga), "files": dga},
        "anchors": {"available": bool(anchors), "files": anchors},
        "shotorder": {"available": bool(shot), "files": shot},
    }


def derive_blocks(conditions: pd.Series) -> pd.Series:
    changed = conditions.ne(conditions.shift()).cumsum()
    return conditions.astype(str) + "__" + changed.astype(str).str.zfill(3)


def numeric_coverage(frame: pd.DataFrame, column: str, mask: pd.Series) -> float:
    if not mask.any():
        return 0.0
    return float(pd.to_numeric(frame.loc[mask, column], errors="coerce").notna().mean())


def status_from(reasons: List[Dict[str, str]]) -> str:
    if any(r["level"] == "INELIGIBLE" for r in reasons):
        return "INELIGIBLE"
    if any(r["level"] == "CAUTION" for r in reasons):
        return "CAUTION"
    return "PASS"


def run_preflight(run_folder: Path, analysis_folder: Optional[Path], out_dir: Path) -> Dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    reasons: List[Dict[str, str]] = []
    selected, examined = find_frame(run_folder, analysis_folder)
    support = detect_support_files(run_folder, analysis_folder)
    result: Dict[str, Any] = {
        "schema": "PRAYCG_CAI_SID_Readiness_v0_2", "version": VERSION,
        "generated_utc": utc_now(), "run_folder": str(run_folder.resolve()),
        "analysis_folder": str(analysis_folder.resolve()) if analysis_folder else None,
        "selected_source_csv": str(selected.resolve()) if selected else None,
        "examined_candidates": examined, "support": support, "reasons": reasons,
        "claim_boundary": "Readiness for exploratory CAI/SID computation only; not evidence of validity, consciousness, meaning reception, or Master Suite eligibility.",
    }
    if selected is None:
        reasons.append({"level": "INELIGIBLE", "code": "NO_ANALYSIS_FRAME", "message": "No CSV containing a plausible time-resolved PRAYCG feature frame was found."})
        result.update({"status": "INELIGIBLE", "generated_run_manifest": None})
        write_outputs(result, out_dir)
        return result

    try:
        frame = pd.read_csv(selected)
    except Exception as exc:
        reasons.append({"level": "INELIGIBLE", "code": "READ_FAILURE", "message": f"Selected frame could not be read: {exc}"})
        result.update({"status": "INELIGIBLE", "generated_run_manifest": None})
        write_outputs(result, out_dir)
        return result

    mappings: Dict[str, str] = {}
    adapter_grade = "CANONICAL_EXACT"
    for role in ["time", "condition", "block"] + REQUIRED + OPTIONAL:
        column, alias_index = pick_usable_alias(frame, role)
        if column:
            mappings[role] = column
            if alias_index and role not in OPTIONAL:
                adapter_grade = "LEGACY_ADAPTED"
                reasons.append({"level": "CAUTION", "code": f"ADAPTER_{role.upper()}", "message": f"{role} uses explicit adapter column '{column}' rather than preferred '{ALIASES[role][0]}'."})
        elif role in ["time", "condition"] + REQUIRED:
            reasons.append({"level": "INELIGIBLE", "code": f"MISSING_{role.upper()}", "message": f"Required role '{role}' has no recognized column."})

    if "condition" in mappings:
        conditions = frame[mappings["condition"]].map(canonical_condition)
        recognized = sorted(set(conditions) & set(CONDITION_MAP.values()))
        unknown = sorted(set(conditions.dropna().astype(str)) - set(CONDITION_MAP.values()))
        if not recognized:
            reasons.append({"level": "INELIGIBLE", "code": "NO_RECOGNIZED_CONDITIONS", "message": "No recognized PRAYCG conditions were found."})
        b1_rows = int((conditions == "BASELINE_1").sum())
        if b1_rows == 0:
            reasons.append({"level": "INELIGIBLE", "code": "NO_BASELINE_1", "message": "Baseline 1 reference is absent."})
        elif b1_rows < 30:
            reasons.append({"level": "CAUTION", "code": "SHORT_BASELINE_1", "message": f"Baseline 1 has {b1_rows} rows; v0.2 specifies at least 30."})
        result["conditions"] = {"recognized": recognized, "unknown": unknown, "baseline_1_rows": b1_rows}
        if "SHOTORDER_SCRAMBLE_1" in recognized:
            support["shotorder"]["available"] = True
        if "SHOTORDER_SCRAMBLE_1" in recognized:
            protocol = "PRAYCG4"
        elif {"TARGET_1", "CONTEXTUAL_OVERRIDE_1"}.issubset(recognized) and ({"CONTROL_1", "PHASE_SCRAMBLED_1"} & set(recognized)):
            protocol = "PRAYCG3"
        else:
            protocol = "UNRESOLVED"
            reasons.append({"level": "CAUTION", "code": "PROTOCOL_UNRESOLVED", "message": "Conditions do not uniquely establish PRAYCG3 or PRAYCG4."})
        result["protocol"] = protocol
    else:
        conditions = pd.Series("", index=frame.index, dtype=str)
        result["conditions"] = {"recognized": [], "unknown": [], "baseline_1_rows": 0}
        result["protocol"] = "UNRESOLVED"

    if "time" in mappings:
        times = pd.to_numeric(frame[mappings["time"]], errors="coerce")
        finite = times.notna()
        if finite.sum() < 2:
            reasons.append({"level": "INELIGIBLE", "code": "INSUFFICIENT_TIME", "message": "Fewer than two finite timestamps are available."})
            timing = {"finite_fraction": float(finite.mean()), "monotonic": False}
        else:
            diffs = times[finite].diff().dropna()
            nonpositive = int((diffs <= 0).sum())
            median_step = float(diffs[diffs > 0].median()) if (diffs > 0).any() else None
            large_gaps = int((diffs > max(2.0, 5.0 * median_step)).sum()) if median_step is not None and np.isfinite(median_step) else 0
            if nonpositive:
                reasons.append({"level": "INELIGIBLE", "code": "NONMONOTONIC_TIME", "message": f"Found {nonpositive} non-positive timestamp steps."})
            if large_gaps:
                reasons.append({"level": "CAUTION", "code": "TIMESTAMP_GAPS", "message": f"Found {large_gaps} gaps larger than max(2 s, 5× median step)."})
            timing = {"finite_fraction": float(finite.mean()), "monotonic": nonpositive == 0, "nonpositive_steps": nonpositive, "median_step_sec": median_step, "large_gap_count": large_gaps}
        result["timing"] = timing

    if "block" not in mappings and "condition" in mappings:
        generated = "_cai_block_instance_id"
        frame[generated] = derive_blocks(conditions)
        mappings["block"] = generated
        adapter_grade = "LEGACY_ADAPTED"
        reasons.append({"level": "CAUTION", "code": "DERIVED_BLOCK_IDS", "message": "Unique block-instance identifiers were derived from contiguous condition changes."})
        derived_path = out_dir / "cai_readiness_adapted_frame_v0_2.csv"
        frame.to_csv(derived_path, index=False)
        selected_for_manifest = derived_path
    else:
        selected_for_manifest = selected

    coverage: Dict[str, Dict[str, float]] = {}
    if "condition" in mappings:
        branch_values = sorted(set(conditions) & set(CONDITION_MAP.values()))
        for branch in branch_values:
            mask = conditions == branch
            coverage[branch] = {role: numeric_coverage(frame, mappings[role], mask) for role in REQUIRED if role in mappings}
            minimum = min(coverage[branch].values(), default=0.0)
            coverage[branch]["minimum_required_fraction"] = minimum
            if minimum < 0.70:
                reasons.append({"level": "INELIGIBLE", "code": "LOW_BRANCH_COVERAGE", "message": f"{branch} minimum required-feature coverage is {minimum:.1%}, below 70%."})
            elif minimum < 0.90:
                reasons.append({"level": "CAUTION", "code": "MARGINAL_BRANCH_COVERAGE", "message": f"{branch} minimum required-feature coverage is {minimum:.1%}."})
    result["branch_coverage"] = coverage

    if not support["als"]["available"]:
        reasons.append({"level": "CAUTION", "code": "ALS_STATUS_UNAVAILABLE", "message": "No ALS/barcode timing evidence was found; CAI may run but timing provenance is incomplete."})
    elif support["als"].get("timing_status") != "PASS":
        reasons.append({"level": "CAUTION", "code": "ALS_TIMING_NOT_PASS", "message": f"ALS/barcode evidence was found, but timing status is {support['als'].get('timing_status')}; review the listed evidence before interpretation."})
    if not support["autonomic"]["available"]:
        reasons.append({"level": "CAUTION", "code": "AUTONOMIC_UNAVAILABLE", "message": "Continuous autonomic arrays are unavailable and will remain absent from exploratory contextual analyses."})
    if not support["dga"]["available"]:
        reasons.append({"level": "CAUTION", "code": "DGA_UNAVAILABLE", "message": "DGA/contextual gating is unavailable; it is not imputed into primary CAI."})
    if not support["anchors"]["available"]:
        reasons.append({"level": "CAUTION", "code": "ANCHORS_UNAVAILABLE", "message": "Locked anchor evidence was not found."})

    feature_mappings = {role: mappings[role] for role in REQUIRED + OPTIONAL if role in mappings}
    run_id = run_folder.name
    if "project_name" in frame.columns:
        project_names = frame["project_name"].dropna().astype(str).str.strip()
        if project_names.nunique() == 1 and project_names.iloc[0]:
            run_id = project_names.iloc[0]
    manifest = {
        "schema": "PRAYCG_CAI_SID_RunManifest_v0_2",
        "boundary": "Generated explicit adapter manifest for exploratory computation; adapter availability does not establish measurement equivalence or validity.",
        "dga_csv": support["dga"]["files"][0] if support["dga"]["available"] else None,
        "runs": [{
            "run_id": run_id,
            "source_csv": str(selected_for_manifest.resolve()),
            "data_grade": adapter_grade,
            "time": mappings.get("time"),
            "condition": mappings.get("condition"),
            "block": mappings.get("block"),
            "columns": feature_mappings,
            "adapter_cautions": [reason["message"] for reason in reasons if reason["code"].startswith("ADAPTER_") or reason["code"] == "DERIVED_BLOCK_IDS"],
        }],
        "provenance": {"generated_by": "praycg_cai_readiness_preflight_v0_2.py", "generated_utc": utc_now(), "original_source_csv": str(selected.resolve())},
    }
    manifest_path = out_dir / "generated_cai_run_manifest_v0_2.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    result["mappings"] = mappings
    result["legacy_adapter_grade"] = adapter_grade
    result["generated_run_manifest"] = str(manifest_path.resolve())
    result["status"] = status_from(reasons)
    write_outputs(result, out_dir)
    return result


def write_outputs(result: Dict[str, Any], out_dir: Path) -> None:
    (out_dir / "cai_readiness_preflight_v0_2.json").write_text(json.dumps(result, indent=2, allow_nan=False), encoding="utf-8")
    lines = [
        "# CAI/SID v0.2 Analysis-Readiness Preflight", "",
        f"**Status: {result.get('status', 'INELIGIBLE')}**", "",
        f"Generated: {result.get('generated_utc')}", "",
        "This status concerns computational readiness for an exploratory proxy only. It does not establish validity, consciousness, meaning reception, or Master Suite eligibility.", "",
        "## Findings", "",
    ]
    for reason in result.get("reasons", []):
        lines.append(f"- **{reason['level']} — {reason['code']}:** {reason['message']}")
    if not result.get("reasons"):
        lines.append("- All specified computational readiness checks passed.")
    lines += ["", "## Selected inputs", "", f"- Source: `{result.get('selected_source_csv')}`", f"- Protocol: `{result.get('protocol', 'UNRESOLVED')}`", f"- Legacy adapter grade: `{result.get('legacy_adapter_grade', 'NOT_ESTABLISHED')}`", f"- Generated manifest: `{result.get('generated_run_manifest')}`", ""]
    (out_dir / "cai_readiness_preflight_v0_2.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-folder", required=True)
    parser.add_argument("--analysis-folder")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    result = run_preflight(Path(args.run_folder), Path(args.analysis_folder) if args.analysis_folder else None, Path(args.out))
    print(json.dumps({"status": result["status"], "report": str((Path(args.out) / 'cai_readiness_preflight_v0_2.md').resolve()), "manifest": result.get("generated_run_manifest")}, indent=2))
    # CAUTION is a successful preflight with documented limitations.  Reserve a
    # non-zero process result for computational ineligibility or execution error.
    return 2 if result["status"] == "INELIGIBLE" else 0


if __name__ == "__main__":
    raise SystemExit(main())
