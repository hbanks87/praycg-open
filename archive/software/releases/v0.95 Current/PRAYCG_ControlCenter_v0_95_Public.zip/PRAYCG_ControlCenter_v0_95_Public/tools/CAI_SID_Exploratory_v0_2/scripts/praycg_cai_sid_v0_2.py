#!/usr/bin/env python3
"""Portable exploratory CAI/SID v0.2 implementation.

CAI means Controlled Access-Integration Index. The output is a unitless proxy,
not a probability or a direct measurement of consciousness.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


VERSION = "0.2.0"
CONDITION_MAP = {
    "BASELINE1": "BASELINE_1",
    "BASELINE_1": "BASELINE_1",
    "BASELINE2": "BASELINE_2_REFLECTION",
    "BASELINE_2": "BASELINE_2_REFLECTION",
    "BASELINE_2_REFLECTION": "BASELINE_2_REFLECTION",
    "CONTROL": "CONTROL_1",
    "CONTROL_1": "CONTROL_1",
    "TARGET": "TARGET_1",
    "TARGET_1": "TARGET_1",
    "OVERRIDE": "CONTEXTUAL_OVERRIDE_1",
    "CONTEXTUAL_OVERRIDE": "CONTEXTUAL_OVERRIDE_1",
    "CONTEXTUAL_OVERRIDE_1": "CONTEXTUAL_OVERRIDE_1",
    "WASHOUT1": "WASHOUT_1",
    "WASHOUT_1": "WASHOUT_1",
    "WASHOUT2": "WASHOUT_2",
    "WASHOUT_2": "WASHOUT_2",
    "WASHOUT3": "WASHOUT_3",
    "WASHOUT_3": "WASHOUT_3",
    "PHASESCRAMBLED": "PHASE_SCRAMBLED_1",
    "PHASE_SCRAMBLED": "PHASE_SCRAMBLED_1",
    "PHASE_SCRAMBLED_1": "PHASE_SCRAMBLED_1",
    "SHOTORDER": "SHOTORDER_SCRAMBLE_1",
    "SHOTORDER_SCRAMBLE": "SHOTORDER_SCRAMBLE_1",
    "SHOTORDER_SCRAMBLE_1": "SHOTORDER_SCRAMBLE_1",
}
BRANCH_MAP = {
    "CONTROL": "CONTROL_1",
    "PHASESCRAMBLED": "PHASE_SCRAMBLED_1",
    "PHASE_SCRAMBLED": "PHASE_SCRAMBLED_1",
    "SHOTORDER": "SHOTORDER_SCRAMBLE_1",
    "SHOTORDER_SCRAMBLE": "SHOTORDER_SCRAMBLE_1",
    "TARGET": "TARGET_1",
    "OVERRIDE": "CONTEXTUAL_OVERRIDE_1",
}
CONTRASTS = [
    ("Target-Control", "TARGET_1", "CONTROL_1"),
    ("Target-PhaseScrambled", "TARGET_1", "PHASE_SCRAMBLED_1"),
    ("Target-ShotOrder", "TARGET_1", "SHOTORDER_SCRAMBLE_1"),
    ("Target-Override", "TARGET_1", "CONTEXTUAL_OVERRIDE_1"),
    ("Washout2-Washout3", "WASHOUT_2", "WASHOUT_3"),
    ("Baseline2-Baseline1", "BASELINE_2_REFLECTION", "BASELINE_1"),
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def portable_display_path(path: Path, root: Path) -> str:
    """Prefer package-relative provenance but retain valid external absolute paths."""
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except (OSError, ValueError):
        return str(path.resolve())


def sigmoid(x: Iterable[float]) -> np.ndarray:
    values = np.asarray(x, dtype=float)
    return 1.0 / (1.0 + np.exp(-np.clip(values, -20.0, 20.0)))


def positive_excess(x: Iterable[float]) -> np.ndarray:
    return np.clip(2.0 * (np.asarray(x, dtype=float) - 0.5), 0.0, 1.0)


def corrected_loop_product(e: Iterable[float], y_future: Iterable[float]) -> np.ndarray:
    e_pos = np.maximum(np.asarray(e, dtype=float) - 0.5, 0.0)
    y_pos = np.maximum(np.asarray(y_future, dtype=float) - 0.5, 0.0)
    return np.clip(2.0 * np.sqrt(e_pos * y_pos), 0.0, 1.0)


def combine_loop(product: Iterable[float], correlation: Iterable[float], product_weight: float = 0.70) -> np.ndarray:
    product_arr = np.asarray(product, dtype=float)
    corr_arr = np.asarray(correlation, dtype=float)
    corr_positive = np.maximum(corr_arr, 0.0)
    combined = product_arr.copy()
    estimable = np.isfinite(corr_arr)
    combined[estimable] = product_weight * product_arr[estimable] + (1.0 - product_weight) * corr_positive[estimable]
    return np.clip(combined, 0.0, 1.0)


def canonical_condition(value: Any) -> str:
    text = str(value).strip().upper().replace(" ", "_").replace("-", "_")
    compact = text.replace("_", "")
    return CONDITION_MAP.get(text, CONDITION_MAP.get(compact, text))


def assign_block_instances(df: pd.DataFrame) -> pd.Series:
    """Create separate IDs for contiguous occurrences of the same condition."""
    change = df["condition"].ne(df["condition"].shift()).cumsum()
    segment_table = pd.DataFrame({"segment": change, "condition": df["condition"]}).drop_duplicates("segment")
    segment_table["occurrence"] = segment_table.groupby("condition").cumcount() + 1
    labels = {
        int(row.segment): f"{row.condition}__B{int(row.occurrence):02d}"
        for row in segment_table.itertuples(index=False)
    }
    return change.map(labels)


def robust_reference_z(
    values: pd.Series,
    reference_mask: pd.Series,
    minimum_reference_rows: int,
    allow_fallback: bool,
    clip: float,
) -> Tuple[pd.Series, Dict[str, Any]]:
    numeric = pd.to_numeric(values, errors="coerce").astype(float)
    reference = numeric[reference_mask & numeric.notna()]
    source = "BASELINE_1"
    if len(reference) < minimum_reference_rows:
        if not allow_fallback:
            raise ValueError(f"Reference contains {len(reference)} valid rows; {minimum_reference_rows} required")
        reference = numeric[numeric.notna()]
        source = "FULL_RUN_FALLBACK_INSUFFICIENT_BASELINE"
    median = float(np.nanmedian(reference)) if len(reference) else math.nan
    mad = float(np.nanmedian(np.abs(reference - median))) if len(reference) else math.nan
    scale = mad / 0.67448975 if np.isfinite(mad) and mad > 0 else math.nan
    if not np.isfinite(scale) or scale <= 0:
        sd = float(np.nanstd(reference)) if len(reference) else math.nan
        if np.isfinite(sd) and sd > 0:
            scale = sd
            source += "_SD_SCALE"
        elif allow_fallback:
            full = numeric[numeric.notna()]
            full_median = float(np.nanmedian(full)) if len(full) else math.nan
            full_mad = float(np.nanmedian(np.abs(full - full_median))) if len(full) else math.nan
            full_scale = full_mad / 0.67448975 if np.isfinite(full_mad) and full_mad > 0 else float(np.nanstd(full))
            if np.isfinite(full_scale) and full_scale > 0:
                median, scale = full_median, full_scale
                source = "FULL_RUN_FALLBACK_ZERO_BASELINE_SCALE"
    if not np.isfinite(median) or not np.isfinite(scale) or scale <= 0:
        return pd.Series(np.nan, index=numeric.index, dtype=float), {
            "reference": "UNUSABLE",
            "n_reference": int(len(reference)),
            "median": None,
            "scale": None,
        }
    z = ((numeric - median) / scale).clip(-clip, clip)
    return z, {
        "reference": source,
        "n_reference": int(len(reference)),
        "median": median,
        "scale": scale,
    }


def weighted_available(frame: pd.DataFrame, weights: Dict[str, float], prefix: str = "z_") -> pd.Series:
    available = [(name, float(weight)) for name, weight in weights.items() if prefix + name in frame and frame[prefix + name].notna().any()]
    if not available:
        return pd.Series(np.nan, index=frame.index, dtype=float)
    numerator = pd.Series(0.0, index=frame.index)
    denominator = pd.Series(0.0, index=frame.index)
    for name, weight in available:
        values = frame[prefix + name]
        valid = values.notna()
        numerator.loc[valid] += weight * values.loc[valid]
        denominator.loc[valid] += weight
    return numerator / denominator.replace(0.0, np.nan)


def future_mean_by_block(
    df: pd.DataFrame,
    value_column: str,
    start_seconds: float,
    end_seconds: float,
    minimum_samples: int,
) -> pd.Series:
    result = pd.Series(np.nan, index=df.index, dtype=float)
    for _, group in df.groupby("block_id", sort=False):
        times = group["time"].to_numpy(float)
        values = group[value_column].to_numpy(float)
        for local_i, row_index in enumerate(group.index):
            mask = (times >= times[local_i] + start_seconds) & (times <= times[local_i] + end_seconds) & np.isfinite(values)
            if int(mask.sum()) >= minimum_samples:
                result.loc[row_index] = float(np.mean(values[mask]))
    return result


def local_correlation_by_block(
    df: pd.DataFrame,
    x_column: str,
    y_column: str,
    window_seconds: float,
    minimum_samples: int,
) -> pd.Series:
    result = pd.Series(np.nan, index=df.index, dtype=float)
    half = window_seconds / 2.0
    for _, group in df.groupby("block_id", sort=False):
        times = group["time"].to_numpy(float)
        x = group[x_column].to_numpy(float)
        y = group[y_column].to_numpy(float)
        for local_i, row_index in enumerate(group.index):
            mask = (times >= times[local_i] - half) & (times <= times[local_i] + half) & np.isfinite(x) & np.isfinite(y)
            if int(mask.sum()) < minimum_samples:
                continue
            xx, yy = x[mask], y[mask]
            if np.std(xx) > 1e-12 and np.std(yy) > 1e-12:
                result.loc[row_index] = float(np.corrcoef(xx, yy)[0, 1])
    return result


def rolling_time_mean(df: pd.DataFrame, value_column: str, window_seconds: float) -> pd.Series:
    result = pd.Series(np.nan, index=df.index, dtype=float)
    half = window_seconds / 2.0
    for _, group in df.groupby("block_id", sort=False):
        times = group["time"].to_numpy(float)
        values = group[value_column].to_numpy(float)
        for local_i, row_index in enumerate(group.index):
            mask = (times >= times[local_i] - half) & (times <= times[local_i] + half) & np.isfinite(values)
            if int(mask.sum()) >= 3:
                result.loc[row_index] = float(np.mean(values[mask]))
    return result


def load_dga(path: Optional[Path]) -> Dict[Tuple[str, str], Dict[str, float]]:
    if path is None or not path.exists():
        return {}
    table = pd.read_csv(path)
    output: Dict[Tuple[str, str], Dict[str, float]] = {}
    for row in table.to_dict("records"):
        run = str(row.get("run", ""))
        condition = BRANCH_MAP.get(str(row.get("branch", "")).upper(), canonical_condition(row.get("branch", "")))
        values: Dict[str, float] = {}
        for source, target in [
            ("decoder_gate_availability", "gate"),
            ("confound_load", "confound"),
            ("extraction_load", "extraction"),
        ]:
            value = pd.to_numeric(pd.Series([row.get(source)]), errors="coerce").iloc[0]
            values[target] = float(value) if pd.notna(value) else math.nan
        output[(run, condition)] = values
    return output


def load_run(
    package_root: Path,
    run_spec: Dict[str, Any],
    config: Dict[str, Any],
) -> Tuple[pd.DataFrame, Dict[str, Any], List[str]]:
    source_path = (package_root / run_spec["source_csv"]).resolve()
    source = pd.read_csv(source_path)
    warnings: List[str] = list(run_spec.get("adapter_cautions", []))
    selected_columns = dict(run_spec["columns"])

    cetr_value = run_spec.get("cetr_csv")
    if cetr_value:
        cetr_path = (package_root / cetr_value).resolve()
        cetr = pd.read_csv(cetr_path)
        nip_source = selected_columns.get("nip")
        if nip_source and nip_source not in source and nip_source in cetr:
            condition_column = run_spec["condition"]
            time_column = run_spec["time"]
            source = pd.merge_asof(
                source.sort_values(time_column),
                cetr[[time_column, condition_column, nip_source]].sort_values(time_column),
                on=time_column,
                by=condition_column,
                direction="nearest",
                tolerance=0.51,
            )

    required = set(config["required_components"])
    for component in required:
        selected = selected_columns.get(component)
        if not selected or selected not in source.columns:
            raise ValueError(f"{run_spec['run_id']}: required component {component!r} has no declared usable source column")

    time_column = run_spec["time"]
    condition_column = run_spec["condition"]
    if time_column not in source or condition_column not in source:
        raise ValueError(f"{run_spec['run_id']}: missing declared time or condition column")

    df = pd.DataFrame()
    df["time"] = pd.to_numeric(source[time_column], errors="coerce")
    df["condition_raw"] = source[condition_column].astype(str)
    df["condition"] = df["condition_raw"].map(canonical_condition)
    for component, column in selected_columns.items():
        df[component] = pd.to_numeric(source[column], errors="coerce") if column and column in source else np.nan
        if column is None or column not in source:
            warnings.append(f"optional component {component} unavailable")

    before = len(df)
    df = df[np.isfinite(df["time"]) & df["condition"].isin(CONDITION_MAP.values())].copy()
    dropped = before - len(df)
    if dropped:
        warnings.append(f"dropped {dropped} rows without valid time or recognized protocol condition")
    df = df.sort_values("time", kind="mergesort").reset_index(drop=True)
    df["block_id"] = assign_block_instances(df)
    df["block_offset_sec"] = df["time"] - df.groupby("block_id")["time"].transform("min")
    df["run"] = run_spec["run_id"]

    duplicate_times = int(df["time"].duplicated().sum())
    nonmonotonic = int((df["time"].diff().dropna() < 0).sum())
    if duplicate_times:
        warnings.append(f"{duplicate_times} duplicate timestamps retained and flagged")
    if nonmonotonic:
        warnings.append(f"{nonmonotonic} nonmonotonic timestamps after stable sort")

    norm = config["normalization"]
    reference_mask = df["condition"].eq(norm["reference_condition"])
    references: Dict[str, Any] = {}
    for component in selected_columns:
        if df[component].notna().any():
            df[f"z_{component}"], references[component] = robust_reference_z(
                df[component],
                reference_mask,
                int(norm["minimum_reference_rows"]),
                bool(norm["allow_full_run_fallback_for_legacy"]),
                float(norm["robust_z_clip"]),
            )
        else:
            df[f"z_{component}"] = np.nan
            references[component] = {"reference": "UNAVAILABLE", "n_reference": 0, "median": None, "scale": None}

    metadata = {
        "run_id": run_spec["run_id"],
        "source_csv": run_spec["source_csv"],
        "source_sha256": sha256_file(source_path),
        "source_rows": int(len(source)),
        "analysis_rows": int(len(df)),
        "data_grade": run_spec.get("data_grade", "unspecified"),
        "selected_columns": selected_columns,
        "references": references,
        "condition_counts": {str(k): int(v) for k, v in df["condition"].value_counts().items()},
        "block_counts": {str(k): int(v) for k, v in df["block_id"].value_counts().items()},
        "duplicate_timestamps": duplicate_times,
        "warnings": warnings,
    }
    return df, metadata, warnings


def compute_run(
    df: pd.DataFrame,
    config: Dict[str, Any],
    dga: Dict[Tuple[str, str], Dict[str, float]],
    variant: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    variant = variant or {}
    frame = df.copy()
    fast_weights = dict(config["fast_weights"])
    visual_penalty = float(fast_weights.pop("visual_positive_penalty"))
    if variant.get("disable_nip"):
        fast_weights.pop("nip", None)
    fast_latent = weighted_available(frame, fast_weights)
    if "z_visual" in frame and frame["z_visual"].notna().any():
        # Visual is optional. Missing rows contribute no optional penalty; an
        # entirely unavailable visual column must not erase otherwise valid E.
        fast_latent = fast_latent - visual_penalty * np.maximum(frame["z_visual"].fillna(0.0), 0.0)
    frame["E_fast"] = sigmoid(fast_latent)

    frame["Y_slow"] = sigmoid(weighted_available(frame, config["slow_weights"]))
    loop_cfg = dict(config["loop"])
    start_seconds = float(variant.get("future_start_seconds", loop_cfg["future_start_seconds"]))
    end_seconds = float(variant.get("future_end_seconds", loop_cfg["future_end_seconds"]))
    frame["Y_future"] = future_mean_by_block(
        frame,
        "Y_slow",
        start_seconds,
        end_seconds,
        int(loop_cfg["minimum_future_samples"]),
    )
    frame["K_product_positive"] = corrected_loop_product(frame["E_fast"], frame["Y_future"])
    frame["K_local_corr"] = local_correlation_by_block(
        frame,
        "E_fast",
        "Y_future",
        float(loop_cfg["local_window_seconds"]),
        int(loop_cfg["minimum_correlation_samples"]),
    )
    frame["K_loop"] = combine_loop(
        frame["K_product_positive"],
        frame["K_local_corr"],
        float(loop_cfg["product_weight"]),
    )

    frame["A_artifact"] = sigmoid(weighted_available(frame, config["artifact_weights"]))
    frame["X_task"] = sigmoid(frame["z_task"])
    frame["E_evidence"] = positive_excess(frame["E_fast"])
    frame["Y_evidence"] = positive_excess(frame["Y_slow"])
    frame["A_excess"] = positive_excess(frame["A_artifact"])
    frame["X_excess"] = positive_excess(frame["X_task"])

    threshold = float(variant.get("artifact_hard_z", config["qc"]["artifact_hard_z"]))
    hard_terms = [frame["z_artifact"] > threshold, frame["z_hf"] > float(variant.get("hf_hard_z", config["qc"]["hf_hard_z"]))]
    if frame["z_p2p"].notna().any():
        hard_terms.append(frame["z_p2p"] > float(variant.get("p2p_hard_z", config["qc"]["p2p_hard_z"])))
    hard_fail = hard_terms[0].fillna(False)
    for term in hard_terms[1:]:
        hard_fail = hard_fail | term.fillna(False)
    frame["hard_qc_pass"] = ~hard_fail

    support_terms = [frame["E_evidence"], frame["Y_evidence"]]
    if not variant.get("disable_loop"):
        support_terms.append(frame["K_loop"])
    support = pd.concat(support_terms, axis=1).mean(axis=1, skipna=False)
    penalty_terms: List[pd.Series] = []
    if not variant.get("disable_soft_artifact"):
        penalty_terms.append(frame["A_excess"])
    if not variant.get("disable_task_penalty"):
        penalty_terms.append(frame["X_excess"])
    penalty = pd.concat(penalty_terms, axis=1).mean(axis=1, skipna=False) if penalty_terms else pd.Series(0.0, index=frame.index)
    frame["support"] = support
    frame["penalty"] = penalty
    frame["CAI_core"] = np.clip(support * (1.0 - penalty), 0.0, 1.0)
    required_valid = frame[["E_fast", "Y_slow", "K_loop", "A_artifact", "X_task"]].notna().all(axis=1)
    if variant.get("disable_loop"):
        required_valid = frame[["E_fast", "Y_slow", "A_artifact", "X_task"]].notna().all(axis=1)
    frame.loc[~required_valid | ~frame["hard_qc_pass"], "CAI_core"] = np.nan

    frame["D_gate"] = np.nan
    frame["confound_load"] = np.nan
    frame["extraction_load"] = np.nan
    for condition in frame["condition"].unique():
        values = dga.get((str(frame["run"].iloc[0]), str(condition)))
        if not values:
            continue
        mask = frame["condition"].eq(condition)
        frame.loc[mask, "D_gate"] = values["gate"]
        frame.loc[mask, "confound_load"] = values["confound"]
        frame.loc[mask, "extraction_load"] = values["extraction"]
    frame["context_reliability"] = frame["D_gate"] * (1.0 - frame["confound_load"]) * (1.0 - frame["extraction_load"])
    frame["CAI_context_gated"] = frame["CAI_core"] * frame["context_reliability"]
    frame["CAI_rolling"] = rolling_time_mean(frame, "CAI_core", float(config["summaries"]["rolling_seconds"]))
    frame["variant"] = variant.get("name", "primary_corrected")
    frame["future_window"] = f"{start_seconds:g}-{end_seconds:g}s"
    return frame


def summarize_run(frame: pd.DataFrame, config: Dict[str, Any]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    rows: List[Dict[str, Any]] = []
    threshold = float(config["summaries"]["occupancy_threshold"])
    for (run, condition), group in frame.groupby(["run", "condition"], sort=False):
        values = group["CAI_core"]
        valid = values.notna()
        sorted_times = np.sort(group["time"].dropna().to_numpy(float))
        dt = float(np.nanmedian(np.diff(sorted_times))) if len(sorted_times) > 1 else 1.0
        if not np.isfinite(dt) or dt <= 0:
            dt = 1.0
        rows.append({
            "run": run,
            "condition": condition,
            "variant": str(group["variant"].iloc[0]),
            "n_total": int(len(group)),
            "n_valid": int(valid.sum()),
            "valid_fraction": float(valid.mean()),
            "valid_duration_sec": float(valid.sum() * dt),
            "CAI_mean": float(values.mean()) if valid.any() else math.nan,
            "CAI_median": float(values.median()) if valid.any() else math.nan,
            "CAI_load_seconds": float(values.sum() * dt) if valid.any() else math.nan,
            "CAI_occupancy": float((values[valid] >= threshold).mean()) if valid.any() else math.nan,
            "CAI_rolling_max": float(group["CAI_rolling"].max()) if group["CAI_rolling"].notna().any() else math.nan,
            "E_mean": float(group["E_fast"].mean()),
            "Y_mean": float(group["Y_slow"].mean()),
            "K_mean": float(group["K_loop"].mean()),
            "artifact_mean": float(group["A_artifact"].mean()),
            "task_mean": float(group["X_task"].mean()),
            "hard_qc_pass_fraction": float(group["hard_qc_pass"].mean()),
            "context_gated_mean": float(group["CAI_context_gated"].mean()) if group["CAI_context_gated"].notna().any() else math.nan,
        })
    summary = pd.DataFrame(rows)
    contrast_rows: List[Dict[str, Any]] = []
    for run, run_summary in summary.groupby("run", sort=False):
        means = run_summary.set_index("condition")["CAI_mean"].to_dict()
        for name, left, right in CONTRASTS:
            left_value, right_value = means.get(left, math.nan), means.get(right, math.nan)
            contrast_rows.append({
                "run": run,
                "variant": str(run_summary["variant"].iloc[0]),
                "contrast": name,
                "left_condition": left,
                "right_condition": right,
                "left_mean": left_value,
                "right_mean": right_value,
                "delta": left_value - right_value if np.isfinite(left_value) and np.isfinite(right_value) else math.nan,
            })
    return summary, pd.DataFrame(contrast_rows)


def moving_block_sample_mean(values: np.ndarray, block_length: int, rng: np.random.Generator) -> float:
    finite = values[np.isfinite(values)]
    n = len(finite)
    if n == 0:
        return math.nan
    block_length = max(1, min(block_length, n))
    starts = np.arange(0, n - block_length + 1)
    pieces: List[np.ndarray] = []
    while sum(len(piece) for piece in pieces) < n:
        start = int(rng.choice(starts))
        pieces.append(finite[start : start + block_length])
    return float(np.concatenate(pieces)[:n].mean())


def add_bootstrap_intervals(
    contrasts: pd.DataFrame,
    time_series: pd.DataFrame,
    config: Dict[str, Any],
) -> pd.DataFrame:
    output = contrasts.copy()
    output["bootstrap_ci_low"] = np.nan
    output["bootstrap_ci_high"] = np.nan
    output["bootstrap_replicates"] = int(config["bootstrap"]["replicates"])
    rng = np.random.default_rng(int(config["bootstrap"]["seed"]))
    for index, row in output.iterrows():
        run_frame = time_series[time_series["run"].eq(row["run"])]
        left = run_frame[run_frame["condition"].eq(row["left_condition"])]["CAI_core"].to_numpy(float)
        right = run_frame[run_frame["condition"].eq(row["right_condition"])]["CAI_core"].to_numpy(float)
        if np.isfinite(left).sum() < 5 or np.isfinite(right).sum() < 5:
            continue
        times = np.sort(run_frame["time"].dropna().unique())
        dt = float(np.nanmedian(np.diff(times))) if len(times) > 1 else 1.0
        block_length = max(1, int(round(float(config["bootstrap"]["block_seconds"]) / max(dt, 1e-9))))
        draws = []
        for _ in range(int(config["bootstrap"]["replicates"])):
            draws.append(moving_block_sample_mean(left, block_length, rng) - moving_block_sample_mean(right, block_length, rng))
        output.loc[index, "bootstrap_ci_low"] = float(np.nanquantile(draws, 0.025))
        output.loc[index, "bootstrap_ci_high"] = float(np.nanquantile(draws, 0.975))
    return output


def analyze(
    config_path: Path,
    run_manifest_path: Path,
    out_dir: Path,
    variant: Optional[Dict[str, Any]] = None,
) -> Dict[str, Path]:
    config_path = config_path.resolve()
    run_manifest_path = run_manifest_path.resolve()
    package_root = config_path.parent.parent
    config = load_json(config_path)
    run_manifest = load_json(run_manifest_path)
    if config.get("algorithm_version") != VERSION:
        raise ValueError(f"Configuration algorithm version {config.get('algorithm_version')} does not match code {VERSION}")
    out_dir.mkdir(parents=True, exist_ok=True)
    dga_path = (package_root / run_manifest["dga_csv"]).resolve() if run_manifest.get("dga_csv") else None
    dga = load_dga(dga_path)

    all_frames: List[pd.DataFrame] = []
    adapter_metadata: List[Dict[str, Any]] = []
    warnings: List[Dict[str, str]] = []
    for run_spec in run_manifest["runs"]:
        run_frame, metadata, run_warnings = load_run(package_root, run_spec, config)
        result = compute_run(run_frame, config, dga, variant)
        all_frames.append(result)
        adapter_metadata.append(metadata)
        warnings.extend({"run": run_spec["run_id"], "warning": warning} for warning in run_warnings)

    time_series = pd.concat(all_frames, ignore_index=True)
    summary, contrasts = summarize_run(time_series, config)
    contrasts = add_bootstrap_intervals(contrasts, time_series, config)

    time_path = out_dir / "cai_sid_v0_2_time_series.csv"
    summary_path = out_dir / "cai_sid_v0_2_branch_summary.csv"
    contrasts_path = out_dir / "cai_sid_v0_2_contrasts.csv"
    adapter_path = out_dir / "cai_sid_v0_2_adapter_manifest.json"
    warnings_path = out_dir / "cai_sid_v0_2_warnings.json"
    manifest_path = out_dir / "cai_sid_v0_2_analysis_manifest.json"
    time_series.to_csv(time_path, index=False)
    summary.to_csv(summary_path, index=False)
    contrasts.to_csv(contrasts_path, index=False)
    adapter_path.write_text(json.dumps(adapter_metadata, indent=2), encoding="utf-8")
    warnings_path.write_text(json.dumps(warnings, indent=2), encoding="utf-8")
    manifest = {
        "schema": "PRAYCG_CAI_SID_AnalysisManifest_v0_2",
        "created_utc": utc_now(),
        "algorithm_version": VERSION,
        "code_sha256": sha256_file(Path(__file__).resolve()),
        "evidence_grade": "EXPLORATORY_RETROSPECTIVE_DERIVED_FEATURES",
        "claim_boundary": config["claim_boundary"],
        "variant": variant or {"name": "primary_corrected"},
        "config_path": portable_display_path(config_path, package_root),
        "config_sha256": sha256_file(config_path),
        "run_manifest_path": portable_display_path(run_manifest_path, package_root),
        "run_manifest_sha256": sha256_file(run_manifest_path),
        "dga_path": portable_display_path(dga_path, package_root) if dga_path else None,
        "dga_sha256": sha256_file(dga_path) if dga_path and dga_path.exists() else None,
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "outputs": {},
    }
    for path in [time_path, summary_path, contrasts_path, adapter_path, warnings_path]:
        manifest["outputs"][path.name] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return {
        "time_series": time_path,
        "summary": summary_path,
        "contrasts": contrasts_path,
        "adapter_manifest": adapter_path,
        "warnings": warnings_path,
        "manifest": manifest_path,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run exploratory CAI/SID v0.2")
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--run-manifest", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--variant-name", default="primary_corrected")
    parser.add_argument("--disable-nip", action="store_true")
    parser.add_argument("--disable-loop", action="store_true")
    parser.add_argument("--disable-task-penalty", action="store_true")
    parser.add_argument("--disable-soft-artifact", action="store_true")
    parser.add_argument("--future-start-seconds", type=float)
    parser.add_argument("--future-end-seconds", type=float)
    parser.add_argument("--artifact-hard-z", type=float)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    variant: Dict[str, Any] = {
        "name": args.variant_name,
        "disable_nip": args.disable_nip,
        "disable_loop": args.disable_loop,
        "disable_task_penalty": args.disable_task_penalty,
        "disable_soft_artifact": args.disable_soft_artifact,
    }
    for name in ["future_start_seconds", "future_end_seconds", "artifact_hard_z"]:
        value = getattr(args, name)
        if value is not None:
            variant[name] = value
    outputs = analyze(args.config, args.run_manifest, args.out, variant)
    print(json.dumps({key: str(value) for key, value in outputs.items()}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
