# Micro Handoff v0.1 synthetic acceptance plan

The configuration must be fixed before historical condition labels are summarized. The synthetic suite must pass all mandatory cases:

1. **Known forward lag:** repeated posterior-temporal gamma bursts followed by theta bursts at 500 ms. The diagnostic full-run lag must recover within ±100 ms, and observed bank handoff must exceed both null medians.
2. **Low-low:** quiet F and S may show coordination, but positive handoff and activation-weighted density must remain low.
3. **Stationary high-high:** activation-weighted coordination may be high, while positive handoff must remain low because no transition occurs.
4. **Reverse direction:** theta leading gamma must not be scored as a stronger forward handoff than the matched forward case.
5. **Independent colored activity:** the estimator must not systematically report strong directional handoff.
6. **Artifact injection:** injected jaw/global transients must be marked invalid and must not increase valid handoff.
7. **Gap handling:** windows spanning a timestamp gap must be invalid; the code must not interpolate across the gap.
8. **Reproducibility:** identical inputs, configuration, and seeds must produce identical summaries and hashes.

Passing these tests establishes implementation behavior only. It does not validate the construct as a measure of consciousness.
