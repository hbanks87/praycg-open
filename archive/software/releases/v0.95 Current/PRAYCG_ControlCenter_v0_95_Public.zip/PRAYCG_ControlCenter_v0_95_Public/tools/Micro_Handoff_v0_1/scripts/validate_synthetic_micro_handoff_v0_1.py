#!/usr/bin/env python3
"""Evaluate the frozen Micro Handoff v0.1 synthetic acceptance criteria."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def branch(root: Path, case: str, condition: str = "TARGET_1") -> pd.Series:
    frame = pd.read_csv(root / case / "output" / "micro_handoff_branch_summary.csv")
    return frame[frame["condition"] == condition].iloc[0]


def best_lag(root: Path, case: str) -> float:
    frame = pd.read_csv(root / case / "output" / "micro_handoff_lag_summary.csv")
    frame = frame[frame["condition"] == "TARGET_1"]
    return float(frame.sort_values("positive_handoff_mean", ascending=False).iloc[0]["lag_seconds"])


def null_rows(root: Path, case: str) -> pd.DataFrame:
    return pd.read_csv(root / case / "output" / "micro_handoff_time_structure_nulls.csv")


def add(checks, name: str, passed: bool, observed, requirement: str) -> None:
    checks.append({"check": name, "passed": bool(passed), "observed": observed, "requirement": requirement})


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    checks = []

    known = branch(root, "known_forward_lag")
    known_lag = best_lag(root, "known_forward_lag")
    known_null = null_rows(root, "known_forward_lag")
    known_h_null = known_null[known_null["metric"] == "positive_handoff"]
    add(checks, "known_lag_recovery", abs(known_lag - 0.5) <= 0.1000001, known_lag, "Best diagnostic lag within 0.10 s of 0.50 s")
    for model in ("CIRCULAR_SHIFT", "PHASE_RANDOMIZED"):
        row = known_h_null[known_h_null["null_model"] == model].iloc[0]
        add(checks, f"known_handoff_exceeds_{model.lower()}", float(row["observed"]) > float(row["null_median"]), {"observed": float(row["observed"]), "null_median": float(row["null_median"]), "p": float(row["one_sided_p"])}, "Observed bank handoff exceeds null median; p-value retained descriptively")

    low = branch(root, "low_low")
    add(checks, "low_low_coordination", float(low["coordination_mean"]) > 0.90, float(low["coordination_mean"]), "Low-low may remain highly coordinated")
    add(checks, "low_low_not_handoff", float(low["positive_handoff_mean"]) < 0.01, float(low["positive_handoff_mean"]), "Positive handoff below 0.01")
    add(checks, "low_low_density_low", float(low["activation_weighted_density_mean"]) < 0.10, float(low["activation_weighted_density_mean"]), "Activation-weighted density below 0.10")

    stationary = branch(root, "stationary_high_high")
    add(checks, "stationary_high_high_density", float(stationary["activation_weighted_density_mean"]) > 0.75, float(stationary["activation_weighted_density_mean"]), "Stationary high-high density above 0.75")
    add(checks, "stationary_high_high_not_transition", float(stationary["positive_handoff_mean"]) < 0.01, float(stationary["positive_handoff_mean"]), "Stationary high-high handoff below 0.01")

    reverse = branch(root, "reverse_direction")
    add(checks, "reverse_weaker_than_forward", float(reverse["positive_handoff_mean"]) < float(known["positive_handoff_mean"]), {"forward": float(known["positive_handoff_mean"]), "reverse": float(reverse["positive_handoff_mean"])}, "Reverse-direction handoff lower than forward")

    independent_null = null_rows(root, "independent")
    independent_h = independent_null[independent_null["metric"] == "positive_handoff"]
    add(checks, "independent_not_above_nulls", bool((independent_h["one_sided_p"] > 0.05).all()), independent_h[["null_model", "one_sided_p"]].to_dict("records"), "Both one-sided null p-values exceed 0.05")

    artifact = branch(root, "artifact")
    artifact_qc = json.loads((root / "artifact" / "output" / "micro_handoff_qc.json").read_text(encoding="utf-8"))
    add(checks, "artifact_rows_gated", int(artifact_qc["hard_artifact_rows"]) > 0, int(artifact_qc["hard_artifact_rows"]), "Injected artifact produces hard-invalid rows")
    add(checks, "artifact_does_not_materially_inflate_handoff", float(artifact["positive_handoff_mean"]) <= float(known["positive_handoff_mean"]) + 0.01, {"clean": float(known["positive_handoff_mean"]), "artifact": float(artifact["positive_handoff_mean"])}, "Artifact-case valid handoff no more than 0.01 above paired clean case")

    gap_qc = json.loads((root / "gap" / "output" / "micro_handoff_qc.json").read_text(encoding="utf-8"))
    add(checks, "timestamp_gap_invalidated", int(gap_qc["timestamp_gap_rows"]) > 0, int(gap_qc["timestamp_gap_rows"]), "Gap-spanning feature rows are flagged")

    repeat = root / "known_forward_lag_repeat" / "output"
    reproducible_files = ["micro_handoff_features_25ms.csv", "micro_handoff_branch_summary.csv", "micro_handoff_lag_summary.csv", "micro_handoff_time_structure_nulls.csv"]
    if repeat.exists():
        matches = {name: sha256(root / "known_forward_lag" / "output" / name) == sha256(repeat / name) for name in reproducible_files}
        add(checks, "deterministic_reproduction", all(matches.values()), matches, "Selected numerical outputs are byte-identical on repeat run")
    else:
        add(checks, "deterministic_reproduction", False, "repeat output missing", "Repeat run must be present")

    status = "PASS" if all(item["passed"] for item in checks) else "FAIL"
    result = {
        "schema": "PRAYCG_MicroHandoff_SyntheticValidation_v0_1",
        "status": status,
        "checks_passed": sum(item["passed"] for item in checks),
        "checks_total": len(checks),
        "checks": checks,
        "boundary": "Passing validates declared software behavior on synthetic fixtures only; it does not validate a consciousness construct.",
    }
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "synthetic_validation_summary.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    lines = ["# Micro Handoff v0.1 synthetic validation", "", f"**Overall status: {status}**", "", result["boundary"], "", "| Check | Result | Requirement |", "|---|---|---|"]
    for item in checks:
        lines.append(f"| {item['check']} | {'PASS' if item['passed'] else 'FAIL'} | {item['requirement']} |")
    lines.extend(["", "The known 500 ms raw-signal fixture is allowed a ±100 ms diagnostic tolerance because gamma and theta are estimated with different causal trailing windows. Null p-values are reported but were not tuned as acceptance thresholds.", ""])
    (args.out / "SYNTHETIC_VALIDATION_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"status": status, "passed": result["checks_passed"], "total": result["checks_total"]}, indent=2))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
