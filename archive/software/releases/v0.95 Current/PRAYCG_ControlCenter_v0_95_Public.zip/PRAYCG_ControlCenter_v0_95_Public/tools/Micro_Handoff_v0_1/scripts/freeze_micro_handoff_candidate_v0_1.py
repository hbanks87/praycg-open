#!/usr/bin/env python3
"""Create the immutable hash record for a passing Micro Handoff v0.1 candidate."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--validation-summary", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    validation = json.loads(args.validation_summary.read_text(encoding="utf-8"))
    if validation.get("status") != "PASS":
        raise SystemExit("Synthetic validation must PASS before freezing the candidate")
    relative_files = [
        "config/micro_handoff_config_v0_1.json",
        "docs/MICRO_HANDOFF_MATHEMATICAL_SPECIFICATION_v0_1.md",
        "docs/SYNTHETIC_ACCEPTANCE_PLAN_v0_1.md",
        "scripts/micro_handoff_core_v0_1.py",
        "scripts/praycg_micro_handoff_v0_1.py",
        "scripts/generate_synthetic_micro_handoff_v0_1.py",
        "scripts/validate_synthetic_micro_handoff_v0_1.py",
        "tests/test_micro_handoff_v0_1.py",
    ]
    record = {
        "schema": "PRAYCG_MicroHandoff_FrozenCandidate_v0_1",
        "module_name": "Micro Handoff",
        "version": "0.1.0",
        "status": "EXPLORATORY_DEVELOPMENT_CANDIDATE_FROZEN_AFTER_SYNTHETIC_PASS",
        "frozen_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "synthetic_validation": {"status": "PASS", "sha256": sha256(args.validation_summary)},
        "files": {name: sha256(root / name) for name in relative_files},
        "boundary": "Frozen for condition-blind retrospective evaluation. Not validated as a consciousness measure.",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(record, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"status": record["status"], "out": str(args.out.resolve())}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
