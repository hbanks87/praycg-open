#!/usr/bin/env python3
"""Condition-blind batch evaluation of unique historical PRAYCG XDF recordings."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import traceback
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd

from micro_handoff_core_v0_1 import STIMULUS_CONDITIONS, analyze_single, sha256_file, utc_now


HERE = Path(__file__).resolve().parent
DEFAULT_CONFIG = HERE.parent / "config" / "micro_handoff_config_v0_1.json"


def safe_label(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(value)).strip("_") or "run"


def bootstrap_run_means(values: np.ndarray, rng: np.random.Generator, replicates: int = 5000) -> tuple[float, float]:
    values = values[np.isfinite(values)]
    if len(values) < 2:
        return math.nan, math.nan
    draws = np.asarray([np.mean(rng.choice(values, len(values), replace=True)) for _ in range(replicates)])
    return float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def cross_run_outputs(out_root: Path, inventory: pd.DataFrame) -> Dict[str, pd.DataFrame]:
    summaries, contrasts, diagnostics, null_rows = [], [], [], []
    for row in inventory.itertuples(index=False):
        if row.analysis_status not in {"PASS", "CAUTION"}:
            continue
        folder = Path(row.output_folder)
        summary_path = folder / "micro_handoff_branch_summary.csv"
        contrast_path = folder / "micro_handoff_contrasts.csv"
        lag_path = folder / "micro_handoff_lag_summary.csv"
        null_path = folder / "micro_handoff_time_structure_nulls.csv"
        if summary_path.exists():
            frame = pd.read_csv(summary_path)
            frame.insert(0, "run_label", row.run_label)
            frame.insert(0, "xdf_id", row.xdf_id)
            summaries.append(frame)
        if contrast_path.exists():
            frame = pd.read_csv(contrast_path)
            frame.insert(0, "run_label", row.run_label)
            frame.insert(0, "xdf_id", row.xdf_id)
            contrasts.append(frame)
        if lag_path.exists():
            lag = pd.read_csv(lag_path)
            stimulus = lag[lag["condition"].isin(STIMULUS_CONDITIONS)]
            if not stimulus.empty:
                by_lag = stimulus.groupby("lag_seconds", as_index=False)["positive_handoff_mean"].mean()
                best = by_lag.sort_values("positive_handoff_mean", ascending=False).iloc[0]
                diagnostics.append({"xdf_id": row.xdf_id, "run_label": row.run_label, "diagnostic_best_lag_seconds": float(best["lag_seconds"]), "diagnostic_best_lag_handoff": float(best["positive_handoff_mean"])})
        if null_path.exists():
            frame = pd.read_csv(null_path)
            frame.insert(0, "run_label", row.run_label)
            frame.insert(0, "xdf_id", row.xdf_id)
            null_rows.append(frame)
    all_summary = pd.concat(summaries, ignore_index=True) if summaries else pd.DataFrame()
    all_contrasts = pd.concat(contrasts, ignore_index=True) if contrasts else pd.DataFrame()
    all_nulls = pd.concat(null_rows, ignore_index=True) if null_rows else pd.DataFrame()
    diagnostics_df = pd.DataFrame(diagnostics)
    run_contrast_rows = []
    rng = np.random.default_rng(20260913)
    if not all_contrasts.empty:
        for (contrast, metric), group in all_contrasts.groupby(["contrast", "metric"]):
            values = pd.to_numeric(group["estimate"], errors="coerce").dropna().to_numpy(float)
            low, high = bootstrap_run_means(values, rng)
            run_contrast_rows.append(
                {
                    "contrast": contrast,
                    "metric": metric,
                    "run_count": int(len(values)),
                    "mean_run_estimate": float(np.mean(values)) if len(values) else math.nan,
                    "median_run_estimate": float(np.median(values)) if len(values) else math.nan,
                    "positive_run_count": int(np.sum(values > 0)),
                    "positive_run_fraction": float(np.mean(values > 0)) if len(values) else math.nan,
                    "run_cluster_bootstrap_ci_low": low,
                    "run_cluster_bootstrap_ci_high": high,
                    "inference_boundary": "Descriptive repeated-run interval; not a participant-population confidence interval.",
                }
            )
    cross_contrasts = pd.DataFrame(run_contrast_rows)
    condition_rows = []
    if not all_summary.empty:
        for condition, group in all_summary.groupby("condition"):
            for metric in ("positive_handoff_mean", "activation_weighted_density_mean", "coordination_mean"):
                values = pd.to_numeric(group[metric], errors="coerce").dropna().to_numpy(float)
                condition_rows.append({"condition": condition, "metric": metric, "run_count": len(values), "mean_across_runs": float(np.mean(values)) if len(values) else math.nan, "median_across_runs": float(np.median(values)) if len(values) else math.nan})
    cross_conditions = pd.DataFrame(condition_rows)
    outputs = {
        "all_branch_summaries": all_summary,
        "all_run_contrasts": all_contrasts,
        "all_time_structure_nulls": all_nulls,
        "historical_run_diagnostics": diagnostics_df,
        "historical_cross_run_contrasts": cross_contrasts,
        "historical_cross_run_condition_summary": cross_conditions,
    }
    for name, frame in outputs.items():
        frame.to_csv(out_root / f"{name}.csv", index=False)
    return outputs


def write_report(out_root: Path, inventory: pd.DataFrame, outputs: Dict[str, pd.DataFrame]) -> None:
    eligible = inventory[inventory["analysis_status"].isin(["PASS", "CAUTION"])]
    lines = [
        "# Micro Handoff v0.1 — historical PRAYCG evaluation",
        "",
        "## Bottom line",
        "",
        f"The frozen candidate inventoried **{len(inventory)} unique XDF recordings** and produced eligible exploratory estimates for **{len(eligible)}**. Files failing timing, sample-rate, EEG, channel-map, Baseline 1, branch-count, or post-artifact coverage gates remain in the inventory as ineligible.",
        "",
        "These data are retrospective and predominantly one participant across different stimuli and software generations. The report therefore describes within-person repeated-run behavior; it does not estimate a population effect and does not validate a consciousness-density construct.",
        "",
        "## Run dispositions",
        "",
        "| XDF | Run | Status | Reason summary |",
        "|---|---|---|---|",
    ]
    for row in inventory.itertuples(index=False):
        reason = str(row.reason_summary).replace("|", "/")
        lines.append(f"| {row.xdf_id} | {row.run_label} | {row.analysis_status} | {reason} |")
    lines.append("")
    diagnostics = outputs["historical_run_diagnostics"]
    if not diagnostics.empty:
        lines.extend(["## Eligible-run lag diagnostics", "", "The best lag is a full-run diagnostic only. It was not selected separately by condition and is not a confirmatory endpoint.", "", "| XDF | Run | Best lag (s) | Mean handoff at lag |", "|---|---|---:|---:|"])
        for row in diagnostics.itertuples(index=False):
            lines.append(f"| {row.xdf_id} | {row.run_label} | {row.diagnostic_best_lag_seconds:.1f} | {row.diagnostic_best_lag_handoff:.4f} |")
        lines.append("")
    cross = outputs["historical_cross_run_contrasts"]
    if not cross.empty:
        lines.extend(["## Cross-run descriptive contrasts", "", "Intervals resample runs, not participants. Positive estimates mean the first condition exceeded the second.", "", "| Contrast | Metric | Runs | Mean | Median | Positive fraction | Run-bootstrap interval |", "|---|---|---:|---:|---:|---:|---:|"])
        for row in cross.itertuples(index=False):
            lines.append(f"| {row.contrast} | {row.metric} | {row.run_count} | {row.mean_run_estimate:.4f} | {row.median_run_estimate:.4f} | {row.positive_run_fraction:.2f} | [{row.run_cluster_bootstrap_ci_low:.4f}, {row.run_cluster_bootstrap_ci_high:.4f}] |")
        lines.append("")
    nulls = outputs["all_time_structure_nulls"]
    if not nulls.empty and "one_sided_p" in nulls:
        handoff = nulls[nulls["metric"] == "positive_handoff"].copy()
        lines.extend(["## Time-structure null audit", ""])
        for model, group in handoff.groupby("null_model"):
            finite = pd.to_numeric(group["one_sided_p"], errors="coerce").dropna()
            lines.append(f"- {model}: {int((finite < 0.05).sum())} of {len(finite)} eligible runs had one-sided p < .05. These are uncorrected exploratory counts, not confirmations.")
        lines.append("")
    lines.extend(
        [
            "## Required interpretation limits",
            "",
            "- A 25 ms row is a display/update cadence, not an independent observation or 25 ms spectral resolution.",
            "- All eligible 125 Hz files carry a resolution caution; 250 Hz or higher is preferred for future collection.",
            "- Historical branch order, stimulus identity, acquisition revisions, and incomplete ALS timing can confound condition differences.",
            "- Low-low agreement is coordination, not positive handoff. Stationary high-high can raise activation-weighted density without showing a transition.",
            "- Null, mixed, or reversed findings are retained as such; no post-hoc archetype is assigned.",
            "- Promotion requires prospective multi-participant reliability, independent criterion validity, calibration, and preregistered exclusions/nulls.",
            "",
        ]
    )
    (out_root / "MICRO_HANDOFF_HISTORICAL_DETAILED_REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--core-audit", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--out-root", type=Path, required=True)
    parser.add_argument("--pyxdf-path", type=Path, default=None)
    args = parser.parse_args()
    out_root = args.out_root.resolve()
    out_root.mkdir(parents=True, exist_ok=True)
    audit = pd.read_csv(args.core_audit)
    inventory_rows: List[Dict[str, Any]] = []
    for row in audit.itertuples(index=False):
        xdf_id = str(row.xdf_id)
        run_label = str(row.run_label)
        source = Path(str(row.raw_path))
        core_folder = Path(str(row.core_output_folder))
        segments = core_folder / "tables" / "segments_used.csv"
        folder = out_root / f"{xdf_id}_{safe_label(run_label)}"
        try:
            if not source.exists():
                raise FileNotFoundError(f"Raw XDF missing: {source}")
            if not segments.exists():
                raise FileNotFoundError(f"Segment adapter missing: {segments}")
            result = analyze_single(source, segments, args.config.resolve(), folder, run_label, args.pyxdf_path.resolve() if args.pyxdf_path else None, "xdf", False)
            reasons = result["readiness"].get("reasons", [])
            reason_summary = "; ".join(f"{item['code']}: {item['message']}" for item in reasons) or "Frozen readiness checks passed"
            status = result["status"]
        except Exception as exc:
            status = "ERROR"
            reason_summary = f"{type(exc).__name__}: {exc}"
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "batch_error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        inventory_rows.append({"xdf_id": xdf_id, "run_label": run_label, "analysis_status": status, "reason_summary": reason_summary, "source_file": source.name, "output_folder": str(folder)})
        print(json.dumps({"xdf_id": xdf_id, "run_label": run_label, "status": status}))
    inventory = pd.DataFrame(inventory_rows)
    inventory.to_csv(out_root / "historical_run_inventory.csv", index=False)
    outputs = cross_run_outputs(out_root, inventory)
    write_report(out_root, inventory, outputs)
    manifest = {
        "schema": "PRAYCG_MicroHandoff_HistoricalBatchManifest_v0_1",
        "generated_utc": utc_now(),
        "config_sha256": sha256_file(args.config.resolve()),
        "core_audit_sha256": sha256_file(args.core_audit.resolve()),
        "unique_recordings": len(inventory),
        "eligible_recordings": int(inventory["analysis_status"].isin(["PASS", "CAUTION"]).sum()),
        "status_counts": inventory["analysis_status"].value_counts().to_dict(),
        "boundary": "Retrospective, primarily single-participant descriptive analysis; not consciousness-measure validation or population inference.",
        "top_level_outputs": {},
    }
    for path in sorted(out_root.glob("*")):
        if path.is_file() and path.name != "historical_batch_manifest.json":
            manifest["top_level_outputs"][path.name] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    (out_root / "historical_batch_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"status_counts": manifest["status_counts"], "out_root": str(out_root)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
