#!/usr/bin/env python3
"""Command-line entry point for PRAYCG Micro Handoff v0.1."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from micro_handoff_core_v0_1 import analyze_single


HERE = Path(__file__).resolve().parent
DEFAULT_CONFIG = HERE.parent / "config" / "micro_handoff_config_v0_1.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--xdf", type=Path, help="Raw XDF recording")
    source.add_argument("--npz", type=Path, help="Synthetic raw EEG NPZ fixture")
    parser.add_argument("--segments-csv", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--run-label", default="PRAYCG_Run")
    parser.add_argument("--pyxdf-path", type=Path, default=None, help="Optional folder containing the pyxdf package")
    parser.add_argument("--skip-nulls", action="store_true", help="Diagnostic-only speed option; not for frozen historical analysis")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = args.xdf or args.npz
    result = analyze_single(
        source_path=source.resolve(),
        segments_path=args.segments_csv.resolve(),
        config_path=args.config.resolve(),
        out_dir=args.out.resolve(),
        run_label=args.run_label,
        pyxdf_path=args.pyxdf_path.resolve() if args.pyxdf_path else None,
        source_kind="npz" if args.npz else "xdf",
        skip_nulls=args.skip_nulls,
    )
    print(json.dumps({"status": result["status"], "out_dir": str(result["out_dir"])}, indent=2))
    return 0 if result["status"] in {"PASS", "CAUTION"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
