from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
CORE_PATH = ROOT / "scripts" / "micro_handoff_core_v0_1.py"
GEN_PATH = ROOT / "scripts" / "generate_synthetic_micro_handoff_v0_1.py"
spec = importlib.util.spec_from_file_location("micro_handoff_core", CORE_PATH)
core = importlib.util.module_from_spec(spec)
assert spec.loader
sys.modules[spec.name] = core
spec.loader.exec_module(core)
gen_spec = importlib.util.spec_from_file_location("micro_handoff_synthetic", GEN_PATH)
generator = importlib.util.module_from_spec(gen_spec)
assert gen_spec.loader
sys.modules[gen_spec.name] = generator
gen_spec.loader.exec_module(generator)
CONFIG = json.loads((ROOT / "config" / "micro_handoff_config_v0_1.json").read_text(encoding="utf-8"))


def score_feature_case(F, S, Q=None, valid=None, dt=0.025):
    F = np.asarray(F, dtype=float)
    S = np.asarray(S, dtype=float)
    Q = np.ones_like(F) if Q is None else np.asarray(Q, dtype=float)
    valid = np.ones_like(F, dtype=bool) if valid is None else np.asarray(valid, dtype=bool)
    return core._score_block_arrays(F, S, Q, valid, dt, CONFIG)


def test_low_low_is_not_positive_handoff():
    F = np.full(4000, 0.1)
    S = np.full(4000, 0.1)
    scores = score_feature_case(F, S)
    assert np.nanmean(scores["coordination_bank_mean"]) > 0.85
    assert np.nanmean(scores["handoff_bank_mean"]) < 1e-8
    assert np.nanmean(scores["density_bank_mean"]) < 0.15


def test_stationary_high_high_is_density_not_transition():
    F = np.full(4000, 0.9)
    S = np.full(4000, 0.9)
    scores = score_feature_case(F, S)
    assert np.nanmean(scores["density_bank_mean"]) > 0.75
    assert np.nanmean(scores["handoff_bank_mean"]) < 1e-8


def test_forward_lag_diagnostic_recovers_500ms():
    dt = 0.025
    times = np.arange(0, 100, dt)
    centers = np.arange(5, 95, 3.0)
    F = 0.15 + 0.7 * generator.burst_envelope(times, centers, 0.08)
    S = 0.15 + 0.7 * generator.burst_envelope(times, centers + 0.5, 0.12)
    scores = score_feature_case(np.clip(F, 0, 1), np.clip(S, 0, 1), dt=dt)
    means = {lag: np.nanmean(scores[f"handoff_{int(lag * 1000):04d}ms"]) for lag in CONFIG["construct"]["lag_bank_seconds"]}
    best = max(means, key=means.get)
    assert abs(best - 0.5) <= 0.1


def test_reverse_is_weaker_than_forward():
    dt = 0.025
    times = np.arange(0, 100, dt)
    centers = np.arange(5, 95, 3.0)
    F = np.clip(0.15 + 0.7 * generator.burst_envelope(times, centers, 0.08), 0, 1)
    forward = np.clip(0.15 + 0.7 * generator.burst_envelope(times, centers + 0.5, 0.12), 0, 1)
    reverse = np.clip(0.15 + 0.7 * generator.burst_envelope(times, centers - 0.5, 0.12), 0, 1)
    forward_h = np.nanmean(score_feature_case(F, forward, dt=dt)["handoff_bank_mean"])
    reverse_h = np.nanmean(score_feature_case(F, reverse, dt=dt)["handoff_bank_mean"])
    assert forward_h > reverse_h


def test_hard_artifact_rows_are_missing():
    frame = pd.DataFrame(
        {
            "time_lsl": np.arange(0, 80, 0.025),
            "sample_index": np.arange(3200),
            "condition": ["BASELINE_1"] * 1600 + ["TARGET_1"] * 1600,
            "block_id": ["BASELINE_1__01"] * 1600 + ["TARGET_1__02"] * 1600,
            "temporal_gamma_log_power": np.random.default_rng(1).normal(size=3200),
            "visual_gamma_log_power": np.random.default_rng(2).normal(size=3200),
            "theta_integration_log_power": np.random.default_rng(3).normal(size=3200),
            "jaw_hf_log_power": np.r_[np.random.default_rng(4).normal(size=3100), np.full(100, 100.0)],
            "global_p2p": np.random.default_rng(5).normal(size=3200),
            "fp1_p2p": np.random.default_rng(6).normal(size=3200),
            "timestamp_gap_in_gamma_window": False,
            "timestamp_gap_in_theta_window": False,
        }
    )
    candidate, _ = core.compute_candidate(frame, CONFIG)
    failed = candidate["artifact_hard_fail"]
    assert failed.sum() >= 100
    assert candidate.loc[failed, "handoff_bank_mean"].isna().all()


def test_gap_window_flagging():
    timestamps = np.arange(1000, 1010, 1 / 250.0)
    timestamps[1250:] += 0.5
    endpoints = np.arange(249, len(timestamps), 6)
    flags = core._gap_window_flags(timestamps, endpoints, 250, 0.1)
    assert flags.any()
    assert flags.sum() > 10
