# Micro Handoff v0.1

Exploratory raw-EEG module for a prespecified temporal-gamma-to-theta micro-handoff candidate.

## Boundaries

- Not a consciousness detector, probability, clinical output, or proof of 40 Hz frames.
- Separate from CAI/SID v0.2 and the Master Suite primary chain.
- A 25 ms output cadence is not 25 ms spectral resolution.
- Historical results are retrospective, condition-order-confounded, and primarily single-participant.

## Main commands

```text
python scripts/praycg_micro_handoff_v0_1.py --xdf RUN.xdf --segments-csv segments_used.csv --out OUTPUT
python scripts/generate_synthetic_micro_handoff_v0_1.py --out examples/synthetic_known_lag
python scripts/praycg_micro_handoff_historical_batch_v0_1.py --core-audit core_output_audit.csv --out-root OUTPUT
python scripts/praycg_micro_handoff_gui_v0_1.py --gui
```

The single-run command writes readiness, 25 ms feature/state series, full lag series, branch summaries, contrasts, null results, QC, provenance, and a human-readable report. The historical batch runner inventories every recording and analyzes only eligible runs.

The Control Center v0.95 Analysis tab launches the same GUI from its isolated **Exploratory Analysis** section and automatically supplies the selected run, resolved XDF when available, preferred analysis folder, and a run-specific output folder. The registration file explicitly prevents this module from changing Master Suite eligibility or primary conclusions.
