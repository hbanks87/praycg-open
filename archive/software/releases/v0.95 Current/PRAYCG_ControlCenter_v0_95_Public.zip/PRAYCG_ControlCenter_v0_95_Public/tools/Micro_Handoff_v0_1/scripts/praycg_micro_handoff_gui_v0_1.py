#!/usr/bin/env python3
"""Plain-language desktop launcher for Micro Handoff v0.1."""

from __future__ import annotations

import argparse
import json
import os
import threading
import traceback
from pathlib import Path
from typing import Optional

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from micro_handoff_core_v0_1 import analyze_single, load_eeg_xdf, load_json, load_segments, readiness_report


HERE = Path(__file__).resolve().parent
DEFAULT_CONFIG = HERE.parent / "config" / "micro_handoff_config_v0_1.json"


def find_one(folder: Optional[Path], pattern: str) -> str:
    if not folder or not folder.is_dir():
        return ""
    matches = sorted(path for path in folder.rglob(pattern) if path.is_file())
    return str(matches[0].resolve()) if len(matches) == 1 else ""


class MicroHandoffGUI:
    def __init__(self, root: tk.Tk, args: argparse.Namespace):
        self.root = root
        self.root.title("PRAYCG Micro Handoff v0.1 — Exploratory")
        self.root.geometry("980x700")
        run_folder = args.run_folder.resolve() if args.run_folder and args.run_folder.exists() else None
        analysis_folder = args.analysis_folder.resolve() if args.analysis_folder and args.analysis_folder.exists() else None
        xdf = str(args.xdf.resolve()) if args.xdf else find_one(run_folder, "*.xdf")
        segments = str(args.segments_csv.resolve()) if args.segments_csv else (find_one(analysis_folder, "segments_used.csv") or find_one(run_folder, "segments_used.csv"))
        default_out = args.out or ((analysis_folder or run_folder or Path.cwd()) / "Exploratory_MicroHandoff_v0_1")
        self.vars = {
            "xdf": tk.StringVar(value=xdf),
            "segments": tk.StringVar(value=segments),
            "out": tk.StringVar(value=str(Path(default_out).resolve())),
            "label": tk.StringVar(value=(run_folder.name if run_folder else "PRAYCG_Run")),
        }
        self.config_path = args.config.resolve()
        self.build()

    def build(self) -> None:
        outer = ttk.Frame(self.root, padding=10)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Micro Handoff v0.1", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(
            outer,
            text="Exploratory temporal-gamma/theta coordination analysis. This is not a consciousness detector, probability, diagnosis, or Master Suite eligibility input.",
            foreground="#8a1c1c",
            wraplength=920,
        ).pack(anchor="w", pady=(3, 10))
        form = ttk.LabelFrame(outer, text="Inputs")
        form.pack(fill="x")
        self.row(form, 0, "Raw recording (XDF)", "xdf", self.choose_xdf)
        self.row(form, 1, "Phase segments", "segments", self.choose_segments)
        self.row(form, 2, "Output folder", "out", self.choose_out)
        self.row(form, 3, "Run label", "label", None)
        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=8)
        self.preflight_button = ttk.Button(actions, text="1. Check Readiness", command=self.preflight)
        self.preflight_button.pack(side="left", padx=3)
        self.run_button = ttk.Button(actions, text="2. Run Micro Handoff", command=self.run_analysis)
        self.run_button.pack(side="left", padx=3)
        ttk.Button(actions, text="Open Output Folder", command=self.open_output).pack(side="left", padx=3)
        ttk.Button(actions, text="Read Method", command=lambda: os.startfile(str(HERE.parent / "docs" / "MICRO_HANDOFF_MATHEMATICAL_SPECIFICATION_v0_1.md"))).pack(side="left", padx=3)
        notes = ttk.LabelFrame(outer, text="What the outputs mean")
        notes.pack(fill="x", pady=(0, 8))
        ttk.Label(
            notes,
            text="Coordination can be high in low-low states. Positive handoff requires a fast positive change followed by a slow positive change. Activation-weighted density can be high in a sustained high-high state without proving a handoff. The 25 ms output is a display refresh, not independent 25 ms spectral evidence.",
            wraplength=920,
        ).pack(anchor="w", padx=6, pady=6)
        status = ttk.LabelFrame(outer, text="Readiness and run log")
        status.pack(fill="both", expand=True)
        self.text = tk.Text(status, wrap="word", height=22)
        self.text.pack(fill="both", expand=True, padx=6, pady=6)
        self.log("Choose a raw XDF and its Master Suite segments_used.csv, then check readiness.\n")

    def row(self, parent, row: int, label: str, key: str, command) -> None:
        ttk.Label(parent, text=label, width=24).grid(row=row, column=0, sticky="w", padx=6, pady=4)
        ttk.Entry(parent, textvariable=self.vars[key]).grid(row=row, column=1, sticky="ew", padx=4, pady=4)
        if command:
            ttk.Button(parent, text="Browse", command=command).grid(row=row, column=2, padx=6, pady=4)
        parent.columnconfigure(1, weight=1)

    def choose_xdf(self):
        value = filedialog.askopenfilename(title="Select raw XDF", filetypes=[("XDF", "*.xdf"), ("All files", "*.*")])
        if value:
            self.vars["xdf"].set(value)

    def choose_segments(self):
        value = filedialog.askopenfilename(title="Select segments_used.csv", filetypes=[("CSV", "*.csv"), ("All files", "*.*")])
        if value:
            self.vars["segments"].set(value)

    def choose_out(self):
        value = filedialog.askdirectory(title="Select output folder")
        if value:
            self.vars["out"].set(value)

    def log(self, message: str) -> None:
        self.text.insert("end", message)
        self.text.see("end")

    def validate_paths(self) -> tuple[Path, Path, Path]:
        xdf = Path(self.vars["xdf"].get().strip())
        segments = Path(self.vars["segments"].get().strip())
        out = Path(self.vars["out"].get().strip())
        if not xdf.is_file() or xdf.suffix.lower() != ".xdf":
            raise ValueError("Select a valid raw XDF recording.")
        if not segments.is_file():
            raise ValueError("Select the matching segments_used.csv file.")
        if not str(out):
            raise ValueError("Choose an output folder.")
        return xdf, segments, out

    def preflight(self) -> None:
        try:
            xdf, segments_path, _ = self.validate_paths()
        except Exception as exc:
            messagebox.showwarning("Inputs needed", str(exc))
            return
        self.preflight_button.configure(state="disabled")
        self.log("Loading recording and checking frozen readiness gates...\n")

        def worker():
            try:
                eeg = load_eeg_xdf(xdf)
                segments = load_segments(segments_path)
                report = readiness_report(eeg, segments, load_json(self.config_path))
                lines = [f"READINESS: {report['status']}"]
                lines.extend(f"- {item['level']} / {item['code']}: {item['message']}" for item in report["reasons"])
                if not report["reasons"]:
                    lines.append("- Initial frozen checks passed. Final coverage is checked after feature extraction.")
                lines.append("This is computation readiness, not proof that the construct is valid.\n")
                self.root.after(0, lambda: self.log("\n".join(lines) + "\n"))
            except Exception:
                detail = traceback.format_exc()
                self.root.after(0, lambda: self.log("Readiness failed to run:\n" + detail + "\n"))
            finally:
                self.root.after(0, lambda: self.preflight_button.configure(state="normal"))

        threading.Thread(target=worker, daemon=True).start()

    def run_analysis(self) -> None:
        try:
            xdf, segments, out = self.validate_paths()
        except Exception as exc:
            messagebox.showwarning("Inputs needed", str(exc))
            return
        self.run_button.configure(state="disabled")
        self.log("Running the frozen candidate. Invalid windows will be missing, not zero...\n")

        def worker():
            try:
                result = analyze_single(xdf, segments, self.config_path, out, self.vars["label"].get().strip() or "PRAYCG_Run")
                self.root.after(0, lambda: self.log(f"Finished with status {result['status']}.\nReport: {out / 'MICRO_HANDOFF_REPORT.md'}\n"))
                self.root.after(0, lambda: messagebox.showinfo("Micro Handoff finished", f"Status: {result['status']}\n\nOutputs: {out}"))
            except Exception:
                detail = traceback.format_exc()
                self.root.after(0, lambda: self.log("Analysis failed:\n" + detail + "\n"))
                self.root.after(0, lambda: messagebox.showerror("Analysis failed", "See the run log for details."))
            finally:
                self.root.after(0, lambda: self.run_button.configure(state="normal"))

        threading.Thread(target=worker, daemon=True).start()

    def open_output(self):
        path = Path(self.vars["out"].get().strip())
        path.mkdir(parents=True, exist_ok=True)
        os.startfile(str(path))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--gui", action="store_true")
    parser.add_argument("--run-folder", type=Path)
    parser.add_argument("--analysis-folder", type=Path)
    parser.add_argument("--xdf", type=Path)
    parser.add_argument("--segments-csv", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = tk.Tk()
    MicroHandoffGUI(root, args)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
