# Micro Handoff v0.1 — frozen candidate specification

## Status and claim boundary

Micro Handoff v0.1 is an **exploratory development candidate**. It tests whether a posterior-temporal 30–45 Hz activation proxy is followed, within a fixed 100–1000 ms lag bank, by a posterior/parietal-temporal 4–8 Hz integration proxy. It does not directly measure consciousness, prove discrete 40 Hz conscious frames, or provide a clinical or diagnostic result. “RPM” and “density” are engineering metaphors for candidate display variables, not established biological quantities.

The module is separate from frozen CAI/SID v0.2 and cannot affect Master Suite eligibility or primary PRAYCG conclusions.

## Sampling and causal feature windows

The output refresh target is 25 ms. A 25 ms row is an update time, not an independent spectral observation. Gamma is estimated from the trailing 250 ms and theta from the trailing 500 ms. Only samples at or before the row timestamp enter those estimates. The estimator uses endpoint-labelled, trailing Hann-window periodograms; it does not use zero-phase filtering or centered windows. Standard XDF clock synchronization/dejittering supplies the marker-aligned analysis timebase. Positive raw timestamp gaps above the declared threshold still invalidate spanning windows; small negative packet-jitter intervals are recorded in QC but are not treated as physiological gaps.

For the fixed PRAYCG16 map:

- temporal gamma: T5/T6, 30–45 Hz;
- visual gamma comparison: O1/O2, 30–45 Hz;
- theta integration: Pz/P3/P4/T5/T6, 4–8 Hz;
- artifact sentinels: T3/T4 high-frequency power, Fp1 peak-to-peak, and global neural peak-to-peak.

The neural channels are common-average referenced over the 13 non-sentinel channels. Raw feature families remain in the output; the combined scores do not replace them.

## Baseline transformation

Every feature is referenced only to valid Baseline 1 rows:

```text
z_B1(x_t) = 0.67448975 * (x_t - median_B1(x)) / MAD_B1(x)
```

The transform is clipped to ±6 after calculation. There is no full-run fallback. Missing or insufficient Baseline 1 makes the candidate ineligible.

## Fast and slow activation

```text
F(t) = sigmoid(z_B1(log temporal-gamma power at t))
S(t) = sigmoid(z_B1(log theta-integration power at t))
```

F and S are bounded activation proxies. They are not probabilities.

## Artifact quality

Let `Z_sentinel(t)` be the maximum positive standardized value across jaw high-frequency and Fp1 peak-to-peak, and let `Z_global(t)` be global neural-channel peak-to-peak.

```text
Q(t) = exp(-0.50 * max(Z_sentinel(t) - 2, 0))
       * exp(-0.15 * max(Z_global(t) - 4, 0))
```

Rows with either sentinel artifact z-score above 5, global peak-to-peak z-score above 8, timestamp gaps inside either feature window, nonfinite required values, or times outside an identified block are invalid and are stored as missing rather than zero. The later and gentler global penalty reduces the risk that a large neural-band candidate is vetoed solely for having high peak-to-peak amplitude; the raw global value remains visible for sensitivity review.

## Coordination, positive handoff, and activation-weighted density

First compute trailing smooths and positive changes:

```text
O(t)     = clip(max(F_100ms(t) - F_100ms(t-100ms), 0) / 0.25, 0, 1)
R(t,tau) = clip(max(S_250ms(t+tau) - S_250ms(t+tau-100ms), 0) / 0.25, 0, 1)
```

For every prespecified lag `tau` in {0.1, 0.2, ..., 1.0} seconds:

```text
C(t,tau) = 1 - abs(F(t) - S(t+tau))
Q_pair(t,tau) = sqrt(Q(t) * Q(t+tau))
H(t,tau) = Q_pair(t,tau) * sqrt(O(t) * R(t,tau))
A(t,tau) = (F(t) + S(t+tau)) / 2
D(t,tau) = Q_pair(t,tau) * A(t,tau) * C(t,tau)
```

- `C` is state agreement. Low-low can have high C.
- `H` is positive directional change evidence. Low-low and stationary high-high should have low H.
- `D` is activation-weighted coordination. Low-low is down-weighted, but D remains a proxy rather than a consciousness measure.

The primary candidate values are equal-weight means across the complete, declared lag bank. No condition-specific “winning lag” is selected. The 500 ms series is a display-only fixed-lag view. A full-run best lag is reported only as a diagnostic and carries no confirmatory status.

Because the slow response is evaluated at `t+tau`, H and D are offline directional estimates. A live implementation would have to display the value after the lag has elapsed.

## Inference and nulls

Rows are not treated as independent observations. Within-run intervals use 30-second non-overlapping block summaries. Time-structure nulls are evaluated on a declared 100 ms diagnostic grid to avoid presenting the 25 ms refresh rows as independent evidence. The module reports circular time-shift and phase-randomized nulls, block-label permutations when estimable, and artifact-matched contrasts. Historical cross-run summaries are descriptive repeated-run evidence; they are not population inference when the archive contains one participant.

## Eligibility

The report distinguishes computation readiness from construct validity. Major sample-rate/timestamp disagreement, insufficient Baseline 1, fewer than two analyzable stimulus branches, or less than 70% feature coverage makes a run ineligible for branch inference. A 125 Hz recording is computationally usable but receives a resolution caution; 250 Hz or higher is preferred.
