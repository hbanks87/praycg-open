# Micro Handoff v0.1 synthetic validation

**Overall status: PASS**

Passing validates declared software behavior on synthetic fixtures only; it does not validate a consciousness construct.

| Check | Result | Requirement |
|---|---|---|
| known_lag_recovery | PASS | Best diagnostic lag within 0.10 s of 0.50 s |
| known_handoff_exceeds_circular_shift | PASS | Observed bank handoff exceeds null median; p-value retained descriptively |
| known_handoff_exceeds_phase_randomized | PASS | Observed bank handoff exceeds null median; p-value retained descriptively |
| low_low_coordination | PASS | Low-low may remain highly coordinated |
| low_low_not_handoff | PASS | Positive handoff below 0.01 |
| low_low_density_low | PASS | Activation-weighted density below 0.10 |
| stationary_high_high_density | PASS | Stationary high-high density above 0.75 |
| stationary_high_high_not_transition | PASS | Stationary high-high handoff below 0.01 |
| reverse_weaker_than_forward | PASS | Reverse-direction handoff lower than forward |
| independent_not_above_nulls | PASS | Both one-sided null p-values exceed 0.05 |
| artifact_rows_gated | PASS | Injected artifact produces hard-invalid rows |
| artifact_does_not_materially_inflate_handoff | PASS | Artifact-case valid handoff no more than 0.01 above paired clean case |
| timestamp_gap_invalidated | PASS | Gap-spanning feature rows are flagged |
| deterministic_reproduction | PASS | Selected numerical outputs are byte-identical on repeat run |

The known 500 ms raw-signal fixture is allowed a ±100 ms diagnostic tolerance because gamma and theta are estimated with different causal trailing windows. Null p-values are reported but were not tuned as acceptance thresholds.
