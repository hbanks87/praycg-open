#!/usr/bin/env python3
"""Core implementation for PRAYCG Micro Handoff v0.1.

This module intentionally keeps construct language conservative.  Its scores are
bounded EEG proxies, not probabilities or direct measurements of consciousness.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import math
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


VERSION = "0.1.0"
MODULE_NAME = "Micro Handoff"
STIMULUS_CONDITIONS = (
    "CONTROL_1",
    "PHASESCRAMBLED_1",
    "TARGET_1",
    "SHOTORDERSCRAMBLE_1",
    "CONTEXTUAL_OVERRIDE_1",
)
CORE_PREFIXES = ("BASELINE", "CONTROL", "PHASESCRAMBLED", "TARGET", "SHOTORDER", "CONTEXTUAL_OVERRIDE", "WASHOUT")


@dataclass
class EEGInput:
    timestamps: np.ndarray
    data: np.ndarray
    stream_name: str
    nominal_rate_hz: float
    source_kind: str
    raw_timestamps: Optional[np.ndarray] = None


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        return None if not np.isfinite(value) else float(value)
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    return value


def _scalar(value: Any, default: Any = "") -> Any:
    while isinstance(value, list) and len(value) == 1:
        value = value[0]
    return default if value is None else value


def _import_pyxdf(extra_path: Optional[Path] = None):
    if extra_path:
        candidate = str(extra_path.resolve())
        if candidate not in sys.path:
            sys.path.insert(0, candidate)
        cached = sys.modules.get("pyxdf")
        if cached is not None and not hasattr(cached, "load_xdf"):
            del sys.modules["pyxdf"]
    module = importlib.import_module("pyxdf")
    if not hasattr(module, "load_xdf"):
        raise RuntimeError("pyxdf with load_xdf() is required; install pyxdf or provide --pyxdf-path")
    return module


def load_eeg_xdf(path: Path, pyxdf_path: Optional[Path] = None) -> EEGInput:
    pyxdf = _import_pyxdf(pyxdf_path)
    streams, _ = pyxdf.load_xdf(str(path), dejitter_timestamps=True, verbose=False)
    candidates = []
    for stream in streams:
        info = stream.get("info", {})
        kind = str(_scalar(info.get("type", ""))).lower()
        name = str(_scalar(info.get("name", "")))
        series = np.asarray(stream.get("time_series", []))
        stamps = np.asarray(stream.get("time_stamps", []), dtype=float)
        if kind == "eeg" or "eeg" in name.lower():
            candidates.append((int(series.shape[0]) if series.ndim else 0, stream, series, stamps))
    if not candidates:
        raise ValueError("No EEG stream was found in the XDF")
    _, stream, series, stamps = max(candidates, key=lambda item: item[0])
    if series.ndim == 1:
        series = series[:, None]
    info = stream.get("info", {})
    nominal = float(_scalar(info.get("nominal_srate", 0.0), 0.0) or 0.0)
    raw_stamps = stamps
    try:
        raw_streams, _ = pyxdf.load_xdf(str(path), dejitter_timestamps=False, verbose=False)
        raw_candidates = []
        for raw_stream in raw_streams:
            raw_info = raw_stream.get("info", {})
            raw_kind = str(_scalar(raw_info.get("type", ""))).lower()
            raw_name = str(_scalar(raw_info.get("name", "")))
            raw_series = np.asarray(raw_stream.get("time_series", []))
            if (raw_kind == "eeg" or "eeg" in raw_name.lower()) and raw_name == str(_scalar(info.get("name", "EEG"))):
                raw_candidates.append((int(raw_series.shape[0]) if raw_series.ndim else 0, raw_stream))
        if raw_candidates:
            raw_stamps = np.asarray(max(raw_candidates, key=lambda item: item[0])[1].get("time_stamps", stamps), dtype=float)
            if len(raw_stamps) != len(stamps):
                raw_stamps = stamps
    except Exception:
        raw_stamps = stamps
    return EEGInput(
        timestamps=stamps.astype(float),
        data=np.asarray(series, dtype=float),
        stream_name=str(_scalar(info.get("name", "EEG"))),
        nominal_rate_hz=nominal,
        source_kind="XDF",
        raw_timestamps=raw_stamps.astype(float),
    )


def load_eeg_npz(path: Path) -> EEGInput:
    bundle = np.load(path, allow_pickle=False)
    stamps = np.asarray(bundle["timestamps"], dtype=float)
    data = np.asarray(bundle["eeg"], dtype=float)
    nominal = float(np.asarray(bundle["nominal_rate_hz"]).reshape(-1)[0])
    return EEGInput(stamps, data, "SyntheticEEG", nominal, "NPZ_SYNTHETIC", stamps.copy())


def canonical_condition(value: Any) -> str:
    text = str(value or "").strip().upper().replace(" ", "_").replace("-", "_")
    if text.startswith("SHOT_ORDER") or text.startswith("SHOTORDER"):
        return "SHOTORDERSCRAMBLE_1" if "SCRAMBLE" in text else "SHOTORDER_1"
    if text.startswith("PHASE_SCRAMBLED") or text.startswith("PHASESCRAMBLED"):
        return "PHASESCRAMBLED_1"
    if text.startswith("OVERRIDE") or text.startswith("CONTEXTUAL_OVERRIDE"):
        return "CONTEXTUAL_OVERRIDE_1"
    for prefix in ("BASELINE", "CONTROL", "TARGET", "WASHOUT"):
        if text.startswith(prefix):
            suffix = "2" if prefix == "BASELINE" and "2" in text else "1"
            if prefix == "WASHOUT":
                digits = "".join(c for c in text if c.isdigit())
                suffix = digits[:1] or "1"
            return f"{prefix}_{suffix}"
    return text


def load_segments(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    lower = {c.lower(): c for c in frame.columns}
    name_col = lower.get("segment") or lower.get("condition") or lower.get("phase")
    start_col = lower.get("start") or lower.get("start_sec") or lower.get("start_time")
    end_col = lower.get("end") or lower.get("end_sec") or lower.get("end_time")
    if not name_col or not start_col or not end_col:
        raise ValueError("Segment table must contain segment/condition, start, and end columns")
    out = pd.DataFrame(
        {
            "condition": frame[name_col].map(canonical_condition),
            "start": pd.to_numeric(frame[start_col], errors="coerce"),
            "end": pd.to_numeric(frame[end_col], errors="coerce"),
        }
    )
    if "segment_type" in frame.columns:
        core_mask = frame["segment_type"].astype(str).str.lower().eq("core")
        if core_mask.any():
            out = out[core_mask.values]
    exact = out["condition"].str.startswith(CORE_PREFIXES, na=False)
    out = out[exact & np.isfinite(out["start"]) & np.isfinite(out["end"]) & (out["end"] > out["start"])]
    out = out.sort_values("start").drop_duplicates(["condition", "start", "end"]).reset_index(drop=True)
    out["block_id"] = [f"{condition}__{index + 1:02d}" for index, condition in enumerate(out["condition"])]
    return out


def assign_segments(timestamps: np.ndarray, segments: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
    condition = np.full(len(timestamps), "UNASSIGNED", dtype=object)
    block = np.full(len(timestamps), "UNASSIGNED", dtype=object)
    for row in segments.itertuples(index=False):
        mask = (timestamps >= float(row.start)) & (timestamps < float(row.end))
        condition[mask] = str(row.condition)
        block[mask] = str(row.block_id)
    return condition, block


def sigmoid(values: Iterable[float]) -> np.ndarray:
    x = np.clip(np.asarray(values, dtype=float), -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-x))


def robust_reference_z(values: np.ndarray, reference_mask: np.ndarray, clip: float) -> Tuple[np.ndarray, Dict[str, float]]:
    x = np.asarray(values, dtype=float)
    ref = x[reference_mask & np.isfinite(x)]
    if len(ref) < 10:
        return np.full_like(x, np.nan), {"median": math.nan, "mad": math.nan, "n": int(len(ref))}
    median = float(np.nanmedian(ref))
    mad = float(np.nanmedian(np.abs(ref - median)))
    if not np.isfinite(mad) or mad <= 1e-12:
        return np.full_like(x, np.nan), {"median": median, "mad": mad, "n": int(len(ref))}
    z = 0.67448975 * (x - median) / mad
    return np.clip(z, -clip, clip), {"median": median, "mad": mad, "n": int(len(ref))}


def _finite_fill(data: np.ndarray) -> np.ndarray:
    x = np.asarray(data, dtype=float).copy()
    for index in range(x.shape[1]):
        column = x[:, index]
        finite = np.isfinite(column)
        median = float(np.nanmedian(column[finite])) if finite.any() else 0.0
        column[~finite] = median
        x[:, index] = column
    return x


def _bandpower_windows(
    data: np.ndarray,
    endpoints: np.ndarray,
    window_samples: int,
    sample_rate: float,
    channels: Sequence[int],
    band: Sequence[float],
    chunk_size: int = 2048,
) -> np.ndarray:
    if not channels:
        return np.full(len(endpoints), np.nan)
    selected = data[:, list(channels)]
    offsets = np.arange(window_samples - 1, -1, -1, dtype=int)
    window = np.hanning(window_samples).astype(float)
    norm = sample_rate * float(np.sum(window * window))
    nfft = 1 << int(math.ceil(math.log2(max(window_samples, 2))))
    frequencies = np.fft.rfftfreq(nfft, 1.0 / sample_rate)
    band_mask = (frequencies >= float(band[0])) & (frequencies <= float(band[1]))
    if not band_mask.any():
        return np.full(len(endpoints), np.nan)
    df_hz = sample_rate / nfft
    output = np.full(len(endpoints), np.nan)
    for first in range(0, len(endpoints), chunk_size):
        last = min(len(endpoints), first + chunk_size)
        ends = endpoints[first:last]
        indices = ends[:, None] - offsets[None, :]
        samples = selected[indices, :]
        samples = samples - np.mean(samples, axis=1, keepdims=True)
        samples = samples * window[None, :, None]
        spectrum = np.fft.rfft(samples, n=nfft, axis=1)
        psd = (np.abs(spectrum) ** 2) / max(norm, 1e-12)
        power = np.sum(psd[:, band_mask, :], axis=1) * df_hz
        output[first:last] = np.nanmedian(power, axis=1)
    return output


def _p2p_windows(
    data: np.ndarray,
    endpoints: np.ndarray,
    window_samples: int,
    channels: Sequence[int],
    chunk_size: int = 4096,
) -> np.ndarray:
    if not channels:
        return np.full(len(endpoints), np.nan)
    selected = data[:, list(channels)]
    offsets = np.arange(window_samples - 1, -1, -1, dtype=int)
    output = np.full(len(endpoints), np.nan)
    for first in range(0, len(endpoints), chunk_size):
        last = min(len(endpoints), first + chunk_size)
        ends = endpoints[first:last]
        indices = ends[:, None] - offsets[None, :]
        samples = selected[indices, :]
        p2p = np.nanmax(samples, axis=1) - np.nanmin(samples, axis=1)
        output[first:last] = np.nanmedian(p2p, axis=1)
    return output


def _gap_window_flags(timestamps: np.ndarray, endpoints: np.ndarray, window_samples: int, maximum_gap: float) -> np.ndarray:
    differences = np.diff(timestamps)
    bad = (~np.isfinite(differences)) | (differences > maximum_gap)
    prefix = np.concatenate([[0], np.cumsum(bad.astype(int))])
    starts = endpoints - window_samples + 1
    return (prefix[endpoints] - prefix[starts]) > 0


def extract_raw_features(eeg: EEGInput, segments: pd.DataFrame, config: Dict[str, Any]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    timestamps = np.asarray(eeg.timestamps, dtype=float)
    data = _finite_fill(np.asarray(eeg.data, dtype=float))
    sample_rate = float(eeg.nominal_rate_hz)
    channel_count = int(data.shape[1]) if data.ndim == 2 else 0
    channels_cfg = config["channels_zero_based"]
    required_max = max(index for values in channels_cfg.values() for index in values)
    if channel_count <= required_max:
        raise ValueError(f"PRAYCG16 feature map needs channel index {required_max}; EEG has {channel_count} channels")
    clean = list(channels_cfg["neural_clean"])
    common = np.nanmean(data[:, clean], axis=1)
    data[:, clean] = data[:, clean] - common[:, None]

    input_cfg = config["input"]
    step_samples = max(1, int(round(sample_rate * float(input_cfg["output_step_seconds"]))))
    gamma_samples = max(8, int(round(sample_rate * float(input_cfg["gamma_window_seconds"]))))
    theta_samples = max(16, int(round(sample_rate * float(input_cfg["theta_window_seconds"]))))
    endpoints = np.arange(max(gamma_samples, theta_samples) - 1, len(timestamps), step_samples, dtype=int)
    if len(endpoints) < 20:
        raise ValueError("EEG is too short for the configured causal feature windows")
    times = timestamps[endpoints]

    temporal_gamma = _bandpower_windows(data, endpoints, gamma_samples, sample_rate, channels_cfg["posterior_temporal"], input_cfg["gamma_band_hz"])
    visual_gamma = _bandpower_windows(data, endpoints, gamma_samples, sample_rate, channels_cfg["visual"], input_cfg["gamma_band_hz"])
    theta = _bandpower_windows(data, endpoints, theta_samples, sample_rate, channels_cfg["theta_integration"], input_cfg["theta_band_hz"])
    jaw_hf = _bandpower_windows(data, endpoints, gamma_samples, sample_rate, channels_cfg["jaw_hf_sentinel"], [45.0, min(55.0, sample_rate / 2.0 - 0.5)])
    global_p2p = _p2p_windows(data, endpoints, gamma_samples, channels_cfg["neural_clean"])
    fp1_p2p = _p2p_windows(data, endpoints, gamma_samples, channels_cfg["fp1_ocular_sentinel"])
    gap_timestamps = np.asarray(eeg.raw_timestamps if eeg.raw_timestamps is not None else timestamps, dtype=float)
    gap_gamma = _gap_window_flags(gap_timestamps, endpoints, gamma_samples, float(config["qc"]["maximum_gap_seconds"]))
    gap_theta = _gap_window_flags(gap_timestamps, endpoints, theta_samples, float(config["qc"]["maximum_gap_seconds"]))
    condition, block = assign_segments(times, segments)

    tiny = np.finfo(float).tiny
    frame = pd.DataFrame(
        {
            "time_lsl": times,
            "sample_index": endpoints,
            "condition": condition,
            "block_id": block,
            "temporal_gamma_log_power": np.log(np.maximum(temporal_gamma, tiny)),
            "visual_gamma_log_power": np.log(np.maximum(visual_gamma, tiny)),
            "theta_integration_log_power": np.log(np.maximum(theta, tiny)),
            "jaw_hf_log_power": np.log(np.maximum(jaw_hf, tiny)),
            "global_p2p": global_p2p,
            "fp1_p2p": fp1_p2p,
            "timestamp_gap_in_gamma_window": gap_gamma,
            "timestamp_gap_in_theta_window": gap_theta,
        }
    )
    differences = np.diff(timestamps)
    finite_positive = differences[np.isfinite(differences) & (differences > 0)]
    duration_rate = (len(timestamps) - 1) / (timestamps[-1] - timestamps[0]) if len(timestamps) > 1 and timestamps[-1] > timestamps[0] else math.nan
    metadata = {
        "source_kind": eeg.source_kind,
        "stream_name": eeg.stream_name,
        "sample_count": int(len(timestamps)),
        "channel_count": channel_count,
        "nominal_rate_hz": sample_rate,
        "duration_effective_rate_hz": float(duration_rate),
        "median_interval_rate_hz": float(1.0 / np.nanmedian(finite_positive)) if len(finite_positive) else math.nan,
        "maximum_timestamp_gap_seconds": float(np.nanmax(finite_positive)) if len(finite_positive) else math.nan,
        "nonmonotonic_interval_count": int(np.sum((~np.isfinite(differences)) | (differences <= 0.0))),
        "raw_nonmonotonic_interval_count": int(np.sum(np.diff(gap_timestamps) <= 0.0)) if len(gap_timestamps) > 1 else 0,
        "feature_step_samples": step_samples,
        "nominal_feature_step_seconds": step_samples / sample_rate,
        "gamma_window_samples": gamma_samples,
        "theta_window_samples": theta_samples,
        "feature_row_count": int(len(frame)),
    }
    return frame, metadata


def _time_coverage(times: np.ndarray, start: float, end: float, cap_step: float) -> float:
    selected = np.sort(times[(times >= start) & (times < end) & np.isfinite(times)])
    if len(selected) < 2 or end <= start:
        return 0.0
    increments = np.diff(selected)
    covered = float(np.sum(np.minimum(increments, cap_step))) + cap_step
    return float(np.clip(covered / (end - start), 0.0, 1.0))


def readiness_report(eeg: EEGInput, segments: pd.DataFrame, config: Dict[str, Any], frame: Optional[pd.DataFrame] = None, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    qc = config["qc"]
    input_cfg = config["input"]
    timestamps = np.asarray(eeg.timestamps, dtype=float)
    data = np.asarray(eeg.data)
    differences = np.diff(timestamps)
    effective = (len(timestamps) - 1) / (timestamps[-1] - timestamps[0]) if len(timestamps) > 1 and timestamps[-1] > timestamps[0] else math.nan
    nominal = float(eeg.nominal_rate_hz)
    deviation = abs(effective - nominal) / nominal if nominal > 0 and np.isfinite(effective) else math.inf
    reasons: List[Dict[str, str]] = []

    def add(level: str, code: str, message: str) -> None:
        reasons.append({"level": level, "code": code, "message": message})

    channels = int(data.shape[1]) if data.ndim == 2 else 0
    if len(timestamps) == 0 or data.size == 0:
        add("INELIGIBLE", "NO_EEG_SAMPLES", "The selected EEG stream contains no samples.")
    if channels < int(input_cfg["minimum_channels"]):
        add("INELIGIBLE", "INSUFFICIENT_CHANNELS", f"The fixed candidate needs at least {input_cfg['minimum_channels']} EEG channels; {channels} were found.")
    if nominal < float(input_cfg["minimum_sample_rate_hz"]):
        add("INELIGIBLE", "LOW_NOMINAL_RATE", f"Nominal rate {nominal:.3f} Hz is below the frozen {input_cfg['minimum_sample_rate_hz']:.1f} Hz minimum.")
    elif nominal < float(input_cfg["preferred_sample_rate_hz"]):
        add("CAUTION", "RESOLUTION_CAUTION", f"Nominal rate {nominal:.3f} Hz is usable but below the preferred {input_cfg['preferred_sample_rate_hz']:.1f} Hz.")
    if deviation > float(qc["maximum_rate_deviation_eligible"]):
        add("INELIGIBLE", "RATE_TIMESTAMP_MISMATCH", f"Duration-derived rate differs from nominal by {deviation:.1%}, above the {qc['maximum_rate_deviation_eligible']:.0%} eligibility ceiling.")
    elif deviation > float(qc["maximum_rate_deviation_pass"]):
        add("CAUTION", "RATE_DEVIATION", f"Duration-derived rate differs from nominal by {deviation:.1%}.")
    if np.any((~np.isfinite(differences)) | (differences <= 0.0)):
        add("INELIGIBLE", "NONMONOTONIC_TIMESTAMPS", "EEG timestamps contain nonmonotonic or nonfinite intervals.")
    if segments.empty:
        add("INELIGIBLE", "NO_CORE_SEGMENTS", "No usable Baseline/stimulus/washout segment table was supplied.")
    baseline = segments[segments["condition"] == str(config["normalization"]["reference_condition"])]
    if baseline.empty:
        add("INELIGIBLE", "NO_BASELINE_1", "Baseline 1 is required and no full-run normalization fallback is allowed.")
    stimulus = segments[segments["condition"].isin(STIMULUS_CONDITIONS)]
    if stimulus["condition"].nunique() < int(qc["minimum_analyzable_branch_count"]):
        add("INELIGIBLE", "TOO_FEW_BRANCHES", f"At least {qc['minimum_analyzable_branch_count']} distinct stimulus branches are required.")

    coverage_rows = []
    if frame is not None and not frame.empty:
        valid_times = frame.loc[frame.get("pre_qc_valid", True).astype(bool), "time_lsl"].to_numpy(float)
        cap_step = max(float(metadata.get("nominal_feature_step_seconds", input_cfg["output_step_seconds"])) if metadata else float(input_cfg["output_step_seconds"]), 0.001) * 2.5
        for row in segments.itertuples(index=False):
            coverage = _time_coverage(valid_times, float(row.start), float(row.end), cap_step)
            coverage_rows.append({"condition": row.condition, "block_id": row.block_id, "coverage": coverage})
            if row.condition == config["normalization"]["reference_condition"] and coverage < float(qc["minimum_branch_coverage"]):
                add("INELIGIBLE", "BASELINE_COVERAGE", f"Baseline 1 feature coverage is {coverage:.1%}, below {qc['minimum_branch_coverage']:.0%}.")
            if row.condition in STIMULUS_CONDITIONS and coverage < float(qc["minimum_branch_coverage"]):
                add("INELIGIBLE", "BRANCH_COVERAGE", f"{row.condition} feature coverage is {coverage:.1%}, below {qc['minimum_branch_coverage']:.0%}.")
            elif row.condition in STIMULUS_CONDITIONS and coverage < float(qc["pass_branch_coverage"]):
                add("CAUTION", "MARGINAL_BRANCH_COVERAGE", f"{row.condition} feature coverage is {coverage:.1%}.")

    levels = {item["level"] for item in reasons}
    status = "INELIGIBLE" if "INELIGIBLE" in levels else ("CAUTION" if "CAUTION" in levels else "PASS")
    return {
        "schema": "PRAYCG_MicroHandoff_Readiness_v0_1",
        "generated_utc": utc_now(),
        "module_version": VERSION,
        "status": status,
        "computation_readiness_only": True,
        "construct_validity_established": False,
        "claim_boundary": config["claim_boundary"],
        "eeg": {
            "stream_name": eeg.stream_name,
            "sample_count": int(len(timestamps)),
            "channel_count": channels,
            "nominal_rate_hz": nominal,
            "duration_effective_rate_hz": float(effective) if np.isfinite(effective) else None,
            "relative_rate_deviation": float(deviation) if np.isfinite(deviation) else None,
        },
        "segments": int(len(segments)),
        "stimulus_conditions": sorted(stimulus["condition"].unique().tolist()) if not stimulus.empty else [],
        "coverage": coverage_rows,
        "reasons": reasons,
    }


def _rolling_mean(values: np.ndarray, rows: int) -> np.ndarray:
    return pd.Series(values, dtype=float).rolling(max(1, rows), min_periods=max(1, rows // 2)).mean().to_numpy(float)


def _score_block_arrays(F: np.ndarray, S: np.ndarray, Q: np.ndarray, valid: np.ndarray, dt: float, config: Dict[str, Any]) -> Dict[str, np.ndarray]:
    construct = config["construct"]
    onset_rows = max(1, int(round(float(construct["onset_smoothing_seconds"]) / dt)))
    onset_delta_rows = max(1, int(round(float(construct["onset_delta_seconds"]) / dt)))
    response_rows = max(1, int(round(float(construct["response_smoothing_seconds"]) / dt)))
    response_delta_rows = max(1, int(round(float(construct.get("response_delta_seconds", 0.10)) / dt)))
    F_smooth = _rolling_mean(F, onset_rows)
    S_smooth = _rolling_mean(S, response_rows)
    prior = np.full(len(F), np.nan)
    prior[onset_delta_rows:] = F_smooth[:-onset_delta_rows]
    scale = float(construct["positive_change_scale"])
    onset = np.clip(np.maximum(F_smooth - prior, 0.0) / scale, 0.0, 1.0)
    result: Dict[str, np.ndarray] = {"fast_onset": onset, "F_smooth": F_smooth, "S_smooth": S_smooth}
    lag_values = [float(value) for value in construct["lag_bank_seconds"]]
    h_columns, d_columns, c_columns = [], [], []
    for lag in lag_values:
        steps = max(1, int(round(lag / dt)))
        future_S = np.full(len(S), np.nan)
        future_Q = np.full(len(S), np.nan)
        future_valid = np.zeros(len(S), dtype=bool)
        future_S_prior = np.full(len(S), np.nan)
        if steps < len(S):
            future_S[:-steps] = S_smooth[steps:]
            future_Q[:-steps] = Q[steps:]
            future_valid[:-steps] = valid[steps:]
        prior_indices = np.arange(len(S)) + steps - response_delta_rows
        prior_ok = (prior_indices >= 0) & (prior_indices < len(S))
        future_S_prior[prior_ok] = S_smooth[prior_indices[prior_ok]]
        response = np.clip(np.maximum(future_S - future_S_prior, 0.0) / scale, 0.0, 1.0)
        quality_pair = np.sqrt(np.clip(Q * future_Q, 0.0, 1.0))
        pair_valid = valid & future_valid & np.isfinite(onset) & np.isfinite(response) & np.isfinite(quality_pair)
        coordination = 1.0 - np.abs(F - future_S)
        activation = 0.5 * (F + future_S)
        handoff = quality_pair * np.sqrt(np.clip(onset * response, 0.0, 1.0))
        density = quality_pair * activation * coordination
        coordination[~pair_valid] = np.nan
        handoff[~pair_valid] = np.nan
        density[~pair_valid] = np.nan
        tag = f"{int(round(lag * 1000)):04d}ms"
        result[f"coordination_{tag}"] = coordination
        result[f"handoff_{tag}"] = handoff
        result[f"density_{tag}"] = density
        result[f"theta_response_{tag}"] = response
        c_columns.append(coordination)
        h_columns.append(handoff)
        d_columns.append(density)
    c_stack = np.column_stack(c_columns)
    h_stack = np.column_stack(h_columns)
    d_stack = np.column_stack(d_columns)
    if bool(construct.get("require_complete_lag_bank_for_primary", True)):
        complete = np.isfinite(h_stack).all(axis=1) & np.isfinite(d_stack).all(axis=1) & np.isfinite(c_stack).all(axis=1)
    else:
        complete = np.isfinite(h_stack).any(axis=1) & np.isfinite(d_stack).any(axis=1) & np.isfinite(c_stack).any(axis=1)
    def row_nanmean(stack: np.ndarray) -> np.ndarray:
        counts = np.sum(np.isfinite(stack), axis=1)
        totals = np.nansum(stack, axis=1)
        return np.divide(totals, counts, out=np.full(len(stack), np.nan), where=counts > 0)
    result["coordination_bank_mean"] = row_nanmean(c_stack)
    result["handoff_bank_mean"] = row_nanmean(h_stack)
    result["density_bank_mean"] = row_nanmean(d_stack)
    for key in ("coordination_bank_mean", "handoff_bank_mean", "density_bank_mean"):
        result[key][~complete] = np.nan
    result["complete_lag_bank"] = complete
    return result


def compute_candidate(frame: pd.DataFrame, config: Dict[str, Any]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    output = frame.copy()
    output["pre_qc_valid"] = (
        output["condition"].ne("UNASSIGNED")
        & ~output["timestamp_gap_in_gamma_window"].astype(bool)
        & ~output["timestamp_gap_in_theta_window"].astype(bool)
        & np.isfinite(output["temporal_gamma_log_power"])
        & np.isfinite(output["theta_integration_log_power"])
    )
    reference = output["condition"].eq(config["normalization"]["reference_condition"]).to_numpy(bool) & output["pre_qc_valid"].to_numpy(bool)
    clip = float(config["normalization"]["robust_z_clip"])
    reference_stats: Dict[str, Any] = {}
    source_columns = {
        "temporal_gamma": "temporal_gamma_log_power",
        "visual_gamma": "visual_gamma_log_power",
        "theta": "theta_integration_log_power",
        "jaw_hf": "jaw_hf_log_power",
        "global_p2p": "global_p2p",
        "fp1_p2p": "fp1_p2p",
    }
    for role, column in source_columns.items():
        z, stats = robust_reference_z(output[column].to_numpy(float), reference, clip)
        output[f"z_{role}"] = z
        reference_stats[role] = stats
    output["fast_temporal_gamma"] = sigmoid(output["z_temporal_gamma"])
    output["slow_theta_integration"] = sigmoid(output["z_theta"])
    artifact_terms = np.column_stack(
        [
            np.maximum(output["z_jaw_hf"].to_numpy(float), 0.0),
            np.maximum(output["z_global_p2p"].to_numpy(float), 0.0),
            np.maximum(output["z_fp1_p2p"].to_numpy(float), 0.0),
        ]
    )
    output["artifact_z_max"] = np.nanmax(artifact_terms, axis=1)
    output["artifact_sentinel_z_max"] = np.nanmax(artifact_terms[:, [0, 2]], axis=1)
    hard = float(config["qc"]["hard_artifact_z"])
    global_hard = float(config["qc"].get("global_p2p_hard_z", hard))
    soft_start = float(config["qc"]["soft_artifact_start_z"])
    soft_global_start = float(config["qc"].get("soft_global_p2p_start_z", 4.0))
    sentinel_coefficient = float(config["qc"].get("soft_sentinel_coefficient", 0.50))
    global_coefficient = float(config["qc"].get("soft_global_p2p_coefficient", 0.15))
    output["artifact_hard_fail"] = (
        (output["z_jaw_hf"] > hard)
        | (output["z_fp1_p2p"] > hard)
        | (output["z_global_p2p"] > global_hard)
    )
    output["quality_soft"] = (
        np.exp(-sentinel_coefficient * np.maximum(output["artifact_sentinel_z_max"] - soft_start, 0.0))
        * np.exp(-global_coefficient * np.maximum(output["z_global_p2p"] - soft_global_start, 0.0))
    )
    output["valid"] = output["pre_qc_valid"] & ~output["artifact_hard_fail"]
    output.loc[~output["valid"], ["fast_temporal_gamma", "slow_theta_integration", "quality_soft"]] = np.nan

    score_columns: Dict[str, np.ndarray] = {}
    realized_dt = []
    for block_id, indices in output.groupby("block_id", sort=False).groups.items():
        if block_id == "UNASSIGNED":
            continue
        positions = np.asarray(list(indices), dtype=int)
        times = output.loc[positions, "time_lsl"].to_numpy(float)
        dt = float(np.nanmedian(np.diff(times))) if len(times) > 1 else float(config["input"]["output_step_seconds"])
        if not np.isfinite(dt) or dt <= 0:
            continue
        realized_dt.append(dt)
        scores = _score_block_arrays(
            output.loc[positions, "fast_temporal_gamma"].to_numpy(float),
            output.loc[positions, "slow_theta_integration"].to_numpy(float),
            output.loc[positions, "quality_soft"].to_numpy(float),
            output.loc[positions, "valid"].to_numpy(bool),
            dt,
            config,
        )
        for name, values in scores.items():
            if name not in score_columns:
                dtype = bool if values.dtype == bool else float
                score_columns[name] = np.zeros(len(output), dtype=dtype) if dtype is bool else np.full(len(output), np.nan)
            score_columns[name][positions] = values
    for name, values in score_columns.items():
        output[name] = values
    if "complete_lag_bank" not in output:
        output["complete_lag_bank"] = False

    display_tag = f"{int(round(float(config['construct']['display_lag_seconds']) * 1000)):04d}ms"
    output["display_coordination"] = output.get(f"coordination_{display_tag}", np.nan)
    output["display_handoff"] = output.get(f"handoff_{display_tag}", np.nan)
    output["display_density"] = output.get(f"density_{display_tag}", np.nan)
    threshold = float(config["construct"]["high_state_threshold"])
    median_step = max(float(np.nanmedian(realized_dt)) if realized_dt else 0.025, 0.001)
    display_rows = max(1, int(round(float(config["construct"]["display_lag_seconds"]) / median_step)))
    future_s = output["slow_theta_integration"].shift(-display_rows)
    same_block = output["block_id"].eq(output["block_id"].shift(-display_rows))
    output["display_future_slow"] = future_s.where(same_block)
    high_fast = output["fast_temporal_gamma"] >= threshold
    high_slow = output["display_future_slow"] >= threshold
    states = np.select(
        [high_fast & high_slow, high_fast & ~high_slow, ~high_fast & high_slow, ~high_fast & ~high_slow],
        ["HIGH_HIGH", "FAST_HIGH_SLOW_LOW", "FAST_LOW_SLOW_HIGH", "LOW_LOW"],
        default="INVALID",
    )
    output["micro_state"] = states
    output.loc[~np.isfinite(output["display_future_slow"]) | ~np.isfinite(output["fast_temporal_gamma"]), "micro_state"] = "INVALID"
    return output, {"reference_statistics": reference_stats, "median_feature_step_seconds": float(np.nanmedian(realized_dt)) if realized_dt else None}


def _nonoverlap_block_means(values: np.ndarray, times: np.ndarray, seconds: float) -> np.ndarray:
    finite = np.isfinite(values) & np.isfinite(times)
    if not finite.any():
        return np.asarray([], dtype=float)
    values, times = values[finite], times[finite]
    origin = float(np.nanmin(times))
    bins = np.floor((times - origin) / seconds).astype(int)
    return pd.DataFrame({"bin": bins, "value": values}).groupby("bin")["value"].mean().to_numpy(float)


def summarize_branches(frame: pd.DataFrame, segments: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    rows = []
    step = float(np.nanmedian(np.diff(frame["time_lsl"].to_numpy(float)))) if len(frame) > 1 else float(config["input"]["output_step_seconds"])
    for segment in segments.itertuples(index=False):
        group = frame[frame["block_id"] == segment.block_id]
        valid = group[np.isfinite(group["handoff_bank_mean"])]
        duration = float(segment.end - segment.start)
        valid_seconds = float(len(valid) * step)
        rows.append(
            {
                "condition": segment.condition,
                "block_id": segment.block_id,
                "start": float(segment.start),
                "end": float(segment.end),
                "duration_seconds": duration,
                "feature_rows": int(len(group)),
                "valid_bank_rows": int(len(valid)),
                "valid_bank_seconds": valid_seconds,
                "valid_bank_fraction": float(np.clip(valid_seconds / duration, 0.0, 1.0)) if duration > 0 else math.nan,
                "artifact_hard_fail_fraction": float(group["artifact_hard_fail"].mean()) if len(group) else math.nan,
                "fast_mean": float(valid["fast_temporal_gamma"].mean()) if len(valid) else math.nan,
                "slow_mean": float(valid["slow_theta_integration"].mean()) if len(valid) else math.nan,
                "coordination_mean": float(valid["coordination_bank_mean"].mean()) if len(valid) else math.nan,
                "positive_handoff_mean": float(valid["handoff_bank_mean"].mean()) if len(valid) else math.nan,
                "activation_weighted_density_mean": float(valid["density_bank_mean"].mean()) if len(valid) else math.nan,
                "low_low_fraction": float((valid["micro_state"] == "LOW_LOW").mean()) if len(valid) else math.nan,
                "high_high_fraction": float((valid["micro_state"] == "HIGH_HIGH").mean()) if len(valid) else math.nan,
            }
        )
    return pd.DataFrame(rows)


def _artifact_matched_difference(frame: pd.DataFrame, first: str, second: str, metric: str) -> float:
    data = frame[frame["condition"].isin([first, second])][["condition", "artifact_z_max", metric]].dropna()
    if data.empty or data["condition"].nunique() < 2:
        return math.nan
    try:
        data["bin"] = pd.qcut(data["artifact_z_max"], q=5, duplicates="drop")
    except Exception:
        data["bin"] = 0
    differences, weights = [], []
    for _, group in data.groupby("bin", observed=True):
        a = group[group["condition"] == first][metric]
        b = group[group["condition"] == second][metric]
        common = min(len(a), len(b))
        if common > 0:
            differences.append(float(a.mean() - b.mean()))
            weights.append(common)
    return float(np.average(differences, weights=weights)) if weights else math.nan


def contrasts_with_uncertainty(frame: pd.DataFrame, summary: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    pairs = [("TARGET_1", "CONTROL_1"), ("TARGET_1", "PHASESCRAMBLED_1"), ("TARGET_1", "SHOTORDERSCRAMBLE_1"), ("TARGET_1", "CONTEXTUAL_OVERRIDE_1")]
    metrics = ["positive_handoff_mean", "activation_weighted_density_mean", "coordination_mean"]
    metric_columns = {
        "positive_handoff_mean": "handoff_bank_mean",
        "activation_weighted_density_mean": "density_bank_mean",
        "coordination_mean": "coordination_bank_mean",
    }
    rng = np.random.default_rng(int(config["uncertainty"]["bootstrap_seed"]))
    reps = int(config["uncertainty"]["bootstrap_replicates"])
    block_seconds = float(config["uncertainty"]["moving_block_seconds"])
    rows = []
    for first, second in pairs:
        a_summary = summary[summary["condition"] == first]
        b_summary = summary[summary["condition"] == second]
        if a_summary.empty or b_summary.empty:
            continue
        for metric in metrics:
            estimate = float(a_summary.iloc[0][metric] - b_summary.iloc[0][metric])
            column = metric_columns[metric]
            ga = frame[frame["condition"] == first]
            gb = frame[frame["condition"] == second]
            ba = _nonoverlap_block_means(ga[column].to_numpy(float), ga["time_lsl"].to_numpy(float), block_seconds)
            bb = _nonoverlap_block_means(gb[column].to_numpy(float), gb["time_lsl"].to_numpy(float), block_seconds)
            draws = []
            if len(ba) >= 2 and len(bb) >= 2:
                for _ in range(reps):
                    draws.append(float(np.mean(rng.choice(ba, len(ba), replace=True)) - np.mean(rng.choice(bb, len(bb), replace=True))))
            rows.append(
                {
                    "contrast": f"{first}_minus_{second}",
                    "first_condition": first,
                    "second_condition": second,
                    "metric": metric,
                    "estimate": estimate,
                    "block_bootstrap_ci_low": float(np.quantile(draws, 0.025)) if draws else math.nan,
                    "block_bootstrap_ci_high": float(np.quantile(draws, 0.975)) if draws else math.nan,
                    "bootstrap_replicates": len(draws),
                    "first_30s_blocks": int(len(ba)),
                    "second_30s_blocks": int(len(bb)),
                    "artifact_matched_estimate": _artifact_matched_difference(frame, first, second, column),
                }
            )
    return pd.DataFrame(rows)


def lag_diagnostic_summary(frame: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    rows = []
    for lag in config["construct"]["lag_bank_seconds"]:
        tag = f"{int(round(float(lag) * 1000)):04d}ms"
        for condition, group in frame.groupby("condition"):
            if condition == "UNASSIGNED":
                continue
            h = pd.to_numeric(group.get(f"handoff_{tag}"), errors="coerce")
            d = pd.to_numeric(group.get(f"density_{tag}"), errors="coerce")
            c = pd.to_numeric(group.get(f"coordination_{tag}"), errors="coerce")
            rows.append(
                {
                    "condition": condition,
                    "lag_seconds": float(lag),
                    "valid_rows": int(h.notna().sum()),
                    "positive_handoff_mean": float(h.mean()),
                    "activation_weighted_density_mean": float(d.mean()),
                    "coordination_mean": float(c.mean()),
                }
            )
    return pd.DataFrame(rows)


def _rank_remap(values: np.ndarray, reference: np.ndarray) -> np.ndarray:
    order = np.argsort(values)
    sorted_ref = np.sort(reference)
    out = np.empty_like(values)
    out[order] = sorted_ref
    return out


def _phase_randomize(values: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    x = np.asarray(values, dtype=float)
    finite = np.isfinite(x)
    if finite.sum() < 8:
        return x.copy()
    fill = x.copy()
    fill[~finite] = float(np.nanmedian(x[finite]))
    centered = fill - np.mean(fill)
    spectrum = np.fft.rfft(centered)
    phases = rng.uniform(0.0, 2.0 * np.pi, len(spectrum))
    phases[0] = 0.0
    if len(fill) % 2 == 0:
        phases[-1] = 0.0
    randomized = np.fft.irfft(np.abs(spectrum) * np.exp(1j * phases), n=len(fill))
    original_mean = float(np.mean(fill))
    original_std = float(np.std(fill))
    randomized_std = float(np.std(randomized))
    if randomized_std > 1e-12:
        randomized = (randomized - float(np.mean(randomized))) * (original_std / randomized_std) + original_mean
    else:
        randomized[:] = original_mean
    randomized = np.clip(randomized, 0.0, 1.0)
    randomized[~finite] = np.nan
    return randomized


def _aggregate_block_score(blocks: List[Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]], dt: float, config: Dict[str, Any]) -> Tuple[float, float]:
    h_values, d_values = [], []
    for F, S, Q, valid in blocks:
        scores = _score_block_arrays(F, S, Q, valid, dt, config)
        h_values.append(scores["handoff_bank_mean"])
        d_values.append(scores["density_bank_mean"])
    h = np.concatenate(h_values) if h_values else np.asarray([])
    d = np.concatenate(d_values) if d_values else np.asarray([])
    return (float(np.nanmean(h)) if np.isfinite(h).any() else math.nan, float(np.nanmean(d)) if np.isfinite(d).any() else math.nan)


def null_models(frame: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    target_step = float(config["nulls"].get("evaluation_step_seconds", 0.10))
    blocks = []
    for block_id, group in frame[frame["condition"].isin(STIMULUS_CONDITIONS)].groupby("block_id", sort=False):
        group = group.sort_values("time_lsl")
        if len(group) < 20:
            continue
        dt_raw = float(np.nanmedian(np.diff(group["time_lsl"])))
        stride = max(1, int(round(target_step / max(dt_raw, 0.001))))
        sample = group.iloc[::stride]
        blocks.append(
            (
                sample["fast_temporal_gamma"].to_numpy(float),
                sample["slow_theta_integration"].to_numpy(float),
                sample["quality_soft"].to_numpy(float),
                sample["valid"].to_numpy(bool),
            )
        )
    if not blocks:
        return pd.DataFrame([{"null_model": "UNAVAILABLE", "reason": "No analyzable stimulus blocks"}])
    observed_h, observed_d = _aggregate_block_score(blocks, target_step, config)
    rng = np.random.default_rng(int(config["nulls"]["seed"]))
    min_shift = max(1, int(round(float(config["nulls"]["minimum_circular_shift_seconds"]) / target_step)))
    shift_h, shift_d = [], []
    for _ in range(int(config["nulls"]["circular_shift_replicates"])):
        shifted = []
        for F, S, Q, valid in blocks:
            if len(S) <= 2 * min_shift + 2:
                offset = max(1, len(S) // 3)
            else:
                offset = int(rng.integers(min_shift, len(S) - min_shift))
            shifted.append((F, np.roll(S, offset), Q, valid & np.roll(valid, offset)))
        h, d = _aggregate_block_score(shifted, target_step, config)
        shift_h.append(h)
        shift_d.append(d)
    phase_h, phase_d = [], []
    for _ in range(int(config["nulls"]["phase_randomized_replicates"])):
        randomized = [(F, _phase_randomize(S, rng), Q, valid) for F, S, Q, valid in blocks]
        h, d = _aggregate_block_score(randomized, target_step, config)
        phase_h.append(h)
        phase_d.append(d)

    rows = []
    for model, h_values, d_values in (("CIRCULAR_SHIFT", shift_h, shift_d), ("PHASE_RANDOMIZED", phase_h, phase_d)):
        for metric, observed, draws in (("positive_handoff", observed_h, h_values), ("activation_weighted_density", observed_d, d_values)):
            finite = np.asarray(draws, dtype=float)
            finite = finite[np.isfinite(finite)]
            rows.append(
                {
                    "null_model": model,
                    "metric": metric,
                    "observed": observed,
                    "null_mean": float(np.mean(finite)) if len(finite) else math.nan,
                    "null_median": float(np.median(finite)) if len(finite) else math.nan,
                    "null_q025": float(np.quantile(finite, 0.025)) if len(finite) else math.nan,
                    "null_q975": float(np.quantile(finite, 0.975)) if len(finite) else math.nan,
                    "one_sided_p": float((1 + np.sum(finite >= observed)) / (len(finite) + 1)) if len(finite) and np.isfinite(observed) else math.nan,
                    "replicates": int(len(finite)),
                    "evaluation_step_seconds": target_step,
                }
            )
    return pd.DataFrame(rows)


def label_permutation_null(summary: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    branches = summary[summary["condition"].isin(STIMULUS_CONDITIONS)].copy()
    if branches["condition"].nunique() < 2:
        return pd.DataFrame([{"null_model": "BLOCK_LABEL_PERMUTATION", "status": "UNAVAILABLE"}])
    rng = np.random.default_rng(int(config["nulls"]["seed"]) + 1)
    reps = int(config["nulls"]["label_permutation_replicates"])
    rows = []
    for first, second in (("TARGET_1", "CONTROL_1"), ("TARGET_1", "CONTEXTUAL_OVERRIDE_1"), ("TARGET_1", "SHOTORDERSCRAMBLE_1")):
        if first not in branches["condition"].values or second not in branches["condition"].values:
            continue
        for metric in ("positive_handoff_mean", "activation_weighted_density_mean"):
            observed = float(branches.loc[branches["condition"] == first, metric].iloc[0] - branches.loc[branches["condition"] == second, metric].iloc[0])
            values = branches[metric].to_numpy(float)
            labels = branches["condition"].to_numpy(object)
            draws = []
            for _ in range(reps):
                permuted = rng.permutation(labels)
                a = values[permuted == first]
                b = values[permuted == second]
                if len(a) and len(b):
                    draws.append(float(np.mean(a) - np.mean(b)))
            draws_arr = np.asarray(draws)
            rows.append(
                {
                    "null_model": "BLOCK_LABEL_PERMUTATION",
                    "contrast": f"{first}_minus_{second}",
                    "metric": metric,
                    "observed": observed,
                    "two_sided_p": float((1 + np.sum(np.abs(draws_arr) >= abs(observed))) / (len(draws_arr) + 1)) if len(draws_arr) else math.nan,
                    "replicates": len(draws_arr),
                    "exchangeability_caution": "Condition order and stimulus identity are not exchangeable in these historical single-run blocks.",
                }
            )
    return pd.DataFrame(rows)


def _write_readiness_markdown(report: Dict[str, Any], path: Path) -> None:
    lines = ["# Micro Handoff v0.1 readiness", "", f"**Status:** {report['status']}", "", report["claim_boundary"], "", "This status concerns computation readiness only; it does not establish construct validity.", "", "## Checks", ""]
    if report["reasons"]:
        for item in report["reasons"]:
            lines.append(f"- **{item['level']} — {item['code']}:** {item['message']}")
    else:
        lines.append("- All frozen computation-readiness checks passed.")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_run_report(run_label: str, readiness: Dict[str, Any], summary: pd.DataFrame, contrasts: pd.DataFrame, nulls: pd.DataFrame, path: Path) -> None:
    lines = [
        f"# Micro Handoff v0.1 report — {run_label}",
        "",
        f"**Readiness:** {readiness['status']}",
        "",
        "Micro Handoff is an exploratory EEG temporal-gamma/theta coordination proxy. It is not a direct measurement of consciousness, proof of 40 Hz frames, or a clinical result.",
        "",
    ]
    if readiness["status"] == "INELIGIBLE":
        lines.extend(["## Disposition", "", "No branch-level Micro Handoff inference was produced because the frozen readiness gates failed.", ""])
    if not summary.empty:
        lines.extend(["## Branch summaries", "", "| Condition | Valid fraction | Fast | Slow | Coordination | Positive handoff | Activation-weighted density |", "|---|---:|---:|---:|---:|---:|---:|"])
        for row in summary.itertuples(index=False):
            lines.append(f"| {row.condition} | {row.valid_bank_fraction:.3f} | {row.fast_mean:.3f} | {row.slow_mean:.3f} | {row.coordination_mean:.3f} | {row.positive_handoff_mean:.3f} | {row.activation_weighted_density_mean:.3f} |")
        lines.append("")
    if not contrasts.empty:
        lines.extend(["## Prespecified contrasts", "", "Positive estimates mean the first condition exceeded the second. Intervals are within-run temporal block-bootstrap intervals, not population confidence intervals.", "", "| Contrast | Metric | Estimate | 95% block interval | Artifact-matched |", "|---|---|---:|---:|---:|"])
        for row in contrasts.itertuples(index=False):
            lines.append(f"| {row.contrast} | {row.metric} | {row.estimate:.4f} | [{row.block_bootstrap_ci_low:.4f}, {row.block_bootstrap_ci_high:.4f}] | {row.artifact_matched_estimate:.4f} |")
        lines.append("")
    if not nulls.empty and "metric" in nulls.columns:
        lines.extend(["## Time-structure nulls", "", "| Null | Metric | Observed | Null median | p (one-sided) |", "|---|---|---:|---:|---:|"])
        for row in nulls.itertuples(index=False):
            lines.append(f"| {row.null_model} | {row.metric} | {row.observed:.4f} | {row.null_median:.4f} | {row.one_sided_p:.4f} |")
        lines.append("")
    lines.extend(["## Interpretation boundary", "", "A positive result would show that this frozen signal-processing candidate exceeded its declared time-structure nulls in this recording. It would not establish that the score is consciousness density. A null or reversed result is retained without inventing a post-hoc state archetype.", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def analyze_single(
    source_path: Path,
    segments_path: Path,
    config_path: Path,
    out_dir: Path,
    run_label: str,
    pyxdf_path: Optional[Path] = None,
    source_kind: str = "xdf",
    skip_nulls: bool = False,
) -> Dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    config = load_json(config_path)
    eeg = load_eeg_npz(source_path) if source_kind.lower() == "npz" else load_eeg_xdf(source_path, pyxdf_path)
    segments = load_segments(segments_path)
    initial = readiness_report(eeg, segments, config)
    if initial["status"] == "INELIGIBLE":
        write_json(out_dir / "micro_handoff_readiness.json", json_safe(initial))
        _write_readiness_markdown(initial, out_dir / "MICRO_HANDOFF_READINESS.md")
        _write_run_report(run_label, initial, pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), out_dir / "MICRO_HANDOFF_REPORT.md")
        return {"status": "INELIGIBLE", "readiness": initial, "out_dir": out_dir}

    raw, metadata = extract_raw_features(eeg, segments, config)
    raw["pre_qc_valid"] = (
        raw["condition"].ne("UNASSIGNED")
        & ~raw["timestamp_gap_in_gamma_window"].astype(bool)
        & ~raw["timestamp_gap_in_theta_window"].astype(bool)
    )
    readiness = readiness_report(eeg, segments, config, raw, metadata)
    write_json(out_dir / "micro_handoff_readiness.json", json_safe(readiness))
    _write_readiness_markdown(readiness, out_dir / "MICRO_HANDOFF_READINESS.md")
    if readiness["status"] == "INELIGIBLE":
        raw.to_csv(out_dir / "micro_handoff_raw_features_diagnostic.csv", index=False)
        _write_run_report(run_label, readiness, pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), out_dir / "MICRO_HANDOFF_REPORT.md")
        return {"status": "INELIGIBLE", "readiness": readiness, "out_dir": out_dir}

    candidate, compute_meta = compute_candidate(raw, config)
    minimum_reference_rows = int(math.ceil(float(config["normalization"]["minimum_reference_seconds"]) / max(float(compute_meta.get("median_feature_step_seconds") or config["input"]["output_step_seconds"]), 0.001)))
    ref_n = int(candidate["condition"].eq(config["normalization"]["reference_condition"]).mul(candidate["valid"].astype(bool)).sum())
    if ref_n < minimum_reference_rows or not np.isfinite(candidate["fast_temporal_gamma"]).any() or not np.isfinite(candidate["slow_theta_integration"]).any():
        readiness["status"] = "INELIGIBLE"
        readiness["reasons"].append({"level": "INELIGIBLE", "code": "BASELINE_NORMALIZATION_FAILED", "message": f"Only {ref_n} valid Baseline 1 rows supported normalization; {minimum_reference_rows} are required, or Baseline MAD was unusable."})
        write_json(out_dir / "micro_handoff_readiness.json", json_safe(readiness))
        _write_readiness_markdown(readiness, out_dir / "MICRO_HANDOFF_READINESS.md")
        candidate.to_csv(out_dir / "micro_handoff_raw_features_diagnostic.csv", index=False)
        _write_run_report(run_label, readiness, pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), out_dir / "MICRO_HANDOFF_REPORT.md")
        return {"status": "INELIGIBLE", "readiness": readiness, "out_dir": out_dir}

    summary = summarize_branches(candidate, segments, config)
    failed_coverage = summary[
        summary["condition"].isin(STIMULUS_CONDITIONS)
        & (summary["valid_bank_fraction"] < float(config["qc"]["minimum_branch_coverage"]))
    ]
    if not failed_coverage.empty:
        readiness["status"] = "INELIGIBLE"
        for row in failed_coverage.itertuples(index=False):
            readiness["reasons"].append({"level": "INELIGIBLE", "code": "POST_ARTIFACT_BRANCH_COVERAGE", "message": f"{row.condition} complete-lag valid coverage is {row.valid_bank_fraction:.1%}, below {config['qc']['minimum_branch_coverage']:.0%}."})
        write_json(out_dir / "micro_handoff_readiness.json", json_safe(readiness))
        _write_readiness_markdown(readiness, out_dir / "MICRO_HANDOFF_READINESS.md")
        candidate.to_csv(out_dir / "micro_handoff_raw_features_diagnostic.csv", index=False)
        summary.to_csv(out_dir / "micro_handoff_branch_summary.csv", index=False)
        _write_run_report(run_label, readiness, summary, pd.DataFrame(), pd.DataFrame(), out_dir / "MICRO_HANDOFF_REPORT.md")
        return {"status": "INELIGIBLE", "readiness": readiness, "out_dir": out_dir, "summary": summary}
    contrasts = contrasts_with_uncertainty(candidate, summary, config)
    lag_summary = lag_diagnostic_summary(candidate, config)
    nulls = pd.DataFrame() if skip_nulls else null_models(candidate, config)
    label_null = label_permutation_null(summary, config)

    state_columns = ["time_lsl", "sample_index", "condition", "block_id", "fast_temporal_gamma", "slow_theta_integration", "artifact_z_max", "quality_soft", "valid", "fast_onset", "coordination_bank_mean", "handoff_bank_mean", "density_bank_mean", "display_coordination", "display_handoff", "display_density", "micro_state"]
    candidate[state_columns].to_csv(out_dir / "micro_handoff_features_25ms.csv", index=False)
    lag_columns = ["time_lsl", "condition", "block_id"] + [c for c in candidate.columns if c.startswith(("coordination_0", "handoff_0", "density_0", "theta_response_0"))]
    if bool(config["outputs"].get("write_full_lag_series", True)):
        candidate[lag_columns].to_csv(out_dir / "micro_handoff_lag_series.csv", index=False)
    raw_columns = ["time_lsl", "condition", "block_id", "temporal_gamma_log_power", "visual_gamma_log_power", "theta_integration_log_power", "jaw_hf_log_power", "global_p2p", "fp1_p2p", "z_temporal_gamma", "z_visual_gamma", "z_theta", "z_jaw_hf", "z_global_p2p", "z_fp1_p2p", "artifact_hard_fail"]
    candidate[raw_columns].to_csv(out_dir / "micro_handoff_feature_families.csv", index=False)
    summary.to_csv(out_dir / "micro_handoff_branch_summary.csv", index=False)
    contrasts.to_csv(out_dir / "micro_handoff_contrasts.csv", index=False)
    lag_summary.to_csv(out_dir / "micro_handoff_lag_summary.csv", index=False)
    nulls.to_csv(out_dir / "micro_handoff_time_structure_nulls.csv", index=False)
    label_null.to_csv(out_dir / "micro_handoff_block_label_nulls.csv", index=False)
    qc_report = {
        "schema": "PRAYCG_MicroHandoff_QC_v0_1",
        "run_label": run_label,
        "metadata": metadata,
        "compute": compute_meta,
        "rows": int(len(candidate)),
        "valid_rows": int(candidate["valid"].sum()),
        "complete_lag_bank_rows": int(candidate["complete_lag_bank"].sum()),
        "hard_artifact_rows": int(candidate["artifact_hard_fail"].sum()),
        "timestamp_gap_rows": int((candidate["timestamp_gap_in_gamma_window"] | candidate["timestamp_gap_in_theta_window"]).sum()),
        "claim_boundary": config["claim_boundary"],
    }
    write_json(out_dir / "micro_handoff_qc.json", json_safe(qc_report))
    _write_run_report(run_label, readiness, summary, contrasts, nulls, out_dir / "MICRO_HANDOFF_REPORT.md")

    manifest = {
        "schema": "PRAYCG_MicroHandoff_Manifest_v0_1",
        "generated_utc": utc_now(),
        "module": MODULE_NAME,
        "version": VERSION,
        "status": "EXPLORATORY_DEVELOPMENT_CANDIDATE",
        "run_label": run_label,
        "source": {"name": source_path.name, "sha256": sha256_file(source_path), "kind": eeg.source_kind},
        "segments": {"name": segments_path.name, "sha256": sha256_file(segments_path)},
        "config": {"name": config_path.name, "sha256": sha256_file(config_path)},
        "readiness": readiness["status"],
        "condition_blind_extraction": True,
        "outputs": {},
        "claim_boundary": config["claim_boundary"],
    }
    for path in sorted(out_dir.iterdir()):
        if path.is_file() and path.name != "micro_handoff_manifest.json":
            manifest["outputs"][path.name] = {"sha256": sha256_file(path), "size_bytes": path.stat().st_size}
    write_json(out_dir / "micro_handoff_manifest.json", json_safe(manifest))
    return {
        "status": readiness["status"],
        "readiness": readiness,
        "out_dir": out_dir,
        "summary": summary,
        "contrasts": contrasts,
        "nulls": nulls,
        "lag_summary": lag_summary,
        "manifest": manifest,
    }
