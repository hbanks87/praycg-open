#!/usr/bin/env python3
"""Generate deterministic raw-EEG fixtures for Micro Handoff v0.1."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


CHANNELS = 16
FS = 250.0


def colored_noise(rng: np.random.Generator, samples: int, channels: int) -> np.ndarray:
    white = rng.normal(0.0, 1.0, (samples, channels))
    output = np.empty_like(white)
    output[0] = white[0]
    for index in range(1, samples):
        output[index] = 0.94 * output[index - 1] + white[index]
    output /= np.std(output, axis=0, keepdims=True)
    return output


def burst_envelope(times: np.ndarray, centers: np.ndarray, width: float = 0.16) -> np.ndarray:
    envelope = np.zeros_like(times)
    for center in centers:
        envelope += np.exp(-0.5 * ((times - center) / width) ** 2)
    return envelope


def make_case(case: str, seed: int = 20260910) -> tuple[np.ndarray, np.ndarray, pd.DataFrame, dict]:
    rng = np.random.default_rng(seed)
    duration = 180.0
    samples = int(duration * FS)
    times = np.arange(samples, dtype=float) / FS + 1000.0
    eeg = 6.0 * colored_noise(rng, samples, CHANNELS)
    local_t = times - times[0]
    intervals = rng.uniform(2.0, 4.5, 30)
    centers = 63.0 + np.cumsum(intervals)
    centers = centers[centers < 116.0]
    lag = 0.5
    gamma_env = burst_envelope(local_t, centers, 0.13)
    theta_env = burst_envelope(local_t, centers + lag, 0.32)
    if case == "reverse_direction":
        theta_env = burst_envelope(local_t, centers - lag, 0.32)
    elif case == "independent":
        theta_env = burst_envelope(local_t, centers + rng.uniform(-1.4, 1.4, len(centers)), 0.32)
    elif case == "low_low":
        gamma_env *= 0.0
        theta_env *= 0.0
    elif case == "stationary_high_high":
        gamma_env = ((local_t >= 60.0) & (local_t < 170.0)).astype(float)
        theta_env = gamma_env.copy()
    phase_gamma = rng.uniform(0, 2 * np.pi, 2)
    phase_theta = rng.uniform(0, 2 * np.pi, 5)
    if case == "low_low":
        baseline_mask = (local_t >= 0.0) & (local_t < 60.0)
        gamma_env = 0.9 * baseline_mask.astype(float)
        theta_env = 0.9 * baseline_mask.astype(float)
    for position, channel in enumerate((9, 10)):
        eeg[:, channel] += 12.0 * gamma_env * np.sin(2 * np.pi * 38.0 * local_t + phase_gamma[position])
    for position, channel in enumerate((2, 7, 8, 9, 10)):
        eeg[:, channel] += 10.0 * theta_env * np.sin(2 * np.pi * 6.0 * local_t + phase_theta[position])
    artifact_interval = None
    if case == "artifact":
        artifact_interval = (80.0, 82.0)
        mask = (local_t >= artifact_interval[0]) & (local_t < artifact_interval[1])
        eeg[mask, 13:16] += 350.0 * np.sin(2 * np.pi * 50.0 * local_t[mask])[:, None]
        eeg[mask, :13] += rng.normal(0.0, 250.0, (int(mask.sum()), 13))
    if case == "gap":
        gap_index = int(110.0 * FS)
        times[gap_index:] += 0.75
    segments = pd.DataFrame(
        [
            {"segment": "BASELINE_1", "start": 1000.0, "end": 1060.0, "segment_type": "core"},
            {"segment": "TARGET_1", "start": 1060.0, "end": 1120.0, "segment_type": "core"},
            {"segment": "CONTROL_1", "start": 1120.0, "end": 1180.0 + (0.75 if case == "gap" else 0.0), "segment_type": "core"},
        ]
    )
    truth = {
        "case": case,
        "sample_rate_hz": FS,
        "known_forward_lag_seconds": lag if case in {"known_forward_lag", "artifact", "gap"} else None,
        "artifact_interval_local_seconds": artifact_interval,
        "claim_boundary": "Synthetic software behavior fixture; not biological validation.",
    }
    return times, eeg, segments, truth


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    cases = ["known_forward_lag", "low_low", "stationary_high_high", "reverse_direction", "independent", "artifact", "gap"]
    args.out.mkdir(parents=True, exist_ok=True)
    paired_seed_cases = {"known_forward_lag", "reverse_direction", "artifact", "gap"}
    for offset, case in enumerate(cases):
        folder = args.out / case
        folder.mkdir(parents=True, exist_ok=True)
        seed = 20260910 if case in paired_seed_cases else 20260910 + offset
        times, eeg, segments, truth = make_case(case, seed)
        np.savez_compressed(folder / "synthetic_raw_eeg.npz", timestamps=times, eeg=eeg, nominal_rate_hz=np.asarray([FS]))
        segments.to_csv(folder / "segments.csv", index=False)
        (folder / "truth.json").write_text(json.dumps(truth, indent=2), encoding="utf-8")
    print(json.dumps({"cases": cases, "out": str(args.out.resolve())}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
