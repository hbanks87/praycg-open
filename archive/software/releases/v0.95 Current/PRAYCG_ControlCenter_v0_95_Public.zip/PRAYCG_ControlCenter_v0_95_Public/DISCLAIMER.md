# PRAYCG Control Center Disclaimer

PRAYCG Control Center is exploratory research software. It is not a medical device, clinical tool, diagnostic system, or safety-critical acquisition controller.

The Control Center launches and organizes other tools. It does not certify EEG quality, biological meaning, consciousness, memory formation, neural mechanism, stimulus validity, or endpoint validity.

The Signal Quality / Contact Index is a practical data-quality proxy, not a true OpenBCI Cyton impedance measurement.

Human data collection requires informed consent and appropriate ethics review where applicable. Do not redistribute copyrighted media, credentials, participant identifiers, or private biosignal data.
