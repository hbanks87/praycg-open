# Her Run 1 - Exploratory Handoff K_HT Report


## Executive conclusion


There is no clean confirmatory K_HT conclusion from the frozen Her windows. One exploratory target-local event near 113.9 s after Target onset shows elevated local reciprocal coupling and positive theta carryover, but it is hypothesis-generating only.


## Phase-level K_HT


| segment               |   n_windows |   eta_Y_to_E_std |   zeta_E_to_Y_std |   K_HT_positive_loop |
|:----------------------|------------:|-----------------:|------------------:|---------------------:|
| CONTROL_1             |         245 |            0.023 |             0.043 |                0.032 |
| TARGET_1              |         247 |            0.069 |             0.412 |                0.168 |
| CONTEXTUAL_OVERRIDE_1 |         248 |            0.072 |             0.401 |                0.171 |


## Key exploratory local K_HT rows


| condition   |   peak_offset_sec |   peak_composite_z |   local_K_mag |   K_within_condition_percentile |   delta_theta_0_10_vs_pre |   delta_theta_10_30_vs_pre |   handoff_idx_comp_0_10 |   handoff_idx_comp_10_30 |   local_sign |
|:------------|------------------:|-------------------:|--------------:|--------------------------------:|--------------------------:|---------------------------:|------------------------:|-------------------------:|-------------:|
| control     |           16.0497 |           8.78981  |     0.101183  |                        0.185366 |                  0.748468 |                  2.84222   |                6.5789   |               24.9826    |           -1 |
| control     |           42.0497 |           7.93264  |     0.216671  |                        0.770732 |                  2.64529  |                 -7.63017   |               20.9841   |              -60.5274    |            1 |
| override    |          120.5    |           1.27131  |     0.0437501 |                        0.259615 |                  0.291609 |                  0.357546  |                0.370726 |                0.454553  |            1 |
| override    |          136.5    |           2.24874  |     0.0315786 |                        0.177885 |                  0.120501 |                 -0.443034  |                0.270975 |               -0.99627   |            1 |
| target      |          113.871  |           1.07247  |     0.40897   |                        0.966184 |                  0.700289 |                  0.889116  |                0.751041 |                0.953552  |            1 |
| target      |          130.871  |           1.15942  |     0.232613  |                        0.792271 |                 -0.419313 |                 -1.14988   |               -0.486159 |               -1.3332    |            1 |
| target      |          166.871  |           0.786341 |     0.144485  |                        0.68599  |                  0.489875 |                 -0.0151825 |                0.385209 |               -0.0119386 |            1 |


## Conclusion


The mathematically sound conclusion is candidate generation, not endpoint confirmation. Future runs should freeze the 113.9 s-like anchor or an independently annotated semantic window and require local K support plus state-locked theta carryover plus Target > Control/Override specificity.
