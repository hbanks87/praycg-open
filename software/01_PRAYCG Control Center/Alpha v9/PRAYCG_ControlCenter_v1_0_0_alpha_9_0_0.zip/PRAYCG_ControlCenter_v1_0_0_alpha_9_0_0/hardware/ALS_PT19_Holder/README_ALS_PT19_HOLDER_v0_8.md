# PRAYCG ALS/PT19 Holder Profile v0.8

This remains the v0.8 physical holder/profile component bundled with **PRAYCG Control Center v1.0.0-alpha.4**. The version is retained as component lineage; the current operator controls are consolidated in Hardware Acquisition / Forge.

This folder contains the OpenSCAD source for the 3D-printed ALS/PT19 holder and a matching PRAYCG holder-profile scaffold.

The holder is a physical-timing accessory. It helps the ALS/PT19 sensor view the runner-level barcode overlay while reducing room-light contamination. It does not measure biology.

## Use with Control Center

1. In **Hardware Acquisition / Forge → 2. Hardware Profile**, load a reviewed profile that includes EEG+ALS.
2. In **3. Connect & Launch**, click **Start New Equipment Session**, confirm that its active UUID appears, then click **Start BrainFlow EEG + ALS**.
3. Attach the holder to the intended study-display location.
4. In **4. Live Checks**, open **ALS Holder Calibration**. Move the white square until the live ALS channel responds strongly without clipping, then press `S` to save the profile.
5. Still in **4. Live Checks**, run the separate **ALS Barcode Placement Test**. This is the sole controlled screen-pulse/placement gate; preserve its run/profile-bound report and repeat it after moving the display, window, sensor, or holder.
6. In **5. Monitor, Record & Arm**, run **Run Required 30-Second Equipment Check**. Its progress window shows the diagnostic interval. The integrated EEG+ALS detail pass uses stream-health-only mode: it requires the current ALS stream but does not display or infer a barcode pulse.
7. Review all evidence, create the session lock, and explicitly arm. Calibration, the placement test, and profile preflight are separate evidence and none independently arms the runner.

## Practical rule

The runner overlay should align to the sensor aperture, not to the center of the flange. Always verify empirically using LSL/ALS readings.

Calibration or pulse visibility does not establish recovered timing accuracy, runner event registration, biological validity, or scientific endpoint validity. Those require their own recorded checks.
