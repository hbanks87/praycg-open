# Alpha 8.5.3 Runner and Ownership Recovery Report

## Incident reproduced from the live evidence

The Alpha 8.5.2 Bench Test session reached hardware lock and ARM, then launched the canonical PsychoPy Protocol Atlas runner. The Nieto Inner Speech Direction Adaptation protocol declared required `eog` and `emg` semantic roles. The reviewed bench hardware profile did not provide those roles, so the runner stopped with `Atlas hardware-role compatibility failed` even though the session was permanently nonparticipant.

The runner wrote a valid terminal lease record during exception cleanup. For a short interval the record existed while its exact PID/start identity was still alive, so global owner release correctly refused to run at that instant. The matching process later exited, but the owner remained. A new session lock was then confirmed in the same UUID directory, replacing the path referenced by the older owner and preventing ordinary identity-based reconciliation.

## Corrections

1. Atlas hardware-role compatibility remains mandatory for participant acquisition.
2. Missing live roles are bypassed only when the immutable lock and child environment agree on `BENCH_TEST`, `participant_data_eligible: false`, and `bench_readiness_bypass_active: true`.
3. The runner records the exact missing-role findings and bypass identity in its state, checkpoint, marker metadata, and authority event.
4. Once a terminal record exists and the exact runner PID/start identity is proven dead, a fresh historical heartbeat no longer prolongs authority.
5. Control Center cleanup retries are bounded and delayed rather than relying on one shutdown instant.
6. A run directory containing a one-use runner lease or ACQUIRE claim cannot receive a replacement runtime lock or a second runner launch.
7. Superseded-owner recovery requires all of the following: a valid LEASE_BOUND owner, dead exact controller identity, exact valid terminal lease, inactive runner identity, valid ACQUIRE and FINALIZE claims for the old lock identity, and a different valid pre-ACQUIRE replacement lock in the same UUID. Any uncertainty remains blocked.

## Safety boundary

Bench Mode does not claim that EOG, EMG, EEG, ALS, or another device passed. It creates permanently nonparticipant software-test evidence. Protocol selection, assets, reviewed hardware-definition integrity, lock identity, one-use authority, and child-environment identity remain enforced. No participant acquisition gate is bypassed.

## Validation

Focused regression tests reproduce the missing-role boundary and the superseded-lock owner state in temporary directories. The full release validator records the final suite counts, Python target, public-package scan, and checksum inventory in `BUILD_VALIDATION_v1_0_0_alpha_8_5_3.json`.
