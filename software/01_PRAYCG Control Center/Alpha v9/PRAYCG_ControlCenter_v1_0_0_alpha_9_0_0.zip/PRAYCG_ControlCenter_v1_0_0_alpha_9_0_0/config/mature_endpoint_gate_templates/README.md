# Mature Endpoint Gate Templates

One fail-closed gate-status template is supplied for each of the 17 mature runners. Populate evidence and status only after the run. Required gates left `NOT_ASSESSED` make the endpoint `NOT_EVALUABLE`.
