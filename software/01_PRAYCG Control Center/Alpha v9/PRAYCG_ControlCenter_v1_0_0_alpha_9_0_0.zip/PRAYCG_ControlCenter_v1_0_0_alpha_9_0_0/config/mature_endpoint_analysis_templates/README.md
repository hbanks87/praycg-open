# Mature Endpoint Analysis-Status Templates

One analysis-status template is supplied for each mature runner. These files record the result of a separately frozen analysis; they do not calculate physiology and cannot exceed the endpoint contract claim ceiling.
