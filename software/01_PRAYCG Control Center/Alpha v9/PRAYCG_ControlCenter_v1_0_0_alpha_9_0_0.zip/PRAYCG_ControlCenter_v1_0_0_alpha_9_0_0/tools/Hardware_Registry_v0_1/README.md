# PRAYCG Hardware Registry v0.1

The registry maps named device streams to canonical scientific roles. A hardware profile is lockable only after every selected module validates and a human reviewer is recorded. The 30-second preflight remains a separate operator action and never arms the runner automatically.

Hardware modules declare transport, LSL names, source identities, sampling behavior, role-specific checks, and trust level. Community modules begin as `COMMUNITY_UNVERIFIED`. Physical-device testing is required before any module can be promoted.
