#!/usr/bin/env python3
"""Validate PRAYCG hardware modules, build profiles, and run live preflights."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import math
import sys
import time
from pathlib import Path
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE_ROOT / "platform_core"))

from praycg_platform_core_v1_0_alpha_4 import (  # noqa: E402
    aggregate_hardware_preflight,
    build_hardware_profile,
    load_json,
    sha256_file,
    sha256_json,
    utc_now,
    validate_hardware_module,
    write_json,
)


def _safe_stream_value(info: Any, method: str, default: Any = None) -> Any:
    try:
        return getattr(info, method)()
    except Exception:
        return default


def stream_identity_findings(
    expected: dict[str, Any],
    observed_source_id: str,
    expected_run_uuid: str = "",
) -> tuple[list[str], list[str]]:
    """Check a resolved outlet against the identity policy in its module.

    Dynamic source identifiers cannot be predicted byte-for-byte for every
    device, but their declared prefix/suffix and the active run token can be
    checked.  An omitted run UUID is reported as a caution rather than silently
    treating a same-name outlet as run-bound.
    """
    errors: list[str] = []
    cautions: list[str] = []
    source_id = str(observed_source_id or "").strip()
    declared = str(expected.get("source_id") or "").strip()
    policy = str(expected.get("source_id_policy") or ("fixed" if declared else "unspecified")).strip().lower()
    prefix = str(expected.get("source_id_prefix") or "").strip()
    suffix = str(expected.get("source_id_suffix") or "").strip()
    examples = {str(value).strip() for value in expected.get("source_id_examples", []) if str(value).strip()}
    run_uuid = str(expected_run_uuid or "").strip()
    run_identity_fragment = run_uuid.replace("-", "")[:12]

    if not source_id:
        errors.append("resolved outlet has no source_id")
        return errors, cautions
    if policy == "fixed" and declared and source_id != declared:
        errors.append(f"source_id {source_id!r} does not match the declared fixed identity {declared!r}")
    elif policy == "dynamic_run_bound":
        if prefix and not source_id.startswith(prefix):
            errors.append(f"source_id {source_id!r} does not begin with declared prefix {prefix!r}")
        if suffix and not source_id.endswith(suffix):
            errors.append(f"source_id {source_id!r} does not end with declared suffix {suffix!r}")
        if run_identity_fragment:
            if run_identity_fragment not in source_id.replace("-", ""):
                errors.append("source_id is not bound to the expected run UUID")
        else:
            cautions.append("no expected run UUID was supplied, so dynamic run binding was not verified")
    elif policy == "connection_specific" and examples and source_id not in examples:
        errors.append(f"source_id {source_id!r} is not one of the declared connection-specific identities")
    elif declared and source_id != declared:
        errors.append(f"source_id {source_id!r} does not match declared identity {declared!r}")
    elif policy == "unspecified":
        cautions.append("the hardware definition has no enforceable source_id policy")
    return errors, cautions


def _declared_check_coverage(
    module: dict[str, Any],
    stream_results: list[dict[str, Any]],
) -> tuple[list[str], list[str]]:
    declared = {str(value) for value in module.get("preflight", {}).get("checks", []) if str(value)}
    performed: set[str] = set()
    if any("timestamp_monotonic" in row for row in stream_results):
        performed.update({"timestamp_monotonicity", "gaps"})
    roles = {str(row.get("canonical_role") or "") for row in stream_results}
    if any("effective_sample_rate_hz" in row and float(row.get("nominal_srate") or 0) > 0 for row in stream_results):
        performed.add("effective_sample_rate")
    if any(row.get("numeric_sample_count", 0) for row in stream_results):
        performed.update({"flat_channels", "flat_signal"})
    if "rr_intervals" in roles:
        performed.add("event_coverage")
        if any(row.get("canonical_role") == "rr_intervals" and row.get("numeric_sample_count", 0) for row in stream_results):
            performed.update({"plausible_rr_range", "duplicate_beats"})
    if "respiration" in roles and any(
        row.get("canonical_role") == "respiration" and row.get("numeric_sample_count", 0)
        for row in stream_results
    ):
        performed.add("respiratory_variation")
    return sorted(declared & performed), sorted(declared - performed)


def live_preflight(
    module: dict[str, Any],
    duration: float,
    *,
    module_file_sha256: str | None = None,
    expected_run_uuid: str = "",
) -> dict[str, Any]:
    """Sample every declared stream in one hardware module.

    Missing streams, empty streams, or timestamp regressions are ineligible.
    Rate, channel-count, or flat-signal concerns are cautions.  This transport
    check does not claim to implement device-specific signal physiology tests.
    """
    result: dict[str, Any] = {
        "schema": "PRAYCG_HardwareModulePreflight_v1_0_alpha_2",
        "platform_version": "1.0.0-alpha.4",
        "generated_utc": utc_now(),
        "module_id": module.get("module_id"),
        "module_file_sha256": module_file_sha256,
        "module_canonical_sha256": sha256_json(module),
        "expected_run_uuid": str(expected_run_uuid or ""),
        "requested_duration_seconds": duration,
        "status": "INELIGIBLE",
        "streams": [],
        "errors": [],
        "cautions": [],
        "limitations": ["This preflight evaluates stream transport and simple signal health, not cortical origin or construct validity."],
    }
    try:
        from pylsl import StreamInlet, resolve_byprop  # type: ignore
    except Exception as exc:
        result["reason"] = f"pylsl unavailable: {type(exc).__name__}: {exc}"
        result["errors"].append("pylsl is unavailable; no live evidence was collected.")
        return result
    stream_results: list[dict[str, Any]] = []
    inlets: list[tuple[dict[str, Any], Any, dict[str, Any]]] = []
    for expected in module.get("streams", []):
        name = str(expected.get("lsl_name", ""))
        candidates = resolve_byprop("name", name, timeout=2.0)
        if not candidates:
            stream_results.append({"lsl_name": name, "status": "INELIGIBLE", "reason": "MISSING"})
            result["errors"].append(f"Expected LSL stream is missing: {name}.")
            continue
        candidate_ids = [str(_safe_stream_value(info, "source_id", "") or "") for info in candidates]
        if len(candidates) != 1:
            stream_results.append({
                "lsl_name": name,
                "status": "INELIGIBLE",
                "reason": "DUPLICATE_NAME",
                "candidate_count": len(candidates),
                "candidate_source_ids": candidate_ids,
            })
            result["errors"].append(
                f"Expected LSL stream name is ambiguous ({len(candidates)} outlets): {name}."
            )
            continue
        info = candidates[0]
        observed_source_id = candidate_ids[0]
        identity_errors, identity_cautions = stream_identity_findings(
            expected,
            observed_source_id,
            expected_run_uuid,
        )
        metadata = {
            "observed_source_id": observed_source_id,
            "observed_type": str(_safe_stream_value(info, "type", "") or ""),
            "observed_nominal_srate": float(_safe_stream_value(info, "nominal_srate", 0.0) or 0.0),
            "resolved_candidate_count": 1,
            "identity_errors": identity_errors,
            "identity_cautions": identity_cautions,
        }
        if identity_errors:
            stream_results.append({
                "lsl_name": name,
                "canonical_role": expected.get("canonical_role"),
                "status": "INELIGIBLE",
                "reason": "SOURCE_IDENTITY_MISMATCH",
                **metadata,
            })
            result["errors"].extend(f"{name}: {item}." for item in identity_errors)
            continue
        result["cautions"].extend(f"{name}: {item}." for item in identity_cautions)
        inlet = StreamInlet(info, max_buflen=max(30, int(duration) + 5), recover=True)
        try:
            open_stream = getattr(inlet, "open_stream", None)
            if callable(open_stream):
                open_stream(timeout=2.0)
        except Exception as exc:
            stream_results.append({
                "lsl_name": name,
                "canonical_role": expected.get("canonical_role"),
                "status": "INELIGIBLE",
                "reason": "STREAM_CONNECTION_FAILED",
                "connection_error": f"{type(exc).__name__}: {exc}",
                **metadata,
            })
            result["errors"].append(f"Expected LSL stream could not be opened: {name}.")
            continue
        inlets.append((expected, inlet, metadata))
    samples: dict[str, list[tuple[float, list[float], int]]] = {str(x.get("lsl_name")): [] for x, _, _ in inlets}
    deadline = time.monotonic() + max(1.0, duration)
    while time.monotonic() < deadline:
        got = False
        for expected, inlet, _metadata in inlets:
            sample, timestamp = inlet.pull_sample(timeout=0.0)
            if sample is not None:
                got = True
                numeric: list[float] = []
                for value in sample:
                    try:
                        numeric.append(float(value))
                    except (TypeError, ValueError):
                        pass
                samples[str(expected.get("lsl_name"))].append((float(timestamp), numeric, len(sample)))
        if not got:
            time.sleep(0.005)
    for _expected, inlet, _metadata in inlets:
        try:
            inlet.close_stream()
        except Exception:
            pass
    for expected, _inlet, metadata in inlets:
        name = str(expected.get("lsl_name"))
        rows = samples[name]
        timestamps = [row[0] for row in rows]
        deltas = [b - a for a, b in zip(timestamps, timestamps[1:])]
        duplicate_timestamp_count = sum(1 for delta in deltas if delta == 0)
        observed_duration = max(timestamps) - min(timestamps) if len(timestamps) > 1 else 0.0
        effective_rate = (len(timestamps) - 1) / observed_duration if observed_duration > 0 else 0.0
        nominal = float(expected.get("nominal_srate", 0) or 0)
        monotonic = all(delta > 0 for delta in deltas)
        rate_ok = nominal == 0 or (0.8 * nominal <= effective_rate <= 1.2 * nominal)
        values = [v for _t, row, _count in rows for v in row if math.isfinite(v)]
        numeric_rows = [row for _t, row, _count in rows if row]
        maximum_numeric_channels = max((len(row) for row in numeric_rows), default=0)
        flat_channels = []
        for channel_index in range(maximum_numeric_channels):
            channel = [row[channel_index] for row in numeric_rows if len(row) > channel_index and math.isfinite(row[channel_index])]
            if channel and max(channel) == min(channel):
                flat_channels.append(channel_index + 1)
        flat = bool(numeric_rows) and maximum_numeric_channels > 0 and len(flat_channels) == maximum_numeric_channels
        expected_channels = int(expected.get("channel_count", 0) or 0)
        observed_channel_counts = sorted({count for _t, _row, count in rows})
        channel_count_ok = bool(rows) and (expected_channels <= 0 or observed_channel_counts == [expected_channels])
        gap_threshold = max(0.1, 5.0 / nominal) if nominal > 0 else None
        max_gap = max((delta for delta in deltas if delta > 0), default=None)
        large_gap_count = sum(1 for delta in deltas if gap_threshold is not None and delta > gap_threshold)
        identity_cautions = list(metadata.get("identity_cautions") or [])
        if not rows or not monotonic:
            status = "INELIGIBLE"
            result["errors"].append(f"{name} has no usable monotonic samples.")
        elif not rate_ok or flat_channels or not channel_count_ok or large_gap_count or identity_cautions:
            status = "CAUTION"
            if not rate_ok:
                result["cautions"].append(f"{name} effective sample rate is outside ±20% of nominal.")
            if flat_channels:
                result["cautions"].append(
                    f"{name} has flat numeric channel(s): {', '.join(map(str, flat_channels))}."
                )
            if not channel_count_ok:
                result["cautions"].append(f"{name} channel count differs from the selected module definition.")
            if large_gap_count:
                result["cautions"].append(f"{name} has {large_gap_count} gap(s) larger than {gap_threshold:.6g} seconds.")
        else:
            status = "PASS"
        role = str(expected.get("canonical_role") or "")
        physiological_range_ok = None
        if role == "rr_intervals" and values:
            units = str(expected.get("units") or "").lower()
            rr_ms = [value * 1000.0 if units.startswith("second") else value for value in values]
            plausible = [300.0 <= value <= 2000.0 for value in rr_ms]
            physiological_range_ok = bool(plausible) and all(plausible)
            if not physiological_range_ok:
                status = "CAUTION" if status == "PASS" else status
                result["cautions"].append(f"{name} contains RR values outside the declared 300–2000 ms transport preflight range.")
            minimum_span = min(max(1.0, duration * 0.5), max(1.0, duration - 1.0))
            if len(rows) < 2 or observed_duration < minimum_span:
                status = "CAUTION" if status == "PASS" else status
                result["cautions"].append(f"{name} has weak event coverage for the requested observation interval.")
        if role == "respiration" and flat:
            physiological_range_ok = False
        stream_results.append({
            "lsl_name": name,
            "canonical_role": role,
            "nominal_srate": nominal,
            "sample_count": len(rows),
            "numeric_sample_count": len(numeric_rows),
            "observed_duration_seconds": observed_duration,
            "effective_sample_rate_hz": effective_rate,
            "timestamp_monotonic": monotonic,
            "duplicate_timestamp_count": duplicate_timestamp_count,
            "flat_across_all_numeric_values": flat,
            "flat_channel_indices_1based": flat_channels,
            "max_gap_seconds": max_gap,
            "large_gap_threshold_seconds": gap_threshold,
            "large_gap_count": large_gap_count,
            "observed_channel_counts": observed_channel_counts,
            "expected_channel_count": expected_channels,
            "channel_count_ok": channel_count_ok,
            "physiological_range_ok_when_checked": physiological_range_ok,
            **metadata,
            "status": status,
        })
    result["streams"] = stream_results
    statuses = {item.get("status") for item in stream_results}
    result["status"] = (
        "INELIGIBLE" if not stream_results or "INELIGIBLE" in statuses
        else "CAUTION" if "CAUTION" in statuses
        else "PASS"
    )
    performed, unperformed = _declared_check_coverage(module, stream_results)
    result["performed_declared_checks"] = performed
    result["unperformed_declared_checks"] = unperformed
    if unperformed:
        result["cautions"].append(
            "Declared device-specific checks were not performed by the generic profile preflight: "
            + ", ".join(unperformed)
            + "."
        )
        if result["status"] == "PASS":
            result["status"] = "CAUTION"
    return result


def profile_preflight(
    profile: dict[str, Any],
    duration: float,
    *,
    expected_run_uuid: str = "",
) -> dict[str, Any]:
    """Run one concurrent interval and aggregate every selected module.

    The requested duration applies to the profile as a whole.  It is not
    multiplied by the number of selected devices.
    """
    reports: list[dict[str, Any]] = []
    valid_modules: list[tuple[dict[str, Any], str]] = []
    for selected in profile.get("modules", []):
        path = Path(str(selected.get("path", "")))
        if not path.is_file():
            reports.append({
                "schema": "PRAYCG_HardwareModulePreflight_v1_0_alpha_2",
                "platform_version": "1.0.0-alpha.4",
                "module_id": selected.get("module_id"),
                "expected_run_uuid": str(expected_run_uuid or ""),
                "module_file_sha256": None,
                "module_canonical_sha256": None,
                "status": "INELIGIBLE",
                "streams": [],
                "errors": ["Selected module definition path is missing."],
                "cautions": [],
            })
            continue
        observed_file_hash = sha256_file(path)
        expected_file_hash = selected.get("module_file_sha256") or selected.get("sha256")
        if observed_file_hash != expected_file_hash:
            reports.append({
                "schema": "PRAYCG_HardwareModulePreflight_v1_0_alpha_2",
                "platform_version": "1.0.0-alpha.4",
                "module_id": selected.get("module_id"),
                "expected_run_uuid": str(expected_run_uuid or ""),
                "module_file_sha256": observed_file_hash,
                "module_canonical_sha256": sha256_json(load_json(path)),
                "status": "INELIGIBLE",
                "streams": [],
                "errors": ["Module definition changed after the hardware profile was approved."],
                "cautions": [],
            })
            continue
        valid_modules.append((load_json(path), observed_file_hash))
    if valid_modules:
        with ThreadPoolExecutor(max_workers=min(8, len(valid_modules))) as executor:
            futures = {
                executor.submit(
                    live_preflight,
                    module,
                    duration,
                    module_file_sha256=file_hash,
                    expected_run_uuid=expected_run_uuid,
                ): module.get("module_id")
                for module, file_hash in valid_modules
            }
            for future in as_completed(futures):
                module_id = futures[future]
                try:
                    reports.append(future.result())
                except Exception as exc:
                    reports.append({
                        "schema": "PRAYCG_HardwareModulePreflight_v1_0_alpha_2",
                        "platform_version": "1.0.0-alpha.4",
                        "module_id": module_id,
                        "expected_run_uuid": str(expected_run_uuid or ""),
                        "module_file_sha256": None,
                        "module_canonical_sha256": None,
                        "status": "INELIGIBLE",
                        "streams": [],
                        "errors": [f"Live preflight failed: {type(exc).__name__}: {exc}"],
                        "cautions": [],
                    })
    return aggregate_hardware_preflight(profile, reports, expected_run_uuid=expected_run_uuid)


def main() -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Hardware Registry v0.1")
    parser.add_argument("action", choices=("list", "validate", "build-profile", "preflight"))
    parser.add_argument("--registry", type=Path, default=PACKAGE_ROOT / "config" / "hardware")
    parser.add_argument("--module", type=Path, action="append")
    parser.add_argument("--profile", type=Path, help="Reviewed hardware profile; required for the full alpha.4 preflight.")
    parser.add_argument("--profile-id", default="praycg_hardware")
    parser.add_argument("--reviewed-by", default="UNRECORDED")
    parser.add_argument("--duration", type=float, default=30.0)
    parser.add_argument("--run-uuid", default="", help="Expected active run UUID used to verify dynamic LSL source identities.")
    parser.add_argument("--out", type=Path, default=Path.cwd() / "hardware_profile.json")
    args = parser.parse_args()
    if args.action == "list":
        print(json.dumps([str(p) for p in sorted(args.registry.glob("*.json"))], indent=2))
        return 0
    if args.action == "preflight" and args.profile:
        result = profile_preflight(load_json(args.profile), args.duration, expected_run_uuid=args.run_uuid)
        write_json(args.out, result)
        print(json.dumps(result, indent=2))
        return 0 if result["status"] == "PASS" else (3 if result["status"] == "CAUTION" else 4)
    if not args.module:
        parser.error("--module is required")
    if args.action == "validate":
        reports = [validate_hardware_module(load_json(path)).as_dict() for path in args.module]
        print(json.dumps(reports, indent=2))
        return 0 if all(x["status"] != "INELIGIBLE" for x in reports) else 2
    if args.action == "build-profile":
        profile = build_hardware_profile(args.module, args.out, profile_id=args.profile_id, reviewed_by=args.reviewed_by)
        print(json.dumps(profile, indent=2))
        return 0 if profile["status"] == "APPROVED" else 3
    if len(args.module) != 1:
        parser.error("preflight accepts exactly one --module")
    module_path = args.module[0]
    result = live_preflight(
        load_json(module_path),
        args.duration,
        module_file_sha256=sha256_file(module_path),
        expected_run_uuid=args.run_uuid,
    )
    write_json(args.out, result)
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else (3 if result["status"] == "CAUTION" else 4)


if __name__ == "__main__":
    raise SystemExit(main())
