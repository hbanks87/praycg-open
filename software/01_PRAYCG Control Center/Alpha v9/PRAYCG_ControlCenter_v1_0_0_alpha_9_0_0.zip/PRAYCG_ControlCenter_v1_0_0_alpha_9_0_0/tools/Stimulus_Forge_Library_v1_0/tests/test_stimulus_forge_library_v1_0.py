from __future__ import annotations

import copy
import json
import shutil
import sys
from pathlib import Path

import pytest


TOOL_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = TOOL_ROOT.parents[1]
ATLAS_ROOT = PACKAGE_ROOT / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0"
sys.path.insert(0, str(TOOL_ROOT))
sys.path.insert(0, str(ATLAS_ROOT / "scripts"))

from praycg_stimulus_common_v1_0 import (  # noqa: E402
    DEMO_BOUNDARY,
    StimulusContractError,
    catalog_pack_by_id,
    catalog_pack_root,
    install_pack,
    load_catalog,
    manifest_content_sha256,
    read_json,
    resolve_bindings,
    scan_installed_packs,
    validate_pack,
    write_registry,
    write_json,
)
from praycg_stimulus_forge_v1_0 import ForgeRequest, run_engine  # noqa: E402
from praycg_protocol_atlas_core_v2_0 import discover_protocol_modules, normalize_asset_bindings  # noqa: E402


def _catalog() -> dict:
    return load_catalog(TOOL_ROOT)


def _pack(pack_id: str) -> Path:
    catalog = _catalog()
    return catalog_pack_root(catalog_pack_by_id(catalog, pack_id), TOOL_ROOT)


def _copy_pack(tmp_path: Path, pack_id: str, name: str = "copy") -> Path:
    destination = tmp_path / name
    shutil.copytree(_pack(pack_id), destination)
    return destination


def _rewrite_manifest(pack_root: Path, mutate) -> dict:
    path = pack_root / "stimulus_pack_manifest.json"
    manifest = read_json(path)
    mutate(manifest)
    manifest["manifest_content_sha256"] = manifest_content_sha256(manifest)
    write_json(path, manifest)
    return manifest


def test_frozen_demo_catalog_covers_the_original_alpha4_surface_exactly_once() -> None:
    catalog = _catalog()
    rows = catalog["protocols"]
    assert len(rows) == 14
    assert len({row["protocol_id"] for row in rows}) == 14
    assert all(len([item for item in row["sample_options"] if item["default"]]) == 1 for row in rows)
    native = {
        read_json(path)["protocol_id"]
        for path in (PACKAGE_ROOT / "tools" / "ProtocolRunner_ModuleLibrary_v1_0" / "protocols").glob("*.json")
        if "schema" not in path.name
    }
    atlas, errors = discover_protocol_modules(ATLAS_ROOT)
    assert errors == []
    atlas_ids = {record.protocol_id for record in atlas}
    catalog_ids = {row["protocol_id"] for row in rows}
    assert native.issubset(catalog_ids)
    assert catalog_ids - native <= atlas_ids
    assert len(catalog_ids - native) == 11
    mature_catalog = read_json(PACKAGE_ROOT / "config" / "praycg_mature_endpoint_atlas_catalog_v1_0.json")
    mature_ids = {row["protocol_id"] for row in mature_catalog["protocols"]}
    assert len(mature_ids) == 17
    assert mature_ids <= atlas_ids
    assert mature_ids.isdisjoint(catalog_ids)


def test_frozen_schema_and_catalog_hashes_match() -> None:
    import hashlib

    freeze = read_json(TOOL_ROOT / "config" / "stimulus_contract_freeze_v1_0.json")
    assert freeze["status"] == "FROZEN_FOR_V1_0_0_ALPHA_4"
    for row in freeze["artifacts"]:
        payload = (TOOL_ROOT / "config" / row["path"]).read_bytes()
        assert hashlib.sha256(payload).hexdigest() == row["sha256"]


def test_every_bundled_pack_is_demo_only_and_hash_valid() -> None:
    for entry in _catalog()["packs"]:
        pack_root = catalog_pack_root(entry, TOOL_ROOT)
        report = validate_pack(pack_root)
        manifest = read_json(pack_root / "stimulus_pack_manifest.json")
        assert report.status == "PASS", report.as_dict()
        assert manifest["scientific_status"] == "DEMO_ONLY"
        assert report.facts["collection_eligibility"] == DEMO_BOUNDARY
        assert manifest["distribution"]["license_id"] == "CC0-1.0"


def test_catalog_expected_keys_match_pack_bindings() -> None:
    catalog = _catalog()
    for protocol in catalog["protocols"]:
        sample = next(item for item in protocol["sample_options"] if item["default"])
        bindings = resolve_bindings(_pack(sample["pack_id"]), protocol["protocol_id"])
        assert set(protocol["expected_asset_keys"]).issubset(bindings)
        assert all(Path(value).exists() for value in bindings.values())


def test_original_atlas_demo_assets_pass_existing_runner_contract() -> None:
    atlas_records, discovery_errors = discover_protocol_modules(ATLAS_ROOT)
    assert discovery_errors == []
    catalog = _catalog()
    protocol_rows = {row["protocol_id"]: row for row in catalog["protocols"]}
    for record in atlas_records:
        if record.protocol_id not in protocol_rows:
            continue
        sample = next(item for item in protocol_rows[record.protocol_id]["sample_options"] if item["default"])
        all_bindings = resolve_bindings(_pack(sample["pack_id"]), record.protocol_id)
        declared = {item["key"] for item in record.module.get("assets", [])}
        selected = {key: value for key, value in all_bindings.items() if key in declared}
        normalized = normalize_asset_bindings(record, selected)
        assert set(normalized).issubset(declared)


def test_mature_atlas_assets_are_explicitly_runner_generated_or_operator_selected() -> None:
    atlas_records, discovery_errors = discover_protocol_modules(ATLAS_ROOT)
    assert discovery_errors == []
    by_id = {record.protocol_id: record for record in atlas_records}
    mature_catalog = read_json(PACKAGE_ROOT / "config" / "praycg_mature_endpoint_atlas_catalog_v1_0.json")
    for row in mature_catalog["protocols"]:
        record = by_id[row["protocol_id"]]
        for declared in record.module.get("assets", []):
            assert declared.get("source") == "operator_selection"
        # Empty asset lists are runner-generated tasks/rest; non-empty lists are reviewed external inputs.
        if not record.module.get("assets", []):
            assert record.module["engine"]["family"] in {"rest", "multi_session_composite"}


def test_target_and_override_are_one_bit_identical_asset() -> None:
    root = _pack("PRAYCG_NATIVE_STORY_DEMO_V1")
    for protocol_id in ("PRAYCG3", "PRAYCG4", "SMG"):
        bindings = resolve_bindings(root, protocol_id)
        assert bindings["target_video"] == bindings["override_video"]
        identity = read_json(root / "override_identity_manifest.json")
        assert identity["bit_identical"] is True
        assert identity["target_sha256"] == identity["override_sha256"]


def test_native_cue_schedule_matches_runner_loader_contract() -> None:
    root = _pack("PRAYCG_NATIVE_STORY_DEMO_V1")
    payload = read_json(root / "cue_schedule.json")
    assert payload["expected_sum"] == sum(row["value"] for row in payload["cue_events"])
    assert payload["cue_events"]
    for row in payload["cue_events"]:
        assert set(("cue_index", "value", "start_sec", "end_sec")).issubset(row)
        assert row["end_sec"] > row["start_sec"] >= 0
    for protocol_id in ("PRAYCG3", "PRAYCG4", "SMG"):
        assert resolve_bindings(root, protocol_id)["cue_schedule_json"].endswith("cue_schedule.json")


def test_tampered_payload_fails_closed(tmp_path: Path) -> None:
    root = _copy_pack(tmp_path, "PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1")
    target = root / "images" / "fixation.png"
    target.write_bytes(target.read_bytes() + b"tamper")
    report = validate_pack(root, media_probe=False)
    assert report.status == "FAIL"
    assert any("SHA-256 mismatch" in error or "Byte count mismatch" in error for error in report.errors)


def test_untracked_and_executable_files_fail_closed(tmp_path: Path) -> None:
    root = _copy_pack(tmp_path, "PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1")
    (root / "surprise.txt").write_text("not in ledger", encoding="utf-8")
    assert validate_pack(root, media_probe=False).status == "FAIL"
    (root / "surprise.txt").unlink()
    executable = root / "payload.py"
    executable.write_text("raise SystemExit", encoding="utf-8")
    manifest = read_json(root / "stimulus_pack_manifest.json")
    manifest["file_ledger"].append({"path": "payload.py", "sha256": __import__("hashlib").sha256(executable.read_bytes()).hexdigest(), "byte_count": executable.stat().st_size, "mime_type": "text/x-python"})
    manifest["manifest_content_sha256"] = manifest_content_sha256(manifest)
    write_json(root / "stimulus_pack_manifest.json", manifest)
    report = validate_pack(root, media_probe=False)
    assert report.status == "FAIL"
    assert any("data-only" in error for error in report.errors)


@pytest.mark.parametrize("unsafe", ["../escape.mp4", "C:/escape.mp4", "/escape.mp4", "folder/../escape.mp4"])
def test_unsafe_binding_paths_fail_closed(tmp_path: Path, unsafe: str) -> None:
    root = _copy_pack(tmp_path, "PRAYCG_NATIVE_STORY_DEMO_V1")
    _rewrite_manifest(root, lambda manifest: manifest["compatibility"][0]["bindings"].__setitem__("target_video", unsafe))
    report = validate_pack(root, media_probe=False)
    assert report.status == "FAIL"
    assert any("unsafe" in error.lower() or "forbidden" in error.lower() for error in report.errors)


def test_study_locked_requires_review_and_lock(tmp_path: Path) -> None:
    root = _copy_pack(tmp_path, "PRAYCG_NATIVE_STORY_DEMO_V1")
    _rewrite_manifest(root, lambda manifest: manifest.__setitem__("scientific_status", "STUDY_LOCKED"))
    report = validate_pack(root, media_probe=False)
    assert report.status == "FAIL"
    assert any("STUDY_LOCKED" in error for error in report.errors)


def test_pilot_candidate_requires_explicit_review(tmp_path: Path) -> None:
    root = _copy_pack(tmp_path, "PRAYCG_NATIVE_STORY_DEMO_V1")
    _rewrite_manifest(root, lambda manifest: manifest.__setitem__("scientific_status", "PILOT_CANDIDATE"))
    report = validate_pack(root, media_probe=False)
    assert report.status == "FAIL"
    assert any("PILOT_CANDIDATE" in error for error in report.errors)


def test_install_is_copy_on_use_and_never_overwrites(tmp_path: Path) -> None:
    source = _pack("PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1")
    installed, report = install_pack(source, tmp_path / "installed")
    assert report.status == "PASS"
    assert (installed / "installation_receipt.json").is_file()
    assert read_json(installed / "stimulus_pack_manifest.json")["scientific_status"] == "DEMO_ONLY"
    with pytest.raises(StimulusContractError):
        install_pack(source, tmp_path / "installed")


def test_registry_disables_duplicate_pack_id(tmp_path: Path) -> None:
    root = tmp_path / "installed"
    root.mkdir()
    shutil.copytree(_pack("PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1"), root / "first")
    shutil.copytree(_pack("PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1"), root / "second")
    registry = scan_installed_packs(root)
    assert registry["duplicate_pack_ids"] == ["PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1"]
    assert all(row["active_for_selection"] is False for row in registry["packs"])


def test_registry_refresh_preserves_legacy_stimuli_exactly(tmp_path: Path) -> None:
    install_root = tmp_path / "installed"
    install_root.mkdir()
    shutil.copytree(_pack("PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1"), install_root / "visuals")
    legacy_stimuli = [
        {"stimulus_id": "MASTER_A", "master_media": "C:/data/master-a.mp4", "operator_note": "preserve me"},
        {"stimulus_id": "MASTER_B", "custom_extension": {"future": True}},
    ]
    registry_path = tmp_path / "stimulus_registry.json"
    write_json(registry_path, {"schema": "PRAYCG_StimulusRegistry_v0_1", "stimuli": legacy_stimuli})
    refreshed = write_registry(install_root, registry_path)
    persisted = read_json(registry_path)
    assert refreshed["stimuli"] == legacy_stimuli
    assert persisted["stimuli"] == legacy_stimuli
    assert persisted["preserved_legacy_schema"] == "PRAYCG_StimulusRegistry_v0_1"
    assert len(persisted["packs"]) == 1


def test_registry_refresh_preserves_pack_ui_metadata(tmp_path: Path) -> None:
    install_root = tmp_path / "installed"
    install_root.mkdir()
    installed = install_root / "visuals"
    shutil.copytree(_pack("PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1"), installed)
    registry_path = tmp_path / "stimulus_registry.json"
    write_json(registry_path, {
        "schema": "PRAYCG_StimulusRegistry_v1_0",
        "stimuli": [],
        "packs": [{
            "pack_id": "PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1",
            "path": str(installed),
            "pinned": True,
            "last_selected_local": "2026-09-14T12:34:56",
            "installed_utc": "2026-09-14T12:00:00Z",
        }],
    })
    refreshed = write_registry(install_root, registry_path)
    row = refreshed["packs"][0]
    assert row["pinned"] is True
    assert row["last_selected_local"] == "2026-09-14T12:34:56"
    assert row["installed_utc"] == "2026-09-14T12:00:00Z"


def test_registry_refresh_refuses_malformed_legacy_registry(tmp_path: Path) -> None:
    install_root = tmp_path / "installed"
    install_root.mkdir()
    registry_path = tmp_path / "stimulus_registry.json"
    original = '{"schema":"PRAYCG_StimulusRegistry_v0_1","stimuli":{"bad":true}}\n'
    registry_path.write_text(original, encoding="utf-8")
    with pytest.raises(StimulusContractError, match="malformed stimuli"):
        write_registry(install_root, registry_path)
    assert registry_path.read_text(encoding="utf-8") == original


def test_allowlist_rejects_arbitrary_engine(tmp_path: Path) -> None:
    with pytest.raises(StimulusContractError):
        run_engine(ForgeRequest("downloaded.module:run", tmp_path / "output"))
    assert not (tmp_path / "output").exists()


def test_pipeline_stage_is_not_misrepresented_as_standalone(tmp_path: Path) -> None:
    with pytest.raises(StimulusContractError, match="typed stage"):
        run_engine(ForgeRequest("phase_scramble", tmp_path / "output"))
    assert not (tmp_path / "output").exists()


def test_fast_generated_pack_retains_demo_status(tmp_path: Path) -> None:
    result = run_engine(ForgeRequest("geometric_cue_cards", tmp_path / "generated", seed=19, pack_id="FORGE_VISUALS_DEMO_019"))
    assert result["validation"]["status"] == "PASS"
    manifest = read_json(tmp_path / "generated" / "stimulus_pack_manifest.json")
    assert manifest["scientific_status"] == "DEMO_ONLY"
    assert manifest["pack_id"] == "FORGE_VISUALS_DEMO_019"


def test_invalid_custom_pack_id_fails_before_writing(tmp_path: Path) -> None:
    with pytest.raises(StimulusContractError, match="Custom pack ID"):
        run_engine(ForgeRequest("geometric_cue_cards", tmp_path / "generated", pack_id="../bad"))
    assert not (tmp_path / "generated").exists()
