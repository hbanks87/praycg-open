#!/usr/bin/env python3
"""Core, non-UI services for the PRAYCG Stimulus Forge and Library.

This module intentionally loads no executable code from stimulus packs.  Packs are
data only.  Validation establishes file identity and contract conformance, not
scientific validity or equivalence between conditions.
"""

from __future__ import annotations

import copy
import hashlib
import json
import mimetypes
import os
import re
import shutil
import tempfile
import wave
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping


SCHEMA_ID = "PRAYCG_StimulusPack_v1_0"
CATALOG_ID = "PRAYCG_StimulusPackCatalog_v1_0"
ALLOWED_STATUSES = {"DEMO_ONLY", "PILOT_CANDIDATE", "STUDY_LOCKED"}
DEMO_BOUNDARY = "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION"
HEX64 = re.compile(r"^[0-9a-f]{64}$")
PACK_ID = re.compile(r"^[A-Z0-9][A-Z0-9_]{2,95}$")
WINDOWS_DRIVE = re.compile(r"^[A-Za-z]:")
WINDOWS_RESERVED = re.compile(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", re.IGNORECASE)
FORBIDDEN_EXECUTABLE_SUFFIXES = {
    ".bat", ".cmd", ".com", ".cpl", ".dll", ".exe", ".hta", ".jar", ".js",
    ".lnk", ".msi", ".ps1", ".py", ".pyc", ".pyd", ".scr", ".sh", ".vbs",
}


class StimulusContractError(RuntimeError):
    """Raised when an operation would violate a pack or installation contract."""


@dataclass
class ValidationReport:
    subject: str
    status: str = "PASS"
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    facts: dict[str, Any] = field(default_factory=dict)

    def error(self, message: str) -> None:
        self.errors.append(message)
        self.status = "FAIL"

    def warn(self, message: str) -> None:
        self.warnings.append(message)
        if self.status == "PASS":
            self.status = "CAUTION"

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema": "PRAYCG_StimulusValidationReport_v1_0",
            "subject": self.subject,
            "status": self.status,
            "errors": self.errors,
            "warnings": self.warnings,
            "facts": self.facts,
            "boundary": (
                "PASS means that the declared files and hashes satisfy this software contract. "
                "It is not evidence of construct validity, perceptual matching, participant safety, "
                "or suitability for scientific inference."
            ),
        }


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def manifest_content_sha256(manifest: Mapping[str, Any]) -> str:
    payload = copy.deepcopy(dict(manifest))
    payload.pop("manifest_content_sha256", None)
    return sha256_bytes(canonical_json_bytes(payload))


def normalize_relative_path(raw: str) -> str:
    if not isinstance(raw, str) or not raw.strip():
        raise StimulusContractError("A pack path must be a non-empty string.")
    candidate = raw.replace("\\", "/")
    if candidate.startswith("/") or WINDOWS_DRIVE.match(candidate):
        raise StimulusContractError(f"Absolute pack path is forbidden: {raw!r}")
    parts = candidate.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise StimulusContractError(f"Unsafe or non-canonical pack path: {raw!r}")
    if any(any(character in part for character in '<>:"|?*\0') for part in parts):
        raise StimulusContractError(f"Pack path contains a cross-platform forbidden character: {raw!r}")
    if any(part.endswith((" ", ".")) or WINDOWS_RESERVED.match(part) for part in parts):
        raise StimulusContractError(f"Pack path is not portable to Windows: {raw!r}")
    return "/".join(parts)


def contained_path(root: Path, relative: str) -> Path:
    rel = normalize_relative_path(relative)
    root_resolved = root.resolve()
    candidate = (root_resolved / Path(*rel.split("/"))).resolve()
    try:
        candidate.relative_to(root_resolved)
    except ValueError as exc:
        raise StimulusContractError(f"Pack path escapes its root: {relative!r}") from exc
    return candidate


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise StimulusContractError(f"Could not read valid JSON from {path}: {exc}") from exc


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def finalize_manifest(manifest: dict[str, Any], pack_root: Path) -> dict[str, Any]:
    """Rebuild the complete file ledger and content hash for a data-only pack."""
    root = pack_root.resolve()
    ledger: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.as_posix().lower()):
        if not path.is_file() or path.name == "stimulus_pack_manifest.json":
            continue
        if path.is_symlink():
            raise StimulusContractError(f"Pack may not contain a symlink: {path}")
        relative = path.relative_to(root).as_posix()
        ledger.append(
            {
                "path": relative,
                "sha256": sha256_file(path),
                "byte_count": path.stat().st_size,
                "mime_type": mimetypes.guess_type(path.name)[0] or "application/octet-stream",
            }
        )
    manifest["file_ledger"] = ledger
    manifest["manifest_content_sha256"] = manifest_content_sha256(manifest)
    write_json(root / "stimulus_pack_manifest.json", manifest)
    return manifest


def _manual_manifest_checks(manifest: Any, report: ValidationReport) -> None:
    if not isinstance(manifest, dict):
        report.error("Manifest root must be a JSON object.")
        return
    required = {
        "schema", "pack_id", "pack_version", "display_name", "scientific_status",
        "distribution", "generator", "compatibility", "asset_roles", "file_ledger",
        "claims_boundary", "manifest_content_sha256",
    }
    missing = sorted(required.difference(manifest))
    if missing:
        report.error(f"Missing required manifest fields: {', '.join(missing)}")
    allowed_top_level = required | {
        "description", "status_boundary", "review", "study_lock", "accessibility_and_safety"
    }
    unknown = sorted(set(manifest).difference(allowed_top_level))
    if unknown:
        report.error("Unknown top-level manifest fields are forbidden by the frozen schema: " + ", ".join(unknown))
    if manifest.get("schema") != SCHEMA_ID:
        report.error(f"schema must be exactly {SCHEMA_ID}.")
    pack_id = manifest.get("pack_id")
    if not isinstance(pack_id, str) or not PACK_ID.fullmatch(pack_id):
        report.error("pack_id must use 3-96 uppercase letters, digits, and underscores.")
    status = manifest.get("scientific_status")
    if status not in ALLOWED_STATUSES:
        report.error(f"scientific_status must be one of {sorted(ALLOWED_STATUSES)}.")
    if status == "DEMO_ONLY" and manifest.get("status_boundary") != DEMO_BOUNDARY:
        report.error(f"DEMO_ONLY requires status_boundary={DEMO_BOUNDARY}.")
    if status == "STUDY_LOCKED" and not isinstance(manifest.get("study_lock"), dict):
        report.error("STUDY_LOCKED requires both review and study_lock evidence.")
    if status == "STUDY_LOCKED" and not isinstance(manifest.get("review"), dict):
        report.error("STUDY_LOCKED requires an explicit review object.")
    if status == "PILOT_CANDIDATE" and not isinstance(manifest.get("review"), dict):
        report.error("PILOT_CANDIDATE requires an explicit review object.")
    review = manifest.get("review")
    if isinstance(review, dict):
        for key in ("reviewer", "reviewed_utc", "scope"):
            if not isinstance(review.get(key), str) or not review.get(key, "").strip():
                report.error(f"review.{key} must be a nonblank string.")
    distribution = manifest.get("distribution")
    if not isinstance(distribution, dict):
        report.error("distribution must be an object.")
    else:
        for key in ("bundled", "license_id", "source_material_bundled", "redistribution_reviewed"):
            if key not in distribution:
                report.error(f"distribution.{key} is required.")
        if distribution.get("bundled") and not distribution.get("redistribution_reviewed"):
            report.error("A bundled pack must have redistribution_reviewed=true.")
    generator = manifest.get("generator")
    if not isinstance(generator, dict):
        report.error("generator must be an object.")
    else:
        for key in ("engine_id", "engine_version", "seed", "deterministic_claim"):
            if key not in generator:
                report.error(f"generator.{key} is required.")
        if generator.get("upstream_model") and not generator.get("human_review_required"):
            report.error("A pack declaring an upstream model must require human review.")
    compatibility = manifest.get("compatibility")
    if not isinstance(compatibility, list) or not compatibility:
        report.error("compatibility must be a non-empty array.")
    else:
        seen_protocols: set[tuple[str, str]] = set()
        for index, item in enumerate(compatibility):
            if not isinstance(item, dict):
                report.error(f"compatibility[{index}] must be an object.")
                continue
            pair = (str(item.get("protocol_id", "")), str(item.get("protocol_version", "")))
            if pair in seen_protocols:
                report.error(f"Duplicate protocol compatibility row: {pair[0]} {pair[1]}.")
            seen_protocols.add(pair)
            bindings = item.get("bindings")
            if not isinstance(bindings, dict) or not bindings:
                report.error(f"compatibility[{index}].bindings must be a non-empty object.")
            else:
                for key, value in bindings.items():
                    try:
                        normalize_relative_path(value)
                    except StimulusContractError as exc:
                        report.error(f"Binding {key!r}: {exc}")
    claims = manifest.get("claims_boundary")
    if not isinstance(claims, list) or not claims or not all(isinstance(v, str) and len(v) >= 10 for v in claims):
        report.error("claims_boundary must contain at least one substantive string.")


def _validate_media_header(path: Path, report: ValidationReport) -> None:
    suffix = path.suffix.lower()
    try:
        if suffix == ".wav":
            with wave.open(str(path), "rb") as handle:
                report.facts.setdefault("audio_files", []).append(
                    {
                        "path": path.name,
                        "channels": handle.getnchannels(),
                        "sample_rate": handle.getframerate(),
                        "frames": handle.getnframes(),
                    }
                )
        elif suffix in {".png", ".jpg", ".jpeg", ".bmp"}:
            try:
                from PIL import Image

                with Image.open(path) as image:
                    image.verify()
            except ImportError:
                report.warn("Pillow is unavailable; image decoding was not checked.")
        elif suffix in {".mp4", ".mov", ".avi", ".mkv"}:
            try:
                import cv2

                capture = cv2.VideoCapture(str(path))
                if not capture.isOpened():
                    report.error(f"Video decoder could not open {path.name}.")
                else:
                    frames = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
                    fps = float(capture.get(cv2.CAP_PROP_FPS))
                    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
                    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
                    report.facts.setdefault("video_files", []).append(
                        {"path": path.name, "frames": frames, "fps": fps, "width": width, "height": height}
                    )
                    if frames <= 0 or fps <= 0 or width <= 0 or height <= 0:
                        report.error(f"Video metadata is invalid for {path.name}.")
                capture.release()
            except ImportError:
                report.warn("OpenCV is unavailable; video decoding was not checked.")
    except (OSError, wave.Error, ValueError) as exc:
        report.error(f"Media header check failed for {path.name}: {exc}")


def validate_pack(pack_root: Path, *, strict_extra_files: bool = True, media_probe: bool = True) -> ValidationReport:
    root = Path(pack_root).expanduser().resolve()
    report = ValidationReport(subject=str(root))
    manifest_path = root / "stimulus_pack_manifest.json"
    if not root.is_dir():
        report.error("Pack root does not exist or is not a directory.")
        return report
    if not manifest_path.is_file():
        report.error("stimulus_pack_manifest.json is missing.")
        return report
    try:
        manifest = read_json(manifest_path)
    except StimulusContractError as exc:
        report.error(str(exc))
        return report
    _manual_manifest_checks(manifest, report)
    if not isinstance(manifest, dict):
        return report
    expected_manifest_digest = manifest.get("manifest_content_sha256")
    actual_manifest_digest = manifest_content_sha256(manifest)
    if not isinstance(expected_manifest_digest, str) or not HEX64.fullmatch(expected_manifest_digest):
        report.error("manifest_content_sha256 must be a lowercase SHA-256 value.")
    elif expected_manifest_digest != actual_manifest_digest:
        report.error("Manifest content hash does not match its declared digest.")
    ledger = manifest.get("file_ledger")
    ledger_paths: set[str] = set()
    if not isinstance(ledger, list) or not ledger:
        report.error("file_ledger must be a non-empty array.")
        ledger = []
    for index, row in enumerate(ledger):
        if not isinstance(row, dict):
            report.error(f"file_ledger[{index}] must be an object.")
            continue
        try:
            relative = normalize_relative_path(row.get("path"))
            file_path = contained_path(root, relative)
        except (StimulusContractError, TypeError) as exc:
            report.error(f"file_ledger[{index}] has an unsafe path: {exc}")
            continue
        if relative in ledger_paths:
            report.error(f"Duplicate file-ledger path: {relative}")
            continue
        ledger_paths.add(relative)
        if not file_path.is_file():
            report.error(f"Declared file is missing: {relative}")
            continue
        if file_path.is_symlink():
            report.error(f"Symlinks are forbidden in stimulus packs: {relative}")
            continue
        if file_path.suffix.casefold() in FORBIDDEN_EXECUTABLE_SUFFIXES:
            report.error(f"Executable or script content is forbidden in a data-only stimulus pack: {relative}")
        expected_bytes = row.get("byte_count")
        expected_sha = row.get("sha256")
        actual_bytes = file_path.stat().st_size
        if not isinstance(expected_bytes, int) or expected_bytes != actual_bytes:
            report.error(f"Byte count mismatch: {relative}")
        if not isinstance(expected_sha, str) or not HEX64.fullmatch(expected_sha):
            report.error(f"Invalid SHA-256 declaration: {relative}")
        elif sha256_file(file_path) != expected_sha:
            report.error(f"SHA-256 mismatch: {relative}")
        if media_probe:
            _validate_media_header(file_path, report)
    actual_paths: set[str] = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            report.error(f"Symlinks are forbidden: {path.relative_to(root).as_posix()}")
        if path.is_file() and path.name not in {"stimulus_pack_manifest.json", "installation_receipt.json"}:
            actual_paths.add(path.relative_to(root).as_posix())
    extras = sorted(actual_paths.difference(ledger_paths))
    if extras and strict_extra_files:
        report.error("Files exist outside the locked ledger: " + ", ".join(extras))
    elif extras:
        report.warn("Untracked files were ignored: " + ", ".join(extras))
    missing_from_tree = sorted(ledger_paths.difference(actual_paths))
    if missing_from_tree:
        report.error("Ledger entries are absent from the tree: " + ", ".join(missing_from_tree))
    asset_roles = manifest.get("asset_roles")
    if not isinstance(asset_roles, list) or not asset_roles:
        report.error("asset_roles must be a non-empty array.")
    else:
        seen_assets: set[str] = set()
        for index, asset in enumerate(asset_roles):
            if not isinstance(asset, dict):
                report.error(f"asset_roles[{index}] must be an object.")
                continue
            asset_id = asset.get("asset_id")
            if not isinstance(asset_id, str) or not asset_id:
                report.error(f"asset_roles[{index}].asset_id is required.")
            elif asset_id in seen_assets:
                report.error(f"Duplicate asset_id: {asset_id}")
            else:
                seen_assets.add(asset_id)
            try:
                asset_path = contained_path(root, asset.get("path"))
                if not asset_path.exists():
                    report.error(f"Asset-role path does not exist: {asset.get('path')}")
            except (StimulusContractError, TypeError) as exc:
                report.error(f"Invalid asset-role path: {exc}")
    for item in manifest.get("compatibility", []) if isinstance(manifest.get("compatibility"), list) else []:
        if not isinstance(item, dict):
            continue
        for key, relative in (item.get("bindings") or {}).items():
            try:
                target = contained_path(root, relative)
                if not target.exists():
                    report.error(f"Binding {item.get('protocol_id')}.{key} points to a missing path: {relative}")
            except (StimulusContractError, TypeError) as exc:
                report.error(f"Binding {item.get('protocol_id')}.{key} is unsafe: {exc}")
    status = manifest.get("scientific_status")
    if status == "DEMO_ONLY":
        report.facts["collection_eligibility"] = DEMO_BOUNDARY
    elif status == "PILOT_CANDIDATE":
        report.warn("PILOT_CANDIDATE is not STUDY_LOCKED and must not enter a locked study without review and a new immutable manifest.")
        report.facts["collection_eligibility"] = "REVIEW_REQUIRED"
    elif status == "STUDY_LOCKED":
        report.facts["collection_eligibility"] = "LOCK_DECLARED_NOT_INDEPENDENTLY_VALIDATED_BY_THIS_CHECK"
    report.facts.update(
        {
            "pack_id": manifest.get("pack_id"),
            "pack_version": manifest.get("pack_version"),
            "scientific_status": status,
            "manifest_content_sha256": actual_manifest_digest,
            "files_checked": len(ledger_paths),
        }
    )
    return report


def load_catalog(tool_root: Path | None = None) -> dict[str, Any]:
    base = Path(tool_root or Path(__file__).resolve().parent)
    catalog = read_json(base / "config" / "stimulus_pack_catalog_v1_0.json")
    if not isinstance(catalog, dict) or catalog.get("schema") != CATALOG_ID:
        raise StimulusContractError(f"Invalid catalog schema in {base}.")
    return catalog


def package_root_from_tool(tool_root: Path | None = None) -> Path:
    base = Path(tool_root or Path(__file__).resolve().parent).resolve()
    try:
        return base.parents[1]
    except IndexError as exc:
        raise StimulusContractError("Could not resolve package root from Stimulus Library tool.") from exc


def catalog_pack_root(pack_entry: Mapping[str, Any], tool_root: Path | None = None) -> Path:
    package_root = package_root_from_tool(tool_root)
    relative = pack_entry.get("package_relative_root")
    return contained_path(package_root, relative)


def catalog_pack_by_id(catalog: Mapping[str, Any], pack_id: str) -> dict[str, Any]:
    matches = [row for row in catalog.get("packs", []) if isinstance(row, dict) and row.get("pack_id") == pack_id]
    if len(matches) != 1:
        raise StimulusContractError(f"Catalog pack_id must resolve exactly once: {pack_id!r}")
    return matches[0]


def protocol_rows(catalog: Mapping[str, Any], protocol_id: str | None = None) -> list[dict[str, Any]]:
    rows = [dict(row) for row in catalog.get("protocols", []) if isinstance(row, dict)]
    if protocol_id is None:
        return rows
    return [row for row in rows if row.get("protocol_id") == protocol_id]


def resolve_bindings(pack_root: Path, protocol_id: str) -> dict[str, str]:
    manifest = read_json(Path(pack_root) / "stimulus_pack_manifest.json")
    matches = [
        item for item in manifest.get("compatibility", [])
        if isinstance(item, dict) and item.get("protocol_id") == protocol_id
    ]
    if len(matches) != 1:
        raise StimulusContractError(
            f"Pack {manifest.get('pack_id')} does not contain exactly one compatibility row for {protocol_id}."
        )
    result: dict[str, str] = {}
    for key, relative in matches[0].get("bindings", {}).items():
        result[key] = str(contained_path(Path(pack_root), relative))
    return result


def install_pack(source_root: Path, destination_root: Path) -> tuple[Path, ValidationReport]:
    source = Path(source_root).expanduser().resolve()
    initial = validate_pack(source)
    if initial.status == "FAIL":
        raise StimulusContractError("Source pack failed validation: " + "; ".join(initial.errors))
    manifest = read_json(source / "stimulus_pack_manifest.json")
    destination_parent = Path(destination_root).expanduser().resolve()
    destination_parent.mkdir(parents=True, exist_ok=True)
    destination = destination_parent / str(manifest["pack_id"])
    if destination.exists():
        raise StimulusContractError(
            f"Installation destination already exists: {destination}. Delete or archive it explicitly, or choose a different root."
        )
    staging = Path(tempfile.mkdtemp(prefix=f".{manifest['pack_id']}.staging-", dir=str(destination_parent)))
    try:
        payload = staging / str(manifest["pack_id"])
        shutil.copytree(source, payload, symlinks=False)
        staged_report = validate_pack(payload)
        if staged_report.status == "FAIL":
            raise StimulusContractError("Copied pack failed validation: " + "; ".join(staged_report.errors))
        receipt = {
            "schema": "PRAYCG_StimulusPackInstallationReceipt_v1_0",
            "installed_utc": utc_now(),
            "pack_id": manifest["pack_id"],
            "pack_version": manifest["pack_version"],
            "source_manifest_content_sha256": manifest["manifest_content_sha256"],
            "scientific_status": manifest["scientific_status"],
            "collection_boundary": DEMO_BOUNDARY if manifest["scientific_status"] == "DEMO_ONLY" else "REVIEW_STATUS_UNCHANGED_BY_INSTALLATION",
            "destination": str(destination),
        }
        write_json(payload / "installation_receipt.json", receipt)
        os.replace(payload, destination)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    shutil.rmtree(staging, ignore_errors=True)
    final_report = validate_pack(destination)
    return destination, final_report


def build_binding_receipt(pack_root: Path, protocol_id: str, output_path: Path) -> dict[str, Any]:
    root = Path(pack_root).resolve()
    report = validate_pack(root)
    if report.status == "FAIL":
        raise StimulusContractError("Cannot bind an invalid pack: " + "; ".join(report.errors))
    manifest = read_json(root / "stimulus_pack_manifest.json")
    bindings = resolve_bindings(root, protocol_id)
    receipt = {
        "schema": "PRAYCG_ProtocolStimulusBindingDraft_v1_0",
        "created_utc": utc_now(),
        "protocol_id": protocol_id,
        "pack_id": manifest["pack_id"],
        "pack_version": manifest["pack_version"],
        "scientific_status": manifest["scientific_status"],
        "collection_boundary": DEMO_BOUNDARY if manifest["scientific_status"] == "DEMO_ONLY" else "REVIEW_REQUIRED_BEFORE_SESSION_LOCK",
        "manifest_content_sha256": manifest["manifest_content_sha256"],
        "bindings": bindings,
        "authority_boundary": "This is a draft convenience binding. It does not create, replace, or bypass the Control Center session lock.",
    }
    write_json(Path(output_path), receipt)
    return receipt


def iter_catalog_pack_reports(tool_root: Path | None = None, media_probe: bool = True) -> Iterable[tuple[dict[str, Any], ValidationReport]]:
    catalog = load_catalog(tool_root)
    for entry in catalog.get("packs", []):
        if not isinstance(entry, dict):
            continue
        yield entry, validate_pack(catalog_pack_root(entry, tool_root), media_probe=media_probe)


def scan_installed_packs(install_root: Path, *, media_probe: bool = False) -> dict[str, Any]:
    """Build a read-only inventory. Invalid packs remain visible but inactive."""
    root = Path(install_root).expanduser().resolve()
    rows: list[dict[str, Any]] = []
    if root.exists() and not root.is_dir():
        raise StimulusContractError(f"Stimulus install root is not a directory: {root}")
    if root.is_dir():
        for child in sorted(root.iterdir(), key=lambda item: item.name.lower()):
            if child.name.startswith(".") or not child.is_dir() or child.is_symlink():
                continue
            report = validate_pack(child, media_probe=media_probe)
            manifest: dict[str, Any] = {}
            try:
                manifest = read_json(child / "stimulus_pack_manifest.json")
            except StimulusContractError:
                pass
            receipt: dict[str, Any] = {}
            if (child / "installation_receipt.json").is_file():
                try:
                    candidate_receipt = read_json(child / "installation_receipt.json")
                    if isinstance(candidate_receipt, dict):
                        receipt = candidate_receipt
                except StimulusContractError:
                    pass
            rows.append(
                {
                    "pack_id": manifest.get("pack_id", child.name),
                    "pack_version": manifest.get("pack_version"),
                    "path": str(child),
                    "scientific_status": manifest.get("scientific_status"),
                    "manifest_content_sha256": manifest.get("manifest_content_sha256"),
                    "installed_utc": receipt.get("installed_utc"),
                    "validation_status": report.status,
                    "active_for_selection": report.status != "FAIL",
                    "errors": report.errors,
                    "warnings": report.warnings,
                }
            )
    duplicate_ids = sorted({row["pack_id"] for row in rows if sum(1 for other in rows if other["pack_id"] == row["pack_id"]) > 1})
    if duplicate_ids:
        for row in rows:
            if row["pack_id"] in duplicate_ids:
                row["active_for_selection"] = False
                row["errors"] = list(row["errors"]) + ["Duplicate pack_id in this registry; selection is ambiguous."]
    return {
        "schema": "PRAYCG_StimulusRegistry_v1_0",
        "generated_utc": utc_now(),
        "install_root": str(root),
        "packs": rows,
        "duplicate_pack_ids": duplicate_ids,
        "boundary": "Registry discovery does not promote scientific status and does not create session authority.",
    }


def write_registry(install_root: Path, registry_path: Path, *, media_probe: bool = False) -> dict[str, Any]:
    registry = scan_installed_packs(install_root, media_probe=media_probe)
    target = Path(registry_path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        existing = read_json(target)
        if not isinstance(existing, dict):
            raise StimulusContractError(
                f"Existing stimulus registry is not a JSON object; refusing to replace it: {target}"
            )
        legacy_stimuli = existing.get("stimuli", [])
        if not isinstance(legacy_stimuli, list):
            raise StimulusContractError(
                f"Existing stimulus registry has a malformed stimuli collection; refusing to replace it: {target}"
            )
        registry["stimuli"] = copy.deepcopy(legacy_stimuli)
        registry["preserved_legacy_schema"] = existing.get("schema")
        existing_packs = existing.get("packs", [])
        if not isinstance(existing_packs, list):
            raise StimulusContractError(
                f"Existing stimulus registry has a malformed packs collection; refusing to replace it: {target}"
            )
        prior = {
            (str(row.get("pack_id") or ""), str(Path(str(row.get("path") or "")).expanduser().resolve())): row
            for row in existing_packs
            if isinstance(row, dict) and row.get("pack_id") and row.get("path")
        }
        for row in registry["packs"]:
            old = prior.get((str(row.get("pack_id") or ""), str(Path(str(row.get("path") or "")).expanduser().resolve())))
            if old:
                row["pinned"] = bool(old.get("pinned"))
                if old.get("last_selected_local"):
                    row["last_selected_local"] = old["last_selected_local"]
                if not row.get("installed_utc") and old.get("installed_utc"):
                    row["installed_utc"] = old["installed_utc"]
    else:
        registry["stimuli"] = []
    handle, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(handle, "w", encoding="utf-8", newline="\n") as stream:
            json.dump(registry, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_name, target)
    except Exception:
        try:
            os.unlink(temporary_name)
        except OSError:
            pass
        raise
    return registry
