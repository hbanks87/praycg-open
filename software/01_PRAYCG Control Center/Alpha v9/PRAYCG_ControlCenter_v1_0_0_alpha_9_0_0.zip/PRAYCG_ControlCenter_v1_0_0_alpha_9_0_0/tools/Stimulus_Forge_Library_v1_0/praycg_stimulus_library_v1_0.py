#!/usr/bin/env python3
"""PRAYCG Stimulus Library v1.0: catalog, validate, copy-on-use install, bind."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from praycg_stimulus_common_v1_0 import (
    DEMO_BOUNDARY,
    StimulusContractError,
    build_binding_receipt,
    catalog_pack_by_id,
    catalog_pack_root,
    install_pack,
    iter_catalog_pack_reports,
    load_catalog,
    protocol_rows,
    read_json,
    scan_installed_packs,
    validate_pack,
    write_registry,
)


TOOL_ROOT = Path(__file__).resolve().parent


def _emit(value: Any, as_json: bool = False) -> None:
    if as_json:
        print(json.dumps(value, ensure_ascii=False, indent=2))
        return
    if isinstance(value, str):
        print(value)
        return
    print(json.dumps(value, ensure_ascii=False, indent=2))


def _cmd_list(args: argparse.Namespace) -> int:
    catalog = load_catalog(TOOL_ROOT)
    rows = protocol_rows(catalog, args.protocol)
    result = {
        "schema": catalog["schema"],
        "catalog_version": catalog["catalog_version"],
        "protocols": rows,
        "boundary": catalog["boundary"],
    }
    _emit(result, args.json)
    return 0 if rows else 2


def _resolve_source(args: argparse.Namespace) -> Path:
    if getattr(args, "path", None):
        return Path(args.path)
    catalog = load_catalog(TOOL_ROOT)
    entry = catalog_pack_by_id(catalog, args.pack)
    return catalog_pack_root(entry, TOOL_ROOT)


def _cmd_validate(args: argparse.Namespace) -> int:
    report = validate_pack(_resolve_source(args), media_probe=not args.skip_media_probe)
    _emit(report.as_dict(), True)
    return 0 if report.status != "FAIL" else 2


def _cmd_audit(args: argparse.Namespace) -> int:
    catalog = load_catalog(TOOL_ROOT)
    reports = []
    failed = False
    manifest_by_pack: dict[str, dict[str, Any]] = {}
    known_packs = {row.get("pack_id") for row in catalog.get("packs", []) if isinstance(row, dict)}
    protocol_ids = {row.get("protocol_id") for row in catalog.get("protocols", []) if isinstance(row, dict)}
    for entry, report in iter_catalog_pack_reports(TOOL_ROOT, media_probe=not args.skip_media_probe):
        failed = failed or report.status == "FAIL"
        try:
            manifest = read_json(catalog_pack_root(entry, TOOL_ROOT) / "stimulus_pack_manifest.json")
            manifest_by_pack[str(entry.get("pack_id"))] = manifest
            if manifest.get("pack_id") != entry.get("pack_id"):
                mapping_errors = [f"Catalog/manifest pack_id mismatch for {entry.get('pack_id')}."]
            else:
                mapping_errors = []
            if manifest.get("scientific_status") != entry.get("scientific_status"):
                mapping_errors.append(f"Catalog/manifest scientific_status mismatch for {entry.get('pack_id')}.")
        except StimulusContractError as exc:
            mapping_errors = [str(exc)]
        reports.append({"catalog_entry": entry, "validation": report.as_dict()})
        if mapping_errors:
            reports[-1]["mapping_errors"] = mapping_errors
    mapping_errors = [error for row in reports for error in row.get("mapping_errors", [])]
    package_root = TOOL_ROOT.parents[1]
    for row in catalog.get("protocols", []):
        if not isinstance(row, dict):
            mapping_errors.append("A catalog protocol row is not an object.")
            continue
        samples = row.get("sample_options")
        if not isinstance(samples, list) or not samples:
            mapping_errors.append(f"{row.get('protocol_id')} has no sample option.")
            continue
        defaults = [sample for sample in samples if isinstance(sample, dict) and sample.get("default")]
        if len(defaults) != 1:
            mapping_errors.append(f"{row.get('protocol_id')} must have exactly one default sample option.")
        definition = package_root / str(row.get("protocol_definition", ""))
        try:
            definition_data = read_json(definition)
            if definition_data.get("protocol_id") != row.get("protocol_id"):
                mapping_errors.append(f"Protocol definition identity mismatch for {row.get('protocol_id')}.")
            if str(definition_data.get("protocol_version")) != str(row.get("protocol_version")):
                mapping_errors.append(f"Protocol definition version mismatch for {row.get('protocol_id')}.")
        except StimulusContractError as exc:
            mapping_errors.append(str(exc))
        for sample in samples:
            if not isinstance(sample, dict) or sample.get("pack_id") not in known_packs:
                mapping_errors.append(f"{row.get('protocol_id')} references an unknown pack.")
                continue
            manifest = manifest_by_pack.get(str(sample.get("pack_id")), {})
            matches = [
                item for item in manifest.get("compatibility", [])
                if isinstance(item, dict)
                and item.get("protocol_id") == row.get("protocol_id")
                and str(item.get("protocol_version")) == str(row.get("protocol_version"))
            ]
            if len(matches) != 1:
                mapping_errors.append(f"{row.get('protocol_id')} lacks exactly one matching pack compatibility row.")
                continue
            if matches[0].get("delivery_mode") != sample.get("delivery_mode"):
                mapping_errors.append(f"{row.get('protocol_id')} delivery mode differs between catalog and pack.")
            expected = set(row.get("expected_asset_keys", []))
            present = set((matches[0].get("bindings") or {}).keys())
            missing_keys = sorted(expected.difference(present))
            if missing_keys:
                mapping_errors.append(f"{row.get('protocol_id')} sample is missing bindings: {', '.join(missing_keys)}")
    if len(protocol_ids) != len(catalog.get("protocols", [])):
        mapping_errors.append("Protocol IDs are not unique.")
    result = {
        "schema": "PRAYCG_StimulusCatalogAudit_v1_0",
        "status": "FAIL" if failed or mapping_errors else "PASS",
        "protocol_count": len(protocol_ids),
        "pack_count": len(known_packs),
        "mapping_errors": mapping_errors,
        "pack_reports": reports,
        "boundary": "Catalog audit verifies software identities and coverage only; it does not validate a stimulus experimentally.",
    }
    _emit(result, True)
    return 0 if result["status"] == "PASS" else 2


def _cmd_install(args: argparse.Namespace) -> int:
    catalog = load_catalog(TOOL_ROOT)
    entry = catalog_pack_by_id(catalog, args.pack)
    source = catalog_pack_root(entry, TOOL_ROOT)
    installed, report = install_pack(source, Path(args.destination_root))
    registry = None
    if args.registry:
        registry = write_registry(Path(args.destination_root), Path(args.registry))
    result = {
        "installed_path": str(installed),
        "validation": report.as_dict(),
        "boundary": DEMO_BOUNDARY if report.facts.get("scientific_status") == "DEMO_ONLY" else "STATUS_UNCHANGED_BY_INSTALLATION",
        "registry": registry,
    }
    _emit(result, True)
    return 0 if report.status != "FAIL" else 2


def _cmd_import_pack(args: argparse.Namespace) -> int:
    installed, report = install_pack(Path(args.path), Path(args.destination_root))
    registry = write_registry(Path(args.destination_root), Path(args.registry)) if args.registry else None
    _emit({"installed_path": str(installed), "validation": report.as_dict(), "registry": registry}, True)
    return 0 if report.status != "FAIL" else 2


def _cmd_bind(args: argparse.Namespace) -> int:
    receipt = build_binding_receipt(Path(args.path), args.protocol, Path(args.output))
    _emit(receipt, True)
    return 0


def _cmd_scan(args: argparse.Namespace) -> int:
    registry = (
        write_registry(Path(args.root), Path(args.registry), media_probe=args.media_probe)
        if args.registry
        else scan_installed_packs(Path(args.root), media_probe=args.media_probe)
    )
    _emit(registry, True)
    return 0 if all(row.get("validation_status") != "FAIL" for row in registry["packs"]) and not registry["duplicate_pack_ids"] else 2


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Browse, validate, install, and draft-bind data-only PRAYCG stimulus packs."
    )
    parser.add_argument("--gui", action="store_true", help="Open the Stimulus Library window.")
    parser.add_argument("--install-root", help="Default copy-on-use install root for the GUI.")
    parser.add_argument("--stimulus-root", help="Parent stimulus root; GUI defaults installation to its bundled_samples child.")
    parser.add_argument("--protocol", dest="prefill_protocol", help="Prefill an exact protocol ID in the GUI.")
    parser.add_argument("--registry", help="Optional registry JSON updated after GUI installation.")
    subparsers = parser.add_subparsers(dest="command")

    list_parser = subparsers.add_parser("list", help="List protocols and their included sample options.")
    list_parser.add_argument("--protocol", help="Exact protocol ID filter.")
    list_parser.add_argument("--json", action="store_true", help="Emit structured JSON.")
    list_parser.set_defaults(func=_cmd_list)

    validate_parser = subparsers.add_parser("validate", help="Verify one bundled or installed pack.")
    source = validate_parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--pack", help="Bundled catalog pack ID.")
    source.add_argument("--path", help="Path to a pack root.")
    validate_parser.add_argument("--skip-media-probe", action="store_true")
    validate_parser.set_defaults(func=_cmd_validate)

    audit_parser = subparsers.add_parser("audit-catalog", help="Validate every catalog mapping and bundled pack.")
    audit_parser.add_argument("--skip-media-probe", action="store_true")
    audit_parser.set_defaults(func=_cmd_audit)

    install_parser = subparsers.add_parser("install", help="Copy an immutable bundled pack into a user stimulus root.")
    install_parser.add_argument("--pack", required=True, help="Bundled catalog pack ID.")
    install_parser.add_argument("--destination-root", required=True, help="Parent folder; a pack-ID child is created.")
    install_parser.add_argument("--registry", help="Optional registry JSON refreshed atomically after installation.")
    install_parser.set_defaults(func=_cmd_install)
    import_parser = subparsers.add_parser("import-pack", help="Validate and copy a Forge/operator pack into the installed library.")
    import_parser.add_argument("--path", required=True, help="Source pack root.")
    import_parser.add_argument("--destination-root", required=True, help="Parent folder; a pack-ID child is created.")
    import_parser.add_argument("--registry", help="Optional registry JSON refreshed atomically after installation.")
    import_parser.set_defaults(func=_cmd_import_pack)

    bind_parser = subparsers.add_parser("bind", help="Create a non-authoritative runner-input binding draft.")
    bind_parser.add_argument("--path", required=True, help="Validated installed pack root.")
    bind_parser.add_argument("--protocol", required=True, help="Exact protocol ID.")
    bind_parser.add_argument("--output", required=True, help="New JSON receipt path.")
    bind_parser.set_defaults(func=_cmd_bind)
    scan_parser = subparsers.add_parser("scan", help="Discover installed packs without executing their contents.")
    scan_parser.add_argument("--root", required=True)
    scan_parser.add_argument("--registry", help="Optional registry JSON output path.")
    scan_parser.add_argument("--media-probe", action="store_true")
    scan_parser.set_defaults(func=_cmd_scan)
    return parser


class StimulusLibraryUI:
    def __init__(self, install_root: str | None = None, stimulus_root: str | None = None, prefill_protocol: str | None = None, registry: str | None = None) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.catalog = load_catalog(TOOL_ROOT)
        self.install_root = Path(install_root).expanduser() if install_root else ((Path(stimulus_root).expanduser() / "bundled_samples") if stimulus_root else None)
        self.prefill_protocol = prefill_protocol
        self.registry_path = Path(registry).expanduser() if registry else None
        self.root = tk.Tk()
        self.root.title("PRAYCG Stimulus Library v1.0 — alpha.4")
        self.root.geometry("1120x720")
        self.protocol_by_label: dict[str, dict[str, Any]] = {}
        self.pack_by_label: dict[str, dict[str, Any]] = {}
        self.protocol_var = tk.StringVar()
        self.pack_var = tk.StringVar()
        self.status_var = tk.StringVar(value="Select a protocol. Bundled examples are DEMO ONLY.")
        self._build()
        self._populate_protocols()

    def _build(self) -> None:
        tk, ttk = self.tk, self.ttk
        banner = tk.Label(
            self.root,
            text="Bundled sample packs are software-flow examples — not validated research stimuli",
            bg="#7A2E2E",
            fg="white",
            padx=12,
            pady=10,
            font=("Segoe UI", 11, "bold"),
        )
        banner.pack(fill="x")
        controls = ttk.Frame(self.root, padding=12)
        controls.pack(fill="x")
        ttk.Label(controls, text="Protocol").grid(row=0, column=0, sticky="w", padx=(0, 8))
        self.protocol_combo = ttk.Combobox(controls, state="readonly", textvariable=self.protocol_var, width=58)
        self.protocol_combo.grid(row=0, column=1, sticky="ew")
        self.protocol_combo.bind("<<ComboboxSelected>>", lambda _event: self._protocol_changed())
        ttk.Label(controls, text="Sample pack").grid(row=1, column=0, sticky="w", padx=(0, 8), pady=(8, 0))
        self.pack_combo = ttk.Combobox(controls, state="readonly", textvariable=self.pack_var, width=58)
        self.pack_combo.grid(row=1, column=1, sticky="ew", pady=(8, 0))
        self.pack_combo.bind("<<ComboboxSelected>>", lambda _event: self._show_details())
        controls.columnconfigure(1, weight=1)
        buttons = ttk.Frame(self.root, padding=(12, 0, 12, 8))
        buttons.pack(fill="x")
        ttk.Button(buttons, text="Validate packaged master", command=self._validate).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Install a working copy…", command=self._install).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Import a Forge pack…", command=self._import_pack).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Create runner-input draft…", command=self._bind).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Audit complete catalog", command=self._audit).pack(side="left")
        self.text = tk.Text(self.root, wrap="word", font=("Consolas", 9), padx=12, pady=12)
        self.text.pack(fill="both", expand=True, padx=12, pady=4)
        ttk.Label(self.root, textvariable=self.status_var, padding=(12, 8)).pack(fill="x")

    def _populate_protocols(self) -> None:
        labels: list[str] = []
        for row in self.catalog.get("protocols", []):
            label = f"{row['display_name']}  [{row['protocol_id']}]"
            labels.append(label)
            self.protocol_by_label[label] = row
        self.protocol_combo["values"] = labels
        if labels:
            selected = next((label for label, row in self.protocol_by_label.items() if row.get("protocol_id") == self.prefill_protocol), labels[0])
            self.protocol_var.set(selected)
            self._protocol_changed()

    def _selected_protocol(self) -> dict[str, Any]:
        return self.protocol_by_label[self.protocol_var.get()]

    def _selected_pack_entry(self) -> dict[str, Any]:
        item = self.pack_by_label[self.pack_var.get()]
        return catalog_pack_by_id(self.catalog, item["pack_id"])

    def _protocol_changed(self) -> None:
        row = self._selected_protocol()
        self.pack_by_label.clear()
        labels: list[str] = []
        for item in row.get("sample_options", []):
            default = " — default" if item.get("default") else ""
            label = f"{item['pack_id']}{default}"
            labels.append(label)
            self.pack_by_label[label] = item
        self.pack_combo["values"] = labels
        if labels:
            self.pack_var.set(labels[0])
        self._show_details()

    def _set_text(self, value: Any) -> None:
        self.text.delete("1.0", "end")
        self.text.insert("1.0", json.dumps(value, ensure_ascii=False, indent=2))

    def _show_details(self) -> None:
        row = self._selected_protocol()
        item = self.pack_by_label.get(self.pack_var.get(), {})
        self._set_text(
            {
                "protocol": row,
                "selected_sample": item,
                "important": DEMO_BOUNDARY,
                "authority": "Using a pack does not create or bypass an acquisition/session lock.",
            }
        )
        self.status_var.set("Ready. Review the status and bindings before installing.")

    def _validate(self) -> None:
        entry = self._selected_pack_entry()
        report = validate_pack(catalog_pack_root(entry, TOOL_ROOT))
        self._set_text(report.as_dict())
        self.status_var.set(f"Validation: {report.status}. PASS is file-integrity evidence only.")

    def _install(self) -> None:
        from tkinter import filedialog, messagebox

        destination = filedialog.askdirectory(title="Choose the stimulus-library parent folder", initialdir=str(self.install_root) if self.install_root else None)
        if not destination:
            return
        try:
            entry = self._selected_pack_entry()
            installed, report = install_pack(catalog_pack_root(entry, TOOL_ROOT), Path(destination))
            registry = write_registry(Path(destination), self.registry_path) if self.registry_path else None
            self._set_text({"installed_path": str(installed), "validation": report.as_dict(), "registry": registry})
            self.status_var.set(f"Installed a verified copy at {installed}. Scientific status was not promoted.")
        except Exception as exc:
            messagebox.showerror("Stimulus installation stopped", str(exc))

    def _bind(self) -> None:
        from tkinter import filedialog, messagebox

        pack_root = filedialog.askdirectory(title="Choose the installed stimulus pack")
        if not pack_root:
            return
        protocol_id = self._selected_protocol()["protocol_id"]
        output = filedialog.asksaveasfilename(
            title="Save a runner-input binding draft",
            defaultextension=".json",
            initialfile=f"{protocol_id}_stimulus_binding_DRAFT.json",
            filetypes=[("JSON", "*.json")],
        )
        if not output:
            return
        try:
            receipt = build_binding_receipt(Path(pack_root), protocol_id, Path(output))
            self._set_text(receipt)
            self.status_var.set("Draft created. It remains non-authoritative until reviewed by the session-lock workflow.")
        except Exception as exc:
            messagebox.showerror("Binding draft stopped", str(exc))

    def _import_pack(self) -> None:
        from tkinter import filedialog, messagebox

        source = filedialog.askdirectory(title="Choose a validated Forge or operator pack")
        if not source:
            return
        destination = filedialog.askdirectory(
            title="Choose the installed stimulus-library parent folder",
            initialdir=str(self.install_root) if self.install_root else None,
        )
        if not destination:
            return
        try:
            installed, report = install_pack(Path(source), Path(destination))
            registry = write_registry(Path(destination), self.registry_path) if self.registry_path else None
            self._set_text({"installed_path": str(installed), "validation": report.as_dict(), "registry": registry})
            self.status_var.set("Forge pack imported. Its scientific status was preserved and not promoted.")
        except Exception as exc:
            messagebox.showerror("Forge-pack import stopped", str(exc))

    def _audit(self) -> None:
        rows = []
        failed = False
        for entry, report in iter_catalog_pack_reports(TOOL_ROOT):
            rows.append({"pack_id": entry.get("pack_id"), "validation": report.as_dict()})
            failed = failed or report.status == "FAIL"
        self._set_text({"status": "FAIL" if failed else "PASS", "packs": rows})
        self.status_var.set("Catalog audit complete. Scientific validation remains outside this operation.")

    def run(self) -> int:
        self.root.mainloop()
        return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.gui or not args.command:
        try:
            return StimulusLibraryUI(args.install_root, args.stimulus_root, args.prefill_protocol, args.registry).run()
        except Exception as exc:
            print(f"Stimulus Library UI could not start: {exc}", file=sys.stderr)
            return 2
    try:
        return int(args.func(args))
    except StimulusContractError as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, indent=2), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("Stopped by operator.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
