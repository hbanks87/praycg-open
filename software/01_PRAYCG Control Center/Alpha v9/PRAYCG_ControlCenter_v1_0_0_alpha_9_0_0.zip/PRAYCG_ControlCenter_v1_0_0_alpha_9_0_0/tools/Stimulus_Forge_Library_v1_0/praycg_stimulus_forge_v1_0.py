#!/usr/bin/env python3
"""Typed, offline-only stimulus generators for PRAYCG alpha.4.

The Forge is deliberately allowlisted: JSON recipes select parameters, never code,
commands, imports, URLs, or model endpoints. Generated assets remain DEMO_ONLY
unless a separate human review and study-lock process creates a new manifest.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
import struct
import subprocess
import sys
import tempfile
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from praycg_stimulus_common_v1_0 import (
    DEMO_BOUNDARY,
    PACK_ID,
    StimulusContractError,
    finalize_manifest,
    read_json,
    sha256_file,
    utc_now,
    validate_pack,
    write_json,
)


TOOL_ROOT = Path(__file__).resolve().parent
ENGINE_VERSION = "0.1"
FRAME_SIZE = (640, 360)
DEFAULT_FPS = 12


@dataclass(frozen=True)
class ForgeRequest:
    engine_id: str
    output: Path
    seed: int = 104729
    title: str = "PRAYCG public-safe demonstration"
    input_path: Path | None = None
    recipe_path: Path | None = None
    pack_id: str | None = None


def _dependencies() -> tuple[Any, Any, Any]:
    try:
        import numpy as np
        from PIL import Image, ImageDraw, ImageFont
    except ImportError as exc:
        raise StimulusContractError("Stimulus Forge requires NumPy and Pillow from the PRAYCG environment.") from exc
    return np, Image, (ImageDraw, ImageFont)


def _font(size: int) -> Any:
    _, _, (_, image_font) = _dependencies()
    try:
        return image_font.truetype("arial.ttf", size)
    except OSError:
        return image_font.load_default()


def _new_frame(color: tuple[int, int, int] = (16, 27, 44)) -> Any:
    _, image, _ = _dependencies()
    return image.new("RGB", FRAME_SIZE, color)


def _center_text(draw: Any, text: str, y: int, *, font_size: int = 32, fill: str = "white") -> None:
    font = _font(font_size)
    box = draw.textbbox((0, 0), text, font=font)
    x = (FRAME_SIZE[0] - (box[2] - box[0])) // 2
    draw.text((x, y), text, fill=fill, font=font)


def _write_tone(path: Path, seconds: float, frequency: float = 440.0, sample_rate: int = 48000, amplitude: float = 0.12) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame_count = int(round(seconds * sample_rate))
    fade = max(1, int(0.02 * sample_rate))
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        for index in range(frame_count):
            envelope = min(1.0, index / fade, (frame_count - index - 1) / fade)
            value = int(32767 * amplitude * max(0.0, envelope) * math.sin(2 * math.pi * frequency * index / sample_rate))
            handle.writeframesraw(struct.pack("<h", value))


def _write_sound_story(path: Path, seconds: float = 12.0, sample_rate: int = 48000) -> None:
    """Create an original non-speech sound sequence for software-flow testing."""
    path.parent.mkdir(parents=True, exist_ok=True)
    frame_count = int(round(seconds * sample_rate))
    with wave.open(str(path), "wb") as handle:
        handle.setnchannels(1)
        handle.setsampwidth(2)
        handle.setframerate(sample_rate)
        frames = bytearray()
        for index in range(frame_count):
            t = index / sample_rate
            scene = min(3, int(t // (seconds / 4)))
            local = t - scene * seconds / 4
            tones = [(220, 330), (280, 420), (196, 294), (330, 495)][scene]
            pulse = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(2 * math.pi * (1.0 + 0.2 * scene) * local))
            envelope = min(1.0, local / 0.08, max(0.0, (seconds / 4 - local) / 0.08))
            sample = 0.07 * envelope * pulse * (
                math.sin(2 * math.pi * tones[0] * t) + 0.45 * math.sin(2 * math.pi * tones[1] * t)
            )
            frames.extend(struct.pack("<h", int(max(-1.0, min(1.0, sample)) * 32767)))
        handle.writeframes(bytes(frames))


def _find_ffmpeg() -> str:
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception as exc:
        raise StimulusContractError("imageio-ffmpeg is required to build playable MP4 demonstrations.") from exc


def _write_video(frames: list[Any], path: Path, fps: int = DEFAULT_FPS, audio_path: Path | None = None) -> None:
    if not frames:
        raise StimulusContractError("A video engine produced no frames.")
    try:
        import imageio.v2 as imageio
        import numpy as np
    except ImportError as exc:
        raise StimulusContractError("imageio and NumPy are required to build video demonstrations.") from exc
    path.parent.mkdir(parents=True, exist_ok=True)
    silent = path.with_name(path.stem + ".video-only.mp4") if audio_path else path
    writer = imageio.get_writer(str(silent), fps=fps, codec="libx264", pixelformat="yuv420p", macro_block_size=None, quality=7)
    try:
        for frame in frames:
            writer.append_data(np.asarray(frame.convert("RGB")))
    finally:
        writer.close()
    if audio_path:
        command = [
            _find_ffmpeg(), "-hide_banner", "-loglevel", "error", "-y",
            "-i", str(silent), "-i", str(audio_path), "-map", "0:v:0", "-map", "1:a:0",
            "-c:v", "copy", "-c:a", "aac", "-shortest", str(path),
        ]
        completed = subprocess.run(command, capture_output=True, text=True, check=False)
        silent.unlink(missing_ok=True)
        if completed.returncode != 0 or not path.is_file():
            raise StimulusContractError(f"Could not mux demonstration audio: {completed.stderr.strip()}")


def _story_frames(seed: int, *, cues: bool = True, seconds: int = 12, fps: int = DEFAULT_FPS) -> tuple[list[Any], list[dict[str, Any]]]:
    np, _, (image_draw, _) = _dependencies()
    rng = np.random.default_rng(seed)
    frames: list[Any] = []
    cues_out: list[dict[str, Any]] = []
    cue_values = [2, 5, 3, 7]
    scene_colors = [(31, 58, 79), (67, 77, 92), (34, 72, 62), (55, 54, 86)]
    scene_titles = ["A seed waits", "Rain arrives", "Roots find water", "A new leaf opens"]
    total = seconds * fps
    for index in range(total):
        t = index / fps
        scene = min(3, int(t // (seconds / 4)))
        local = (t - scene * seconds / 4) / (seconds / 4)
        frame = _new_frame(scene_colors[scene])
        draw = image_draw.Draw(frame)
        horizon = 258
        draw.rectangle((0, horizon, 640, 360), fill=(63, 54, 43))
        if scene == 0:
            x = 120 + int(190 * local)
            draw.ellipse((x - 12, 245, x + 12, 269), fill=(206, 158, 74))
        elif scene == 1:
            draw.ellipse((300, 244, 326, 270), fill=(206, 158, 74))
            for drop in range(14):
                x = int((drop * 53 + index * 11 + rng.integers(0, 2)) % 680) - 20
                y = int((drop * 31 + index * 15) % 250)
                draw.line((x, y, x - 6, y + 15), fill=(119, 180, 222), width=2)
        elif scene == 2:
            draw.line((313, 258, 313, 292), fill=(215, 188, 115), width=5)
            reach = int(60 * local)
            draw.line((313, 286, 313 - reach, 286 + int(0.45 * reach)), fill=(215, 188, 115), width=4)
            draw.line((313, 286, 313 + reach, 286 + int(0.45 * reach)), fill=(215, 188, 115), width=4)
        else:
            stem = int(95 * local)
            draw.line((313, 258, 313, 258 - stem), fill=(85, 166, 92), width=8)
            if local > 0.35:
                draw.ellipse((313, 205 - int(25 * local), 370, 235), fill=(99, 190, 105))
            if local > 0.65:
                draw.ellipse((260, 170, 316, 202), fill=(99, 190, 105))
        _center_text(draw, scene_titles[scene], 26, font_size=26, fill="#F8F5E7")
        if cues:
            cue_start = scene * seconds / 4 + 1.0
            if cue_start <= t < cue_start + 0.55:
                value = cue_values[scene]
                draw.rounded_rectangle((550, 22, 620, 92), radius=12, fill=(244, 244, 238), outline=(30, 30, 30), width=3)
                font = _font(38)
                draw.text((574, 34), str(value), fill=(25, 25, 25), font=font)
                if index == int(round(cue_start * fps)):
                    cues_out.append({"cue_index": scene + 1, "start_sec": cue_start, "end_sec": cue_start + 0.55, "value": value, "placement": "upper_right_safe_area"})
        frames.append(frame)
    return frames, cues_out


def _semantic_zero_frames(seed: int, seconds: int = 12, fps: int = DEFAULT_FPS) -> list[Any]:
    np, _, (image_draw, _) = _dependencies()
    rng = np.random.default_rng(seed)
    phases = rng.uniform(0, 2 * math.pi, size=8)
    frames: list[Any] = []
    for index in range(seconds * fps):
        t = index / fps
        frame = _new_frame((29, 31, 38))
        draw = image_draw.Draw(frame)
        for item in range(8):
            x = 55 + item * 76
            height = int(45 + 25 * math.sin(2 * math.pi * (0.15 + item * 0.01) * t + phases[item]))
            draw.rounded_rectangle((x, 180 - height, x + 34, 180 + height), radius=8, fill=(75 + item * 12, 125, 175 - item * 7))
        _center_text(draw, "Coherent geometric motion — demonstration only", 305, font_size=20, fill="#D8DCE3")
        frames.append(frame)
    return frames


def _phase_scramble_frames(frames: list[Any], seed: int) -> list[Any]:
    np, image, _ = _dependencies()
    rng = np.random.default_rng(seed)
    output: list[Any] = []
    for frame in frames:
        arr = np.asarray(frame.convert("RGB"), dtype=np.float32)
        scrambled_channels = []
        for channel in range(3):
            spectrum = np.fft.rfft2(arr[:, :, channel])
            phase = rng.uniform(-math.pi, math.pi, size=spectrum.shape)
            phase[0, 0] = 0.0
            transformed = np.fft.irfft2(np.abs(spectrum) * np.exp(1j * phase), s=arr[:, :, channel].shape)
            transformed = transformed - transformed.mean() + arr[:, :, channel].mean()
            scrambled_channels.append(np.clip(transformed, 0, 255))
        output.append(image.fromarray(np.stack(scrambled_channels, axis=2).astype(np.uint8)))
    return output


def _draw_card(path: Path, title: str, symbol: str, accent: str) -> None:
    _, _, (image_draw, _) = _dependencies()
    image = _new_frame((247, 247, 245))
    draw = image_draw.Draw(image)
    draw.rounded_rectangle((160, 55, 480, 285), radius=28, fill="white", outline=accent, width=8)
    _center_text(draw, title, 76, font_size=25, fill="#20252B")
    _center_text(draw, symbol, 142, font_size=72, fill=accent)
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)


def _scramble_wav(source: Path, destination: Path, chunk_seconds: float, seed: int) -> list[int]:
    import random

    with wave.open(str(source), "rb") as handle:
        params = handle.getparams()
        frames = handle.readframes(handle.getnframes())
    bytes_per_frame = params.nchannels * params.sampwidth
    chunk_frames = max(1, int(round(chunk_seconds * params.framerate)))
    chunk_bytes = chunk_frames * bytes_per_frame
    chunks = [frames[index:index + chunk_bytes] for index in range(0, len(frames), chunk_bytes)]
    order = list(range(len(chunks)))
    random.Random(seed).shuffle(order)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), "wb") as handle:
        handle.setparams(params)
        handle.writeframes(b"".join(chunks[index] for index in order))
    return order


def _reorder_wav(source: Path, destination: Path, segment_seconds: float, order: list[int]) -> None:
    with wave.open(str(source), "rb") as handle:
        params = handle.getparams()
        frames = handle.readframes(handle.getnframes())
    bytes_per_frame = params.nchannels * params.sampwidth
    segment_bytes = int(round(segment_seconds * params.framerate)) * bytes_per_frame
    segments = [frames[index:index + segment_bytes] for index in range(0, len(frames), segment_bytes)]
    if sorted(order) != list(range(len(segments))):
        raise StimulusContractError("Shot-order audio permutation does not exactly cover the source segments.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), "wb") as handle:
        handle.setparams(params)
        handle.writeframes(b"".join(segments[index] for index in order))


def _base_manifest(pack_id: str, display_name: str, seed: int, engine_id: str) -> dict[str, Any]:
    return {
        "schema": "PRAYCG_StimulusPack_v1_0",
        "pack_id": pack_id,
        "pack_version": "1.0.0-alpha.4",
        "display_name": display_name,
        "description": "Original, procedurally generated public-safe assets for software flow testing and operator training.",
        "scientific_status": "DEMO_ONLY",
        "status_boundary": DEMO_BOUNDARY,
        "distribution": {
            "bundled": True,
            "license_id": "CC0-1.0",
            "attribution": "Original procedural PRAYCG alpha.4 demonstration assets; no third-party media incorporated.",
            "source_material_bundled": False,
            "redistribution_reviewed": True,
        },
        "generator": {
            "engine_id": engine_id,
            "engine_version": ENGINE_VERSION,
            "seed": seed,
            "deterministic_claim": False,
            "recipe_path": "generation_recipe.json",
            "upstream_model": None,
            "human_review_required": True,
        },
        "compatibility": [],
        "asset_roles": [],
        "file_ledger": [],
        "accessibility_and_safety": [
            "Short demonstrations contain ordinary visual motion and synthesized audio; operators should preview comfort and volume.",
            "The examples are not calibrated for luminance, sound level, emotional intensity, semantic density, or participant suitability.",
        ],
        "claims_boundary": [
            "These assets test software flow and train operators; they are not validated scientific stimuli.",
            "A generated control is not assumed perceptually matched, emotionally neutral, semantically equivalent, or mechanistically selective.",
            "Installing or hashing a pack does not promote it to PILOT_CANDIDATE or STUDY_LOCKED.",
        ],
        "manifest_content_sha256": "0" * 64,
    }


def _write_recipe(root: Path, engine: str, seed: int, details: dict[str, Any]) -> None:
    write_json(
        root / "generation_recipe.json",
        {
            "schema": "PRAYCG_StimulusGenerationRecipe_v1_0",
            "engine_id": engine,
            "engine_version": ENGINE_VERSION,
            "seed": seed,
            "created_for": "alpha.4 bundled demonstration",
            "network_used": False,
            "upstream_model": None,
            "details": details,
            "boundary": DEMO_BOUNDARY,
        },
    )


def build_native_pack(root: Path, seed: int = 104729) -> None:
    root.mkdir(parents=True, exist_ok=False)
    _write_recipe(root, "narrative_demo_video", seed, {"scenes": 4, "duration_seconds": 12, "fps": DEFAULT_FPS, "original_story": "seed-rain-roots-leaf"})
    audio = root / "audio" / "procedural_soundtrack.wav"
    _write_sound_story(audio, 12.0)
    target_frames, cues = _story_frames(seed)
    _write_video(target_frames, root / "videos" / "target_with_cues.mp4", audio_path=audio)
    _write_video(_phase_scramble_frames(target_frames, seed + 1), root / "videos" / "phase_scrambled.mp4", audio_path=audio)
    order = [2, 0, 3, 1]
    per_scene = len(target_frames) // 4
    shot_frames = [frame for scene in order for frame in target_frames[scene * per_scene:(scene + 1) * per_scene]]
    shot_audio = root / "audio" / "shot_order_soundtrack.wav"
    _reorder_wav(audio, shot_audio, 3.0, order)
    _write_video(shot_frames, root / "videos" / "shot_order_scramble.mp4", audio_path=shot_audio)
    semantic_audio = root / "audio" / "semantic_zero_tone.wav"
    _write_tone(semantic_audio, 12.0, frequency=247.0, amplitude=0.018)
    _write_video(_semantic_zero_frames(seed + 2), root / "videos" / "semantic_zero.mp4", audio_path=semantic_audio)
    write_json(root / "cue_schedule.json", {"schema": "PRAYCG_CueSchedule_v1_0_DEMO", "clock": "media_seconds", "cue_events": cues, "expected_sum": sum(int(row["value"]) for row in cues), "boundary": DEMO_BOUNDARY})
    write_json(root / "shot_order_manifest.json", {"schema": "PRAYCG_DemoShotOrderManifest_v1_0", "parent": "videos/target_with_cues.mp4", "scene_duration_seconds": 3.0, "source_order_zero_based": [0, 1, 2, 3], "output_order_zero_based": order, "video_and_audio_reordered_together": True, "boundary": DEMO_BOUNDARY})
    target_hash = sha256_file(root / "videos" / "target_with_cues.mp4")
    write_json(root / "override_identity_manifest.json", {"schema": "PRAYCG_OverrideIdentityBinding_v1_0", "target_path": "videos/target_with_cues.mp4", "override_path": "videos/target_with_cues.mp4", "target_sha256": target_hash, "override_sha256": target_hash, "bit_identical": True, "boundary": "Identity supports a low-level media control but does not isolate cognition or establish construct validity."})
    manifest = _base_manifest("PRAYCG_NATIVE_STORY_DEMO_V1", "PRAYCG3/4 and SMG procedural story demonstration", seed, "narrative_demo_video")
    manifest["compatibility"] = [
        {"protocol_id": "PRAYCG3", "protocol_version": "3.0", "delivery_mode": "PACK_ASSET", "bindings": {"control_video": "videos/phase_scrambled.mp4", "target_video": "videos/target_with_cues.mp4", "override_video": "videos/target_with_cues.mp4", "cue_schedule_json": "cue_schedule.json"}, "notes": DEMO_BOUNDARY},
        {"protocol_id": "PRAYCG4", "protocol_version": "4.0", "delivery_mode": "PACK_ASSET", "bindings": {"control_video": "videos/phase_scrambled.mp4", "shot_order_video": "videos/shot_order_scramble.mp4", "target_video": "videos/target_with_cues.mp4", "override_video": "videos/target_with_cues.mp4", "cue_schedule_json": "cue_schedule.json", "shot_order_manifest": "shot_order_manifest.json"}, "notes": DEMO_BOUNDARY},
        {"protocol_id": "SMG", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": {"semantic_zero_video": "videos/semantic_zero.mp4", "target_video": "videos/target_with_cues.mp4", "override_video": "videos/target_with_cues.mp4", "cue_schedule_json": "cue_schedule.json"}, "notes": "Semantic-Zero status must be established empirically; this file is only a flow-test candidate."},
    ]
    manifest["asset_roles"] = [
        {"asset_id": "target", "role": "intact_demo_story_with_arithmetic_cues", "path": "videos/target_with_cues.mp4", "media_type": "video", "parent_asset_id": None, "derivation": None, "scientific_use": "FLOW_TEST_ONLY"},
        {"asset_id": "phase_control", "role": "phase_scrambled_demonstration", "path": "videos/phase_scrambled.mp4", "media_type": "video", "parent_asset_id": "target", "derivation": "per-frame seeded Fourier phase replacement; audio retained", "scientific_use": "FLOW_TEST_ONLY"},
        {"asset_id": "shot_order", "role": "shot_order_scramble_demonstration", "path": "videos/shot_order_scramble.mp4", "media_type": "video", "parent_asset_id": "target", "derivation": "four equal audiovisual 3-second scenes reordered [3,1,4,2]", "scientific_use": "FLOW_TEST_ONLY"},
        {"asset_id": "semantic_zero", "role": "coherent_geometric_motion_demonstration", "path": "videos/semantic_zero.mp4", "media_type": "video", "parent_asset_id": None, "derivation": "procedural geometric motion", "scientific_use": "FLOW_TEST_ONLY"},
        {"asset_id": "cue_schedule", "role": "demonstration_arithmetic_cue_schedule", "path": "cue_schedule.json", "media_type": "schedule", "parent_asset_id": "target", "derivation": "generator-native schedule", "scientific_use": "FLOW_TEST_ONLY"},
    ]
    finalize_manifest(manifest, root)


def build_audio_pack(root: Path, seed: int = 130363) -> None:
    root.mkdir(parents=True, exist_ok=False)
    _write_recipe(root, "audio_story_bundle", seed, {"duration_seconds": 12, "coarse_chunk_seconds": 3.0, "fine_chunk_seconds": 0.25, "content": "non-speech sound sequence"})
    intact = root / "audio" / "intact_sound_story.wav"
    coarse = root / "audio" / "coarse_scrambled_sound_story.wav"
    fine = root / "audio" / "fine_scrambled_sound_story.wav"
    _write_sound_story(intact, 12.0)
    coarse_order = _scramble_wav(intact, coarse, 3.0, seed + 1)
    fine_order = _scramble_wav(intact, fine, 0.25, seed + 2)
    variants = {
        "intact": {"path": "audio/intact_sound_story.wav", "sha256": sha256_file(intact), "parent": None, "chunk_seconds": None, "order": None},
        "coarse": {"path": "audio/coarse_scrambled_sound_story.wav", "sha256": sha256_file(coarse), "parent": "intact", "chunk_seconds": 3.0, "order": coarse_order},
        "fine": {"path": "audio/fine_scrambled_sound_story.wav", "sha256": sha256_file(fine), "parent": "intact", "chunk_seconds": 0.25, "order": fine_order},
    }
    fixture_review = {
        "review_status": "APPROVED",
        "reviewed_by": "PRAYCG alpha.4 bundled-fixture technical review",
        "reviewed_utc": "2026-09-14T00:00:00Z",
        "operator_attestation": "The generated CC0 fixture was decoded and checked for software-flow use only; scientific suitability is not attested.",
    }
    role_names = {"intact": "intact", "coarse": "coarse_scramble", "fine": "fine_scramble"}
    manifest_names: dict[str, str] = {}
    for role, data in variants.items():
        variant_role = role_names[role]
        manifest_name = f"narr_{role}_reviewed_import_manifest.json"
        manifest_names[role] = manifest_name
        derivative = {
            "required_for_scrambled_variants": role != "intact",
            "intact_parent_sha256": variants["intact"]["sha256"] if role != "intact" else "",
            "method": "fixed-seed chunk permutation" if role != "intact" else "none_intact_parent",
            "parameters": {"chunk_seconds": data["chunk_seconds"]} if role != "intact" else {},
            "random_seed": seed + (1 if role == "coarse" else 2) if role != "intact" else None,
            "derivative_sha256": data["sha256"] if role != "intact" else "",
        }
        payload = {
            "schema": "PRAYCG_ReviewedAssetImportManifest_v1_0",
            "protocol_family": "NARR_AUDIO_STORY_ADAPTATION",
            **fixture_review,
            "review_scope": "DEMO_ONLY_SOFTWARE_FLOW",
            "assets": [{
                "key": "story_audio",
                "path": data["path"],
                "sha256": data["sha256"],
                "variant_role": variant_role,
                "source_citation": "Original deterministic PRAYCG alpha.4 procedural sound fixture",
                "license_or_permission_basis": "CC0-1.0 package-native synthetic media",
                "content_review_notes": "Non-speech sound sequence for playback and marker-flow testing; not a Narratives-equivalent story.",
                "technical_review": {"container": "WAV", "channels": 1, "sample_rate_hz": 48000, "duration_s": 12.0, "decodes_without_error": True, "no_unintended_leading_or_trailing_content": True},
                "derivative_provenance": derivative,
            }],
        }
        write_json(root / manifest_name, payload)
    manifest = _base_manifest("PRAYCG_NARR_SOUND_STORY_DEMO_V1", "NARR procedural sound-story demonstration", seed, "audio_story_bundle")
    manifest["compatibility"] = [
        {"protocol_id": "ATLAS_NARR_AUDIO_INTACT_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": {"story_audio": "audio/intact_sound_story.wav", "reviewed_import_manifest": manifest_names["intact"]}, "notes": "Non-speech flow test; not a Narratives-equivalent story."},
        {"protocol_id": "ATLAS_NARR_AUDIO_COARSE_SCRAMBLE_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": {"story_audio": "audio/coarse_scrambled_sound_story.wav", "reviewed_import_manifest": manifest_names["coarse"]}, "notes": DEMO_BOUNDARY},
        {"protocol_id": "ATLAS_NARR_AUDIO_FINE_SCRAMBLE_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": {"story_audio": "audio/fine_scrambled_sound_story.wav", "reviewed_import_manifest": manifest_names["fine"]}, "notes": DEMO_BOUNDARY},
    ]
    manifest["asset_roles"] = [
        {"asset_id": role, "role": f"{role}_sound_story_demonstration", "path": data["path"], "media_type": "audio", "parent_asset_id": data["parent"], "derivation": None if role == "intact" else f"seeded fixed-order chunk scramble at {data['chunk_seconds']} seconds", "scientific_use": "FLOW_TEST_ONLY"}
        for role, data in variants.items()
    ] + [
        {"asset_id": f"audio_import_manifest_{role}", "role": f"identity_rights_and_derivation_record_{role}", "path": path, "media_type": "manifest", "parent_asset_id": role, "derivation": None, "scientific_use": "FLOW_TEST_ONLY"}
        for role, path in manifest_names.items()
    ]
    finalize_manifest(manifest, root)


def _event_frames(event_id: str, seed: int, seconds: int = 3) -> list[Any]:
    _, _, (image_draw, _) = _dependencies()
    frames: list[Any] = []
    color_map = {"123": "#4A90E2", "639": "#E67E22", "313": "#43A047", "241": "#8E5BB7"}
    color = color_map[event_id]
    for index in range(seconds * DEFAULT_FPS):
        p = index / max(1, seconds * DEFAULT_FPS - 1)
        frame = _new_frame((237, 239, 242))
        draw = image_draw.Draw(frame)
        x = int(80 + 440 * p)
        y = int(205 - 80 * math.sin(math.pi * p))
        draw.line((60, 250, 580, 250), fill="#40464D", width=5)
        draw.ellipse((x - 34, y - 34, x + 34, y + 34), fill=color, outline="#20252B", width=3)
        draw.rectangle((500, 185, 570, 250), fill="#F5C542", outline="#20252B", width=3)
        _center_text(draw, f"Event {event_id} — public-safe demo", 30, font_size=24, fill="#20252B")
        frames.append(frame)
    return frames


def build_event_pack(root: Path, seed: int = 155921) -> None:
    root.mkdir(parents=True, exist_ok=False)
    _write_recipe(root, "event_video_set", seed, {"event_ids": ["123", "639", "313", "241"], "clip_seconds": 3.0, "fps": DEFAULT_FPS})
    emd = root / "emd_assets"
    audio = emd / "procedural_clip_audio.wav"
    _write_tone(audio, 3.0, frequency=330.0)
    clips: list[dict[str, Any]] = []
    all_frames: list[Any] = []
    for offset, event_id in enumerate(("123", "639", "313", "241")):
        frames = _event_frames(event_id, seed + offset)
        all_frames.extend(frames)
        path = emd / "clips" / f"event_{event_id}.mp4"
        _write_video(frames, path, audio_path=audio)
        clips.append({"clip_id": f"DEMO_EVENT_{event_id}", "relative_path": f"clips/event_{event_id}.mp4", "sha256": sha256_file(path), "duration_seconds": 3.0, "audio_expected": True, "license_id": "CC0-1.0"})
    repeated_audio = root / "video" / "procedural_repeated_audio.wav"
    _write_sound_story(repeated_audio, 12.0)
    repeated_video = root / "video" / "repeated_naturalistic_demo.mp4"
    _write_video(all_frames, repeated_video, audio_path=repeated_audio)
    emd_manifest = {
        "schema": "PRAYCG_ExternalMediaManifest_v1_0",
        "manifest_id": "PRAYCG_ALPHA4_PUBLIC_SAFE_EMD_DEMO",
        "media_root": ".",
        "license_and_access_note": "Package-native procedural CC0 media; DEMO_ONLY software-flow scope.",
        "clips": [],
    }
    for index, clip in enumerate(clips):
        emd_manifest["clips"].append({
            "clip_id": clip["clip_id"],
            "relative_path": clip["relative_path"],
            "sha256": clip["sha256"],
            "expected_duration_seconds": 3.0,
            "audio_expected": True,
            "source_reference": "Original PRAYCG alpha.4 procedural CC0 event clip",
            "attention_probe": {
                "probe_id": "DEMO_EVENT_241_COLOR",
                "prompt": "Was the final moving object purple?",
                "left_label": "FALSE",
                "right_label": "TRUE",
                "correct_key": "right",
            } if index == 3 else False,
        })
    write_json(emd / "emd_media_manifest.json", emd_manifest)
    trials = []
    for index, clip in enumerate(clips, start=1):
        trials.append({"trial_id": f"DEMO_TRIAL_{index:03d}", "clip_id": clip["clip_id"], "scheduled_repetition": 1, "attention_probe": index == 4, "probe_id": "DEMO_PROBE_001" if index == 4 else None, "probe_prompt": "Was the final object purple?" if index == 4 else None, "probe_correct_key": "right" if index == 4 else None, "allow_immediate_repeat": False})
    schedule_path = emd / "emd_schedule_demo.json"
    schedule = {"schema": "PRAYCG_ClipSchedule_v1_0", "schedule_id": "ALPHA4_PUBLIC_SAFE_DEMO_SCHEDULE", "media_manifest_id": emd_manifest["manifest_id"], "seed": seed, "generation_method": "fixed package-native four-clip demonstration", "frozen_before_launch": True, "sessions": [{"session_index": 1, "runs": [{"run_index": 1, "trials": trials}]}]}
    write_json(schedule_path, schedule)
    manifest_path = emd / "emd_media_manifest.json"
    write_json(emd / "emd_run_selection.json", {
        "schema": "PRAYCG_ClipScheduleSelection_v1_0",
        "selection_id": "ALPHA4_PUBLIC_SAFE_DEMO_SELECTION",
        "schedule_filename": schedule_path.name,
        "schedule_id": schedule["schedule_id"],
        "schedule_sha256": sha256_file(schedule_path),
        "media_manifest_filename": manifest_path.name,
        "media_manifest_id": emd_manifest["manifest_id"],
        "media_manifest_sha256": sha256_file(manifest_path),
        "session_index": 1,
        "run_index": 1,
        "frozen_before_launch": True,
        "review_status": "APPROVED",
        "reviewed_by": "PRAYCG alpha.4 bundled-fixture technical review",
        "reviewed_utc": "2026-09-14T00:00:00Z",
        "selection_note": "Four-trial package-native DEMO_ONLY software-flow schedule; not a source-scale acquisition schedule.",
    })
    fixture_review = {
        "schema": "PRAYCG_ReviewedAssetImportManifest_v1_0",
        "review_status": "APPROVED",
        "reviewed_by": "PRAYCG alpha.4 bundled-fixture technical review",
        "reviewed_utc": "2026-09-14T00:00:00Z",
        "review_scope": "DEMO_ONLY_SOFTWARE_FLOW",
        "operator_attestation": "Generated CC0 fixtures were decoded and checked for software-flow use only; scientific suitability is not attested.",
    }
    natview_manifest = dict(fixture_review)
    natview_manifest["protocol_family"] = "NATVIEW_REPEATED_VIDEO_ADAPTATION"
    natview_manifest["assets"] = [{
        "key": "repeated_video", "path": "video/repeated_naturalistic_demo.mp4", "sha256": sha256_file(repeated_video),
        "source_citation": "Original PRAYCG alpha.4 procedural CC0 media", "license_or_permission_basis": "CC0-1.0 package-native synthetic media",
        "content_review_notes": "Twelve-second concatenated geometric event flow test; not a validated naturalistic stimulus.",
        "technical_review": {"container": "MP4", "video_codec": "H.264", "audio_present": True, "duration_s": 12.0, "frame_rate_hz": DEFAULT_FPS, "decodes_without_error": True, "starts_at_media_time_zero": True},
    }]
    write_json(root / "natview_reviewed_import_manifest.json", natview_manifest)
    zacks_manifest = dict(fixture_review)
    zacks_manifest["protocol_family"] = "ZACKS_EVERYDAY_EVENT_ADAPTATION"
    zacks_manifest["assets"] = []
    for event_id, clip in zip(("123", "639", "313", "241"), clips):
        zacks_manifest["assets"].append({
            "key": f"event_video_{event_id}", "expected_label": ".".join(event_id), "path": f"emd_assets/{clip['relative_path']}", "sha256": clip["sha256"],
            "source_citation": "Original PRAYCG alpha.4 procedural CC0 media", "license_or_permission_basis": "CC0-1.0 package-native synthetic media",
            "content_review_notes": "Three-second geometric event flow test; not a source stimulus.",
            "technical_review": {"duration_s": 3.0, "audio_track_present": True, "forced_mute_verified": True, "decodes_without_error": True},
        })
    write_json(root / "zacks_reviewed_import_manifest.json", zacks_manifest)
    manifest = _base_manifest("PRAYCG_ATLAS_EVENT_VIDEO_DEMO_V1", "Naturalistic, event-boundary, and rapid-clip demonstration set", seed, "event_video_set")
    zacks_bindings = {f"event_video_{event_id}": f"emd_assets/clips/event_{event_id}.mp4" for event_id in ("123", "639", "313", "241")}
    zacks_bindings["reviewed_import_manifest"] = "zacks_reviewed_import_manifest.json"
    manifest["compatibility"] = [
        {"protocol_id": "ATLAS_NATVIEW_REPEATED_VIDEO_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": {"repeated_video": "video/repeated_naturalistic_demo.mp4", "reviewed_import_manifest": "natview_reviewed_import_manifest.json"}, "notes": DEMO_BOUNDARY},
        {"protocol_id": "ATLAS_ZACKS_EVENT_PASSIVE_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": zacks_bindings, "notes": DEMO_BOUNDARY},
        {"protocol_id": "ATLAS_ZACKS_EVENT_BOUNDARY_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": zacks_bindings, "notes": DEMO_BOUNDARY},
        {"protocol_id": "ATLAS_EEG_MOMENTS_CLIPS_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": {"emd_protocol_assets_folder": "emd_assets"}, "notes": "Four-trial software demonstration, not source-scale EEG Moments acquisition."},
    ]
    manifest["asset_roles"] = [
        {"asset_id": "event_set", "role": "four_public_safe_event_videos", "path": "emd_assets/clips", "media_type": "directory", "parent_asset_id": None, "derivation": "procedurally rendered geometric events", "scientific_use": "FLOW_TEST_ONLY"},
        {"asset_id": "repeated_video", "role": "repeated_naturalistic_demonstration", "path": "video/repeated_naturalistic_demo.mp4", "media_type": "video", "parent_asset_id": "event_set", "derivation": "concatenation of the four procedural event sequences", "scientific_use": "FLOW_TEST_ONLY"},
        {"asset_id": "emd_assets", "role": "rapid_clip_manifest_schedule_selection_and_media", "path": "emd_assets", "media_type": "directory", "parent_asset_id": "event_set", "derivation": "fixed four-trial demonstration schedule", "scientific_use": "FLOW_TEST_ONLY"},
    ]
    finalize_manifest(manifest, root)


def build_generated_visual_pack(root: Path, seed: int = 180749) -> None:
    root.mkdir(parents=True, exist_ok=False)
    _write_recipe(root, "geometric_cue_cards", seed, {"cards": ["fixation", "circle", "square", "left", "right", "feet"], "svna_source": "package-native CC0 geometry specification"})
    _draw_card(root / "images" / "fixation.png", "Rest / fixation", "+", "#3568B8")
    _draw_card(root / "images" / "p3b_target_circle.png", "P3b target", "●", "#D45D48")
    _draw_card(root / "images" / "p3b_standard_square.png", "P3b standard", "■", "#3568B8")
    _draw_card(root / "images" / "motor_left.png", "Imagine left hand", "←", "#4A9D62")
    _draw_card(root / "images" / "motor_right.png", "Imagine right hand", "→", "#8E5BB7")
    _draw_card(root / "images" / "motor_feet.png", "Imagine both feet", "↓", "#E67E22")
    _write_tone(root / "audio" / "start_tone.wav", 0.25, 660.0)
    package_root = TOOL_ROOT.parents[1]
    source_svna = package_root / "examples" / "no_copyright_media_demo" / "protocol_atlas" / "SVNA_public_safe_demo_strips_v1_0.json"
    if not source_svna.is_file():
        raise StimulusContractError(f"Required package-native SVNA fixture is missing: {source_svna}")
    (root / "svna").mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_svna, root / "svna" / "SVNA_public_safe_demo_strips_v1_0.json")
    manifest = _base_manifest("PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1", "Rest, P3b, motor-imagery, and SVNA generated demonstrations", seed, "geometric_cue_cards")
    manifest["compatibility"] = [
        {"protocol_id": "ATLAS_MIPDB_EYES_CLOSED_REST_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "RUNNER_GENERATED", "bindings": {"operator_preview_fixation": "images/fixation.png", "operator_preview_tone": "audio/start_tone.wav"}, "notes": "The runner generates its actual instructions/timing; these assets are previews."},
        {"protocol_id": "ATLAS_ERP_CORE_P3B_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "RUNNER_GENERATED", "bindings": {"p3b_target_preview": "images/p3b_target_circle.png", "p3b_standard_preview": "images/p3b_standard_square.png"}, "notes": "The runner generates its actual shapes; these cards are previews."},
        {"protocol_id": "ATLAS_EEGMMIDB_MOTOR_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "RUNNER_GENERATED", "bindings": {"fixation_cross": "images/fixation.png", "motor_cue_left": "images/motor_left.png", "motor_cue_right": "images/motor_right.png", "motor_cue_feet": "images/motor_feet.png"}, "notes": "The runner generates its actual cue cards; these files are previews."},
        {"protocol_id": "ATLAS_SVNA_GUTTER_RANKING_ADAPTATION", "protocol_version": "1.0", "delivery_mode": "PACK_ASSET", "bindings": {"svna_public_safe_demo_strips": "svna/SVNA_public_safe_demo_strips_v1_0.json"}, "notes": DEMO_BOUNDARY},
    ]
    manifest["asset_roles"] = [
        {"asset_id": "fixation", "role": "rest_and_motor_fixation_preview", "path": "images/fixation.png", "media_type": "image", "parent_asset_id": None, "derivation": "procedural card", "scientific_use": "OPERATOR_TRAINING"},
        {"asset_id": "p3b_cards", "role": "P3b_shape_previews", "path": "images", "media_type": "directory", "parent_asset_id": None, "derivation": "procedural cards", "scientific_use": "OPERATOR_TRAINING"},
        {"asset_id": "svna_manifest", "role": "six_panel_gutter_ranking_geometry", "path": "svna/SVNA_public_safe_demo_strips_v1_0.json", "media_type": "image_sequence", "parent_asset_id": None, "derivation": "package-native primitive geometry", "scientific_use": "FLOW_TEST_ONLY"},
    ]
    finalize_manifest(manifest, root)


def _guard_new_output(output: Path) -> Path:
    resolved = output.expanduser().resolve()
    if resolved.exists():
        raise StimulusContractError(f"Forge output already exists: {resolved}. Choose a new folder; Forge does not overwrite outputs.")
    resolved.parent.mkdir(parents=True, exist_ok=True)
    return resolved


def run_engine(request: ForgeRequest) -> dict[str, Any]:
    registry = read_json(TOOL_ROOT / "engine_registry_v1_0.json")
    registered = {row["id"]: row for row in registry.get("engines", []) if isinstance(row, dict) and row.get("id")}
    engine_record = registered.get(request.engine_id)
    if engine_record is None:
        raise StimulusContractError(f"Engine is not statically allowlisted: {request.engine_id!r}")
    if engine_record.get("invocation_mode") == "PIPELINE_STAGE":
        raise StimulusContractError(
            f"{request.engine_id} is an implemented, typed stage inside a reviewed pack template, not a standalone alpha.4 entry. "
            "Use narrative_demo_video, illustrated_storybook, audio_story_bundle, event_video_set, or geometric_cue_cards."
        )
    if request.pack_id and not PACK_ID.fullmatch(request.pack_id.strip().upper()):
        raise StimulusContractError("Custom pack ID must use 3-96 uppercase letters, digits, and underscores.")
    handlers: dict[str, Callable[[Path, int], None]] = {
        "narrative_demo_video": build_native_pack,
        "illustrated_storybook": build_native_pack,
        "audio_story_bundle": build_audio_pack,
        "event_video_set": build_event_pack,
        "geometric_cue_cards": build_generated_visual_pack,
    }
    if request.engine_id == "protocol_sample_pack_validator":
        target = request.input_path or request.output
        report = validate_pack(target)
        return report.as_dict()
    if request.input_path is not None or request.recipe_path is not None:
        raise StimulusContractError(
            "Alpha.4 standalone Forge entries are frozen public-safe templates. Custom input and recipe admission is not enabled yet."
        )
    handler = handlers.get(request.engine_id)
    if handler is None:
        raise StimulusContractError(f"Engine has no standalone alpha.4 handler: {request.engine_id!r}")
    output = _guard_new_output(request.output)
    try:
        handler(output, request.seed)
        generated_manifest = read_json(output / "stimulus_pack_manifest.json")
        generated_manifest["generator"]["engine_id"] = request.engine_id
        generated_manifest["generator"]["seed"] = request.seed
        if request.pack_id:
            normalized_pack_id = request.pack_id.strip().upper()
            generated_manifest["pack_id"] = normalized_pack_id
        if request.title and request.title != "PRAYCG public-safe demonstration":
            generated_manifest["display_name"] = request.title.strip()[:160]
        finalize_manifest(generated_manifest, output)
        report = validate_pack(output)
        if report.status == "FAIL":
            raise StimulusContractError("Generated pack failed its own validation: " + "; ".join(report.errors))
        return {"schema": "PRAYCG_StimulusForgeResult_v1_0", "engine_id": request.engine_id, "output": str(output), "validation": report.as_dict(), "scientific_status": "DEMO_ONLY", "boundary": DEMO_BOUNDARY}
    except Exception:
        if output.exists():
            shutil.rmtree(output, ignore_errors=True)
        raise


def build_bundled_library(package_root: Path) -> list[dict[str, Any]]:
    destination = package_root.resolve() / "examples" / "no_copyright_media_demo" / "stimulus_library" / "packs"
    destination.mkdir(parents=True, exist_ok=True)
    builders = [
        ("PRAYCG_NATIVE_STORY_DEMO_V1", build_native_pack, 104729),
        ("PRAYCG_NARR_SOUND_STORY_DEMO_V1", build_audio_pack, 130363),
        ("PRAYCG_ATLAS_EVENT_VIDEO_DEMO_V1", build_event_pack, 155921),
        ("PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1", build_generated_visual_pack, 180749),
    ]
    results = []
    for pack_id, builder, seed in builders:
        output = destination / pack_id
        if output.exists():
            raise StimulusContractError(f"Bundled-pack target already exists: {output}")
        builder(output, seed)
        report = validate_pack(output)
        if report.status == "FAIL":
            raise StimulusContractError(f"Built-in pack {pack_id} failed validation: {'; '.join(report.errors)}")
        results.append(report.as_dict())
    return results


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Create offline, typed, DEMO_ONLY PRAYCG stimulus packs.")
    parser.add_argument("--gui", action="store_true", help="Open the Stimulus Forge window.")
    parser.add_argument("--output-root", help="Default GUI parent folder or CLI output root.")
    parser.add_argument("--protocol", help="Display the protocol that constrained this Forge session.")
    parser.add_argument("--prefill-engine", help="Select one allowed standalone engine when the GUI opens.")
    parser.add_argument("--allowed-engines", help="Comma-separated standalone-engine allowlist supplied by the locked protocol workflow.")
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("list-engines", help="List the frozen allowlist and scientific boundary.")
    generate = sub.add_parser("generate", help="Run one allowlisted engine into a new folder.")
    generate.add_argument("--engine", required=True)
    generate.add_argument("--output", required=True)
    generate.add_argument("--seed", type=int, default=104729)
    generate.add_argument("--title", default="PRAYCG public-safe demonstration")
    generate.add_argument("--pack-id", help="Unique uppercase pack identity for this generated output.")
    generate.add_argument("--input")
    generate.add_argument("--recipe")
    bundled = sub.add_parser("build-bundled", help=argparse.SUPPRESS)
    bundled.add_argument("--package-root", required=True)
    return parser


class ForgeUI:
    def __init__(
        self,
        output_root: str | None = None,
        *,
        protocol_id: str | None = None,
        prefill_engine: str | None = None,
        allowed_engines: list[str] | None = None,
    ) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk, self.ttk = tk, ttk
        self.registry = read_json(TOOL_ROOT / "engine_registry_v1_0.json")
        self.root = tk.Tk()
        self.root.title("PRAYCG Stimulus Forge v1.0 — protocol-filtered alpha")
        self.root.geometry("980x650")
        self.output_root = Path(output_root).expanduser() if output_root else Path.cwd() / "stimulus_forge_outputs"
        self.engine_var = tk.StringVar()
        self.pack_id_var = tk.StringVar(value="FORGE_GEOMETRIC_CUE_CARDS_DEMO_001")
        self.title_var = tk.StringVar(value="PRAYCG Forge demonstration")
        self.seed_var = tk.StringVar(value="104729")
        self.output_var = tk.StringVar(value=str(self.output_root / self.pack_id_var.get()))
        self.status_var = tk.StringVar(value="Forge outputs begin as DEMO_ONLY.")
        self.protocol_id = str(protocol_id or "").strip()
        self.prefill_engine = str(prefill_engine or "").strip()
        self.allowed_engines = [str(value).strip() for value in (allowed_engines or []) if str(value).strip()]
        self._build()

    def _build(self) -> None:
        tk, ttk = self.tk, self.ttk
        tk.Label(self.root, text="Forge outputs are DEMO ONLY until separately reviewed and study-locked", bg="#7A2E2E", fg="white", padx=12, pady=10, font=("Segoe UI", 11, "bold")).pack(fill="x")
        if self.protocol_id:
            tk.Label(
                self.root,
                text=f"Locked protocol filter: {self.protocol_id}. Only its directly invocable preparation engines are listed.",
                bg="#1F4E79",
                fg="white",
                padx=12,
                pady=7,
            ).pack(fill="x")
        pane = ttk.Frame(self.root, padding=14)
        pane.pack(fill="x")
        ids = [row["id"] for row in self.registry["engines"] if row.get("invocation_mode") == "STANDALONE_PACK_TEMPLATE"]
        if self.allowed_engines:
            requested = set(self.allowed_engines)
            ids = [engine_id for engine_id in ids if engine_id in requested]
        if not ids:
            raise StimulusContractError("The locked protocol exposes no directly invocable Forge engine.")
        ttk.Label(pane, text="Typed engine").grid(row=0, column=0, sticky="w")
        combo = ttk.Combobox(pane, state="readonly", textvariable=self.engine_var, values=ids, width=42)
        combo.grid(row=0, column=1, sticky="ew", padx=8)
        self.engine_var.set(self.prefill_engine if self.prefill_engine in ids else ids[0])
        ttk.Label(pane, text="Pack ID").grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(pane, textvariable=self.pack_id_var).grid(row=1, column=1, sticky="ew", padx=8, pady=(8, 0))
        ttk.Label(pane, text="Display name").grid(row=2, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(pane, textvariable=self.title_var).grid(row=2, column=1, sticky="ew", padx=8, pady=(8, 0))
        ttk.Label(pane, text="Seed").grid(row=3, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(pane, textvariable=self.seed_var).grid(row=3, column=1, sticky="ew", padx=8, pady=(8, 0))
        ttk.Label(pane, text="New output folder").grid(row=4, column=0, sticky="w", pady=(8, 0))
        ttk.Entry(pane, textvariable=self.output_var).grid(row=4, column=1, sticky="ew", padx=8, pady=(8, 0))
        ttk.Button(pane, text="Choose…", command=self._choose).grid(row=4, column=2, pady=(8, 0))
        ttk.Button(pane, text="Generate and validate", command=self._generate).grid(row=5, column=1, sticky="w", padx=8, pady=12)
        pane.columnconfigure(1, weight=1)
        self.text = tk.Text(self.root, wrap="word", font=("Consolas", 9), padx=12, pady=12)
        self.text.pack(fill="both", expand=True, padx=14)
        self.text.insert("1.0", json.dumps(self.registry, indent=2))
        ttk.Label(self.root, textvariable=self.status_var, padding=12).pack(fill="x")

    def _choose(self) -> None:
        from tkinter import filedialog

        path = filedialog.askdirectory(title="Choose a parent folder for a new Forge output")
        if path:
            self.output_var.set(str(Path(path) / self.pack_id_var.get().strip().upper()))

    def _generate(self) -> None:
        from tkinter import messagebox

        try:
            result = run_engine(ForgeRequest(self.engine_var.get(), Path(self.output_var.get()), int(self.seed_var.get()), title=self.title_var.get(), pack_id=self.pack_id_var.get()))
            self.text.delete("1.0", "end")
            self.text.insert("1.0", json.dumps(result, indent=2))
            self.status_var.set("Generated and validated. Status remains DEMO_ONLY.")
        except Exception as exc:
            messagebox.showerror("Forge stopped safely", str(exc))

    def run(self) -> int:
        self.root.mainloop()
        return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.gui or not args.command:
        try:
            allowed = [value.strip() for value in str(args.allowed_engines or "").split(",") if value.strip()]
            return ForgeUI(
                args.output_root,
                protocol_id=args.protocol,
                prefill_engine=args.prefill_engine,
                allowed_engines=allowed or None,
            ).run()
        except Exception as exc:
            print(f"Stimulus Forge UI could not start: {exc}", file=sys.stderr)
            return 2
    try:
        if args.command == "list-engines":
            print(json.dumps(read_json(TOOL_ROOT / "engine_registry_v1_0.json"), indent=2))
            return 0
        if args.command == "build-bundled":
            print(json.dumps(build_bundled_library(Path(args.package_root)), indent=2))
            return 0
        request = ForgeRequest(
            engine_id=args.engine,
            output=Path(args.output),
            seed=args.seed,
            title=args.title,
            input_path=Path(args.input) if args.input else None,
            recipe_path=Path(args.recipe) if args.recipe else None,
            pack_id=args.pack_id,
        )
        print(json.dumps(run_engine(request), indent=2))
        return 0
    except StimulusContractError as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
