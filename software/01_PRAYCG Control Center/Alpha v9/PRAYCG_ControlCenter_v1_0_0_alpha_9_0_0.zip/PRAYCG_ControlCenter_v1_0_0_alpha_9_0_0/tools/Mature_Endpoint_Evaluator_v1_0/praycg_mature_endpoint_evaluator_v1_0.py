#!/usr/bin/env python3
"""Audit PRAYCG mature-endpoint run evidence without inventing physiology.

This tool is intentionally narrower than an analysis suite.  It checks that a
Protocol Atlas run can be joined to its reviewed endpoint contract, that frozen
markers/responses are present, that required quality gates are explicitly
adjudicated, and that any requested claim label is capped by the manifest.
It computes only structural and behavioral quantities that are directly
recoverable from the Atlas event/response logs.  EEG, HRV, respiration, EDA,
metabolic, neurochemical, and causal endpoints remain the responsibility of a
separately frozen and validated analysis pipeline.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


REPORT_SCHEMA = "PRAYCG_MatureEndpointEvaluation_v1_0"
GATE_SCHEMA = "PRAYCG_MatureEndpointGateStatus_v1_0"
ANALYSIS_SCHEMA = "PRAYCG_MatureEndpointAnalysisStatus_v1_0"
CONTRACT_SCHEMA = "PRAYCG_MatureEndpointContract_v1_0"

ALLOWED_GATE_STATES = {
    "PASS",
    "FAIL",
    "NOT_ASSESSED",
    "NOT_APPLICABLE",
    "PARTIAL",
}
ALLOWED_ENDPOINT_STATES = {
    "NOT_RUN",
    "POSITIVE",
    "NULL",
    "MIXED",
    "INCONCLUSIVE",
}
DECISION_LABELS = (
    "CONFIRMATION_CANDIDATE",
    "EXPLORATORY_INTERESTING",
    "CONFOUNDED_USEFUL",
    "CALIBRATION_ONLY",
    "FAIL_NULL",
    "NOT_EVALUABLE",
)
CLAIM_RANK = {
    "NOT_EVALUABLE": 0,
    "FAIL_NULL": 1,
    "CALIBRATION_ONLY": 2,
    "CONFOUNDED_USEFUL": 3,
    "EXPLORATORY_INTERESTING": 4,
    "CONFIRMATION_CANDIDATE": 5,
}
STRUCTURAL_BLOCKING_GATES = {
    "timing_integrity",
    "branch_or_condition_identity",
    "signal_coverage",
    "anchor_lock",
}
SPECIAL_MEASUREMENT_GATES = {
    "metabolic_measurement_gate",
    "direct_assay_gate",
    "molecular_measurement_gate",
}


class EvaluationError(ValueError):
    """Raised for malformed or internally inconsistent evaluation inputs."""


@dataclass(frozen=True)
class TrialResponseExpectation:
    trial_id: str
    response_id: str
    correct_key: str | None
    condition: str | None
    step_id: str | None


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _text(value: Any) -> str:
    return str(value or "").strip()


def _normalized_state(value: Any, *, allowed: set[str], label: str) -> str:
    state = _text(value).upper().replace(" ", "_").replace("-", "_")
    if state not in allowed:
        raise EvaluationError(f"Unsupported {label} state {value!r}; expected one of {sorted(allowed)}")
    return state


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise EvaluationError(f"Could not read JSON {path}: {exc}") from exc


def _load_rows(path: Path | None, *, preferred_key: str) -> list[dict[str, Any]]:
    if path is None:
        return []
    if not path.is_file():
        raise EvaluationError(f"Input file does not exist: {path}")
    if path.suffix.casefold() == ".csv":
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as stream:
                return [dict(row) for row in csv.DictReader(stream)]
        except (OSError, UnicodeError, csv.Error) as exc:
            raise EvaluationError(f"Could not read CSV {path}: {exc}") from exc
    payload = _load_json(path)
    if isinstance(payload, list):
        rows = payload
    elif isinstance(payload, Mapping):
        rows = payload.get(preferred_key)
        if not isinstance(rows, list):
            for alternate in ("rows", "events", "responses", "data"):
                if isinstance(payload.get(alternate), list):
                    rows = payload[alternate]
                    break
    else:
        rows = None
    if not isinstance(rows, list):
        raise EvaluationError(f"{path} does not contain a JSON row list")
    return [dict(row) for row in rows if isinstance(row, Mapping)]


def _walk_nodes(nodes: Any) -> Iterable[Mapping[str, Any]]:
    if not isinstance(nodes, list):
        return
    for raw in nodes:
        if not isinstance(raw, Mapping):
            continue
        yield raw
        for field in ("children", "timeline", "nodes", "phases"):
            yield from _walk_nodes(raw.get(field))


def _response_contract_ids(manifest: Mapping[str, Any]) -> set[str]:
    result: set[str] = set()
    for raw in manifest.get("responses", []):
        if not isinstance(raw, Mapping):
            continue
        parent = _text(raw.get("id"))
        if parent:
            result.add(parent)
        items = raw.get("items")
        if isinstance(items, list):
            for item in items:
                if not isinstance(item, Mapping):
                    continue
                item_id = _text(item.get("id"))
                if parent and item_id:
                    result.add(f"{parent}.{item_id}")
    for node in _walk_nodes(manifest.get("timeline")):
        response_id = _text(node.get("response_id"))
        if response_id:
            result.add(response_id)
        response_ids = node.get("response_ids")
        if isinstance(response_ids, list):
            result.update(_text(value) for value in response_ids if _text(value))
    return result


def _trial_expectations(manifest: Mapping[str, Any]) -> list[TrialResponseExpectation]:
    expectations: list[TrialResponseExpectation] = []
    for node in _walk_nodes(manifest.get("timeline")):
        trials = node.get("trials")
        if not isinstance(trials, list):
            trials = node.get("randomized_trials")
        if not isinstance(trials, list):
            continue
        for index, raw_trial in enumerate(trials, start=1):
            if not isinstance(raw_trial, Mapping):
                continue
            trial_id = _text(raw_trial.get("trial_id")) or f"trial_{index:04d}"
            condition = _text(raw_trial.get("condition")) or None
            steps = raw_trial.get("steps")
            if isinstance(steps, list):
                for step_index, raw_step in enumerate(steps, start=1):
                    if not isinstance(raw_step, Mapping):
                        continue
                    keys = raw_step.get("keys")
                    response_id = _text(raw_step.get("response_id"))
                    if not response_id or not isinstance(keys, list) or not keys:
                        continue
                    expectations.append(TrialResponseExpectation(
                        trial_id=trial_id,
                        response_id=response_id,
                        correct_key=_text(raw_step.get("correct_key")) or None,
                        condition=condition,
                        step_id=_text(raw_step.get("step_id")) or f"step_{step_index:02d}",
                    ))
            else:
                keys = raw_trial.get("keys")
                response_id = _text(raw_trial.get("response_id") or node.get("response_id"))
                if response_id and isinstance(keys, list) and keys:
                    expectations.append(TrialResponseExpectation(
                        trial_id=trial_id,
                        response_id=response_id,
                        correct_key=_text(raw_trial.get("correct_key")) or None,
                        condition=condition,
                        step_id=None,
                    ))
    return expectations


def _parse_response_value(value: Any) -> Any:
    if isinstance(value, (dict, list, int, float, bool)) or value is None:
        return value
    text = _text(value)
    if not text:
        return ""
    if text[0] in "[{\"" or text in {"true", "false", "null"} or re.fullmatch(r"-?\d+(?:\.\d+)?", text):
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text
    return text


def _response_key(value: Any) -> str:
    parsed = _parse_response_value(value)
    if isinstance(parsed, Mapping):
        return _text(parsed.get("key") or parsed.get("response") or parsed.get("value"))
    return _text(parsed)


def _event_marker(row: Mapping[str, Any]) -> str:
    return _text(row.get("marker") or row.get("event_name") or row.get("name"))


def _event_response_rows(events: Sequence[Mapping[str, Any]], responses: Sequence[Mapping[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for raw in events:
        if _text(raw.get("event_kind")).casefold() == "response" or _text(raw.get("response_id")):
            rows.append({
                "trial_id": _text(raw.get("trial_id")),
                "response_id": _text(raw.get("response_id")),
                "value": _parse_response_value(raw.get("response_value")),
                "response_time_seconds": raw.get("response_time_seconds"),
                "event_id": _text(raw.get("event_id")),
                "source": "events",
            })
    seen = {(row["event_id"], row["trial_id"], row["response_id"]) for row in rows if row["event_id"]}
    for raw in responses:
        identity = (_text(raw.get("event_id")), _text(raw.get("trial_id")), _text(raw.get("response_id")))
        if identity[0] and identity in seen:
            continue
        rows.append({
            "trial_id": identity[1],
            "response_id": identity[2],
            "value": _parse_response_value(raw.get("value", raw.get("response_value"))),
            "response_time_seconds": raw.get("response_time_seconds"),
            "event_id": identity[0],
            "source": "responses",
        })
    return rows


def _normalize_gate_payload(payload: Any) -> tuple[str | None, dict[str, dict[str, Any]]]:
    if payload is None:
        return None, {}
    if not isinstance(payload, Mapping):
        raise EvaluationError("Gate-status input must be a JSON object")
    protocol_id = _text(payload.get("protocol_id")) or None
    gates_raw = payload.get("gates", payload)
    result: dict[str, dict[str, Any]] = {}
    if isinstance(gates_raw, list):
        for row in gates_raw:
            if not isinstance(row, Mapping):
                continue
            gate_id = _text(row.get("id") or row.get("gate_id"))
            if not gate_id:
                continue
            status = _normalized_state(row.get("status", "NOT_ASSESSED"), allowed=ALLOWED_GATE_STATES, label="gate")
            result[gate_id] = {
                "status": status,
                "evidence": row.get("evidence"),
                "notes": _text(row.get("notes")),
            }
    elif isinstance(gates_raw, Mapping):
        reserved = {"schema", "protocol_id", "participant_pseudonym", "session_index", "notes", "gates"}
        for gate_id, value in gates_raw.items():
            if gate_id in reserved:
                continue
            if isinstance(value, Mapping):
                status_value = value.get("status", "NOT_ASSESSED")
                evidence = value.get("evidence")
                notes = _text(value.get("notes"))
            else:
                status_value, evidence, notes = value, None, ""
            status = _normalized_state(status_value, allowed=ALLOWED_GATE_STATES, label="gate")
            result[_text(gate_id)] = {"status": status, "evidence": evidence, "notes": notes}
    else:
        raise EvaluationError("Gate-status input must contain a gate list or mapping")
    return protocol_id, result


def _normalize_analysis_payload(payload: Any) -> dict[str, Any]:
    if payload is None:
        return {
            "schema": ANALYSIS_SCHEMA,
            "primary_endpoint_status": "NOT_RUN",
            "preregistered": False,
            "adequately_powered": False,
            "independent_replication": False,
            "special_measurement_gate_passed": False,
            "notes": "No endpoint-analysis status was supplied.",
        }
    if not isinstance(payload, Mapping):
        raise EvaluationError("Analysis-status input must be a JSON object")
    status = _normalized_state(payload.get("primary_endpoint_status", "NOT_RUN"), allowed=ALLOWED_ENDPOINT_STATES, label="endpoint")
    return {
        "schema": _text(payload.get("schema")) or ANALYSIS_SCHEMA,
        "protocol_id": _text(payload.get("protocol_id")) or None,
        "primary_endpoint_status": status,
        "preregistered": bool(payload.get("preregistered", False)),
        "adequately_powered": bool(payload.get("adequately_powered", False)),
        "independent_replication": bool(payload.get("independent_replication", False)),
        "special_measurement_gate_passed": bool(payload.get("special_measurement_gate_passed", False)),
        "effect_direction": _text(payload.get("effect_direction")) or None,
        "multiplicity_controlled": bool(payload.get("multiplicity_controlled", False)),
        "notes": _text(payload.get("notes")),
    }


def _cap_label(label: str, maximum: str) -> tuple[str, bool]:
    if label not in CLAIM_RANK or maximum not in CLAIM_RANK:
        return label, False
    if CLAIM_RANK[label] <= CLAIM_RANK[maximum]:
        return label, False
    return maximum, True


def _decision_label(
    *,
    runtime_supplied: bool,
    protocol_mismatch: bool,
    expected_event_missing: Sequence[str],
    gate_rows: Sequence[Mapping[str, Any]],
    trial_completion_ratio: float | None,
    analysis: Mapping[str, Any],
    maximum_claim: str,
) -> tuple[str, list[str], bool]:
    reasons: list[str] = []
    if not runtime_supplied:
        return "CALIBRATION_ONLY", ["Static contract audit only; no run evidence was supplied."], False
    if protocol_mismatch:
        return "NOT_EVALUABLE", ["Run evidence protocol identity does not match the selected manifest."], False
    if expected_event_missing:
        return "NOT_EVALUABLE", ["One or more required analysis-handoff events are missing."], False

    missing_gates = [row["id"] for row in gate_rows if row["required"] and row["status"] == "NOT_ASSESSED"]
    structural_failures = [row["id"] for row in gate_rows if row["required"] and row["status"] == "FAIL" and row["id"] in STRUCTURAL_BLOCKING_GATES]
    other_failures = [row["id"] for row in gate_rows if row["required"] and row["status"] in {"FAIL", "PARTIAL"} and row["id"] not in STRUCTURAL_BLOCKING_GATES]
    if missing_gates:
        reasons.append("Required gates remain unassessed: " + ", ".join(missing_gates))
        return "NOT_EVALUABLE", reasons, False
    if structural_failures:
        reasons.append("Structural gate failure: " + ", ".join(structural_failures))
        return "NOT_EVALUABLE", reasons, False
    if trial_completion_ratio is not None and trial_completion_ratio < 0.80:
        reasons.append(f"Trial-addressable response completeness is {trial_completion_ratio:.1%}, below the 80% structural threshold.")
        return "NOT_EVALUABLE", reasons, False
    if other_failures:
        reasons.append("Non-structural confound or partial gate: " + ", ".join(other_failures))
        return "CONFOUNDED_USEFUL", reasons, False

    endpoint_status = _text(analysis.get("primary_endpoint_status")) or "NOT_RUN"
    if endpoint_status == "NULL":
        return "FAIL_NULL", ["The supplied primary endpoint analysis is null."], False
    if endpoint_status == "NOT_RUN":
        return "CALIBRATION_ONLY", ["Structural readiness passed, but no primary endpoint analysis was supplied."], False
    if endpoint_status in {"MIXED", "INCONCLUSIVE"}:
        return "CONFOUNDED_USEFUL", [f"The supplied primary endpoint status is {endpoint_status}."], False

    candidate = "EXPLORATORY_INTERESTING"
    if (
        endpoint_status == "POSITIVE"
        and bool(analysis.get("preregistered"))
        and bool(analysis.get("adequately_powered"))
        and bool(analysis.get("independent_replication"))
        and bool(analysis.get("multiplicity_controlled"))
    ):
        candidate = "CONFIRMATION_CANDIDATE"
    capped, was_capped = _cap_label(candidate, maximum_claim)
    reasons.append(f"Positive endpoint status supports at most {candidate} before the manifest claim cap.")
    if was_capped:
        reasons.append(f"The manifest caps this run at {maximum_claim}.")
    return capped, reasons, was_capped


def evaluate(
    manifest_path: Path,
    *,
    events_path: Path | None = None,
    responses_path: Path | None = None,
    gates_path: Path | None = None,
    analysis_path: Path | None = None,
) -> dict[str, Any]:
    manifest = _load_json(manifest_path)
    if not isinstance(manifest, Mapping):
        raise EvaluationError("Protocol manifest must be a JSON object")
    contract = manifest.get("endpoint_contract")
    if not isinstance(contract, Mapping) or _text(contract.get("schema")) != CONTRACT_SCHEMA:
        raise EvaluationError(f"Manifest does not contain a {CONTRACT_SCHEMA} endpoint_contract")
    protocol_id = _text(manifest.get("protocol_id"))
    protocol_version = _text(manifest.get("protocol_version"))
    if not protocol_id or not protocol_version:
        raise EvaluationError("Manifest protocol identity is incomplete")

    events = _load_rows(events_path, preferred_key="events")
    responses = _load_rows(responses_path, preferred_key="responses")
    response_rows = _event_response_rows(events, responses)
    gate_payload = _load_json(gates_path) if gates_path else None
    gate_protocol_id, gate_status = _normalize_gate_payload(gate_payload)
    analysis_payload = _load_json(analysis_path) if analysis_path else None
    analysis = _normalize_analysis_payload(analysis_payload)

    observed_protocol_ids = {
        _text(row.get("protocol_id"))
        for row in [*events, *responses]
        if _text(row.get("protocol_id"))
    }
    protocol_mismatch = bool(
        (observed_protocol_ids and observed_protocol_ids != {protocol_id})
        or (gate_protocol_id and gate_protocol_id != protocol_id)
        or (analysis.get("protocol_id") and analysis.get("protocol_id") != protocol_id)
    )

    handoff = manifest.get("analysis_handoff") if isinstance(manifest.get("analysis_handoff"), Mapping) else {}
    expected_events = [_text(value) for value in handoff.get("expected_events", []) if _text(value)]
    observed_markers = {_event_marker(row) for row in events if _event_marker(row)}
    missing_events = [marker for marker in expected_events if marker not in observed_markers]
    expected_event_coverage = None if not expected_events else (len(expected_events) - len(missing_events)) / len(expected_events)

    declared_response_ids = _response_contract_ids(manifest)
    observed_response_ids = {_text(row.get("response_id")) for row in response_rows if _text(row.get("response_id"))}
    response_id_coverage = None if not declared_response_ids else len(declared_response_ids & observed_response_ids) / len(declared_response_ids)

    expectations = _trial_expectations(manifest)
    observed_by_pair: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in response_rows:
        observed_by_pair[(_text(row.get("trial_id")), _text(row.get("response_id")))].append(row)
    expected_pairs = [(item.trial_id, item.response_id) for item in expectations]
    completed_pairs = [pair for pair in expected_pairs if observed_by_pair.get(pair)]
    trial_completion_ratio = None if not expected_pairs else len(completed_pairs) / len(expected_pairs)
    scored_rows: list[dict[str, Any]] = []
    for expectation in expectations:
        if expectation.correct_key is None:
            continue
        observed = observed_by_pair.get((expectation.trial_id, expectation.response_id), [])
        key = _response_key(observed[0].get("value")) if observed else ""
        scored_rows.append({
            "trial_id": expectation.trial_id,
            "response_id": expectation.response_id,
            "step_id": expectation.step_id,
            "condition": expectation.condition,
            "correct_key": expectation.correct_key,
            "observed_key": key or None,
            "responded": bool(observed),
            "correct": bool(observed and key == expectation.correct_key),
        })
    answered_scored = [row for row in scored_rows if row["responded"]]
    accuracy_answered = None if not answered_scored else sum(bool(row["correct"]) for row in answered_scored) / len(answered_scored)
    accuracy_all_expected = None if not scored_rows else sum(bool(row["correct"]) for row in scored_rows) / len(scored_rows)

    required_gate_contracts = [row for row in contract.get("quality_gates", []) if isinstance(row, Mapping)]
    gate_rows: list[dict[str, Any]] = []
    for row in required_gate_contracts:
        gate_id = _text(row.get("id"))
        supplied = gate_status.get(gate_id, {})
        status = _text(supplied.get("status")) or "NOT_ASSESSED"
        gate_rows.append({
            "id": gate_id,
            "required": bool(row.get("required", False)),
            "rule": _text(row.get("rule")),
            "status": status,
            "evidence": supplied.get("evidence"),
            "notes": _text(supplied.get("notes")),
            "special_measurement_gate": gate_id in SPECIAL_MEASUREMENT_GATES,
        })
    undeclared_gate_ids = sorted(set(gate_status) - {row["id"] for row in gate_rows})

    maximum_claim = _text(contract.get("maximum_claim_without_special_measurement")) or "CALIBRATION_ONLY"
    special_pass = bool(analysis.get("special_measurement_gate_passed")) or any(
        row["special_measurement_gate"] and row["status"] == "PASS" for row in gate_rows
    )
    effective_maximum = maximum_claim
    if maximum_claim == "CALIBRATION_ONLY" and special_pass:
        effective_maximum = "EXPLORATORY_INTERESTING"

    runtime_supplied = bool(events_path or responses_path or gates_path or analysis_path)
    decision, decision_reasons, claim_capped = _decision_label(
        runtime_supplied=runtime_supplied,
        protocol_mismatch=protocol_mismatch,
        expected_event_missing=missing_events,
        gate_rows=gate_rows,
        trial_completion_ratio=trial_completion_ratio,
        analysis=analysis,
        maximum_claim=effective_maximum,
    )

    response_time_values: list[float] = []
    for row in response_rows:
        value = row.get("response_time_seconds")
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            continue
        if math.isfinite(numeric) and numeric >= 0:
            response_time_values.append(numeric)

    report = {
        "schema": REPORT_SCHEMA,
        "generated_utc": _utc_now(),
        "tool_version": "1.0",
        "protocol": {
            "protocol_id": protocol_id,
            "protocol_version": protocol_version,
            "display_name": _text(manifest.get("display_name")),
            "manifest_path": str(manifest_path.resolve()),
            "manifest_sha256": _sha256(manifest_path),
            "endpoint_id": _text(contract.get("endpoint_id")),
            "construct": _text(contract.get("construct")),
            "primary_contrast": _text(contract.get("primary_contrast")),
        },
        "input_evidence": {
            "events_path": str(events_path.resolve()) if events_path else None,
            "responses_path": str(responses_path.resolve()) if responses_path else None,
            "gates_path": str(gates_path.resolve()) if gates_path else None,
            "analysis_path": str(analysis_path.resolve()) if analysis_path else None,
            "event_row_count": len(events),
            "response_row_count": len(response_rows),
            "observed_protocol_ids": sorted(observed_protocol_ids),
            "protocol_identity_mismatch": protocol_mismatch,
        },
        "event_coverage": {
            "expected_count": len(expected_events),
            "observed_expected_count": len(expected_events) - len(missing_events),
            "coverage_ratio": expected_event_coverage,
            "missing_expected_events": missing_events,
        },
        "response_coverage": {
            "declared_response_id_count": len(declared_response_ids),
            "observed_response_id_count": len(observed_response_ids),
            "declared_response_ids_observed": sorted(declared_response_ids & observed_response_ids),
            "declared_response_ids_missing": sorted(declared_response_ids - observed_response_ids),
            "response_id_coverage_ratio": response_id_coverage,
            "expected_trial_response_count": len(expected_pairs),
            "completed_trial_response_count": len(completed_pairs),
            "trial_response_completion_ratio": trial_completion_ratio,
            "scored_response_count": len(scored_rows),
            "answered_scored_response_count": len(answered_scored),
            "accuracy_among_answered": accuracy_answered,
            "accuracy_over_all_expected": accuracy_all_expected,
            "valid_response_time_count": len(response_time_values),
        },
        "behavioral_scoring": scored_rows,
        "quality_gates": {
            "rows": gate_rows,
            "undeclared_supplied_gate_ids": undeclared_gate_ids,
            "required_pass_count": sum(row["required"] and row["status"] == "PASS" for row in gate_rows),
            "required_gate_count": sum(row["required"] for row in gate_rows),
            "all_required_pass": bool(gate_rows) and all((not row["required"]) or row["status"] in {"PASS", "NOT_APPLICABLE"} for row in gate_rows),
        },
        "analysis_status": analysis,
        "endpoint_families": list(contract.get("endpoint_families", [])),
        "minimum_data": list(contract.get("minimum_data", [])),
        "manipulation_checks": list(contract.get("manipulation_checks", [])),
        "falsification_criteria": list(contract.get("falsification_criteria", [])),
        "decision": {
            "label": decision,
            "reasons": decision_reasons,
            "manifest_maximum_claim_without_special_measurement": maximum_claim,
            "effective_maximum_claim_for_this_audit": effective_maximum,
            "special_measurement_gate_passed": special_pass,
            "claim_was_capped": claim_capped,
            "reporting_rule": _text(contract.get("reporting_rule")),
        },
        "interpretation_boundary": [
            "This report audits endpoint readiness, event/response linkage, gate adjudication, and manifest claim limits.",
            "It does not calculate or validate EEG, HRV, respiration, EDA, neurochemical, metabolic, causal, clinical, consciousness, or metaphysical endpoints.",
            "A positive label requires a separately frozen analysis plan and does not replace expert review, ethics approval, or independent replication.",
        ],
    }
    return report


def _pct(value: Any) -> str:
    return "n/a" if not isinstance(value, (int, float)) else f"{float(value):.1%}"


def render_markdown(report: Mapping[str, Any]) -> str:
    protocol = report["protocol"]
    decision = report["decision"]
    event_cov = report["event_coverage"]
    response_cov = report["response_coverage"]
    gates = report["quality_gates"]["rows"]
    lines = [
        f"# Mature Endpoint Evaluation — {protocol['display_name']}",
        "",
        f"- **Protocol:** `{protocol['protocol_id']}` v{protocol['protocol_version']}",
        f"- **Endpoint contract:** `{protocol['endpoint_id']}`",
        f"- **Decision label:** **{decision['label']}**",
        f"- **Manifest SHA-256:** `{protocol['manifest_sha256']}`",
        "",
        "## Construct and contrast",
        "",
        f"**Construct.** {protocol['construct']}",
        "",
        f"**Primary contrast.** {protocol['primary_contrast']}",
        "",
        "## Structural evidence",
        "",
        f"- Expected-event coverage: **{_pct(event_cov['coverage_ratio'])}** "
        f"({event_cov['observed_expected_count']}/{event_cov['expected_count']})",
        f"- Declared response-ID coverage: **{_pct(response_cov['response_id_coverage_ratio'])}**",
        f"- Trial-addressable response completion: **{_pct(response_cov['trial_response_completion_ratio'])}**",
        f"- Accuracy among answered scored responses: **{_pct(response_cov['accuracy_among_answered'])}**",
        "",
    ]
    if event_cov["missing_expected_events"]:
        lines += ["Missing expected events:", ""] + [f"- `{value}`" for value in event_cov["missing_expected_events"]] + [""]
    lines += [
        "## Quality gates",
        "",
        "| Gate | Required | Status | Rule |",
        "| --- | ---: | --- | --- |",
    ]
    for row in gates:
        lines.append(f"| `{row['id']}` | {'yes' if row['required'] else 'no'} | **{row['status']}** | {row['rule']} |")
    lines += [
        "",
        "## Endpoint families",
        "",
    ]
    for family in report.get("endpoint_families", []):
        if isinstance(family, Mapping):
            lines.append(f"- **{_text(family.get('id'))}** ({_text(family.get('clock'))}): {_text(family.get('definition'))}")
    lines += [
        "",
        "## Decision rationale",
        "",
    ]
    lines.extend(f"- {reason}" for reason in decision.get("reasons", []))
    lines += [
        "",
        f"Manifest claim cap without special measurement: **{decision['manifest_maximum_claim_without_special_measurement']}**.",
        "",
        "## Falsification criteria",
        "",
    ]
    lines.extend(f"- {value}" for value in report.get("falsification_criteria", []))
    lines += [
        "",
        "## Interpretation boundary",
        "",
    ]
    lines.extend(f"- {value}" for value in report.get("interpretation_boundary", []))
    lines.append("")
    return "\n".join(lines)


def write_report(report: Mapping[str, Any], output_dir: Path) -> tuple[Path, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    protocol_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", _text(report["protocol"]["protocol_id"]))
    json_path = output_dir / f"{protocol_id}_mature_endpoint_evaluation_v1_0.json"
    md_path = output_dir / f"{protocol_id}_mature_endpoint_evaluation_v1_0.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    md_path.write_text(render_markdown(report), encoding="utf-8")
    return json_path, md_path


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True, help="Reviewed Protocol Atlas JSON manifest.")
    parser.add_argument("--events", type=Path, help="Atlas event JSON or CSV.")
    parser.add_argument("--responses", type=Path, help="Atlas response JSON; optional when responses are present in events.")
    parser.add_argument("--gates", type=Path, help="Explicit gate adjudication JSON.")
    parser.add_argument("--analysis-results", type=Path, help="Bounded primary-endpoint status JSON.")
    parser.add_argument("--output-dir", type=Path, required=True, help="Output folder for JSON and Markdown reports.")
    parser.add_argument("--print-json", action="store_true", help="Print the complete report to stdout.")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        report = evaluate(
            args.manifest.resolve(strict=True),
            events_path=args.events.resolve(strict=True) if args.events else None,
            responses_path=args.responses.resolve(strict=True) if args.responses else None,
            gates_path=args.gates.resolve(strict=True) if args.gates else None,
            analysis_path=args.analysis_results.resolve(strict=True) if args.analysis_results else None,
        )
        json_path, md_path = write_report(report, args.output_dir.resolve())
    except (EvaluationError, OSError, RuntimeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    if args.print_json:
        print(json.dumps(report, indent=2, ensure_ascii=False))
    else:
        print(f"Decision: {report['decision']['label']}")
        print(f"JSON: {json_path}")
        print(f"Markdown: {md_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
