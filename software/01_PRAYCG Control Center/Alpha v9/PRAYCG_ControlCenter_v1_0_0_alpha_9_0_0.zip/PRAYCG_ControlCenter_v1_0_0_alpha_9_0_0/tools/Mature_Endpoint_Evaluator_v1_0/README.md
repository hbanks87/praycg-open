# PRAYCG Mature Endpoint Evaluator v1.0

This utility turns an Atlas manifest's `PRAYCG_MatureEndpointContract_v1_0` into a run-level readiness and claim-boundary report. It does **not** analyze EEG, HRV, respiration, EDA, neurochemistry, metabolism, consciousness, or clinical state.

It checks four things:

1. the event log matches the selected protocol and contains the manifest's analysis-handoff markers;
2. declared responses and compound-trial responses can be joined to their exact trial/step;
3. every required quality gate is explicitly adjudicated rather than silently assumed; and
4. the final decision label does not exceed the claim ceiling in the reviewed manifest.

## Static contract audit

```bat
py -3.11 praycg_mature_endpoint_evaluator_v1_0.py ^
  --manifest ..\ProtocolAtlas_ModuleLibrary_v2_0\protocols\PRAYCG_G_mature_gradient_v2_0.json ^
  --output-dir .\endpoint_report
```

A static audit returns `CALIBRATION_ONLY` because no run evidence or primary analysis was supplied.

## Run evidence audit

```bat
py -3.11 praycg_mature_endpoint_evaluator_v1_0.py ^
  --manifest path\to\reviewed_manifest.json ^
  --events path\to\ProtocolAtlas_*_events.json ^
  --responses path\to\ProtocolAtlas_*_responses.json ^
  --gates examples\gate_status_TEMPLATE.json ^
  --analysis-results examples\analysis_status_TEMPLATE.json ^
  --output-dir path\to\endpoint_report
```

Gate statuses are `PASS`, `FAIL`, `PARTIAL`, `NOT_ASSESSED`, or `NOT_APPLICABLE`. Missing required gates produce `NOT_EVALUABLE`. Structural failures in timing, identity, signal coverage, or anchor locking also produce `NOT_EVALUABLE`; other failed/partial confound gates produce `CONFOUNDED_USEFUL`. A separately supplied null endpoint produces `FAIL_NULL`. Positive findings remain capped by the manifest.

## Behavioral scoring

For declarative compound trials, the evaluator can calculate response completion and key accuracy because the exact `trial_id`, `response_id`, and `correct_key` are frozen in the manifest and response events. That calculation is a software/behavioral integrity check, not a physiological endpoint.

## Thermodynamic and neurochemical boundary

The Thermodynamic Weight of Thought protocol remains `CALIBRATION_ONLY` unless an independent synchronized calibrated metabolic-power measurement passes its explicit gate. Gratitude-neurochemical labels remain proxy constructs unless direct assays are independently collected. This evaluator never converts EEG/HRV into literal energy, mass, ATP, neurotransmitters, hormones, or molecular state.

## Protocol-specific templates

The package includes one gate-status and one analysis-status template for each mature runner under:

- `config/mature_endpoint_gate_templates/`
- `config/mature_endpoint_analysis_templates/`

They can be regenerated deterministically from the reviewed manifests:

```bat
py -3.11 generate_protocol_templates_v1_0.py --package-root ..\..
```

Generation copies the declared gate IDs and rules; it never marks a gate as passed.
