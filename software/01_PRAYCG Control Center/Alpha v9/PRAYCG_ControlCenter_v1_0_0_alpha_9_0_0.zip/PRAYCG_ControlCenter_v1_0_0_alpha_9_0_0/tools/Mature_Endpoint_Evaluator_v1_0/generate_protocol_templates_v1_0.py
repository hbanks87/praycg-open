#!/usr/bin/env python3
"""Regenerate protocol-specific mature-endpoint gate and analysis templates.

The generator reads only reviewed data-only Atlas manifests. It does not execute
protocol code, inspect participant data, or adjudicate any gate.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def _load(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return payload


def generate(package_root: Path) -> dict[str, Any]:
    catalog_path = package_root / "config" / "praycg_mature_endpoint_atlas_catalog_v1_0.json"
    catalog = _load(catalog_path)
    protocols_root = package_root / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0" / "protocols"
    gate_root = package_root / "config" / "mature_endpoint_gate_templates"
    analysis_root = package_root / "config" / "mature_endpoint_analysis_templates"
    gate_root.mkdir(parents=True, exist_ok=True)
    analysis_root.mkdir(parents=True, exist_ok=True)

    written: list[dict[str, str]] = []
    for row in catalog.get("protocols", []):
        manifest_path = protocols_root / str(row["manifest"])
        manifest = _load(manifest_path)
        contract = manifest.get("endpoint_contract")
        if not isinstance(contract, dict) or contract.get("schema") != "PRAYCG_MatureEndpointContract_v1_0":
            raise ValueError(f"Missing mature endpoint contract: {manifest_path}")
        protocol_id = str(manifest["protocol_id"])
        gate_payload = {
            "schema": "PRAYCG_MatureEndpointGateStatus_v1_0",
            "protocol_id": protocol_id,
            "participant_pseudonym": "PSEUDONYM",
            "session_index": 1,
            "endpoint_id": contract["endpoint_id"],
            "gates": [
                {
                    "id": gate["id"],
                    "required": bool(gate.get("required", False)),
                    "rule": gate.get("rule", ""),
                    "status": "NOT_ASSESSED",
                    "evidence": None,
                    "notes": "",
                }
                for gate in contract.get("quality_gates", [])
            ],
            "notes": "Complete only from frozen run evidence. NOT_ASSESSED is fail-closed for required gates.",
        }
        analysis_payload = {
            "schema": "PRAYCG_MatureEndpointAnalysisStatus_v1_0",
            "protocol_id": protocol_id,
            "endpoint_id": contract["endpoint_id"],
            "primary_endpoint_status": "NOT_RUN",
            "preregistered": False,
            "adequately_powered": False,
            "multiplicity_controlled": False,
            "independent_replication": False,
            "special_measurement_gate_passed": False,
            "maximum_claim_without_special_measurement": contract["maximum_claim_without_special_measurement"],
            "effect_direction": None,
            "notes": "Records a separate frozen analysis; does not contain raw physiology or raise the manifest claim ceiling.",
        }
        gate_path = gate_root / f"{protocol_id}_gate_status_TEMPLATE.json"
        analysis_path = analysis_root / f"{protocol_id}_analysis_status_TEMPLATE.json"
        gate_path.write_text(json.dumps(gate_payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        analysis_path.write_text(json.dumps(analysis_payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        written.append({"protocol_id": protocol_id, "gate_template": str(gate_path), "analysis_template": str(analysis_path)})

    if len(written) != int(catalog.get("protocol_count", -1)):
        raise ValueError("Generated template count does not match mature catalog")
    return {"status": "PASS", "protocol_count": len(written), "written": written}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    default_root = Path(__file__).resolve().parents[2]
    parser.add_argument("--package-root", type=Path, default=default_root)
    args = parser.parse_args()
    print(json.dumps(generate(args.package_root.resolve()), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
