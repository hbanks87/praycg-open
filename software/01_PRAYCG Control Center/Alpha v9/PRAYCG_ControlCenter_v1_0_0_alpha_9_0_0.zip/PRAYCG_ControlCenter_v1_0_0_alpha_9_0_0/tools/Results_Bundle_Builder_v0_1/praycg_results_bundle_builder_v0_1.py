#!/usr/bin/env python3
"""Build a local, review-required PRAYCG results bundle without raw signals.

There is deliberately no network or upload implementation in alpha.8.  A bundle
must be built, reviewed for privacy/licensing/claims, and explicitly approved in
a future publishing layer.  This builder cannot perform the third step.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping


BUNDLE_SCHEMA = "PRAYCG_LocalResultsBundle_v0_1"
REVIEW_SCHEMA = "PRAYCG_LocalResultsBundleReview_v0_1"
RAW_EXTENSIONS = frozenset(
    {".xdf", ".edf", ".bdf", ".fif", ".set", ".vhdr", ".vmrk", ".eeg", ".cnt", ".raw"}
)
SAFE_DERIVED_EXTENSIONS = frozenset(
    {".csv", ".tsv", ".json", ".md", ".txt", ".png", ".jpg", ".jpeg", ".svg", ".html", ".pdf"}
)
SENSITIVE_KEYS = frozenset(
    {
        "participant_name", "participant_id", "participant_pseudonym", "operator", "locked_by",
        "recorded_by", "email", "phone", "address", "serial_number", "mac_address", "com_port",
    }
)
PATH_KEY_HINTS = ("path", "folder", "directory", "root", "entry_point")
WINDOWS_USER_PATH_RE = re.compile(r"(?i)[A-Z]:\\Users\\[^\\\s]+")
EMAIL_RE = re.compile(r"(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b")
BOUNDARY = (
    "This is a local review bundle, not a public release. The builder has no upload capability, "
    "excludes raw biosignal formats, redacts common identifiers and local paths from copied metadata, "
    "and requires a separate explicit privacy/licensing/claim review before any future publication."
)


class ResultsBundleError(RuntimeError):
    """Raised when a local bundle cannot be built safely."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    data = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def safe_slug(value: str) -> str:
    text = re.sub(r"[^a-zA-Z0-9._-]+", "-", str(value).strip()).strip("-._")
    return (text[:64] or "study").lower()


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ResultsBundleError(f"{path.name} must contain one JSON object")
    return value


def _redact_string(value: str, *, path_like: bool) -> str:
    text = EMAIL_RE.sub("<EMAIL_REDACTED>", WINDOWS_USER_PATH_RE.sub("<LOCAL_USER_PATH_REDACTED>", value))
    if path_like and (Path(text).is_absolute() or re.match(r"^[A-Za-z]:", text)):
        return f"<LOCAL_PATH_REDACTED>/{Path(text).name}"
    return text


def redact_metadata(value: Any, *, key: str = "") -> Any:
    key_folded = key.casefold()
    if key_folded in SENSITIVE_KEYS:
        return "<REDACTED>"
    if isinstance(value, dict):
        return {str(child): redact_metadata(item, key=str(child)) for child, item in value.items()}
    if isinstance(value, list):
        return [redact_metadata(item, key=key) for item in value]
    if isinstance(value, str):
        return _redact_string(value, path_like=any(token in key_folded for token in PATH_KEY_HINTS))
    return value


def _analysis_sources(workspace: Mapping[str, Any]) -> list[tuple[str, Path]]:
    sources: dict[str, tuple[str, Path]] = {}
    analysis = workspace.get("analysis", {}) if isinstance(workspace.get("analysis"), dict) else {}
    for row in analysis.get("outputs", []):
        if not isinstance(row, dict) or not row.get("path"):
            continue
        path = Path(str(row["path"])).expanduser().resolve(strict=False)
        label = str(row.get("kind") or row.get("module_id") or path.name)
        sources[str(path).casefold()] = (safe_slug(label), path)
    for row in analysis.get("executions", []):
        if not isinstance(row, dict):
            continue
        inventory = row.get("output_inventory") if isinstance(row.get("output_inventory"), dict) else {}
        if inventory.get("root"):
            path = Path(str(inventory["root"])).expanduser().resolve(strict=False)
            label = str(row.get("module_id") or path.name)
            sources[str(path).casefold()] = (safe_slug(label), path)
    return sorted(sources.values(), key=lambda item: (item[0], str(item[1]).casefold()))


def _copy_derived_outputs(workspace: Mapping[str, Any], destination: Path, *, maximum_files: int = 10000) -> tuple[list[dict[str, Any]], list[str]]:
    ledger: list[dict[str, Any]] = []
    exclusions: list[str] = []
    copied = 0
    for label, source in _analysis_sources(workspace):
        if not source.exists() or source.is_symlink():
            exclusions.append(f"missing or symbolic analysis output: {label}")
            continue
        files = [source] if source.is_file() else sorted((path for path in source.rglob("*") if path.is_file()), key=lambda path: path.as_posix().casefold())
        for path in files:
            if path.is_symlink():
                exclusions.append(f"symbolic file excluded: {label}/{path.name}")
                continue
            if path.suffix.casefold() in RAW_EXTENSIONS:
                exclusions.append(f"raw biosignal excluded: {label}/{path.name}")
                continue
            if path.suffix.casefold() not in SAFE_DERIVED_EXTENSIONS:
                exclusions.append(f"unsupported derived file excluded: {label}/{path.name}")
                continue
            copied += 1
            if copied > maximum_files:
                raise ResultsBundleError(f"Derived output selection exceeds {maximum_files} files")
            relative = Path(path.name) if source.is_file() else path.relative_to(source)
            target = destination / label / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if path.suffix.casefold() in {".json", ".md", ".txt", ".csv", ".tsv", ".html", ".svg"}:
                try:
                    text = path.read_text(encoding="utf-8-sig")
                    target.write_text(_redact_string(text, path_like=False), encoding="utf-8")
                except (UnicodeError, OSError):
                    exclusions.append(f"unreadable text output excluded: {label}/{relative.as_posix()}")
                    continue
            else:
                shutil.copy2(path, target)
            ledger.append({
                "source_class": label,
                "bundle_path": target.relative_to(destination.parent).as_posix(),
                "sha256": sha256_file(target),
                "byte_count": target.stat().st_size,
            })
    return ledger, exclusions


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _write_inventory_csv(path: Path, rows: Iterable[Mapping[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["source_class", "bundle_path", "sha256", "byte_count"])
        writer.writeheader()
        writer.writerows(rows)


def _dependency_graph(workspace: Mapping[str, Any]) -> dict[str, Any]:
    plan = workspace.get("analysis", {}).get("plan", {}) if isinstance(workspace.get("analysis"), dict) else {}
    nodes = []
    for row in plan.get("modules", []) if isinstance(plan, dict) else []:
        if isinstance(row, dict):
            nodes.append({
                "module_id": row.get("module_id"),
                "module_version": row.get("module_version"),
                "effective_role": row.get("effective_role"),
                "depends_on": row.get("depends_on", []),
                "descriptor_sha256": row.get("descriptor_sha256"),
            })
    return {
        "schema": "PRAYCG_ResultsDependencyGraph_v0_1",
        "plan_id": plan.get("plan_id") if isinstance(plan, dict) else None,
        "plan_lock_sha256": plan.get("plan_lock_sha256") if isinstance(plan, dict) else None,
        "nodes": nodes,
    }


def _results_report(workspace: Mapping[str, Any], manifest: Mapping[str, Any]) -> str:
    analysis = workspace.get("analysis", {}) if isinstance(workspace.get("analysis"), dict) else {}
    plan = analysis.get("plan", {}) if isinstance(analysis.get("plan"), dict) else {}
    modules = plan.get("modules", []) if isinstance(plan.get("modules"), list) else []
    grouped: dict[str, list[str]] = {}
    for row in modules:
        if isinstance(row, dict):
            grouped.setdefault(str(row.get("effective_role") or "UNCLASSIFIED"), []).append(str(row.get("display_name") or row.get("module_id")))
    lines = [
        f"# {workspace.get('display_name', 'PRAYCG Study')} — Local Results Review",
        "",
        f"Study ID: `{workspace.get('study_id')}`",
        f"Bundle ID: `{manifest.get('bundle_id')}`",
        f"Status: **{manifest.get('status')}**",
        "",
        "> This document inventories recorded outputs. It does not infer a scientific conclusion.",
        "",
        "## Protocol and provenance",
        "",
        f"- Protocol: {workspace.get('components', {}).get('protocol', {}).get('protocol_id') or 'not recorded'}",
        f"- Protocol version: {workspace.get('components', {}).get('protocol', {}).get('protocol_version') or 'not recorded'}",
        f"- Analysis plan: {plan.get('plan_id') or 'not locked'}",
        f"- Plan hash: `{plan.get('plan_lock_sha256') or 'not available'}`",
        "",
        "## Analysis roles",
        "",
    ]
    if grouped:
        for role in sorted(grouped):
            lines.append(f"### {role.replace('_', ' ').title()}")
            lines.append("")
            lines.extend(f"- {name}" for name in grouped[role])
            lines.append("")
    else:
        lines.extend(["No locked analysis modules were recorded.", ""])
    lines.extend([
        "## Exclusions and missingness",
        "",
        "Operator review required. Consult the copied QC records and derived tables; absence of a file is not evidence of zero.",
        "",
        "## Null and reversed results",
        "",
        "Operator review required. Null, reversed, incomplete, and ineligible findings must be reported rather than omitted.",
        "",
        "## Known limitations",
        "",
    ])
    limitations = workspace.get("known_limitations", [])
    lines.extend(f"- {item}" for item in limitations) if limitations else lines.append("- No operator-entered limitations were recorded; this is itself a review caution.")
    lines.extend([
        "",
        "## Publication boundary",
        "",
        BOUNDARY,
        "",
    ])
    return "\n".join(lines)


def _scan_no_raw(root: Path) -> list[str]:
    return [path.relative_to(root).as_posix() for path in root.rglob("*") if path.is_file() and path.suffix.casefold() in RAW_EXTENSIONS]


def _checksum_ledger(root: Path) -> list[dict[str, Any]]:
    rows = []
    for path in sorted((item for item in root.rglob("*") if item.is_file() and item.name != "SHA256SUMS.txt"), key=lambda item: item.as_posix().casefold()):
        rows.append({"path": path.relative_to(root).as_posix(), "sha256": sha256_file(path), "byte_count": path.stat().st_size})
    return rows


def build_results_bundle(
    workspace_path: Path | str,
    destination_root: Path | str,
    *,
    software_provenance: Mapping[str, Any] | None = None,
) -> tuple[Path, dict[str, Any]]:
    workspace_file = Path(workspace_path).expanduser().resolve(strict=True)
    workspace = _read_json(workspace_file)
    if workspace.get("schema") != "PRAYCG_StudyWorkspace_v0_1":
        raise ResultsBundleError("A v0.1 Study Workspace is required")
    study_id = str(workspace.get("study_id") or "")
    try:
        uuid.UUID(study_id)
    except (ValueError, TypeError, AttributeError) as exc:
        raise ResultsBundleError("Workspace study_id is not a full UUID") from exc
    plan = workspace.get("analysis", {}).get("plan", {})
    if not isinstance(plan, dict) or plan.get("status") != "LOCKED":
        raise ResultsBundleError("A locked analysis plan is required before building a results bundle")
    destination = Path(destination_root).expanduser().resolve(strict=False)
    destination.mkdir(parents=True, exist_ok=True)
    bundle_id = str(uuid.uuid4())
    final = destination / f"{safe_slug(workspace.get('display_name', 'study'))}--results--{bundle_id[:8]}"
    staging = destination / f".{final.name}.{uuid.uuid4().hex}.staging"
    if final.exists() or staging.exists():
        raise ResultsBundleError("Generated results-bundle path already exists")
    staging.mkdir()
    try:
        (staging / "derived_outputs").mkdir()
        copied, exclusions = _copy_derived_outputs(workspace, staging / "derived_outputs")
        redacted_workspace = redact_metadata(workspace)
        _write_json(staging / "provenance" / "study_workspace_redacted.json", redacted_workspace)
        _write_json(staging / "provenance" / "analysis_plan_lock_redacted.json", redact_metadata(plan))
        _write_json(staging / "provenance" / "software_provenance.json", redact_metadata(dict(software_provenance or {})))
        _write_json(staging / "provenance" / "qc_record_redacted.json", redact_metadata(workspace.get("qc", {})))
        graph = _dependency_graph(workspace)
        _write_json(staging / "manifests" / "dependency_graph.json", graph)
        _write_inventory_csv(staging / "tables" / "derived_output_inventory.csv", copied)
        review = {
            "schema": REVIEW_SCHEMA,
            "status": "NOT_REVIEWED",
            "privacy_review": "REQUIRED",
            "licensing_review": "REQUIRED",
            "claim_boundary_review": "REQUIRED",
            "publication_approval": "NOT_APPROVED",
            "upload_performed": False,
            "upload_capability": "NONE_LOCAL_ONLY",
            "boundary": BOUNDARY,
        }
        _write_json(staging / "review" / "LOCAL_REVIEW_STATUS.json", review)
        (staging / "review" / "README_REVIEW_REQUIRED.md").write_text(
            "# Local review required\n\n"
            "1. Review every included file for privacy and pseudonymization.\n"
            "2. Verify stimulus, code, figure, and third-party licensing.\n"
            "3. Verify confirmatory, secondary, exploratory, null, reversed, and ineligible findings are labeled.\n"
            "4. Record explicit publication approval in a future governed publishing layer.\n\n"
            "This alpha.8 builder cannot upload or publish data.\n",
            encoding="utf-8",
        )
        preliminary_manifest = {
            "schema": BUNDLE_SCHEMA,
            "version": "0.1.0",
            "bundle_id": bundle_id,
            "created_utc": utc_now(),
            "status": "LOCAL_REVIEW_REQUIRED",
            "study_id": study_id,
            "session_id": workspace.get("current_session", {}).get("session_id"),
            "protocol": redact_metadata(workspace.get("components", {}).get("protocol", {})),
            "stimulus_provenance": redact_metadata(workspace.get("components", {}).get("stimulus", {})),
            "hardware_and_timing_grades": redact_metadata(workspace.get("components", {}).get("hardware", {})),
            "analysis_plan_id": plan.get("plan_id"),
            "analysis_plan_lock_sha256": plan.get("plan_lock_sha256"),
            "analysis_roles": sorted({row.get("effective_role") for row in plan.get("modules", []) if isinstance(row, dict)}),
            "copied_derived_file_count": len(copied),
            "excluded_file_count": len(exclusions),
            "exclusions": exclusions,
            "null_and_reversed_results": "REQUIRED_OPERATOR_REVIEW",
            "missingness": "PRESERVED_AS_RECORDED_NOT_ZERO_FILLED",
            "raw_biosignal_file_count": 0,
            "upload_capability": "NONE_LOCAL_ONLY",
            "publication_approval": "NOT_APPROVED",
            "dependency_graph_sha256": canonical_sha256(graph),
            "known_limitations": redact_metadata(workspace.get("known_limitations", [])),
            "content_ledger_sha256": "",
            "boundary": BOUNDARY,
        }
        (staging / "reports").mkdir(exist_ok=True)
        (staging / "reports" / "results_review.md").write_text(
            _results_report(workspace, preliminary_manifest), encoding="utf-8"
        )
        content_rows = _checksum_ledger(staging)
        preliminary_manifest["content_ledger_sha256"] = canonical_sha256(content_rows)
        _write_json(staging / "manifests" / "results_bundle_manifest.json", preliminary_manifest)
        raw = _scan_no_raw(staging)
        if raw:
            raise ResultsBundleError("Raw biosignal files entered the bundle: " + ", ".join(raw))
        ledger = _checksum_ledger(staging)
        (staging / "SHA256SUMS.txt").write_text(
            "".join(f"{row['sha256']}  {row['path']}\n" for row in ledger), encoding="utf-8"
        )
        os.replace(staging, final)
        return final, preliminary_manifest
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def record_local_review(
    bundle_path: Path | str,
    *,
    reviewer: str,
    privacy_confirmed: bool,
    licensing_confirmed: bool,
    claim_boundaries_confirmed: bool,
) -> dict[str, Any]:
    root = Path(bundle_path).expanduser().resolve(strict=True)
    manifest = _read_json(root / "manifests" / "results_bundle_manifest.json")
    raw = _scan_no_raw(root)
    if raw:
        raise ResultsBundleError("Review cannot pass because raw biosignal files are present")
    if not str(reviewer).strip():
        raise ResultsBundleError("Reviewer name is required")
    confirmations = {
        "privacy_confirmed": bool(privacy_confirmed),
        "licensing_confirmed": bool(licensing_confirmed),
        "claim_boundaries_confirmed": bool(claim_boundaries_confirmed),
    }
    status = "PASS" if all(confirmations.values()) else "INCOMPLETE"
    record = {
        "schema": REVIEW_SCHEMA,
        "review_id": str(uuid.uuid4()),
        "bundle_id": manifest.get("bundle_id"),
        "reviewed_utc": utc_now(),
        "reviewer": str(reviewer).strip(),
        "status": status,
        **confirmations,
        "raw_biosignal_scan": {"status": "PASS", "file_count": 0},
        "publication_approval": "NOT_APPROVED",
        "upload_performed": False,
        "upload_capability": "NONE_LOCAL_ONLY",
        "boundary": BOUNDARY,
    }
    _write_json(root / "review" / "LOCAL_REVIEW_RECORD.json", record)
    ledger = _checksum_ledger(root)
    (root / "SHA256SUMS.txt").write_text(
        "".join(f"{row['sha256']}  {row['path']}\n" for row in ledger), encoding="utf-8"
    )
    return record


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PRAYCG local results bundle builder v0.1")
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--out-root", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    path, manifest = build_results_bundle(args.workspace, args.out_root)
    print(json.dumps({"path": str(path), "manifest": manifest}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
