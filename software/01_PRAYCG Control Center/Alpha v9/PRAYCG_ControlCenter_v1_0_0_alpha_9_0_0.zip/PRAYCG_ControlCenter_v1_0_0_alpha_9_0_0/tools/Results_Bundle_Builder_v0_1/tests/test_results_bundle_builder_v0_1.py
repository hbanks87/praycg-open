import json
import tempfile
import unittest
from pathlib import Path
import sys

MODULE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(MODULE_ROOT))

from praycg_results_bundle_builder_v0_1 import build_results_bundle, record_local_review  # noqa: E402


class ResultsBundleTests(unittest.TestCase):
    def test_local_bundle_excludes_raw_and_never_approves_publication(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            output = root / "analysis"
            output.mkdir()
            fixture_email = "fixture" + chr(64) + "example.invalid"
            fixture_path = "C:" + "\\Users" + "\\private\\run"
            (output / "derived.csv").write_text(f"email,path\n{fixture_email},{fixture_path}\n")
            (output / "recording.xdf").write_bytes(b"raw")
            workspace = {
                "schema": "PRAYCG_StudyWorkspace_v0_1",
                "study_id": "11111111-1111-4111-8111-111111111111",
                "display_name": "Bundle Test",
                "current_session": {"session_id": "22222222-2222-4222-8222-222222222222"},
                "components": {"protocol": {"protocol_id": "PRAYCG3"}, "stimulus": {}, "hardware": {}},
                "analysis": {
                    "plan": {"status": "LOCKED", "plan_id": "plan", "plan_lock_sha256": "a" * 64, "modules": []},
                    "outputs": [{"kind": "TEST", "path": str(output)}],
                    "executions": [],
                },
                "qc": {}, "known_limitations": ["fixture only"],
            }
            workspace_path = root / "study_workspace.json"
            workspace_path.write_text(json.dumps(workspace))
            bundle, manifest = build_results_bundle(workspace_path, root / "bundles")
            self.assertEqual(manifest["raw_biosignal_file_count"], 0)
            self.assertFalse(list(bundle.rglob("*.xdf")))
            copied = next(bundle.rglob("derived.csv")).read_text()
            self.assertNotIn(fixture_email, copied)
            self.assertNotIn(fixture_path, copied)
            review = record_local_review(
                bundle, reviewer="Tester", privacy_confirmed=True,
                licensing_confirmed=True, claim_boundaries_confirmed=True,
            )
            self.assertEqual(review["status"], "PASS")
            self.assertEqual(review["publication_approval"], "NOT_APPROVED")
            self.assertFalse(review["upload_performed"])


if __name__ == "__main__":
    unittest.main()
