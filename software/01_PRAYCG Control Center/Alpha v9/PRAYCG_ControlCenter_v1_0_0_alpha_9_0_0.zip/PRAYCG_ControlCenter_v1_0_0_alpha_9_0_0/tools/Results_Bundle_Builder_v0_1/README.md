# Local Results Bundle Builder v0.1

Creates a review-required, local-only results package from a locked Study
Workspace and analysis plan. It copies allowlisted derived outputs, excludes raw
biosignal formats, redacts common identifiers and local paths in text metadata,
records exclusions, preserves role labels and missingness boundaries, and writes
a complete checksum ledger.

Alpha.6.1 contains no upload or publication implementation.
