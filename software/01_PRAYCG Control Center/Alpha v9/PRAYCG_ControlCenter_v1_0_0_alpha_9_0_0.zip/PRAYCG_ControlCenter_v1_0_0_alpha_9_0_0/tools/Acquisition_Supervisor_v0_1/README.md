# PRAYCG Acquisition Supervisor v0.1

Observer mode watches stream identity, continuity, effective rate, gaps, and timestamp order without controlling acquisition processes. It is the default.

Managed recovery is an experimental, opt-in policy. It is limited to built-in modules, at most one restart per session, a cooldown, and a duplicate-process guard. This alpha does not fabricate missing samples or merge pre- and post-restart data into one uninterrupted segment. If a trusted launch command is absent, it records the problem and does not restart anything.
