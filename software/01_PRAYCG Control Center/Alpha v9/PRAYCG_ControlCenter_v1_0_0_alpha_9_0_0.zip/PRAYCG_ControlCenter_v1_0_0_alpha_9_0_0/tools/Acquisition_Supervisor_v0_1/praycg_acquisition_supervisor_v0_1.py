#!/usr/bin/env python3
"""Observer-first, profile-bound LSL acquisition supervisor for the current Control Center.

Carried alpha.2-named compatibility schemas remain intentional.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE_ROOT / "platform_core"))

from praycg_platform_core_v1_0_alpha_2 import (  # noqa: E402
    load_json,
    utc_now,
    validate_hardware_profile_identity,
    write_json,
)


def monitor(profile: dict[str, Any], policy: dict[str, Any], duration: float, managed_recovery: bool) -> dict[str, Any]:
    if managed_recovery and not policy.get("managed_recovery", {}).get("status") == "EXPERIMENTAL":
        raise ValueError("Managed recovery policy is not explicitly EXPERIMENTAL.")
    result: dict[str, Any] = {
        "schema": "PRAYCG_AcquisitionSupervisorReport_v0_2",
        "generated_utc": utc_now(),
        "hardware_profile_id": profile.get("profile_id"),
        "hardware_profile_canonical_sha256": profile.get("canonical_sha256"),
        "mode": "MANAGED_RECOVERY_EXPERIMENTAL" if managed_recovery else "OBSERVER_ONLY",
        "requested_duration_seconds": duration,
        "events": [],
        "segments": [],
        "status": "INELIGIBLE",
        "boundary": "Transport monitoring detects missing, stalled, gapped, or non-monotonic streams. It does not repair lost samples or establish signal validity.",
    }
    profile_validation = validate_hardware_profile_identity(profile)
    if profile_validation.status == "INELIGIBLE":
        result["events"].extend({
            "time_utc": utc_now(),
            "severity": "ERROR",
            "event": "PROFILE_IDENTITY_INVALID",
            "detail": detail,
        } for detail in profile_validation.errors)
        return result
    try:
        from pylsl import StreamInlet, resolve_byprop  # type: ignore
    except Exception as exc:
        result["events"].append({"time_utc": utc_now(), "severity": "ERROR", "event": "PYLSL_UNAVAILABLE", "detail": f"{type(exc).__name__}: {exc}"})
        return result
    expected: list[dict[str, Any]] = []
    for module in profile.get("modules", []):
        expected.extend(module.get("streams", []))
    state: dict[str, dict[str, Any]] = {}
    for stream in expected:
        name = str(stream.get("lsl_name", ""))
        source_id = str(stream.get("source_id", ""))
        key = f"{name}|{source_id}"
        matches = resolve_byprop("source_id", source_id, timeout=1.5) if source_id else []
        if not matches:
            # Several supported bridges use per-launch source IDs.  The stable
            # LSL name is the compatibility identity; a fallback is explicit in
            # the audit trail instead of silently declaring the stream missing.
            matches = resolve_byprop("name", name, timeout=1.5)
            if matches and source_id:
                result["events"].append({
                    "time_utc": utc_now(),
                    "severity": "CAUTION",
                    "event": "SOURCE_ID_FALLBACK_TO_STABLE_NAME",
                    "stream": key,
                })
        if not matches:
            state[key] = {"stream": stream, "inlet": None, "segment": 0, "samples": 0, "first": None, "last": None, "gaps": 0, "regressions": 0, "missing": True}
            result["events"].append({"time_utc": utc_now(), "severity": "ERROR", "event": "STREAM_MISSING", "stream": key})
        else:
            inlet = StreamInlet(matches[0], max_buflen=max(30, int(duration) + 5), recover=True)
            state[key] = {"stream": stream, "inlet": inlet, "segment": 1, "samples": 0, "first": None, "last": None, "gaps": 0, "regressions": 0, "missing": False}
            result["events"].append({"time_utc": utc_now(), "severity": "INFO", "event": "STREAM_CONNECTED", "stream": key, "segment": 1})
    started = time.monotonic()
    while time.monotonic() - started < max(0.1, duration):
        got_any = False
        for key, item in state.items():
            inlet = item["inlet"]
            if inlet is None:
                continue
            sample, stamp = inlet.pull_sample(timeout=0.0)
            if sample is None:
                continue
            got_any = True
            stamp = float(stamp)
            last = item["last"]
            nominal = float(item["stream"].get("nominal_srate", 0) or 0)
            if last is not None:
                delta = stamp - last
                if delta <= float(policy.get("timestamp_regression_tolerance_seconds", 0.0)):
                    item["regressions"] += 1
                    result["events"].append({"time_utc": utc_now(), "severity": "ERROR", "event": "TIMESTAMP_NON_MONOTONIC", "stream": key, "delta_seconds": delta, "segment": item["segment"]})
                if nominal > 0 and delta > float(policy.get("sample_gap_multiplier", 4.0)) / nominal:
                    item["gaps"] += 1
                    result["events"].append({"time_utc": utc_now(), "severity": "CAUTION", "event": "SAMPLE_GAP", "stream": key, "delta_seconds": delta, "segment": item["segment"]})
            item["first"] = stamp if item["first"] is None else item["first"]
            item["last"] = stamp
            item["samples"] += 1
        if not got_any:
            time.sleep(min(0.01, float(policy.get("poll_interval_seconds", 1.0))))
    for key, item in state.items():
        observed = item["last"] - item["first"] if item["first"] is not None and item["last"] is not None else 0.0
        rate = (item["samples"] - 1) / observed if item["samples"] > 1 and observed > 0 else 0.0
        nominal = float(item["stream"].get("nominal_srate", 0) or 0)
        rate_ok = nominal == 0 or (0.8 * nominal <= rate <= 1.2 * nominal)
        if not item["samples"] or item["regressions"]:
            segment_status = "INELIGIBLE"
        elif item["gaps"] or not rate_ok:
            segment_status = "CAUTION"
        else:
            segment_status = "PASS"
        result["segments"].append({
            "stream": key,
            "segment": item["segment"],
            "sample_count": item["samples"],
            "effective_rate_hz": rate,
            "gap_count": item["gaps"],
            "timestamp_regression_count": item["regressions"],
            "nominal_rate_hz": nominal,
            "rate_within_tolerance": rate_ok,
            "status": segment_status,
        })
    if managed_recovery:
        result["events"].append({"time_utc": utc_now(), "severity": "INFO", "event": "RECOVERY_NOT_TRIGGERED", "detail": "Managed recovery can authorize a trusted restart, but this observer invocation received no signed module launch command. No process was restarted."})
    statuses = {row["status"] for row in result["segments"]}
    result["status"] = (
        "INELIGIBLE" if not result["segments"] or "INELIGIBLE" in statuses
        else "CAUTION" if "CAUTION" in statuses
        else "PASS"
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Acquisition Supervisor v0.1")
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--policy", type=Path, default=PACKAGE_ROOT / "config" / "supervisor_policy_v0_1.json")
    parser.add_argument("--duration", type=float, default=30.0)
    parser.add_argument("--out", type=Path, default=Path.cwd() / "acquisition_supervisor")
    parser.add_argument("--enable-managed-recovery", action="store_true")
    args = parser.parse_args()
    profile = load_json(args.profile)
    policy = load_json(args.policy)
    args.out.mkdir(parents=True, exist_ok=True)
    result = monitor(profile, policy, args.duration, args.enable_managed_recovery)
    write_json(args.out / "supervisor_report.json", result)
    with (args.out / "supervisor_segments.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = (
            "stream", "segment", "sample_count", "effective_rate_hz",
            "gap_count", "timestamp_regression_count", "nominal_rate_hz",
            "rate_within_tolerance", "status",
        )
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(result["segments"])
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 4


if __name__ == "__main__":
    raise SystemExit(main())
