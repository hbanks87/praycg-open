#!/usr/bin/env python3
"""Presentation-independent hardware workflow model carried into PRAYCG Alpha 9.

The Control Center UI can use this module to implement the ordered flow

    Hardware Selection -> validated tray -> profile draft -> review/lock
    -> exact-module Connect & Launch actions

without duplicating the Hardware Forge catalog rules or the platform-core
profile and admission gates.  A workflow profile lock is deliberately a UI
selection lock only.  It does not create a session lock, ARM authority, or
acquisition authority.
"""
from __future__ import annotations

from collections import OrderedDict
from copy import deepcopy
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import sys
from typing import Any, Iterable, Mapping, Sequence


WORKFLOW_ROOT = Path(__file__).resolve().parent
PACKAGE_ROOT = WORKFLOW_ROOT.parents[1]
PLATFORM_CORE_ROOT = PACKAGE_ROOT / "platform_core"
HARDWARE_REGISTRY_ROOT = PACKAGE_ROOT / "config" / "hardware"
DEFAULT_ADAPTER_CATALOG = PACKAGE_ROOT / "config" / "hardware_adapter_catalog_v0_1.json"
FORGE_SOURCE = PACKAGE_ROOT / "tools" / "Hardware_Forge_v0_1" / "praycg_hardware_forge_v0_1.py"

if str(PLATFORM_CORE_ROOT) not in sys.path:
    sys.path.insert(0, str(PLATFORM_CORE_ROOT))

import praycg_platform_core_v1_0_alpha_4 as platform_core  # noqa: E402


def _load_hardware_forge() -> Any:
    module_name = "_praycg_hardware_forge_for_alpha5_workflow"
    existing = sys.modules.get(module_name)
    if existing is not None:
        return existing
    spec = importlib.util.spec_from_file_location(module_name, FORGE_SOURCE)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load the packaged Hardware Forge: {FORGE_SOURCE}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    previous = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    finally:
        sys.dont_write_bytecode = previous
    return module


hardware_forge = _load_hardware_forge()

WORKFLOW_SCHEMA = "PRAYCG_HardwareSelectionWorkflow_v0_1"
SELECTION_VALIDATION_SCHEMA = "PRAYCG_HardwareSelectionValidation_v0_1"
PROFILE_LOCK_SCHEMA = "PRAYCG_HardwareProfileUILock_v0_1"
LAUNCH_PLAN_SCHEMA = "PRAYCG_HardwareLaunchPlan_v0_1"
WORKFLOW_VERSION = "0.1.0"
CONTROL_CENTER_TARGET = "1.0.0-alpha.9.0.0"

# Ordered for direct notebook/tree rendering.  Canonical roles remain the
# platform-core roles; these are only human-facing selector groupings.
ROLE_GROUPS: "OrderedDict[str, dict[str, Any]]" = OrderedDict([
    ("eeg", {
        "display_name": "EEG",
        "description": "Primary or supplemental electroencephalography streams.",
        "canonical_roles": ("eeg",),
    }),
    ("cardiac", {
        "display_name": "Heart rate / ECG",
        "description": "ECG, beat-to-beat/RR interval, or heart-rate streams.",
        "canonical_roles": ("ecg", "rr_intervals", "heart_rate"),
    }),
    ("respiration", {
        "display_name": "Respiration",
        "description": "Respiration belt or other reviewed respiratory streams.",
        "canonical_roles": ("respiration",),
    }),
    ("eda_ppg", {
        "display_name": "EDA / PPG",
        "description": "Electrodermal activity and photoplethysmography streams.",
        "canonical_roles": ("eda", "ppg"),
    }),
    ("emg", {
        "display_name": "EMG",
        "description": "Muscle or artifact-sentinel streams.",
        "canonical_roles": ("emg",),
    }),
    ("eog", {
        "display_name": "EOG",
        "description": "Eye-movement or blink-sentinel streams.",
        "canonical_roles": ("eog",),
    }),
    ("timing", {
        "display_name": "ALS / markers",
        "description": "Ambient-light-sensor timing and event-marker streams.",
        "canonical_roles": ("als", "markers"),
    }),
    ("auxiliary", {
        "display_name": "Auxiliary / media",
        "description": "Optional analog auxiliary, video, and audio streams.",
        "canonical_roles": ("analog_aux", "video", "audio"),
    }),
])

ROLE_TO_GROUP = {
    role: group_id
    for group_id, definition in ROLE_GROUPS.items()
    for role in definition["canonical_roles"]
}


# These bindings describe existing Control Center handlers; they do not execute
# anything.  One process may publish more than one role, so the preferred UI is
# one button per process rather than one duplicate button per outlet.
LAUNCH_BINDINGS: dict[str, tuple[dict[str, Any], ...]] = {
    "openbci_cyton_daisy_eeg": ({
        "action_id": "launch_openbci_eeg",
        "label": "Launch OpenBCI EEG",
        "handler_key": "launch_brainflow_eeg_only",
        "ui_kind": "BUTTON",
        "roles": ("eeg", "markers"),
    },),
    "openbci_cyton_daisy_eeg_als": ({
        "action_id": "launch_openbci_eeg_als",
        "label": "Launch OpenBCI EEG + ALS",
        "handler_key": "launch_brainflow_eeg_als",
        "ui_kind": "BUTTON",
        "roles": ("eeg", "analog_aux", "als", "markers"),
    },),
    "polar_h10_rr": ({
        "action_id": "launch_polar_h10_rr",
        "label": "Launch Polar H10 RR",
        "handler_key": "launch_polar",
        "ui_kind": "BUTTON",
        "roles": ("rr_intervals",),
    },),
    "vernier_respiration": ({
        "action_id": "launch_vernier_respiration",
        "label": "Launch Vernier respiration",
        "handler_key": "launch_vernier",
        "ui_kind": "MENU_BUTTON",
        "roles": ("respiration",),
        "variants": (
            {"variant_id": "usb", "label": "USB", "handler_argument": "usb"},
            {"variant_id": "ble", "label": "Bluetooth", "handler_argument": "ble"},
        ),
    },),
    "generic_eda_ppg_serial": ({
        "action_id": "launch_generic_eda_ppg_serial",
        "label": "Launch EDA + PPG (serial)",
        "handler_key": "launch_generic_eda_ppg",
        "ui_kind": "BUTTON",
        "roles": ("eda", "ppg", "markers"),
    },),
    "generic_eda_ppg_udp": ({
        "action_id": "launch_generic_eda_ppg_udp",
        "label": "Launch EDA + PPG (UDP)",
        "handler_key": "launch_generic_eda_ppg",
        "ui_kind": "BUTTON",
        "roles": ("eda", "ppg", "markers"),
    },),
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _json_object(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def _write_json(path: Path, value: Mapping[str, Any]) -> None:
    path = Path(path).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    platform_core.write_json(path, value)


def _status(errors: Sequence[str], cautions: Sequence[str]) -> str:
    return "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS")


def _unique_strings(values: Iterable[Any]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for raw in values:
        value = str(raw or "").strip()
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _module_roles(module: Mapping[str, Any]) -> list[str]:
    roles: list[Any] = []
    for stream in module.get("streams", []):
        if not isinstance(stream, Mapping):
            continue
        roles.append(stream.get("canonical_role"))
        embedded = stream.get("embedded_roles", [])
        if isinstance(embedded, Sequence) and not isinstance(embedded, (str, bytes)):
            roles.extend(embedded)
    return _unique_strings(roles)


def normalize_role_group(value: str) -> str:
    key = str(value or "").strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "hr": "cardiac", "heart_rate": "cardiac", "ecg": "cardiac",
        "rr": "cardiac", "rr_intervals": "cardiac", "hr_ecg": "cardiac",
        "resp": "respiration", "resp_belt": "respiration",
        "eda": "eda_ppg", "ppg": "eda_ppg", "eda/ppg": "eda_ppg",
        "als": "timing", "markers": "timing", "als_markers": "timing",
        "analog_aux": "auxiliary", "video": "auxiliary", "audio": "auxiliary",
    }
    key = aliases.get(key, key)
    if key not in ROLE_GROUPS:
        raise ValueError(f"Unknown hardware role group: {value!r}")
    return key


def _role_groups_for(roles: Iterable[str]) -> list[str]:
    groups = {ROLE_TO_GROUP[role] for role in roles if role in ROLE_TO_GROUP}
    return [group for group in ROLE_GROUPS if group in groups]


def _choice_identity(choice: Mapping[str, Any]) -> str:
    fields = {
        "choice_id": choice.get("choice_id"),
        "source_kind": choice.get("source_kind"),
        "module_id": choice.get("module_id"),
        "module_path": choice.get("module_path"),
        "module_file_sha256": choice.get("module_file_sha256"),
        "module_canonical_sha256": choice.get("module_canonical_sha256"),
        "adapter_id": choice.get("adapter_id"),
        "route_id": choice.get("route_id"),
        "draft_module_id": choice.get("draft_module_id"),
        "admission_state": choice.get("admission_state"),
        "physical_validation": choice.get("physical_validation"),
        "launch_state": choice.get("launch_state"),
        "canonical_roles": choice.get("canonical_roles"),
    }
    return platform_core.sha256_json(fields)


def load_hardware_inventory(
    *,
    catalog_path: Path = DEFAULT_ADAPTER_CATALOG,
    registry_root: Path = HARDWARE_REGISTRY_ROOT,
) -> dict[str, Any]:
    """Load reviewed module definitions and catalog-only adapter routes.

    The two source classes intentionally remain distinguishable.  A catalog
    descriptor is visible for discovery but is never relabelled as a reviewed
    module definition.
    """
    errors: list[str] = []
    cautions: list[str] = []
    choices: list[dict[str, Any]] = []
    ids: set[str] = set()

    registry_root = Path(registry_root).resolve()
    expected_registry = HARDWARE_REGISTRY_ROOT.resolve()
    if registry_root != expected_registry:
        cautions.append(
            "A non-default registry root was supplied. Platform admission may reject legacy-carried definitions outside exact packaged paths."
        )
    if not registry_root.is_dir():
        errors.append(f"Reviewed hardware registry is missing: {registry_root}")
    else:
        for path in sorted(registry_root.glob("*.json"), key=lambda item: item.name.lower()):
            try:
                module = _json_object(path)
                report = platform_core.validate_hardware_module(module)
            except Exception as exc:
                errors.append(f"{path.name}: {type(exc).__name__}: {exc}")
                continue
            module_id = str(module.get("module_id") or "").strip()
            if not module_id:
                errors.append(f"{path.name}: module_id is missing")
                continue
            choice_id = f"module:{module_id}"
            if choice_id in ids:
                errors.append(f"Duplicate hardware choice: {choice_id}")
                continue
            ids.add(choice_id)
            roles = _module_roles(module)
            state = str(module.get("admission_state") or "LEGACY_CARRIED_UNGRADED")
            choice = {
                "choice_id": choice_id,
                "source_kind": "REVIEWED_MODULE",
                "display_name": str(module.get("display_name") or module_id),
                "provider_name": str(module.get("display_name") or module_id),
                "module_id": module_id,
                "module_path": str(path),
                "module_file_sha256": platform_core.sha256_file(path),
                "module_canonical_sha256": platform_core.sha256_json(module),
                "transport": str(module.get("transport") or "unspecified"),
                "trust_level": str(module.get("trust_level") or "UNRATED"),
                "admission_state": state,
                "physical_validation": str(module.get("physical_validation") or "UNRECORDED_LEGACY"),
                "launch_state": "PROFILE_DEPENDENT",
                "canonical_roles": roles,
                "role_groups": _role_groups_for(roles),
                "definition_validation": report.as_dict(),
                "claim_boundary": str(module.get("scientific_boundary") or ""),
            }
            choice["choice_identity_sha256"] = _choice_identity(choice)
            choices.append(choice)

    try:
        forge_report = hardware_forge.validate_catalog(Path(catalog_path))
    except Exception as exc:
        forge_report = {
            "status": "INELIGIBLE",
            "errors": [f"{type(exc).__name__}: {exc}"],
            "cautions": [],
        }
    if forge_report.get("status") == "INELIGIBLE":
        errors.extend(f"Adapter catalog: {item}" for item in forge_report.get("errors", []))
    else:
        cautions.extend(f"Adapter catalog: {item}" for item in forge_report.get("cautions", []))
        catalog, draft_catalog = hardware_forge.load_catalog(Path(catalog_path))
        draft_index = {
            str(row.get("draft_module_id")): row
            for row in draft_catalog.get("drafts", [])
            if isinstance(row, Mapping) and row.get("draft_module_id")
        }
        for adapter in catalog.get("adapters", []):
            if not isinstance(adapter, Mapping):
                continue
            adapter_id = str(adapter.get("adapter_id") or "").strip()
            for route in adapter.get("routes", []):
                if not isinstance(route, Mapping):
                    continue
                route_id = str(route.get("route_id") or "").strip()
                draft_id = str(route.get("draft_module_id") or "").strip()
                draft = draft_index.get(draft_id, {})
                proposed = draft.get("proposed_module", {}) if isinstance(draft, Mapping) else {}
                roles = _unique_strings([
                    *_module_roles(proposed if isinstance(proposed, Mapping) else {}),
                    *(route.get("role_defaults", {}).keys() if isinstance(route.get("role_defaults"), Mapping) else []),
                ])
                choice_id = f"adapter:{adapter_id}:{route_id}"
                if choice_id in ids:
                    errors.append(f"Duplicate hardware choice: {choice_id}")
                    continue
                ids.add(choice_id)
                choice = {
                    "choice_id": choice_id,
                    "source_kind": "ADAPTER_ROUTE_DRAFT",
                    "display_name": str(route.get("display_name") or route_id),
                    "provider_name": str(adapter.get("display_name") or adapter_id),
                    "adapter_id": adapter_id,
                    "route_id": route_id,
                    "draft_module_id": draft_id,
                    "module_id": str(proposed.get("module_id") or "") if isinstance(proposed, Mapping) else "",
                    "module_path": None,
                    "module_file_sha256": None,
                    "module_canonical_sha256": (
                        platform_core.sha256_json(proposed) if isinstance(proposed, Mapping) and proposed else None
                    ),
                    "transport": str(proposed.get("transport") or "unspecified") if isinstance(proposed, Mapping) else "unspecified",
                    "trust_level": str(proposed.get("trust_level") or "COMMUNITY_UNVERIFIED") if isinstance(proposed, Mapping) else "COMMUNITY_UNVERIFIED",
                    "admission_state": str(adapter.get("admission_state") or "UNKNOWN"),
                    "physical_validation": str(adapter.get("physical_validation") or "NOT_PERFORMED"),
                    "launch_state": str(route.get("launch_state") or "WITHHELD"),
                    "canonical_roles": roles,
                    "role_groups": _role_groups_for(roles),
                    "definition_validation": {
                        "status": str(forge_report.get("status") or "INELIGIBLE"),
                        "errors": [],
                        "cautions": list(route.get("limitations", [])),
                    },
                    "open_fields": list(draft.get("open_fields", [])) if isinstance(draft, Mapping) else [],
                    "claim_boundary": str(adapter.get("claim_boundary") or ""),
                    "source_archive": deepcopy(adapter.get("source_archive", {})),
                }
                choice["choice_identity_sha256"] = _choice_identity(choice)
                choices.append(choice)

    choices.sort(key=lambda row: (
        0 if row["source_kind"] == "REVIEWED_MODULE" else 1,
        row["provider_name"].lower(),
        row["display_name"].lower(),
        row["choice_id"],
    ))
    return {
        "schema": "PRAYCG_HardwareInventory_v0_1",
        "workflow_version": WORKFLOW_VERSION,
        "control_center_target": CONTROL_CENTER_TARGET,
        "generated_utc": utc_now(),
        "status": _status(errors, cautions),
        "choices": choices,
        "errors": errors,
        "cautions": cautions,
        "role_groups": [
            {"group_id": key, **deepcopy(value)} for key, value in ROLE_GROUPS.items()
        ],
        "authority_boundary": (
            "Inventory visibility and definition validation never establish physical validation, "
            "a hardware-profile lock, a session lock, ARM authority, or acquisition authority."
        ),
    }


def choices_for_role(
    role_group: str,
    *,
    inventory: Mapping[str, Any] | None = None,
    catalog_path: Path = DEFAULT_ADAPTER_CATALOG,
    registry_root: Path = HARDWARE_REGISTRY_ROOT,
) -> list[dict[str, Any]]:
    group_id = normalize_role_group(role_group)
    value = inventory or load_hardware_inventory(catalog_path=catalog_path, registry_root=registry_root)
    return [
        deepcopy(choice)
        for choice in value.get("choices", [])
        if isinstance(choice, Mapping) and group_id in choice.get("role_groups", [])
    ]


def hardware_tree_rows(
    *,
    inventory: Mapping[str, Any] | None = None,
    catalog_path: Path = DEFAULT_ADAPTER_CATALOG,
    registry_root: Path = HARDWARE_REGISTRY_ROOT,
) -> list[dict[str, Any]]:
    """Return flat parent-linked rows suitable for a Tk/Qt file navigator."""
    value = inventory or load_hardware_inventory(catalog_path=catalog_path, registry_root=registry_root)
    rows: list[dict[str, Any]] = []
    for group_id, definition in ROLE_GROUPS.items():
        group_row_id = f"group:{group_id}"
        rows.append({
            "row_id": group_row_id,
            "parent_id": "",
            "row_kind": "ROLE_GROUP",
            "label": definition["display_name"],
            "description": definition["description"],
            "selectable": False,
            "choice_id": None,
        })
        adapter_parents: set[str] = set()
        for choice in choices_for_role(group_id, inventory=value):
            if choice["source_kind"] == "REVIEWED_MODULE":
                rows.append({
                    "row_id": f"{group_row_id}:module:{choice['module_id']}",
                    "parent_id": group_row_id,
                    "row_kind": "REVIEWED_MODULE",
                    "label": choice["display_name"],
                    "description": choice["transport"],
                    "selectable": True,
                    "choice_id": choice["choice_id"],
                    "admission_state": choice["admission_state"],
                    "physical_validation": choice["physical_validation"],
                    "launch_state": choice["launch_state"],
                    "canonical_roles": deepcopy(choice["canonical_roles"]),
                })
                continue
            adapter_id = str(choice["adapter_id"])
            adapter_row_id = f"{group_row_id}:adapter:{adapter_id}"
            if adapter_row_id not in adapter_parents:
                adapter_parents.add(adapter_row_id)
                rows.append({
                    "row_id": adapter_row_id,
                    "parent_id": group_row_id,
                    "row_kind": "ADAPTER",
                    "label": choice["provider_name"],
                    "description": "Adapter catalog entry; expand to choose a route.",
                    "selectable": False,
                    "choice_id": None,
                    "admission_state": choice["admission_state"],
                    "physical_validation": choice["physical_validation"],
                })
            rows.append({
                "row_id": f"{adapter_row_id}:route:{choice['route_id']}",
                "parent_id": adapter_row_id,
                "row_kind": "ADAPTER_ROUTE",
                "label": choice["display_name"],
                "description": choice["transport"],
                "selectable": True,
                "choice_id": choice["choice_id"],
                "admission_state": choice["admission_state"],
                "physical_validation": choice["physical_validation"],
                "launch_state": choice["launch_state"],
                "canonical_roles": deepcopy(choice["canonical_roles"]),
            })
    return rows


def validate_role_selection(
    role_group: str,
    choice_id: str,
    *,
    intended_use: str = "HUMAN_CONNECTED",
    inventory: Mapping[str, Any] | None = None,
    catalog_path: Path = DEFAULT_ADAPTER_CATALOG,
    registry_root: Path = HARDWARE_REGISTRY_ROOT,
) -> dict[str, Any]:
    """Validate one role choice without claiming a live-device test."""
    group_id = normalize_role_group(role_group)
    use = str(intended_use or "HUMAN_CONNECTED").strip().upper()
    if use not in {"HUMAN_CONNECTED", "SIMULATION"}:
        raise ValueError("intended_use must be HUMAN_CONNECTED or SIMULATION")
    value = inventory or load_hardware_inventory(catalog_path=catalog_path, registry_root=registry_root)
    errors: list[str] = []
    cautions: list[str] = []
    information: list[str] = []
    choice = next(
        (row for row in value.get("choices", []) if isinstance(row, Mapping) and row.get("choice_id") == choice_id),
        None,
    )
    if choice is None:
        errors.append(f"Unknown hardware choice: {choice_id}")
    elif group_id not in choice.get("role_groups", []):
        errors.append(
            f"{choice_id} does not provide a canonical role in the {ROLE_GROUPS[group_id]['display_name']} group."
        )
    elif choice.get("source_kind") == "REVIEWED_MODULE":
        path = Path(str(choice.get("module_path") or ""))
        try:
            module = _json_object(path)
            report = platform_core.validate_hardware_module(module)
            errors.extend(report.errors)
            cautions.extend(report.cautions)
            information.extend(report.information)
            if platform_core.sha256_file(path) != choice.get("module_file_sha256"):
                errors.append("The hardware module file changed after inventory loading.")
            if platform_core.sha256_json(module) != choice.get("module_canonical_sha256"):
                errors.append("The hardware module canonical identity changed after inventory loading.")
            admission = module.get("admission_state")
            if admission is None:
                exact_check = getattr(platform_core, "_is_exact_carried_module_path", None)
                if exact_check is None or not exact_check(str(module.get("module_id") or ""), path):
                    errors.append("Missing admission metadata is allowed only for an exact packaged legacy-carried module.")
                else:
                    cautions.append(
                        "This exact packaged legacy module is carried for compatibility but remains admission-ungraded."
                    )
            else:
                admission_check = getattr(platform_core, "_admission_findings", None)
                if admission_check is None:
                    errors.append("The platform admission validator is unavailable.")
                else:
                    admission_errors, admission_cautions = admission_check(module, intended_use=use)
                    errors.extend(admission_errors)
                    cautions.extend(admission_cautions)
        except Exception as exc:
            errors.append(f"Could not validate reviewed module: {type(exc).__name__}: {exc}")
    else:
        admission = str(choice.get("admission_state") or "UNKNOWN")
        physical = str(choice.get("physical_validation") or "NOT_PERFORMED")
        route_state = str(choice.get("launch_state") or "WITHHELD")
        information.append(
            "The adapter and route metadata passed the Hardware Forge catalog validator, but no reviewed module file is selected."
        )
        if admission == "QUARANTINED":
            errors.append("The adapter is quarantined and cannot enter a hardware profile.")
        elif admission == "CATALOG_ONLY":
            errors.append("CATALOG_ONLY routes are discoverable drafts and cannot enter a reviewed hardware profile.")
        elif use == "HUMAN_CONNECTED" and admission != "HUMAN_CONNECTED_APPROVED":
            errors.append(f"{admission} is not eligible for a human-connected profile.")
        elif use == "SIMULATION" and admission != "SIMULATOR_VERIFIED":
            errors.append(f"{admission} is not eligible for a simulation-only profile.")
        # Even an admission label on the catalog is not a reviewed module file.
        errors.append(
            "Complete and review a packaged hardware-module definition before this catalog route can enter the validated tray."
        )
        if route_state == "WITHHELD":
            cautions.append("The catalog route launch_state is WITHHELD.")
        elif route_state == "DIAGNOSTIC_ONLY":
            cautions.append("The catalog route is diagnostic-only and cannot satisfy participant acquisition.")
        if physical == "NOT_PERFORMED":
            cautions.append("No physical-device validation has been performed.")

    errors = _unique_strings(errors)
    cautions = _unique_strings(cautions)
    information = _unique_strings(information)
    eligible = bool(choice is not None and choice.get("source_kind") == "REVIEWED_MODULE" and not errors)
    return {
        "schema": SELECTION_VALIDATION_SCHEMA,
        "workflow_version": WORKFLOW_VERSION,
        "control_center_target": CONTROL_CENTER_TARGET,
        "generated_utc": utc_now(),
        "status": _status(errors, cautions),
        "selection_state": "VALIDATED_FOR_PROFILE" if eligible else "NOT_PROFILE_ELIGIBLE",
        "profile_eligible": eligible,
        "selected_role_group": group_id,
        "selected_role_group_label": ROLE_GROUPS[group_id]["display_name"],
        "intended_use": use,
        "choice_id": choice_id,
        "choice_identity_sha256": choice.get("choice_identity_sha256") if choice else None,
        "module_id": choice.get("module_id") if choice else None,
        "source_kind": choice.get("source_kind") if choice else None,
        "canonical_roles": deepcopy(choice.get("canonical_roles", [])) if choice else [],
        "errors": errors,
        "cautions": cautions,
        "information": information,
        "validation_scope": "DEFINITION_IDENTITY_AND_PROFILE_ADMISSION_ONLY",
        "physical_device_test_performed": False,
        "runtime_authority": False,
        "arm_authority": False,
        "acquisition_authority": False,
        "claim_boundary": (
            "VALIDATED_FOR_PROFILE means the definition and admission gate can enter profile construction. "
            "It is not a live signal check, electrical-safety certification, medical validation, or scientific validation."
        ),
    }


class HardwareWorkflowModel:
    """Small state model backing Selection, Profile, and Connect/Launch panes."""

    def __init__(
        self,
        *,
        intended_use: str = "HUMAN_CONNECTED",
        catalog_path: Path = DEFAULT_ADAPTER_CATALOG,
        registry_root: Path = HARDWARE_REGISTRY_ROOT,
    ) -> None:
        use = str(intended_use or "HUMAN_CONNECTED").strip().upper()
        if use not in {"HUMAN_CONNECTED", "SIMULATION"}:
            raise ValueError("intended_use must be HUMAN_CONNECTED or SIMULATION")
        self.intended_use = use
        self.catalog_path = Path(catalog_path)
        self.registry_root = Path(registry_root)
        self.inventory = load_hardware_inventory(
            catalog_path=self.catalog_path,
            registry_root=self.registry_root,
        )
        self._tickets_by_group: dict[str, dict[str, Any]] = {}

    def refresh(self) -> dict[str, Any]:
        self.inventory = load_hardware_inventory(
            catalog_path=self.catalog_path,
            registry_root=self.registry_root,
        )
        return deepcopy(self.inventory)

    def tree_rows(self) -> list[dict[str, Any]]:
        return hardware_tree_rows(inventory=self.inventory)

    def choices_for_role(self, role_group: str) -> list[dict[str, Any]]:
        return choices_for_role(role_group, inventory=self.inventory)

    def validate_and_select(self, role_group: str, choice_id: str) -> dict[str, Any]:
        group_id = normalize_role_group(role_group)
        report = validate_role_selection(
            group_id,
            choice_id,
            intended_use=self.intended_use,
            inventory=self.inventory,
        )
        if report["profile_eligible"]:
            self._tickets_by_group[group_id] = deepcopy(report)
            report["added_to_tray"] = True
        else:
            # A failed replacement must not erase a previously valid choice.
            report["added_to_tray"] = False
        return report

    def remove_selection(self, role_group: str) -> None:
        self._tickets_by_group.pop(normalize_role_group(role_group), None)

    def clear_selections(self) -> None:
        self._tickets_by_group.clear()

    def tray_rows(self) -> list[dict[str, Any]]:
        """Aggregate repeated role selections into one row per physical module."""
        aggregated: dict[str, dict[str, Any]] = {}
        for group_id, ticket in self._tickets_by_group.items():
            choice_id = str(ticket["choice_id"])
            row = aggregated.setdefault(choice_id, {
                "choice_id": choice_id,
                "module_id": ticket.get("module_id"),
                "choice_identity_sha256": ticket.get("choice_identity_sha256"),
                "selected_for_groups": [],
                "provided_roles": deepcopy(ticket.get("canonical_roles", [])),
                "validation_status": ticket.get("status"),
                "profile_eligible": True,
                "physical_device_test_performed": False,
            })
            row["selected_for_groups"].append(group_id)
        order = {key: index for index, key in enumerate(ROLE_GROUPS)}
        rows = list(aggregated.values())
        for row in rows:
            row["selected_for_groups"].sort(key=lambda item: order[item])
        rows.sort(key=lambda row: min(order[item] for item in row["selected_for_groups"]))
        return rows

    def _validated_module_paths(self) -> list[Path]:
        if not self._tickets_by_group:
            raise ValueError("Validate at least one hardware selection before creating a profile draft.")
        choice_index = {
            str(row.get("choice_id")): row
            for row in self.inventory.get("choices", [])
            if isinstance(row, Mapping)
        }
        paths: list[Path] = []
        seen: set[str] = set()
        for group_id, ticket in self._tickets_by_group.items():
            current = validate_role_selection(
                group_id,
                str(ticket["choice_id"]),
                intended_use=self.intended_use,
                inventory=self.inventory,
            )
            if not current["profile_eligible"]:
                raise ValueError(
                    f"Hardware selection {ticket['choice_id']} is no longer profile-eligible: "
                    + "; ".join(current["errors"])
                )
            if current.get("choice_identity_sha256") != ticket.get("choice_identity_sha256"):
                raise ValueError(f"Hardware selection identity changed: {ticket['choice_id']}")
            choice = choice_index[str(ticket["choice_id"])]
            path = Path(str(choice.get("module_path") or "")).resolve()
            key = str(path).lower()
            if key not in seen:
                seen.add(key)
                paths.append(path)
        return paths

    def create_profile_draft(
        self,
        output_path: Path,
        *,
        profile_id: str,
        role_assignments: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        """Build the canonical profile shape without recording human approval."""
        profile = platform_core.build_hardware_profile(
            self._validated_module_paths(),
            Path(output_path),
            profile_id=profile_id,
            reviewed_by="UNRECORDED",
            role_assignments=role_assignments,
            intended_use=self.intended_use,
        )
        if profile.get("status") != "DRAFT_NOT_APPROVED":
            raise RuntimeError("Draft construction unexpectedly created an approved profile.")
        return profile


def _profile_hash(mapping: Mapping[str, Any]) -> str:
    return platform_core.sha256_json({
        key: deepcopy(value)
        for key, value in mapping.items()
        if key != "canonical_sha256"
    })


def _module_paths_from_draft(draft: Mapping[str, Any]) -> list[Path]:
    errors: list[str] = []
    paths: list[Path] = []
    seen: set[str] = set()
    for selected in draft.get("modules", []):
        if not isinstance(selected, Mapping):
            errors.append("Draft contains a malformed module selection.")
            continue
        path = Path(str(selected.get("path") or "")).resolve()
        module_id = str(selected.get("module_id") or "unknown")
        if not path.is_file():
            errors.append(f"Selected module path is missing for {module_id}.")
            continue
        observed_file = platform_core.sha256_file(path)
        observed_canonical = platform_core.sha256_json(_json_object(path))
        if observed_file != selected.get("module_file_sha256"):
            errors.append(f"Selected module file changed for {module_id}.")
        if observed_canonical != selected.get("module_canonical_sha256"):
            errors.append(f"Selected module canonical identity changed for {module_id}.")
        key = str(path).lower()
        if key not in seen:
            seen.add(key)
            paths.append(path)
    if errors:
        raise ValueError("Draft identity validation failed: " + "; ".join(errors))
    if not paths:
        raise ValueError("Draft does not contain a hardware module.")
    return paths


def review_hardware_profile_draft(
    draft_path: Path,
    approved_output_path: Path,
    *,
    reviewed_by: str,
    role_assignments: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Rebuild an identity-checked draft through the canonical approval path."""
    draft_path = Path(draft_path).resolve()
    draft = _json_object(draft_path)
    if draft.get("schema") != platform_core.PROFILE_SCHEMA:
        raise ValueError("Draft is not a current hardware profile schema.")
    if draft.get("status") != "DRAFT_NOT_APPROVED":
        raise ValueError("Only an unapproved hardware profile draft may enter this review step.")
    if draft.get("canonical_sha256") != _profile_hash(draft):
        raise ValueError("Draft canonical identity is missing or has changed.")
    paths = _module_paths_from_draft(draft)
    return platform_core.build_hardware_profile(
        paths,
        Path(approved_output_path),
        profile_id=str(draft.get("profile_id") or "hardware_profile"),
        reviewed_by=reviewed_by,
        role_assignments=role_assignments,
        intended_use=str(draft.get("intended_use") or "HUMAN_CONNECTED"),
    )


def _lock_hash(mapping: Mapping[str, Any]) -> str:
    return platform_core.sha256_json({
        key: deepcopy(value)
        for key, value in mapping.items()
        if key != "lock_sha256"
    })


def lock_hardware_profile(
    profile_path: Path,
    *,
    output_path: Path | None = None,
) -> dict[str, Any]:
    """Lock one approved profile for Connect & Launch UI derivation only."""
    profile_path = Path(profile_path).resolve()
    profile = _json_object(profile_path)
    report = platform_core.validate_hardware_profile_identity(profile, profile_path=profile_path)
    if report.status == "INELIGIBLE":
        raise ValueError("Hardware profile is not lockable: " + "; ".join(report.errors))
    profile_cautions = _unique_strings([
        *report.cautions,
        *(profile.get("cautions", []) if isinstance(profile.get("cautions"), list) else []),
    ])
    selected_modules = [
        {
            "module_id": row.get("module_id"),
            "module_file_sha256": row.get("module_file_sha256") or row.get("sha256"),
            "module_canonical_sha256": row.get("module_canonical_sha256"),
        }
        for row in profile.get("modules", [])
        if isinstance(row, Mapping)
    ]
    lock = {
        "schema": PROFILE_LOCK_SCHEMA,
        "workflow_version": WORKFLOW_VERSION,
        "control_center_target": CONTROL_CENTER_TARGET,
        "created_utc": utc_now(),
        "status": "LOCKED_FOR_CONNECT_AND_LAUNCH",
        "lock_scope": "CONTROL_CENTER_HARDWARE_UI_SELECTION_ONLY",
        "profile_path": str(profile_path),
        "profile_file_sha256": platform_core.sha256_file(profile_path),
        "profile_canonical_sha256": profile.get("canonical_sha256"),
        "profile_id": profile.get("profile_id"),
        "reviewed_by": profile.get("reviewed_by"),
        "validation_status": "CAUTION" if profile_cautions else report.status,
        "profile_cautions": profile_cautions,
        "selected_modules": selected_modules,
        "primary_role_sources": deepcopy(profile.get("primary_role_sources", {})),
        "runtime_authority": False,
        "session_lock_authority": False,
        "arm_authority": False,
        "acquisition_authority": False,
        "authority_boundary": (
            "This lock freezes which reviewed hardware profile supplies Connect & Launch controls. "
            "The canonical session-lock, preflight, ARM, owner-lease, and acquisition gates remain separate and mandatory."
        ),
    }
    lock["lock_sha256"] = _lock_hash(lock)
    if output_path is not None:
        _write_json(Path(output_path), lock)
    return lock


def validate_hardware_profile_lock(
    lock: Mapping[str, Any],
    *,
    profile_path: Path | None = None,
) -> dict[str, Any]:
    errors: list[str] = []
    cautions: list[str] = []
    if lock.get("schema") != PROFILE_LOCK_SCHEMA:
        errors.append("Hardware workflow lock schema is not recognized.")
    if lock.get("status") != "LOCKED_FOR_CONNECT_AND_LAUNCH":
        errors.append("Hardware workflow lock is not active.")
    for field in ("runtime_authority", "session_lock_authority", "arm_authority", "acquisition_authority"):
        if lock.get(field) is not False:
            errors.append(f"Hardware workflow lock must set {field}=false.")
    if lock.get("lock_sha256") != _lock_hash(lock):
        errors.append("Hardware workflow lock canonical identity is missing or has changed.")
    recorded_path = Path(str(lock.get("profile_path") or "")).resolve()
    requested_path = Path(profile_path).resolve() if profile_path is not None else recorded_path
    if requested_path != recorded_path:
        errors.append("Requested profile path does not match the path bound into the workflow lock.")
    if not requested_path.is_file():
        errors.append("The locked hardware profile file is missing.")
        profile: dict[str, Any] = {}
    else:
        profile = _json_object(requested_path)
        if platform_core.sha256_file(requested_path) != lock.get("profile_file_sha256"):
            errors.append("The locked hardware profile file changed after locking.")
        if profile.get("canonical_sha256") != lock.get("profile_canonical_sha256"):
            errors.append("The locked hardware profile canonical identity changed after locking.")
        identity = platform_core.validate_hardware_profile_identity(profile, profile_path=requested_path)
        errors.extend(identity.errors)
        cautions.extend(identity.cautions)
        recorded_cautions = profile.get("cautions", []) if isinstance(profile.get("cautions"), list) else []
        cautions.extend(str(item) for item in recorded_cautions)
        if _unique_strings(recorded_cautions) != lock.get("profile_cautions", []):
            errors.append("The locked profile-caution ledger does not match the reviewed profile.")
        observed_modules = [
            {
                "module_id": row.get("module_id"),
                "module_file_sha256": row.get("module_file_sha256") or row.get("sha256"),
                "module_canonical_sha256": row.get("module_canonical_sha256"),
            }
            for row in profile.get("modules", [])
            if isinstance(row, Mapping)
        ]
        if observed_modules != lock.get("selected_modules"):
            errors.append("The locked module ledger does not match the reviewed profile.")
        if profile.get("primary_role_sources", {}) != lock.get("primary_role_sources", {}):
            errors.append("The locked primary-role ledger does not match the reviewed profile.")
    errors = _unique_strings(errors)
    cautions = _unique_strings(cautions)
    return {
        "status": _status(errors, cautions),
        "errors": errors,
        "cautions": cautions,
        "profile": profile,
    }


def derive_launch_actions(
    profile_path: Path,
    profile_lock: Mapping[str, Any],
) -> dict[str, Any]:
    """Return only actions bound to exact modules in a valid profile UI lock."""
    validation = validate_hardware_profile_lock(profile_lock, profile_path=profile_path)
    if validation["status"] == "INELIGIBLE":
        return {
            "schema": LAUNCH_PLAN_SCHEMA,
            "workflow_version": WORKFLOW_VERSION,
            "control_center_target": CONTROL_CENTER_TARGET,
            "generated_utc": utc_now(),
            "status": "INELIGIBLE",
            "actions": [],
            "unavailable_modules": [],
            "errors": validation["errors"],
            "cautions": validation["cautions"],
            "authority_boundary": "No launch action is exposed from an invalid or stale hardware-profile lock.",
        }
    profile = validation["profile"]
    actions: list[dict[str, Any]] = []
    unavailable: list[dict[str, Any]] = []
    for selected in profile.get("modules", []):
        if not isinstance(selected, Mapping):
            continue
        module_id = str(selected.get("module_id") or "")
        bindings = LAUNCH_BINDINGS.get(module_id, ())
        if not bindings:
            unavailable.append({
                "module_id": module_id,
                "reason": "No reviewed Control Center launch binding exists for this exact module.",
                "expected_roles": _module_roles(selected),
            })
            continue
        available_roles = set(_module_roles(selected))
        for binding in bindings:
            declared_roles = [role for role in binding.get("roles", ()) if role in available_roles]
            action = {
                "action_id": binding["action_id"],
                "label": binding["label"],
                "handler_key": binding["handler_key"],
                "ui_kind": binding["ui_kind"],
                "module_id": module_id,
                "module_file_sha256": selected.get("module_file_sha256") or selected.get("sha256"),
                "canonical_roles": declared_roles,
                "role_groups": _role_groups_for(declared_roles),
                "variants": [deepcopy(row) for row in binding.get("variants", ())],
                "enabled": True,
                "requires_valid_profile_lock": True,
                "starts_stream_only": True,
                "session_lock_authority": False,
                "arm_authority": False,
                "acquisition_authority": False,
            }
            actions.append(action)
    actions.sort(key=lambda row: (
        min((list(ROLE_GROUPS).index(group) for group in row["role_groups"]), default=999),
        row["label"].lower(),
    ))
    cautions = list(validation["cautions"])
    if unavailable:
        cautions.append(
            "Some exact locked modules have no packaged launch binding; no placeholder or guessed launch button was created."
        )
    return {
        "schema": LAUNCH_PLAN_SCHEMA,
        "workflow_version": WORKFLOW_VERSION,
        "control_center_target": CONTROL_CENTER_TARGET,
        "generated_utc": utc_now(),
        "status": "CAUTION" if cautions else "PASS",
        "profile_id": profile.get("profile_id"),
        "profile_lock_sha256": profile_lock.get("lock_sha256"),
        "actions": actions,
        "unavailable_modules": unavailable,
        "errors": [],
        "cautions": _unique_strings(cautions),
        "button_policy": (
            "Render one button per launch process. Use a menu button only when one locked module has explicit transport variants."
        ),
        "authority_boundary": (
            "Launch actions start only the exact reviewed stream bridge. They do not satisfy live preflight, "
            "create a session lock, ARM the runner, or grant acquisition authority."
        ),
    }


def workflow_snapshot(model: HardwareWorkflowModel) -> dict[str, Any]:
    """Return a JSON-friendly state snapshot for UI rendering and tests."""
    return {
        "schema": WORKFLOW_SCHEMA,
        "workflow_version": WORKFLOW_VERSION,
        "control_center_target": CONTROL_CENTER_TARGET,
        "generated_utc": utc_now(),
        "intended_use": model.intended_use,
        "inventory_status": model.inventory.get("status"),
        "validated_selection_tray": model.tray_rows(),
        "next_step": "CREATE_PROFILE_DRAFT" if model.tray_rows() else "SELECT_AND_VALIDATE_HARDWARE",
        "runtime_authority": False,
        "arm_authority": False,
        "acquisition_authority": False,
    }
