from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "tools" / "Hardware_Workflow_v0_1" / "praycg_hardware_workflow_v0_1.py"
SPEC = importlib.util.spec_from_file_location("praycg_hardware_workflow_v0_1", SOURCE)
assert SPEC and SPEC.loader
workflow = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(workflow)


class HardwareWorkflowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.inventory = workflow.load_hardware_inventory()

    def test_inventory_federates_reviewed_modules_and_adapter_drafts(self) -> None:
        self.assertNotEqual("INELIGIBLE", self.inventory["status"], self.inventory)
        kinds = {row["source_kind"] for row in self.inventory["choices"]}
        self.assertEqual({"REVIEWED_MODULE", "ADAPTER_ROUTE_DRAFT"}, kinds)
        self.assertGreaterEqual(len(self.inventory["choices"]), 20)

    def test_tree_rows_are_parent_linked_and_route_nested(self) -> None:
        rows = workflow.hardware_tree_rows(inventory=self.inventory)
        row_ids = {row["row_id"] for row in rows}
        roots = [row for row in rows if row["row_kind"] == "ROLE_GROUP"]
        self.assertEqual(list(workflow.ROLE_GROUPS), [row["row_id"].split(":", 1)[1] for row in roots])
        for row in rows:
            if row["parent_id"]:
                self.assertIn(row["parent_id"], row_ids)
        route = next(row for row in rows if row["row_kind"] == "ADAPTER_ROUTE")
        parent = next(row for row in rows if row["row_id"] == route["parent_id"])
        self.assertEqual("ADAPTER", parent["row_kind"])

    def test_per_role_choices_are_filtered_by_canonical_roles(self) -> None:
        eeg = workflow.choices_for_role("EEG", inventory=self.inventory)
        cardiac = workflow.choices_for_role("HR", inventory=self.inventory)
        self.assertTrue(any(row["module_id"] == "openbci_cyton_daisy_eeg" for row in eeg))
        self.assertTrue(any(row["module_id"] == "polar_h10_rr" for row in cardiac))
        self.assertTrue(all("eeg" in row["canonical_roles"] for row in eeg))
        self.assertTrue(all(set(row["canonical_roles"]) & {"ecg", "rr_intervals", "heart_rate"} for row in cardiac))

    def test_exact_carried_module_is_profile_eligible_with_visible_caution(self) -> None:
        result = workflow.validate_role_selection(
            "eeg", "module:openbci_cyton_daisy_eeg", inventory=self.inventory
        )
        self.assertTrue(result["profile_eligible"], result)
        self.assertEqual("VALIDATED_FOR_PROFILE", result["selection_state"])
        self.assertEqual("CAUTION", result["status"])
        self.assertFalse(result["physical_device_test_performed"])
        self.assertFalse(result["acquisition_authority"])

    def test_role_mismatch_is_rejected(self) -> None:
        result = workflow.validate_role_selection(
            "respiration", "module:openbci_cyton_daisy_eeg", inventory=self.inventory
        )
        self.assertFalse(result["profile_eligible"])
        self.assertEqual("INELIGIBLE", result["status"])
        self.assertTrue(any("does not provide" in item for item in result["errors"]))

    def test_catalog_and_quarantined_routes_do_not_enter_tray(self) -> None:
        model = workflow.HardwareWorkflowModel()
        catalog_result = model.validate_and_select("eeg", "adapter:muse_brainflow:muse_2_brainflow")
        quarantine = model.validate_and_select("emg", "adapter:cerelog_emg_als:split_emg_als")
        self.assertFalse(catalog_result["added_to_tray"])
        self.assertTrue(any("CATALOG_ONLY" in item for item in catalog_result["errors"]))
        self.assertFalse(quarantine["added_to_tray"])
        self.assertTrue(any("quarantined" in item.lower() for item in quarantine["errors"]))
        self.assertEqual([], model.tray_rows())

    def test_failed_replacement_does_not_erase_a_valid_choice(self) -> None:
        model = workflow.HardwareWorkflowModel()
        valid = model.validate_and_select("eeg", "module:openbci_cyton_daisy_eeg")
        failed = model.validate_and_select("eeg", "adapter:muse_brainflow:muse_2_brainflow")
        self.assertTrue(valid["added_to_tray"])
        self.assertFalse(failed["added_to_tray"])
        self.assertEqual("module:openbci_cyton_daisy_eeg", model.tray_rows()[0]["choice_id"])

    def test_multirole_module_is_one_tray_row_and_one_profile_module(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("eeg", "module:openbci_cyton_daisy_eeg_als")
        model.validate_and_select("timing", "module:openbci_cyton_daisy_eeg_als")
        tray = model.tray_rows()
        self.assertEqual(1, len(tray))
        self.assertEqual(["eeg", "timing"], tray[0]["selected_for_groups"])
        with tempfile.TemporaryDirectory() as temp:
            draft = model.create_profile_draft(Path(temp) / "draft.json", profile_id="EEG ALS")
            self.assertEqual("DRAFT_NOT_APPROVED", draft["status"])
            self.assertEqual(1, len(draft["modules"]))
            self.assertFalse(workflow.workflow_snapshot(model)["acquisition_authority"])

    def test_draft_review_and_ui_lock_use_canonical_profile_gates(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("eeg", "module:openbci_cyton_daisy_eeg_als")
        model.validate_and_select("cardiac", "module:polar_h10_rr")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            draft_path = root / "draft.json"
            approved_path = root / "approved.json"
            lock_path = root / "profile_ui_lock.json"
            draft = model.create_profile_draft(draft_path, profile_id="alpha5 rig")
            self.assertEqual("DRAFT_NOT_APPROVED", draft["status"])
            approved = workflow.review_hardware_profile_draft(
                draft_path, approved_path, reviewed_by="Unit Test Reviewer"
            )
            self.assertEqual("APPROVED", approved["status"], approved)
            lock = workflow.lock_hardware_profile(approved_path, output_path=lock_path)
            self.assertEqual("LOCKED_FOR_CONNECT_AND_LAUNCH", lock["status"])
            self.assertFalse(lock["session_lock_authority"])
            self.assertFalse(lock["arm_authority"])
            self.assertEqual(
                "CAUTION",
                workflow.validate_hardware_profile_lock(lock, profile_path=approved_path)["status"],
            )

    def test_unapproved_draft_cannot_be_locked(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("cardiac", "module:polar_h10_rr")
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "draft.json"
            model.create_profile_draft(path, profile_id="draft")
            with self.assertRaisesRegex(ValueError, "not lockable"):
                workflow.lock_hardware_profile(path)

    def test_launch_plan_contains_only_exact_locked_module_processes(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("eeg", "module:openbci_cyton_daisy_eeg_als")
        model.validate_and_select("cardiac", "module:polar_h10_rr")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            draft_path = root / "draft.json"
            approved_path = root / "approved.json"
            model.create_profile_draft(draft_path, profile_id="launch rig")
            workflow.review_hardware_profile_draft(
                draft_path, approved_path, reviewed_by="Unit Test Reviewer"
            )
            lock = workflow.lock_hardware_profile(approved_path)
            plan = workflow.derive_launch_actions(approved_path, lock)
            action_ids = {row["action_id"] for row in plan["actions"]}
            self.assertEqual({"launch_openbci_eeg_als", "launch_polar_h10_rr"}, action_ids)
            self.assertFalse(any("vernier" in item for item in action_ids))
            self.assertTrue(all(row["acquisition_authority"] is False for row in plan["actions"]))

    def test_vernier_uses_one_menu_button_for_two_transports(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("respiration", "module:vernier_respiration")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            draft_path = root / "draft.json"
            approved_path = root / "approved.json"
            model.create_profile_draft(draft_path, profile_id="respiration")
            workflow.review_hardware_profile_draft(
                draft_path, approved_path, reviewed_by="Unit Test Reviewer"
            )
            plan = workflow.derive_launch_actions(approved_path, workflow.lock_hardware_profile(approved_path))
            self.assertEqual(1, len(plan["actions"]))
            self.assertEqual("MENU_BUTTON", plan["actions"][0]["ui_kind"])
            self.assertEqual({"usb", "ble"}, {row["variant_id"] for row in plan["actions"][0]["variants"]})

    def test_module_without_managed_launcher_gets_notice_not_guessed_button(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("eog", "module:generic_eog_emg_sentinels")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            draft_path = root / "draft.json"
            approved_path = root / "approved.json"
            model.create_profile_draft(draft_path, profile_id="sentinels")
            workflow.review_hardware_profile_draft(
                draft_path, approved_path, reviewed_by="Unit Test Reviewer"
            )
            plan = workflow.derive_launch_actions(approved_path, workflow.lock_hardware_profile(approved_path))
            self.assertEqual([], plan["actions"])
            self.assertEqual("generic_eog_emg_sentinels", plan["unavailable_modules"][0]["module_id"])
            self.assertEqual("CAUTION", plan["status"])

    def test_profile_or_module_tamper_invalidates_lock_and_hides_actions(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("cardiac", "module:polar_h10_rr")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            draft_path = root / "draft.json"
            approved_path = root / "approved.json"
            model.create_profile_draft(draft_path, profile_id="tamper test")
            workflow.review_hardware_profile_draft(
                draft_path, approved_path, reviewed_by="Unit Test Reviewer"
            )
            lock = workflow.lock_hardware_profile(approved_path)
            changed = json.loads(approved_path.read_text(encoding="utf-8"))
            changed["reviewed_by"] = "Someone Else"
            approved_path.write_text(json.dumps(changed), encoding="utf-8")
            plan = workflow.derive_launch_actions(approved_path, lock)
            self.assertEqual("INELIGIBLE", plan["status"])
            self.assertEqual([], plan["actions"])

    def test_lock_authority_fields_fail_closed_if_tampered(self) -> None:
        model = workflow.HardwareWorkflowModel()
        model.validate_and_select("cardiac", "module:polar_h10_rr")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            draft_path = root / "draft.json"
            approved_path = root / "approved.json"
            model.create_profile_draft(draft_path, profile_id="authority test")
            workflow.review_hardware_profile_draft(
                draft_path, approved_path, reviewed_by="Unit Test Reviewer"
            )
            lock = workflow.lock_hardware_profile(approved_path)
            tampered = deepcopy(lock)
            tampered["acquisition_authority"] = True
            # Rehashing an unsafe claim must not bypass the explicit authority gate.
            tampered["lock_sha256"] = workflow._lock_hash(tampered)
            result = workflow.validate_hardware_profile_lock(tampered, profile_path=approved_path)
            self.assertEqual("INELIGIBLE", result["status"])
            self.assertTrue(any("acquisition_authority=false" in item for item in result["errors"]))


if __name__ == "__main__":
    unittest.main()
