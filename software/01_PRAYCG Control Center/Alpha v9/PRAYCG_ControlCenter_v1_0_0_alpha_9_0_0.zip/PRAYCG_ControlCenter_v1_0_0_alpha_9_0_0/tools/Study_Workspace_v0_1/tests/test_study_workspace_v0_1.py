import tempfile
import unittest
from pathlib import Path

import sys

MODULE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(MODULE_ROOT))

from praycg_study_workspace_v0_1 import (  # noqa: E402
    WORKFLOW_STAGES,
    bind_component,
    create_workspace,
    load_workspace,
    record_run,
    save_workspace,
    start_new_session,
    validate_workspace,
)


class StudyWorkspaceTests(unittest.TestCase):
    def test_lifecycle_and_true_downstream_staleness(self):
        with tempfile.TemporaryDirectory() as temp:
            path, workspace = create_workspace(Path(temp), "Atlas Feasibility")
            self.assertEqual(tuple(workspace["workflow"]), WORKFLOW_STAGES)
            workspace, _ = bind_component(workspace, "protocol", {"protocol_id": "PRAYCG3"}, reason="test")
            workspace, _ = bind_component(workspace, "stimulus", {"id": "sample-a", "folder": temp}, reason="test")
            workspace, _ = bind_component(workspace, "hardware", {"profile_id": "profile-a"}, reason="test")
            workspace, _ = bind_component(
                workspace, "runner", {"armed": True, "session_lock_status": "VALID"}, reason="test"
            )
            workspace, _ = record_run(
                workspace,
                {"run_uuid": "11111111-1111-4111-8111-111111111111", "folder": temp},
                reason="test",
            )
            workspace, changed = bind_component(workspace, "stimulus", {"id": "sample-b", "folder": temp}, reason="changed")
            self.assertTrue(changed)
            self.assertEqual(workspace["workflow"]["hardware"]["status"], "LOCKED")
            self.assertEqual(workspace["workflow"]["run"]["status"], "STALE")
            self.assertEqual(len(workspace["runs"]), 1, "staling must preserve earlier run evidence")
            saved = save_workspace(path, workspace)
            self.assertEqual(validate_workspace(saved)["status"], "PASS")
            self.assertEqual(load_workspace(path)["workspace_content_sha256"], saved["workspace_content_sha256"])

    def test_new_session_preserves_prior_session_and_clears_session_bound_plan(self):
        with tempfile.TemporaryDirectory() as temp:
            _path, workspace = create_workspace(Path(temp), "Sessions")
            workspace["analysis"]["plan"] = {"status": "LOCKED"}
            prior = workspace["current_session"]["session_id"]
            workspace = start_new_session(workspace, reason="test")
            self.assertEqual(workspace["sessions"][0]["session_id"], prior)
            self.assertNotEqual(workspace["current_session"]["session_id"], prior)
            self.assertEqual(workspace["analysis"]["plan"], {})


if __name__ == "__main__":
    unittest.main()
