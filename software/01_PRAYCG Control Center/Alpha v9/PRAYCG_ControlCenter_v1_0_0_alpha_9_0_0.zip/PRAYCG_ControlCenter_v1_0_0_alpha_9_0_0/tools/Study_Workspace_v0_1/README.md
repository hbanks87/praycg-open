# Study Workspace v0.1

The Study Workspace is the local provenance backbone introduced in Control Center
`v1.0.0-alpha.8`. It records study/session identity, governed selections, workflow
state, runs, analysis plans and outputs, QC evidence, and results-bundle state.

It never grants protocol, hardware, acquisition, analysis, scientific, or
publication authority. Upstream changes retain prior evidence but mark dependent
workflow stages `STALE` until the applicable independent gates are repeated.
