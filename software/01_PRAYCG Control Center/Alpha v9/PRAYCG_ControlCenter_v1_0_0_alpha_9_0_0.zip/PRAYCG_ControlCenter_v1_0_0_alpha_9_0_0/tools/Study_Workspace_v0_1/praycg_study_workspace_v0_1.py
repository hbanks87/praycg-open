#!/usr/bin/env python3
"""Persistent, local-only Study Workspace for PRAYCG Control Center alpha.8.

The workspace records selections and provenance.  It does not grant protocol,
hardware, acquisition, analysis, scientific, or publication authority.  Those
decisions remain with their independently validated components and the operator.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


WORKSPACE_SCHEMA = "PRAYCG_StudyWorkspace_v0_1"
WORKSPACE_VERSION = "0.1.0"
POINTER_SCHEMA = "PRAYCG_ActiveStudyWorkspacePointer_v0_1"
WORKFLOW_STAGES = (
    "protocol",
    "stimuli",
    "hardware",
    "arm",
    "run",
    "qc",
    "analyze",
    "review",
    "export",
)
WORKFLOW_LABELS = {
    "protocol": "Protocol",
    "stimuli": "Stimuli",
    "hardware": "Hardware",
    "arm": "Arm",
    "run": "Run",
    "qc": "QC",
    "analyze": "Analyze",
    "review": "Review",
    "export": "Export",
}
WORKFLOW_STATUSES = frozenset(
    {"NOT_STARTED", "READY", "LOCKED", "CAUTION", "INELIGIBLE", "COMPLETE", "STALE"}
)
COMPONENT_STAGES = {
    "protocol": "protocol",
    "stimulus": "stimuli",
    "hardware": "hardware",
    "runner": "arm",
    "analysis_plan": "analyze",
}
STALE_DEPENDENCIES = {
    "protocol": ("stimuli", "hardware", "arm", "run", "qc", "analyze", "review", "export"),
    "stimulus": ("arm", "run", "qc", "analyze", "review", "export"),
    "hardware": ("arm", "run", "qc", "analyze", "review", "export"),
    "runner": ("run", "qc", "analyze", "review", "export"),
    "analysis_plan": ("analyze", "review", "export"),
}
BOUNDARY = (
    "A Study Workspace is a local provenance and workflow record. Its states summarize recorded "
    "evidence only; they cannot approve a protocol, validate hardware, arm acquisition, establish "
    "an endpoint, certify a scientific claim, or publish data."
)
_SLUG_RE = re.compile(r"[^a-zA-Z0-9._-]+")


class WorkspaceError(RuntimeError):
    """Raised when a workspace fails a fail-closed integrity check."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def safe_slug(value: str, fallback: str = "study") -> str:
    text = _SLUG_RE.sub("-", str(value).strip()).strip("-._")
    return (text[:64] or fallback).lower()


def path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except (OSError, ValueError):
        return False


def _workspace_hash_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    value = deepcopy(dict(payload))
    value.pop("workspace_content_sha256", None)
    return value


def _atomic_write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _event(event_type: str, *, reason: str, details: Mapping[str, Any] | None = None) -> dict[str, Any]:
    return {
        "event_id": str(uuid.uuid4()),
        "recorded_utc": utc_now(),
        "event_type": event_type,
        "reason": str(reason),
        "details": deepcopy(dict(details or {})),
    }


def empty_workspace(display_name: str, *, study_id: str | None = None) -> dict[str, Any]:
    sid = str(uuid.UUID(study_id)) if study_id else str(uuid.uuid4())
    session_id = str(uuid.uuid4())
    created = utc_now()
    workspace = {
        "schema": WORKSPACE_SCHEMA,
        "version": WORKSPACE_VERSION,
        "study_id": sid,
        "display_name": str(display_name).strip() or "Untitled Study",
        "created_utc": created,
        "updated_utc": created,
        "status": "ACTIVE",
        "current_session": {
            "session_id": session_id,
            "session_index": 1,
            "status": "PLANNED",
            "created_utc": created,
        },
        "sessions": [],
        "components": {
            "protocol": {},
            "stimulus": {},
            "hardware": {},
            "runner": {},
        },
        "analysis": {
            "plan": {},
            "post_hoc_supplements": [],
            "executions": [],
            "outputs": [],
            "outcomes_reviewed": False,
            "outcomes_reviewed_utc": None,
        },
        "runs": [],
        "qc": {"status": "NOT_STARTED", "evidence": [], "limitations": []},
        "results_package": {
            "status": "NOT_STARTED",
            "bundles": [],
            "publication_approval": "NOT_APPROVED",
            "upload_capability": "NONE_LOCAL_ONLY",
        },
        "workflow": {
            stage: {
                "status": "READY" if stage == "protocol" else "NOT_STARTED",
                "updated_utc": created,
                "reason": "Create or select the next governed artifact." if stage == "protocol" else "Awaiting prerequisites.",
            }
            for stage in WORKFLOW_STAGES
        },
        "history": [
            _event(
                "WORKSPACE_CREATED",
                reason="Operator created a local Study Workspace.",
                details={"session_id": session_id},
            )
        ],
        "known_limitations": [],
        "boundary": BOUNDARY,
        "workspace_content_sha256": "",
    }
    workspace["workspace_content_sha256"] = sha256_json(_workspace_hash_payload(workspace))
    return workspace


def validate_workspace(payload: Any) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(payload, dict):
        return {"status": "INELIGIBLE", "errors": ["workspace must be a JSON object"], "warnings": [], "boundary": BOUNDARY}
    if payload.get("schema") != WORKSPACE_SCHEMA:
        errors.append(f"schema must be {WORKSPACE_SCHEMA}")
    if payload.get("version") != WORKSPACE_VERSION:
        errors.append(f"version must be {WORKSPACE_VERSION}")
    try:
        uuid.UUID(str(payload.get("study_id")))
    except (ValueError, TypeError, AttributeError):
        errors.append("study_id must be a full UUID")
    current_session = payload.get("current_session")
    if not isinstance(current_session, dict):
        errors.append("current_session must be an object")
    else:
        try:
            uuid.UUID(str(current_session.get("session_id")))
        except (ValueError, TypeError, AttributeError):
            errors.append("current_session.session_id must be a full UUID")
        if not isinstance(current_session.get("session_index"), int) or current_session.get("session_index", 0) < 1:
            errors.append("current_session.session_index must be a positive integer")
    workflow = payload.get("workflow")
    if not isinstance(workflow, dict):
        errors.append("workflow must be an object")
    else:
        if set(workflow) != set(WORKFLOW_STAGES):
            errors.append("workflow must contain exactly the nine governed stages")
        for stage in WORKFLOW_STAGES:
            row = workflow.get(stage)
            if not isinstance(row, dict) or row.get("status") not in WORKFLOW_STATUSES:
                errors.append(f"workflow.{stage}.status is invalid")
    if not isinstance(payload.get("components"), dict):
        errors.append("components must be an object")
    if not isinstance(payload.get("analysis"), dict):
        errors.append("analysis must be an object")
    if not isinstance(payload.get("runs"), list):
        errors.append("runs must be an array")
    recorded_hash = str(payload.get("workspace_content_sha256") or "")
    actual_hash = sha256_json(_workspace_hash_payload(payload))
    if not re.fullmatch(r"[0-9a-f]{64}", recorded_hash):
        errors.append("workspace_content_sha256 must be lowercase SHA-256")
    elif recorded_hash != actual_hash:
        errors.append("workspace content changed without a matching integrity hash")
    if payload.get("status") != "ACTIVE":
        warnings.append(f"workspace status is {payload.get('status')!r}, not ACTIVE")
    status = "INELIGIBLE" if errors else ("CAUTION" if warnings else "PASS")
    return {"status": status, "errors": errors, "warnings": warnings, "actual_sha256": actual_hash, "boundary": BOUNDARY}


def save_workspace(path: Path | str, payload: Mapping[str, Any]) -> dict[str, Any]:
    target = Path(path).expanduser().resolve(strict=False)
    value = deepcopy(dict(payload))
    value["schema"] = WORKSPACE_SCHEMA
    value["version"] = WORKSPACE_VERSION
    value["updated_utc"] = utc_now()
    value["boundary"] = BOUNDARY
    value["workspace_content_sha256"] = sha256_json(_workspace_hash_payload(value))
    report = validate_workspace(value)
    if report["status"] == "INELIGIBLE":
        raise WorkspaceError("Workspace validation failed: " + "; ".join(report["errors"]))
    _atomic_write_json(target, value)
    return value


def load_workspace(path: Path | str) -> dict[str, Any]:
    target = Path(path).expanduser().resolve(strict=True)
    payload = json.loads(target.read_text(encoding="utf-8-sig"))
    report = validate_workspace(payload)
    if report["status"] == "INELIGIBLE":
        raise WorkspaceError("Workspace validation failed: " + "; ".join(report["errors"]))
    return payload


def create_workspace(root: Path | str, display_name: str) -> tuple[Path, dict[str, Any]]:
    workspace_root = Path(root).expanduser().resolve(strict=False)
    workspace_root.mkdir(parents=True, exist_ok=True)
    payload = empty_workspace(display_name)
    directory = workspace_root / f"{safe_slug(display_name)}--{payload['study_id'][:8]}"
    if not path_is_within(directory, workspace_root):
        raise WorkspaceError("Generated workspace path escaped the configured workspace root")
    directory.mkdir(parents=False, exist_ok=False)
    for child in ("locks", "sessions", "analysis", "results_bundles"):
        (directory / child).mkdir()
    path = directory / "study_workspace.json"
    payload = save_workspace(path, payload)
    return path, payload


def write_active_pointer(pointer_path: Path | str, workspace_path: Path | str | None) -> None:
    target = Path(pointer_path).expanduser().resolve(strict=False)
    value = {
        "schema": POINTER_SCHEMA,
        "updated_utc": utc_now(),
        "workspace_path": str(Path(workspace_path).expanduser().resolve(strict=False)) if workspace_path else "",
    }
    _atomic_write_json(target, value)


def read_active_pointer(pointer_path: Path | str) -> Path | None:
    target = Path(pointer_path).expanduser().resolve(strict=False)
    try:
        value = json.loads(target.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or value.get("schema") != POINTER_SCHEMA:
        return None
    raw = str(value.get("workspace_path") or "").strip()
    path = Path(raw).expanduser().resolve(strict=False) if raw else None
    return path if path and path.is_file() else None


def artifact_record(path: Path | str | None, *, kind: str, status: str = "RECORDED") -> dict[str, Any]:
    if not path:
        return {}
    target = Path(path).expanduser().resolve(strict=False)
    record = {"kind": kind, "path": str(target), "status": status, "exists": target.exists()}
    if target.is_file() and not target.is_symlink():
        record.update({"sha256": sha256_file(target), "byte_count": target.stat().st_size})
    return record


def _set_stage(workspace: dict[str, Any], stage: str, status: str, reason: str) -> None:
    if stage not in WORKFLOW_STAGES or status not in WORKFLOW_STATUSES:
        raise WorkspaceError(f"Invalid workflow transition: {stage} -> {status}")
    workspace["workflow"][stage] = {"status": status, "updated_utc": utc_now(), "reason": str(reason)}


def _stale_dependencies(workspace: dict[str, Any], component: str, reason: str) -> None:
    for stage in STALE_DEPENDENCIES[component]:
        current = workspace["workflow"][stage]["status"]
        if current not in {"NOT_STARTED", "READY"}:
            _set_stage(workspace, stage, "STALE", reason)


def _component_fingerprint(record: Mapping[str, Any]) -> str:
    return sha256_json(record)


def bind_component(
    workspace: Mapping[str, Any],
    component: str,
    record: Mapping[str, Any] | None,
    *,
    reason: str,
) -> tuple[dict[str, Any], bool]:
    """Bind one governed snapshot and stale only its true downstream consumers."""
    if component not in COMPONENT_STAGES:
        raise WorkspaceError(f"Unsupported workspace component: {component}")
    value = deepcopy(dict(workspace))
    container = value["analysis"] if component == "analysis_plan" else value["components"]
    key = "plan" if component == "analysis_plan" else component
    new_record = deepcopy(dict(record or {}))
    if new_record:
        new_record["workspace_snapshot_sha256"] = _component_fingerprint(new_record)
    previous = container.get(key, {}) if isinstance(container.get(key), dict) else {}
    previous_hash = str(previous.get("workspace_snapshot_sha256") or "")
    new_hash = str(new_record.get("workspace_snapshot_sha256") or "")
    if previous_hash == new_hash and bool(previous) == bool(new_record):
        return value, False
    container[key] = new_record
    stage = COMPONENT_STAGES[component]
    _stale_dependencies(value, component, f"Upstream {component} changed: {reason}")
    if new_record:
        status = "LOCKED"
        if component == "runner":
            status = "LOCKED" if new_record.get("armed") else (
                "READY" if new_record.get("session_lock_status") == "VALID" else "CAUTION"
            )
        _set_stage(value, stage, status, reason)
    else:
        _set_stage(value, stage, "READY" if stage == "protocol" else "NOT_STARTED", reason)

    if component == "protocol" and new_record and not value["components"].get("stimulus"):
        _set_stage(value, "stimuli", "READY", "Protocol is locked; select compatible stimuli.")
    if component == "stimulus" and new_record and not value["components"].get("hardware"):
        _set_stage(value, "hardware", "READY", "Stimuli are locked; select and validate hardware.")
    if component == "hardware" and new_record:
        _set_stage(value, "arm", "READY", "Hardware profile is locked; prepare the runtime session lock.")
    if component == "runner" and new_record.get("armed"):
        _set_stage(value, "run", "READY", "The independent acquisition gate reports ARMED.")
    value["history"].append(
        _event(
            "COMPONENT_BOUND" if new_record else "COMPONENT_CLEARED",
            reason=reason,
            details={"component": component, "previous_sha256": previous_hash, "new_sha256": new_hash},
        )
    )
    return value, True


def record_run(workspace: Mapping[str, Any], run: Mapping[str, Any], *, reason: str) -> tuple[dict[str, Any], bool]:
    value = deepcopy(dict(workspace))
    record = deepcopy(dict(run))
    record.pop("workspace_snapshot_sha256", None)
    if not record.get("folder") and not record.get("run_uuid"):
        return value, False
    record["workspace_snapshot_sha256"] = _component_fingerprint(record)
    identity = str(record.get("run_uuid") or record.get("folder") or "").casefold()
    existing = {
        str(item.get("run_uuid") or item.get("folder") or "").casefold(): index
        for index, item in enumerate(value["runs"])
        if isinstance(item, dict)
    }
    changed = False
    if identity in existing:
        index = existing[identity]
        if value["runs"][index].get("workspace_snapshot_sha256") != record["workspace_snapshot_sha256"]:
            value["runs"][index] = record
            changed = True
    else:
        value["runs"].append(record)
        changed = True
    if changed:
        _set_stage(value, "run", "COMPLETE", reason)
        _set_stage(value, "qc", "READY", "A run is recorded; perform required QC.")
        value["history"].append(_event("RUN_RECORDED", reason=reason, details={"identity": identity}))
    return value, changed


def record_analysis_outputs(
    workspace: Mapping[str, Any], outputs: list[Mapping[str, Any]], *, reason: str
) -> tuple[dict[str, Any], bool]:
    value = deepcopy(dict(workspace))
    normalized = []
    for output in outputs:
        row = deepcopy(dict(output))
        row.pop("workspace_snapshot_sha256", None)
        if row.get("path"):
            row["workspace_snapshot_sha256"] = _component_fingerprint(row)
            normalized.append(row)
    previous_hash = sha256_json(value["analysis"].get("outputs", []))
    new_hash = sha256_json(normalized)
    if previous_hash == new_hash:
        return value, False
    value["analysis"]["outputs"] = normalized
    if normalized:
        _set_stage(value, "analyze", "COMPLETE", reason)
        _set_stage(value, "review", "READY", "Analysis outputs are recorded; review outcomes and limitations.")
    value["history"].append(_event("ANALYSIS_OUTPUTS_RECORDED", reason=reason, details={"count": len(normalized)}))
    return value, True


def set_workflow_stage(
    workspace: Mapping[str, Any], stage: str, status: str, *, reason: str, evidence: Mapping[str, Any] | None = None
) -> dict[str, Any]:
    value = deepcopy(dict(workspace))
    _set_stage(value, stage, status, reason)
    value["history"].append(
        _event("WORKFLOW_STAGE_RECORDED", reason=reason, details={"stage": stage, "status": status, "evidence": dict(evidence or {})})
    )
    if stage == "qc":
        value["qc"]["status"] = status
        if evidence:
            value["qc"]["evidence"].append(deepcopy(dict(evidence)))
        if status in {"COMPLETE", "CAUTION"} and value["analysis"].get("plan"):
            _set_stage(value, "analyze", "READY", "QC is recorded and an analysis plan is locked.")
    if stage == "review" and status == "COMPLETE":
        value["analysis"]["outcomes_reviewed"] = True
        value["analysis"]["outcomes_reviewed_utc"] = utc_now()
        _set_stage(value, "export", "READY", "Outcome review is recorded; a local results bundle may be built.")
    return value


def add_post_hoc_supplement(workspace: Mapping[str, Any], supplement: Mapping[str, Any]) -> dict[str, Any]:
    value = deepcopy(dict(workspace))
    row = deepcopy(dict(supplement))
    if row.get("effective_role") != "POST_HOC_EXPLORATORY":
        raise WorkspaceError("Post-hoc supplements must remain POST_HOC_EXPLORATORY")
    row["primary_conclusion_authority"] = "NONE"
    value["analysis"]["post_hoc_supplements"].append(row)
    value["history"].append(
        _event("POST_HOC_ANALYSIS_ADDED", reason="Operator added an analysis after the locked plan.", details={"module_id": row.get("module_id")})
    )
    return value


def start_new_session(workspace: Mapping[str, Any], *, reason: str) -> dict[str, Any]:
    value = deepcopy(dict(workspace))
    current = deepcopy(value["current_session"])
    current["closed_utc"] = utc_now()
    value["sessions"].append(current)
    next_index = int(current.get("session_index") or 0) + 1
    value["current_session"] = {
        "session_id": str(uuid.uuid4()),
        "session_index": next_index,
        "status": "PLANNED",
        "created_utc": utc_now(),
    }
    for stage in ("arm", "run", "qc", "analyze", "review", "export"):
        _set_stage(value, stage, "NOT_STARTED", "New session requires new session-bound evidence.")
    value["components"]["runner"] = {}
    value["analysis"]["plan"] = {}
    value["analysis"]["outputs"] = []
    value["analysis"]["outcomes_reviewed"] = False
    value["analysis"]["outcomes_reviewed_utc"] = None
    value["history"].append(_event("SESSION_STARTED", reason=reason, details={"session_index": next_index}))
    return value


def workflow_summary(workspace: Mapping[str, Any]) -> str:
    rows = []
    workflow = workspace.get("workflow", {})
    for stage in WORKFLOW_STAGES:
        status = workflow.get(stage, {}).get("status", "NOT_STARTED")
        rows.append(f"{WORKFLOW_LABELS[stage]} {status}")
    return "  →  ".join(rows)


def next_action(workspace: Mapping[str, Any]) -> tuple[str, str]:
    workflow = workspace.get("workflow", {})
    for stage in WORKFLOW_STAGES:
        row = workflow.get(stage, {})
        if row.get("status") in {"READY", "CAUTION", "INELIGIBLE", "STALE"}:
            return stage, str(row.get("reason") or f"Review {WORKFLOW_LABELS[stage]}.")
    return "export", "All recorded workflow stages are complete; review the local bundle before any future publication approval."
