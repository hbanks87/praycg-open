#!/usr/bin/env python3
"""Governed analysis registry, plan locking, and dependency resolution.

The orchestrator never imports registered analysis code and never infers a
scientific result.  It validates data-only descriptors, freezes plans before
outcome access, resolves dependencies, and produces explicit launch records.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping


REGISTRY_SCHEMA = "PRAYCG_AnalysisOrchestrationRegistry_v0_1"
MODULE_SCHEMA = "PRAYCG_AnalysisOrchestrationModule_v0_1"
PLAN_SCHEMA = "PRAYCG_AnalysisPlan_v0_1"
PLAN_LOCK_SCHEMA = "PRAYCG_AnalysisPlanLock_v0_1"
POSTHOC_SCHEMA = "PRAYCG_PostHocAnalysisSupplement_v0_1"
PREFLIGHT_SCHEMA = "PRAYCG_AnalysisEligibility_v0_1"
EXECUTION_GRAPH_SCHEMA = "PRAYCG_AnalysisExecutionGraph_v0_1"
REGISTRY_VERSION = "0.1.0"
MODULE_CATEGORIES = (
    "REQUIRED_QC",
    "PROTOCOL_PRIMARY",
    "PROTOCOL_SECONDARY",
    "PRAYCG_STANDARD",
    "PRAYCG_EXPLORATORY",
    "USER_ADDED",
    "VISUALIZATION_INTERPRETATION",
)
ANALYSIS_ROLES = frozenset(
    {
        "REQUIRED_QC",
        "CONFIRMATORY_PRIMARY",
        "STANDARD_SECONDARY",
        "EXPLORATORY",
        "VISUALIZATION_ONLY",
    }
)
ELIGIBILITY_STATES = frozenset({"READY", "CAUTION", "BLOCKED_BY_DEPENDENCY", "INELIGIBLE"})
EXECUTION_MODES = frozenset({"MANAGED_CLI", "CONTROL_CENTER_ACTION", "REFERENCE_ONLY"})
MATCH_POLICIES = frozenset({"AT_LEAST_ONE", "EXACTLY_ONE", "OPTIONAL"})
MODULE_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,95}$")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
RAW_RECORDING_EXTENSIONS = frozenset({".xdf", ".edf", ".bdf", ".fif", ".set", ".vhdr", ".eeg", ".cnt"})
BOUNDARY = (
    "Registry validation, eligibility, plan locking, and dependency resolution are software-governance "
    "operations. They do not validate a construct, promote an endpoint, change Master Suite eligibility, "
    "or establish a scientific, causal, clinical, or consciousness claim."
)


class OrchestrationError(RuntimeError):
    """Raised when an orchestration contract fails closed."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except (OSError, ValueError):
        return False


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise OrchestrationError(f"{path.name} must contain one JSON object")
    return value


def _safe_package_file(root: Path, relative: Any, label: str, errors: list[str]) -> Path | None:
    text = str(relative or "").strip().replace("\\", "/")
    if not text or Path(text).is_absolute() or ".." in Path(text).parts:
        errors.append(f"{label} must be a safe package-relative path")
        return None
    path = (root / text).resolve(strict=False)
    if not path_is_within(path, root) or not path.is_file() or path.is_symlink():
        errors.append(f"{label} does not resolve to a regular packaged file: {text}")
        return None
    return path


def _string_list(value: Any, label: str, errors: list[str], *, allow_empty: bool = True) -> list[str]:
    if not isinstance(value, list) or (not allow_empty and not value):
        errors.append(f"{label} must be {'an' if allow_empty else 'a nonempty'} array of unique strings")
        return []
    result = []
    for item in value:
        if not isinstance(item, str) or not item.strip():
            errors.append(f"{label} contains a non-string or empty value")
        else:
            result.append(item.strip())
    if len(set(result)) != len(result):
        errors.append(f"{label} contains duplicate values")
    return result


def _validate_module(module: Any, root: Path, allowed_actions: set[str]) -> dict[str, Any]:
    errors: list[str] = []
    if not isinstance(module, dict):
        return {"status": "INELIGIBLE", "errors": ["module descriptor must be an object"], "descriptor": {}}
    required = {
        "schema", "module_id", "module_version", "display_name", "category", "analysis_role", "stage",
        "depends_on", "accepted_protocols", "required_modalities", "required_events", "required_conditions",
        "sampling_rate", "timing", "required_preprocessing", "input_contracts", "outputs",
        "software_dependencies", "execution", "multiplicity_family", "missing_data_policy",
        "primary_conclusion_authority", "synthetic_test_status", "human_validation_status",
        "claims_boundary", "code_sha256", "configuration_sha256",
    }
    missing = sorted(required.difference(module))
    extra = sorted(set(module).difference(required))
    if missing:
        errors.append("missing fields: " + ", ".join(missing))
    if extra:
        errors.append("unsupported fields: " + ", ".join(extra))
    if module.get("schema") != MODULE_SCHEMA:
        errors.append(f"schema must be {MODULE_SCHEMA}")
    module_id = str(module.get("module_id") or "")
    if not MODULE_ID_RE.fullmatch(module_id):
        errors.append("module_id must use lower snake case")
    if module.get("category") not in MODULE_CATEGORIES:
        errors.append("category is unsupported")
    if module.get("analysis_role") not in ANALYSIS_ROLES:
        errors.append("analysis_role is unsupported")
    dependencies = _string_list(module.get("depends_on"), "depends_on", errors)
    _string_list(module.get("accepted_protocols"), "accepted_protocols", errors, allow_empty=False)
    _string_list(module.get("required_modalities"), "required_modalities", errors)
    _string_list(module.get("required_events"), "required_events", errors)
    _string_list(module.get("required_conditions"), "required_conditions", errors)
    _string_list(module.get("required_preprocessing"), "required_preprocessing", errors)
    _string_list(module.get("software_dependencies"), "software_dependencies", errors)
    if module.get("primary_conclusion_authority") not in {"NONE", "PROTOCOL_DECLARED_ONLY"}:
        errors.append("primary_conclusion_authority is unsupported")
    if module.get("category") != "PROTOCOL_PRIMARY" and module.get("primary_conclusion_authority") != "NONE":
        errors.append("only PROTOCOL_PRIMARY modules may declare PROTOCOL_DECLARED_ONLY authority")
    if not isinstance(module.get("input_contracts"), list):
        errors.append("input_contracts must be an array")
    else:
        for index, contract in enumerate(module["input_contracts"]):
            if not isinstance(contract, dict):
                errors.append(f"input_contracts[{index}] must be an object")
                continue
            if set(contract) != {"artifact_id", "scope", "patterns", "match", "produced_by_dependencies"}:
                errors.append(f"input_contracts[{index}] fields are invalid")
                continue
            _string_list(contract.get("patterns"), f"input_contracts[{index}].patterns", errors, allow_empty=False)
            if contract.get("scope") not in {"RUN", "ANALYSIS"}:
                errors.append(f"input_contracts[{index}].scope is invalid")
            if contract.get("match") not in MATCH_POLICIES:
                errors.append(f"input_contracts[{index}].match is invalid")
            if not isinstance(contract.get("produced_by_dependencies"), bool):
                errors.append(f"input_contracts[{index}].produced_by_dependencies must be boolean")
    if not isinstance(module.get("outputs"), list):
        errors.append("outputs must be an array")
    sampling = module.get("sampling_rate")
    if not isinstance(sampling, dict) or set(sampling) != {"minimum_hz", "missing_policy"}:
        errors.append("sampling_rate must contain minimum_hz and missing_policy")
    elif sampling.get("missing_policy") not in {"CAUTION", "INELIGIBLE", "NOT_APPLICABLE"}:
        errors.append("sampling_rate.missing_policy is invalid")
    timing = module.get("timing")
    if not isinstance(timing, dict) or set(timing) != {"requires_monotonic_timestamps", "maximum_uncertainty_ms", "missing_policy"}:
        errors.append("timing fields are invalid")
    elif timing.get("missing_policy") not in {"CAUTION", "INELIGIBLE", "NOT_APPLICABLE"}:
        errors.append("timing.missing_policy is invalid")
    execution = module.get("execution")
    entry = None
    if not isinstance(execution, dict) or set(execution) != {"mode", "entry_point", "control_center_action", "arguments"}:
        errors.append("execution fields are invalid")
    else:
        mode = execution.get("mode")
        if mode not in EXECUTION_MODES:
            errors.append("execution.mode is invalid")
        entry = _safe_package_file(root, execution.get("entry_point"), "execution.entry_point", errors)
        action = execution.get("control_center_action")
        if mode == "CONTROL_CENTER_ACTION" and action not in allowed_actions:
            errors.append("execution.control_center_action is not allowlisted by the registry")
        if mode != "CONTROL_CENTER_ACTION" and action is not None:
            errors.append("only CONTROL_CENTER_ACTION modules may declare an action")
        if not isinstance(execution.get("arguments"), list):
            errors.append("execution.arguments must be an array")
    code_hashes = module.get("code_sha256")
    if not isinstance(code_hashes, dict) or not code_hashes:
        errors.append("code_sha256 must be a nonempty path-to-hash object")
    else:
        for relative, expected in code_hashes.items():
            code_path = _safe_package_file(root, relative, f"code_sha256[{relative}]", errors)
            if not isinstance(expected, str) or not SHA_RE.fullmatch(expected):
                errors.append(f"code_sha256[{relative}] must be lowercase SHA-256")
            elif code_path is not None and sha256_file(code_path) != expected:
                errors.append(f"code hash mismatch: {relative}")
        if isinstance(execution, dict) and str(execution.get("entry_point") or "") not in code_hashes:
            errors.append("code_sha256 must bind the declared execution.entry_point")
    config_hashes = module.get("configuration_sha256")
    if not isinstance(config_hashes, dict):
        errors.append("configuration_sha256 must be a path-to-hash object")
    else:
        for relative, expected in config_hashes.items():
            config_path = _safe_package_file(root, relative, f"configuration_sha256[{relative}]", errors)
            if not isinstance(expected, str) or not SHA_RE.fullmatch(expected):
                errors.append(f"configuration_sha256[{relative}] must be lowercase SHA-256")
            elif config_path is not None and sha256_file(config_path) != expected:
                errors.append(f"configuration hash mismatch: {relative}")
    return {
        "status": "PASS" if not errors else "INELIGIBLE",
        "module_id": module_id,
        "descriptor": deepcopy(module),
        "dependencies": dependencies,
        "entry_point": str(entry) if entry is not None else "",
        "errors": errors,
    }


def _topological_order(modules: Mapping[str, Mapping[str, Any]]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    indegree = {module_id: 0 for module_id in modules}
    children = {module_id: [] for module_id in modules}
    for module_id, module in modules.items():
        for dependency in module.get("depends_on", []):
            if dependency not in modules:
                errors.append(f"{module_id} depends on unknown module {dependency}")
                continue
            indegree[module_id] += 1
            children[dependency].append(module_id)
    ready = sorted(module_id for module_id, count in indegree.items() if count == 0)
    order: list[str] = []
    while ready:
        current = ready.pop(0)
        order.append(current)
        for child in sorted(children[current]):
            indegree[child] -= 1
            if indegree[child] == 0:
                ready.append(child)
                ready.sort()
    if len(order) != len(modules):
        errors.append("analysis dependency graph contains a cycle")
    return order, errors


def validate_registry(registry_path: Path | str, package_root: Path | str) -> dict[str, Any]:
    path = Path(registry_path).expanduser().resolve(strict=False)
    root = Path(package_root).expanduser().resolve(strict=False)
    errors: list[str] = []
    try:
        registry = _read_json(path)
    except (OSError, UnicodeError, json.JSONDecodeError, OrchestrationError) as exc:
        return {"status": "INELIGIBLE", "errors": [f"Registry load failed: {type(exc).__name__}: {exc}"], "modules": [], "boundary": BOUNDARY}
    if registry.get("schema") != REGISTRY_SCHEMA:
        errors.append(f"registry schema must be {REGISTRY_SCHEMA}")
    if registry.get("version") != REGISTRY_VERSION:
        errors.append(f"registry version must be {REGISTRY_VERSION}")
    allowed_actions = set(_string_list(registry.get("allowed_control_center_actions"), "allowed_control_center_actions", errors))
    if registry.get("network_execution") != "DISABLED":
        errors.append("network_execution must be DISABLED")
    if registry.get("primary_authority") != "NONE_BY_REGISTRATION":
        errors.append("primary_authority must be NONE_BY_REGISTRATION")
    raw_modules = registry.get("modules")
    if not isinstance(raw_modules, list) or not raw_modules:
        errors.append("modules must be a nonempty array")
        raw_modules = []
    reports = [_validate_module(module, root, allowed_actions) for module in raw_modules]
    module_ids = [report["module_id"] for report in reports if report.get("module_id")]
    if len(module_ids) != len(set(module_ids)):
        errors.append("module IDs must be unique")
    module_map = {
        str(report["module_id"]): report["descriptor"]
        for report in reports
        if report.get("status") == "PASS" and report.get("module_id")
    }
    order, graph_errors = _topological_order(module_map)
    errors.extend(graph_errors)
    recorded_hash = str(registry.get("registry_content_sha256") or "")
    hash_payload = deepcopy(registry)
    hash_payload.pop("registry_content_sha256", None)
    actual_hash = sha256_json(hash_payload)
    if not SHA_RE.fullmatch(recorded_hash) or recorded_hash != actual_hash:
        errors.append("registry_content_sha256 does not match the canonical registry")
    status = "PASS" if not errors and all(report["status"] == "PASS" for report in reports) else "INELIGIBLE"
    return {
        "status": status,
        "registry_path": str(path),
        "registry_sha256": sha256_file(path) if path.is_file() else "",
        "registry_content_sha256": actual_hash,
        "module_count": len(reports),
        "modules": reports,
        "module_map": module_map,
        "topological_order": order,
        "errors": errors + [error for report in reports for error in report["errors"]],
        "boundary": BOUNDARY,
    }


def _glob_files(root: Path, patterns: Iterable[str]) -> list[Path]:
    found: dict[str, Path] = {}
    if not root.is_dir():
        return []
    for pattern in patterns:
        try:
            for path in root.glob(str(pattern)):
                if path.is_file() and not path.is_symlink() and path_is_within(path, root):
                    found[str(path.resolve()).casefold()] = path.resolve()
        except (OSError, ValueError):
            continue
    return sorted(found.values(), key=lambda item: item.as_posix().casefold())


def _event_tokens(run_folder: Path) -> set[str]:
    tokens: set[str] = set()
    for path in _glob_files(run_folder, ("*events.json", "**/*events.json", "*events.csv", "**/*events.csv")):
        if path.stat().st_size > 4 * 1024 * 1024:
            continue
        try:
            text = path.read_text(encoding="utf-8-sig", errors="ignore").upper()
        except OSError:
            continue
        tokens.update(re.findall(r"[A-Z][A-Z0-9_:-]{2,80}", text))
    return tokens


def _detect_modalities(run_folder: Path, supplied: Iterable[str]) -> set[str]:
    modalities = {str(value).upper() for value in supplied if str(value).strip()}
    names = " ".join(path.name.casefold() for path in _glob_files(run_folder, ("*", "**/*")))
    if ".xdf" in names:
        modalities.add("LSL_RECORDING")
    for token, modality in (
        ("cardiac", "CARDIAC"), ("ibi", "CARDIAC"), ("rr_interval", "CARDIAC"),
        ("resp", "RESPIRATION"), ("eeg", "EEG"), ("eda", "EDA"), ("ppg", "PPG"),
        ("emg", "EMG"), ("eog", "EOG"), ("als", "ALS"),
    ):
        if token in names:
            modalities.add(modality)
    return modalities


def preflight_module(
    module: Mapping[str, Any],
    *,
    run_folder: Path | str,
    analysis_root: Path | str,
    protocol_id: str,
    available_modalities: Iterable[str] = (),
    observed_sample_rates: Mapping[str, float] | None = None,
    timing_grade: str | None = None,
) -> dict[str, Any]:
    run = Path(run_folder).expanduser().resolve(strict=False)
    analysis = Path(analysis_root).expanduser().resolve(strict=False)
    errors: list[str] = []
    cautions: list[str] = []
    blockers: list[str] = []
    accepted = {str(value).casefold() for value in module.get("accepted_protocols", [])}
    if "*" not in accepted and str(protocol_id).casefold() not in accepted:
        errors.append(f"Protocol {protocol_id or '(unknown)'} is not accepted by this module.")
    if not run.is_dir():
        errors.append("Selected run folder does not exist.")
    modalities = _detect_modalities(run, available_modalities)
    missing_modalities = sorted(set(str(value).upper() for value in module.get("required_modalities", [])) - modalities)
    if missing_modalities:
        cautions.append("Required modalities are not evidenced by the supplied profile/run scan: " + ", ".join(missing_modalities))
    tokens = _event_tokens(run)
    missing_events = [value for value in module.get("required_events", []) if not any(str(value).upper() in token for token in tokens)]
    missing_conditions = [value for value in module.get("required_conditions", []) if not any(str(value).upper() in token for token in tokens)]
    if missing_events:
        cautions.append("Required events were not verified: " + ", ".join(missing_events))
    if missing_conditions:
        cautions.append("Required conditions were not verified: " + ", ".join(missing_conditions))
    contracts = []
    for contract in module.get("input_contracts", []):
        root = run if contract.get("scope") == "RUN" else analysis
        matches = _glob_files(root, contract.get("patterns", []))
        policy = contract.get("match")
        if policy == "OPTIONAL":
            state = "OPTIONAL"
        elif not matches:
            state = "DEFERRED" if contract.get("produced_by_dependencies") else "MISSING"
        elif policy == "EXACTLY_ONE" and len(matches) != 1:
            state = "AMBIGUOUS"
        else:
            state = "RESOLVED"
        contracts.append({
            "artifact_id": contract.get("artifact_id"),
            "scope": contract.get("scope"),
            "status": state,
            "match_count": len(matches),
            "matches": [str(path) for path in matches],
        })
        if state == "MISSING":
            errors.append(f"Required input is missing: {contract.get('artifact_id')}")
        elif state == "AMBIGUOUS":
            errors.append(f"Required input is ambiguous: {contract.get('artifact_id')}")
        elif state == "DEFERRED":
            blockers.append(f"Input will be checked after dependencies complete: {contract.get('artifact_id')}")
    rates = {str(key).upper(): float(value) for key, value in (observed_sample_rates or {}).items()}
    minimum = module.get("sampling_rate", {}).get("minimum_hz")
    if isinstance(minimum, (int, float)) and minimum > 0:
        relevant = [rates.get(modality) for modality in module.get("required_modalities", []) if rates.get(str(modality).upper()) is not None]
        if not relevant:
            policy = module.get("sampling_rate", {}).get("missing_policy")
            (errors if policy == "INELIGIBLE" else cautions).append("Required sampling rate could not be verified.")
        elif min(relevant) < float(minimum):
            errors.append(f"Observed sampling rate is below the declared {minimum:g} Hz minimum.")
    if module.get("timing", {}).get("requires_monotonic_timestamps"):
        if timing_grade not in {"PASS", "CAUTION"}:
            policy = module.get("timing", {}).get("missing_policy")
            (errors if policy == "INELIGIBLE" else cautions).append("Monotonic timestamp evidence is not recorded.")
        elif timing_grade == "CAUTION":
            cautions.append("Timestamp evidence carries a CAUTION grade.")
    if errors:
        status = "INELIGIBLE"
    elif blockers:
        status = "BLOCKED_BY_DEPENDENCY"
    elif cautions:
        status = "CAUTION"
    else:
        status = "READY"
    return {
        "schema": PREFLIGHT_SCHEMA,
        "module_id": module.get("module_id"),
        "display_name": module.get("display_name"),
        "status": status,
        "protocol_id": protocol_id,
        "run_folder": str(run),
        "analysis_root": str(analysis),
        "detected_modalities": sorted(modalities),
        "input_contracts": contracts,
        "errors": errors,
        "cautions": cautions,
        "dependency_blockers": blockers,
        "boundary": BOUNDARY,
    }


def preflight_registry(
    registry_report: Mapping[str, Any],
    *,
    run_folder: Path | str,
    analysis_root: Path | str,
    protocol_id: str,
    available_modalities: Iterable[str] = (),
    observed_sample_rates: Mapping[str, float] | None = None,
    timing_grade: str | None = None,
) -> dict[str, dict[str, Any]]:
    if registry_report.get("status") != "PASS":
        raise OrchestrationError("Cannot preflight an invalid analysis registry")
    return {
        module_id: preflight_module(
            module,
            run_folder=run_folder,
            analysis_root=analysis_root,
            protocol_id=protocol_id,
            available_modalities=available_modalities,
            observed_sample_rates=observed_sample_rates,
            timing_grade=timing_grade,
        )
        for module_id, module in registry_report["module_map"].items()
    }


def _dependency_closure(module_map: Mapping[str, Mapping[str, Any]], selected: Iterable[str]) -> tuple[set[str], list[str]]:
    requested = {str(value) for value in selected}
    unknown = sorted(requested - set(module_map))
    if unknown:
        raise OrchestrationError("Unknown analysis modules: " + ", ".join(unknown))
    closure = set(requested)
    stack = list(requested)
    while stack:
        current = stack.pop()
        for dependency in module_map[current].get("depends_on", []):
            if dependency not in closure:
                closure.add(dependency)
                stack.append(dependency)
    return closure, sorted(closure - requested)


def build_analysis_plan(
    registry_report: Mapping[str, Any],
    eligibility: Mapping[str, Mapping[str, Any]],
    selected_module_ids: Iterable[str],
    *,
    study_id: str,
    session_id: str,
    protocol_id: str,
    run_folder: Path | str,
    workspace_sha256: str,
    outcomes_reviewed: bool = False,
    previous_locked_module_ids: Iterable[str] = (),
) -> dict[str, Any]:
    if registry_report.get("status") != "PASS":
        raise OrchestrationError("Cannot build a plan from an invalid registry")
    module_map = registry_report["module_map"]
    closure, auto_added = _dependency_closure(module_map, selected_module_ids)
    order = [module_id for module_id in registry_report["topological_order"] if module_id in closure]
    previous = set(previous_locked_module_ids)
    modules = []
    for module_id in order:
        descriptor = module_map[module_id]
        effective_role = str(descriptor["analysis_role"])
        post_hoc = bool(outcomes_reviewed and module_id not in previous)
        if post_hoc:
            effective_role = "POST_HOC_EXPLORATORY"
        modules.append({
            "module_id": module_id,
            "module_version": descriptor["module_version"],
            "display_name": descriptor["display_name"],
            "category": descriptor["category"],
            "declared_role": descriptor["analysis_role"],
            "effective_role": effective_role,
            "post_hoc": post_hoc,
            "primary_conclusion_authority": "NONE" if post_hoc else descriptor["primary_conclusion_authority"],
            "depends_on": list(descriptor["depends_on"]),
            "execution": deepcopy(descriptor["execution"]),
            "multiplicity_family": descriptor["multiplicity_family"],
            "missing_data_policy": descriptor["missing_data_policy"],
            "eligibility": deepcopy(dict(eligibility[module_id])),
            "descriptor_sha256": sha256_json(descriptor),
            "code_sha256": descriptor["code_sha256"],
            "configuration_sha256": deepcopy(descriptor["configuration_sha256"]),
        })
    return {
        "schema": PLAN_SCHEMA,
        "version": "0.1.0",
        "plan_id": str(uuid.uuid4()),
        "created_utc": utc_now(),
        "status": "DRAFT",
        "study_id": str(study_id),
        "session_id": str(session_id),
        "protocol_id": str(protocol_id),
        "run_folder": str(Path(run_folder).expanduser().resolve(strict=False)),
        "workspace_sha256_at_draft": str(workspace_sha256),
        "registry_sha256": registry_report["registry_sha256"],
        "registry_content_sha256": registry_report["registry_content_sha256"],
        "requested_module_ids": sorted(set(str(value) for value in selected_module_ids)),
        "auto_added_dependencies": auto_added,
        "execution_order": order,
        "modules": modules,
        "outcomes_reviewed_before_plan": bool(outcomes_reviewed),
        "contains_post_hoc_modules": any(row["post_hoc"] for row in modules),
        "boundary": BOUNDARY,
    }


def _plan_hash_payload(plan: Mapping[str, Any]) -> dict[str, Any]:
    value = deepcopy(dict(plan))
    value.pop("plan_lock_sha256", None)
    # Study Workspace adds this provenance-only wrapper fingerprint after the
    # immutable plan is locked. It is not part of the plan's own lock hash.
    value.pop("workspace_snapshot_sha256", None)
    return value


def lock_analysis_plan(
    plan: Mapping[str, Any], output_path: Path | str, *, operator: str, caution_acknowledgement: str = ""
) -> dict[str, Any]:
    value = deepcopy(dict(plan))
    if value.get("schema") != PLAN_SCHEMA or value.get("status") != "DRAFT":
        raise OrchestrationError("Only a valid DRAFT analysis plan can be locked")
    if not str(operator).strip():
        raise OrchestrationError("An operator name is required to lock an analysis plan")
    states = {row.get("eligibility", {}).get("status") for row in value.get("modules", [])}
    if "INELIGIBLE" in states:
        raise OrchestrationError("An INELIGIBLE module cannot be included in a locked plan")
    if "CAUTION" in states and not str(caution_acknowledgement).strip():
        raise OrchestrationError("CAUTION modules require a recorded operator acknowledgement")
    value["schema"] = PLAN_LOCK_SCHEMA
    value["status"] = "LOCKED"
    value["locked_utc"] = utc_now()
    value["locked_by"] = str(operator).strip()
    value["caution_acknowledgement"] = str(caution_acknowledgement).strip()
    value["plan_lock_sha256"] = sha256_json(_plan_hash_payload(value))
    target = Path(output_path).expanduser().resolve(strict=False)
    if target.exists():
        raise OrchestrationError("Analysis plan locks are immutable; choose a new path or session")
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
        os.replace(temp, target)
    finally:
        temp.unlink(missing_ok=True)
    return value


def validate_plan_lock(plan: Mapping[str, Any]) -> dict[str, Any]:
    errors = []
    if plan.get("schema") != PLAN_LOCK_SCHEMA or plan.get("status") != "LOCKED":
        errors.append("plan is not a locked v0.1 analysis plan")
    recorded = str(plan.get("plan_lock_sha256") or "")
    actual = sha256_json(_plan_hash_payload(plan))
    if not SHA_RE.fullmatch(recorded) or recorded != actual:
        errors.append("plan lock hash mismatch")
    if any(row.get("post_hoc") and row.get("effective_role") != "POST_HOC_EXPLORATORY" for row in plan.get("modules", [])):
        errors.append("a post-hoc module was not demoted to POST_HOC_EXPLORATORY")
    return {"status": "PASS" if not errors else "INELIGIBLE", "errors": errors, "actual_sha256": actual, "boundary": BOUNDARY}


def build_post_hoc_supplement(plan_lock: Mapping[str, Any], module: Mapping[str, Any], eligibility: Mapping[str, Any]) -> dict[str, Any]:
    if validate_plan_lock(plan_lock)["status"] != "PASS":
        raise OrchestrationError("A valid locked parent plan is required")
    return {
        "schema": POSTHOC_SCHEMA,
        "supplement_id": str(uuid.uuid4()),
        "created_utc": utc_now(),
        "parent_plan_id": plan_lock.get("plan_id"),
        "parent_plan_lock_sha256": plan_lock.get("plan_lock_sha256"),
        "module_id": module.get("module_id"),
        "module_version": module.get("module_version"),
        "declared_role": module.get("analysis_role"),
        "effective_role": "POST_HOC_EXPLORATORY",
        "primary_conclusion_authority": "NONE",
        "eligibility": deepcopy(dict(eligibility)),
        "descriptor_sha256": sha256_json(module),
        "boundary": "This module was added after the locked plan and cannot alter a preregistered or primary conclusion.",
    }


def execution_graph(plan_lock: Mapping[str, Any], completion_records: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    validation = validate_plan_lock(plan_lock)
    if validation["status"] != "PASS":
        raise OrchestrationError("Execution requires a valid locked analysis plan")
    completions = {
        str(row.get("module_id")): deepcopy(dict(row))
        for row in completion_records
        if isinstance(row, Mapping) and row.get("status") == "COMPLETE"
    }
    nodes = []
    for row in plan_lock.get("modules", []):
        module_id = str(row.get("module_id"))
        dependencies = list(row.get("depends_on", []))
        if module_id in completions:
            status = "COMPLETE"
            reason = "A completion record is attached."
        elif any(dependency not in completions for dependency in dependencies):
            status = "BLOCKED"
            reason = "Waiting for: " + ", ".join(dependency for dependency in dependencies if dependency not in completions)
        elif row.get("eligibility", {}).get("status") == "INELIGIBLE":
            status = "INELIGIBLE"
            reason = "The locked eligibility record is INELIGIBLE."
        else:
            status = "READY"
            reason = "Dependencies are complete; revalidate inputs at click time before launch."
        nodes.append({
            "module_id": module_id,
            "display_name": row.get("display_name"),
            "status": status,
            "reason": reason,
            "depends_on": dependencies,
            "execution": deepcopy(row.get("execution", {})),
            "effective_role": row.get("effective_role"),
        })
    next_ready = next((row["module_id"] for row in nodes if row["status"] == "READY"), None)
    return {
        "schema": EXECUTION_GRAPH_SCHEMA,
        "plan_id": plan_lock.get("plan_id"),
        "plan_lock_sha256": plan_lock.get("plan_lock_sha256"),
        "nodes": nodes,
        "next_ready_module_id": next_ready,
        "complete_count": sum(row["status"] == "COMPLETE" for row in nodes),
        "total_count": len(nodes),
        "status": "COMPLETE" if nodes and all(row["status"] == "COMPLETE" for row in nodes) else "ACTIVE",
        "boundary": BOUNDARY,
    }


def output_inventory(path: Path | str, *, maximum_files: int = 4096) -> dict[str, Any]:
    root = Path(path).expanduser().resolve(strict=False)
    if not root.exists() or root.is_symlink():
        raise OrchestrationError("Output path is missing or is a symbolic link")
    files = [root] if root.is_file() else sorted((item for item in root.rglob("*") if item.is_file() and not item.is_symlink()), key=lambda item: item.as_posix().casefold())
    if len(files) > maximum_files:
        raise OrchestrationError(f"Output contains more than {maximum_files} files")
    ledger = []
    for file in files:
        relative = file.name if root.is_file() else file.relative_to(root).as_posix()
        ledger.append({"path": relative, "sha256": sha256_file(file), "byte_count": file.stat().st_size, "raw_recording_extension": file.suffix.casefold() in RAW_RECORDING_EXTENSIONS})
    return {
        "root": str(root),
        "file_count": len(ledger),
        "total_bytes": sum(row["byte_count"] for row in ledger),
        "ledger_sha256": sha256_json(ledger),
        "files": ledger,
    }


def completion_record(module_id: str, output_path: Path | str, *, operator: str, notes: str = "") -> dict[str, Any]:
    inventory = output_inventory(output_path)
    return {
        "schema": "PRAYCG_AnalysisModuleCompletion_v0_1",
        "completion_id": str(uuid.uuid4()),
        "module_id": str(module_id),
        "status": "COMPLETE",
        "recorded_utc": utc_now(),
        "recorded_by": str(operator).strip(),
        "notes": str(notes),
        "output_inventory": inventory,
        "scientific_validation_effect": "NONE",
        "boundary": "Completion records provenance and operator review; it does not mean an analysis result is scientifically valid.",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PRAYCG Analysis Orchestrator v0.1")
    parser.add_argument("--registry", type=Path, required=True)
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--validate-registry", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    report = validate_registry(args.registry, args.package_root)
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
