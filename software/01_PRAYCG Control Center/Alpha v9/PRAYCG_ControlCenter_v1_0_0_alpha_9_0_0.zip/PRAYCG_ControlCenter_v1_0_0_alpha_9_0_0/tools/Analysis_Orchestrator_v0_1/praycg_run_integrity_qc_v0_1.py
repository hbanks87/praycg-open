#!/usr/bin/env python3
"""Conservative file/event integrity preflight for a selected PRAYCG run.

This module does not inspect EEG physiology or certify scientific validity.  It
records file presence, ambiguity, event timestamp order when parseable, and the
limits of what was not checked.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA = "PRAYCG_RunIntegrityTimingQC_v0_1"
UUID_RE = re.compile(r"(?i)\b[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\b")
TIME_KEYS = ("timestamp", "time", "onset", "lsl_time", "local_clock", "start_time")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _unique_files(root: Path, patterns: tuple[str, ...]) -> list[Path]:
    rows: dict[str, Path] = {}
    for pattern in patterns:
        for path in root.glob(pattern):
            if path.is_file() and not path.is_symlink():
                rows[str(path.resolve()).casefold()] = path.resolve()
    return sorted(rows.values(), key=lambda item: item.as_posix().casefold())


def _flatten_json_events(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        for key in ("events", "markers", "rows", "records"):
            if isinstance(value.get(key), list):
                return [item for item in value[key] if isinstance(item, dict)]
    return []


def _event_rows(path: Path) -> tuple[list[dict[str, Any]], list[str]]:
    warnings: list[str] = []
    try:
        if path.suffix.casefold() == ".csv":
            with path.open("r", encoding="utf-8-sig", newline="") as stream:
                return list(csv.DictReader(stream)), warnings
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        rows = _flatten_json_events(value)
        if not rows:
            warnings.append("Event JSON did not expose an events/markers/rows/records array.")
        return rows, warnings
    except (OSError, UnicodeError, csv.Error, json.JSONDecodeError) as exc:
        return [], [f"Event table could not be parsed: {type(exc).__name__}: {exc}"]


def _timestamps(rows: list[dict[str, Any]]) -> tuple[list[float], str | None]:
    if not rows:
        return [], None
    for key in TIME_KEYS:
        parsed: list[float] = []
        valid = True
        for row in rows:
            try:
                parsed.append(float(row.get(key)))
            except (TypeError, ValueError):
                valid = False
                break
        if valid and parsed:
            return parsed, key
    return [], None


def _run_uuids(root: Path) -> list[str]:
    found: set[str] = set()
    for path in _unique_files(root, ("*.json", "**/*.json"))[:256]:
        if path.stat().st_size > 2 * 1024 * 1024:
            continue
        try:
            text = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeError):
            continue
        found.update(value.lower() for value in UUID_RE.findall(text))
    return sorted(found)


def inspect_run(run_folder: Path) -> dict[str, Any]:
    root = run_folder.expanduser().resolve(strict=False)
    findings: list[dict[str, str]] = []
    warnings: list[str] = []
    xdf = _unique_files(root, ("*.xdf", "**/*.xdf")) if root.is_dir() else []
    events = _unique_files(root, ("*events.json", "**/*events.json", "*events.csv", "**/*events.csv")) if root.is_dir() else []
    if not root.is_dir():
        findings.append({"severity": "ERROR", "code": "RUN_FOLDER_MISSING", "message": "Selected run folder does not exist."})
    if len(xdf) != 1:
        findings.append({
            "severity": "ERROR",
            "code": "XDF_MISSING_OR_AMBIGUOUS",
            "message": f"Expected exactly one XDF recording; found {len(xdf)}.",
        })
    elif xdf[0].stat().st_size == 0:
        findings.append({"severity": "ERROR", "code": "XDF_EMPTY", "message": "The selected XDF is empty."})
    if len(events) != 1:
        findings.append({
            "severity": "ERROR" if not events else "CAUTION",
            "code": "EVENT_LOG_MISSING_OR_AMBIGUOUS",
            "message": f"Expected exactly one event log; found {len(events)}.",
        })

    event_report: dict[str, Any] = {
        "status": "NOT_CHECKED",
        "row_count": 0,
        "timestamp_field": None,
        "monotonic_non_decreasing": None,
        "strictly_increasing": None,
        "negative_gap_count": None,
        "duplicate_timestamp_count": None,
    }
    if len(events) == 1:
        rows, parse_warnings = _event_rows(events[0])
        warnings.extend(parse_warnings)
        stamps, field = _timestamps(rows)
        event_report["row_count"] = len(rows)
        event_report["timestamp_field"] = field
        if stamps:
            gaps = [right - left for left, right in zip(stamps, stamps[1:])]
            negative = sum(value < 0 for value in gaps)
            duplicates = sum(value == 0 for value in gaps)
            event_report.update({
                "status": "PASS" if negative == 0 else "INELIGIBLE",
                "monotonic_non_decreasing": negative == 0,
                "strictly_increasing": negative == 0 and duplicates == 0,
                "negative_gap_count": negative,
                "duplicate_timestamp_count": duplicates,
                "minimum_gap_s": min(gaps) if gaps else None,
                "maximum_gap_s": max(gaps) if gaps else None,
            })
            if negative:
                findings.append({"severity": "ERROR", "code": "EVENT_TIME_NONMONOTONIC", "message": "Parsed event timestamps move backward."})
            if duplicates:
                warnings.append(f"Event log contains {duplicates} duplicate adjacent timestamp(s).")
        else:
            event_report["status"] = "CAUTION"
            warnings.append("Event timestamp monotonicity could not be evaluated from recognized fields.")

    uuids = _run_uuids(root) if root.is_dir() else []
    if not uuids:
        warnings.append("No full run/session UUID was found in bounded JSON metadata.")
    elif len(uuids) > 1:
        warnings.append(f"Multiple UUIDs were found ({len(uuids)}); this preflight does not infer which one is authoritative.")

    errors = [row for row in findings if row["severity"] == "ERROR"]
    cautions = [row for row in findings if row["severity"] == "CAUTION"]
    status = "INELIGIBLE" if errors else ("CAUTION" if cautions or warnings else "PASS")
    return {
        "schema": SCHEMA,
        "version": "0.1.0",
        "generated_utc": utc_now(),
        "status": status,
        "run_folder": str(root),
        "run_uuid_candidates": uuids,
        "recording": {
            "match_count": len(xdf),
            "files": [
                {"path": str(path), "byte_count": path.stat().st_size, "sha256": sha256_file(path)}
                for path in xdf
            ],
        },
        "event_log": {
            "match_count": len(events),
            "files": [
                {"path": str(path), "byte_count": path.stat().st_size, "sha256": sha256_file(path)}
                for path in events
            ],
            "timing": event_report,
        },
        "findings": findings,
        "warnings": warnings,
        "not_performed": [
            "XDF stream parsing",
            "EEG signal-quality or artifact evaluation",
            "physiological plausibility",
            "hardware or ALS bench validation",
            "scientific, causal, clinical, or endpoint validation",
        ],
        "boundary": "File/event integrity QC is required workflow evidence, not evidence that a physiological signal or scientific claim is valid.",
    }


def write_report(run_folder: Path, output_path: Path) -> dict[str, Any]:
    report = inspect_run(run_folder)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PRAYCG run file/event integrity QC v0.1")
    parser.add_argument("--run-folder", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    report = write_report(args.run_folder, args.out)
    print(json.dumps(report, indent=2))
    return 2 if report["status"] == "INELIGIBLE" else (1 if report["status"] == "CAUTION" else 0)


if __name__ == "__main__":
    raise SystemExit(main())
