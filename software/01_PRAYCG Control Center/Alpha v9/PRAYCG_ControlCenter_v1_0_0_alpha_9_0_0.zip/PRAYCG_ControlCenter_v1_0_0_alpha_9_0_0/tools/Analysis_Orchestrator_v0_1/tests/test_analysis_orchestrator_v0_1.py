import json
import tempfile
import unittest
from pathlib import Path
import sys

MODULE_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(MODULE_ROOT))

from praycg_analysis_orchestrator_v0_1 import (  # noqa: E402
    build_analysis_plan,
    build_post_hoc_supplement,
    completion_record,
    execution_graph,
    lock_analysis_plan,
    preflight_registry,
    validate_plan_lock,
    validate_registry,
)


class AnalysisOrchestratorTests(unittest.TestCase):
    def _fixture(self, root: Path) -> Path:
        run = root / "run"
        run.mkdir()
        (run / "recording.xdf").write_bytes(b"XDF fixture")
        (run / "events.json").write_text(json.dumps({"events": [{"timestamp": 1, "event": "BASELINE_START"}]}))
        return run

    def test_registry_hashes_plan_lock_dependency_graph_and_posthoc_boundary(self):
        report = validate_registry(PACKAGE_ROOT / "config" / "analysis_orchestration_registry_v0_1.json", PACKAGE_ROOT)
        self.assertEqual(report["status"], "PASS", report["errors"])
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            run = self._fixture(root)
            eligibility = preflight_registry(
                report,
                run_folder=run,
                analysis_root=root / "analysis",
                protocol_id="PRAYCG3",
                available_modalities=["EEG", "LSL_RECORDING"],
                observed_sample_rates={"EEG": 250},
                timing_grade="PASS",
            )
            selected = ["full_chained_analysis_v1_6_1"]
            draft = build_analysis_plan(
                report,
                eligibility,
                selected,
                study_id="11111111-1111-4111-8111-111111111111",
                session_id="22222222-2222-4222-8222-222222222222",
                protocol_id="PRAYCG3",
                run_folder=run,
                workspace_sha256="a" * 64,
            )
            self.assertEqual(
                draft["execution_order"][:3],
                ["run_integrity_timing_qc_v0_1", "master_comprehensive_suite_v1_6_0", "full_chained_analysis_v1_6_1"],
            )
            lock = lock_analysis_plan(draft, root / "plan.json", operator="Tester", caution_acknowledgement="Dependencies are prospective.")
            lock["workspace_snapshot_sha256"] = "b" * 64
            self.assertEqual(validate_plan_lock(lock)["status"], "PASS")
            graph = execution_graph(lock, [])
            self.assertEqual(graph["next_ready_module_id"], "run_integrity_timing_qc_v0_1")
            output = root / "qc-output.json"
            output.write_text("{}")
            complete = completion_record("run_integrity_timing_qc_v0_1", output, operator="Tester")
            graph = execution_graph(lock, [complete])
            self.assertEqual(graph["next_ready_module_id"], "master_comprehensive_suite_v1_6_0")
            module = report["module_map"]["cue_locked_gamma_forensics_v0_1"]
            supplement = build_post_hoc_supplement(lock, module, eligibility["cue_locked_gamma_forensics_v0_1"])
            self.assertEqual(supplement["effective_role"], "POST_HOC_EXPLORATORY")
            self.assertEqual(supplement["primary_conclusion_authority"], "NONE")


if __name__ == "__main__":
    unittest.main()
