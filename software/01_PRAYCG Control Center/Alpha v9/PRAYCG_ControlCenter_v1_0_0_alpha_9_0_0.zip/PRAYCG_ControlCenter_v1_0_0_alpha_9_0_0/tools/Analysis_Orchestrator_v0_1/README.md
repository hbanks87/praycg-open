# Analysis Orchestrator v0.1

Alpha.6.1 validates a strict module registry, evaluates run/protocol compatibility,
locks a dependency-aware analysis plan before outcome access, automatically binds
dependencies, and resolves the next executable node. Modules added after outcome
review are irreversibly labeled `POST_HOC_EXPLORATORY` with no primary authority.

The orchestrator never imports registered analysis code. Managed launches remain
operator actions and are revalidated at click time by the Control Center.
