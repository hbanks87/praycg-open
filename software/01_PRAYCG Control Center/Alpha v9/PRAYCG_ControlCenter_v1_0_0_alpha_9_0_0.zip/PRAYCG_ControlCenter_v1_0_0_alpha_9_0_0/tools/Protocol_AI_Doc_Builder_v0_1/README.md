# PRAYCG Protocol AI Docs Builder v0.1

This standalone builder helps a researcher explain a proposed protocol and create a structured folder to review and upload to an AI collaborator. It does not generate runnable code.

The form asks for a substantial account of the protocol's intent, theoretical rationale, construction, and hypotheses. It also collects structured information about conditions, stimuli, participant tasks, timing, measures, hardware roles, confounds, quality control, analysis, ethics, sources, and unresolved decisions.

Selecting **Create Protocol AI Docs** writes a sanitized, new custom-protocol folder containing:

- `README.md`
- `USER_PROTOCOL_INPUT.md`
- `user_protocol_input.json`
- `PROTOCOL_DESIGN_BRIEF.md`
- `AI_PORTING_HANDOFF.md`
- `protocol_draft_manifest.json`

Every package is marked `DESIGN_DRAFT_AI_ASSISTED_REVIEW_REQUIRED`. Existing folders are never overwritten. The manifest records hashes for the other five documents and explicitly denies executable, runtime, hardware, participant-acquisition, analysis, scientific, and clinical authority.

## Control Center integration

Launch this script as a separate process:

```text
python tools/Protocol_AI_Doc_Builder_v0_1/praycg_protocol_ai_doc_builder_v0_1.py --output-root <custom-protocol-parent-folder>
```

The stable Python API is:

```python
from tools.Protocol_AI_Doc_Builder_v0_1 import ProtocolDraftInput, create_protocol_ai_docs

result = create_protocol_ai_docs(draft, output_root)
```

The form launch API is:

```python
from tools.Protocol_AI_Doc_Builder_v0_1.praycg_protocol_ai_doc_builder_v0_1 import launch_ui

launch_ui(output_root)
```

For automated use, pass a JSON object with the `ProtocolDraftInput` field names to `--input-json`. JSON values must be text. No JSON content is imported or executed.

## Boundary

This tool is a design-document generator. It never downloads, imports, compiles, or executes generated protocol code, and it cannot add a draft to the Protocol Atlas, unlock a runner, approve a stimulus, validate a device, arm acquisition, authorize analysis, or establish scientific validity.

