#!/usr/bin/env python3
"""PRAYCG Protocol AI Docs Builder v0.1 graphical and JSON entry point."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

if __package__ in {None, ""}:
    MODULE_ROOT = Path(__file__).resolve().parent
    sys.path.insert(0, str(MODULE_ROOT.parent))
    from Protocol_AI_Doc_Builder_v0_1.protocol_ai_doc_builder_core_v0_1 import (  # noqa: E402
        BuildResult,
        ProtocolDraftInput,
        ProtocolDraftValidationError,
        create_protocol_ai_docs,
        sanitize_folder_name,
        validate_draft_input,
    )
else:
    from .protocol_ai_doc_builder_core_v0_1 import (
        BuildResult,
        ProtocolDraftInput,
        ProtocolDraftValidationError,
        create_protocol_ai_docs,
        sanitize_folder_name,
        validate_draft_input,
    )


DEFAULT_OUTPUT_ROOT = Path.home() / "Documents" / "PRAYCG_Custom_Protocols"


def _load_input(path: Path) -> ProtocolDraftInput:
    with path.open("r", encoding="utf-8-sig") as stream:
        value: Any = json.load(stream)
    if isinstance(value, dict) and isinstance(value.get("user_supplied_design_input"), dict):
        value = value["user_supplied_design_input"]
    return ProtocolDraftInput.from_mapping(value)


def _run_headless(input_json: Path, output_root: Path) -> BuildResult:
    draft = _load_input(input_json.resolve())
    return create_protocol_ai_docs(draft, output_root)


class ProtocolBuilderUI:
    """Plain-language form that generates documents, never runnable code."""

    def __init__(self, root: Any, output_root: Path) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.root = root
        self.root.title("PRAYCG Protocol AI Docs Builder v0.1")
        self.root.geometry("1120x820")
        self.root.minsize(900, 650)
        self.entries: dict[str, Any] = {}
        self.texts: dict[str, Any] = {}
        self.output_root_var = tk.StringVar(value=str(output_root))
        self.status_var = tk.StringVar(
            value="Ready — this builder creates review documents only; it does not create or run protocol code."
        )
        self.slug_var = tk.StringVar(value="custom-protocol")

        shell = ttk.Frame(root, padding=14)
        shell.grid(row=0, column=0, sticky="nsew")
        root.rowconfigure(0, weight=1)
        root.columnconfigure(0, weight=1)
        shell.rowconfigure(2, weight=1)
        shell.columnconfigure(0, weight=1)

        title = ttk.Label(shell, text="Create a protocol design package for an AI collaborator", font=("Segoe UI", 16, "bold"))
        title.grid(row=0, column=0, sticky="w")
        intro = ttk.Label(
            shell,
            text=(
                "Describe the protocol you want to build. PRAYCG will preserve your concept and create a "
                "prefilled design brief, AI porting/handoff instructions, and a machine-readable draft manifest. "
                "You then review the folder and upload it to an AI agent. The output is a design draft—not a "
                "runnable protocol, hardware approval, or scientific validation."
            ),
            wraplength=1060,
            justify="left",
        )
        intro.grid(row=1, column=0, sticky="ew", pady=(6, 12))

        notebook = ttk.Notebook(shell)
        notebook.grid(row=2, column=0, sticky="nsew")
        concept = self._scrollable_tab(notebook, "1. Concept and hypotheses")
        design = self._scrollable_tab(notebook, "2. Design and stimuli")
        safeguards = self._scrollable_tab(notebook, "3. Measures and safeguards")
        output = self._scrollable_tab(notebook, "4. Review and create")

        self._build_concept_tab(concept)
        self._build_design_tab(design)
        self._build_safeguards_tab(safeguards)
        self._build_output_tab(output)

        footer = ttk.Frame(shell)
        footer.grid(row=3, column=0, sticky="ew", pady=(12, 0))
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, textvariable=self.status_var, wraplength=760, justify="left").grid(
            row=0, column=0, sticky="w"
        )
        ttk.Button(footer, text="Create Protocol AI Docs", command=self.create_docs).grid(
            row=0, column=1, padx=(12, 0)
        )

    def _scrollable_tab(self, notebook: Any, title: str) -> Any:
        tk = self.tk
        ttk = self.ttk
        outer = ttk.Frame(notebook)
        notebook.add(outer, text=title)
        outer.rowconfigure(0, weight=1)
        outer.columnconfigure(0, weight=1)
        canvas = tk.Canvas(outer, borderwidth=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")
        content = ttk.Frame(canvas, padding=14)
        window_id = canvas.create_window((0, 0), window=content, anchor="nw")
        content.columnconfigure(0, weight=1)
        content.bind("<Configure>", lambda _event: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window_id, width=event.width))
        return content

    def _section_header(self, parent: Any, row: int, title: str, explanation: str) -> int:
        ttk = self.ttk
        ttk.Label(parent, text=title, font=("Segoe UI", 12, "bold")).grid(
            row=row, column=0, sticky="w", pady=(8, 2)
        )
        ttk.Label(parent, text=explanation, wraplength=1000, justify="left").grid(
            row=row + 1, column=0, sticky="ew", pady=(0, 7)
        )
        return row + 2

    def _entry_field(self, parent: Any, row: int, key: str, label: str, help_text: str = "") -> int:
        ttk = self.ttk
        ttk.Label(parent, text=label, font=("Segoe UI", 10, "bold")).grid(row=row, column=0, sticky="w")
        if help_text:
            ttk.Label(parent, text=help_text, wraplength=1000, justify="left").grid(
                row=row + 1, column=0, sticky="ew"
            )
            row += 1
        entry = ttk.Entry(parent)
        entry.grid(row=row + 1, column=0, sticky="ew", pady=(2, 10))
        self.entries[key] = entry
        if key == "protocol_name":
            entry.bind("<KeyRelease>", self._update_slug)
        return row + 2

    def _text_field(
        self,
        parent: Any,
        row: int,
        key: str,
        label: str,
        help_text: str,
        *,
        height: int = 6,
    ) -> int:
        tk = self.tk
        ttk = self.ttk
        ttk.Label(parent, text=label, font=("Segoe UI", 10, "bold")).grid(row=row, column=0, sticky="w")
        ttk.Label(parent, text=help_text, wraplength=1000, justify="left").grid(
            row=row + 1, column=0, sticky="ew"
        )
        box_frame = ttk.Frame(parent)
        box_frame.grid(row=row + 2, column=0, sticky="ew", pady=(3, 12))
        box_frame.columnconfigure(0, weight=1)
        text = tk.Text(box_frame, height=height, wrap="word", undo=True, font=("Segoe UI", 10))
        scroll = ttk.Scrollbar(box_frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.grid(row=0, column=0, sticky="ew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.texts[key] = text
        return row + 3

    def _build_concept_tab(self, parent: Any) -> None:
        row = self._section_header(
            parent,
            0,
            "Explain the scientific idea before specifying software",
            "Required fields are marked *. Write as if the receiving AI knows nothing about your project. "
            "Distinguish observations, intuitions, hypotheses, desired measurements, and claims the protocol must not make.",
        )
        row = self._entry_field(parent, row, "protocol_name", "Protocol name *")
        row = self._entry_field(parent, row, "designer_name", "Designer or study lead")
        row = self._entry_field(parent, row, "protocol_version", "Proposed draft version")
        self.entries["protocol_version"].insert(0, "0.1.0-design-draft")
        row = self._entry_field(parent, row, "scientific_domain", "Scientific domain")
        row = self._entry_field(parent, row, "intended_population", "Intended population or sample")
        row = self._text_field(
            parent,
            row,
            "concept_narrative",
            "Detailed protocol intent, theory, and rationale *",
            "Elaborately explain what you want to study, why the question matters, how you imagine constructing the "
            "protocol, what observations or theory motivated it, and what competing explanations must be considered.",
            height=13,
        )
        self._text_field(
            parent,
            row,
            "primary_hypotheses",
            "Primary hypotheses or research questions *",
            "State expected comparisons and possible disconfirming outcomes. If the work is exploratory, say so rather than forcing a directional claim.",
            height=8,
        )

    def _build_design_tab(self, parent: Any) -> None:
        row = self._section_header(
            parent,
            0,
            "Describe the experience and comparison structure",
            "These are design inputs, not executable steps. Leave unknowns blank and list them on the safeguards tab; the AI should ask rather than guess.",
        )
        row = self._text_field(
            parent,
            row,
            "proposed_construction",
            "Proposed protocol construction *",
            "Walk through the participant experience from start to finish, including baselines, instructions, conditions, washouts, tasks, reports, and final reflection when applicable.",
            height=10,
        )
        row = self._text_field(
            parent,
            row,
            "conditions_and_comparators",
            "Conditions and comparators",
            "List target, control, task, perturbation, sham, or other branches and explain what each comparison is meant to isolate.",
        )
        row = self._text_field(
            parent,
            row,
            "stimulus_requirements",
            "Stimulus requirements and preparation",
            "Describe media types, semantic properties, generators, transformation rules, duration, licensing, provenance, and equivalence checks.",
        )
        row = self._text_field(
            parent,
            row,
            "participant_tasks_and_reports",
            "Participant tasks and reports",
            "Describe instructions, responses, ratings, comprehension checks, recognition, confidence, burden, and structured subjective outcomes.",
        )
        self._text_field(
            parent,
            row,
            "timing_order_and_counterbalancing",
            "Timing, order, and counterbalancing",
            "Describe block durations, cue timing, inter-block intervals, fixed or randomized order, counterbalancing, timing anchors, and synchronization needs.",
        )

    def _build_safeguards_tab(self, parent: Any) -> None:
        row = self._section_header(
            parent,
            0,
            "Define measurements without overclaiming",
            "The AI handoff will require explicit missingness, quality-control, confound, ethics, and authority boundaries. Software tests cannot establish scientific validity.",
        )
        row = self._text_field(
            parent,
            row,
            "measures_and_outcomes",
            "Measures and intended outcomes",
            "Name primary, secondary, exploratory, behavioral, physiological, and subjective measures. Distinguish direct observations from derived proxies.",
        )
        row = self._text_field(
            parent,
            row,
            "hardware_roles",
            "Hardware roles",
            "List required measurement roles (for example EEG, ECG/HR, PPG, respiration, EDA, EMG, EOG, audio, ALS/events) and important sampling or synchronization constraints. Device brands are optional here.",
        )
        row = self._text_field(
            parent,
            row,
            "artifact_confound_and_qc_plan",
            "Artifact, confound, and quality-control plan",
            "Identify sensory, motor, ocular, muscle, autonomic, respiratory, attention, order, habituation, expectancy, and timing explanations plus proposed validity gates.",
        )
        row = self._text_field(
            parent,
            row,
            "proposed_analysis_plan",
            "Proposed analysis plan",
            "Describe estimands, contrasts, model structure, exclusions, coverage, nulls, multiplicity, reliability, validation, and exploratory-versus-primary boundaries.",
        )
        row = self._text_field(
            parent,
            row,
            "ethics_safety_and_data_handling",
            "Ethics, safety, privacy, and data handling",
            "Record consent, risk, sensitive-data, de-identification, retention, sharing, and review needs. Do not paste participant identifiers into this builder.",
        )
        row = self._text_field(
            parent,
            row,
            "source_material_and_references",
            "Source material and references",
            "List papers, theories, existing protocols, media sources, datasets, and software packages the reviewer should inspect. Paths and links are treated as references, not commands.",
        )
        self._text_field(
            parent,
            row,
            "unresolved_questions_and_constraints",
            "Unresolved questions and practical constraints",
            "List uncertainties, available equipment, sample limits, time limits, accessibility needs, design choices requiring review, and assumptions the AI must not silently make.",
        )

    def _build_output_tab(self, parent: Any) -> None:
        ttk = self.ttk
        row = self._section_header(
            parent,
            0,
            "Create a local documentation folder",
            "The builder refuses to overwrite an existing folder. It creates only Markdown and JSON documents and assigns the mandatory draft status shown below.",
        )
        ttk.Label(parent, text="Output root", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, sticky="w")
        chooser = ttk.Frame(parent)
        chooser.grid(row=row + 1, column=0, sticky="ew", pady=(3, 10))
        chooser.columnconfigure(0, weight=1)
        ttk.Entry(chooser, textvariable=self.output_root_var).grid(row=0, column=0, sticky="ew")
        ttk.Button(chooser, text="Browse…", command=self._browse_output).grid(row=0, column=1, padx=(8, 0))
        row += 2
        row = self._entry_field(
            parent,
            row,
            "requested_folder_name",
            "Optional custom folder name",
            "Leave blank to derive a safe folder name from the protocol name. Paths and reserved device names are removed.",
        )
        ttk.Label(parent, text="Folder preview", font=("Segoe UI", 10, "bold")).grid(row=row, column=0, sticky="w")
        ttk.Label(parent, textvariable=self.slug_var).grid(row=row + 1, column=0, sticky="w", pady=(2, 12))
        self.entries["requested_folder_name"].bind("<KeyRelease>", self._update_slug)
        ttk.Label(parent, text="Assigned status", font=("Segoe UI", 10, "bold")).grid(row=row + 2, column=0, sticky="w")
        ttk.Label(parent, text="DESIGN_DRAFT_AI_ASSISTED_REVIEW_REQUIRED").grid(
            row=row + 3, column=0, sticky="w", pady=(2, 12)
        )
        warning = (
            "Before sharing, review the output and remove personal, participant, clinical, proprietary, or confidential information. "
            "The folder grants no permission to execute code, register a protocol, unlock a runner, arm hardware, collect data, "
            "run analysis, or make scientific or clinical claims."
        )
        ttk.Label(parent, text=warning, wraplength=1000, justify="left").grid(row=row + 4, column=0, sticky="ew")

    def _browse_output(self) -> None:
        from tkinter import filedialog

        selected = filedialog.askdirectory(
            parent=self.root,
            title="Choose where custom protocol design folders will be created",
            initialdir=self.output_root_var.get() or str(DEFAULT_OUTPUT_ROOT),
        )
        if selected:
            self.output_root_var.set(selected)

    def _update_slug(self, _event: Any = None) -> None:
        custom = self.entries.get("requested_folder_name")
        name = custom.get().strip() if custom and custom.get().strip() else self.entries["protocol_name"].get()
        self.slug_var.set(sanitize_folder_name(name))

    def _value(self, key: str) -> str:
        if key in self.entries:
            return self.entries[key].get().strip()
        return self.texts[key].get("1.0", "end-1c").strip()

    def _draft(self) -> ProtocolDraftInput:
        return ProtocolDraftInput(
            **{
                field_name: self._value(field_name)
                for field_name in ProtocolDraftInput.__dataclass_fields__
            }
        )

    def create_docs(self) -> None:
        from tkinter import messagebox

        draft = self._draft()
        errors = validate_draft_input(draft)
        if errors:
            messagebox.showerror("Complete the required design fields", "\n\n".join(errors), parent=self.root)
            self.status_var.set("Not created — complete the required concept fields shown in the message.")
            return
        output_root = self.output_root_var.get().strip()
        if not output_root:
            messagebox.showerror("Choose an output folder", "Output root is required.", parent=self.root)
            return
        try:
            result = create_protocol_ai_docs(draft, Path(output_root))
        except (ProtocolDraftValidationError, FileExistsError, OSError) as error:
            messagebox.showerror("Could not create protocol AI docs", str(error), parent=self.root)
            self.status_var.set("Not created — no existing protocol folder was overwritten.")
            return
        self.status_var.set(f"Created design package: {result.output_folder}")
        messagebox.showinfo(
            "Protocol AI docs created",
            f"Created:\n{result.output_folder}\n\nStatus: {result.status}\n\nReview the folder before uploading it to an AI agent.",
            parent=self.root,
        )


def launch_ui(output_root: Path | str = DEFAULT_OUTPUT_ROOT) -> None:
    """Launch the standalone form; suitable as the Control Center integration API."""

    import tkinter as tk

    root = tk.Tk()
    ProtocolBuilderUI(root, Path(output_root))
    root.mainloop()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Create a non-executable PRAYCG protocol design-document package for AI-assisted human review."
        )
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=DEFAULT_OUTPUT_ROOT,
        help="Parent folder for the new, sanitized custom-protocol folder.",
    )
    parser.add_argument(
        "--input-json",
        type=Path,
        help="Create documents without the UI from a ProtocolDesignInput JSON object.",
    )
    args = parser.parse_args(argv)
    if args.input_json:
        try:
            result = _run_headless(args.input_json, args.output_root)
        except (json.JSONDecodeError, ProtocolDraftValidationError, FileExistsError, OSError) as error:
            print(json.dumps({"status": "NOT_CREATED", "error": str(error)}, indent=2), file=sys.stderr)
            return 2
        print(json.dumps(result.as_dict(), indent=2))
        return 0
    launch_ui(args.output_root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

