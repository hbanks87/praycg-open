# PRAYCG Acquisition Supervisor v1.0

The Alpha 9 supervisor is observer-only and bound to canonical stream contracts. It verifies complete outlet identity and ordered channel metadata before monitoring samples.

During the requested observation window it records effective sampling rate, drift in parts per million, sample-interval jitter, maximum gaps, timestamp regressions, non-finite timestamps, LSL clock corrections, source identity, and LSL UID continuity.

The supervisor does not restart an adapter, fabricate missing data, merge across restarts, approve a device, validate physiology, confirm a session, or ARM the protocol runner. A process or UID change is a new segment and is reported as ineligible for uninterrupted acquisition.
