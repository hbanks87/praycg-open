#!/usr/bin/env python3
"""Contract-bound, observer-only LSL acquisition supervisor for Alpha 9."""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import statistics
import sys
import time
from typing import Any, Iterable, Mapping, Sequence


SUPERVISOR_ROOT = Path(__file__).resolve().parent
PACKAGE_ROOT = SUPERVISOR_ROOT.parents[1]
FORGE_ROOT = PACKAGE_ROOT / "tools" / "Hardware_Forge_v1_0"
if str(FORGE_ROOT) not in sys.path:
    sys.path.insert(0, str(FORGE_ROOT))

from praycg_generic_lsl_intake_v1_0 import observation_from_stream_info  # noqa: E402
from praycg_stream_contract_v1_0 import (  # noqa: E402
    compare_contract,
    read_json,
    select_unambiguous_stream,
    validate_contract,
    write_json,
)


REPORT_SCHEMA = "PRAYCG_AcquisitionSupervisorReport_v1_0"
SEGMENT_SCHEMA = "PRAYCG_AcquisitionStreamSegment_v1_0"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _status(errors: Sequence[str], cautions: Sequence[str]) -> str:
    return "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS")


@dataclass
class TimestampAccumulator:
    nominal_srate: float
    gap_multiplier: float = 4.0
    sample_count: int = 0
    first_timestamp: float | None = None
    last_timestamp: float | None = None
    delta_count: int = 0
    delta_mean: float = 0.0
    delta_m2: float = 0.0
    max_gap_seconds: float = 0.0
    gap_count: int = 0
    timestamp_regression_count: int = 0
    nonfinite_timestamp_count: int = 0
    clock_offsets: list[float] = field(default_factory=list)

    def add(self, timestamp: Any) -> None:
        try:
            stamp = float(timestamp)
        except (TypeError, ValueError):
            self.nonfinite_timestamp_count += 1
            return
        if not math.isfinite(stamp):
            self.nonfinite_timestamp_count += 1
            return
        if self.first_timestamp is None:
            self.first_timestamp = stamp
        if self.last_timestamp is not None:
            delta = stamp - self.last_timestamp
            if delta <= 0:
                self.timestamp_regression_count += 1
            else:
                self.delta_count += 1
                difference = delta - self.delta_mean
                self.delta_mean += difference / self.delta_count
                self.delta_m2 += difference * (delta - self.delta_mean)
                self.max_gap_seconds = max(self.max_gap_seconds, delta)
                if self.nominal_srate > 0 and delta > self.gap_multiplier / self.nominal_srate:
                    self.gap_count += 1
        self.last_timestamp = stamp
        self.sample_count += 1

    def add_clock_offset(self, value: Any) -> None:
        try:
            number = float(value)
        except (TypeError, ValueError):
            return
        if math.isfinite(number):
            self.clock_offsets.append(number)

    def summary(self, *, rate_tolerance_fraction: float = 0.05) -> dict[str, Any]:
        duration = (
            self.last_timestamp - self.first_timestamp
            if self.first_timestamp is not None and self.last_timestamp is not None
            else 0.0
        )
        effective_rate = (
            (self.sample_count - 1) / duration
            if self.sample_count > 1 and duration > 0
            else 0.0
        )
        drift_ppm = (
            ((effective_rate / self.nominal_srate) - 1.0) * 1_000_000.0
            if self.nominal_srate > 0 and effective_rate > 0
            else None
        )
        jitter_std = (
            math.sqrt(self.delta_m2 / (self.delta_count - 1))
            if self.delta_count > 1
            else 0.0
        )
        rate_within_tolerance = (
            True if self.nominal_srate == 0
            else abs(effective_rate - self.nominal_srate) <= self.nominal_srate * rate_tolerance_fraction
        )
        offsets = self.clock_offsets
        return {
            "sample_count": self.sample_count,
            "first_timestamp": self.first_timestamp,
            "last_timestamp": self.last_timestamp,
            "observed_duration_seconds": duration,
            "effective_rate_hz": effective_rate,
            "nominal_rate_hz": self.nominal_srate,
            "rate_tolerance_fraction": rate_tolerance_fraction,
            "rate_within_tolerance": rate_within_tolerance,
            "drift_ppm": drift_ppm,
            "mean_sample_interval_seconds": self.delta_mean if self.delta_count else None,
            "sample_interval_jitter_std_seconds": jitter_std,
            "max_gap_seconds": self.max_gap_seconds,
            "gap_count": self.gap_count,
            "timestamp_regression_count": self.timestamp_regression_count,
            "nonfinite_timestamp_count": self.nonfinite_timestamp_count,
            "clock_correction_measurement_count": len(offsets),
            "clock_correction_first_seconds": offsets[0] if offsets else None,
            "clock_correction_last_seconds": offsets[-1] if offsets else None,
            "clock_correction_span_seconds": (max(offsets) - min(offsets)) if offsets else None,
            "clock_correction_median_seconds": statistics.median(offsets) if offsets else None,
        }


def analyze_timestamps(
    timestamps: Iterable[Any],
    *,
    nominal_srate: float,
    gap_multiplier: float = 4.0,
    rate_tolerance_fraction: float = 0.05,
    clock_offsets: Iterable[Any] = (),
) -> dict[str, Any]:
    accumulator = TimestampAccumulator(float(nominal_srate), float(gap_multiplier))
    for stamp in timestamps:
        accumulator.add(stamp)
    for value in clock_offsets:
        accumulator.add_clock_offset(value)
    return accumulator.summary(rate_tolerance_fraction=float(rate_tolerance_fraction))


def _segment_status(summary: Mapping[str, Any], *, irregular: bool) -> tuple[str, list[str], list[str]]:
    errors: list[str] = []
    cautions: list[str] = []
    if int(summary.get("sample_count") or 0) < 1:
        errors.append("No samples were observed")
    if int(summary.get("timestamp_regression_count") or 0):
        errors.append("One or more timestamps were non-monotonic")
    if int(summary.get("nonfinite_timestamp_count") or 0):
        errors.append("One or more timestamps were non-finite")
    if not irregular and not bool(summary.get("rate_within_tolerance")):
        errors.append("Effective sampling rate is outside the locked tolerance")
    if int(summary.get("gap_count") or 0):
        cautions.append("One or more sample gaps exceeded the configured multiplier")
    if int(summary.get("clock_correction_measurement_count") or 0) < 1:
        cautions.append("No LSL clock-correction measurement was captured")
    return _status(errors, cautions), errors, cautions


def monitor_contracts(
    contracts: Sequence[Mapping[str, Any]],
    *,
    duration: float,
    expected_run_uuid: str = "",
    gap_multiplier: float = 4.0,
    identity_poll_seconds: float = 2.0,
) -> dict[str, Any]:
    result: dict[str, Any] = {
        "schema": REPORT_SCHEMA,
        "generated_utc": utc_now(),
        "mode": "OBSERVER_ONLY_FAIL_CLOSED",
        "requested_duration_seconds": float(duration),
        "expected_run_uuid": expected_run_uuid,
        "status": "INELIGIBLE",
        "errors": [],
        "cautions": [],
        "events": [],
        "segments": [],
        "boundary": (
            "The supervisor observes identity, continuity, timing and rate. It never restarts an adapter, "
            "fabricates samples, merges across restarts, approves physiology, or grants ARM authority."
        ),
    }
    if not contracts:
        result["errors"].append("At least one stream contract is required")
        return result
    for contract in contracts:
        validation = validate_contract(contract)
        if validation["errors"]:
            result["errors"].extend(
                f"{contract.get('contract_id')}: {message}" for message in validation["errors"]
            )
    if result["errors"]:
        return result
    try:
        import pylsl  # type: ignore
    except Exception as exc:
        result["errors"].append(f"pylsl unavailable: {type(exc).__name__}: {exc}")
        return result

    try:
        try:
            infos = list(pylsl.resolve_streams(wait_time=2.0))
        except TypeError:
            infos = list(pylsl.resolve_streams(2.0))
        observations = [observation_from_stream_info(info, pylsl) for info in infos]
    except Exception as exc:
        result["errors"].append(f"LSL resolution failed: {type(exc).__name__}: {exc}")
        return result

    states: list[dict[str, Any]] = []
    for contract in contracts:
        selection = select_unambiguous_stream(
            contract, observations,
            expected_run_uuid=expected_run_uuid,
            require_admission_ready=False,
        )
        contract_id = str(contract.get("contract_id") or "")
        if selection["status"] != "PASS":
            result["errors"].extend(f"{contract_id}: {message}" for message in selection["errors"])
            result["events"].append({
                "time_utc": utc_now(), "severity": "ERROR", "event": "STREAM_ADMISSION_FAILED",
                "contract_id": contract_id, "selection": selection,
            })
            continue
        selected_index = int(selection["selected_index"])
        info = infos[selected_index]
        observation = observations[selected_index]
        try:
            inlet = pylsl.StreamInlet(info, max_buflen=max(30, int(duration) + 5), recover=False)
            inlet.open_stream(timeout=2.0)
        except Exception as exc:
            result["errors"].append(f"{contract_id}: inlet could not be opened: {type(exc).__name__}: {exc}")
            continue
        stream = contract.get("stream") if isinstance(contract.get("stream"), Mapping) else {}
        state = {
            "contract": contract,
            "contract_id": contract_id,
            "info": info,
            "inlet": inlet,
            "observation": observation,
            "start_uid": str(observation.get("uid") or ""),
            "source_id": str(observation.get("source_id") or ""),
            "identity_changes": 0,
            "accumulator": TimestampAccumulator(float(stream.get("nominal_srate") or 0.0), gap_multiplier),
            "last_identity_poll": 0.0,
        }
        states.append(state)
        result["events"].append({
            "time_utc": utc_now(), "severity": "INFO", "event": "STREAM_CONNECTED",
            "contract_id": contract_id, "uid": state["start_uid"], "source_id": state["source_id"],
        })
    if result["errors"] or len(states) != len(contracts):
        for state in states:
            try:
                state["inlet"].close_stream()
            except Exception:
                pass
        return result

    started = time.monotonic()
    while time.monotonic() - started < max(0.1, float(duration)):
        got_any = False
        now = time.monotonic()
        for state in states:
            inlet = state["inlet"]
            try:
                sample, timestamp = inlet.pull_sample(timeout=0.0)
            except Exception as exc:
                result["events"].append({
                    "time_utc": utc_now(), "severity": "ERROR", "event": "PULL_FAILED",
                    "contract_id": state["contract_id"], "detail": f"{type(exc).__name__}: {exc}",
                })
                state["identity_changes"] += 1
                continue
            if sample is not None:
                got_any = True
                state["accumulator"].add(timestamp)
            if now - state["last_identity_poll"] >= max(0.5, identity_poll_seconds):
                state["last_identity_poll"] = now
                try:
                    offset = inlet.time_correction(timeout=0.1)
                    state["accumulator"].add_clock_offset(offset)
                except Exception as exc:
                    result["events"].append({
                        "time_utc": utc_now(), "severity": "CAUTION", "event": "CLOCK_CORRECTION_UNAVAILABLE",
                        "contract_id": state["contract_id"], "detail": f"{type(exc).__name__}: {exc}",
                    })
                try:
                    matches = list(pylsl.resolve_byprop("source_id", state["source_id"], timeout=0.1))
                    live_uids = {str(match.uid() or "") for match in matches}
                    if state["start_uid"] not in live_uids:
                        state["identity_changes"] += 1
                        result["events"].append({
                            "time_utc": utc_now(), "severity": "ERROR", "event": "STREAM_UID_CHANGED_OR_DISAPPEARED",
                            "contract_id": state["contract_id"], "expected_uid": state["start_uid"],
                            "observed_uids": sorted(live_uids),
                        })
                except Exception as exc:
                    result["events"].append({
                        "time_utc": utc_now(), "severity": "CAUTION", "event": "IDENTITY_RECHECK_FAILED",
                        "contract_id": state["contract_id"], "detail": f"{type(exc).__name__}: {exc}",
                    })
        if not got_any:
            time.sleep(0.005)

    for state in states:
        try:
            state["inlet"].close_stream()
        except Exception:
            pass
        contract = state["contract"]
        stream = contract.get("stream") if isinstance(contract.get("stream"), Mapping) else {}
        summary = state["accumulator"].summary(
            rate_tolerance_fraction=float(stream.get("rate_tolerance_fraction") or 0.05)
        )
        segment_status, errors, cautions = _segment_status(
            summary, irregular=float(stream.get("nominal_srate") or 0.0) == 0.0,
        )
        if state["identity_changes"]:
            errors.append("Stream UID changed, disappeared, or the inlet failed during observation")
            segment_status = "INELIGIBLE"
        result["segments"].append({
            "schema": SEGMENT_SCHEMA,
            "contract_id": state["contract_id"],
            "contract_comparison": compare_contract(
                contract, state["observation"], expected_run_uuid=expected_run_uuid,
                require_admission_ready=False,
            ),
            "source_id": state["source_id"],
            "start_uid": state["start_uid"],
            "identity_change_count": state["identity_changes"],
            **summary,
            "status": segment_status,
            "errors": errors,
            "cautions": cautions,
        })
    statuses = {row["status"] for row in result["segments"]}
    result["status"] = (
        "INELIGIBLE" if result["errors"] or "INELIGIBLE" in statuses
        else "CAUTION" if "CAUTION" in statuses
        else "PASS"
    )
    return result


def write_report_bundle(output_dir: Path, report: Mapping[str, Any]) -> tuple[Path, Path]:
    root = Path(output_dir).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    json_path = root / "acquisition_supervisor_report_v1_0.json"
    csv_path = root / "acquisition_supervisor_segments_v1_0.csv"
    write_json(json_path, report)
    fields = [
        "contract_id", "status", "source_id", "start_uid", "identity_change_count",
        "sample_count", "observed_duration_seconds", "nominal_rate_hz", "effective_rate_hz",
        "drift_ppm", "sample_interval_jitter_std_seconds", "max_gap_seconds", "gap_count",
        "timestamp_regression_count", "nonfinite_timestamp_count",
        "clock_correction_measurement_count", "clock_correction_span_seconds",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(report.get("segments", []))
    return json_path, csv_path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Alpha 9 contract-bound acquisition supervisor")
    parser.add_argument("--contract", type=Path, action="append", required=True)
    parser.add_argument("--duration", type=float, default=30.0)
    parser.add_argument("--run-uuid", default="")
    parser.add_argument("--gap-multiplier", type=float, default=4.0)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    contracts = [read_json(path) for path in args.contract]
    report = monitor_contracts(
        contracts,
        duration=args.duration,
        expected_run_uuid=args.run_uuid,
        gap_multiplier=args.gap_multiplier,
    )
    write_report_bundle(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report["status"] == "PASS" else 4


if __name__ == "__main__":
    raise SystemExit(main())
