from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Tuple


BOARD_ENUM_NAME = "CERELOG_X8_BOARD"
SAFETY_TEXT = (
    "Cerelog documents ESP-EEG as NON-ISOLATED. Human-connected use requires a battery-powered "
    "laptop or battery-powered single-board computer; never use a mains-connected laptop or desktop."
)


def add_connection_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--serial-port", default="", help="Optional serial device/COM port for the installed custom fork.")
    parser.add_argument("--ip-address", default="", help="Optional board IP address.")
    parser.add_argument("--ip-port", type=int, default=0, help="Optional board IP port.")
    parser.add_argument("--mac-address", default="", help="Optional MAC address.")
    parser.add_argument("--timeout", type=int, default=15, help="Connection timeout in seconds.")
    parser.add_argument("--other-info", default="", help="Optional custom-fork connection string.")
    parser.add_argument(
        "--acknowledge-battery-only",
        action="store_true",
        help="Required acknowledgement of the manufacturer's non-isolated/battery-only warning.",
    )


def require_safety_acknowledgement(args: argparse.Namespace) -> None:
    if not bool(args.acknowledge_battery_only):
        raise RuntimeError(SAFETY_TEXT + " Re-run only after confirming this condition, with --acknowledge-battery-only.")


def load_brainflow() -> Tuple[Any, Any, Any, Any]:
    try:
        from brainflow.board_shim import BoardIds, BoardShim, BrainFlowInputParams  # type: ignore
        from brainflow.data_filter import DataFilter  # type: ignore
    except Exception as exc:
        raise RuntimeError(
            "BrainFlow is unavailable. Build and install the complete Cerelog custom fork documented at "
            "https://github.com/shakimiansky/Shared_brainflow-cerelog"
        ) from exc
    return BoardIds, BoardShim, BrainFlowInputParams, DataFilter


def resolve_board_id(board_ids: Any) -> int:
    member = getattr(board_ids, BOARD_ENUM_NAME, None)
    if member is None:
        raise RuntimeError(
            f"The installed BrainFlow build does not define BoardIds.{BOARD_ENUM_NAME}. "
            "The ordinary PyPI build may not include Cerelog; install the complete Cerelog custom fork."
        )
    return int(getattr(member, "value", member))


def build_params(params_type: Any, args: argparse.Namespace) -> Any:
    params = params_type()
    for name in ("serial_port", "ip_address", "mac_address", "other_info"):
        value = str(getattr(args, name, "") or "").strip()
        if value:
            setattr(params, name, value)
    if int(getattr(args, "ip_port", 0) or 0):
        params.ip_port = int(args.ip_port)
    params.timeout = int(args.timeout)
    return params


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)
