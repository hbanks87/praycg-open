from __future__ import annotations

import argparse
import math
import re
import time
import uuid

import numpy as np

from praycg_cerelog_brainflow_common_v0_1 import (
    BOARD_ENUM_NAME,
    SAFETY_TEXT,
    add_connection_arguments,
    build_params,
    load_brainflow,
    require_safety_acknowledgement,
    resolve_board_id,
)


MAX_BRAINFLOW_BUFFER_SAMPLES = 45_000


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description="Publish Cerelog ESP-EEG from its custom BrainFlow build to LSL.")
    add_connection_arguments(value)
    value.add_argument("--run-uuid", default="", help="Run-bound identifier; generated when omitted.")
    value.add_argument("--stream-name", default="PRAYCG_Cerelog_EEG")
    value.add_argument("--source-id", default="", help="Optional explicit LSL source_id.")
    value.add_argument("--duration", type=float, default=0.0, help="Seconds to stream; zero runs until Ctrl+C.")
    value.add_argument("--scale", type=float, default=1_000_000.0, help="Multiplier applied to raw BrainFlow EEG values.")
    value.add_argument("--units", default="microvolts_provisional", help="LSL unit label for the scaled values.")
    return value


def safe_id(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", value).strip("_") or uuid.uuid4().hex


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    require_safety_acknowledgement(args)
    if not math.isfinite(args.scale) or args.scale == 0:
        raise RuntimeError("--scale must be a finite non-zero number")
    try:
        from pylsl import StreamInfo, StreamOutlet, cf_float32, local_clock  # type: ignore
    except Exception as exc:
        raise RuntimeError("pylsl is required for the Cerelog LSL publisher") from exc

    BoardIds, BoardShim, BrainFlowInputParams, _DataFilter = load_brainflow()
    board_id = resolve_board_id(BoardIds)
    params = build_params(BrainFlowInputParams, args)
    eeg_rows = list(BoardShim.get_eeg_channels(board_id))
    sampling_rate = float(BoardShim.get_sampling_rate(board_id))
    timestamp_row = int(BoardShim.get_timestamp_channel(board_id))
    if not eeg_rows or sampling_rate <= 0:
        raise RuntimeError("The custom BrainFlow board description did not expose EEG channels and a positive sample rate.")

    run_uuid = safe_id(args.run_uuid or str(uuid.uuid4()))
    source_id = safe_id(args.source_id or f"praycg_cerelog_eeg_{run_uuid}")
    info = StreamInfo(args.stream_name, "EEG", len(eeg_rows), sampling_rate, cf_float32, source_id)
    desc = info.desc()
    desc.append_child_value("manufacturer", "Cerelog")
    desc.append_child_value("model", "ESP-EEG")
    desc.append_child_value("brainflow_board_enum", BOARD_ENUM_NAME)
    desc.append_child_value("run_uuid", run_uuid)
    desc.append_child_value("units", args.units)
    desc.append_child_value("raw_scale_multiplier", format(args.scale, ".17g"))
    desc.append_child_value("physical_validation", "NOT_PERFORMED")
    desc.append_child_value("safety_boundary", SAFETY_TEXT)
    channels = desc.append_child("channels")
    for index, row in enumerate(eeg_rows, start=1):
        channel = channels.append_child("channel")
        channel.append_child_value("label", f"Cerelog_EEG_{index}")
        channel.append_child_value("unit", args.units)
        channel.append_child_value("type", "EEG")
        channel.append_child_value("brainflow_row", str(row))
    outlet = StreamOutlet(info, chunk_size=0, max_buffered=360)

    board = BoardShim(board_id, params)
    prepared = False
    streaming = False
    lsl_offset: float | None = None
    started = time.monotonic()
    samples_sent = 0
    try:
        print(SAFETY_TEXT)
        print(f"Preparing {BOARD_ENUM_NAME}; EEG rows={eeg_rows}; declared rate={sampling_rate:g} Hz")
        board.prepare_session()
        prepared = True
        board.start_stream(MAX_BRAINFLOW_BUFFER_SAMPLES)
        streaming = True
        while args.duration <= 0 or time.monotonic() - started < args.duration:
            data = board.get_board_data()
            if data.shape[1] == 0:
                time.sleep(0.01)
                continue
            values = (data[eeg_rows, :].T * args.scale).astype(np.float32, copy=False)
            raw_times = data[timestamp_row, :]
            use_board_times = bool(
                len(raw_times) == len(values)
                and np.isfinite(raw_times).all()
                and (len(raw_times) < 2 or np.all(np.diff(raw_times) > 0))
            )
            if use_board_times:
                if lsl_offset is None:
                    lsl_offset = float(local_clock()) - float(raw_times[-1])
                timestamps = raw_times + lsl_offset
            else:
                newest = float(local_clock())
                timestamps = newest - np.arange(len(values) - 1, -1, -1, dtype=float) / sampling_rate
            # Match the validated alpha.8 transport pattern: one explicitly
            # flushed numeric chunk with one LSL-domain timestamp per sample.
            # Merely creating a discoverable outlet is not proof of delivery.
            outlet.push_chunk(values.tolist(), timestamp=timestamps.tolist(), pushthrough=True)
            samples_sent += len(values)
    except KeyboardInterrupt:
        print("Stopping after operator interrupt.")
    finally:
        if streaming:
            try:
                board.stop_stream()
            except Exception:
                pass
        if prepared:
            board.release_session()
    elapsed = max(time.monotonic() - started, 1e-9)
    print(f"Published {samples_sent} samples to {args.stream_name} ({samples_sent / elapsed:.2f} samples/s observed).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
