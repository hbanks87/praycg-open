from __future__ import annotations

import argparse
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from praycg_cerelog_brainflow_common_v0_1 import (
    BOARD_ENUM_NAME,
    SAFETY_TEXT,
    add_connection_arguments,
    build_params,
    load_brainflow,
    require_safety_acknowledgement,
    resolve_board_id,
    sha256_file,
    write_json,
)


MAX_BRAINFLOW_BUFFER_SAMPLES = 45_000


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description="Record the raw Cerelog custom-BrainFlow board matrix to CSV.")
    add_connection_arguments(value)
    value.add_argument("--output", type=Path, required=True, help="Destination CSV; a metadata sidecar is written beside it.")
    value.add_argument("--duration", type=float, default=0.0, help="Seconds to record; zero runs until Ctrl+C.")
    value.add_argument("--overwrite", action="store_true", help="Explicitly replace an existing output file.")
    return value


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    require_safety_acknowledgement(args)
    output = args.output.expanduser().resolve()
    if output.exists() and not args.overwrite:
        raise RuntimeError(f"Output already exists: {output}. Choose another path or pass --overwrite explicitly.")
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    metadata_path = output.with_suffix(".metadata.json")

    BoardIds, BoardShim, BrainFlowInputParams, DataFilter = load_brainflow()
    board_id = resolve_board_id(BoardIds)
    params = build_params(BrainFlowInputParams, args)
    description = BoardShim.get_board_descr(board_id)
    eeg_rows = list(BoardShim.get_eeg_channels(board_id))
    sampling_rate = float(BoardShim.get_sampling_rate(board_id))
    timestamp_row = int(BoardShim.get_timestamp_channel(board_id))
    if not eeg_rows or sampling_rate <= 0:
        raise RuntimeError("The custom BrainFlow board description did not expose EEG channels and a positive sample rate.")

    board = BoardShim(board_id, params)
    prepared = False
    streaming = False
    wrote_data = False
    samples = 0
    first_timestamp: float | None = None
    last_timestamp: float | None = None
    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    status = "RUNNING"
    try:
        print(SAFETY_TEXT)
        print(f"Preparing {BOARD_ENUM_NAME}; raw output={output}")
        board.prepare_session()
        prepared = True
        board.start_stream(MAX_BRAINFLOW_BUFFER_SAMPLES)
        streaming = True
        while args.duration <= 0 or time.monotonic() - started < args.duration:
            data = board.get_board_data()
            if data.shape[1] == 0:
                time.sleep(0.01)
                continue
            DataFilter.write_file(data, str(output), "a" if wrote_data else "w")
            wrote_data = True
            samples += int(data.shape[1])
            stamps = data[timestamp_row, :]
            finite = stamps[np.isfinite(stamps)]
            if finite.size:
                if first_timestamp is None:
                    first_timestamp = float(finite[0])
                last_timestamp = float(finite[-1])
        status = "COMPLETE"
    except KeyboardInterrupt:
        status = "STOPPED_BY_OPERATOR"
        print("Stopping after operator interrupt.")
    except Exception:
        status = "FAILED"
        raise
    finally:
        if streaming:
            try:
                board.stop_stream()
            except Exception:
                pass
        if prepared:
            board.release_session()
        elapsed = max(time.monotonic() - started, 0.0)
        metadata = {
            "schema": "PRAYCG_CerelogBrainFlowRawCapture_v0_1",
            "status": status,
            "started_utc": started_utc,
            "finished_utc": datetime.now(timezone.utc).isoformat(),
            "output_csv": str(output),
            "output_sha256": sha256_file(output) if output.is_file() else None,
            "sample_count": samples,
            "elapsed_seconds": elapsed,
            "observed_samples_per_second": samples / elapsed if elapsed > 0 else 0.0,
            "brainflow_board_enum": BOARD_ENUM_NAME,
            "brainflow_board_id": board_id,
            "board_description": description,
            "eeg_rows": eeg_rows,
            "timestamp_row": timestamp_row,
            "declared_sample_rate": sampling_rate,
            "first_board_timestamp": first_timestamp,
            "last_board_timestamp": last_timestamp,
            "filtering": "NONE_RAW_BRAINFLOW_BOARD_MATRIX",
            "rescaling": "NONE",
            "battery_only_acknowledged": True,
            "physical_validation": "NOT_PERFORMED",
            "safety_boundary": SAFETY_TEXT,
            "authority_boundary": "This capture does not approve hardware, validate electrical safety, create a session lock, or grant ARM/acquisition authority.",
        }
        write_json(metadata_path, metadata)
    print(f"Recorded {samples} samples. Metadata: {metadata_path}")
    return 0 if samples else 3


if __name__ == "__main__":
    raise SystemExit(main())
