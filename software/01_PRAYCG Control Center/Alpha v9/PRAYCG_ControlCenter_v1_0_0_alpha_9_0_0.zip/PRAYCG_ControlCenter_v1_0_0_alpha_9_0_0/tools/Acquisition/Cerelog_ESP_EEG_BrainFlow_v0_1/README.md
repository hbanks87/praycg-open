# Cerelog ESP-EEG BrainFlow acquisition tools v0.1

This folder adds two PRAYCG-authored wrappers around the Cerelog custom BrainFlow board implementation:

- `scripts/praycg_cerelog_brainflow_to_lsl_v0_1.py` publishes the eight EEG channels to one run-bound LSL outlet.
- `scripts/praycg_cerelog_brainflow_record_v0_1.py` records the complete raw BrainFlow board matrix and a JSON metadata sidecar.

## Critical electrical-safety boundary

**Cerelog documents the ESP-EEG as non-isolated. A human-connected board must only be attached to a battery-powered laptop or a battery-powered single-board computer. Never use a mains-connected laptop or a desktop computer.** The command-line acknowledgement is a reminder, not an electrical test or certification.

This alpha integration is `QUARANTINED`, `NOT_PERFORMED` for physical validation, and withheld from profile/ARM authority. Before promotion, record the exact board, firmware and custom-BrainFlow commit; transport; rate; channel map; units/gain; battery-only power review; and a supervised physical preflight.

## Required BrainFlow build

The public Cerelog repository directs users to its custom BrainFlow fork. The ordinary PyPI `brainflow` package may not define `BoardIds.CERELOG_X8_BOARD`; both scripts stop with an actionable error if it is absent.

1. Follow the Cerelog device guide and build/install the complete custom fork: <https://github.com/shakimiansky/Shared_brainflow-cerelog>
2. Install the remaining dependencies: `python -m pip install -r requirements_cerelog_brainflow_v0_1.txt`
3. Confirm that `BoardIds.CERELOG_X8_BOARD` exists in that Python environment.

The upstream quick visualization/acquisition example is `python_package/cerelog_tests/filtered_plot.py`. PRAYCG does not copy that experimental plotting program; these wrappers keep raw acquisition separate from visualization and preserve a run-bound identity.

## LSL streaming

```text
python scripts/praycg_cerelog_brainflow_to_lsl_v0_1.py \
  --acknowledge-battery-only \
  --run-uuid YOUR-RUN-UUID
```

Optional connection fields are `--serial-port`, `--ip-address`, `--ip-port`, `--mac-address`, `--timeout`, and `--other-info`. Leave them unset when the installed Cerelog fork performs its own discovery. The default `--scale 1000000` follows the upstream plotting example's conversion to microvolts; this conversion remains provisional until the exact fork/firmware is bench-verified.

## Raw acquisition

```text
python scripts/praycg_cerelog_brainflow_record_v0_1.py \
  --acknowledge-battery-only \
  --output cerelog_raw.csv \
  --duration 60
```

The recorder writes the complete board matrix without filtering or rescaling. It also writes `cerelog_raw.metadata.json`, including the board description, EEG-row indices, declared sample rate, sample count, timing summary, safety acknowledgement, and SHA-256 of the finished CSV.

## Primary sources

- Cerelog ESP-EEG hardware/firmware repository: <https://github.com/Cerelog-ESP-EEG/ESP-EEG>
- Cerelog custom BrainFlow fork: <https://github.com/shakimiansky/Shared_brainflow-cerelog>
- Cerelog BrainFlow examples: <https://github.com/shakimiansky/Shared_brainflow-cerelog/tree/master/python_package/cerelog_tests>
- BrainFlow upstream: <https://github.com/brainflow-dev/brainflow>

These scripts do not establish medical-device status, electrical safety, physiological validity, cortical origin, timing accuracy, or construct validity.
