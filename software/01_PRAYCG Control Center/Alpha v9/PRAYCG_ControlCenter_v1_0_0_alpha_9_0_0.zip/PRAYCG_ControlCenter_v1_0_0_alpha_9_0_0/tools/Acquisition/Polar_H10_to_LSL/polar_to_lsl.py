#!/usr/bin/env python3
"""Publish Polar H10 RR intervals to a run-bound LSL outlet.

The Heart Rate Measurement characteristic encodes RR intervals in 1/1024 s.
This bridge publishes those intervals in milliseconds as irregular events. It
does not publish an ECG waveform, and the LSL type and channel metadata say so.
"""
from __future__ import annotations

import argparse
import asyncio
import os
import struct
import uuid
from typing import Any, Callable


HR_MEASUREMENT_UUID = "00002a37-0000-1000-8000-00805f9b34fb"
SOURCE_ID_PREFIX = "praycg_polar_h10_rr_v0_2_"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Polar H10 RR intervals to LSL")
    parser.add_argument("--run-uuid", default=os.environ.get("PRAYCG_RUN_UUID", ""))
    parser.add_argument("--source-id", default="", help="Optional explicit LSL source_id override.")
    parser.add_argument("--stream-name", default="PolarHRV")
    parser.add_argument("--device-name", default="Polar H10", help="Case-insensitive substring used during BLE discovery.")
    parser.add_argument("--scan-timeout", type=float, default=5.0)
    parser.add_argument("--retry-seconds", type=float, default=3.0)
    return parser


def make_outlet(stream_name: str, source_id: str, run_uuid: str) -> Any:
    from pylsl import StreamInfo, StreamOutlet

    info = StreamInfo(stream_name, "RRIntervals", 1, 0, "float32", source_id)
    description = info.desc()
    description.append_child_value("manufacturer", "Polar")
    description.append_child_value("model", "H10")
    description.append_child_value("run_uuid", run_uuid)
    description.append_child_value("measurement", "beat_to_beat_rr_interval")
    channel = description.append_child("channels").append_child("channel")
    channel.append_child_value("label", "RR_interval")
    channel.append_child_value("unit", "milliseconds")
    channel.append_child_value("type", "RRIntervals")
    return StreamOutlet(info)


def make_hr_data_handler(outlet: Any) -> Callable[[Any, bytearray], None]:
    def hr_data_handler(_sender: Any, data: bytearray) -> None:
        try:
            flags = data[0]
            is_16bit_hr = (flags & 0x01) != 0
            current_hr = struct.unpack_from("<H", data, 1)[0] if is_16bit_hr else data[1]
            energy_present = (flags & 0x08) != 0
            rr_present = (flags & 0x10) != 0
            print(f"[DIAGNOSTIC] Raw HR: {current_hr} bpm | RR Present: {rr_present}")
            if not rr_present:
                return
            offset = 1 + (2 if is_16bit_hr else 1) + (2 if energy_present else 0)
            while offset + 1 < len(data):
                rr_raw = struct.unpack_from("<H", data, offset)[0]
                rr_ms = (rr_raw / 1024.0) * 1000.0
                outlet.push_sample([rr_ms])
                print(f"  -> Beat Caught: {rr_ms:.2f} ms")
                offset += 2
        except Exception as exc:
            print(f"[ERROR] Callback Error during unpack: {exc}")

    return hr_data_handler


async def run_polar_bridge(args: argparse.Namespace, outlet: Any) -> None:
    from bleak import BleakClient, BleakScanner
    from bleak.exc import BleakError

    handler = make_hr_data_handler(outlet)
    requested_name = args.device_name.casefold()
    while True:
        print("\nScanning for Polar H10...")
        devices = await BleakScanner.discover(timeout=max(1.0, args.scan_timeout))
        polar_device = next(
            (device for device in devices if device.name and requested_name in device.name.casefold()),
            None,
        )
        if not polar_device:
            print(f"{args.device_name} not found. Retrying in {args.retry_seconds:g} seconds...")
            await asyncio.sleep(max(0.5, args.retry_seconds))
            continue
        print(f"Found {polar_device.name}. Attempting connection...")
        try:
            async with BleakClient(polar_device, timeout=15.0) as client:
                print(f"Connection Status: {client.is_connected}")
                if client.is_connected:
                    print("Stabilizing connection...")
                    await asyncio.sleep(1.0)
                    _services = client.services
                    print("Subscribing to Heart Rate notifications...")
                    await client.start_notify(HR_MEASUREMENT_UUID, handler)
                    print("Successfully subscribed! Waiting for RR events...")
                    while client.is_connected:
                        await asyncio.sleep(1)
                    print("Connection dropped by adapter. Restarting loop...")
        except BleakError as exc:
            print(f"Bleak Connection Error: {exc}. Retrying...")
            await asyncio.sleep(max(0.5, args.retry_seconds))
        except Exception as exc:
            print(f"General Connection Error: {exc}. Retrying...")
            await asyncio.sleep(max(0.5, args.retry_seconds))


def main() -> int:
    args = build_parser().parse_args()
    run_uuid = str(args.run_uuid or "").strip() or str(uuid.uuid4())
    run_identity_fragment = run_uuid.replace("-", "")[:12]
    source_id = str(args.source_id or "").strip() or f"{SOURCE_ID_PREFIX}{run_identity_fragment}"
    print("Initializing Polar H10 RR-interval LSL outlet...")
    print(f"  run_uuid: {run_uuid}")
    print(f"  source_id: {source_id}")
    try:
        outlet = make_outlet(args.stream_name, source_id, run_uuid)
        print(f"LSL stream {args.stream_name!r} established (irregular RR intervals, milliseconds).")
        asyncio.run(run_polar_bridge(args, outlet))
    except ModuleNotFoundError as exc:
        print(f"[ERROR] Required acquisition dependency is unavailable: {exc.name}.")
        print("Install the Control Center acquisition requirements, then retry.")
        return 2
    except KeyboardInterrupt:
        print("\nScript terminated by user.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
