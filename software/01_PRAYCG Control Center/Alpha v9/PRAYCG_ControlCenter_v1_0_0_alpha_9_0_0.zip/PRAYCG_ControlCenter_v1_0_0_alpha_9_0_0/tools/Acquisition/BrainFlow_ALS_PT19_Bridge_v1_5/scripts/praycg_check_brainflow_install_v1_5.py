#!/usr/bin/env python3
"""Hardware-free dependency and native-library check for the EEG + ALS bridge."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from praycg_check_acquisition_install_v1_0 import main

if __name__ == "__main__":
    raise SystemExit(main())
