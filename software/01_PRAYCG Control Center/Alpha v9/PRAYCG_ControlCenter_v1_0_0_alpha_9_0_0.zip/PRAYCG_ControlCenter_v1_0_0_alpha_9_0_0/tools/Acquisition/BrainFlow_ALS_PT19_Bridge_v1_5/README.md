# PRAYCG OpenBCI BrainFlow ALS-PT19 Bridge v1.5

This remains the v1.5 acquisition component inside **PRAYCG Control Center v1.0.0-alpha.4**. The component version records its lineage; the current operator workflow and run authority are supplied by the alpha.4 Control Center. Carried alpha.2-named lock and evidence schemas remain compatibility contracts, not an alternate current release.

This package replaces the OpenBCI GUI networking layer when the GUI will only export one LSL stream at a time.

It creates simultaneous LSL streams from one BrainFlow session:

```text
obci_eeg1              EEG, 16 channels for Cyton+Daisy
OpenBCIAnalogAux       raw analog AUX, 3 channels: A5/D11, A6/D12, A7/D13
ALS_PT19_Timing        single extracted light sensor channel, default A6/D12
OpenBCIStatusMarkers   status / heartbeat markers
```

Do not run OpenBCI GUI at the same time. BrainFlow needs exclusive control of the OpenBCI COM port.

Version 1.5 also writes a manifest, event CSV, chunk-diagnostics CSV, and final acquisition-QC JSON. Diagnostics retain device timestamps separately from reconstructed LSL timestamps, distinguish missing/duplicate/out-of-order packets, track buffer backlog and saturation-review counts, and include the optional calibration-profile hash. The final status is an engineering PASS/WARN/FAIL summary, not scientific endpoint certification.

## KISS wiring

```text
ALS-PT19 +      -> Cyton DVDD / 3V3
ALS-PT19 -      -> Cyton GND
ALS-PT19 OUT    -> Cyton D12 / A6
```

Default ALS channel in the script:

```text
--als-aux-channel 1
```

because the analog channels are:

```text
0 = A5 / D11
1 = A6 / D12  <- ALS-PT19 default
2 = A7 / D13
```

## Windows installation, reliable path

Use a normal Python install rather than the Microsoft Store Python. Python 3.11 or 3.12 is recommended for the least package friction.

Unzip this folder somewhere simple:

```text
C:\PRAYCG\BrainFlow_ALS_v1_5\
```

Open **Command Prompt** in that folder.

Create a virtual environment:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_brainflow_als_pt19_v1_5.txt
python scripts\praycg_check_brainflow_install_v1_5.py
```

If `py -3.11` is not found, install Python 3.11 or 3.12 from python.org and check **Add Python to PATH**.

## Find the COM port

Close OpenBCI GUI first.

```bat
python scripts\praycg_identify_openbci_port_v1_5.py --watch
```

Unplug the dongle, press Enter, plug the dongle back into the USB port you intend to use, wait a few seconds, and press Enter. Use the COM port that appears.

You can also simply list ports:

```bat
python scripts\praycg_openbci_brainflow_als_pt19_bridge_v1_5.py --list-ports
```

## Start the EEG + ALS bridge

Replace `COM3` with your actual COM port:

```bat
python scripts\praycg_openbci_brainflow_als_pt19_bridge_v1_5.py ^
  --board cyton-daisy ^
  --serial-port COM3 ^
  --enable-analog-aux ^
  --publish-als-stream ^
  --confirmed-channel-map
```

The script sends `/2` to the Cyton to enter analog board mode. On exit it tries to send `/0` to restore default mode.

## Confirm LSL streams

In a second Command Prompt with the same venv activated:

```bat
python scripts\praycg_list_lsl_streams_v1_5.py
```

Expected streams:

```text
obci_eeg1
OpenBCIAnalogAux
ALS_PT19_Timing
OpenBCIStatusMarkers
```

## Alpha.4 Control Center workflow

Routine hardware work is consolidated under **Hardware Acquisition / Forge**:

1. Choose or build the reviewed EEG+ALS hardware profile in **2. Hardware Profile**.
2. In **3. Connect & Launch**, click **Start New Equipment Session**, confirm that the active UUID appears, then click **Start BrainFlow EEG + ALS**. The Control Center supplies that UUID to the bridge; an outside or prior-session bridge may be inspected but cannot pass the current session gates.
3. In **4. Live Checks**, use **Open Live Stream Monitor** to view EEG sampling/quality and ALS raw/relative photonic load in real time.
4. Run **ALS Barcode Placement Test** for the controlled black/white screen-pulse and sensor-placement check. This run/profile-bound test is the sole controlled pulse/placement gate.
5. In **5. Monitor, Record & Arm**, run **Run Required 30-Second Equipment Check**. Its progress window describes the checks and reports completion. For an EEG+ALS profile, the detailed checker is invoked with `--require-als --stream-health-only`: it requires the ALS outlet and its run-bound identity, but it does not display a pulse or infer pulse visibility from background variation.
6. Review the profile and supplemental evidence, create the combined session lock, and explicitly arm. Neither this bridge nor either preflight independently arms the runner.

Preflight, ALS-test, bridge, supervisor, and lock artifacts are kept under `logs\protocol_runs\<run_uuid>\`. A new UUID or Control Center process makes prior run authority stale even though its files remain preserved.

## Manual ALS bench test

For hardware troubleshooting outside the controlled alpha.4 session workflow, you may still inspect the stream manually. Do not substitute this manual check for the run-bound **ALS Barcode Placement Test** or the full profile preflight.

Start LabRecorder and select at least:

```text
obci_eeg1
OpenBCIAnalogAux
ALS_PT19_Timing
OpenBCIStatusMarkers
StasisMarkers
PolarHRV
VernierRespirationBelt
```

Then run the ALS watchdog in a second terminal:

```bat
python scripts\praycg_als_pt19_light_watchdog_v1_5.py --duration 30 --expected-pulses 1
```

Present a known light transition while it records. The ALS value should rise and return toward baseline. This is an engineering observation only; it does not create alpha.4 placement-gate evidence.

## If the bridge fails to open the port

Almost always this means something else owns the serial port.

Close:

```text
OpenBCI GUI
Arduino serial monitor
old BrainFlow terminal windows
PuTTY / serial tools
```

Then unplug/replug the dongle and rerun the port identifier.

## If ALS stream is flat

Check in this order:

```text
1. ALS OUT really goes to D12/A6.
2. ALS + is on DVDD/3V3, not 5V.
3. ALS - is on GND.
4. The timing square is actually visible under the sensor.
5. The sensor is covered/shrouded from room light.
6. --enable-analog-aux was included.
7. --als-aux-channel is 1 for D12/A6.
```

## Interpretation boundary

The ALS stream is not a brain signal. It validates physical monitor timing. It belongs to the external input vector `u(t)`, not to any biological hidden variable `Y(t)`.
