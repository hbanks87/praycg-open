#!/usr/bin/env python3
"""Bridge typed serial/UDP EDA and PPG packets to run-bound LSL outlets."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import signal
import socket
import sys
import time
import uuid
from typing import Any, Iterator, Mapping

from praycg_generic_eda_ppg_core_v0_1 import (
    Observation,
    load_json,
    parse_packet,
    sha256_file,
    summarize_preflight,
    utc_now,
    validate_driver_profile,
)


STOP = False


def _stop(_signum: int, _frame: Any) -> None:
    global STOP
    STOP = True


class PacketSource:
    def read(self) -> bytes | None:
        raise NotImplementedError

    def close(self) -> None:
        pass


class UDPSource(PacketSource):
    def __init__(self, config: Mapping[str, Any]) -> None:
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.settimeout(float(config.get("read_timeout_seconds", 0.25)))
        self.socket.bind((str(config["bind_host"]), int(config["port"])))

    def read(self) -> bytes | None:
        try:
            payload, _address = self.socket.recvfrom(65535)
            return payload
        except socket.timeout:
            return None

    def close(self) -> None:
        self.socket.close()


class SerialSource(PacketSource):
    def __init__(self, config: Mapping[str, Any]) -> None:
        try:
            import serial  # type: ignore
        except Exception as exc:
            raise RuntimeError(f"pyserial is required for serial transport: {type(exc).__name__}: {exc}") from exc
        self.serial = serial.Serial(
            port=str(config["port"]),
            baudrate=int(config["baud"]),
            timeout=float(config.get("read_timeout_seconds", 0.25)),
        )

    def read(self) -> bytes | None:
        payload = self.serial.readline()
        return payload if payload else None

    def close(self) -> None:
        self.serial.close()


def open_source(profile: Mapping[str, Any]) -> PacketSource:
    transport = profile["transport"]
    if transport["kind"] == "udp":
        return UDPSource(transport)
    if transport["kind"] == "serial":
        return SerialSource(transport)
    raise ValueError(f"Unsupported transport: {transport.get('kind')!r}")


def _validated_run_uuid(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError("--run-uuid is required; outlets must be bound to one run")
    try:
        return str(uuid.UUID(text))
    except ValueError as exc:
        raise ValueError("--run-uuid must be a full UUID") from exc


def run_fragment(run_uuid: str) -> str:
    return re.sub(r"[^0-9a-f]", "", run_uuid.lower())[:12]


def collect_observations(
    source: PacketSource,
    profile: Mapping[str, Any],
    *,
    duration_seconds: float,
    max_records: int = 0,
) -> tuple[list[Observation], int]:
    observations: list[Observation] = []
    parse_errors = 0
    deadline = time.perf_counter() + max(0.1, duration_seconds)
    while not STOP and time.perf_counter() < deadline:
        raw = source.read()
        if raw is None:
            continue
        try:
            observations.append(parse_packet(raw, profile, host_timestamp_seconds=time.perf_counter()))
        except (UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError):
            parse_errors += 1
        if max_records and len(observations) >= max_records:
            break
    return observations, parse_errors


def _lsl_outlets(profile: Mapping[str, Any], run_uuid: str) -> tuple[dict[str, Any], Any, Any]:
    try:
        from pylsl import StreamInfo, StreamOutlet, cf_float32, cf_string, local_clock  # type: ignore
    except Exception as exc:
        raise RuntimeError(f"pylsl is required for LSL output: {type(exc).__name__}: {exc}") from exc
    fragment = run_fragment(run_uuid)
    prefix = "synthetic_praycg_physio" if profile.get("synthetic") else "praycg_physio"
    outlets: dict[str, Any] = {}
    for stream in profile["streams"]:
        source_id = f"{prefix}_{stream['canonical_role']}_{fragment}"
        info = StreamInfo(
            name=str(stream["lsl_name"]),
            type=str(stream["canonical_role"]).upper(),
            channel_count=int(stream["channel_count"]),
            nominal_srate=float(stream["nominal_srate"]),
            channel_format=cf_float32,
            source_id=source_id,
        )
        desc = info.desc()
        desc.append_child_value("manufacturer", "PRAYCG generic typed bridge")
        desc.append_child_value("profile_id", str(profile["profile_id"]))
        desc.append_child_value("run_uuid", run_uuid)
        desc.append_child_value("synthetic", str(bool(profile.get("synthetic"))).lower())
        desc.append_child_value("units", str(stream["units"]))
        desc.append_child_value("timestamp_policy", "LSL local host receipt; device timestamp retained only in bridge evidence")
        outlets[str(stream["input_stream_id"])] = StreamOutlet(info, chunk_size=1, max_buffered=360)
    status_name = "SYNTHETIC_PRAYCG_PhysioStatusMarkers" if profile.get("synthetic") else "PRAYCG_PhysioStatusMarkers"
    status_info = StreamInfo(
        name=status_name,
        type="Markers",
        channel_count=1,
        nominal_srate=0.0,
        channel_format=cf_string,
        source_id=f"{prefix}_status_{fragment}",
    )
    status_desc = status_info.desc()
    status_desc.append_child_value("run_uuid", run_uuid)
    status_desc.append_child_value("synthetic", str(bool(profile.get("synthetic"))).lower())
    return outlets, StreamOutlet(status_info, chunk_size=1, max_buffered=360), local_clock


def bridge(profile: Mapping[str, Any], run_uuid: str, out_dir: Path, *, duration_seconds: float = 0.0, max_records: int = 0) -> dict[str, Any]:
    outlets, status_outlet, local_clock = _lsl_outlets(profile, run_uuid)
    source = open_source(profile)
    counts = {stream_id: 0 for stream_id in outlets}
    parse_errors = 0
    started = time.perf_counter()
    status_outlet.push_sample([json.dumps({"event": "BRIDGE_STARTED", "run_uuid": run_uuid, "synthetic": bool(profile.get("synthetic"))})], timestamp=local_clock())
    try:
        while not STOP:
            if duration_seconds > 0 and time.perf_counter() - started >= duration_seconds:
                break
            raw = source.read()
            if raw is None:
                continue
            try:
                observation = parse_packet(raw, profile, host_timestamp_seconds=time.perf_counter())
            except (UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError):
                parse_errors += 1
                continue
            outlets[observation.stream_id].push_sample(list(observation.values), timestamp=local_clock())
            counts[observation.stream_id] += 1
            if max_records and sum(counts.values()) >= max_records:
                break
    finally:
        source.close()
        status_outlet.push_sample([json.dumps({"event": "BRIDGE_STOPPED", "run_uuid": run_uuid, "counts": counts, "parse_errors": parse_errors})], timestamp=local_clock())
    evidence = {
        "schema": "PRAYCG_GenericEDAPPGBridgeEvidence_v0_1",
        "generated_utc": utc_now(),
        "profile_id": profile["profile_id"],
        "run_uuid": run_uuid,
        "synthetic": bool(profile.get("synthetic")),
        "physical_validation": "NOT_ESTABLISHED",
        "status": "STOPPED",
        "accepted_samples": counts,
        "rejected_packet_count": parse_errors,
        "runtime_authority": False,
        "scientific_boundary": "LSL publication is transport evidence only and does not validate physiology, artifacts, medical use, or PRAYCG constructs.",
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "generic_eda_ppg_bridge_evidence_v0_1.json").write_text(json.dumps(evidence, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return evidence


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Generic EDA/PPG serial/UDP to LSL bridge v0.1")
    parser.add_argument("action", nargs="?", choices=("bridge", "preflight", "validate-profile"), default="bridge")
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--transport", choices=("serial", "udp"), help="Must agree with the reviewed driver profile")
    parser.add_argument("--run-uuid", default="")
    parser.add_argument("--out-dir", type=Path, default=Path.cwd() / "generic_eda_ppg_output")
    parser.add_argument("--duration", type=float, default=0.0, help="Bridge: 0 runs until stopped. Preflight: defaults to 30 seconds.")
    parser.add_argument("--max-records", type=int, default=0, help="Test/diagnostic bound; 0 is unlimited")
    args = parser.parse_args(argv)
    profile = load_json(args.profile)
    report = validate_driver_profile(profile, for_live=args.action == "bridge")
    if args.transport and args.transport != profile.get("transport", {}).get("kind"):
        report["errors"].append("--transport does not match the selected driver profile")
        report["status"] = "INELIGIBLE"
    if args.action == "validate-profile":
        print(json.dumps(report, indent=2))
        return 0 if report["status"] != "INELIGIBLE" else 4
    if report["status"] == "INELIGIBLE":
        print(json.dumps(report, indent=2), file=sys.stderr)
        return 4
    try:
        run_uuid = _validated_run_uuid(args.run_uuid)
    except ValueError as exc:
        print(f"ValueError: {exc}", file=sys.stderr)
        return 2
    signal.signal(signal.SIGINT, _stop)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, _stop)
    if args.action == "preflight":
        source = open_source(profile)
        try:
            duration = args.duration if args.duration > 0 else 30.0
            observations, parse_errors = collect_observations(source, profile, duration_seconds=duration, max_records=max(0, args.max_records))
        finally:
            source.close()
        result = summarize_preflight(observations, profile, requested_duration_seconds=duration, parse_error_count=parse_errors)
        result["profile_file_sha256"] = sha256_file(args.profile)
        result["run_uuid"] = run_uuid
        args.out_dir.mkdir(parents=True, exist_ok=True)
        (args.out_dir / "generic_eda_ppg_preflight_v0_1.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps(result, indent=2))
        return 0 if result["status"] == "PASS" else (3 if result["status"] == "CAUTION" else 4)
    try:
        evidence = bridge(profile, run_uuid, args.out_dir, duration_seconds=max(0.0, args.duration), max_records=max(0, args.max_records))
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 4
    print(json.dumps(evidence, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
