from __future__ import annotations

import importlib.util
import json
import math
from pathlib import Path
import sys
import unittest
import uuid


ROOT = Path(__file__).resolve().parents[4]
SCRIPTS = ROOT / "tools" / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1" / "scripts"
sys.path.insert(0, str(SCRIPTS))
from praycg_generic_eda_ppg_core_v0_1 import (  # noqa: E402
    Observation,
    load_json,
    parse_packet,
    summarize_preflight,
    validate_driver_profile,
)
from praycg_generic_eda_ppg_to_lsl_v0_1 import _validated_run_uuid, run_fragment  # noqa: E402
from praycg_generic_eda_ppg_profile_wizard_v0_1 import build_drafts, build_parser  # noqa: E402


PROFILE = ROOT / "tools" / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1" / "config" / "generic_eda_ppg_udp_SIMULATOR_v0_1.json"


class GenericEDAPPGTests(unittest.TestCase):
    def setUp(self) -> None:
        self.profile = load_json(PROFILE)

    def test_simulator_profile_is_valid_and_unmistakably_synthetic(self) -> None:
        report = validate_driver_profile(self.profile, for_live=True)
        self.assertEqual(report["status"], "PASS", report)
        self.assertTrue(self.profile["synthetic"])
        self.assertTrue(all(row["lsl_name"].startswith("SYNTHETIC_") for row in self.profile["streams"]))

    def test_parser_accepts_typed_packet_and_rejects_bad_values(self) -> None:
        packet = json.dumps({"stream": "eda", "values": [5.2], "device_timestamp_seconds": 1.0, "sequence": 4})
        row = parse_packet(packet, self.profile, host_timestamp_seconds=2.0)
        self.assertEqual(row.stream_id, "eda")
        self.assertEqual(row.sequence, 4)
        for bad in (
            {"stream": "unknown", "values": [1.0]},
            {"stream": "eda", "values": [1.0, 2.0]},
            {"stream": "eda", "values": [float("nan")]},
            {"stream": "eda", "values": [True]},
        ):
            with self.assertRaises((TypeError, ValueError)):
                parse_packet(json.dumps(bad), self.profile, host_timestamp_seconds=2.0)

    def test_preflight_reports_rate_pulse_and_clock_evidence_without_promoting_physical_validation(self) -> None:
        rows: list[Observation] = []
        for index in range(500):
            t = index / 100.0
            ppg = math.sin(2 * math.pi * 1.2 * t)
            rows.append(Observation("ppg", (ppg,), t, t, index))
            if index % 10 == 0:
                rows.append(Observation("eda", (5.0 + 0.2 * math.sin(2 * math.pi * 0.1 * t),), t, t, index // 10))
        report = summarize_preflight(rows, self.profile, requested_duration_seconds=5.0)
        self.assertNotEqual(report["status"], "INELIGIBLE", report)
        self.assertEqual(report["physical_validation"], "NOT_ESTABLISHED")
        ppg = next(row for row in report["streams"] if row["canonical_role"] == "ppg")
        self.assertTrue(ppg["rate_within_20_percent"])
        self.assertTrue(ppg["ppg_pulse_visibility"]["visible"])
        self.assertTrue(ppg["device_host_drift_evidence_available"])

    def test_missing_required_stream_is_ineligible(self) -> None:
        rows = [Observation("ppg", (math.sin(index / 10),), index / 100, None, index) for index in range(400)]
        report = summarize_preflight(rows, self.profile, requested_duration_seconds=4.0)
        self.assertEqual(report["status"], "INELIGIBLE")
        self.assertTrue(any("eda: no accepted samples" in item for item in report["errors"]))

    def test_run_identity_requires_a_full_uuid_and_uses_twelve_hex_characters(self) -> None:
        value = str(uuid.uuid4())
        self.assertEqual(_validated_run_uuid(value), value)
        self.assertEqual(len(run_fragment(value)), 12)
        for bad in ("", "not-a-uuid", "1234"):
            with self.assertRaises(ValueError):
                _validated_run_uuid(bad)

    def test_profile_wizard_outputs_catalog_only_physical_draft(self) -> None:
        args = build_parser().parse_args([
            "--transport", "udp",
            "--profile-id", "test_device",
            "--device-identity", "TEST_DEVICE",
            "--out-dir", "unused",
        ])
        driver, module = build_drafts(args)
        self.assertEqual(driver["status"], "DRAFT_NOT_REVIEWED")
        self.assertFalse(driver["runtime_authority"])
        self.assertEqual(module["module_id"], "generic_eda_ppg_udp")
        self.assertEqual(module["admission_state"], "CATALOG_ONLY")
        self.assertEqual(module["physical_validation"], "NOT_PERFORMED")

    def test_profile_wizard_keeps_simulation_explicit(self) -> None:
        args = build_parser().parse_args([
            "--transport", "udp",
            "--profile-id", "test_sim",
            "--device-identity", "TEST_SIM",
            "--out-dir", "unused",
            "--synthetic",
        ])
        driver, module = build_drafts(args)
        self.assertEqual(driver["status"], "SIMULATOR_ONLY")
        self.assertEqual(module["admission_state"], "SIMULATOR_VERIFIED")
        self.assertTrue(module["synthetic"])
        self.assertTrue(all(row["lsl_name"].startswith("SYNTHETIC_") for row in module["streams"]))


if __name__ == "__main__":
    unittest.main()
