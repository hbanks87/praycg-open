#!/usr/bin/env python3
"""Create typed, explicitly non-approved EDA/PPG driver and module drafts."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import hashlib
import sys
from typing import Any

from praycg_generic_eda_ppg_core_v0_1 import validate_driver_profile


def safe_id(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(value).lower()).strip("_") or "generic_eda_ppg"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_drafts(args: argparse.Namespace) -> tuple[dict[str, Any], dict[str, Any]]:
    profile_id = safe_id(args.profile_id)
    if args.transport == "serial":
        if not args.serial_port:
            raise ValueError("--serial-port is required for serial transport")
        transport = {
            "kind": "serial",
            "port": args.serial_port,
            "baud": args.baud,
            "read_timeout_seconds": 0.25,
        }
    else:
        transport = {
            "kind": "udp",
            "bind_host": args.bind_host,
            "port": args.udp_port,
            "read_timeout_seconds": 0.25,
        }
    lsl_prefix = "SYNTHETIC_" if args.synthetic else ""
    streams = [
        {
            "input_stream_id": "eda",
            "lsl_name": f"{lsl_prefix}PRAYCG_EDA",
            "canonical_role": "eda",
            "nominal_srate": args.eda_rate,
            "channel_count": args.eda_channels,
            "units": args.eda_units,
            "rail_min": args.eda_rail_min,
            "rail_max": args.eda_rail_max,
            "minimum_dynamic_range": args.eda_min_range,
        },
        {
            "input_stream_id": "ppg",
            "lsl_name": f"{lsl_prefix}PRAYCG_PPG",
            "canonical_role": "ppg",
            "nominal_srate": args.ppg_rate,
            "channel_count": args.ppg_channels,
            "units": args.ppg_units,
            "rail_min": args.ppg_rail_min,
            "rail_max": args.ppg_rail_max,
            "minimum_dynamic_range": args.ppg_min_range,
        },
    ]
    driver = {
        "schema": "PRAYCG_GenericEDAPPGDriverProfile_v0_1",
        "profile_id": profile_id,
        "created_utc": utc_now(),
        "status": "SIMULATOR_ONLY" if args.synthetic else "DRAFT_NOT_REVIEWED",
        "runtime_authority": False,
        "synthetic": bool(args.synthetic),
        "device_identity": args.device_identity,
        "transport": transport,
        "packet": {
            "format": "json_object_per_message",
            "stream_field": args.stream_field,
            "values_field": args.values_field,
            "device_timestamp_field": args.device_timestamp_field or None,
            "sequence_field": args.sequence_field or None,
        },
        "streams": streams,
        "calibration": {
            "status": "NONE" if not args.calibration_record else "OPERATOR_SUPPLIED_UNREVIEWED",
            "record": args.calibration_record or None,
            "transformation_applied_by_bridge": False,
        },
        "scientific_boundary": "Draft only. Values remain in declared native units; no calibration is applied by the bridge. Review packet semantics, rates, rails, units, timing, and physical behavior before use.",
    }
    validation = validate_driver_profile(driver)
    if validation["status"] == "INELIGIBLE":
        raise ValueError("Draft configuration is invalid: " + "; ".join(validation["errors"]))
    source_prefix = "synthetic_praycg_physio" if args.synthetic else "praycg_physio"
    module = {
        "schema": "PRAYCG_HardwareModule_v0_1",
        "module_id": f"generic_eda_ppg_{args.transport}",
        "module_version": "0.1.0-draft",
        "display_name": f"Generic EDA/PPG {args.transport.upper()} - {args.device_identity}",
        "transport": f"Typed {args.transport} JSON bridge profile {profile_id}",
        "trust_level": "COMMUNITY_UNVERIFIED",
        "admission_state": "SIMULATOR_VERIFIED" if args.synthetic else "CATALOG_ONLY",
        "physical_validation": "NOT_PERFORMED",
        "admission_evidence": [],
        "synthetic": bool(args.synthetic),
        "activation_status": "SIMULATOR_ONLY" if args.synthetic else "DRAFT_NOT_APPROVED",
        "runtime_authority": False,
        "physical_validation": "NOT_PERFORMED",
        "driver_profile_relative_path": f"{profile_id}_driver_profile_DRAFT.json",
        "streams": [
            {
                "lsl_name": stream["lsl_name"],
                "source_id": "",
                "source_id_policy": "dynamic_run_bound",
                "source_id_prefix": f"{source_prefix}_{stream['canonical_role']}_",
                "canonical_role": stream["canonical_role"],
                "nominal_srate": stream["nominal_srate"],
                "channel_count": stream["channel_count"],
                "units": stream["units"],
                "role_assignment_default": "PRIMARY",
            }
            for stream in streams
        ] + [{
            "lsl_name": f"{lsl_prefix}PRAYCG_PhysioStatusMarkers",
            "source_id": "",
            "source_id_policy": "dynamic_run_bound",
            "source_id_prefix": f"{source_prefix}_status_",
            "canonical_role": "markers",
            "nominal_srate": 0.0,
            "channel_count": 1,
            "units": "string",
            "role_assignment_default": "SUPPLEMENTAL",
        }],
        "preflight": {
            "duration_seconds": 30,
            "checks": [
                "effective_sample_rate", "timestamp_monotonicity", "gaps",
                "packet_loss_if_sequence_available", "nonfinite_values", "flat_signal",
                "clipping_if_rails_declared", "dynamic_range", "ppg_pulse_visibility",
                "motion_coupling_if_available", "device_host_clock_drift_if_available",
            ],
        },
        "managed_recovery": {"enabled_by_default": False, "status": "EXPERIMENTAL", "restart_limit_per_session": 0},
        "scientific_boundary": "Draft/module declaration is not physical, medical, physiological, timing, artifact, or construct validation.",
    }
    return driver, module


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PRAYCG Generic EDA/PPG profile wizard v0.1 (draft-only)")
    parser.add_argument("--transport", choices=("serial", "udp"), required=True)
    parser.add_argument("--profile-id", required=True)
    parser.add_argument("--device-identity", required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--serial-port")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--bind-host", default="127.0.0.1")
    parser.add_argument("--udp-port", type=int, default=18995)
    parser.add_argument("--stream-field", default="stream")
    parser.add_argument("--values-field", default="values")
    parser.add_argument("--device-timestamp-field", default="device_timestamp_seconds")
    parser.add_argument("--sequence-field", default="sequence")
    parser.add_argument("--eda-rate", type=float, default=10.0)
    parser.add_argument("--eda-channels", type=int, default=1)
    parser.add_argument("--eda-units", default="device_native")
    parser.add_argument("--eda-rail-min", type=float)
    parser.add_argument("--eda-rail-max", type=float)
    parser.add_argument("--eda-min-range", type=float, default=0.0)
    parser.add_argument("--ppg-rate", type=float, default=100.0)
    parser.add_argument("--ppg-channels", type=int, default=1)
    parser.add_argument("--ppg-units", default="device_native")
    parser.add_argument("--ppg-rail-min", type=float)
    parser.add_argument("--ppg-rail-max", type=float)
    parser.add_argument("--ppg-min-range", type=float, default=0.0)
    parser.add_argument("--calibration-record", help="Path or identifier recorded verbatim; the bridge never applies it")
    parser.add_argument("--synthetic", action="store_true", help="Create a simulator-only profile with SYNTHETIC_ outlet names")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        driver, module = build_drafts(args)
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    profile_id = safe_id(args.profile_id)
    driver_path = args.out_dir / f"{profile_id}_driver_profile_DRAFT.json"
    module_path = args.out_dir / f"{profile_id}_hardware_module_DRAFT.json"
    write_json(driver_path, driver)
    module["driver_profile_relative_path"] = driver_path.name
    module["driver_profile_sha256"] = sha256_file(driver_path)
    write_json(module_path, module)
    result = {
        "schema": "PRAYCG_GenericEDAPPGWizardResult_v0_1",
        "status": "DRAFT_NOT_APPROVED",
        "runtime_authority": False,
        "driver_profile": str(driver_path.resolve()),
        "hardware_module": str(module_path.resolve()),
        "next_gate": "Review exact device semantics, then validate/register the module and run a physical 30-second preflight. This wizard cannot perform those approvals.",
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
