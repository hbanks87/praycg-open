#!/usr/bin/env python3
"""Typed packet parsing and conservative signal-health checks for EDA/PPG."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import statistics
from typing import Any, Iterable, Mapping


PROFILE_SCHEMA = "PRAYCG_GenericEDAPPGDriverProfile_v0_1"
PROFILE_STATUSES = {"TEMPLATE_NOT_CONFIGURED", "DRAFT_NOT_REVIEWED", "SIMULATOR_ONLY", "REVIEWED_DRIVER_PROFILE"}
ALLOWED_ROLES = {"eda", "ppg", "analog_aux"}
PLACEHOLDERS = {"CONFIGURE_BEFORE_USE", "REPLACE_ME", "UNRECORDED", "UNKNOWN"}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("Driver profile must be a JSON object.")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_driver_profile(profile: Mapping[str, Any], *, for_live: bool = False) -> dict[str, Any]:
    errors: list[str] = []
    cautions: list[str] = []
    if profile.get("schema") != PROFILE_SCHEMA:
        errors.append(f"schema must be {PROFILE_SCHEMA}")
    if profile.get("status") not in PROFILE_STATUSES:
        errors.append("profile status is not recognized")
    if profile.get("runtime_authority") is not False:
        errors.append("runtime_authority must be false")
    synthetic = profile.get("synthetic")
    if not isinstance(synthetic, bool):
        errors.append("synthetic must be boolean")
    if profile.get("status") == "SIMULATOR_ONLY" and synthetic is not True:
        errors.append("SIMULATOR_ONLY profiles must set synthetic=true")
    if synthetic:
        for stream in profile.get("streams", []):
            if not str(stream.get("lsl_name") or "").startswith("SYNTHETIC_"):
                errors.append("every synthetic LSL name must start with SYNTHETIC_")
    if for_live and profile.get("status") in {"TEMPLATE_NOT_CONFIGURED", "DRAFT_NOT_REVIEWED"}:
        errors.append("template/draft profile is not eligible for a live bridge; review it first")
    transport = profile.get("transport")
    if not isinstance(transport, Mapping) or transport.get("kind") not in {"serial", "udp"}:
        errors.append("transport.kind must be serial or udp")
        transport = {}
    if transport.get("kind") == "serial":
        port = str(transport.get("port") or "")
        if not port or port in PLACEHOLDERS:
            errors.append("serial port must be configured")
        try:
            if int(transport.get("baud", 0)) < 1200:
                errors.append("serial baud must be at least 1200")
        except (TypeError, ValueError):
            errors.append("serial baud must be an integer")
    elif transport.get("kind") == "udp":
        host = str(transport.get("bind_host") or "")
        if not host:
            errors.append("UDP bind_host is required")
        try:
            port = int(transport.get("port", 0))
            if not 1024 <= port <= 65535:
                errors.append("UDP port must be in 1024..65535")
        except (TypeError, ValueError):
            errors.append("UDP port must be an integer")
    packet = profile.get("packet")
    if not isinstance(packet, Mapping) or packet.get("format") != "json_object_per_message":
        errors.append("packet format must be json_object_per_message")
        packet = {}
    for field in ("stream_field", "values_field"):
        if not str(packet.get(field) or ""):
            errors.append(f"packet.{field} is required")
    streams = profile.get("streams")
    if not isinstance(streams, list) or len(streams) < 2:
        errors.append("at least two typed streams are required")
        streams = []
    ids: set[str] = set()
    names: set[str] = set()
    roles: set[str] = set()
    for stream in streams:
        if not isinstance(stream, Mapping):
            errors.append("stream entry is not an object")
            continue
        input_id = str(stream.get("input_stream_id") or "")
        lsl_name = str(stream.get("lsl_name") or "")
        role = str(stream.get("canonical_role") or "")
        if not input_id or input_id in ids:
            errors.append(f"input_stream_id is empty or duplicated: {input_id!r}")
        ids.add(input_id)
        if not lsl_name or lsl_name in names:
            errors.append(f"lsl_name is empty or duplicated: {lsl_name!r}")
        names.add(lsl_name)
        if role not in ALLOWED_ROLES:
            errors.append(f"unsupported canonical role: {role!r}")
        roles.add(role)
        try:
            if float(stream.get("nominal_srate", 0)) <= 0:
                errors.append(f"{input_id or '?'} nominal_srate must be positive")
        except (TypeError, ValueError):
            errors.append(f"{input_id or '?'} nominal_srate must be numeric")
        try:
            if int(stream.get("channel_count", 0)) < 1:
                errors.append(f"{input_id or '?'} channel_count must be positive")
        except (TypeError, ValueError):
            errors.append(f"{input_id or '?'} channel_count must be an integer")
        rail_min, rail_max = stream.get("rail_min"), stream.get("rail_max")
        if rail_min is not None and rail_max is not None:
            try:
                if float(rail_min) >= float(rail_max):
                    errors.append(f"{input_id or '?'} rail_min must be below rail_max")
            except (TypeError, ValueError):
                errors.append(f"{input_id or '?'} rail limits must be numeric")
        if rail_min is None or rail_max is None:
            cautions.append(f"{input_id or '?'} has no declared rail limits; clipping cannot be fully evaluated")
    if not {"eda", "ppg"}.issubset(roles):
        errors.append("typed EDA and PPG stream declarations are both required")
    if not str(profile.get("scientific_boundary") or "").strip():
        errors.append("scientific_boundary is required")
    return {
        "schema": "PRAYCG_GenericEDAPPGProfileValidation_v0_1",
        "generated_utc": utc_now(),
        "status": "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS"),
        "errors": errors,
        "cautions": cautions,
        "runtime_authority": False,
    }


@dataclass(frozen=True)
class Observation:
    stream_id: str
    values: tuple[float, ...]
    host_timestamp_seconds: float
    device_timestamp_seconds: float | None
    sequence: int | None


def parse_packet(raw: bytes | str, profile: Mapping[str, Any], *, host_timestamp_seconds: float) -> Observation:
    if isinstance(raw, bytes):
        text = raw.decode("utf-8", errors="strict")
    else:
        text = raw
    payload = json.loads(text.strip())
    if not isinstance(payload, Mapping):
        raise ValueError("packet must be a JSON object")
    packet = profile["packet"]
    stream_field = str(packet["stream_field"])
    values_field = str(packet["values_field"])
    stream_id = str(payload.get(stream_field) or "")
    declared = {str(row["input_stream_id"]): row for row in profile["streams"]}
    if stream_id not in declared:
        raise ValueError(f"unknown input stream identifier: {stream_id!r}")
    raw_values = payload.get(values_field)
    if isinstance(raw_values, (int, float)) and not isinstance(raw_values, bool):
        raw_values = [raw_values]
    if not isinstance(raw_values, list):
        raise ValueError("packet values must be a number or numeric list")
    if len(raw_values) != int(declared[stream_id]["channel_count"]):
        raise ValueError(f"{stream_id} packet channel count does not match the reviewed driver profile")
    values: list[float] = []
    for raw_value in raw_values:
        if isinstance(raw_value, bool):
            raise ValueError("boolean values are not numeric samples")
        value = float(raw_value)
        if not math.isfinite(value):
            raise ValueError("non-finite sample value")
        values.append(value)
    timestamp_field = packet.get("device_timestamp_field")
    device_timestamp: float | None = None
    if timestamp_field and payload.get(str(timestamp_field)) is not None:
        device_timestamp = float(payload[str(timestamp_field)])
        if not math.isfinite(device_timestamp):
            raise ValueError("device timestamp is non-finite")
    sequence_field = packet.get("sequence_field")
    sequence: int | None = None
    if sequence_field and payload.get(str(sequence_field)) is not None:
        sequence = int(payload[str(sequence_field)])
        if sequence < 0:
            raise ValueError("sequence must be nonnegative")
    return Observation(
        stream_id=stream_id,
        values=tuple(values),
        host_timestamp_seconds=float(host_timestamp_seconds),
        device_timestamp_seconds=device_timestamp,
        sequence=sequence,
    )


def _pearson(x: list[float], y: list[float]) -> float | None:
    if len(x) != len(y) or len(x) < 3:
        return None
    mx, my = statistics.fmean(x), statistics.fmean(y)
    dx = [v - mx for v in x]
    dy = [v - my for v in y]
    denom = math.sqrt(sum(v * v for v in dx) * sum(v * v for v in dy))
    return sum(a * b for a, b in zip(dx, dy)) / denom if denom > 0 else None


def _pulse_visibility(values: list[float], timestamps: list[float], nominal_srate: float) -> dict[str, Any]:
    if len(values) < max(10, int(nominal_srate * 3)) or len(timestamps) != len(values):
        return {"available": False, "reason": "insufficient duration or samples"}
    mean = statistics.fmean(values)
    sd = statistics.pstdev(values)
    if sd <= 0:
        return {"available": True, "visible": False, "peak_count": 0, "estimated_bpm": None}
    threshold = mean + 0.25 * sd
    min_separation = max(1, int(round(nominal_srate * 0.30)))
    peaks: list[int] = []
    for index in range(1, len(values) - 1):
        if values[index] > threshold and values[index] >= values[index - 1] and values[index] > values[index + 1]:
            if not peaks or index - peaks[-1] >= min_separation:
                peaks.append(index)
            elif values[index] > values[peaks[-1]]:
                peaks[-1] = index
    duration = timestamps[-1] - timestamps[0]
    bpm = 60.0 * max(0, len(peaks) - 1) / duration if duration > 0 and len(peaks) >= 2 else None
    visible = bpm is not None and 30.0 <= bpm <= 220.0
    return {"available": True, "visible": visible, "peak_count": len(peaks), "estimated_bpm": bpm, "method": "simple local-peak transport check; not a validated beat detector"}


def summarize_preflight(
    observations: Iterable[Observation],
    profile: Mapping[str, Any],
    *,
    requested_duration_seconds: float,
    parse_error_count: int = 0,
) -> dict[str, Any]:
    rows = list(observations)
    errors: list[str] = []
    cautions: list[str] = []
    stream_reports: list[dict[str, Any]] = []
    by_id: dict[str, list[Observation]] = {}
    for row in rows:
        by_id.setdefault(row.stream_id, []).append(row)
    if parse_error_count:
        cautions.append(f"{parse_error_count} malformed or non-finite packet(s) were rejected")
    motion_streams: list[tuple[list[float], list[float]]] = []
    for stream in profile["streams"]:
        stream_id = str(stream["input_stream_id"])
        role = str(stream["canonical_role"])
        observed = by_id.get(stream_id, [])
        host_ts = [row.host_timestamp_seconds for row in observed]
        values_by_channel = [
            [row.values[channel] for row in observed]
            for channel in range(int(stream["channel_count"]))
        ]
        duration = host_ts[-1] - host_ts[0] if len(host_ts) >= 2 else 0.0
        effective_rate = (len(host_ts) - 1) / duration if duration > 0 else 0.0
        nominal = float(stream["nominal_srate"])
        deltas = [b - a for a, b in zip(host_ts, host_ts[1:])]
        monotonic = all(delta >= 0 for delta in deltas)
        duplicate_host_timestamps = sum(1 for delta in deltas if delta == 0)
        gap_threshold = max(0.1, 5.0 / nominal)
        large_gaps = [delta for delta in deltas if delta > gap_threshold]
        rate_ok = 0.8 * nominal <= effective_rate <= 1.2 * nominal
        flat_channels = [index + 1 for index, channel in enumerate(values_by_channel) if channel and max(channel) == min(channel)]
        rail_min, rail_max = stream.get("rail_min"), stream.get("rail_max")
        clipping_available = rail_min is not None and rail_max is not None
        clipped = 0
        total_values = sum(len(channel) for channel in values_by_channel)
        if clipping_available:
            low, high = float(rail_min), float(rail_max)
            clipped = sum(1 for channel in values_by_channel for value in channel if value <= low or value >= high)
        dynamic_ranges = [max(channel) - min(channel) if channel else 0.0 for channel in values_by_channel]
        min_range = float(stream.get("minimum_dynamic_range", 0.0) or 0.0)
        dynamic_ok = all(value >= min_range for value in dynamic_ranges) if observed else False
        sequences = [row.sequence for row in observed if row.sequence is not None]
        missing_by_sequence = 0
        duplicate_or_reordered = 0
        for a, b in zip(sequences, sequences[1:]):
            if b <= a:
                duplicate_or_reordered += 1
            elif b > a + 1:
                missing_by_sequence += b - a - 1
        device_rows = [row for row in observed if row.device_timestamp_seconds is not None]
        drift_ppm: float | None = None
        if len(device_rows) >= 2:
            host_span = device_rows[-1].host_timestamp_seconds - device_rows[0].host_timestamp_seconds
            device_span = float(device_rows[-1].device_timestamp_seconds) - float(device_rows[0].device_timestamp_seconds)
            if host_span > 0:
                drift_ppm = ((device_span / host_span) - 1.0) * 1_000_000.0
        pulse = _pulse_visibility(values_by_channel[0], host_ts, nominal) if role == "ppg" and values_by_channel else {"available": False, "reason": "not a PPG stream"}
        if not observed:
            errors.append(f"{stream_id}: no accepted samples")
        else:
            if not monotonic:
                errors.append(f"{stream_id}: host-receipt timestamps regress")
            if duplicate_host_timestamps:
                cautions.append(f"{stream_id}: {duplicate_host_timestamps} duplicate host-receipt timestamp(s) reflect limited host clock resolution or packet batching")
            if not rate_ok:
                cautions.append(f"{stream_id}: effective rate is outside +/-20% of nominal")
            if large_gaps:
                cautions.append(f"{stream_id}: {len(large_gaps)} large gap(s) detected")
            if flat_channels:
                cautions.append(f"{stream_id}: flat channel(s) {flat_channels}")
            if clipping_available and clipped:
                cautions.append(f"{stream_id}: {clipped} value(s) reached declared rails")
            if not dynamic_ok:
                cautions.append(f"{stream_id}: declared minimum dynamic range was not met")
            if missing_by_sequence or duplicate_or_reordered:
                cautions.append(f"{stream_id}: sequence evidence indicates loss, duplication, or reordering")
            if drift_ppm is not None and abs(drift_ppm) > 2000:
                cautions.append(f"{stream_id}: device/host span differs by more than 2000 ppm")
            if role == "ppg" and pulse.get("available") and not pulse.get("visible"):
                cautions.append(f"{stream_id}: simple pulse-visibility check did not find a plausible repeating waveform")
        report = {
            "input_stream_id": stream_id,
            "lsl_name": stream["lsl_name"],
            "canonical_role": role,
            "sample_count": len(observed),
            "observed_duration_seconds": duration,
            "nominal_srate_hz": nominal,
            "effective_sample_rate_hz": effective_rate,
            "rate_within_20_percent": rate_ok,
            "host_timestamp_monotonic": monotonic,
            "duplicate_host_timestamp_count": duplicate_host_timestamps,
            "large_gap_threshold_seconds": gap_threshold,
            "large_gap_count": len(large_gaps),
            "flat_channel_indices_1based": flat_channels,
            "clipping_check_available": clipping_available,
            "declared_rail_hit_count": clipped,
            "declared_rail_hit_fraction": clipped / total_values if total_values else None,
            "dynamic_range_by_channel": dynamic_ranges,
            "minimum_dynamic_range_met": dynamic_ok,
            "sequence_evidence_available": bool(sequences),
            "sequence_missing_estimate": missing_by_sequence,
            "sequence_duplicate_or_reordered_count": duplicate_or_reordered,
            "device_host_drift_evidence_available": drift_ppm is not None,
            "device_host_span_drift_ppm": drift_ppm,
            "ppg_pulse_visibility": pulse,
        }
        stream_reports.append(report)
        if role == "analog_aux" and stream.get("semantic_subrole") == "motion" and values_by_channel:
            magnitude = [math.sqrt(sum(values_by_channel[ch][i] ** 2 for ch in range(len(values_by_channel)))) for i in range(len(observed))]
            motion_streams.append((host_ts, magnitude))
    motion_coupling: dict[str, Any]
    ppg = next((report for report in stream_reports if report["canonical_role"] == "ppg"), None)
    if not motion_streams or ppg is None:
        motion_coupling = {"available": False, "reason": "no reviewed motion stream in this driver profile"}
    else:
        ppg_obs = by_id.get(str(ppg["input_stream_id"]), [])
        motion_ts, motion_values = motion_streams[0]
        if len(motion_values) != len(ppg_obs) or motion_ts != [row.host_timestamp_seconds for row in ppg_obs]:
            motion_coupling = {"available": False, "reason": "motion and PPG samples are not co-sampled; resampling was not assumed"}
        else:
            corr = _pearson([row.values[0] for row in ppg_obs], motion_values)
            motion_coupling = {"available": corr is not None, "pearson_r": corr, "interpretation": "nonspecific artifact indicator only"}
    status = "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS")
    return {
        "schema": "PRAYCG_GenericEDAPPGPreflight_v0_1",
        "generated_utc": utc_now(),
        "status": status,
        "requested_duration_seconds": requested_duration_seconds,
        "synthetic": bool(profile.get("synthetic")),
        "physical_validation": "NOT_ESTABLISHED",
        "parse_error_count": parse_error_count,
        "streams": stream_reports,
        "motion_coupling": motion_coupling,
        "errors": errors,
        "cautions": cautions,
        "scientific_boundary": "This is a transport and signal-health screen, not medical validation, physiological validity, artifact removal, or evidence for a PRAYCG construct.",
    }
