#!/usr/bin/env python3
"""Transmit unmistakably synthetic EDA/PPG JSON datagrams for bridge testing."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import random
import socket
import sys
import time
import uuid

from praycg_generic_eda_ppg_core_v0_1 import load_json, utc_now, validate_driver_profile


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_PROFILE = SCRIPT_DIR.parent / "config" / "generic_eda_ppg_udp_SIMULATOR_v0_1.json"


def _uuid(value: str) -> str:
    try:
        return str(uuid.UUID(str(value)))
    except ValueError as exc:
        raise argparse.ArgumentTypeError("run UUID must be a full UUID") from exc


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PRAYCG synthetic EDA/PPG UDP source v0.1")
    parser.add_argument("--profile", type=Path, default=DEFAULT_PROFILE)
    parser.add_argument("--run-uuid", type=_uuid, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int)
    parser.add_argument("--duration", type=float, default=30.0)
    parser.add_argument("--seed", type=int, default=104)
    parser.add_argument("--out-dir", type=Path, default=Path.cwd() / "generic_eda_ppg_simulator_output")
    args = parser.parse_args(argv)
    profile = load_json(args.profile)
    validation = validate_driver_profile(profile)
    if validation["status"] == "INELIGIBLE" or profile.get("synthetic") is not True or profile.get("status") != "SIMULATOR_ONLY":
        print("Selected profile must be a valid SIMULATOR_ONLY profile with synthetic=true.", file=sys.stderr)
        return 4
    if profile["transport"]["kind"] != "udp":
        print("The v0.1 simulator supports UDP only.", file=sys.stderr)
        return 4
    port = int(args.port or profile["transport"]["port"])
    if not 1024 <= port <= 65535:
        print("UDP port must be in 1024..65535.", file=sys.stderr)
        return 2
    duration = max(0.1, float(args.duration))
    streams = {str(row["canonical_role"]): row for row in profile["streams"]}
    ppg_rate = float(streams["ppg"]["nominal_srate"])
    eda_rate = float(streams["eda"]["nominal_srate"])
    if ppg_rate < eda_rate or abs(round(ppg_rate / eda_rate) - (ppg_rate / eda_rate)) > 1e-9:
        print("Simulator fixture requires PPG rate to be an integer multiple of EDA rate.", file=sys.stderr)
        return 4
    eda_stride = int(round(ppg_rate / eda_rate))
    rng = random.Random(args.seed)
    counts = {"eda": 0, "ppg": 0}
    packet = profile["packet"]
    stream_field = str(packet["stream_field"])
    values_field = str(packet["values_field"])
    ts_field = str(packet.get("device_timestamp_field") or "device_timestamp_seconds")
    seq_field = str(packet.get("sequence_field") or "sequence")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    started = time.perf_counter()
    total_ticks = int(round(duration * ppg_rate))
    try:
        for tick in range(total_ticks):
            target = started + tick / ppg_rate
            delay = target - time.perf_counter()
            if delay > 0:
                time.sleep(delay)
            t = tick / ppg_rate
            ppg = 0.80 * math.sin(2.0 * math.pi * 1.2 * t) + 0.18 * math.sin(2.0 * math.pi * 2.4 * t) + rng.gauss(0.0, 0.015)
            payload = {
                stream_field: "ppg",
                values_field: [ppg],
                ts_field: t,
                seq_field: counts["ppg"],
                "run_uuid": args.run_uuid,
                "synthetic": True,
            }
            sock.sendto(json.dumps(payload, separators=(",", ":")).encode("utf-8"), (args.host, port))
            counts["ppg"] += 1
            if tick % eda_stride == 0:
                eda = 5.0 + 0.25 * math.sin(2.0 * math.pi * 0.08 * t) + 0.08 * math.sin(2.0 * math.pi * 0.31 * t) + rng.gauss(0.0, 0.008)
                payload = {
                    stream_field: "eda",
                    values_field: [eda],
                    ts_field: t,
                    seq_field: counts["eda"],
                    "run_uuid": args.run_uuid,
                    "synthetic": True,
                }
                sock.sendto(json.dumps(payload, separators=(",", ":")).encode("utf-8"), (args.host, port))
                counts["eda"] += 1
    finally:
        sock.close()
    summary = {
        "schema": "PRAYCG_GenericEDAPPGSimulatorEvidence_v0_1",
        "generated_utc": utc_now(),
        "run_uuid": args.run_uuid,
        "synthetic": True,
        "destination": {"host": args.host, "port": port},
        "requested_duration_seconds": duration,
        "sent_packets": counts,
        "seed": args.seed,
        "physical_validation": "NOT_APPLICABLE",
        "runtime_authority": False,
        "scientific_boundary": "Synthetic transport fixture only; never participant data or physical-device evidence.",
    }
    args.out_dir.mkdir(parents=True, exist_ok=True)
    (args.out_dir / "generic_eda_ppg_simulator_evidence_v0_1.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
