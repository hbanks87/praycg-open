#!/usr/bin/env python3
"""Shared packet, timestamp, and final-QC helpers for PRAYCG BrainFlow bridges."""
from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

DIAGNOSTICS_VERSION = "1.0"


def atomic_write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    os.replace(str(temp), str(path))


def file_sha256(path: str) -> Optional[str]:
    if not str(path or "").strip():
        return None
    p = Path(path).expanduser()
    if not p.is_file():
        return None
    h = hashlib.sha256()
    with p.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def software_versions() -> Dict[str, Any]:
    values: Dict[str, Any] = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "numpy": np.__version__,
        "diagnostics": DIAGNOSTICS_VERSION,
    }
    try:
        import brainflow  # type: ignore
        values["brainflow"] = getattr(brainflow, "__version__", "unknown")
    except Exception:
        values["brainflow"] = "unavailable"
    try:
        import pylsl  # type: ignore
        values["pylsl"] = getattr(pylsl, "__version__", "unknown")
    except Exception:
        values["pylsl"] = "unavailable"
    return values


def analyze_package_numbers(
    packages: Optional[Sequence[int]],
    last_package: Optional[int],
    expected_step: int = 1,
) -> Tuple[Dict[str, int], Optional[int], List[int]]:
    """Classify 8-bit packet deltas using the board's native counter stride.

    Cyton+Daisy samples advance the packet counter by two. Treating that native
    stride as a one-packet gap doubles reconstructed time and reports nearly
    every valid sample as packet loss.
    """
    expected_step = int(expected_step)
    if expected_step < 1 or expected_step > 128:
        raise ValueError("expected_step must be between 1 and 128")
    counts = {"missing": 0, "duplicates": 0, "out_of_order": 0}
    gaps: List[int] = []
    current_last = last_package
    if packages is None:
        return counts, current_last, gaps
    for raw in packages:
        packet = int(raw) % 256
        if current_last is None:
            gaps.append(1)
        else:
            delta = (packet - current_last) % 256
            if delta == 0:
                counts["duplicates"] += 1
                gaps.append(1)
            elif 1 <= delta <= 128 and delta % expected_step == 0:
                sample_steps = delta // expected_step
                missing = sample_steps - 1
                counts["missing"] += missing
                gaps.append(1 + missing)
            else:
                counts["out_of_order"] += 1
                gaps.append(1)
        current_last = packet
    return counts, current_last, gaps


def reconstruct_lsl_timestamps(
    sample_count: int,
    nominal_rate_hz: float,
    packages: Optional[Sequence[int]],
    last_package: Optional[int],
    last_lsl_timestamp: Optional[float],
    current_lsl_clock: float,
    expected_package_step: int = 1,
) -> Tuple[List[float], Optional[int], Optional[float], Dict[str, int], float]:
    dt = 1.0 / float(nominal_rate_hz)
    counts, new_last_package, gap_steps = analyze_package_numbers(
        packages,
        last_package,
        expected_step=expected_package_step,
    )
    if last_lsl_timestamp is None:
        last_lsl_timestamp = current_lsl_clock - sample_count * dt
    stamps: List[float] = []
    max_gap = 0.0
    for index in range(sample_count):
        steps = gap_steps[index] if index < len(gap_steps) else 1
        step = max(1, int(steps)) * dt
        last_lsl_timestamp += step
        max_gap = max(max_gap, step)
        stamps.append(last_lsl_timestamp)
    return stamps, new_last_package, last_lsl_timestamp, counts, max_gap


def device_timestamp_summary(values: Optional[Sequence[float]], host_first: Optional[float], host_last: Optional[float]) -> Dict[str, Any]:
    if values is None:
        return {"device_timestamp_first": None, "device_timestamp_last": None, "clock_offset_first_sec": None, "clock_offset_last_sec": None}
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return {"device_timestamp_first": None, "device_timestamp_last": None, "clock_offset_first_sec": None, "clock_offset_last_sec": None}
    first, last = float(arr[0]), float(arr[-1])
    # BrainFlow device timestamps are normally Unix-domain seconds; host LSL is a
    # monotonic clock.  Report their offset only when both look like the same domain.
    comparable_first = host_first is not None and abs(first - host_first) < 86400.0
    comparable_last = host_last is not None and abs(last - host_last) < 86400.0
    return {
        "device_timestamp_first": first,
        "device_timestamp_last": last,
        "clock_offset_first_sec": (first - float(host_first)) if comparable_first else None,
        "clock_offset_last_sec": (last - float(host_last)) if comparable_last else None,
    }


def channel_health(samples: np.ndarray, saturation_abs: float = 100000.0) -> Dict[str, Any]:
    if samples.ndim != 2 or not samples.size:
        return {"nonfinite_count": 0, "flat_channel_count": 0, "saturation_count": 0, "channel_std": []}
    finite = np.isfinite(samples)
    stds = np.nanstd(np.where(finite, samples, np.nan), axis=0)
    spans = np.nanmax(np.where(finite, samples, np.nan), axis=0) - np.nanmin(np.where(finite, samples, np.nan), axis=0)
    return {
        "nonfinite_count": int(np.size(samples) - np.sum(finite)),
        "flat_channel_count": int(np.sum((stds < 0.5) | (spans < 2.0))),
        "saturation_count": int(np.sum(np.abs(np.where(finite, samples, 0.0)) >= saturation_abs)),
        "channel_std": [float(x) if math.isfinite(float(x)) else None for x in stds],
    }


def final_qc(
    *,
    run_uuid: str,
    bridge_version: str,
    exit_reason: str,
    error: str,
    expected_rate_hz: float,
    samples_total: int,
    elapsed_sec: float,
    package_missing: int,
    duplicates: int,
    out_of_order: int,
    max_gap_sec: float,
    nonfinite_count: int,
    saturation_count: int,
    max_buffer_samples: int,
    als_expected: bool = False,
    als_samples: int = 0,
) -> Dict[str, Any]:
    effective = samples_total / elapsed_sec if elapsed_sec > 0 else 0.0
    rate_error = abs(effective - expected_rate_hz) / expected_rate_hz if expected_rate_hz > 0 else 0.0
    fail: List[str] = []
    warn: List[str] = []
    if error:
        fail.append("bridge exception: " + error)
    if samples_total <= 0:
        fail.append("no EEG samples published")
    if elapsed_sec >= 5.0 and rate_error > 0.20:
        fail.append("effective sample rate differs from nominal by more than 20%")
    elif elapsed_sec >= 5.0 and rate_error > 0.05:
        warn.append("effective sample rate differs from nominal by more than 5%")
    if package_missing:
        warn.append(f"{package_missing} package(s) missing")
    if duplicates:
        warn.append(f"{duplicates} duplicate package(s)")
    if out_of_order:
        warn.append(f"{out_of_order} out-of-order package transition(s)")
    if nonfinite_count:
        warn.append(f"{nonfinite_count} non-finite EEG value(s) preserved as missing")
    if saturation_count:
        warn.append(f"{saturation_count} EEG value(s) crossed the saturation review threshold")
    if als_expected and als_samples <= 0:
        fail.append("ALS publishing was requested but no ALS samples were published")
    status = "FAIL" if fail else ("WARN" if warn else "PASS")
    return {
        "schema": "PRAYCG_BrainFlow_FinalQC_v1_0",
        "created_unix": time.time(),
        "run_uuid": run_uuid,
        "bridge_version": bridge_version,
        "status": status,
        "exit_reason": exit_reason,
        "error": error or None,
        "expected_rate_hz": expected_rate_hz,
        "effective_rate_hz": effective,
        "rate_error_fraction": rate_error,
        "samples_total": samples_total,
        "elapsed_sec": elapsed_sec,
        "package_missing_total": package_missing,
        "duplicate_packages_total": duplicates,
        "out_of_order_packages_total": out_of_order,
        "max_timestamp_gap_sec": max_gap_sec,
        "nonfinite_eeg_values_total": nonfinite_count,
        "saturation_review_values_total": saturation_count,
        "max_brainflow_buffer_samples": max_buffer_samples,
        "als_samples_total": als_samples,
        "fail_reasons": fail,
        "warning_reasons": warn,
    }
