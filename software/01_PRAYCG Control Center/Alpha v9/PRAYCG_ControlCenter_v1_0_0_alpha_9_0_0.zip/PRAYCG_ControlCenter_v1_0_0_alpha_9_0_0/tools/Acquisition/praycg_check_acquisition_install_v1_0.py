#!/usr/bin/env python3
"""Fail-closed, hardware-free checks shared by the installer and both bridges.

Imports alone do not load BrainFlow's BoardController library. These checks do,
but never construct a board, prepare a session, create outlets, or start streams.
Passing establishes software readiness only, not hardware or ALS timing quality.
"""
from __future__ import annotations

import importlib
from importlib import metadata
import math
import platform
import sys


def main() -> int:
    print("Python:", sys.version)
    print("Executable:", sys.executable)
    print("Platform:", platform.platform())
    failed = False
    loaded = {}
    for module_name, distribution in (
        ("numpy", "numpy"), ("pylsl", "pylsl"),
        ("serial", "pyserial"), ("brainflow.board_shim", "brainflow"),
    ):
        try:
            loaded[module_name] = importlib.import_module(module_name)
            print(f"OK: {module_name} version={metadata.version(distribution)}")
        except Exception as exc:
            failed = True
            print(f"FAIL: {module_name}: {exc!r}")

    if "pylsl" in loaded:
        try:
            if not math.isfinite(float(loaded["pylsl"].local_clock())):
                raise RuntimeError("LSL returned a nonfinite clock value")
            print("OK: LSL native library loaded (clock-only check)")
        except Exception as exc:
            failed = True
            print(f"FAIL: LSL native library: {exc!r}")

    if "brainflow.board_shim" in loaded:
        try:
            module = loaded["brainflow.board_shim"]
            board = module.BoardShim
            board.disable_board_logger()  # Forces DLL load without opening hardware.
            for label, board_id, channels in (
                ("cyton", module.BoardIds.CYTON_BOARD.value, 8),
                ("cyton-daisy", module.BoardIds.CYTON_DAISY_BOARD.value, 16),
            ):
                rate = float(board.get_sampling_rate(board_id))
                eeg = list(board.get_eeg_channels(board_id))
                analog = list(board.get_analog_channels(board_id))
                if not math.isfinite(rate) or rate <= 0 or len(eeg) != channels or len(analog) != 3:
                    raise RuntimeError(f"Unexpected {label} metadata: rate={rate}, EEG={eeg}, analog={analog}")
                print(f"OK: {label}: {rate:g} Hz, {len(eeg)} EEG channels, {len(analog)} analog AUX channels")
            print("OK: BrainFlow native library and board metadata")
        except Exception as exc:
            failed = True
            print(f"FAIL: BrainFlow native library / board metadata: {exc!r}")
            if "pkg_resources" in str(exc):
                print('Repair in this Python environment: python -m pip install "setuptools>=80.9,<82"')

    if failed:
        print("FAIL: Acquisition dependencies are not ready. No hardware was opened.")
        return 1
    print("PASS: Acquisition software checks. Board connection and ALS pulse quality are NOT tested.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
