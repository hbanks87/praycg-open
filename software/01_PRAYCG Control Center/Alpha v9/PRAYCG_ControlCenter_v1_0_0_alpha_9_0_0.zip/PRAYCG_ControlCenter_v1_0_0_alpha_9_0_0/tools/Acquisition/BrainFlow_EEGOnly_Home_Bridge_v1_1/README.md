# PRAYCG BrainFlow EEG-Only LSL Bridge v1.1

This remains the v1.1 acquisition component inside **PRAYCG Control Center v1.0.0-alpha.4**. Its version records component lineage; alpha.4 supplies the current profile, run-identity, preflight, lock, and arming workflow. Carried alpha.2-named lock and evidence schemas remain compatibility contracts, not an alternate current release.

A simple public-home acquisition bridge for PR-AYC-G users who want OpenBCI EEG streaming through BrainFlow without ALS-PT19 / photodiode timing setup.

Version 1.1 brings the EEG-only route to diagnostic parity with the ALS bridge: reconstructed per-sample timestamps, separately preserved device timestamps, missing/duplicate/out-of-order packet counts, bounded-buffer backlog, run UUID provenance, preserved non-finite values, and an always-written final acquisition-QC JSON.

## What it streams

```text
obci_eeg1
  EEG stream from OpenBCI Cyton or Cyton+Daisy

OpenBCIStatusMarkers
  bridge status / heartbeat markers
```

## What it deliberately does not stream

```text
ALS_PT19_Timing
OpenBCIAnalogAux
photodiode / light-sensor timing
Cyton analog AUX mode
```

This is the KISS home version. It is useful for getting people started, teaching the protocol, and collecting lower-burden pilot data. It is not the full metrological version of PR-AYC-G.

## Install on Windows

Use Python 3.11 or 3.12.

```bat
cd C:\PRAYCG\PRAYCG_BrainFlow_EEGOnly_LSL_Bridge_v1_1
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_brainflow_eeg_only_v1_1.txt
python scripts\praycg_check_install_eeg_only_v1_1.py
```

If `py -3.11` is not available, use:

```bat
py -3.12 -m venv .venv
```

## Find the OpenBCI COM port

Close the OpenBCI GUI first. Only one program can own the OpenBCI serial port at a time.

```bat
python scripts\praycg_identify_openbci_port_eeg_only_v1_1.py --watch
```

## Run with Cyton+Daisy

Replace `COM3` with your actual port.

```bat
python scripts\praycg_openbci_brainflow_eeg_to_lsl_v1_1.py ^
  --board cyton-daisy ^
  --serial-port COM3 ^
  --stream-name obci_eeg1 ^
  --confirmed-channel-map ^
  --stats-json logs\eegonly_stats.json
```

## Run with plain Cyton

```bat
python scripts\praycg_openbci_brainflow_eeg_to_lsl_v1_1.py ^
  --board cyton ^
  --serial-port COM3 ^
  --stream-name obci_eeg1
```

## Test with synthetic board

```bat
python scripts\praycg_openbci_brainflow_eeg_to_lsl_v1_1.py ^
  --board synthetic ^
  --stream-name obci_eeg1 ^
  --duration 30
```

## Confirm LSL streams

In another terminal:

```bat
python scripts\praycg_list_lsl_streams_v1_1.py
```

Expected:

```text
obci_eeg1
OpenBCIStatusMarkers
```

## Watchdog test

```bat
python scripts\praycg_eeg_lsl_watchdog_v1_1.py --stream-name obci_eeg1 --duration 120
```

For the integrated path, use **Connect & Check Equipment → 2. Hardware Profile** to choose an EEG-only profile. Then, in **3. Connect & Launch**, click **Start New Equipment Session** before **Start BrainFlow EEG Only**. The visible active-session indicator confirms the UUID passed to the bridge so the outlet and resulting evidence belong to the current run.

Use **4. Live Checks → Open Live Stream Monitor** for the actual delivery rate and rolling per-channel quality/contact proxy. Then use **5. Monitor, Record & Arm → Run Required 30-Second Equipment Check**. The profile-aware check evaluates the declared EEG stream, run-bound identity, effective sample rate, timestamp order/gaps, channel count, flatness, and explicitly reports checks that were not performed. Because the active profile is EEG-only, it neither requires nor claims ALS pulse evidence.

The profile preflight and EEG diagnostics are evidence inputs to readiness and the combined session lock. They never independently arm or launch the runner. After review, the operator must create the session lock and explicitly click **Arm Acquisition Session**. Artifacts are retained under `logs\protocol_runs\<run_uuid>\`; a new UUID or Control Center process invalidates prior run authority.

## LabRecorder

Select at least:

```text
obci_eeg1
OpenBCIStatusMarkers
StasisMarkers
PolarHRV, if used
VernierRespirationBelt, if used
```

## Boundary

This EEG-only bridge is a lower-burden acquisition route. It does not physically validate screen onset. The ALS-enabled bridge remains the recommended path for timing-critical TSC-grade runs.
