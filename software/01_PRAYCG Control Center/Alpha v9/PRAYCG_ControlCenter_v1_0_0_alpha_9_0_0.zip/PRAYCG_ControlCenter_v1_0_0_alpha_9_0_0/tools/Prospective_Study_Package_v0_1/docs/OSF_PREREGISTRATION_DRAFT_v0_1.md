# PRAYCG Prospective CAI/SID Protocol — OSF Preregistration Draft v0.1

**Status:** DRAFT — NOT REGISTERED — NOT YET COLLECTION-READY  
**Author:** Hoyt Banks  
**Contact:** hoytbanks@gmail.com  
**OSF project:** 8n75v — https://osf.io/8n75v/  
**Public code repository:** https://github.com/hbanks87/praycg-open

## Research boundary

The Controlled Access-Integration Index (CAI) is a bounded, unitless signal composite. It is not a probability, direct consciousness measure, clinical measurement, or proof that narrative meaning was received. CAI/SID v0.2 remains `EXPLORATORY` during this study. DGA, autonomic arrays, and contextual gates remain separate secondary layers and do not enter primary CAI.

## Design

The prospective package supports separately versioned PRAYCG3 and PRAYCG4 modules. Both include Baseline 1, a washout and report after every stimulus branch, Baseline 2/final reflection, and a final report. PRAYCG3 includes PhaseScrambled, Target, and Contextual Override. PRAYCG4 additionally includes ShotOrderScramble. Participant/stimulus assignments use a frozen Williams first-order-balanced schedule; each assigned runner sequence is immutable within a run.

Every stimulus, control derivative, anchor file, runner, protocol manifest, allocation file, and analysis configuration will be hashed before collection. Runner-registered ALS barcode events and the barcode placement script-location test are required. Collection must not begin if the lock manifest reports missing required inputs.

## Candidate primary endpoint

Participant-by-stimulus branch mean `CAI_core` across preregistered valid windows. Invalid hard-QC windows are missing, not zero. Baseline 1 supplies the declared reference normalization. The exact aggregation level and minimum valid coverage must be finalized after blinded feasibility review and before confirmatory outcomes are examined.

## Three primary contrasts

1. Target minus PhaseScrambled.
2. Target minus ShotOrderScramble (PRAYCG4 only).
3. Target minus Contextual Override.

All three contrasts will be reported. Family-wise multiplicity is controlled with Holm’s procedure at two-sided α = .05. Null and reversed results will be published without assigning new post-hoc archetypes.

## Model

The confirmatory model will include participant and stimulus random effects and, where supported by blinded feasibility data, condition random slopes. The frozen formula, optimizer, convergence rule, fallback rule, covariance structure, and residual diagnostics must be inserted here before registration. Condition-specific manual exclusions or lag adjustments are prohibited.

## Exclusions and coverage

Finalize before registration: timestamp-gap tolerance, minimum Baseline 1 rows, branch valid-window coverage, stream coverage, ALS timing tolerance, artifact thresholds, lag windows, null-shift range, treatment of interrupted runs, and rules for protocol deviations. Exclusions must be applied by blinded identifiers and reported with counts and reasons.

## Independent validity outcomes

Recognition, comprehension, their confidence ratings, narrative coherence, and structured subjective meaning are collected independently from the CAI calculation. Held-out criterion validity, test-retest/internal reliability as appropriate, and calibration are evaluated without using these outcomes to retune v0.2.

## Nulls and robustness

Declared circular time-shift and condition-label nulls will be run with frozen seeds and minimum shifts. The pipeline will report timing, artifact, respiratory, order/habituation, attention, afterglow, and high-order structural cautions. These defenses constrain interpretation; passing them does not prove a preferred mechanism.

## Sample-size planning

The final sample size will be selected using blinded feasibility estimates of participant-condition, stimulus-condition, and residual variance. The included simulator uses conservative α/3 planning while the registered inferential analysis uses Holm. Illustrative scenario inputs are not the final determination.

## Versioning and deviations

Operational changes discovered during feasibility create a new prospective candidate version before confirmatory collection. CAI v0.2 will not be tuned against the four historical runs. Any new tuning is a separately named v0.3 development candidate.

## Promotion

CAI/SID remains `EXPLORATORY` unless prospective frozen-pipeline execution, held-out criterion validity, reliability/calibration, and complete bounded/null reporting all pass Gates 7–10. Only then may a future version be considered for `STANDARD_SECONDARY`; this study does not pre-authorize promotion.
