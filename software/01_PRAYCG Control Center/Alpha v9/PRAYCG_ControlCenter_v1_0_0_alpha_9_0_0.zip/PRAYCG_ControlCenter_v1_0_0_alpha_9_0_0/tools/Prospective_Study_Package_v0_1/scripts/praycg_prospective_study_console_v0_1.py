#!/usr/bin/env python3
"""Non-technical console for prospective package preparation and audit tools."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
from pathlib import Path
from tkinter import BOTH, END, LEFT, X, StringVar, Tk, filedialog, messagebox, ttk

import pandas as pd


class App:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.package = Path(__file__).resolve().parents[1]
        self.root.title("PRAYCG Prospective Study Console v0.1")
        self.root.geometry("1080x720")
        self.participant = StringVar(value="P001")
        self.stimulus = StringVar(value="S001")
        self.protocol = StringVar(value="PRAYCG4")
        self._build()

    def _build(self) -> None:
        outer = ttk.Frame(self.root, padding=12); outer.pack(fill=BOTH, expand=True)
        ttk.Label(outer, text="Prospective PRAYCG3 / PRAYCG4 Study Console", font=("Segoe UI", 17, "bold")).pack(anchor="w")
        ttk.Label(outer, text="Preparation and blinded operational checks only. The draft is not registered or collection-ready until real media, anchors, feasibility variance, ethics/consent requirements, and an OSF registration are supplied.", foreground="#8a1c1c", wraplength=1030).pack(anchor="w", pady=(3, 10))

        allocation = ttk.LabelFrame(outer, text="Frozen counterbalance assignment", padding=8); allocation.pack(fill=X)
        for label, var in [("Participant", self.participant), ("Stimulus", self.stimulus), ("Protocol", self.protocol)]:
            ttk.Label(allocation, text=label).pack(side=LEFT, padx=(4, 2)); ttk.Entry(allocation, textvariable=var, width=14).pack(side=LEFT, padx=(0, 8))
        ttk.Button(allocation, text="Show assigned sequence", command=self.show_assignment).pack(side=LEFT, padx=4)
        ttk.Button(allocation, text="Show canonical launch instructions", command=self.open_runner).pack(side=LEFT, padx=4)

        tools = ttk.LabelFrame(outer, text="Preparation and audit actions", padding=8); tools.pack(fill=X, pady=8)
        definitions = [
            ("Regenerate protocol catalog", self.generate_catalog), ("Template hash freeze", self.freeze_template),
            ("Synthetic blinded dry-run", self.synthetic_pilot), ("Illustrative sample simulation", self.sample_sim),
            ("Run promotion audit", self.promotion_audit), ("Open OSF draft", lambda: self.reveal(self.package / "docs" / "OSF_PREREGISTRATION_DRAFT_v0_1.md")),
        ]
        for index, (label, command) in enumerate(definitions):
            ttk.Button(tools, text=label, command=command).grid(row=index // 3, column=index % 3, padx=4, pady=4, sticky="ew")
            tools.columnconfigure(index % 3, weight=1)

        status = ttk.LabelFrame(outer, text="Scientific status", padding=8); status.pack(fill=X)
        ttk.Label(status, text="CAI/SID grade: EXPLORATORY. Autonomic and DGA outputs stay outside primary CAI. Promotion requires affirmative prospective Gates 7–10; missing evidence is not a pass.", wraplength=1030).pack(anchor="w")
        from tkinter import Text
        self.log = Text(outer, wrap="word"); self.log.pack(fill=BOTH, expand=True, pady=(8, 0))
        self.write("Choose an action. Synthetic feasibility records contain operational QC only and deliberately omit condition outcomes.\n")

    def write(self, text: str) -> None:
        self.log.insert(END, text); self.log.see(END)

    def reveal(self, path: Path) -> None:
        try:
            if not path.exists(): raise FileNotFoundError(str(path))
            if os.name == "nt": os.startfile(str(path))  # type: ignore[attr-defined]
            else: subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc: messagebox.showerror("Cannot open", str(exc))

    def run(self, command: list[str]) -> None:
        self.write("\nRunning: " + " ".join(command) + "\n")
        def worker() -> None:
            try:
                process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
                assert process.stdout is not None
                for line in process.stdout: self.root.after(0, self.write, line)
                code = process.wait(); self.root.after(0, self.write, f"Completed with process code {code}.\n")
            except Exception as exc: self.root.after(0, self.write, f"ERROR: {exc}\n")
        threading.Thread(target=worker, daemon=True).start()

    def assigned(self) -> dict | None:
        path = self.package / "config" / "counterbalance_schedule_TEMPLATE_v0_1.csv"
        table = pd.read_csv(path, dtype=str)
        mask = (table.participant_id.str.upper() == self.participant.get().strip().upper()) & (table.stimulus_id.str.upper() == self.stimulus.get().strip().upper()) & (table.base_protocol_id.str.upper() == self.protocol.get().strip().upper())
        if not mask.any():
            messagebox.showwarning("Assignment not found", "No matching template assignment was found. Use IDs such as P001, S001, and PRAYCG3 or PRAYCG4.")
            return None
        return table[mask].iloc[0].to_dict()

    def show_assignment(self) -> None:
        row = self.assigned()
        if row: self.write("\nAssignment:\n" + json.dumps(row, indent=2) + "\n")

    def open_runner(self) -> None:
        row = self.assigned()
        if not row: return
        self.write(
            "\nCanonical controlled-launch boundary:\n"
            f"Assigned protocol: {row['assigned_protocol_id']}\n"
            f"Assigned sequence: {row.get('sequence', row.get('assigned_sequence', 'see assignment record'))}\n"
            "This console does not open a runner directly. Convert or select the assigned declarative "
            "protocol in Control Center > Protocol Atlas / Runner, complete human review and approval, "
            "create a fresh acquisition session lock, arm it, and launch with the Control Center. "
            "The shared engine rejects an unbound direct launch.\n"
        )

    def generate_catalog(self) -> None:
        self.run([sys.executable, str(self.package / "scripts" / "generate_counterbalanced_protocols_v0_1.py"), "--package-root", str(self.package)])

    def freeze_template(self) -> None:
        out = self.package / "validation" / "template_freeze_manifest_v0_1.json"
        self.run([sys.executable, str(self.package / "scripts" / "freeze_study_package_v0_1.py"), "--study-config", str(self.package / "config" / "prospective_study_config_TEMPLATE_v0_1.json"), "--out", str(out), "--template-only"])

    def synthetic_pilot(self) -> None:
        out = self.package / "examples" / "synthetic_feasibility_dry_run"
        self.run([sys.executable, str(self.package / "scripts" / "feasibility_pilot_audit_v0_1.py"), "--make-synthetic", "--out", str(out)])

    def sample_sim(self) -> None:
        out = self.package / "examples" / "illustrative_sample_size_scenarios"
        self.run([sys.executable, str(self.package / "scripts" / "simulate_sample_size_v0_1.py"), "--variance-input", str(self.package / "config" / "feasibility_variance_INPUT_TEMPLATE_v0_1.json"), "--out", str(out)])

    def promotion_audit(self) -> None:
        out = self.package / "validation" / "promotion_audit"
        self.run([sys.executable, str(self.package / "scripts" / "prospective_promotion_audit_v0_1.py"), "--evidence", str(self.package / "config" / "promotion_evidence_INPUT_TEMPLATE_v0_1.json"), "--out", str(out)])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--control-context-file"); parser.parse_args()
    root = Tk(); App(root); root.mainloop(); return 0


if __name__ == "__main__": raise SystemExit(main())
