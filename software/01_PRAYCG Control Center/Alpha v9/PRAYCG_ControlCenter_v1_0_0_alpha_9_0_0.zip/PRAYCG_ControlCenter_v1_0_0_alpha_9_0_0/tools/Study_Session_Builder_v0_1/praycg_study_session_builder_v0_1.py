#!/usr/bin/env python3
"""Prepare and lock a staged PRAYCG runtime session.

The component retains alpha.2-named compatibility schemas while the current
host release and operator boundary are supplied by the Control Center.

Live and post-lock gates are deliberately owned by the Control Center and the
authorized runner process; this public utility cannot advance them.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE_ROOT / "platform_core"))
from praycg_platform_core_v1_0_alpha_2 import (  # noqa: E402
    build_session_draft,
    build_session_lock,
    load_json,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Study/Session Builder v0.2 (current Control Center host; compatible carried gate schemas)")
    parser.add_argument(
        "action",
        nargs="?",
        default="prepare",
        choices=("prepare", "lock"),
    )
    parser.add_argument("--template", type=Path)
    parser.add_argument("--protocol-snapshot", "--protocol-lock", dest="protocol_snapshot", type=Path)
    parser.add_argument("--hardware-profile", type=Path)
    parser.add_argument("--session-draft", type=Path)
    parser.add_argument("--preflight", type=Path)
    parser.add_argument("--operator", default="UNRECORDED")
    parser.add_argument("--allow-caution-override", action="store_true")
    parser.add_argument("--override-reason", default="")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.action == "prepare":
        if not all((args.template, args.protocol_snapshot, args.hardware_profile)):
            parser.error("prepare requires --template, --protocol-snapshot, and --hardware-profile")
        result = build_session_draft(
            load_json(args.template),
            load_json(args.protocol_snapshot),
            load_json(args.hardware_profile),
            args.out,
            protocol_snapshot_path=args.protocol_snapshot,
            hardware_profile_path=args.hardware_profile,
        )
        success = result["status"] == "READY_TO_CONNECT"
    elif args.action == "lock":
        if not args.session_draft or not args.preflight:
            parser.error("lock requires --session-draft and --preflight")
        result = build_session_lock(
            load_json(args.session_draft),
            load_json(args.preflight),
            args.out,
            operator=args.operator,
            allow_caution_override=args.allow_caution_override,
            override_reason=args.override_reason,
        )
        success = result["status"] == "LOCKED_READY_TO_ARM"
    print(json.dumps(result, indent=2))
    return 0 if success else 3


if __name__ == "__main__":
    raise SystemExit(main())
