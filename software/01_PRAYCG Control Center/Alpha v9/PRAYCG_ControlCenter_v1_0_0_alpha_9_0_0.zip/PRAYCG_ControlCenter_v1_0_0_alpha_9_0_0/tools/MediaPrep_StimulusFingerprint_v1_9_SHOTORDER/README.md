# PRAYCG MediaPrep / Stimulus Fingerprint v1.9 ShotOrder

This remains the current v1.9 media-preparation component bundled with **PRAYCG Control Center v1.0.0-alpha.4**. The component version records lineage. In the consolidated interface, media selection and preparation belong to **Stimulus Forge / Library**, which can prefill the GUI's master MP4, output root, and project name; generation still requires an explicit Run click and operator review.

The **Launch MediaPrep** action in **Stimulus Forge / Library** opens `scripts/run_PRAYCG_MediaPrep_v1_8.py`, which starts the current MediaPrep GUI and includes the stable audio-stack fixes. The v1.9 ShotOrder workflow is provided by `scripts/praycg_shot_order_scramble_control_v1_9.py` and is also available from the Control Center.

The scripts retained here support media preparation, stimulus fingerprints, anchor locking, embedded ALS barcode backup, CET/EET processing, post-processing, and ShotOrder control. After generation, inspect the derivative, cue schedule, manifests, and hashes; make the correct registered stimulus active before protocol approval and session locking. Auto-detected filenames are candidates, not proof that a file has the intended content.

MediaPrep prepares media and quality-control artifacts. It does not arm or launch the runner and does not certify physiology, meaning, an endpoint, or a biological mechanism. Do not include copyrighted media in a public redistribution unless you have permission.
