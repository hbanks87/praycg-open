#!/usr/bin/env python3
"""Loss-conscious PRAYCG export to BIDS-shaped EEG/physiology derivatives.

XDF is retained as the source record. BrainVision export is attempted only when
pyxdf, MNE, MNE-BIDS, and a regular EEG stream are available. Irregular RR
events are never silently interpolated into a regular waveform.
"""
from __future__ import annotations

import argparse
import csv
import gzip
import json
import math
import shutil
import sys
from pathlib import Path
from typing import Any, Iterable

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE_ROOT / "platform_core"))
from praycg_platform_core_v1_0_alpha_2 import sha256_file, utc_now, write_json  # noqa: E402


def read_rows(path: Path) -> list[dict[str, str]]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_tsv(path: Path, rows: Iterable[dict[str, Any]], fields: list[str], *, gzip_output: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if gzip_output else open
    kwargs = {"encoding": "utf-8", "newline": ""}
    with opener(path, "wt", **kwargs) if gzip_output else opener(path, "w", **kwargs) as handle:  # type: ignore[arg-type]
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", extrasaction="ignore", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def normalized_events(rows: list[dict[str, str]]) -> tuple[list[dict[str, Any]], list[str]]:
    output: list[dict[str, Any]] = []
    warnings: list[str] = []
    for index, row in enumerate(rows):
        onset_raw = row.get("onset") or row.get("time") or row.get("timestamp") or row.get("lsl_timestamp")
        name = row.get("trial_type") or row.get("event_name") or row.get("marker") or row.get("event")
        try:
            onset = float(str(onset_raw))
        except (TypeError, ValueError):
            warnings.append(f"event row {index + 2} omitted: no numeric onset")
            continue
        duration_raw = row.get("duration", "0")
        try:
            duration = max(0.0, float(duration_raw or 0))
        except ValueError:
            duration = 0.0
            warnings.append(f"event row {index + 2}: invalid duration replaced with 0 and flagged")
        output.append({
            "onset": onset,
            "duration": duration,
            "trial_type": name or "UNNAMED_EVENT",
            "value": row.get("value") or row.get("payload") or "n/a",
            "block_instance_id": row.get("block_instance_id") or "n/a",
            "timing_status": row.get("timing_status") or "SOURCE_REPORTED",
        })
    output.sort(key=lambda item: item["onset"])
    return output, warnings


def export_regular_physio(source: Path, target: Path, sidecar: Path) -> dict[str, Any]:
    rows = read_rows(source)
    if len(rows) < 2:
        return {"status": "INELIGIBLE", "reason": "fewer than two samples"}
    time_key = next((key for key in ("time", "timestamp", "seconds", "lsl_timestamp") if key in rows[0]), None)
    if not time_key:
        return {"status": "INELIGIBLE", "reason": "no time column"}
    times: list[float] = []
    for row in rows:
        try:
            times.append(float(row[time_key]))
        except (TypeError, ValueError):
            return {"status": "INELIGIBLE", "reason": "non-numeric time value"}
    deltas = [b - a for a, b in zip(times, times[1:])]
    if not all(delta > 0 for delta in deltas):
        return {"status": "INELIGIBLE", "reason": "timestamps are not strictly increasing"}
    median_delta = sorted(deltas)[len(deltas) // 2]
    max_fractional_deviation = max(abs(delta - median_delta) / median_delta for delta in deltas) if median_delta > 0 else math.inf
    if max_fractional_deviation > 0.05:
        return {"status": "INELIGIBLE", "reason": "timestamps are not regular within 5%; export as irregular events or resample in a declared derivative"}
    channels = [key for key in rows[0] if key != time_key]
    write_tsv(target, ({key: row.get(key, "n/a") for key in channels} for row in rows), channels, gzip_output=True)
    meta = {
        "SamplingFrequency": 1.0 / median_delta,
        "StartTime": times[0],
        "Columns": channels,
        "SourceFile": source.name,
        "SourceSHA256": sha256_file(source),
    }
    write_json(sidecar, meta)
    return {"status": "PASS", "samples": len(rows), "sampling_frequency": meta["SamplingFrequency"], "columns": channels}


def export_rr_events(source: Path, target: Path, sidecar: Path) -> dict[str, Any]:
    rows = read_rows(source)
    time_key = next((key for key in ("onset", "time", "timestamp", "lsl_timestamp") if rows and key in rows[0]), None)
    rr_key = next((key for key in ("rr_interval", "rr_seconds", "rr_ms", "ibi") if rows and key in rows[0]), None)
    if not time_key or not rr_key:
        return {"status": "INELIGIBLE", "reason": "RR file requires onset/time and rr_interval/rr_seconds/rr_ms/ibi columns"}
    out: list[dict[str, Any]] = []
    previous = -math.inf
    units = "ms" if rr_key == "rr_ms" else "s"
    for index, row in enumerate(rows):
        try:
            onset = float(row[time_key])
            rr = float(row[rr_key])
        except (TypeError, ValueError):
            return {"status": "INELIGIBLE", "reason": f"non-numeric RR row {index + 2}"}
        if onset <= previous:
            return {"status": "INELIGIBLE", "reason": "RR event timestamps are not strictly increasing"}
        previous = onset
        out.append({"onset": onset, "duration": 0, "trial_type": "cardiac_beat", "rr_interval": rr, "interpolated": row.get("interpolated", "false")})
    fields = ["onset", "duration", "trial_type", "rr_interval", "interpolated"]
    write_tsv(target, out, fields, gzip_output=True)
    write_json(sidecar, {
        "Columns": fields,
        "rr_interval": {"Units": units, "Description": "Irregular source beat interval; not resampled by the exporter."},
        "interpolated": {"Description": "Whether the source marked this beat value as interpolated."},
        "SourceFile": source.name,
        "SourceSHA256": sha256_file(source),
        "BIDSCompatibilityNote": "The physioevents representation follows the event-style physiology extension available in current BIDS; validate with the project-selected BIDS Validator version.",
    })
    return {"status": "PASS", "events": len(out), "units": units, "resampled": False}


def export_xdf_eeg_brainvision(xdf_path: Path, bids_root: Path, subject: str, session: str, task: str) -> dict[str, Any]:
    try:
        import numpy as np
        import mne
        import pyxdf
        from mne_bids import BIDSPath, write_raw_bids
    except Exception as exc:
        return {"status": "UNAVAILABLE", "reason": f"optional XDF/BrainVision dependencies unavailable: {type(exc).__name__}: {exc}"}
    streams, _header = pyxdf.load_xdf(str(xdf_path), dejitter_timestamps=False)
    candidates = []
    for stream in streams:
        info = stream.get("info", {})
        stype = str((info.get("type") or [""])[0]).lower()
        srate = float((info.get("nominal_srate") or [0])[0] or 0)
        series = np.asarray(stream.get("time_series"))
        if series.ndim == 2 and srate > 0 and (stype == "eeg" or series.shape[1] >= 8):
            candidates.append((series.shape[1], stream, srate))
    if not candidates:
        return {"status": "INELIGIBLE", "reason": "no regular EEG-like XDF stream found"}
    _count, stream, srate = sorted(candidates, key=lambda item: item[0], reverse=True)[0]
    data = np.asarray(stream["time_series"], dtype=float).T
    labels = [f"EEG{index + 1:02d}" for index in range(data.shape[0])]
    try:
        channels = stream["info"]["desc"][0]["channels"][0]["channel"]
        parsed = [str(item.get("label", [""])[0]) for item in channels]
        if len(parsed) >= len(labels) and all(parsed[:len(labels)]):
            labels = parsed[:len(labels)]
    except Exception:
        pass
    info = mne.create_info(labels, sfreq=srate, ch_types=["eeg"] * len(labels))
    raw = mne.io.RawArray(data * 1e-6, info, verbose="ERROR")
    bids_path = BIDSPath(subject=subject, session=session, task=task, datatype="eeg", root=bids_root)
    try:
        write_raw_bids(raw, bids_path=bids_path, format="BrainVision", allow_preload=True, overwrite=True, verbose=False)
    except Exception as exc:
        return {"status": "INELIGIBLE", "reason": f"BrainVision write failed: {type(exc).__name__}: {exc}"}
    return {"status": "PASS", "channels": len(labels), "sampling_frequency": srate, "format": "BrainVision"}


def main() -> int:
    parser = argparse.ArgumentParser(description="PRAYCG BIDS Exporter v0.1")
    parser.add_argument("--run-folder", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--subject", default="001")
    parser.add_argument("--session", default="01")
    parser.add_argument("--task", default="praycg")
    parser.add_argument("--events-csv", type=Path)
    parser.add_argument("--physio-csv", type=Path)
    parser.add_argument("--rr-csv", type=Path)
    parser.add_argument("--xdf", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    run_folder = args.run_folder.resolve()
    out = args.out.resolve()
    prefix = f"sub-{args.subject}_ses-{args.session}_task-{args.task}"
    eeg_dir = out / f"sub-{args.subject}" / f"ses-{args.session}" / "eeg"
    func_dir = out / f"sub-{args.subject}" / f"ses-{args.session}" / "func"
    sourcedata = out / "sourcedata" / f"sub-{args.subject}" / f"ses-{args.session}"
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "dataset_description.json", {"Name": "PRAYCG Export", "BIDSVersion": "1.11.1", "DatasetType": "raw", "GeneratedBy": [{"Name": "PRAYCG BIDS Exporter", "Version": "0.1.0"}]})
    (out / "README").write_text("PRAYCG standards export. XDF remains the provenance source; derived regular and irregular physiology representations are explicitly separated.\n", encoding="utf-8")
    report: dict[str, Any] = {"schema": "PRAYCG_BIDSExportReport_v0_1", "generated_utc": utc_now(), "dry_run": args.dry_run, "source_run_folder": str(run_folder), "outputs": {}, "warnings": []}
    if args.events_csv and args.events_csv.is_file():
        rows, warnings = normalized_events(read_rows(args.events_csv))
        report["warnings"].extend(warnings)
        if not args.dry_run:
            write_tsv(eeg_dir / f"{prefix}_events.tsv", rows, ["onset", "duration", "trial_type", "value", "block_instance_id", "timing_status"])
        report["outputs"]["events"] = {"status": "PASS" if rows else "INELIGIBLE", "rows": len(rows), "source_sha256": sha256_file(args.events_csv)}
    if args.physio_csv and args.physio_csv.is_file():
        report["outputs"]["regular_physio"] = {"status": "DRY_RUN_NOT_WRITTEN"} if args.dry_run else export_regular_physio(args.physio_csv, func_dir / f"{prefix}_physio.tsv.gz", func_dir / f"{prefix}_physio.json")
    if args.rr_csv and args.rr_csv.is_file():
        report["outputs"]["rr_events"] = {"status": "DRY_RUN_NOT_WRITTEN", "resampled": False} if args.dry_run else export_rr_events(args.rr_csv, func_dir / f"{prefix}_physioevents.tsv.gz", func_dir / f"{prefix}_physioevents.json")
    if args.xdf and args.xdf.is_file():
        report["outputs"]["xdf_source"] = {"status": "REFERENCED_ONLY" if args.dry_run else "COPIED", "sha256": sha256_file(args.xdf)}
        if not args.dry_run:
            sourcedata.mkdir(parents=True, exist_ok=True)
            shutil.copy2(args.xdf, sourcedata / args.xdf.name)
            report["outputs"]["eeg_brainvision"] = export_xdf_eeg_brainvision(args.xdf, out, args.subject, args.session, args.task)
    report["status"] = "PASS" if report["outputs"] and all(value.get("status") not in {"INELIGIBLE"} for value in report["outputs"].values()) else "CAUTION"
    write_json(out / "praycg_export_report.json", report)
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
