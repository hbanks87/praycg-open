# PRAYCG BIDS Exporter v0.1

This exporter treats XDF as the source record and produces a standards-facing representation with hashes and an export report. When the optional XDF/MNE/MNE-BIDS stack is installed, regular EEG is written in BrainVision format. Runner events are written as events tables. Regular physiology is exported only if timestamps are monotonic and regular within the declared tolerance. RR intervals remain irregular beat events and are never silently interpolated.

The internal structural check is not a substitute for the external BIDS Validator. The release reports whether that validator was actually available and run.
