#!/usr/bin/env python3
"""Validate the packaged, non-authoritative exploratory-analysis catalog.

Descriptors are metadata for discovery and compatibility review.  They cannot
grant primary-analysis status, Master Suite eligibility, canonical gate
authority, or acquisition/runtime authority.
"""
from __future__ import annotations

import argparse
import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Iterable, Mapping


DESCRIPTOR_SCHEMA = "PRAYCG_ExploratoryAnalysisModuleDescriptor_v0_1"
CATALOG_SCHEMA = "PRAYCG_ExploratoryAnalysisModuleCatalog_v0_1"
CLASSIFICATION = "EXPLORATORY_ANALYSIS_MODULE"
CATALOG_CLASSIFICATION = "NON_AUTHORITATIVE_EXPLORATORY_ANALYSIS_CATALOG"
MATURITY_LEVELS = frozenset({"ALPHA_EXPLORATORY", "FROZEN_EXPLORATORY_CANDIDATE"})
EVIDENCE_GRADES = frozenset({
    "SYNTHETIC_SOFTWARE_ONLY",
    "RETROSPECTIVE_EXPLORATORY",
    "RETROSPECTIVE_EXPLORATORY_WITH_SYNTHETIC_SOFTWARE_TEST",
})
OUTPUT_KINDS = frozenset({"CSV_TABLE", "JSON_REPORT", "MARKDOWN_REPORT", "PNG_FIGURE", "OUTPUT_DIRECTORY"})
ARTIFACT_KINDS = frozenset({
    "RUN_DIRECTORY",
    "ANALYSIS_DIRECTORY",
    "XDF_RECORDING",
    "EVENT_TABLE",
    "SEGMENT_TABLE",
    "FEATURE_TABLE",
    "CARDIAC_EVENT_TABLE",
    "RESPIRATION_TABLE",
    "TIMING_EVIDENCE",
})
MODULE_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
VERSION_RE = re.compile(r"^[0-9]+\.[0-9]+(?:\.[0-9]+)?(?:-[a-z0-9][a-z0-9.-]*)?$")
PACKAGE_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")

DESCRIPTOR_FIELDS = frozenset({
    "schema",
    "module_id",
    "module_version",
    "display_name",
    "description",
    "classification",
    "maturity",
    "evidence_grade",
    "entry_point",
    "accepted_protocols",
    "signal_roles",
    "inputs",
    "outputs",
    "dependencies",
    "primary_authority",
    "master_suite_eligibility_effect",
    "primary_conclusion_effect",
    "canonical_gate_effect",
    "runtime_authority",
    "claims",
})
CATALOG_FIELDS = frozenset({
    "schema",
    "catalog_id",
    "catalog_version",
    "classification",
    "descriptor_paths",
    "primary_authority",
    "master_suite_eligibility_effect",
    "primary_conclusion_effect",
    "canonical_gate_effect",
    "runtime_authority",
    "boundary",
})


def _packaged_paths() -> tuple[Path, Path, Path]:
    package_root = Path(__file__).resolve().parents[3]
    library_root = package_root / "tools" / "Analysis_ModuleLibrary_v0_1"
    catalog_path = library_root / "catalog" / "analysis_module_catalog_v0_1.json"
    return package_root, library_root, catalog_path


def _load_json_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path.name} must contain one JSON object")
    return payload


def _duplicates(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    repeated: set[str] = set()
    for value in values:
        if value in seen:
            repeated.add(value)
        seen.add(value)
    return sorted(repeated)


def _require_exact_fields(
    payload: Mapping[str, Any],
    allowed: frozenset[str],
    required: frozenset[str],
    context: str,
    errors: list[str],
) -> None:
    missing = sorted(required - set(payload))
    unexpected = sorted(set(payload) - allowed)
    if missing:
        errors.append(f"{context} is missing required fields: {', '.join(missing)}")
    if unexpected:
        errors.append(f"{context} contains unsupported fields: {', '.join(unexpected)}")


def _nonempty_text(value: Any, label: str, errors: list[str]) -> str:
    text = str(value).strip() if isinstance(value, str) else ""
    if not text:
        errors.append(f"{label} must be a nonempty string")
    return text


def _string_list(value: Any, label: str, errors: list[str], *, allow_empty: bool = False) -> list[str]:
    if not isinstance(value, list) or (not value and not allow_empty):
        errors.append(f"{label} must be {'a' if allow_empty else 'a nonempty'} list of unique nonempty strings")
        return []
    result: list[str] = []
    for index, item in enumerate(value):
        text = _nonempty_text(item, f"{label}[{index}]", errors)
        if text:
            result.append(text)
    repeated = _duplicates(result)
    if repeated:
        errors.append(f"{label} repeats values: {', '.join(repeated)}")
    return result


def _contained_relative_path(
    base: Path,
    value: Any,
    label: str,
    errors: list[str],
    *,
    must_exist: bool,
    require_file: bool = False,
) -> Path | None:
    text = _nonempty_text(value, label, errors)
    if not text:
        return None
    relative = Path(text)
    if relative.is_absolute() or relative.anchor or ".." in relative.parts:
        errors.append(f"{label} must be a relative path without traversal")
        return None
    base_resolved = base.resolve(strict=False)
    candidate = (base_resolved / relative).resolve(strict=False)
    try:
        candidate.relative_to(base_resolved)
    except ValueError:
        errors.append(f"{label} resolves outside {base_resolved}")
        return None
    if must_exist and not candidate.exists():
        errors.append(f"{label} does not exist: {text}")
    elif require_file and candidate.exists() and not candidate.is_file():
        errors.append(f"{label} must resolve to a file: {text}")
    return candidate


def _supported_roles(package_root: Path) -> set[str]:
    path = package_root / "config" / "canonical_signal_roles_v1_0_alpha_2.json"
    payload = _load_json_object(path)
    roles = payload.get("roles")
    if not isinstance(roles, dict) or not roles:
        raise ValueError("The canonical signal-role registry is missing or malformed")
    return {str(role).strip() for role in roles if str(role).strip()}


def _known_protocol_ids(package_root: Path) -> set[str]:
    roots = (
        package_root / "tools" / "ProtocolRunner_ModuleLibrary_v1_0" / "protocols",
        package_root / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0" / "protocols",
    )
    result: set[str] = set()
    for root in roots:
        for path in sorted(root.glob("*.json")):
            if "schema" in path.name.casefold():
                continue
            try:
                payload = _load_json_object(path)
            except (OSError, ValueError, json.JSONDecodeError):
                continue
            protocol_id = payload.get("protocol_id")
            if isinstance(protocol_id, str) and protocol_id.strip():
                result.add(protocol_id.strip())
    return result


def _validate_authority_boundary(payload: Mapping[str, Any], context: str, errors: list[str]) -> None:
    if payload.get("primary_authority") is not False:
        errors.append(f"{context}.primary_authority must be false")
    for field in ("master_suite_eligibility_effect", "primary_conclusion_effect", "canonical_gate_effect", "runtime_authority"):
        if payload.get(field) != "NONE":
            errors.append(f"{context}.{field} must be NONE")


def validate_descriptor(
    payload: Mapping[str, Any],
    *,
    package_root: Path,
    library_root: Path,
    descriptor_path: Path | None = None,
    supported_roles: set[str] | None = None,
    known_protocol_ids: set[str] | None = None,
) -> dict[str, Any]:
    """Validate one descriptor without importing or executing its entry point."""
    errors: list[str] = []
    warnings: list[str] = []
    context = descriptor_path.name if descriptor_path is not None else "descriptor"
    _require_exact_fields(payload, DESCRIPTOR_FIELDS, DESCRIPTOR_FIELDS, context, errors)

    if payload.get("schema") != DESCRIPTOR_SCHEMA:
        errors.append(f"{context}.schema must be {DESCRIPTOR_SCHEMA}")
    module_id = _nonempty_text(payload.get("module_id"), f"{context}.module_id", errors)
    if module_id and not MODULE_ID_RE.fullmatch(module_id):
        errors.append(f"{context}.module_id must use lower_snake_case and 3-64 characters")
    version = _nonempty_text(payload.get("module_version"), f"{context}.module_version", errors)
    if version and not VERSION_RE.fullmatch(version):
        errors.append(f"{context}.module_version is not a supported semantic version")
    _nonempty_text(payload.get("display_name"), f"{context}.display_name", errors)
    _nonempty_text(payload.get("description"), f"{context}.description", errors)
    if payload.get("classification") != CLASSIFICATION:
        errors.append(f"{context}.classification must be {CLASSIFICATION}")
    if payload.get("maturity") not in MATURITY_LEVELS:
        errors.append(f"{context}.maturity is unsupported")
    if payload.get("evidence_grade") not in EVIDENCE_GRADES:
        errors.append(f"{context}.evidence_grade is unsupported")
    _validate_authority_boundary(payload, context, errors)

    if descriptor_path is not None:
        descriptor_resolved = descriptor_path.resolve(strict=False)
        try:
            descriptor_resolved.relative_to(library_root.resolve(strict=False))
        except ValueError:
            errors.append(f"{context} is outside the analysis-module library root")

    entry = _contained_relative_path(
        package_root,
        payload.get("entry_point"),
        f"{context}.entry_point",
        errors,
        must_exist=True,
        require_file=True,
    )
    if entry is not None and entry.suffix.casefold() != ".py":
        errors.append(f"{context}.entry_point must identify a packaged Python file")

    accepted = payload.get("accepted_protocols")
    if not isinstance(accepted, dict):
        errors.append(f"{context}.accepted_protocols must be an object")
    else:
        _require_exact_fields(
            accepted,
            frozenset({"mode", "protocol_ids"}),
            frozenset({"mode", "protocol_ids"}),
            f"{context}.accepted_protocols",
            errors,
        )
        if accepted.get("mode") != "EXPLICIT_ALLOWLIST":
            errors.append(f"{context}.accepted_protocols.mode must be EXPLICIT_ALLOWLIST")
        protocol_ids = _string_list(
            accepted.get("protocol_ids"),
            f"{context}.accepted_protocols.protocol_ids",
            errors,
        )
        if known_protocol_ids is not None:
            unknown = sorted(set(protocol_ids) - known_protocol_ids)
            if unknown:
                errors.append(f"{context} accepts unknown protocol IDs: {', '.join(unknown)}")

    roles = payload.get("signal_roles")
    role_registry = supported_roles if supported_roles is not None else _supported_roles(package_root)
    if not isinstance(roles, dict):
        errors.append(f"{context}.signal_roles must be an object")
    else:
        _require_exact_fields(
            roles,
            frozenset({"accepted_role_sets", "optional_roles"}),
            frozenset({"accepted_role_sets", "optional_roles"}),
            f"{context}.signal_roles",
            errors,
        )
        alternatives = roles.get("accepted_role_sets")
        required_roles: set[str] = set()
        if not isinstance(alternatives, list) or not alternatives:
            errors.append(f"{context}.signal_roles.accepted_role_sets must be a nonempty list")
        else:
            normalized_sets: list[tuple[str, ...]] = []
            for index, alternative in enumerate(alternatives):
                values = _string_list(
                    alternative,
                    f"{context}.signal_roles.accepted_role_sets[{index}]",
                    errors,
                )
                required_roles.update(values)
                normalized_sets.append(tuple(sorted(values)))
            repeated_sets = _duplicates(["|".join(value) for value in normalized_sets])
            if repeated_sets:
                errors.append(f"{context}.signal_roles.accepted_role_sets repeats an alternative")
        optional_roles = set(_string_list(
            roles.get("optional_roles"),
            f"{context}.signal_roles.optional_roles",
            errors,
            allow_empty=True,
        ))
        unknown_roles = sorted((required_roles | optional_roles) - role_registry)
        if unknown_roles:
            errors.append(f"{context} declares unsupported signal roles: {', '.join(unknown_roles)}")
        overlap = sorted(required_roles & optional_roles)
        if overlap:
            errors.append(f"{context} repeats required roles as optional: {', '.join(overlap)}")

    inputs = payload.get("inputs")
    if not isinstance(inputs, dict):
        errors.append(f"{context}.inputs must be an object")
    else:
        _require_exact_fields(
            inputs,
            frozenset({"required_artifact_kinds", "optional_artifact_kinds"}),
            frozenset({"required_artifact_kinds", "optional_artifact_kinds"}),
            f"{context}.inputs",
            errors,
        )
        required_inputs = set(_string_list(inputs.get("required_artifact_kinds"), f"{context}.inputs.required_artifact_kinds", errors))
        optional_inputs = set(_string_list(inputs.get("optional_artifact_kinds"), f"{context}.inputs.optional_artifact_kinds", errors, allow_empty=True))
        unsupported_inputs = sorted((required_inputs | optional_inputs) - ARTIFACT_KINDS)
        if unsupported_inputs:
            errors.append(f"{context} declares unsupported artifact kinds: {', '.join(unsupported_inputs)}")
        overlap = sorted(required_inputs & optional_inputs)
        if overlap:
            errors.append(f"{context} repeats required artifacts as optional: {', '.join(overlap)}")

    outputs = payload.get("outputs")
    output_ids: list[str] = []
    if not isinstance(outputs, list) or not outputs:
        errors.append(f"{context}.outputs must be a nonempty list")
    else:
        output_fields = frozenset({"id", "kind", "relative_path", "required", "interpretation"})
        for index, output in enumerate(outputs):
            label = f"{context}.outputs[{index}]"
            if not isinstance(output, dict):
                errors.append(f"{label} must be an object")
                continue
            _require_exact_fields(output, output_fields, output_fields, label, errors)
            output_id = _nonempty_text(output.get("id"), f"{label}.id", errors)
            if output_id:
                output_ids.append(output_id)
                if not MODULE_ID_RE.fullmatch(output_id):
                    errors.append(f"{label}.id must use lower_snake_case")
            if output.get("kind") not in OUTPUT_KINDS:
                errors.append(f"{label}.kind is unsupported")
            _contained_relative_path(Path("."), output.get("relative_path"), f"{label}.relative_path", errors, must_exist=False)
            if not isinstance(output.get("required"), bool):
                errors.append(f"{label}.required must be boolean")
            _nonempty_text(output.get("interpretation"), f"{label}.interpretation", errors)
        repeated_outputs = _duplicates(output_ids)
        if repeated_outputs:
            errors.append(f"{context}.outputs repeats IDs: {', '.join(repeated_outputs)}")

    dependencies = payload.get("dependencies")
    if not isinstance(dependencies, dict):
        errors.append(f"{context}.dependencies must be an object")
    else:
        dependency_fields = frozenset({"python_packages", "module_ids", "package_paths"})
        _require_exact_fields(dependencies, dependency_fields, dependency_fields, f"{context}.dependencies", errors)
        packages = _string_list(dependencies.get("python_packages"), f"{context}.dependencies.python_packages", errors, allow_empty=True)
        for package in packages:
            if not PACKAGE_NAME_RE.fullmatch(package):
                errors.append(f"{context}.dependencies.python_packages contains an invalid name: {package}")
        module_dependencies = _string_list(dependencies.get("module_ids"), f"{context}.dependencies.module_ids", errors, allow_empty=True)
        if module_id and module_id in module_dependencies:
            errors.append(f"{context} cannot depend on itself")
        package_paths = _string_list(dependencies.get("package_paths"), f"{context}.dependencies.package_paths", errors, allow_empty=True)
        for index, path in enumerate(package_paths):
            _contained_relative_path(
                package_root,
                path,
                f"{context}.dependencies.package_paths[{index}]",
                errors,
                must_exist=True,
            )

    claims = payload.get("claims")
    if not isinstance(claims, dict):
        errors.append(f"{context}.claims must be an object")
    else:
        claim_fields = frozenset({"allowed", "prohibited", "boundary"})
        _require_exact_fields(claims, claim_fields, claim_fields, f"{context}.claims", errors)
        _string_list(claims.get("allowed"), f"{context}.claims.allowed", errors)
        _string_list(claims.get("prohibited"), f"{context}.claims.prohibited", errors)
        _nonempty_text(claims.get("boundary"), f"{context}.claims.boundary", errors)

    return {
        "status": "PASS" if not errors else "FAIL",
        "module_id": module_id or None,
        "errors": errors,
        "warnings": warnings,
    }


def validate_catalog(
    catalog_path: Path,
    *,
    package_root: Path,
    library_root: Path,
) -> dict[str, Any]:
    """Validate a catalog and every descriptor without executing modules."""
    errors: list[str] = []
    modules: list[dict[str, Any]] = []
    try:
        catalog = _load_json_object(catalog_path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        return {"status": "FAIL", "catalog_path": str(catalog_path), "modules": [], "errors": [f"Catalog load failed: {exc}"]}

    _require_exact_fields(catalog, CATALOG_FIELDS, CATALOG_FIELDS, "catalog", errors)
    if catalog.get("schema") != CATALOG_SCHEMA:
        errors.append(f"catalog.schema must be {CATALOG_SCHEMA}")
    if catalog.get("catalog_id") != "praycg_exploratory_analysis_modules":
        errors.append("catalog.catalog_id must be praycg_exploratory_analysis_modules")
    version = _nonempty_text(catalog.get("catalog_version"), "catalog.catalog_version", errors)
    if version and not VERSION_RE.fullmatch(version):
        errors.append("catalog.catalog_version is not a supported semantic version")
    if catalog.get("classification") != CATALOG_CLASSIFICATION:
        errors.append(f"catalog.classification must be {CATALOG_CLASSIFICATION}")
    _validate_authority_boundary(catalog, "catalog", errors)
    _nonempty_text(catalog.get("boundary"), "catalog.boundary", errors)

    descriptor_values = _string_list(catalog.get("descriptor_paths"), "catalog.descriptor_paths", errors)
    role_registry: set[str]
    protocol_registry: set[str]
    try:
        role_registry = _supported_roles(package_root)
        protocol_registry = _known_protocol_ids(package_root)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        errors.append(f"Package registry load failed: {exc}")
        role_registry = set()
        protocol_registry = set()

    for index, relative in enumerate(descriptor_values):
        descriptor_path = _contained_relative_path(
            library_root,
            relative,
            f"catalog.descriptor_paths[{index}]",
            errors,
            must_exist=True,
            require_file=True,
        )
        if descriptor_path is None or not descriptor_path.is_file():
            continue
        try:
            descriptor = _load_json_object(descriptor_path)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            errors.append(f"Descriptor load failed for {relative}: {exc}")
            continue
        result = validate_descriptor(
            descriptor,
            package_root=package_root,
            library_root=library_root,
            descriptor_path=descriptor_path,
            supported_roles=role_registry,
            known_protocol_ids=protocol_registry,
        )
        errors.extend(result["errors"])
        if result["status"] == "PASS":
            row = deepcopy(descriptor)
            row["descriptor_path"] = str(descriptor_path)
            modules.append(row)

    ids = [str(module.get("module_id", "")) for module in modules]
    duplicates = _duplicates(ids)
    if duplicates:
        errors.append(f"Catalog repeats module IDs: {', '.join(duplicates)}")
    known_modules = set(ids)
    for module in modules:
        declared = set(module.get("dependencies", {}).get("module_ids", []))
        missing = sorted(declared - known_modules)
        if missing:
            errors.append(f"{module['module_id']} depends on unregistered module IDs: {', '.join(missing)}")

    return {
        "schema": "PRAYCG_ExploratoryAnalysisCatalogValidation_v0_1",
        "status": "PASS" if not errors else "FAIL",
        "catalog_path": str(catalog_path.resolve(strict=False)),
        "library_root": str(library_root.resolve(strict=False)),
        "module_count": len(modules),
        "modules": modules,
        "errors": errors,
        "authority_boundary": {
            "primary_authority": False,
            "master_suite_eligibility_effect": "NONE",
            "primary_conclusion_effect": "NONE",
            "canonical_gate_effect": "NONE",
            "runtime_authority": "NONE",
        },
    }


def load_packaged_catalog() -> dict[str, Any]:
    """Load only the exact package-owned catalog used for future UI discovery."""
    package_root, library_root, catalog_path = _packaged_paths()
    return validate_catalog(catalog_path, package_root=package_root, library_root=library_root)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Validate the packaged PRAYCG exploratory-analysis catalog")
    parser.add_argument("--json", action="store_true", help="Print the full machine-readable validation record")
    args = parser.parse_args(argv)
    result = load_packaged_catalog()
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"{result['status']}: {result['module_count']} exploratory analysis module descriptors")
        for error in result["errors"]:
            print(f"- {error}")
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())

