# PRAYCG Exploratory Analysis Module Library v0.1

This package is a non-authoritative catalog for reviewed exploratory analysis
modules. It describes compatibility, dependencies, and outputs without changing
the Master Comprehensive Suite, primary endpoints, acquisition authority, or the
canonical workflow gates.

`scripts/praycg_analysis_module_catalog_v0_1.py` validates the packaged catalog
and descriptors. Descriptors are data, not executable plugins: each entry point
must already exist inside this versioned package, and catalog admission never
grants scientific or runtime authority.

