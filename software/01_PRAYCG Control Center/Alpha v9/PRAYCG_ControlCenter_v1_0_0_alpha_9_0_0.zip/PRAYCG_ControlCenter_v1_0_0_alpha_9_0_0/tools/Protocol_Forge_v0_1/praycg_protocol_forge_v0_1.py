#!/usr/bin/env python3
"""Validate, dry-run, and compile PRAYCG protocol modules without custom code."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE_ROOT / "platform_core"))

from praycg_platform_core_v1_0_alpha_2 import (  # noqa: E402
    compile_protocol,
    load_json,
    protocol_timeline,
    validate_protocol,
    write_json,
)


def discover(library: Path) -> list[Path]:
    return sorted((library / "protocols").glob("*.json")) if (library / "protocols").is_dir() else sorted(library.glob("*.json"))


def main() -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Protocol Forge v0.1")
    parser.add_argument("action", choices=("list", "validate", "dry-run", "compile"))
    parser.add_argument("--library", type=Path, default=PACKAGE_ROOT / "tools" / "ProtocolRunner_ModuleLibrary_v1_0")
    parser.add_argument("--module", type=Path)
    parser.add_argument("--out", type=Path, default=Path.cwd() / "protocol_builds")
    parser.add_argument("--reviewed-by", default="UNRECORDED")
    args = parser.parse_args()
    library = args.library.resolve()
    if args.action == "list":
        rows = []
        for path in discover(library):
            try:
                value = load_json(path)
            except Exception:
                continue
            if value.get("schema") == "PRAYCG_ProtocolModule_v1_0":
                rows.append({"protocol_id": value.get("protocol_id"), "version": value.get("protocol_version"), "display_name": value.get("display_name"), "path": str(path)})
        print(json.dumps(rows, indent=2))
        return 0
    if not args.module:
        parser.error("--module is required for validate, dry-run, and compile")
    module_path = args.module.resolve()
    module = load_json(module_path)
    report = validate_protocol(module, library_root=library)
    if args.action == "validate":
        print(json.dumps(report.as_dict(), indent=2))
        return 0 if report.status != "INELIGIBLE" else 2
    if args.action == "dry-run":
        result = report.as_dict()
        result["timeline"] = protocol_timeline(module)
        result["execution"] = "NOT_STARTED"
        result["note"] = "A dry run validates and renders the schedule; it does not launch PsychoPy or acquire data."
        args.out.mkdir(parents=True, exist_ok=True)
        target = args.out / f"{module.get('protocol_id', 'protocol')}_dry_run.json"
        write_json(target, result)
        print(target)
        return 0 if report.status != "INELIGIBLE" else 2
    out, lock = compile_protocol(module_path, library, args.out, human_reviewed_by=args.reviewed_by)
    print(json.dumps({"output": str(out), "lock": lock}, indent=2))
    return 0 if lock["status"] == "APPROVED" else 3


if __name__ == "__main__":
    raise SystemExit(main())
