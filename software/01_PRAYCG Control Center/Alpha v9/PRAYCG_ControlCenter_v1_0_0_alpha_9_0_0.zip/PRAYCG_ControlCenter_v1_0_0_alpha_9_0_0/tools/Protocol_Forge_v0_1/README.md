# PRAYCG Protocol Forge v0.1

Protocol Forge validates and compiles declarative PRAYCG protocol modules for the fixed Protocol Engine v3.0. It does not execute arbitrary code from a draft. A compiled protocol is lockable only when all three validation layers pass and a human reviewer is recorded.

The three layers are structural schema checks, cross-field scientific/operational checks, and a package-boundary check on the existing runner entry. A dry run writes the full timeline without starting PsychoPy.

AI-assisted drafts are permitted only as drafts. Human review, a successful dry run, and a new hash are required before use.
