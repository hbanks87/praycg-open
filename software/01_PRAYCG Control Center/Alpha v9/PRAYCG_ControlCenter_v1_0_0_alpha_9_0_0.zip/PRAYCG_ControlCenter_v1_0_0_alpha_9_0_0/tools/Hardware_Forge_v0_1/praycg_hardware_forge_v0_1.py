#!/usr/bin/env python3
"""Governed adapter catalog and non-authoritative profile drafting for PRAYCG.

The Hardware Forge is intentionally upstream of the reviewed Hardware Registry.
It can describe an adapter, validate staging metadata, and create a profile draft.
It cannot approve hardware, run an unreviewed third-party bridge, issue a session
lock, arm a protocol, or promote simulator evidence to physical-device evidence.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import sys
from typing import Any, Iterable, Mapping


FORGE_ROOT = Path(__file__).resolve().parent
PACKAGE_ROOT = FORGE_ROOT.parents[1]
DEFAULT_CATALOG = PACKAGE_ROOT / "config" / "hardware_adapter_catalog_v0_1.json"
ADAPTER_SCHEMA = "PRAYCG_HardwareAdapterDescriptor_v0_1"
DRAFT_CATALOG_SCHEMA = "PRAYCG_HardwareModuleDraftCatalog_v0_1"
DRAFT_PROFILE_SCHEMA = "PRAYCG_HardwareProfileDraft_v0_2"
HARDWARE_SCHEMA = "PRAYCG_HardwareModule_v0_1"
ADMISSION_STATES = {
    "CATALOG_ONLY", "SIMULATOR_VERIFIED", "BENCH_VERIFIED",
    "HUMAN_CONNECTED_APPROVED", "QUARANTINED",
}
PHYSICAL_STATES = {"NOT_PERFORMED", "BENCH_ONLY", "HUMAN_CONNECTED"}
LAUNCH_STATES = {"WITHHELD", "DIAGNOSTIC_ONLY", "AVAILABLE_ALPHA"}
ROLE_ASSIGNMENTS = {"PRIMARY", "SUPPLEMENTAL", "UNASSIGNED"}
ID_RE = re.compile(r"^[a-z0-9][a-z0-9_]*$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def write_json(path: Path, value: Mapping[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def resolved_within(path: Path, root: Path) -> bool:
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def _catalog_reference(catalog_path: Path, reference: Any) -> Path:
    text = str(reference or "").strip()
    if not text:
        raise ValueError("Catalog reference is empty.")
    candidate = Path(text)
    if candidate.is_absolute():
        raise ValueError(f"Catalog reference must be relative: {text}")
    resolved = (catalog_path.parent / candidate).resolve()
    if not resolved_within(resolved, FORGE_ROOT):
        raise ValueError(f"Catalog reference escapes the Hardware Forge: {text}")
    return resolved


def load_catalog(catalog_path: Path = DEFAULT_CATALOG) -> tuple[dict[str, Any], dict[str, Any]]:
    catalog_path = Path(catalog_path).resolve()
    if not resolved_within(catalog_path, PACKAGE_ROOT):
        raise ValueError("Adapter catalog must be contained in the packaged PRAYCG release.")
    catalog = load_json(catalog_path)
    draft_path = _catalog_reference(catalog_path, catalog.get("module_draft_catalog"))
    drafts = load_json(draft_path)
    return catalog, drafts


def _require(errors: list[str], condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def validate_adapter_descriptor(descriptor: Mapping[str, Any], draft_ids: set[str]) -> list[str]:
    errors: list[str] = []
    adapter_id = str(descriptor.get("adapter_id") or "")
    _require(errors, descriptor.get("schema") == ADAPTER_SCHEMA, f"{adapter_id or '?'}: unsupported descriptor schema")
    _require(errors, bool(ID_RE.fullmatch(adapter_id)), f"{adapter_id or '?'}: invalid adapter_id")
    _require(errors, bool(str(descriptor.get("display_name") or "").strip()), f"{adapter_id or '?'}: display_name is required")
    _require(errors, descriptor.get("category") in {"EEG_EXG", "ARTIFACT_TIMING", "AUTONOMIC", "GENERIC_LSL"}, f"{adapter_id or '?'}: unsupported category")
    admission = descriptor.get("admission_state")
    physical = descriptor.get("physical_validation")
    _require(errors, admission in ADMISSION_STATES, f"{adapter_id or '?'}: unsupported admission_state")
    _require(errors, physical in PHYSICAL_STATES, f"{adapter_id or '?'}: unsupported physical_validation")
    _require(errors, descriptor.get("runtime_authority") is False, f"{adapter_id or '?'}: runtime_authority must be false")
    if admission in {"CATALOG_ONLY", "SIMULATOR_VERIFIED", "QUARANTINED"}:
        _require(errors, physical == "NOT_PERFORMED", f"{adapter_id or '?'}: {admission} cannot claim physical validation")
    if admission == "HUMAN_CONNECTED_APPROVED":
        _require(errors, physical == "HUMAN_CONNECTED", f"{adapter_id or '?'}: human approval requires human-connected evidence")
    archive = descriptor.get("source_archive")
    _require(errors, isinstance(archive, Mapping), f"{adapter_id or '?'}: source_archive is required")
    if isinstance(archive, Mapping):
        filename = str(archive.get("filename") or "")
        _require(errors, bool(filename) and not Path(filename).is_absolute() and Path(filename).name == filename, f"{adapter_id or '?'}: source archive must be a filename, not a path")
        _require(errors, bool(SHA256_RE.fullmatch(str(archive.get("sha256") or ""))), f"{adapter_id or '?'}: source archive SHA-256 must be lowercase hex")
        _require(errors, archive.get("integration_policy") == "METADATA_REVIEW_ONLY_NO_SOURCE_CODE_COPIED", f"{adapter_id or '?'}: unsafe integration policy")
    routes = descriptor.get("routes")
    _require(errors, isinstance(routes, list) and bool(routes), f"{adapter_id or '?'}: at least one route is required")
    route_ids: set[str] = set()
    if isinstance(routes, list):
        for route in routes:
            if not isinstance(route, Mapping):
                errors.append(f"{adapter_id or '?'}: route is not an object")
                continue
            route_id = str(route.get("route_id") or "")
            prefix = f"{adapter_id or '?'}/{route_id or '?'}"
            _require(errors, bool(ID_RE.fullmatch(route_id)), f"{prefix}: invalid route_id")
            _require(errors, route_id not in route_ids, f"{prefix}: duplicate route_id")
            route_ids.add(route_id)
            _require(errors, route.get("launch_state") in LAUNCH_STATES, f"{prefix}: unsupported launch_state")
            _require(errors, str(route.get("draft_module_id") or "") in draft_ids, f"{prefix}: missing draft module")
            defaults = route.get("role_defaults")
            _require(errors, isinstance(defaults, Mapping), f"{prefix}: role_defaults must be an object")
            if isinstance(defaults, Mapping):
                for role, assignment in defaults.items():
                    _require(errors, bool(str(role)), f"{prefix}: empty canonical role")
                    _require(errors, assignment in ROLE_ASSIGNMENTS, f"{prefix}: invalid role assignment {assignment!r}")
            if admission in {"CATALOG_ONLY", "QUARANTINED"}:
                _require(errors, route.get("launch_state") != "AVAILABLE_ALPHA", f"{prefix}: unavailable admission state cannot expose a live launch")
            if admission == "QUARANTINED":
                _require(errors, route.get("launch_state") == "WITHHELD", f"{prefix}: quarantined routes must be withheld")
    _require(errors, bool(str(descriptor.get("claim_boundary") or "").strip()), f"{adapter_id or '?'}: claim_boundary is required")
    return errors


def validate_draft(draft: Mapping[str, Any], canonical_roles: set[str]) -> list[str]:
    errors: list[str] = []
    draft_id = str(draft.get("draft_module_id") or "")
    prefix = draft_id or "?"
    _require(errors, bool(ID_RE.fullmatch(draft_id)), f"{prefix}: invalid draft_module_id")
    _require(errors, draft.get("runtime_authority") is False, f"{prefix}: runtime_authority must be false")
    _require(errors, draft.get("status") in ADMISSION_STATES, f"{prefix}: unsupported draft status")
    _require(errors, draft.get("physical_validation") in PHYSICAL_STATES, f"{prefix}: unsupported physical_validation")
    if draft.get("status") in {"CATALOG_ONLY", "SIMULATOR_VERIFIED", "QUARANTINED"}:
        _require(errors, draft.get("physical_validation") == "NOT_PERFORMED", f"{prefix}: staging draft cannot claim physical validation")
    module = draft.get("proposed_module")
    _require(errors, isinstance(module, Mapping), f"{prefix}: proposed_module is required")
    if not isinstance(module, Mapping):
        return errors
    _require(errors, module.get("schema") == HARDWARE_SCHEMA, f"{prefix}: proposed module schema is not compatible")
    _require(errors, module.get("trust_level") == "COMMUNITY_UNVERIFIED", f"{prefix}: staging modules must be COMMUNITY_UNVERIFIED")
    _require(errors, module.get("managed_recovery", {}).get("enabled_by_default") is False, f"{prefix}: managed recovery must be disabled")
    streams = module.get("streams")
    _require(errors, isinstance(streams, list) and bool(streams), f"{prefix}: at least one proposed stream is required")
    names: set[str] = set()
    if isinstance(streams, list):
        for stream in streams:
            if not isinstance(stream, Mapping):
                errors.append(f"{prefix}: stream is not an object")
                continue
            name = str(stream.get("lsl_name") or "")
            _require(errors, bool(name), f"{prefix}: lsl_name is required")
            _require(errors, name not in names, f"{prefix}: duplicate lsl_name {name}")
            names.add(name)
            _require(errors, stream.get("canonical_role") in canonical_roles, f"{prefix}/{name or '?'}: unsupported canonical role")
            _require(errors, stream.get("role_assignment_default") in ROLE_ASSIGNMENTS, f"{prefix}/{name or '?'}: invalid role assignment default")
            _require(errors, stream.get("source_id_policy") in {"dynamic_run_bound", "connection_specific", "fixed"}, f"{prefix}/{name or '?'}: source identity policy is required")
    return errors


def validate_catalog(catalog_path: Path = DEFAULT_CATALOG) -> dict[str, Any]:
    errors: list[str] = []
    cautions: list[str] = []
    try:
        catalog_path = Path(catalog_path).resolve()
        catalog, draft_catalog = load_catalog(catalog_path)
    except Exception as exc:
        return {"status": "INELIGIBLE", "errors": [f"{type(exc).__name__}: {exc}"], "cautions": [], "adapter_count": 0, "draft_count": 0}
    _require(errors, catalog.get("schema") == "PRAYCG_HardwareAdapterCatalog_v0_1", "Unsupported adapter catalog schema")
    try:
        schema_path = _catalog_reference(catalog_path, catalog.get("descriptor_schema"))
        _require(errors, schema_path.is_file(), "Descriptor schema file is missing")
    except Exception as exc:
        errors.append(f"Descriptor schema reference is invalid: {exc}")
    _require(errors, draft_catalog.get("schema") == DRAFT_CATALOG_SCHEMA, "Unsupported module-draft catalog schema")
    _require(errors, draft_catalog.get("runtime_authority") is False, "Module-draft catalog cannot have runtime authority")
    roles = {str(role) for role in draft_catalog.get("canonical_roles", [])}
    drafts = draft_catalog.get("drafts") if isinstance(draft_catalog.get("drafts"), list) else []
    draft_ids: set[str] = set()
    for draft in drafts:
        if not isinstance(draft, Mapping):
            errors.append("Module draft is not an object")
            continue
        draft_id = str(draft.get("draft_module_id") or "")
        if draft_id in draft_ids:
            errors.append(f"Duplicate draft_module_id: {draft_id}")
        draft_ids.add(draft_id)
        errors.extend(validate_draft(draft, roles))
    adapters = catalog.get("adapters") if isinstance(catalog.get("adapters"), list) else []
    adapter_ids: set[str] = set()
    for descriptor in adapters:
        if not isinstance(descriptor, Mapping):
            errors.append("Adapter descriptor is not an object")
            continue
        adapter_id = str(descriptor.get("adapter_id") or "")
        if adapter_id in adapter_ids:
            errors.append(f"Duplicate adapter_id: {adapter_id}")
        adapter_ids.add(adapter_id)
        errors.extend(validate_adapter_descriptor(descriptor, draft_ids))
    referenced = {
        str(route.get("draft_module_id"))
        for descriptor in adapters if isinstance(descriptor, Mapping)
        for route in descriptor.get("routes", []) if isinstance(route, Mapping)
    }
    unused = sorted(draft_ids - referenced)
    if unused:
        cautions.append("Unreferenced module drafts: " + ", ".join(unused))
    return {
        "schema": "PRAYCG_HardwareForgeValidation_v0_1",
        "generated_utc": utc_now(),
        "status": "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS"),
        "adapter_count": len(adapters),
        "route_count": sum(len(row.get("routes", [])) for row in adapters if isinstance(row, Mapping)),
        "draft_count": len(drafts),
        "errors": errors,
        "cautions": cautions,
        "authority_boundary": catalog.get("authority_boundary"),
    }


def _indexes(catalog: Mapping[str, Any], drafts: Mapping[str, Any]) -> tuple[dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]]]:
    adapter_index = {
        str(row["adapter_id"]): row
        for row in catalog.get("adapters", []) if isinstance(row, Mapping) and row.get("adapter_id")
    }
    draft_index = {
        str(row["draft_module_id"]): row
        for row in drafts.get("drafts", []) if isinstance(row, Mapping) and row.get("draft_module_id")
    }
    return adapter_index, draft_index


def _parse_selection(text: str) -> tuple[str, str]:
    parts = str(text).split(":")
    if len(parts) != 2 or not all(parts):
        raise ValueError(f"Selection must be adapter_id:route_id, got {text!r}")
    return parts[0], parts[1]


def create_draft_profile(
    selections: Iterable[str],
    *,
    profile_id: str,
    primary_overrides: Mapping[str, str] | None = None,
    catalog_path: Path = DEFAULT_CATALOG,
) -> dict[str, Any]:
    validation = validate_catalog(catalog_path)
    if validation["status"] == "INELIGIBLE":
        raise ValueError("Hardware catalog is ineligible: " + "; ".join(validation["errors"]))
    catalog, drafts = load_catalog(catalog_path)
    adapter_index, draft_index = _indexes(catalog, drafts)
    selected_modules: list[dict[str, Any]] = []
    source_rows: list[dict[str, str]] = []
    errors: list[str] = []
    for selection in selections:
        adapter_id, route_id = _parse_selection(selection)
        descriptor = adapter_index.get(adapter_id)
        if descriptor is None:
            raise ValueError(f"Unknown adapter: {adapter_id}")
        route = next((row for row in descriptor.get("routes", []) if row.get("route_id") == route_id), None)
        if route is None:
            raise ValueError(f"Unknown route for {adapter_id}: {route_id}")
        draft = draft_index[str(route["draft_module_id"])]
        module = deepcopy(draft["proposed_module"])
        selected_modules.append({
            "adapter_id": adapter_id,
            "route_id": route_id,
            "admission_state": descriptor["admission_state"],
            "physical_validation": descriptor["physical_validation"],
            "launch_state": route["launch_state"],
            "draft_module_id": draft["draft_module_id"],
            "open_fields": deepcopy(draft.get("open_fields", [])),
            "proposed_module": module,
        })
        if descriptor["admission_state"] == "QUARANTINED":
            errors.append(f"{adapter_id}/{route_id} is quarantined and cannot be promoted without new evidence.")
        for stream in module.get("streams", []):
            role = str(stream.get("canonical_role") or "")
            assignment = str(route.get("role_defaults", {}).get(role) or stream.get("role_assignment_default") or "UNASSIGNED")
            source_rows.append({
                "role": role,
                "source": f"{adapter_id}/{route_id}/{stream.get('lsl_name')}",
                "assignment": assignment,
            })
    if not selected_modules:
        raise ValueError("At least one adapter route is required.")
    overrides = {str(k): str(v) for k, v in (primary_overrides or {}).items()}
    assignments: dict[str, dict[str, Any]] = {}
    for role in sorted({row["role"] for row in source_rows if row["role"]}):
        rows = [row for row in source_rows if row["role"] == role]
        override = overrides.get(role)
        if override:
            if override not in {row["source"] for row in rows}:
                errors.append(f"Primary override for {role} is not a selected source: {override}")
            for row in rows:
                row["assignment"] = "PRIMARY" if row["source"] == override else "SUPPLEMENTAL"
        elif len(rows) == 1:
            rows[0]["assignment"] = "SUPPLEMENTAL" if role == "markers" else "PRIMARY"
        primaries = [row["source"] for row in rows if row["assignment"] == "PRIMARY"]
        supplemental = [row["source"] for row in rows if row["assignment"] == "SUPPLEMENTAL"]
        unassigned = [row["source"] for row in rows if row["assignment"] == "UNASSIGNED"]
        if role != "markers" and len(primaries) > 1:
            errors.append(f"Canonical role {role} has multiple primary sources; supply an explicit primary override.")
        if role != "markers" and not primaries and supplemental:
            errors.append(f"Canonical role {role} has supplemental sources but no primary source.")
        assignments[role] = {
            "primary": primaries[0] if len(primaries) == 1 else None,
            "supplemental": supplemental,
            "unassigned": unassigned,
        }
    return {
        "schema": DRAFT_PROFILE_SCHEMA,
        "profile_id": re.sub(r"[^a-z0-9]+", "_", profile_id.lower()).strip("_") or "hardware_draft",
        "created_utc": utc_now(),
        "status": "DRAFT_NOT_APPROVED",
        "runtime_authority": False,
        "physical_validation": "NOT_ESTABLISHED",
        "reviewed_by": "UNRECORDED",
        "modules": selected_modules,
        "role_assignments": assignments,
        "errors_requiring_resolution": errors,
        "next_gate": "Export completed module definitions to the packaged registry, review them, run live preflight, and use the canonical profile approval path.",
        "forbidden_effects": ["SESSION_LOCK", "ARM", "ACQUIRE", "TRUST_PROMOTION", "PRIMARY_ANALYSIS_AUTHORITY"],
    }


def _parse_primary(values: Iterable[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for raw in values:
        if "=" not in raw:
            raise ValueError(f"Primary override must be role=adapter/route/lsl_name, got {raw!r}")
        role, source = raw.split("=", 1)
        if not role or not source:
            raise ValueError(f"Primary override is incomplete: {raw!r}")
        result[role] = source
    return result


def launch_gui(catalog_path: Path = DEFAULT_CATALOG) -> int:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, simpledialog, ttk
    except Exception as exc:
        print(f"Tkinter is unavailable: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    report = validate_catalog(catalog_path)
    if report["status"] == "INELIGIBLE":
        message = "Hardware catalog is ineligible:\n" + "\n".join(report["errors"])
        print(message, file=sys.stderr)
        return 2
    catalog, _drafts = load_catalog(catalog_path)
    root = tk.Tk()
    root.title("PRAYCG Hardware Forge v0.1 — staging only")
    root.geometry("1040x650")
    banner = ttk.Label(
        root,
        text="Catalog and draft builder only — no device is approved and no session authority can be created here.",
        foreground="#8b1e1e",
        wraplength=1000,
    )
    banner.pack(fill="x", padx=12, pady=10)
    frame = ttk.Frame(root)
    frame.pack(fill="both", expand=True, padx=12)
    tree = ttk.Treeview(frame, columns=("category", "state", "physical", "launch"), show="tree headings")
    tree.heading("#0", text="Adapter / route")
    tree.heading("category", text="Category")
    tree.heading("state", text="Admission")
    tree.heading("physical", text="Physical evidence")
    tree.heading("launch", text="Launch")
    tree.column("#0", width=360)
    tree.pack(fill="both", expand=True, side="left")
    scroll = ttk.Scrollbar(frame, command=tree.yview)
    scroll.pack(fill="y", side="right")
    tree.configure(yscrollcommand=scroll.set)
    lookup: dict[str, tuple[str, str | None]] = {}
    for descriptor in catalog["adapters"]:
        parent = tree.insert("", "end", text=descriptor["display_name"], values=(descriptor["category"], descriptor["admission_state"], descriptor["physical_validation"], ""))
        lookup[parent] = (descriptor["adapter_id"], None)
        for route in descriptor["routes"]:
            child = tree.insert(parent, "end", text=route["display_name"], values=("", descriptor["admission_state"], descriptor["physical_validation"], route["launch_state"]))
            lookup[child] = (descriptor["adapter_id"], route["route_id"])
    detail = tk.Text(root, height=10, wrap="word", state="disabled")
    detail.pack(fill="x", padx=12, pady=8)

    def selected_pair() -> tuple[str, str] | None:
        selected = tree.selection()
        if not selected:
            return None
        adapter_id, route_id = lookup[selected[0]]
        if route_id is None:
            return None
        return adapter_id, route_id

    def show_detail(_event: Any = None) -> None:
        selected = tree.selection()
        if not selected:
            return
        adapter_id, route_id = lookup[selected[0]]
        descriptor = next(row for row in catalog["adapters"] if row["adapter_id"] == adapter_id)
        payload: Any = descriptor if route_id is None else next(row for row in descriptor["routes"] if row["route_id"] == route_id)
        detail.configure(state="normal")
        detail.delete("1.0", "end")
        detail.insert("1.0", json.dumps(payload, indent=2))
        detail.configure(state="disabled")

    def save_draft() -> None:
        pair = selected_pair()
        if pair is None:
            messagebox.showinfo("Select a route", "Select one adapter route, not only the adapter heading.")
            return
        profile_id = simpledialog.askstring("Draft name", "Profile draft identifier:", initialvalue=f"{pair[0]}_{pair[1]}")
        if not profile_id:
            return
        output = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON", "*.json")], initialfile=f"{profile_id}_DRAFT.json")
        if not output:
            return
        try:
            draft = create_draft_profile([f"{pair[0]}:{pair[1]}"], profile_id=profile_id, catalog_path=catalog_path)
            write_json(Path(output), draft)
        except Exception as exc:
            messagebox.showerror("Draft failed", f"{type(exc).__name__}: {exc}")
            return
        messagebox.showinfo("Draft written", "A non-approved draft was written. It cannot arm or launch acquisition.")

    tree.bind("<<TreeviewSelect>>", show_detail)
    buttons = ttk.Frame(root)
    buttons.pack(fill="x", padx=12, pady=(0, 12))
    ttk.Button(buttons, text="Create non-approved draft", command=save_draft).pack(side="left")
    ttk.Button(buttons, text="Close", command=root.destroy).pack(side="right")
    root.mainloop()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Hardware Forge v0.1")
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG)
    sub = parser.add_subparsers(dest="action")
    sub.add_parser("gui", help="Open the staging catalog and draft builder")
    sub.add_parser("validate", help="Validate catalog, descriptors, draft modules, and authority boundaries")
    listing = sub.add_parser("list", help="List adapter routes")
    listing.add_argument("--category")
    listing.add_argument("--admission-state")
    show = sub.add_parser("show", help="Show one adapter descriptor")
    show.add_argument("adapter_id")
    create = sub.add_parser("create-draft-profile", help="Compose a non-approved profile draft")
    create.add_argument("--selection", action="append", required=True, help="adapter_id:route_id; repeat to compose")
    create.add_argument("--profile-id", required=True)
    create.add_argument("--primary", action="append", default=[], help="role=adapter/route/lsl_name; resolves role collisions")
    create.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.action in {None, "gui"}:
        return launch_gui(args.catalog)
    if args.action == "validate":
        report = validate_catalog(args.catalog)
        print(json.dumps(report, indent=2))
        return 0 if report["status"] == "PASS" else (3 if report["status"] == "CAUTION" else 4)
    catalog, _drafts = load_catalog(args.catalog)
    if args.action == "list":
        rows = []
        for descriptor in catalog["adapters"]:
            if args.category and descriptor["category"] != args.category:
                continue
            if args.admission_state and descriptor["admission_state"] != args.admission_state:
                continue
            for route in descriptor["routes"]:
                rows.append({
                    "adapter_id": descriptor["adapter_id"],
                    "route_id": route["route_id"],
                    "display_name": route["display_name"],
                    "category": descriptor["category"],
                    "admission_state": descriptor["admission_state"],
                    "physical_validation": descriptor["physical_validation"],
                    "launch_state": route["launch_state"],
                })
        print(json.dumps(rows, indent=2))
        return 0
    if args.action == "show":
        descriptor = next((row for row in catalog["adapters"] if row.get("adapter_id") == args.adapter_id), None)
        if descriptor is None:
            print(f"Unknown adapter: {args.adapter_id}", file=sys.stderr)
            return 2
        print(json.dumps(descriptor, indent=2))
        return 0
    if args.action == "create-draft-profile":
        try:
            draft = create_draft_profile(
                args.selection,
                profile_id=args.profile_id,
                primary_overrides=_parse_primary(args.primary),
                catalog_path=args.catalog,
            )
            write_json(args.out, draft)
        except Exception as exc:
            print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
        print(json.dumps(draft, indent=2))
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
