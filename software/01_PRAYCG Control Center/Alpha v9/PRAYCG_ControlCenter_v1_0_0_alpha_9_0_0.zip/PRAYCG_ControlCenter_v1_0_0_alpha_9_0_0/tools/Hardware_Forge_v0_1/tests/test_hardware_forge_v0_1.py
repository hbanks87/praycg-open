from __future__ import annotations

from copy import deepcopy
import importlib.util
from pathlib import Path
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[3]
SCRIPT = ROOT / "tools" / "Hardware_Forge_v0_1" / "praycg_hardware_forge_v0_1.py"
SPEC = importlib.util.spec_from_file_location("hardware_forge", SCRIPT)
assert SPEC and SPEC.loader
forge = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(forge)


class HardwareForgeTests(unittest.TestCase):
    def test_packaged_catalog_passes_and_has_no_authority(self) -> None:
        report = forge.validate_catalog()
        self.assertEqual(report["status"], "PASS", report)
        catalog, drafts = forge.load_catalog()
        self.assertGreaterEqual(len(catalog["adapters"]), 8)
        self.assertTrue(all(row["runtime_authority"] is False for row in catalog["adapters"]))
        self.assertTrue(all(row["runtime_authority"] is False for row in drafts["drafts"]))

    def test_catalog_reference_cannot_escape_forge(self) -> None:
        with self.assertRaises(ValueError):
            forge._catalog_reference(forge.DEFAULT_CATALOG, "../../outside.json")

    def test_quarantine_cannot_expose_live_launch(self) -> None:
        catalog, drafts = forge.load_catalog()
        draft_ids = {row["draft_module_id"] for row in drafts["drafts"]}
        descriptor = deepcopy(next(row for row in catalog["adapters"] if row["adapter_id"] == "cerelog_emg_als"))
        descriptor["routes"][0]["launch_state"] = "AVAILABLE_ALPHA"
        errors = forge.validate_adapter_descriptor(descriptor, draft_ids)
        self.assertTrue(any("quarantined routes must be withheld" in item for item in errors))

    def test_source_archive_hash_is_lowercase_and_filename_only(self) -> None:
        catalog, drafts = forge.load_catalog()
        draft_ids = {row["draft_module_id"] for row in drafts["drafts"]}
        descriptor = deepcopy(catalog["adapters"][0])
        descriptor["source_archive"]["sha256"] = "A" * 64
        descriptor["source_archive"]["filename"] = "C:/private/source.zip"
        errors = forge.validate_adapter_descriptor(descriptor, draft_ids)
        self.assertTrue(any("lowercase hex" in item for item in errors))
        self.assertTrue(any("filename, not a path" in item for item in errors))

    def test_single_route_profile_is_always_nonapproved(self) -> None:
        draft = forge.create_draft_profile(
            ["generic_eda_ppg:udp_json_datagrams"],
            profile_id="physio draft",
        )
        self.assertEqual(draft["status"], "DRAFT_NOT_APPROVED")
        self.assertFalse(draft["runtime_authority"])
        self.assertEqual(draft["role_assignments"]["eda"]["primary"], "generic_eda_ppg/udp_json_datagrams/PRAYCG_EDA")
        self.assertEqual(draft["role_assignments"]["ppg"]["primary"], "generic_eda_ppg/udp_json_datagrams/PRAYCG_PPG")

    def test_multiple_eeg_sources_require_explicit_primary(self) -> None:
        draft = forge.create_draft_profile(
            ["muse_brainflow:muse_2_brainflow", "pieeg_network:pieeg_8ch_network"],
            profile_id="ambiguous eeg",
        )
        self.assertTrue(any("multiple primary sources" in item for item in draft["errors_requiring_resolution"]))
        resolved = forge.create_draft_profile(
            ["muse_brainflow:muse_2_brainflow", "pieeg_network:pieeg_8ch_network"],
            profile_id="resolved eeg",
            primary_overrides={"eeg": "muse_brainflow/muse_2_brainflow/Muse2EEG"},
        )
        self.assertEqual(resolved["role_assignments"]["eeg"]["primary"], "muse_brainflow/muse_2_brainflow/Muse2EEG")
        self.assertIn("pieeg_network/pieeg_8ch_network/PiEEG8EEG", resolved["role_assignments"]["eeg"]["supplemental"])

    def test_quarantined_selection_is_visible_as_unresolved(self) -> None:
        draft = forge.create_draft_profile(["cerelog_emg_als:split_emg_als"], profile_id="unsafe")
        self.assertTrue(any("quarantined" in item.lower() for item in draft["errors_requiring_resolution"]))
        self.assertFalse(draft["runtime_authority"])


if __name__ == "__main__":
    unittest.main()
