#!/usr/bin/env python3
"""Discover existing LSL outlets and produce non-authoritative PRAYCG drafts.

Discovery never approves a device or arms a session.  It captures the complete
observable outlet identity and ordered channel metadata so that an operator can
turn a vendor-provided LSL stream into a reviewed PRAYCG stream contract.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import sys
from typing import Any, Mapping
import xml.etree.ElementTree as ET


FORGE_ROOT = Path(__file__).resolve().parent
if str(FORGE_ROOT) not in sys.path:
    sys.path.insert(0, str(FORGE_ROOT))

from praycg_stream_contract_v1_0 import (  # noqa: E402
    CANONICAL_ROLES,
    compare_contract,
    create_contract_draft,
    read_json,
    write_json,
)


SNAPSHOT_SCHEMA = "PRAYCG_LSLDiscoverySnapshot_v1_0"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _child_text(node: ET.Element | None, name: str) -> str:
    if node is None:
        return ""
    child = node.find(name)
    return str(child.text or "").strip() if child is not None else ""


def _xml_observation(xml_text: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    channels: list[dict[str, Any]] = []
    desc_values: dict[str, Any] = {}
    try:
        root = ET.fromstring(xml_text)
    except (ET.ParseError, TypeError, ValueError):
        return channels, desc_values
    desc = root.find("desc")
    if desc is not None:
        for child in list(desc):
            if child.tag == "channels":
                continue
            if not list(child):
                desc_values[child.tag] = str(child.text or "").strip()
        channel_root = desc.find("channels")
        if channel_root is not None:
            for index, channel in enumerate(channel_root.findall("channel"), start=1):
                channels.append({
                    "index": index,
                    "label": _child_text(channel, "label"),
                    "type": _child_text(channel, "type"),
                    "unit": _child_text(channel, "unit"),
                    "reference": _child_text(channel, "reference"),
                    "description": _child_text(channel, "description"),
                })
    return channels, desc_values


def _channel_format_name(pylsl: Any, raw: Any) -> str:
    mapping = {
        getattr(pylsl, "cf_float32", object()): "float32",
        getattr(pylsl, "cf_double64", object()): "double64",
        getattr(pylsl, "cf_string", object()): "string",
        getattr(pylsl, "cf_int8", object()): "int8",
        getattr(pylsl, "cf_int16", object()): "int16",
        getattr(pylsl, "cf_int32", object()): "int32",
        getattr(pylsl, "cf_int64", object()): "int64",
    }
    if raw in mapping:
        return mapping[raw]
    text = str(raw or "").strip().lower()
    aliases = {"1": "float32", "2": "double64", "3": "string", "4": "int32", "5": "int16", "6": "int8", "7": "int64"}
    return aliases.get(text, text)


def observation_from_stream_info(info: Any, pylsl: Any) -> dict[str, Any]:
    try:
        xml_text = str(info.as_xml() or "")
    except Exception:
        xml_text = ""
    channels, desc = _xml_observation(xml_text)

    def value(method: str, default: Any = "") -> Any:
        try:
            return getattr(info, method)()
        except Exception:
            return default

    observation = {
        "name": str(value("name") or ""),
        "type": str(value("type") or ""),
        "channel_count": int(value("channel_count", 0) or 0),
        "nominal_srate": float(value("nominal_srate", 0.0) or 0.0),
        "channel_format": _channel_format_name(pylsl, value("channel_format", "")),
        "source_id": str(value("source_id") or ""),
        "uid": str(value("uid") or ""),
        "hostname": str(value("hostname") or ""),
        "session_id": str(value("session_id") or ""),
        "created_at": float(value("created_at", 0.0) or 0.0),
        "channels": channels,
        "desc": desc,
    }
    observation["metadata_complete"] = (
        len(channels) == observation["channel_count"]
        and all(row.get("label") and row.get("type") and row.get("unit") for row in channels)
        and bool(observation["source_id"])
        and bool(observation["uid"])
    )
    return observation


def discover_live(timeout: float = 2.0) -> dict[str, Any]:
    snapshot: dict[str, Any] = {
        "schema": SNAPSHOT_SCHEMA,
        "generated_utc": utc_now(),
        "timeout_seconds": float(timeout),
        "status": "INELIGIBLE",
        "streams": [],
        "errors": [],
        "cautions": [],
        "authority_boundary": (
            "Discovery records observable LSL metadata only. It does not approve hardware, "
            "validate physiology, lock a profile, confirm a session, or arm a runner."
        ),
    }
    try:
        import pylsl  # type: ignore
    except Exception as exc:
        snapshot["errors"].append(f"pylsl unavailable: {type(exc).__name__}: {exc}")
        return snapshot
    try:
        infos = list(pylsl.resolve_streams(wait_time=max(0.0, float(timeout))))
    except TypeError:
        infos = list(pylsl.resolve_streams(max(0.0, float(timeout))))
    except Exception as exc:
        snapshot["errors"].append(f"LSL discovery failed: {type(exc).__name__}: {exc}")
        return snapshot
    for info in infos:
        try:
            snapshot["streams"].append(observation_from_stream_info(info, pylsl))
        except Exception as exc:
            snapshot["cautions"].append(f"One outlet could not be described: {type(exc).__name__}: {exc}")
    snapshot["streams"].sort(key=lambda row: (row["name"].lower(), row["type"].lower(), row["source_id"]))
    if not snapshot["streams"]:
        snapshot["cautions"].append("No LSL outlets were visible during the discovery window")
        snapshot["status"] = "CAUTION"
    elif any(not row["metadata_complete"] for row in snapshot["streams"]):
        snapshot["cautions"].append("One or more outlets omit source identity or complete ordered channel metadata")
        snapshot["status"] = "CAUTION"
    else:
        snapshot["status"] = "PASS"
    return snapshot


def stream_from_snapshot(snapshot: Mapping[str, Any], index: int) -> dict[str, Any]:
    if snapshot.get("schema") != SNAPSHOT_SCHEMA:
        raise ValueError("Unsupported LSL discovery snapshot schema")
    rows = snapshot.get("streams")
    if not isinstance(rows, list) or not (0 <= index < len(rows)):
        raise IndexError(f"Stream index {index} is outside the discovery snapshot")
    value = rows[index]
    if not isinstance(value, dict):
        raise ValueError(f"Stream index {index} is not an object")
    return value


def launch_gui() -> int:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, simpledialog, ttk
    except Exception as exc:
        print(f"Tkinter unavailable: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    root = tk.Tk()
    root.title("PRAYCG Alpha 9 — Generic LSL Intake")
    root.geometry("1080x720")
    ttk.Label(
        root,
        text=(
            "Discover and fingerprint existing LSL outlets. Drafts are non-authoritative until their source identity, "
            "ordered channels, units, timing provenance, device details, license, and physical validation are reviewed."
        ),
        foreground="#7a1e1e",
        wraplength=1040,
    ).pack(fill="x", padx=12, pady=10)
    tree = ttk.Treeview(
        root,
        columns=("type", "channels", "rate", "source", "metadata"),
        show="tree headings",
        height=15,
    )
    tree.heading("#0", text="LSL name")
    tree.heading("type", text="Type")
    tree.heading("channels", text="Channels")
    tree.heading("rate", text="Nominal Hz")
    tree.heading("source", text="Source ID")
    tree.heading("metadata", text="Metadata")
    tree.column("#0", width=210)
    tree.column("source", width=330)
    tree.pack(fill="both", expand=True, padx=12)
    detail = tk.Text(root, height=13, wrap="none", state="disabled")
    detail.pack(fill="both", expand=True, padx=12, pady=8)
    state: dict[str, Any] = {"snapshot": None, "index": {}}

    def show_detail(_event: Any = None) -> None:
        selected = tree.selection()
        if not selected or state["snapshot"] is None:
            return
        row = stream_from_snapshot(state["snapshot"], state["index"][selected[0]])
        detail.configure(state="normal")
        detail.delete("1.0", "end")
        detail.insert("1.0", json.dumps(row, indent=2, ensure_ascii=False))
        detail.configure(state="disabled")

    def discover() -> None:
        snapshot = discover_live(2.0)
        state["snapshot"] = snapshot
        state["index"] = {}
        tree.delete(*tree.get_children())
        for index, row in enumerate(snapshot["streams"]):
            item = tree.insert(
                "", "end", text=row["name"],
                values=(row["type"], row["channel_count"], row["nominal_srate"], row["source_id"], "complete" if row["metadata_complete"] else "review"),
            )
            state["index"][item] = index
        if snapshot["errors"]:
            messagebox.showerror("Discovery failed", "\n".join(snapshot["errors"]), parent=root)
        elif not snapshot["streams"]:
            messagebox.showinfo("No streams visible", "No LSL outlets were visible during the discovery window.", parent=root)

    def save_snapshot() -> None:
        snapshot = state.get("snapshot")
        if not snapshot:
            messagebox.showinfo("Discover first", "Run discovery before saving a snapshot.", parent=root)
            return
        output = filedialog.asksaveasfilename(
            title="Save LSL discovery snapshot", defaultextension=".json",
            initialfile="praycg_lsl_discovery_snapshot.json", filetypes=(("JSON", "*.json"),),
        )
        if output:
            write_json(Path(output), snapshot)

    def save_draft() -> None:
        selected = tree.selection()
        if not selected or state.get("snapshot") is None:
            messagebox.showinfo("Select a stream", "Select exactly one discovered outlet.", parent=root)
            return
        row = stream_from_snapshot(state["snapshot"], state["index"][selected[0]])
        role = simpledialog.askstring(
            "Canonical role", "Role (for example eeg, emg, ecg, respiration, rr_intervals, gaze):",
            initialvalue=str(row.get("type") or "other").lower(), parent=root,
        )
        if not role:
            return
        role = role.strip().lower()
        if role not in CANONICAL_ROLES:
            messagebox.showerror("Unsupported role", f"Choose one of:\n{', '.join(sorted(CANONICAL_ROLES))}", parent=root)
            return
        contract_id = simpledialog.askstring(
            "Contract identifier", "Portable contract identifier:",
            initialvalue=f"{row.get('name', 'lsl_stream')}_{role}".lower().replace(" ", "_"), parent=root,
        )
        if not contract_id:
            return
        output = filedialog.asksaveasfilename(
            title="Save non-authoritative stream contract draft", defaultextension=".json",
            initialfile=f"{contract_id}_DRAFT.json", filetypes=(("JSON", "*.json"),),
        )
        if not output:
            return
        write_json(Path(output), create_contract_draft(row, contract_id=contract_id, canonical_role=role))
        messagebox.showinfo(
            "Draft saved",
            "The observed outlet was converted into a non-authoritative draft. Review every open field before admission.",
            parent=root,
        )

    tree.bind("<<TreeviewSelect>>", show_detail)
    buttons = ttk.Frame(root)
    buttons.pack(fill="x", padx=12, pady=(0, 12))
    ttk.Button(buttons, text="Discover LSL outlets", command=discover).pack(side="left", padx=3)
    ttk.Button(buttons, text="Save discovery snapshot", command=save_snapshot).pack(side="left", padx=3)
    ttk.Button(buttons, text="Create reviewed-fields draft", command=save_draft).pack(side="left", padx=3)
    ttk.Button(buttons, text="Close", command=root.destroy).pack(side="right", padx=3)
    root.mainloop()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Alpha 9 generic existing-LSL intake")
    sub = parser.add_subparsers(dest="action")
    discover = sub.add_parser("discover")
    discover.add_argument("--timeout", type=float, default=2.0)
    discover.add_argument("--out", type=Path)
    draft = sub.add_parser("draft")
    draft.add_argument("--snapshot", type=Path, required=True)
    draft.add_argument("--index", type=int, required=True)
    draft.add_argument("--contract-id", required=True)
    draft.add_argument("--role", required=True, choices=sorted(CANONICAL_ROLES))
    draft.add_argument("--out", type=Path, required=True)
    validate = sub.add_parser("compare")
    validate.add_argument("--snapshot", type=Path, required=True)
    validate.add_argument("--index", type=int, required=True)
    validate.add_argument("--contract", type=Path, required=True)
    validate.add_argument("--run-uuid", default="")
    sub.add_parser("gui")
    args = parser.parse_args(argv)
    if args.action in {None, "gui"}:
        return launch_gui()
    if args.action == "discover":
        result = discover_live(args.timeout)
        if args.out:
            write_json(args.out, result)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0 if result["status"] in {"PASS", "CAUTION"} else 4
    snapshot = read_json(args.snapshot)
    observation = stream_from_snapshot(snapshot, args.index)
    if args.action == "draft":
        result = create_contract_draft(observation, contract_id=args.contract_id, canonical_role=args.role)
        write_json(args.out, result)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    result = compare_contract(read_json(args.contract), observation, expected_run_uuid=args.run_uuid)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 4


if __name__ == "__main__":
    raise SystemExit(main())
