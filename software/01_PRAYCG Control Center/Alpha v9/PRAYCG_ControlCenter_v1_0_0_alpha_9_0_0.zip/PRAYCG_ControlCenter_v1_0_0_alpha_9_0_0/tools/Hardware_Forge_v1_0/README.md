# PRAYCG Hardware Forge v1.0

Hardware Forge v1.0 is the Alpha 9 adapter workbench. It presents packaged PRAYCG bridges, external LSL publishers, and generic existing-LSL discovery through one governed catalog.

The Forge can:

- validate adapter entry points and stream contracts;
- check whether local dependencies are installed;
- discover existing LSL outlets;
- capture complete observable outlet metadata;
- create non-authoritative stream-contract drafts;
- produce run-bound launch plans for the existing Control Center handlers.

It cannot approve hardware, promote physical evidence, confirm a session, issue a session lock, ARM a runner, or turn a catalog entry into participant-data eligibility.

Use `praycg_hardware_forge_v1_0.py validate` for catalog validation, `doctor` for dependency checks, and `gui` for the device-oriented workbench. Use `praycg_generic_lsl_intake_v1_0.py gui` when a manufacturer or community application already publishes LSL.
