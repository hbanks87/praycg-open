#!/usr/bin/env python3
"""Canonical, fail-closed LSL stream contracts for PRAYCG Alpha 9.

The contract is deliberately independent of pylsl so that adapters, captured
stream snapshots, and release tests can be validated without attached hardware.
Live tools can convert a pylsl StreamInfo into the same observation shape.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
from typing import Any, Iterable, Mapping, Sequence


CONTRACT_SCHEMA = "PRAYCG_StreamContract_v1_0"
VALIDATION_SCHEMA = "PRAYCG_StreamContractValidation_v1_0"
COMPARISON_SCHEMA = "PRAYCG_StreamContractComparison_v1_0"
DRAFT_SCHEMA = "PRAYCG_StreamContractDraft_v1_0"

CANONICAL_ROLES = {
    "eeg", "eog", "emg", "ecg", "rr_intervals", "heart_rate",
    "respiration", "eda", "ppg", "gaze", "pupil", "analog_aux",
    "als", "markers", "audio", "video", "status", "other",
}
CHANNEL_FORMATS = {
    "float32", "double64", "string", "int8", "int16", "int32", "int64",
}
SOURCE_ID_POLICIES = {
    "EXACT", "RUN_BOUND_PREFIX", "CONNECTION_SPECIFIC", "UNVERIFIED",
}
TIMESTAMP_SOURCES = {
    "DEVICE_CLOCK", "HOST_ACQUISITION", "HOST_RECEIPT", "LSL_LOCAL_CLOCK",
    "INTERPOLATED_DEVICE_SCHEDULE", "VENDOR_SDK", "UNVERIFIED",
}
CONTRACT_STATES = {
    "DRAFT_UNVERIFIED", "SIMULATOR_VERIFIED", "BENCH_VERIFIED",
    "HUMAN_CONNECTED_APPROVED", "QUARANTINED",
}
ID_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]*$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
PLACEHOLDER_VALUES = {
    "", "unknown", "unverified", "n/a", "device_native_unverified",
    "replace_me", "replace-with-observed-value",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return value


def write_json(path: Path, value: Mapping[str, Any]) -> None:
    target = Path(path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(target)


def _text(value: Any) -> str:
    return str(value or "").strip()


def _number(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _status(errors: Sequence[str], cautions: Sequence[str]) -> str:
    return "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS")


def _is_placeholder(value: Any) -> bool:
    return _text(value).lower() in PLACEHOLDER_VALUES


def _contract_core(contract: Mapping[str, Any]) -> dict[str, Any]:
    """Return the immutable identity-bearing portion of a contract."""
    return {
        "schema": contract.get("schema"),
        "contract_id": contract.get("contract_id"),
        "contract_version": contract.get("contract_version"),
        "contract_state": contract.get("contract_state"),
        "canonical_role": contract.get("canonical_role"),
        "required": contract.get("required"),
        "identity": deepcopy(contract.get("identity")),
        "stream": deepcopy(contract.get("stream")),
        "channels": deepcopy(contract.get("channels")),
        "timing": deepcopy(contract.get("timing")),
        "device": deepcopy(contract.get("device")),
        "adapter": deepcopy(contract.get("adapter")),
        "quality": deepcopy(contract.get("quality")),
        "privacy": deepcopy(contract.get("privacy")),
    }


def contract_sha256(contract: Mapping[str, Any]) -> str:
    return sha256_json(_contract_core(contract))


def validate_contract(contract: Mapping[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    cautions: list[str] = []
    if contract.get("schema") != CONTRACT_SCHEMA:
        errors.append(f"Unsupported stream contract schema: {contract.get('schema')!r}")
    contract_id = _text(contract.get("contract_id"))
    if not ID_RE.fullmatch(contract_id):
        errors.append("contract_id must be a lowercase portable identifier")
    if not _text(contract.get("contract_version")):
        errors.append("contract_version is required")
    state = _text(contract.get("contract_state"))
    if state not in CONTRACT_STATES:
        errors.append(f"Unsupported contract_state: {state or '<blank>'}")
    elif state in {"DRAFT_UNVERIFIED", "SIMULATOR_VERIFIED", "BENCH_VERIFIED"}:
        cautions.append(f"{state} is not human-connected acquisition approval")
    elif state == "QUARANTINED":
        errors.append("Quarantined contracts cannot be admitted")
    role = _text(contract.get("canonical_role"))
    if role not in CANONICAL_ROLES:
        errors.append(f"Unsupported canonical_role: {role or '<blank>'}")
    if not isinstance(contract.get("required"), bool):
        errors.append("required must be boolean")

    identity = contract.get("identity")
    if not isinstance(identity, Mapping):
        errors.append("identity must be an object")
        identity = {}
    for field in ("name", "type"):
        if _is_placeholder(identity.get(field)):
            errors.append(f"identity.{field} is required")
    policy = _text(identity.get("source_id_policy"))
    if policy not in SOURCE_ID_POLICIES:
        errors.append(f"Unsupported identity.source_id_policy: {policy or '<blank>'}")
    if policy == "EXACT" and _is_placeholder(identity.get("source_id")):
        errors.append("EXACT source identity requires identity.source_id")
    if policy == "RUN_BOUND_PREFIX" and _is_placeholder(identity.get("source_id_prefix")):
        errors.append("RUN_BOUND_PREFIX requires identity.source_id_prefix")
    if policy in {"CONNECTION_SPECIFIC", "UNVERIFIED"}:
        cautions.append(f"{policy} source identity must be frozen from discovery before ARM")

    stream = contract.get("stream")
    if not isinstance(stream, Mapping):
        errors.append("stream must be an object")
        stream = {}
    try:
        channel_count = int(stream.get("channel_count"))
    except (TypeError, ValueError):
        channel_count = 0
    if channel_count < 1:
        errors.append("stream.channel_count must be positive")
    nominal = _number(stream.get("nominal_srate"))
    if nominal is None or nominal < 0:
        errors.append("stream.nominal_srate must be a finite non-negative number")
    channel_format = _text(stream.get("channel_format"))
    if channel_format not in CHANNEL_FORMATS:
        errors.append(f"Unsupported stream.channel_format: {channel_format or '<blank>'}")
    tolerance = _number(stream.get("rate_tolerance_fraction"))
    if tolerance is None or tolerance < 0 or tolerance > 1:
        errors.append("stream.rate_tolerance_fraction must be between 0 and 1")

    channels = contract.get("channels")
    if not isinstance(channels, list):
        errors.append("channels must be an ordered array")
        channels = []
    if channel_count and len(channels) != channel_count:
        errors.append(f"channels length {len(channels)} does not equal channel_count {channel_count}")
    labels: set[str] = set()
    for offset, channel in enumerate(channels, start=1):
        if not isinstance(channel, Mapping):
            errors.append(f"channel {offset} is not an object")
            continue
        try:
            index = int(channel.get("index"))
        except (TypeError, ValueError):
            index = -1
        if index != offset:
            errors.append(f"channel {offset} must declare index {offset}")
        label = _text(channel.get("label"))
        if _is_placeholder(label):
            errors.append(f"channel {offset} label is required")
        elif label in labels:
            errors.append(f"duplicate channel label: {label}")
        labels.add(label)
        if _is_placeholder(channel.get("type")):
            errors.append(f"channel {offset} type is required")
        if _is_placeholder(channel.get("unit")):
            cautions.append(f"channel {offset} physical unit is unverified")
        scale = _number(channel.get("scale"))
        offset_value = _number(channel.get("offset"))
        if scale is None or scale == 0:
            errors.append(f"channel {offset} scale must be finite and nonzero")
        if offset_value is None:
            errors.append(f"channel {offset} offset must be finite")

    timing = contract.get("timing")
    if not isinstance(timing, Mapping):
        errors.append("timing must be an object")
        timing = {}
    timestamp_source = _text(timing.get("timestamp_source"))
    if timestamp_source not in TIMESTAMP_SOURCES:
        errors.append(f"Unsupported timing.timestamp_source: {timestamp_source or '<blank>'}")
    elif timestamp_source == "UNVERIFIED":
        cautions.append("Timestamp source is unverified")
    for field in ("clock_domain", "assignment_point", "clock_correction", "restart_policy"):
        if _is_placeholder(timing.get(field)):
            cautions.append(f"timing.{field} is unverified")

    device = contract.get("device")
    if not isinstance(device, Mapping):
        errors.append("device must be an object")
        device = {}
    for field in ("manufacturer", "model"):
        if _is_placeholder(device.get(field)):
            cautions.append(f"device.{field} is unverified")

    adapter = contract.get("adapter")
    if not isinstance(adapter, Mapping):
        errors.append("adapter must be an object")
        adapter = {}
    for field in ("adapter_id", "adapter_version"):
        if _is_placeholder(adapter.get(field)):
            errors.append(f"adapter.{field} is required")
    upstream_sha = _text(adapter.get("upstream_commit"))
    if upstream_sha and upstream_sha != "package_native" and not re.fullmatch(r"[0-9a-f]{7,64}", upstream_sha):
        cautions.append("adapter.upstream_commit is not a pinned hexadecimal revision")

    quality = contract.get("quality")
    if not isinstance(quality, Mapping):
        errors.append("quality must be an object")
    privacy = contract.get("privacy")
    if not isinstance(privacy, Mapping) or privacy.get("allows_direct_identifiers") is not False:
        errors.append("privacy.allows_direct_identifiers must be false")

    declared_hash = _text(contract.get("contract_sha256"))
    actual_hash = contract_sha256(contract)
    if declared_hash:
        if not SHA256_RE.fullmatch(declared_hash):
            errors.append("contract_sha256 must be lowercase hexadecimal")
        elif declared_hash != actual_hash:
            errors.append("contract_sha256 does not match the canonical contract content")

    admission_ready = not errors and state == "HUMAN_CONNECTED_APPROVED" and policy in {"EXACT", "RUN_BOUND_PREFIX"}
    return {
        "schema": VALIDATION_SCHEMA,
        "generated_utc": utc_now(),
        "contract_id": contract_id,
        "status": _status(errors, cautions),
        "admission_ready": admission_ready,
        "errors": errors,
        "cautions": cautions,
        "contract_sha256": actual_hash,
        "boundary": (
            "Contract validation establishes metadata completeness and identity policy only. "
            "It does not establish electrical safety, signal origin, construct validity, or session authority."
        ),
    }


def _channel_rows(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        return []
    return [dict(row) for row in value if isinstance(row, Mapping)]


def compare_contract(
    contract: Mapping[str, Any],
    observed: Mapping[str, Any],
    *,
    expected_run_uuid: str = "",
    require_admission_ready: bool = True,
) -> dict[str, Any]:
    contract_report = validate_contract(contract)
    errors = list(contract_report["errors"])
    cautions = list(contract_report["cautions"])
    if require_admission_ready and not contract_report["admission_ready"]:
        errors.append("The contract is not HUMAN_CONNECTED_APPROVED with a lockable source identity")

    identity = contract.get("identity", {}) if isinstance(contract.get("identity"), Mapping) else {}
    stream = contract.get("stream", {}) if isinstance(contract.get("stream"), Mapping) else {}
    for field in ("name", "type"):
        expected = _text(identity.get(field))
        actual = _text(observed.get(field))
        if expected != actual:
            errors.append(f"{field} mismatch: expected {expected!r}, observed {actual!r}")
    try:
        expected_count = int(stream.get("channel_count"))
        observed_count = int(observed.get("channel_count"))
    except (TypeError, ValueError):
        expected_count, observed_count = -1, -2
    if expected_count != observed_count:
        errors.append(f"channel_count mismatch: expected {expected_count}, observed {observed_count}")
    expected_format = _text(stream.get("channel_format"))
    observed_format = _text(observed.get("channel_format"))
    if expected_format != observed_format:
        errors.append(f"channel_format mismatch: expected {expected_format!r}, observed {observed_format!r}")
    expected_rate = _number(stream.get("nominal_srate"))
    observed_rate = _number(observed.get("nominal_srate"))
    tolerance = _number(stream.get("rate_tolerance_fraction")) or 0.0
    if expected_rate is None or observed_rate is None:
        errors.append("Nominal sample rate could not be compared")
    elif expected_rate == 0:
        if observed_rate != 0:
            errors.append(f"Irregular stream must declare nominal_srate 0, observed {observed_rate}")
    elif abs(observed_rate - expected_rate) > expected_rate * tolerance:
        errors.append(
            f"nominal_srate mismatch: expected {expected_rate} ± {expected_rate * tolerance}, observed {observed_rate}"
        )

    source_id = _text(observed.get("source_id"))
    policy = _text(identity.get("source_id_policy"))
    if policy == "EXACT" and source_id != _text(identity.get("source_id")):
        errors.append("source_id does not match the exact locked identity")
    elif policy == "RUN_BOUND_PREFIX" and not source_id.startswith(_text(identity.get("source_id_prefix"))):
        errors.append("source_id does not match the locked run-bound prefix")
    elif policy in {"CONNECTION_SPECIFIC", "UNVERIFIED"}:
        errors.append("Connection-specific or unverified source identity must be frozen before comparison")
    if not source_id:
        errors.append("Observed stream has no source_id")
    if not _text(observed.get("uid")):
        errors.append("Observed stream has no LSL UID")

    expected_channels = _channel_rows(contract.get("channels"))
    observed_channels = _channel_rows(observed.get("channels"))
    if len(observed_channels) != observed_count:
        errors.append(
            f"Observed ordered channel metadata has {len(observed_channels)} rows for {observed_count} channels"
        )
    for offset, expected in enumerate(expected_channels, start=1):
        if offset > len(observed_channels):
            break
        actual = observed_channels[offset - 1]
        for field in ("label", "type", "unit"):
            if _text(expected.get(field)) != _text(actual.get(field)):
                errors.append(
                    f"channel {offset} {field} mismatch: expected {_text(expected.get(field))!r}, "
                    f"observed {_text(actual.get(field))!r}"
                )

    desc = observed.get("desc") if isinstance(observed.get("desc"), Mapping) else {}
    if expected_run_uuid:
        actual_run_uuid = _text(desc.get("run_uuid"))
        if actual_run_uuid != _text(expected_run_uuid):
            errors.append(
                f"run_uuid mismatch: expected {_text(expected_run_uuid)!r}, observed {actual_run_uuid!r}"
            )
    device = contract.get("device") if isinstance(contract.get("device"), Mapping) else {}
    for contract_field, desc_field in (("manufacturer", "manufacturer"), ("model", "model")):
        expected = _text(device.get(contract_field))
        actual = _text(desc.get(desc_field))
        if expected and not _is_placeholder(expected) and actual and expected != actual:
            errors.append(f"device {contract_field} mismatch: expected {expected!r}, observed {actual!r}")
        elif expected and not _is_placeholder(expected) and not actual:
            cautions.append(f"Observed stream omits device {contract_field}")

    return {
        "schema": COMPARISON_SCHEMA,
        "generated_utc": utc_now(),
        "contract_id": contract.get("contract_id"),
        "contract_sha256": contract_report["contract_sha256"],
        "status": _status(errors, cautions),
        "errors": errors,
        "cautions": cautions,
        "observed_identity": {
            key: observed.get(key)
            for key in ("name", "type", "channel_count", "nominal_srate", "channel_format", "source_id", "uid", "hostname", "session_id")
        },
        "boundary": "A metadata match does not establish signal quality, biological origin, scientific validity, or acquisition authority.",
    }


def select_unambiguous_stream(
    contract: Mapping[str, Any],
    observations: Iterable[Mapping[str, Any]],
    *,
    expected_run_uuid: str = "",
    require_admission_ready: bool = True,
) -> dict[str, Any]:
    rows = list(observations)
    comparisons = [
        compare_contract(
            contract,
            row,
            expected_run_uuid=expected_run_uuid,
            require_admission_ready=require_admission_ready,
        )
        for row in rows
    ]
    passing = [index for index, report in enumerate(comparisons) if report["status"] in {"PASS", "CAUTION"} and not report["errors"]]
    errors: list[str] = []
    if not passing:
        errors.append("No observed LSL outlet satisfies the complete locked stream contract")
    elif len(passing) > 1:
        errors.append("More than one observed LSL outlet satisfies the locked stream contract")
    return {
        "schema": "PRAYCG_StreamContractSelection_v1_0",
        "generated_utc": utc_now(),
        "status": "PASS" if len(passing) == 1 else "INELIGIBLE",
        "selected_index": passing[0] if len(passing) == 1 else None,
        "errors": errors,
        "comparisons": comparisons,
    }


def create_contract_draft(
    observed: Mapping[str, Any],
    *,
    contract_id: str,
    canonical_role: str,
    adapter_id: str = "generic_existing_lsl",
    adapter_version: str = "1.0.0",
) -> dict[str, Any]:
    """Create a non-authoritative draft from one observed outlet."""
    observed_channels = _channel_rows(observed.get("channels"))
    try:
        channel_count = int(observed.get("channel_count"))
    except (TypeError, ValueError):
        channel_count = len(observed_channels)
    channels: list[dict[str, Any]] = []
    for index in range(1, max(0, channel_count) + 1):
        source = observed_channels[index - 1] if index <= len(observed_channels) else {}
        channels.append({
            "index": index,
            "label": _text(source.get("label")) or f"CH{index}",
            "type": _text(source.get("type")) or canonical_role.upper(),
            "unit": _text(source.get("unit")) or "device_native_unverified",
            "scale": 1.0,
            "offset": 0.0,
            "reference": _text(source.get("reference")) or "unverified",
            "description": _text(source.get("description")),
        })
    desc = observed.get("desc") if isinstance(observed.get("desc"), Mapping) else {}
    draft: dict[str, Any] = {
        "schema": CONTRACT_SCHEMA,
        "contract_id": re.sub(r"[^a-z0-9_.-]+", "_", contract_id.lower()).strip("_") or "lsl_stream_draft",
        "contract_version": "1.0.0-draft",
        "contract_state": "DRAFT_UNVERIFIED",
        "canonical_role": canonical_role,
        "required": True,
        "identity": {
            "name": _text(observed.get("name")),
            "type": _text(observed.get("type")),
            "source_id_policy": "CONNECTION_SPECIFIC",
            "source_id": _text(observed.get("source_id")),
            "source_id_prefix": "",
        },
        "stream": {
            "channel_count": channel_count,
            "nominal_srate": _number(observed.get("nominal_srate")) or 0.0,
            "rate_tolerance_fraction": 0.05,
            "channel_format": _text(observed.get("channel_format")) or "float32",
        },
        "channels": channels,
        "timing": {
            "timestamp_source": "UNVERIFIED",
            "clock_domain": "unverified",
            "assignment_point": "unverified",
            "chunk_timestamping": "unverified",
            "clock_correction": "LSL_CLOCK_OFFSETS_RECORDED_IN_XDF",
            "restart_policy": "NEW_SEGMENT_AND_NEW_UID_REQUIRED",
        },
        "device": {
            "manufacturer": _text(desc.get("manufacturer")) or "unverified",
            "model": _text(desc.get("model")) or "unverified",
            "firmware": _text(desc.get("firmware")) or "unverified",
            "device_identifier_policy": "PSEUDONYMIZED_SEPARATE_FROM_PARTICIPANT",
        },
        "adapter": {
            "adapter_id": adapter_id,
            "adapter_version": adapter_version,
            "upstream_url": "",
            "upstream_commit": "",
            "license": "REVIEW_REQUIRED",
        },
        "quality": {
            "preflight_seconds": 30,
            "checks": [
                "exact_identity", "ordered_channel_metadata", "effective_sample_rate",
                "timestamp_monotonicity", "gaps", "nonfinite_values", "runtime_uid_continuity",
            ],
        },
        "privacy": {
            "allows_direct_identifiers": False,
            "device_serial_export": "PSEUDONYMIZE_OR_OMIT",
        },
        "draft_provenance": {
            "schema": DRAFT_SCHEMA,
            "generated_utc": utc_now(),
            "observed_uid": _text(observed.get("uid")),
            "observed_hostname": _text(observed.get("hostname")),
            "open_fields": [
                "source identity policy", "channel units and scaling", "timestamp provenance",
                "manufacturer/model/firmware", "adapter license and revision", "physical validation",
            ],
            "runtime_authority": False,
        },
    }
    draft["contract_sha256"] = contract_sha256(draft)
    return draft


def _main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Alpha 9 canonical LSL stream contracts")
    sub = parser.add_subparsers(dest="action", required=True)
    validate = sub.add_parser("validate")
    validate.add_argument("contract", type=Path)
    compare = sub.add_parser("compare")
    compare.add_argument("contract", type=Path)
    compare.add_argument("observation", type=Path)
    compare.add_argument("--run-uuid", default="")
    compare.add_argument("--allow-unapproved", action="store_true")
    draft = sub.add_parser("draft")
    draft.add_argument("observation", type=Path)
    draft.add_argument("--contract-id", required=True)
    draft.add_argument("--role", required=True, choices=sorted(CANONICAL_ROLES))
    draft.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.action == "validate":
        report = validate_contract(read_json(args.contract))
    elif args.action == "compare":
        report = compare_contract(
            read_json(args.contract), read_json(args.observation),
            expected_run_uuid=args.run_uuid,
            require_admission_ready=not args.allow_unapproved,
        )
    else:
        report = create_contract_draft(
            read_json(args.observation), contract_id=args.contract_id, canonical_role=args.role,
        )
        write_json(args.out, report)
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0 if report.get("status") == "PASS" or args.action == "draft" else 4


if __name__ == "__main__":
    raise SystemExit(_main())
