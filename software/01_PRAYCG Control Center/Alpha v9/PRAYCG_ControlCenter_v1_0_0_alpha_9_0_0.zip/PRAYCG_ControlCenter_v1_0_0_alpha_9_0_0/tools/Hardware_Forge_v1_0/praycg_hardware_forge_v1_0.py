#!/usr/bin/env python3
"""PRAYCG Alpha 9 governed hardware-adapter catalog and intake workbench.

Alpha 9 separates four facts that earlier catalog drafts could blur:

* an adapter is visible;
* its dependencies and packaged entry point are available;
* an observed LSL outlet matches a frozen stream contract;
* a reviewed hardware profile is authorized for a particular session.

Only the existing Hardware Registry and session-lock path can establish the last
fact.  Hardware Forge v1.0 provides discovery, validation, launch plans, and
non-authoritative drafts, but never ARM or acquisition authority.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import re
import sys
from typing import Any, Iterable, Mapping, Sequence


FORGE_ROOT = Path(__file__).resolve().parent
PACKAGE_ROOT = FORGE_ROOT.parents[1]
DEFAULT_CATALOG = PACKAGE_ROOT / "config" / "hardware_adapter_catalog_v1_0.json"
STREAM_TOOL = FORGE_ROOT / "praycg_generic_lsl_intake_v1_0.py"
CATALOG_SCHEMA = "PRAYCG_HardwareAdapterCatalog_v1_0"
REPORT_SCHEMA = "PRAYCG_HardwareAdapterCatalogValidation_v1_0"
PLAN_SCHEMA = "PRAYCG_HardwareAdapterLaunchPlan_v1_0"
ID_RE = re.compile(r"^[a-z0-9][a-z0-9_]*$")
SUPPORT_STATES = {
    "CATALOG_ONLY", "DEPENDENCY_READY", "SIMULATOR_VERIFIED", "BENCH_VERIFIED",
    "HUMAN_CONNECTED_APPROVED", "QUARANTINED", "DEPRECATED",
}
PHYSICAL_STATES = {"NOT_PERFORMED", "BENCH_ONLY", "HUMAN_CONNECTED"}
INTAKE_MODES = {"CONTROL_CENTER_HANDLER", "MANAGED_SCRIPT", "EXTERNAL_LSL", "EXISTING_LSL"}
LAUNCH_STATES = {"WITHHELD", "DISCOVERY_READY", "AVAILABLE_ALPHA", "AVAILABLE_REVIEWED"}
INTEGRATION_POLICIES = {"PACKAGE_NATIVE", "INDEPENDENT_ADAPTER", "UPSTREAM_EXTERNAL"}

if str(FORGE_ROOT) not in sys.path:
    sys.path.insert(0, str(FORGE_ROOT))

from praycg_stream_contract_v1_0 import read_json, validate_contract, write_json  # noqa: E402


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _text(value: Any) -> str:
    return str(value or "").strip()


def _status(errors: Sequence[str], cautions: Sequence[str]) -> str:
    return "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS")


def _contained(relative: str, *, must_exist: bool = False) -> Path:
    value = Path(str(relative or ""))
    if value.is_absolute() or ".." in value.parts:
        raise ValueError(f"Package path must be relative and contained: {relative!r}")
    resolved = (PACKAGE_ROOT / value).resolve()
    try:
        resolved.relative_to(PACKAGE_ROOT.resolve())
    except ValueError as exc:
        raise ValueError(f"Package path escapes the Alpha 9 release: {relative!r}") from exc
    if must_exist and not resolved.is_file():
        raise FileNotFoundError(resolved)
    return resolved


def load_catalog(path: Path = DEFAULT_CATALOG) -> dict[str, Any]:
    catalog_path = Path(path).expanduser().resolve()
    value = read_json(catalog_path)
    if value.get("schema") != CATALOG_SCHEMA:
        raise ValueError(f"Unsupported Alpha 9 adapter catalog schema: {value.get('schema')!r}")
    return value


def _validate_route(adapter: Mapping[str, Any], route: Mapping[str, Any]) -> tuple[list[str], list[str], list[dict[str, Any]]]:
    errors: list[str] = []
    cautions: list[str] = []
    contracts: list[dict[str, Any]] = []
    adapter_id = _text(adapter.get("adapter_id")) or "?"
    route_id = _text(route.get("route_id"))
    prefix = f"{adapter_id}/{route_id or '?'}"
    if not ID_RE.fullmatch(route_id):
        errors.append(f"{prefix}: invalid route_id")
    if not _text(route.get("display_name")):
        errors.append(f"{prefix}: display_name is required")
    intake = _text(route.get("intake_mode"))
    if intake not in INTAKE_MODES:
        errors.append(f"{prefix}: unsupported intake_mode {intake or '<blank>'}")
    launch = _text(route.get("launch_state"))
    if launch not in LAUNCH_STATES:
        errors.append(f"{prefix}: unsupported launch_state {launch or '<blank>'}")
    roles = route.get("canonical_roles")
    if not isinstance(roles, list) or not roles or any(not _text(value) for value in roles):
        errors.append(f"{prefix}: canonical_roles must be a non-empty string array")
    if not isinstance(route.get("requires_credentials"), bool):
        errors.append(f"{prefix}: requires_credentials must be boolean")
    managed_script = _text(route.get("managed_script"))
    if intake in {"CONTROL_CENTER_HANDLER", "MANAGED_SCRIPT", "EXISTING_LSL"}:
        if not managed_script:
            errors.append(f"{prefix}: managed_script is required for {intake}")
        else:
            try:
                script = _contained(managed_script, must_exist=True)
            except (ValueError, FileNotFoundError) as exc:
                errors.append(f"{prefix}: packaged entry point is invalid: {exc}")
            else:
                if script.suffix.lower() != ".py":
                    cautions.append(f"{prefix}: packaged entry point is not a Python script")
    elif managed_script:
        errors.append(f"{prefix}: external publishers must not masquerade as package-managed scripts")
    if intake == "CONTROL_CENTER_HANDLER" and not _text(route.get("handler_key")):
        errors.append(f"{prefix}: Control Center route requires handler_key")
    if launch == "AVAILABLE_REVIEWED" and adapter.get("support_state") != "HUMAN_CONNECTED_APPROVED":
        errors.append(f"{prefix}: reviewed launch requires HUMAN_CONNECTED_APPROVED adapter state")
    if adapter.get("support_state") == "QUARANTINED" and launch != "WITHHELD":
        errors.append(f"{prefix}: quarantined adapter routes must be withheld")

    contract_paths = route.get("contract_paths")
    if not isinstance(contract_paths, list):
        errors.append(f"{prefix}: contract_paths must be an array")
        contract_paths = []
    for relative in contract_paths:
        try:
            path = _contained(_text(relative), must_exist=True)
            contract = read_json(path)
            report = validate_contract(contract)
        except Exception as exc:
            errors.append(f"{prefix}: stream contract cannot be loaded: {type(exc).__name__}: {exc}")
            continue
        contracts.append({
            "path": _text(relative),
            "contract_id": contract.get("contract_id"),
            "status": report["status"],
            "admission_ready": report["admission_ready"],
            "contract_sha256": report["contract_sha256"],
            "errors": report["errors"],
            "cautions": report["cautions"],
        })
        errors.extend(f"{prefix}/{contract.get('contract_id')}: {item}" for item in report["errors"])
        cautions.extend(f"{prefix}/{contract.get('contract_id')}: {item}" for item in report["cautions"])
    if launch == "AVAILABLE_REVIEWED" and not contract_paths:
        errors.append(f"{prefix}: reviewed launch requires at least one frozen stream contract")
    if launch == "AVAILABLE_ALPHA" and not contract_paths:
        cautions.append(f"{prefix}: exact stream contracts are generated or locked later by the reviewed profile path")
    return errors, cautions, contracts


def validate_catalog(path: Path = DEFAULT_CATALOG) -> dict[str, Any]:
    errors: list[str] = []
    cautions: list[str] = []
    contract_reports: list[dict[str, Any]] = []
    try:
        catalog = load_catalog(path)
    except Exception as exc:
        return {
            "schema": REPORT_SCHEMA,
            "generated_utc": utc_now(),
            "status": "INELIGIBLE",
            "errors": [f"{type(exc).__name__}: {exc}"],
            "cautions": [],
            "adapter_count": 0,
            "route_count": 0,
            "contract_reports": [],
        }
    if not _text(catalog.get("version")):
        errors.append("Catalog version is required")
    if not isinstance(catalog.get("admission_ladder"), list):
        errors.append("Catalog admission_ladder is required")
    if not isinstance(catalog.get("lifecycle_states"), list):
        errors.append("Catalog lifecycle_states is required")
    if not _text(catalog.get("authority_boundary")):
        errors.append("Catalog authority_boundary is required")
    adapters = catalog.get("adapters")
    if not isinstance(adapters, list) or not adapters:
        errors.append("Catalog must contain adapters")
        adapters = []
    adapter_ids: set[str] = set()
    route_count = 0
    for row in adapters:
        if not isinstance(row, Mapping):
            errors.append("Adapter row is not an object")
            continue
        adapter_id = _text(row.get("adapter_id"))
        if not ID_RE.fullmatch(adapter_id):
            errors.append(f"{adapter_id or '?'}: invalid adapter_id")
        elif adapter_id in adapter_ids:
            errors.append(f"Duplicate adapter_id: {adapter_id}")
        adapter_ids.add(adapter_id)
        if not _text(row.get("display_name")):
            errors.append(f"{adapter_id or '?'}: display_name is required")
        if not isinstance(row.get("categories"), list) or not row.get("categories"):
            errors.append(f"{adapter_id or '?'}: categories are required")
        support = _text(row.get("support_state"))
        if support not in SUPPORT_STATES:
            errors.append(f"{adapter_id or '?'}: unsupported support_state {support or '<blank>'}")
        physical = _text(row.get("physical_validation"))
        if physical not in PHYSICAL_STATES:
            errors.append(f"{adapter_id or '?'}: unsupported physical_validation {physical or '<blank>'}")
        if row.get("runtime_authority") is not False:
            errors.append(f"{adapter_id or '?'}: runtime_authority must be false")
        if support == "HUMAN_CONNECTED_APPROVED" and physical != "HUMAN_CONNECTED":
            errors.append(f"{adapter_id or '?'}: human approval requires human-connected validation")
        source = row.get("source")
        if not isinstance(source, Mapping):
            errors.append(f"{adapter_id or '?'}: source provenance is required")
        elif _text(source.get("integration_policy")) not in INTEGRATION_POLICIES:
            errors.append(f"{adapter_id or '?'}: unsupported source integration policy")
        routes = row.get("routes")
        if not isinstance(routes, list) or not routes:
            errors.append(f"{adapter_id or '?'}: at least one route is required")
            continue
        route_ids: set[str] = set()
        for route in routes:
            route_count += 1
            if not isinstance(route, Mapping):
                errors.append(f"{adapter_id or '?'}: route is not an object")
                continue
            route_id = _text(route.get("route_id"))
            if route_id in route_ids:
                errors.append(f"{adapter_id or '?'}/{route_id}: duplicate route_id")
            route_ids.add(route_id)
            route_errors, route_cautions, contracts = _validate_route(row, route)
            errors.extend(route_errors)
            cautions.extend(route_cautions)
            contract_reports.extend(contracts)
    return {
        "schema": REPORT_SCHEMA,
        "generated_utc": utc_now(),
        "catalog_version": catalog.get("version"),
        "status": _status(errors, cautions),
        "errors": errors,
        "cautions": cautions,
        "adapter_count": len(adapters),
        "route_count": route_count,
        "contract_reports": contract_reports,
        "authority_boundary": catalog.get("authority_boundary"),
    }


def route_index(catalog: Mapping[str, Any]) -> dict[tuple[str, str], tuple[dict[str, Any], dict[str, Any]]]:
    result: dict[tuple[str, str], tuple[dict[str, Any], dict[str, Any]]] = {}
    for adapter in catalog.get("adapters", []):
        if not isinstance(adapter, Mapping):
            continue
        for route in adapter.get("routes", []):
            if isinstance(route, Mapping):
                result[(_text(adapter.get("adapter_id")), _text(route.get("route_id")))] = (dict(adapter), dict(route))
    return result


def adapter_doctor(
    adapter_id: str = "",
    route_id: str = "",
    *,
    catalog_path: Path = DEFAULT_CATALOG,
) -> dict[str, Any]:
    catalog_report = validate_catalog(catalog_path)
    catalog = load_catalog(catalog_path)
    rows = route_index(catalog)
    selected = [
        (key, value) for key, value in rows.items()
        if (not adapter_id or key[0] == adapter_id) and (not route_id or key[1] == route_id)
    ]
    results: list[dict[str, Any]] = []
    for (selected_adapter, selected_route), (adapter, route) in selected:
        errors: list[str] = []
        cautions: list[str] = []
        intake = _text(route.get("intake_mode"))
        script = _text(route.get("managed_script"))
        entry_path = ""
        if script:
            try:
                entry_path = str(_contained(script, must_exist=True))
            except Exception as exc:
                errors.append(f"Entry point unavailable: {exc}")
        if intake in {"EXTERNAL_LSL", "EXISTING_LSL"}:
            if importlib.util.find_spec("pylsl") is None:
                errors.append("pylsl is not installed in the selected Python environment")
        if selected_adapter == "polar_h10" and importlib.util.find_spec("bleak") is None:
            errors.append("bleak is not installed")
        if selected_adapter == "openbci_brainflow" and importlib.util.find_spec("brainflow") is None:
            errors.append("brainflow is not installed")
        if selected_adapter == "vernier_respiration" and importlib.util.find_spec("godirect") is None:
            errors.append("godirect is not installed")
        if intake == "EXTERNAL_LSL":
            cautions.append("The external publisher must be installed and started separately")
        if adapter.get("physical_validation") != "HUMAN_CONNECTED":
            cautions.append("This route is not human-connected approved")
        results.append({
            "adapter_id": selected_adapter,
            "route_id": selected_route,
            "display_name": route.get("display_name"),
            "status": _status(errors, cautions),
            "errors": errors,
            "cautions": cautions,
            "entry_path": entry_path,
            "intake_mode": intake,
            "launch_state": route.get("launch_state"),
            "physical_validation": adapter.get("physical_validation"),
        })
    top_errors: list[str] = []
    if not selected:
        top_errors.append("No adapter route matched the requested identifiers")
    if catalog_report["status"] == "INELIGIBLE":
        top_errors.append("The packaged adapter catalog is ineligible")
    statuses = {row["status"] for row in results}
    overall = "INELIGIBLE" if top_errors or "INELIGIBLE" in statuses else ("CAUTION" if "CAUTION" in statuses else "PASS")
    return {
        "schema": "PRAYCG_HardwareAdapterDoctor_v1_0",
        "generated_utc": utc_now(),
        "status": overall,
        "errors": top_errors,
        "routes": results,
        "catalog_validation": catalog_report,
        "boundary": "Doctor readiness does not establish physical validation or acquisition authority.",
    }


def build_launch_plan(
    adapter_id: str,
    route_id: str,
    *,
    run_uuid: str,
    catalog_path: Path = DEFAULT_CATALOG,
) -> dict[str, Any]:
    catalog = load_catalog(catalog_path)
    match = route_index(catalog).get((adapter_id, route_id))
    if match is None:
        raise ValueError(f"Unknown adapter route: {adapter_id}:{route_id}")
    adapter, route = match
    doctor = adapter_doctor(adapter_id, route_id, catalog_path=catalog_path)
    contract_reports = [
        row for row in doctor["catalog_validation"].get("contract_reports", [])
        if row.get("path") in route.get("contract_paths", [])
    ]
    return {
        "schema": PLAN_SCHEMA,
        "generated_utc": utc_now(),
        "run_uuid": run_uuid,
        "adapter_id": adapter_id,
        "route_id": route_id,
        "intake_mode": route.get("intake_mode"),
        "launch_state": route.get("launch_state"),
        "handler_key": route.get("handler_key"),
        "entry_path": doctor["routes"][0].get("entry_path") if doctor["routes"] else "",
        "canonical_roles": deepcopy(route.get("canonical_roles", [])),
        "stream_contracts": contract_reports,
        "doctor_status": doctor["status"],
        "runtime_authority": False,
        "required_lifecycle": ["STARTING", "READY", "STREAMING", "STOPPING", "RELEASED"],
        "restart_policy": "A process or LSL UID change creates a new acquisition segment.",
        "next_gate": "Use the reviewed Hardware Registry, physical preflight, session confirmation, and ARM path.",
        "forbidden_effects": ["SESSION_LOCK", "ARM", "PARTICIPANT_APPROVAL", "TRUST_PROMOTION"],
    }


def launch_gui(catalog_path: Path = DEFAULT_CATALOG) -> int:
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, simpledialog, ttk
    except Exception as exc:
        print(f"Tkinter unavailable: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    validation = validate_catalog(catalog_path)
    if validation["status"] == "INELIGIBLE":
        print(json.dumps(validation, indent=2), file=sys.stderr)
        return 4
    catalog = load_catalog(catalog_path)
    root = tk.Tk()
    root.title("PRAYCG Hardware Forge v1.0 — Alpha 9 Adapter Workbench")
    root.geometry("1180x760")
    ttk.Label(
        root,
        text=(
            "Select hardware by what you own. Managed PRAYCG bridges, external LSL publishers, and generic existing-LSL intake "
            "all converge on one stream-contract and validation path. Forge readiness never arms a participant session."
        ),
        foreground="#7a1e1e",
        wraplength=1140,
    ).pack(fill="x", padx=12, pady=10)
    tree = ttk.Treeview(
        root,
        columns=("support", "physical", "mode", "launch", "roles"),
        show="tree headings",
        height=16,
    )
    for key, title in (("#0", "Device / route"), ("support", "Support"), ("physical", "Physical"), ("mode", "Intake"), ("launch", "Launch"), ("roles", "Roles")):
        tree.heading(key, text=title)
    tree.column("#0", width=310)
    tree.column("roles", width=300)
    tree.pack(fill="both", expand=True, padx=12)
    lookup: dict[str, tuple[str, str | None]] = {}
    for adapter in catalog["adapters"]:
        parent = tree.insert(
            "", "end", text=adapter["display_name"],
            values=(adapter["support_state"], adapter["physical_validation"], "", "", ", ".join(adapter["categories"])),
        )
        lookup[parent] = (adapter["adapter_id"], None)
        for route in adapter["routes"]:
            child = tree.insert(
                parent, "end", text=route["display_name"],
                values=("", "", route["intake_mode"], route["launch_state"], ", ".join(route["canonical_roles"])),
            )
            lookup[child] = (adapter["adapter_id"], route["route_id"])
    detail = tk.Text(root, height=14, wrap="word", state="disabled")
    detail.pack(fill="both", expand=True, padx=12, pady=8)

    def selected_route() -> tuple[str, str] | None:
        selection = tree.selection()
        if not selection:
            return None
        adapter_id, route_id = lookup[selection[0]]
        return (adapter_id, route_id) if route_id else None

    def show_detail(_event: Any = None) -> None:
        selection = tree.selection()
        if not selection:
            return
        adapter_id, route_id = lookup[selection[0]]
        adapter = next(row for row in catalog["adapters"] if row["adapter_id"] == adapter_id)
        payload: Any = adapter if route_id is None else next(row for row in adapter["routes"] if row["route_id"] == route_id)
        detail.configure(state="normal")
        detail.delete("1.0", "end")
        detail.insert("1.0", json.dumps(payload, indent=2, ensure_ascii=False))
        detail.configure(state="disabled")

    def doctor_selected() -> None:
        pair = selected_route()
        if pair is None:
            messagebox.showinfo("Select a route", "Select a device route rather than only a device heading.", parent=root)
            return
        result = adapter_doctor(*pair, catalog_path=catalog_path)
        detail.configure(state="normal")
        detail.delete("1.0", "end")
        detail.insert("1.0", json.dumps(result, indent=2, ensure_ascii=False))
        detail.configure(state="disabled")

    def save_plan() -> None:
        pair = selected_route()
        if pair is None:
            messagebox.showinfo("Select a route", "Select one route first.", parent=root)
            return
        run_uuid = simpledialog.askstring("Equipment session", "Current equipment-session UUID:", parent=root)
        if not run_uuid:
            return
        output = filedialog.asksaveasfilename(
            title="Save non-authoritative adapter launch plan", defaultextension=".json",
            initialfile=f"{pair[0]}_{pair[1]}_launch_plan.json", filetypes=(("JSON", "*.json"),),
        )
        if not output:
            return
        write_json(Path(output), build_launch_plan(*pair, run_uuid=run_uuid, catalog_path=catalog_path))
        messagebox.showinfo("Plan saved", "The launch plan has no ARM or acquisition authority.", parent=root)

    def open_lsl_intake() -> None:
        import subprocess
        subprocess.Popen([sys.executable, str(STREAM_TOOL), "gui"], cwd=str(PACKAGE_ROOT))

    tree.bind("<<TreeviewSelect>>", show_detail)
    actions = ttk.Frame(root)
    actions.pack(fill="x", padx=12, pady=(0, 12))
    ttk.Button(actions, text="Run Adapter Doctor", command=doctor_selected).pack(side="left", padx=3)
    ttk.Button(actions, text="Save Launch Plan", command=save_plan).pack(side="left", padx=3)
    ttk.Button(actions, text="Discover Existing LSL", command=open_lsl_intake).pack(side="left", padx=3)
    ttk.Button(actions, text="Close", command=root.destroy).pack(side="right", padx=3)
    root.mainloop()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Hardware Forge v1.0 for Alpha 9")
    parser.add_argument("--catalog", type=Path, default=DEFAULT_CATALOG)
    sub = parser.add_subparsers(dest="action")
    sub.add_parser("gui")
    sub.add_parser("validate")
    listing = sub.add_parser("list")
    listing.add_argument("--adapter-id", default="")
    show = sub.add_parser("show")
    show.add_argument("adapter_id")
    doctor = sub.add_parser("doctor")
    doctor.add_argument("--adapter-id", default="")
    doctor.add_argument("--route-id", default="")
    plan = sub.add_parser("plan")
    plan.add_argument("adapter_id")
    plan.add_argument("route_id")
    plan.add_argument("--run-uuid", required=True)
    plan.add_argument("--out", type=Path)
    args = parser.parse_args(argv)
    if args.action in {None, "gui"}:
        return launch_gui(args.catalog)
    if args.action == "validate":
        result = validate_catalog(args.catalog)
    elif args.action == "doctor":
        result = adapter_doctor(args.adapter_id, args.route_id, catalog_path=args.catalog)
    elif args.action == "plan":
        result = build_launch_plan(args.adapter_id, args.route_id, run_uuid=args.run_uuid, catalog_path=args.catalog)
        if args.out:
            write_json(args.out, result)
    else:
        catalog = load_catalog(args.catalog)
        if args.action == "show":
            result = next((row for row in catalog["adapters"] if row.get("adapter_id") == args.adapter_id), None)
            if result is None:
                print(f"Unknown adapter: {args.adapter_id}", file=sys.stderr)
                return 2
        else:
            result = []
            for (adapter_id, route_id), (adapter, route) in route_index(catalog).items():
                if args.adapter_id and adapter_id != args.adapter_id:
                    continue
                result.append({
                    "adapter_id": adapter_id,
                    "route_id": route_id,
                    "display_name": route.get("display_name"),
                    "support_state": adapter.get("support_state"),
                    "physical_validation": adapter.get("physical_validation"),
                    "intake_mode": route.get("intake_mode"),
                    "launch_state": route.get("launch_state"),
                    "canonical_roles": route.get("canonical_roles"),
                })
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if not isinstance(result, dict) or result.get("status") in {None, "PASS", "CAUTION"} else 4


if __name__ == "__main__":
    raise SystemExit(main())
