# PRAYCG Master Comprehensive Suite v1.6.1

This remains the current cumulative v1.6.1 analysis component bundled with **PRAYCG Control Center v1.0.0-alpha.4**. The core analysis frame remains v1.6.0; v1.6.1 updates chained provenance, visualization, and offline interpretation. Alpha.4 adds a non-authoritative module-catalog foundation without changing those analytical methods. Carried alpha.2-named evidence schemas remain compatibility contracts.

## Current entry points

- Core suite/GUI: `scripts/praycg_master_comprehensive_suite_v1_6_0.py`
- Dependency-aware chained analysis: `scripts/praycg_chain_runner_v1_6_1.py`
- Master Sync Visualizer: `scripts/praycg_master_sync_visualizer_v1_4_0.py`
- Deterministic artifact index: `scripts/praycg_artifact_index_v1_0.py`
- Manifest-driven Offline Interpreter: `scripts/praycg_offline_interpretive_report_generator_v1_6_0.py`
- Expanded confound modules: `scripts/praycg_confound_expanded_modules_v1_5_7.py`
- ALS barcode detector: `scripts/praycg_als_barcode_detector_v1_5_8.py`
- ShotOrder HOC-R: `scripts/praycg_shotorder_hocr_module_v1_6_0.py`

The core first writes `tables/praycg_analysis_frame_v1_6_0.csv`, its schema JSON, run eligibility, stream-selection provenance, and Baseline 2 summaries. Run the v1.6.1 chain only on a completed v1.6.0 core output. The chain stages inputs in a new workspace and never modifies the source analysis folder. It publishes the module-state manifest and artifact index before interpretation so gated or partial files cannot be promoted by filename alone.

## Alpha.4 analysis workflow

1. Select and resolve the recorded run folder in **Analysis Modules**. Review the chosen XDF, event log, channel map, cue schedule, anchors, media manifest, and timing grade; automatic discovery does not resolve genuine ambiguity.
2. Click **1. Open Master Suite**, then use **Run Analysis** inside that suite to create the canonical v1.6.0 feature/QC output.
3. Review that output and, for a run tracked by the alpha.4 session gate, use **Record QC Evidence** to bind the reviewed artifact's path, size, and SHA-256.
4. Select or refresh the matching core output and click **2. Run Full Chain**. The full chain consumes the compatible core result; it is not a replacement for **Run Analysis**.
5. Review the chained outputs, then use **Record Analysis Evidence** when appropriate. The Control Center revalidates the active session lock and its externally bound artifacts before advancing either gate.

The evidence buttons record that a named operator reviewed a byte-identifiable artifact. They do not certify the analysis, repair missing inputs, or promote exploratory results. If an authorized runner was interrupted while its runtime lock remains at `ACQUIRE`, **Finalize Interrupted Run** can record a reviewed incomplete artifact and reason; it does not label that run complete.

## Common module outcomes

- `PASS`: the module's declared primary gate passed.
- `FAIL_PRIMARY_GATE`: required data existed, but the primary scientific/QC gate failed.
- `NOT_GRADABLE_MISSING_INPUT`: a required file, anchor, column, or stream was unavailable.
- `NOT_APPLICABLE_PROTOCOL`: the current protocol did not include the relevant branch.
- `EXPLORATORY_ONLY`: computation completed, but the result is not a strict pass.
- `SOFTWARE_ERROR`: the module failed because of a software/runtime fault.

Missing measurements remain undefined. Nyquist-ineligible bands remain unavailable. ShotOrder HOC-R and all other proxy/confound modules are audit tools; their outputs do not certify an endpoint, mechanism, diagnosis, consciousness state, or biological interpretation.
