# Micro Handoff v0.1

Exploratory raw-EEG module for a prespecified temporal-gamma-to-theta micro-handoff candidate.

This remains the v0.1 exploratory component bundled with **PRAYCG Control Center v1.0.0-alpha.4**. The component version records its scientific/software candidate lineage; it is not a superseded Control Center workflow label.

## Boundaries

- Not a consciousness detector, probability, clinical output, or proof of 40 Hz frames.
- Separate from CAI/SID v0.2 and the Master Suite primary chain.
- A 25 ms output cadence is not 25 ms spectral resolution.
- Historical results are retrospective, condition-order-confounded, and primarily single-participant.

## Main commands

```text
python scripts/praycg_micro_handoff_v0_1.py --xdf RUN.xdf --segments-csv segments_used.csv --out OUTPUT
python scripts/generate_synthetic_micro_handoff_v0_1.py --out examples/synthetic_known_lag
python scripts/praycg_micro_handoff_historical_batch_v0_1.py --core-audit core_output_audit.csv --out-root OUTPUT
python scripts/praycg_micro_handoff_gui_v0_1.py --gui
```

The single-run command writes readiness, 25 ms feature/state series, full lag series, branch summaries, contrasts, null results, QC, provenance, and a human-readable report. The historical batch runner inventories every recording and analyzes only eligible runs.

The alpha.4 **Analysis Modules** workspace launches the same GUI from its isolated **Exploratory Analysis** section and automatically supplies the selected run, resolved XDF when available, preferred analysis folder, and a run-specific output folder. Review every resolved input before running; ambiguous or missing evidence remains unresolved.

The registration boundary explicitly prevents Micro Handoff from changing Master Suite eligibility or primary conclusions. Its results also do not advance the canonical QC/analysis gates merely because the computation completed. A synthetic PASS demonstrates expected software behavior on the synthetic case only; it does not validate the construct, cortical origin, or historical inference.
