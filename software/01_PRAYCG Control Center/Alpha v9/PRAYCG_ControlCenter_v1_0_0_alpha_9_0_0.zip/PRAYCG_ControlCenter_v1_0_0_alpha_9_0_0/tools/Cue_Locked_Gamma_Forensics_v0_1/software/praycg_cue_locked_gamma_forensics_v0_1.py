from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from typing import Any, Iterable

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pyxdf
from scipy import signal, stats


MODULE_VERSION = "0.1.0"
CUE_RE = re.compile(r"^(TARGET_1|CONTEXTUAL_OVERRIDE_1|OVERRIDE_1)_CUE_(\d+)_VALUE_([^_]+)_START$")
RATING_RE = re.compile(r"^RATING_(TARGET|OVERRIDE)_1_AFTER_WASHOUT_\d+_(?:CONFOUND_REPORT_|OVERRIDE_TASK_REPORT_)?(.+)_(-?\d+(?:\.\d+)?)$")
PHASES = ("TARGET_1", "CONTEXTUAL_OVERRIDE_1")
EPS = np.finfo(float).tiny


def scalar(value: Any, default: Any = "") -> Any:
    while isinstance(value, list) and len(value) == 1:
        value = value[0]
    return default if value is None else value


def marker_text(value: Any) -> str:
    if isinstance(value, np.ndarray):
        value = value.tolist()
    if isinstance(value, (list, tuple)):
        return str(value[0]) if value else ""
    return str(value)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def finite(values: Iterable[float]) -> np.ndarray:
    x = np.asarray(list(values), dtype=float)
    return x[np.isfinite(x)]


def fmt(value: Any, digits: int = 3) -> str:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return "NA"
    return f"{x:.{digits}f}" if math.isfinite(x) else "NA"


def ci_text(point: Any, low: Any, high: Any, digits: int = 3) -> str:
    return f"{fmt(point, digits)} [{fmt(low, digits)}, {fmt(high, digits)}]"


def bootstrap_stat(
    values: np.ndarray,
    rng: np.random.Generator,
    iterations: int,
    statistic=np.nanmedian,
    block_length: int = 1,
) -> tuple[float, float, float]:
    x = finite(values)
    if x.size == 0:
        return math.nan, math.nan, math.nan
    point = float(statistic(x))
    if x.size < 3:
        return point, math.nan, math.nan
    draws = np.empty(iterations, dtype=float)
    block_length = max(1, min(int(block_length), x.size))
    for i in range(iterations):
        if block_length == 1:
            sample = rng.choice(x, size=x.size, replace=True)
        else:
            n_blocks = int(math.ceil(x.size / block_length))
            starts = rng.integers(0, x.size, size=n_blocks)
            sample = np.concatenate(
                [
                    x[
                        (
                            np.arange(start, start + block_length)
                            % x.size
                        )
                    ]
                    for start in starts
                ]
            )[: x.size]
        draws[i] = statistic(sample)
    return point, float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))


def channel_labels(
    info: dict[str, Any], fallback: list[str], n_ch: int
) -> tuple[list[str], str]:
    try:
        channels = info["desc"][0]["channels"][0]["channel"]
        labels = [str(scalar(item.get("label"), "")) for item in channels]
        if len(labels) >= n_ch and all(labels[:n_ch]):
            return labels[:n_ch], "CONFIRMED_XDF_METADATA"
    except Exception:
        pass
    if n_ch == len(fallback):
        return fallback.copy(), "LEGACY_FIXED_ORDER_ASSUMED"
    return [f"Ch{i + 1}" for i in range(n_ch)], "UNKNOWN_CHANNEL_ORDER"


def choose_stream(
    streams: list[dict[str, Any]],
    *,
    name: str | None = None,
    stype: str | None = None,
    min_channels: int = 0,
) -> dict[str, Any] | None:
    found = []
    for stream in streams:
        info = stream.get("info", {})
        sname = str(scalar(info.get("name"), ""))
        typ = str(scalar(info.get("type"), ""))
        data = np.asarray(stream.get("time_series", []))
        channels = data.shape[1] if data.ndim == 2 else (1 if data.size else 0)
        if name is not None and sname != name:
            continue
        if stype is not None and typ.lower() != stype.lower():
            continue
        if channels < min_channels:
            continue
        found.append(stream)
    return max(found, key=lambda s: len(s.get("time_stamps", []))) if found else None


def load_xdf(path: Path) -> list[dict[str, Any]]:
    streams, _ = pyxdf.load_xdf(
        str(path),
        synchronize_clocks=False,
        dejitter_timestamps=False,
        verbose=False,
    )
    return streams


def parse_cues_and_context(
    streams: list[dict[str, Any]],
) -> tuple[pd.DataFrame, dict[str, tuple[float, float]], list[dict[str, Any]]]:
    cues: list[dict[str, Any]] = []
    starts: dict[str, float] = {}
    ends: dict[str, float] = {}
    ratings: list[dict[str, Any]] = []
    for stream in streams:
        info = stream.get("info", {})
        name = str(scalar(info.get("name"), ""))
        typ = str(scalar(info.get("type"), ""))
        try:
            fs = float(scalar(info.get("nominal_srate"), 0) or 0)
        except Exception:
            fs = 0.0
        if not (fs == 0 or "marker" in name.lower() or "marker" in typ.lower()):
            continue
        for stamp, sample in zip(
            stream.get("time_stamps", []), stream.get("time_series", [])
        ):
            text = marker_text(sample)
            match = CUE_RE.match(text)
            if match:
                phase = (
                    "CONTEXTUAL_OVERRIDE_1"
                    if match.group(1) == "OVERRIDE_1"
                    else match.group(1)
                )
                cues.append(
                    {
                        "phase": phase,
                        "cue_index": int(match.group(2)),
                        "cue_value": match.group(3),
                        "cue_lsl_time": float(stamp),
                        "cue_source": f"xdf_marker:{name}",
                    }
                )
            if text in {
                "TARGET_1_START",
                "CONTEXTUAL_OVERRIDE_1_START",
                "OVERRIDE_1_START",
            }:
                phase = (
                    "CONTEXTUAL_OVERRIDE_1"
                    if text.startswith("OVERRIDE")
                    else text.removesuffix("_START")
                )
                starts[phase] = float(stamp)
            if text in {
                "TARGET_1_END",
                "CONTEXTUAL_OVERRIDE_1_END",
                "OVERRIDE_1_END",
            }:
                phase = (
                    "CONTEXTUAL_OVERRIDE_1"
                    if text.startswith("OVERRIDE")
                    else text.removesuffix("_END")
                )
                ends[phase] = float(stamp)
            rating = RATING_RE.match(text)
            if rating:
                ratings.append(
                    {
                        "phase": (
                            "TARGET_1"
                            if rating.group(1) == "TARGET"
                            else "CONTEXTUAL_OVERRIDE_1"
                        ),
                        "rating": rating.group(2),
                        "value": float(rating.group(3)),
                    }
                )
    bounds = {
        phase: (starts[phase], ends[phase]) for phase in starts.keys() & ends.keys()
    }
    cue_df = pd.DataFrame(cues)
    if not cue_df.empty:
        cue_df = (
            cue_df.drop_duplicates(["phase", "cue_index", "cue_lsl_time"])
            .sort_values(["phase", "cue_index"])
            .reset_index(drop=True)
        )
    return cue_df, bounds, ratings


def load_external_cues(audit_root: Path, run_label: str) -> pd.DataFrame:
    path = (
        audit_root
        / "03_DataRuns"
        / "PRAYCG_DataRuns_InAHeartbeat_to_FieldOfDreams_MasterPack_v1_0"
        / "03_CROSS_RUN_ANALYSES"
        / "combined_ocm_025_cue_epoch_table.csv"
    )
    if not path.exists():
        return pd.DataFrame()
    use = pd.read_csv(
        path,
        usecols=[
            "run",
            "phase",
            "cue_index",
            "cue_value",
            "cue_lsl_time",
            "cue_source",
        ],
    )
    use = use[(use["run"] == run_label) & (use["phase"].isin(PHASES))].copy()
    return (
        use.drop(columns=["run"])
        .drop_duplicates(["phase", "cue_index"])
        .sort_values(["phase", "cue_index"])
        .reset_index(drop=True)
    )


def preprocess(data: np.ndarray) -> np.ndarray:
    x = np.asarray(data, dtype=float).copy()
    for col in range(x.shape[1]):
        values = x[:, col]
        good = np.isfinite(values)
        med = float(np.median(values[good])) if np.any(good) else 0.0
        values[~good] = med
        x[:, col] = values - med
    return x


def bandpass(x: np.ndarray, fs: float, low: float, high: float) -> np.ndarray:
    sos = signal.butter(
        4, [low, high], btype="bandpass", fs=fs, output="sos"
    )
    return signal.sosfiltfilt(sos, x, axis=0)


def interval_indices(ts: np.ndarray, start: float, end: float) -> np.ndarray:
    return np.flatnonzero((ts >= start) & (ts < end))


def log_power(
    arr: np.ndarray, idx: np.ndarray, channels: list[int]
) -> float:
    if idx.size == 0 or not channels:
        return math.nan
    value = float(np.nanmean(np.square(arr[np.ix_(idx, channels)])))
    return 10.0 * math.log10(max(value, EPS))


def log_peak_to_peak(arr: np.ndarray, idx: np.ndarray) -> float:
    if idx.size == 0:
        return math.nan
    segment = arr[idx, :]
    p2p = np.nanmedian(
        np.nanmax(segment, axis=0) - np.nanmin(segment, axis=0)
    )
    return 20.0 * math.log10(max(float(p2p), EPS))


def epoch_features(
    run_id: str,
    run_label: str,
    cues: pd.DataFrame,
    ts: np.ndarray,
    raw: np.ndarray,
    gamma: np.ndarray,
    guard: np.ndarray,
    roi_indices: dict[str, list[int]],
    labels: list[str],
    config: dict[str, Any],
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    fs = float(config["sampling_rate_hz"])
    windows = config["windows_sec"]
    rows: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    time_rows: list[dict[str, Any]] = []
    expected_total = sum((b - a) * fs for a, b in windows.values())
    for cue in cues.to_dict("records"):
        t0 = float(cue["cue_lsl_time"])
        indices = {
            name: interval_indices(ts, t0 + float(a), t0 + float(b))
            for name, (a, b) in windows.items()
        }
        coverage = (
            sum(len(v) for v in indices.values()) / expected_total
            if expected_total
            else 0.0
        )
        full = interval_indices(ts, t0 - 0.70, t0 + 2.85)
        max_gap = (
            float(np.max(np.diff(ts[full]))) if full.size >= 2 else math.inf
        )
        reasons = []
        for name, (a, b) in windows.items():
            need = 0.65 * (float(b) - float(a)) * fs
            if len(indices[name]) < need:
                reasons.append(f"LOW_{name.upper()}_COVERAGE")
        if max_gap > 0.50:
            reasons.append("GAP_OVER_500MS")
        base = {
            "run_id": run_id,
            "run_label": run_label,
            "phase": cue["phase"],
            "cue_index": int(cue["cue_index"]),
            "cue_value": cue.get("cue_value", ""),
            "cue_lsl_time": t0,
            "cue_source": cue.get("cue_source", ""),
            "coverage_fraction": coverage,
            "max_gap_sec": max_gap,
            "valid": not reasons,
            "exclusion_reason": ";".join(reasons),
        }
        if reasons:
            excluded.append(base.copy())
        for roi, chans in roi_indices.items():
            for window, idx in indices.items():
                base[f"{roi}_gamma_{window}"] = log_power(
                    gamma, idx, chans
                )
                base[f"{roi}_guard_{window}"] = log_power(
                    guard, idx, chans
                )
            base[f"{roi}_gamma_delta"] = (
                base[f"{roi}_gamma_early"] - base[f"{roi}_gamma_pre"]
            )
            base[f"{roi}_guard_delta"] = (
                base[f"{roi}_guard_early"] - base[f"{roi}_guard_pre"]
            )
        for channel_index, label in enumerate(labels):
            base[f"channel_{label}_gamma_delta"] = (
                log_power(gamma, indices["early"], [channel_index])
                - log_power(gamma, indices["pre"], [channel_index])
            )
        base["global_log_p2p_pre"] = log_peak_to_peak(
            raw, indices["pre"]
        )
        base["global_log_p2p_early"] = log_peak_to_peak(
            raw, indices["early"]
        )
        base["global_log_p2p_delta"] = (
            base["global_log_p2p_early"] - base["global_log_p2p_pre"]
        )
        base["perimeter_minus_central_gamma_delta"] = (
            base["perimeter_gamma_delta"]
            - base["central_midline_gamma_delta"]
        )
        rows.append(base)

        for center in np.arange(-0.65, 2.851, 0.10):
            idx = interval_indices(
                ts, t0 + center - 0.10, t0 + center + 0.10
            )
            if len(idx) < 0.65 * 0.20 * fs:
                continue
            for roi in (
                "central_midline",
                "jaw_temporal",
                "ocular_frontal",
                "perimeter",
            ):
                time_rows.append(
                    {
                        "run_id": run_id,
                        "run_label": run_label,
                        "phase": cue["phase"],
                        "cue_index": int(cue["cue_index"]),
                        "time_sec": round(float(center), 3),
                        "roi": roi,
                        "gamma_db": log_power(
                            gamma, idx, roi_indices[roi]
                        ),
                        "guard_db": log_power(
                            guard, idx, roi_indices[roi]
                        ),
                        "cue_valid": not reasons,
                    }
                )
    return (
        pd.DataFrame(rows),
        pd.DataFrame(excluded),
        pd.DataFrame(time_rows),
    )


def paired_vectors(
    cues: pd.DataFrame, metric: str
) -> tuple[np.ndarray, pd.DataFrame]:
    valid = cues[cues["valid"]].copy()
    pivot = valid.pivot_table(
        index="cue_index", columns="phase", values=metric, aggfunc="first"
    )
    if not all(phase in pivot.columns for phase in PHASES):
        return np.asarray([], dtype=float), pd.DataFrame()
    pivot = pivot.dropna(subset=list(PHASES))
    return (
        (
            pivot["CONTEXTUAL_OVERRIDE_1"] - pivot["TARGET_1"]
        ).to_numpy(float),
        pivot,
    )


def paired_summaries(
    cues: pd.DataFrame,
    run_id: str,
    run_label: str,
    config: dict[str, Any],
    rng: np.random.Generator,
) -> pd.DataFrame:
    metrics = []
    for roi in config["rois"]:
        metrics.extend(
            [f"{roi}_gamma_delta", f"{roi}_guard_delta"]
        )
    metrics.extend(
        [
            "global_log_p2p_delta",
            "perimeter_minus_central_gamma_delta",
        ]
    )
    rows = []
    for metric in metrics:
        values, _ = paired_vectors(cues, metric)
        point, low, high = bootstrap_stat(
            values,
            rng,
            int(config["bootstrap_iterations"]),
            block_length=10,
        )
        p = math.nan
        if values.size:
            observed = abs(float(np.nanmedian(values)))
            null = []
            for _ in range(int(config["null_iterations"])):
                n_blocks = int(math.ceil(values.size / 10))
                signs = np.repeat(
                    rng.choice([-1.0, 1.0], size=n_blocks),
                    10,
                )[: values.size]
                null.append(
                    abs(float(np.nanmedian(values * signs)))
                )
            p = (1 + sum(v >= observed for v in null)) / (
                len(null) + 1
            )
        rows.append(
            {
                "run_id": run_id,
                "run_label": run_label,
                "metric": metric,
                "n_pairs": int(values.size),
                "override_minus_target_median": point,
                "bootstrap_ci95_low": low,
                "bootstrap_ci95_high": high,
                "sign_flip_p_two_sided": p,
                "multiplicity_adjusted": False,
            }
        )
    return pd.DataFrame(rows)


def artifact_adjustment(
    cues: pd.DataFrame, rng: np.random.Generator, iterations: int
) -> dict[str, Any]:
    cols = [
        "central_midline_gamma_delta",
        "jaw_temporal_guard_delta",
        "ocular_frontal_gamma_delta",
        "global_log_p2p_delta",
    ]
    data = cues[
        cues["valid"] & cues["phase"].isin(PHASES)
    ][["cue_index", "phase", *cols]].dropna()
    counts = data.groupby("cue_index")["phase"].nunique()
    keep = counts[counts == 2].index
    data = data[data["cue_index"].isin(keep)].copy()
    if data["cue_index"].nunique() < 10:
        return {
            "n_pairs": int(data["cue_index"].nunique()),
            "unadjusted_beta_db": math.nan,
            "adjusted_beta_db": math.nan,
            "attenuation_fraction": math.nan,
            "adjusted_ci_low": math.nan,
            "adjusted_ci_high": math.nan,
        }

    def fit(frame: pd.DataFrame) -> tuple[float, float]:
        y = frame[cols[0]].to_numpy(float)
        condition = (
            frame["phase"] == "CONTEXTUAL_OVERRIDE_1"
        ).to_numpy(float)
        zcols = []
        for col in cols[1:]:
            x = frame[col].to_numpy(float)
            sd = np.std(x, ddof=1)
            zcols.append(
                (x - np.mean(x)) / sd
                if sd > 1e-12
                else np.zeros_like(x)
            )
        xu = np.column_stack([np.ones(len(frame)), condition])
        xa = np.column_stack(
            [np.ones(len(frame)), condition, *zcols]
        )
        return (
            float(np.linalg.lstsq(xu, y, rcond=None)[0][1]),
            float(np.linalg.lstsq(xa, y, rcond=None)[0][1]),
        )

    unadjusted, adjusted = fit(data)
    pair_ids = np.asarray(sorted(keep), dtype=int)
    boot = []
    for _ in range(iterations):
        block_length = min(10, len(pair_ids))
        starts = rng.integers(
            0,
            len(pair_ids),
            size=int(math.ceil(len(pair_ids) / block_length)),
        )
        selected = np.concatenate(
            [
                pair_ids[
                    (
                        np.arange(start, start + block_length)
                        % len(pair_ids)
                    )
                ]
                for start in starts
            ]
        )[: len(pair_ids)]
        frames = []
        for new_id, old_id in enumerate(selected):
            part = data[data["cue_index"] == old_id].copy()
            part["cue_index"] = new_id
            frames.append(part)
        _, beta = fit(pd.concat(frames, ignore_index=True))
        boot.append(beta)
    attenuation = (
        1.0 - adjusted / unadjusted
        if abs(unadjusted) > 1e-12
        and np.sign(adjusted) == np.sign(unadjusted)
        else math.nan
    )
    return {
        "n_pairs": int(len(pair_ids)),
        "unadjusted_beta_db": unadjusted,
        "adjusted_beta_db": adjusted,
        "attenuation_fraction": attenuation,
        "adjusted_ci_low": float(np.quantile(boot, 0.025)),
        "adjusted_ci_high": float(np.quantile(boot, 0.975)),
    }


def timecourse_summary(
    trial_time: pd.DataFrame,
    config: dict[str, Any],
    rng: np.random.Generator,
) -> pd.DataFrame:
    rows = []
    if trial_time.empty or "cue_valid" not in trial_time.columns:
        return pd.DataFrame()
    use = trial_time[trial_time["cue_valid"]].copy()
    baseline = (
        use[use["time_sec"] < -0.10]
        .groupby(
            ["run_id", "phase", "cue_index", "roi"],
            as_index=False,
        )["gamma_db"]
        .median()
        .rename(columns={"gamma_db": "cue_baseline_db"})
    )
    use = use.merge(
        baseline,
        on=["run_id", "phase", "cue_index", "roi"],
        how="left",
    )
    use["gamma_change_db"] = (
        use["gamma_db"] - use["cue_baseline_db"]
    )
    keys = ["run_id", "run_label", "phase", "roi", "time_sec"]
    for values, group in use.groupby(keys, sort=True):
        point, low, high = bootstrap_stat(
            group.sort_values("cue_index")[
                "gamma_change_db"
            ].to_numpy(float),
            rng,
            int(config["bootstrap_iterations"]),
            block_length=10,
        )
        row = dict(zip(keys, values))
        row.update(
            {
                "n_cues": len(group),
                "median_gamma_db": point,
                "ci95_low": low,
                "ci95_high": high,
            }
        )
        rows.append(row)
    pair_keys = ["run_id", "run_label", "roi", "time_sec"]
    pivot = use.pivot_table(
        index=[
            "run_id",
            "run_label",
            "roi",
            "time_sec",
            "cue_index",
        ],
        columns="phase",
        values="gamma_change_db",
        aggfunc="first",
    ).reset_index()
    if all(phase in pivot.columns for phase in PHASES):
        pivot["paired_difference"] = (
            pivot["CONTEXTUAL_OVERRIDE_1"]
            - pivot["TARGET_1"]
        )
        for values, group in pivot.groupby(
            pair_keys, sort=True
        ):
            point, low, high = bootstrap_stat(
                group.sort_values("cue_index")[
                    "paired_difference"
                ].to_numpy(float),
                rng,
                int(config["bootstrap_iterations"]),
                block_length=10,
            )
            row = dict(zip(pair_keys, values))
            row.update(
                {
                    "phase": "OVERRIDE_MINUS_TARGET",
                    "n_cues": int(
                        np.isfinite(
                            group["paired_difference"]
                        ).sum()
                    ),
                    "median_gamma_db": point,
                    "ci95_low": low,
                    "ci95_high": high,
                }
            )
            rows.append(row)
    return pd.DataFrame(rows)


def peak_summary(timecourse: pd.DataFrame) -> pd.DataFrame:
    if timecourse.empty:
        return pd.DataFrame()
    use = timecourse[
        (timecourse["phase"] == "OVERRIDE_MINUS_TARGET")
        & (timecourse["time_sec"] >= 0.0)
        & (timecourse["time_sec"] <= 0.80)
    ].copy()
    rows = []
    for (run_id, run_label, roi), group in use.groupby(
        ["run_id", "run_label", "roi"]
    ):
        valid = group.dropna(subset=["median_gamma_db"])
        if valid.empty:
            continue
        peak = valid.loc[valid["median_gamma_db"].idxmax()]
        rows.append(
            {
                "run_id": run_id,
                "run_label": run_label,
                "roi": roi,
                "peak_search_window_sec": "0.00-0.80",
                "peak_time_sec": float(peak["time_sec"]),
                "peak_override_minus_target_db": float(
                    peak["median_gamma_db"]
                ),
                "peak_ci95_low": float(peak["ci95_low"]),
                "peak_ci95_high": float(peak["ci95_high"]),
                "inside_proposed_200_400ms_window": bool(
                    0.20 <= float(peak["time_sec"]) <= 0.40
                ),
                "selection_note": (
                    "Peak selected after inspecting 0-0.8 s; its "
                    "pointwise interval is not selection-adjusted."
                ),
            }
        )
    return pd.DataFrame(rows)


def topography_summary(
    cues: pd.DataFrame,
    labels: list[str],
    run_id: str,
    run_label: str,
    config: dict[str, Any],
    rng: np.random.Generator,
) -> pd.DataFrame:
    rows = []
    for label in labels:
        metric = f"channel_{label}_gamma_delta"
        values, _ = paired_vectors(cues, metric)
        point, low, high = bootstrap_stat(
            values,
            rng,
            int(config["bootstrap_iterations"]),
            block_length=10,
        )
        rows.append(
            {
                "run_id": run_id,
                "run_label": run_label,
                "channel": label,
                "n_pairs": len(values),
                "override_minus_target_gamma_db": point,
                "ci95_low": low,
                "ci95_high": high,
            }
        )
    return pd.DataFrame(rows)


def aperiodic_summary(
    raw: np.ndarray,
    ts: np.ndarray,
    bounds: dict[str, tuple[float, float]],
    roi_indices: dict[str, list[int]],
    run_id: str,
    run_label: str,
    fs: float,
) -> pd.DataFrame:
    rows = []
    for phase in PHASES:
        if phase not in bounds:
            continue
        idx = interval_indices(
            ts, bounds[phase][0], bounds[phase][1]
        )
        if len(idx) < 20 * fs:
            continue
        nperseg = int(4 * fs)
        freq, psd = signal.welch(
            raw[idx, :],
            fs=fs,
            nperseg=nperseg,
            noverlap=nperseg // 2,
            axis=0,
            detrend="linear",
        )
        for roi, channels in roi_indices.items():
            spectrum = np.nanmedian(psd[:, channels], axis=1)
            fit_mask = (
                (freq >= 5)
                & (freq <= 55)
                & ~((freq >= 7.5) & (freq <= 14))
                & ~((freq >= 28) & (freq <= 47))
            )
            if np.sum(fit_mask) < 8:
                continue
            x = np.log10(freq[fit_mask])
            y = np.log10(np.maximum(spectrum[fit_mask], EPS))
            slope, intercept, _, _ = stats.theilslopes(y, x)
            residual = np.log10(np.maximum(spectrum, EPS)) - (
                intercept
                + slope * np.log10(np.maximum(freq, EPS))
            )
            gamma_mask = (freq >= 30) & (freq <= 45)
            guard_mask = (freq >= 45) & (freq <= 55)
            rows.append(
                {
                    "run_id": run_id,
                    "run_label": run_label,
                    "phase": phase,
                    "roi": roi,
                    "n_samples": len(idx),
                    "aperiodic_exponent": -float(slope),
                    "periodic_gamma_residual_log10": float(
                        np.nanmean(residual[gamma_mask])
                    ),
                    "guard_residual_log10": float(
                        np.nanmean(residual[guard_mask])
                    ),
                    "fit_frequency_hz": (
                        "5-55; excluding 7.5-14 and 28-47"
                    ),
                }
            )
    return pd.DataFrame(rows)


def phase_grid_series(
    ts: np.ndarray, values: np.ndarray, start: float, end: float
) -> tuple[np.ndarray, np.ndarray]:
    grid = np.arange(math.ceil(start), math.floor(end), 1.0)
    out = np.full(len(grid), np.nan)
    for i, second in enumerate(grid):
        idx = interval_indices(ts, second, second + 1.0)
        if len(idx) >= 20:
            out[i] = float(np.nanmean(values[idx]))
    return grid, out


def autonomic_coupling(
    streams: list[dict[str, Any]],
    eeg_ts: np.ndarray,
    central_gamma: np.ndarray,
    bounds: dict[str, tuple[float, float]],
    run_id: str,
    run_label: str,
    rng: np.random.Generator,
    null_iterations: int,
) -> dict[str, Any]:
    polar = choose_stream(streams, name="PolarHRV")
    if polar is None or len(polar.get("time_stamps", [])) < 60:
        return {
            "run_id": run_id,
            "run_label": run_label,
            "status": "UNAVAILABLE_NO_POLAR",
            "n_seconds": 0,
        }
    beat_t = np.asarray(polar["time_stamps"], dtype=float)
    rr = np.asarray(polar["time_series"], dtype=float).reshape(-1)
    good = (
        np.isfinite(beat_t)
        & np.isfinite(rr)
        & (rr > 0)
    )
    beat_t, rr = beat_t[good], rr[good]
    median_rr = float(np.median(rr)) if rr.size else math.nan
    if median_rr > 100:
        hr = 60000.0 / rr
    elif median_rr < 5:
        hr = 60.0 / rr
    else:
        return {
            "run_id": run_id,
            "run_label": run_label,
            "status": "UNAVAILABLE_UNKNOWN_RR_UNITS",
            "n_seconds": 0,
        }

    phase_arrays = []
    for phase in PHASES:
        if phase not in bounds:
            continue
        grid, gamma = phase_grid_series(
            eeg_ts, central_gamma, *bounds[phase]
        )
        if len(grid) < 60:
            continue
        h = np.interp(
            grid + 0.5,
            beat_t,
            hr,
            left=np.nan,
            right=np.nan,
        )
        valid = np.isfinite(gamma) & np.isfinite(h)
        if valid.sum() < 45:
            continue
        g = signal.detrend(gamma[valid])
        hv = signal.detrend(h[valid])
        g = (g - np.mean(g)) / max(np.std(g), EPS)
        hv = (hv - np.mean(hv)) / max(np.std(hv), EPS)
        phase_arrays.append((g, hv))
    if not phase_arrays:
        return {
            "run_id": run_id,
            "run_label": run_label,
            "status": "UNAVAILABLE_INSUFFICIENT_OVERLAP",
            "n_seconds": 0,
        }

    lags = np.arange(-10, 11, 1)

    def lag_correlations(arrays):
        out = []
        for lag in lags:
            gs, hs = [], []
            for g, h in arrays:
                if lag < 0:
                    gs.extend(g[-lag:])
                    hs.extend(h[:lag])
                elif lag > 0:
                    gs.extend(g[:-lag])
                    hs.extend(h[lag:])
                else:
                    gs.extend(g)
                    hs.extend(h)
            out.append(
                float(np.corrcoef(gs, hs)[0, 1])
                if len(gs) >= 60
                else math.nan
            )
        return np.asarray(out)

    observed = lag_correlations(phase_arrays)
    if not np.any(np.isfinite(observed)):
        return {
            "run_id": run_id,
            "run_label": run_label,
            "status": "UNAVAILABLE_INSUFFICIENT_OVERLAP",
            "n_seconds": 0,
        }
    best_i = int(np.nanargmax(np.abs(observed)))
    obs_max = abs(float(observed[best_i]))
    null = []
    for _ in range(null_iterations):
        shifted = []
        for g, h in phase_arrays:
            if len(h) > 70:
                shift = int(rng.integers(30, len(h) - 29))
            else:
                shift = int(rng.integers(1, len(h)))
            shifted.append((g, np.roll(h, shift)))
        null.append(
            float(np.nanmax(np.abs(lag_correlations(shifted))))
        )
    p = (1 + sum(value >= obs_max for value in null)) / (
        len(null) + 1
    )
    return {
        "run_id": run_id,
        "run_label": run_label,
        "status": "AVAILABLE_EXPLORATORY",
        "n_seconds": int(sum(len(g) for g, _ in phase_arrays)),
        "best_lag_sec_hr_relative_to_gamma": int(lags[best_i]),
        "best_r": float(observed[best_i]),
        "circular_shift_maxlag_p": p,
        "interpretive_boundary": (
            "Condition-detrended HR coupling is nonspecific and cannot "
            "identify EEG artifact or direction of causation."
        ),
    }


def context_row(
    run_id: str,
    run_label: str,
    cues: pd.DataFrame,
    streams: list[dict[str, Any]],
    ratings: list[dict[str, Any]],
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "run_id": run_id,
        "run_label": run_label,
    }
    for phase in PHASES:
        stamps = (
            np.sort(
                cues.loc[
                    cues["phase"] == phase, "cue_lsl_time"
                ].to_numpy(float)
            )
            if not cues.empty
            else np.asarray([])
        )
        row[f"{phase}_cue_count"] = len(stamps)
        row[f"{phase}_median_interval_sec"] = (
            float(np.median(np.diff(stamps)))
            if len(stamps) > 1
            else math.nan
        )
    stream_names = [
        str(scalar(s.get("info", {}).get("name"), ""))
        for s in streams
    ]
    row["gaze_stream_available"] = any(
        "gaze" in name.lower() or "eye" in name.lower()
        for name in stream_names
    )
    row["osa_status"] = (
        "GAZE_AVAILABLE_REVIEW_REQUIRED"
        if row["gaze_stream_available"]
        else "SPATIAL_ATTENTION_UNRESOLVED_NO_GAZE"
    )
    row["aam_status"] = "KEPT_SEPARATE_ACTIVE_BLOCK_ONLY"
    keep_ratings = {
        "NumberCueDistraction",
        "AnalyticEffort",
        "TaskCompliance",
        "OverrideLeakage",
        "StoryActiveWashout",
        "EmotionalAfterglow",
    }
    for item in ratings:
        if item["rating"] in keep_ratings:
            row[f"{item['phase']}_{item['rating']}"] = (
                item["value"]
            )
    return row


def evidence_label(
    summary: dict[str, Any],
    timing_grade: str,
    minimum_pairs: int,
) -> tuple[str, list[str]]:
    if (
        int(summary.get("n_pairs", 0)) < minimum_pairs
        or not timing_grade.startswith("PASS")
    ):
        return (
            "INDETERMINATE_TIMING_OR_COVERAGE",
            [
                f"timing_grade={timing_grade}",
                f"n_pairs={summary.get('n_pairs', 0)}",
            ],
        )
    central = summary.get("central_midline_gamma")
    direct = []
    for key in (
        "jaw_temporal_gamma",
        "jaw_temporal_guard",
        "ocular_frontal_gamma",
        "global_log_p2p",
        "perimeter_minus_central_gamma",
    ):
        item = summary.get(key, {})
        if (
            math.isfinite(float(item.get("low", math.nan)))
            and float(item["low"]) > 0
        ):
            direct.append(key)
    attenuation = float(
        summary.get("attenuation_fraction", math.nan)
    )
    central_positive = (
        central
        and math.isfinite(float(central.get("low", math.nan)))
        and float(central["low"]) > 0
    )
    if (
        central_positive
        and len(direct) >= 2
        and math.isfinite(attenuation)
        and attenuation >= 0.50
    ):
        return (
            "ARTIFACT_PATTERN_SUPPORTED",
            [
                "target-adjusted central gamma increased",
                "direct artifact-compatible fields="
                + ",".join(direct),
                f"artifact-covariate attenuation={attenuation:.2f}",
            ],
        )
    if (
        central_positive
        and not direct
        and math.isfinite(attenuation)
        and attenuation <= 0.20
    ):
        return (
            "NEURAL_COMPATIBLE_NOT_ESTABLISHED",
            [
                "target-adjusted central gamma increased",
                "no direct artifact field had a positive descriptive "
                "95% bootstrap interval",
                f"artifact-covariate attenuation={attenuation:.2f}",
            ],
        )
    reasons = [
        "forensic fields did not meet either conservative convergence rule"
    ]
    if central_positive:
        reasons.append(
            "central gamma increase present but source evidence remained mixed"
        )
    if direct:
        reasons.append(
            "artifact-compatible fields=" + ",".join(direct)
        )
    return "INDETERMINATE", reasons


def metric_dict(
    paired: pd.DataFrame, metric: str
) -> dict[str, float]:
    part = paired[paired["metric"] == metric]
    if part.empty:
        return {
            "point": math.nan,
            "low": math.nan,
            "high": math.nan,
            "n": 0,
        }
    row = part.iloc[0]
    return {
        "point": float(row["override_minus_target_median"]),
        "low": float(row["bootstrap_ci95_low"]),
        "high": float(row["bootstrap_ci95_high"]),
        "n": int(row["n_pairs"]),
    }


def plot_topography(
    topography: pd.DataFrame, out_path: Path, title: str
) -> None:
    coords = {
        "Fp1": (-0.38, 0.92),
        "F3": (-0.42, 0.55),
        "Fz": (0, 0.62),
        "F4": (0.42, 0.55),
        "T3": (-0.90, 0.18),
        "C3": (-0.48, 0.05),
        "Cz": (0, 0.05),
        "C4": (0.48, 0.05),
        "T4": (0.90, 0.18),
        "T5": (-0.78, -0.42),
        "P3": (-0.40, -0.48),
        "Pz": (0, -0.55),
        "P4": (0.40, -0.48),
        "T6": (0.78, -0.42),
        "O1": (-0.30, -0.88),
        "O2": (0.30, -0.88),
    }
    values = (
        topography.set_index("channel")[
            "override_minus_target_gamma_db"
        ].to_dict()
    )
    vmax = max(
        [
            abs(v)
            for v in values.values()
            if math.isfinite(v)
        ]
        + [0.1]
    )
    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    head = plt.Circle(
        (0, 0),
        1.03,
        facecolor="#f7f7f7",
        edgecolor="#333333",
        lw=2,
    )
    ax.add_patch(head)
    ax.plot(
        [-0.12, 0, 0.12],
        [1.02, 1.16, 1.02],
        color="#333333",
        lw=2,
    )
    for ch, (x, y) in coords.items():
        value = values.get(ch, math.nan)
        color = (
            plt.cm.coolwarm((value + vmax) / (2 * vmax))
            if math.isfinite(value)
            else "#bbbbbb"
        )
        ax.scatter(
            [x],
            [y],
            s=520,
            c=[color],
            edgecolors="#222222",
            linewidths=1.2,
            zorder=3,
        )
        ax.text(
            x, y, ch, ha="center", va="center", fontsize=9, zorder=4
        )
    sm = plt.cm.ScalarMappable(
        cmap="coolwarm", norm=plt.Normalize(-vmax, vmax)
    )
    sm.set_array([])
    fig.colorbar(
        sm,
        ax=ax,
        shrink=0.72,
        label="Override - Target early gamma change (dB)",
    )
    ax.set_title(
        title
        + "\nElectrode-level values; no source localization or interpolation"
    )
    ax.set(
        xlim=(-1.25, 1.25),
        ylim=(-1.18, 1.25),
        aspect="equal",
    )
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(out_path, dpi=170, bbox_inches="tight")
    plt.close(fig)


def plot_timecourse(
    summary: pd.DataFrame, out_path: Path, title: str
) -> None:
    fig, axes = plt.subplots(
        2, 2, figsize=(11, 7), sharex=True
    )
    rois = [
        "central_midline",
        "jaw_temporal",
        "ocular_frontal",
        "perimeter",
    ]
    for panel_index, (ax, roi) in enumerate(
        zip(axes.flat, rois)
    ):
        part = summary[summary["roi"] == roi]
        for phase, color in [
            ("TARGET_1", "#2878B5"),
            ("CONTEXTUAL_OVERRIDE_1", "#D1495B"),
            ("OVERRIDE_MINUS_TARGET", "#222222"),
        ]:
            line = part[part["phase"] == phase].sort_values(
                "time_sec"
            )
            if line.empty:
                continue
            x = line["time_sec"].to_numpy(float)
            median = line["median_gamma_db"].to_numpy(float)
            low = line["ci95_low"].to_numpy(float)
            high = line["ci95_high"].to_numpy(float)
            ax.plot(
                x,
                median,
                color=color,
                label=phase.replace("CONTEXTUAL_", ""),
                linestyle=(
                    "--"
                    if phase == "OVERRIDE_MINUS_TARGET"
                    else "-"
                ),
            )
            if phase != "OVERRIDE_MINUS_TARGET":
                ax.fill_between(
                    x, low, high, color=color, alpha=0.16
                )
        ax.axvline(0, color="#333333", lw=1, ls="--")
        ax.axvspan(0.2, 0.4, color="#F2C14E", alpha=0.18)
        ax.set_title(roi.replace("_", " ").title())
        ax.grid(alpha=0.2)
    axes[-1, 0].set_xlabel("Seconds from cue")
    axes[-1, 1].set_xlabel("Seconds from cue")
    fig.supylabel(
        "Baseline-referenced 30-45 Hz change (dB)", x=0.015
    )
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.885),
        ncol=3,
    )
    fig.suptitle(
        title
        + "\nShading: pointwise descriptive 95% moving-block-bootstrap intervals",
        y=0.985,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.82))
    fig.savefig(out_path, dpi=170, bbox_inches="tight")
    plt.close(fig)


def plot_forest(
    run_summary: pd.DataFrame, out_path: Path
) -> None:
    use = run_summary[run_summary["n_pairs"] >= 20].copy()
    fig, ax = plt.subplots(
        figsize=(10, max(4.5, 0.7 * len(use)))
    )
    y = np.arange(len(use))
    fields = [
        (
            -0.18,
            "central_midline_gamma",
            "#2878B5",
            "central/midline 30-45",
        ),
        (
            0,
            "jaw_temporal_gamma",
            "#D1495B",
            "T3/T4 30-45",
        ),
        (
            0.18,
            "jaw_temporal_guard",
            "#F28E2B",
            "T3/T4 45-55",
        ),
    ]
    for offset, stem, color, label in fields:
        point = use[f"{stem}_point"].to_numpy(float)
        low = use[f"{stem}_low"].to_numpy(float)
        high = use[f"{stem}_high"].to_numpy(float)
        ax.errorbar(
            point,
            y + offset,
            xerr=np.vstack([point - low, high - point]),
            fmt="o",
            color=color,
            capsize=3,
            label=label,
        )
    ax.axvline(0, color="#333333", ls="--")
    ax.set_yticks(y, use["run_label"])
    ax.set_xlabel(
        "Override - Target early cue response change (dB)"
    )
    ax.set_title(
        "Cue-locked gamma forensics: run-level descriptive effects"
    )
    ax.grid(axis="x", alpha=0.25)
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(out_path, dpi=170, bbox_inches="tight")
    plt.close(fig)


def write_report(
    out_dir: Path,
    config: dict[str, Any],
    eligibility: pd.DataFrame,
    run_summary: pd.DataFrame,
    aper: pd.DataFrame,
    auto: pd.DataFrame,
    context: pd.DataFrame,
    source_hashes: pd.DataFrame,
    peaks: pd.DataFrame,
) -> None:
    minimum = int(config["minimum_paired_cues"])
    analyzed = run_summary[run_summary["n_pairs"] >= minimum]
    passed_timing = analyzed[
        analyzed["timing_grade"].str.startswith("PASS")
    ]
    lines = [
        "# PRAYCG Cue-Locked Gamma Forensics: Detailed Historical Report",
        "",
        f"**Module:** v{MODULE_VERSION}  ",
        "**Analysis date:** 2026-09-10  ",
        (
            "**Status:** exploratory secondary confound analysis; "
            "not a new primary score  "
        ),
        (
            "**Scope:** OCM temporal cue-locking extended with OSA "
            "spatial-attention checks, AAM separation, spectral guard "
            "bands/aperiodic sensitivity, amplitude sentinels, actual-"
            "montage topography, and a separate HR-coupling sensitivity."
        ),
        "",
        "## Bottom line",
        "",
        (
            f"The archive contained {len(eligibility)} unique XDF "
            f"recordings. {len(run_summary)} recordings reached feature "
            f"extraction, {len(analyzed)} had at least {minimum} paired "
            f"Target/Override cues, and {len(passed_timing)} of those also "
            "had a PASS sub-second timing grade."
        ),
        "",
    ]
    if not run_summary.empty:
        counts = run_summary["forensic_label"].value_counts().to_dict()
        lines.append(
            "Descriptive labels across extracted runs: "
            + ", ".join(
                f"{key} = {value}" for key, value in counts.items()
            )
            + "."
        )
        lines.append("")
        main_quality = run_summary[
            run_summary["eligibility_status"]
            == "ELIGIBLE_MAIN_FORENSICS"
        ]
        positive_central = main_quality[
            main_quality["central_midline_gamma_low"] > 0
        ]
        artifact_labeled = main_quality[
            main_quality["forensic_label"]
            == "ARTIFACT_PATTERN_SUPPORTED"
        ]
        lines.append(
            f"Among the {len(main_quality)} main-quality runs, "
            f"{len(positive_central)} showed a positive Target-adjusted "
            "central/midline 30-45 Hz change whose descriptive interval "
            f"excluded zero, and {len(artifact_labeled)} met the "
            "conservative artifact-pattern rule. Thus this pass does not "
            "establish a repeatable cue-locked task-gamma increase, a "
            "craniofacial source, or a cortical source."
        )
        lines.append("")
    lines.extend(
        [
            (
                "These data do not permit a categorical brain-versus-face "
                "verdict. A positive central 30-45 Hz effect is not "
                "automatically neural; a peripheral or 45-55 Hz effect is "
                "not automatically muscle. Separate evidence fields are "
                "reported, with conservative descriptive triage labels. "
                "Nothing here alters OCM, CAI/SID, MRED, Master Suite "
                "eligibility, or a prior primary conclusion."
            ),
            "",
            "![Run-level forensic effects](figures/combined_run_effects.png)",
            "",
            "## Applicability audit",
            "",
            (
                "A recording was applicable to the main contrast only when "
                "it contained EEG, identifiable Override cue onsets, matched "
                "same-media Target epochs, at least 20 valid pairs, and defensible "
                "sub-second alignment. Runs with weaker timing are retained "
                "as sensitivity analyses. Runs without cue markers or a "
                "uniquely matched external event log were not reconstructed "
                "from filenames alone."
            ),
            "",
            (
                "| XDF | Assigned run | EEG samples | Matched Target epochs | Override cues | "
                "Valid pairs | Timing | Status |"
            ),
            "|---|---|---:|---:|---:|---:|---|---|",
        ]
    )
    for row in eligibility.to_dict("records"):
        fields = []
        for key in [
            "eeg_samples",
            "target_cues",
            "override_cues",
            "valid_pairs",
        ]:
            value = row[key]
            fields.append("not assessed" if pd.isna(value) else str(int(value)))
        lines.append(
            f"| {row['run_id']} | {row['run_label']} | "
            f"{fields[0]} | {fields[1]} | "
            f"{fields[2]} | {fields[3]} | "
            f"{row['timing_grade']} | {row['eligibility_status']} |"
        )
    lines.extend(
        [
            "",
            "## Methods and equations",
            "",
            "### 1. Cue-locked signal definition",
            "",
            (
                "For channel set (ROI) R, band-pass filtered signal "
                "x(c,B,t), and window W, log band power was:"
            ),
            "",
            (
                r"$$L_{R,B}(W)=10\log_{10}\left("
                r"\frac{1}{|R||W|}\sum_{c\in R}\sum_{t\in W}"
                r"x_{c,B}(t)^2+\epsilon\right).$$"
            ),
            "",
            "The per-cue response was a baseline-referenced change:",
            "",
            (
                r"$$\Delta_{R,B,i}=L_{R,B,i}(0.15,0.45)"
                r"-L_{R,B,i}(-0.70,-0.10).$$"
            ),
            "",
            (
                "The 150-450 ms window tests the proposed 200-400 ms "
                "cue-linked transient while allowing modest display/response "
                "jitter. The report also retains later windows and a 100 ms-"
                "step time course. A 30-45 Hz Butterworth band was the target; "
                "45-55 Hz was the only valid above-target guard band because "
                "125 Hz sampling has a 62.5 Hz Nyquist frequency. The "
                "suggested 70-100 Hz check is mathematically impossible in "
                "these recordings."
            ),
            "",
            "### 2. Same-media Target adjustment",
            "",
            (
                "Target displayed the same narrative and cue schedule while "
                "instructing the participant to ignore the numbers; Override "
                "used the same media but required arithmetic. For cue index i:"
            ),
            "",
            (
                r"$$D_{R,B,i}=\Delta^{Override}_{R,B,i}"
                r"-\Delta^{Target}_{R,B,i}.$$"
            ),
            "",
            (
                r"The reported run effect is $\operatorname{median}_i"
                r"(D_{R,B,i})$. Descriptive 95% intervals use a circular "
                "moving-block bootstrap of 10 consecutive cues (about 30 "
                "seconds), preserving short-range serial dependence. The "
                "sign-flip null assigns one sign to each 10-cue block. "
                "Sign-flip p-values are unadjusted diagnostics, "
                "not confirmatory tests. No cross-run p-value is computed "
                "because these are repeated self-runs, not independent "
                "participants."
            ),
            "",
            "### 3. Artifact-covariate sensitivity",
            "",
            (
                "A pooled within-run sensitivity regression estimated the "
                "Override coefficient before and after including T3/T4 "
                "45-55 Hz change, Fp1 30-45 Hz change, and global log "
                "peak-to-peak change:"
            ),
            "",
            (
                r"$$y_i=\beta_0+\beta_O I(Override)_i+\gamma_1J_i"
                r"+\gamma_2E_i+\gamma_3A_i+\varepsilon_i.$$"
            ),
            "",
            (
                r"When unadjusted and adjusted coefficients had the same "
                r"sign, attenuation was $1-\beta_{O,adjusted}/"
                r"\beta_{O,unadjusted}$. This is a sensitivity analysis, "
                "not proof that the covariates are pure artifact: T3/T4 and "
                "Fp1 can contain neural activity, and regression can remove "
                "shared neural variance."
            ),
            "",
            "### 4. Aperiodic sensitivity",
            "",
            (
                "Welch spectra were fit in log-log coordinates with a robust "
                "Theil-Sen line:"
            ),
            "",
            (
                r"$$\log_{10}P(f)=b-\chi\log_{10}f+e(f).$$"
            ),
            "",
            (
                "The fit used 5-55 Hz while excluding 7.5-14 Hz and "
                "28-47 Hz. Gamma residuals are mean residual e(f) in "
                "30-45 Hz. This separates a narrowband-compatible residual "
                "from a broadband slope/offset change only approximately; "
                "it is not spectral source localization."
            ),
            "",
            "### 5. Spatial and autonomic checks",
            "",
            (
                "Electrode maps display measured channels only: no "
                "interpolated scalp field and no inverse solution. The actual "
                "montage was Fz, Cz, Pz, F3/F4, C3/C4, P3/P4, T5/T6, "
                "O1/O2, T3/T4, and Fp1; it does not contain Fp2, F7/F8, "
                "or modern T7/T8 labels."
            ),
            "",
            (
                "The autonomic panel detrends HR and central gamma within "
                "each phase, searches lags from -10 to +10 seconds, and "
                "compares the maximum absolute correlation with circular-"
                "shift nulls. It remains nonspecific and separate from the "
                "cue label."
            ),
            "",
            "## Run-level results",
            "",
            (
                "Values are Override minus Target median cue changes in dB "
                "with descriptive moving-block-bootstrap intervals. For "
                f"runs below the {minimum}-pair eligibility threshold, "
                "intervals are computational diagnostics only and must not "
                "be interpreted inferentially."
            ),
            "",
            (
                "| Run | Pairs | Central 30-45 | Central peak (s) | "
                "T3/T4 30-45 | T3/T4 45-55 | Fp1 30-45 | P2P | "
                "Attenuation | Label |"
            ),
            "|---|---:|---|---:|---|---|---|---|---:|---|",
        ]
    )
    for row in run_summary.to_dict("records"):
        lines.append(
            f"| {row['run_label']} | {row['n_pairs']} | "
            f"{ci_text(row['central_midline_gamma_point'], row['central_midline_gamma_low'], row['central_midline_gamma_high'])} | "
            f"{fmt(row.get('central_midline_peak_time_sec'))} | "
            f"{ci_text(row['jaw_temporal_gamma_point'], row['jaw_temporal_gamma_low'], row['jaw_temporal_gamma_high'])} | "
            f"{ci_text(row['jaw_temporal_guard_point'], row['jaw_temporal_guard_low'], row['jaw_temporal_guard_high'])} | "
            f"{ci_text(row['ocular_frontal_gamma_point'], row['ocular_frontal_gamma_low'], row['ocular_frontal_gamma_high'])} | "
            f"{ci_text(row['global_log_p2p_point'], row['global_log_p2p_low'], row['global_log_p2p_high'])} | "
            f"{fmt(row['attenuation_fraction'], 2)} | "
            f"{row['forensic_label']} |"
        )
    lines.append("")
    main_ids = set(
        run_summary.loc[
            run_summary["eligibility_status"]
            == "ELIGIBLE_MAIN_FORENSICS",
            "run_id",
        ].astype(str)
    )
    central_peaks = peaks[
        peaks["run_id"].astype(str).isin(main_ids)
        & (peaks["roi"] == "central_midline")
    ].copy()
    n_inside = int(
        central_peaks["peak_time_sec"].between(0.20, 0.40).sum()
    )
    n_positive = int(
        (central_peaks["peak_ci95_low"] > 0).sum()
    )
    lines.extend(
        [
            "### Temporal-lock result",
            "",
            (
                f"Among the {len(central_peaks)} main-quality runs, "
                f"{n_inside} had their largest positive central/midline "
                "Override-minus-Target point between 0.20 and 0.40 seconds. "
                f"However, {n_positive} of those selected pointwise intervals "
                "excluded zero. Because the peak was chosen after inspecting "
                "the 0-0.8-second search interval and the intervals are not "
                "selection-adjusted, the recurring latency is only a "
                "prospective hypothesis; it is not evidence of a reliable "
                "cue-locked response in this archive."
            ),
            "",
        ]
    )
    for row in run_summary.to_dict("records"):
        slug = re.sub(
            r"[^A-Za-z0-9]+", "_", row["run_label"]
        ).strip("_")
        lines.extend(
            [
                f"### {row['run_label']} ({row['run_id']})",
                "",
                (
                    f"- Eligibility: {row['eligibility_status']}; timing: "
                    f"{row['timing_grade']}; paired cues: {row['n_pairs']}."
                ),
                (
                    "- Central/midline 30-45 Hz: "
                    + ci_text(
                        row["central_midline_gamma_point"],
                        row["central_midline_gamma_low"],
                        row["central_midline_gamma_high"],
                    )
                    + " dB."
                ),
                (
                    "- T3/T4 gamma: "
                    + ci_text(
                        row["jaw_temporal_gamma_point"],
                        row["jaw_temporal_gamma_low"],
                        row["jaw_temporal_gamma_high"],
                    )
                    + " dB; T3/T4 guard band: "
                    + ci_text(
                        row["jaw_temporal_guard_point"],
                        row["jaw_temporal_guard_low"],
                        row["jaw_temporal_guard_high"],
                    )
                    + " dB."
                ),
                (
                    "- Fp1 gamma: "
                    + ci_text(
                        row["ocular_frontal_gamma_point"],
                        row["ocular_frontal_gamma_low"],
                        row["ocular_frontal_gamma_high"],
                    )
                    + " dB; global log peak-to-peak: "
                    + ci_text(
                        row["global_log_p2p_point"],
                        row["global_log_p2p_low"],
                        row["global_log_p2p_high"],
                    )
                    + " dB."
                ),
                (
                    "- Artifact-covariate adjustment: unadjusted beta="
                    f"{fmt(row['unadjusted_beta_db'])} dB, adjusted beta="
                    f"{fmt(row['adjusted_beta_db'])} dB, attenuation="
                    f"{fmt(row['attenuation_fraction'], 2)}."
                ),
                (
                    "- Target-adjusted central time-course peak within the "
                    "post-cue 0-0.8 s search: "
                    f"{fmt(row.get('central_midline_peak_time_sec'))} s "
                    f"at {fmt(row.get('central_midline_peak_db'))} dB. "
                    "This selected peak has no selection-adjusted interval."
                ),
                (
                    f"- Triage: {row['forensic_label']} - "
                    f"{row['forensic_reasons']}."
                ),
                (
                    f"- Figures: [cue time course](figures/{slug}_timecourse.png) "
                    f"and [electrode map](figures/{slug}_topography.png)."
                    if (
                        (out_dir / "figures" / f"{slug}_timecourse.png").exists()
                        and (out_dir / "figures" / f"{slug}_topography.png").exists()
                    )
                    else "- Figures: not generated because no valid cue time course was available."
                ),
                "",
            ]
        )
    lines.extend(
        [
            "## OSA and AAM interpretation",
            "",
            (
                "All analyzed cue-bearing runs used an approximately three-"
                "second cadence. No gaze/eye-tracking stream was found. OSA "
                "therefore remains unresolved: Fp1, T3/T4, timing, and peak-"
                "to-peak sentinels can show an artifact-compatible pattern, "
                "but cannot prove that the participant made a saccade or "
                "identify gaze position. The matched Target epochs control "
                "the underlying movie and approximate time-within-movie, but "
                "Target did not display the arithmetic cue. Consequently, "
                "Override-minus-Target still conflates cue visibility, visual "
                "orienting/saccades, arithmetic operations, effort, and any "
                "associated postural or facial response. A prospective "
                "non-task visual-cue control is needed to separate these."
            ),
            "",
            (
                "AAM is deliberately not folded into the cue result. Cue "
                "epochs are restricted to active Target and Override blocks. "
                "Post-washout afterglow, story-active-washout, and override-"
                "leakage ratings are contextual descriptors, not covariates "
                "used to rescue or invalidate a 200-400 ms gamma response. "
                "This prevents a slow carryover construct from being mistaken "
                "for a millisecond artifact detector."
            ),
            "",
            (
                "| Run | Target interval | Override interval | Gaze | "
                "OSA | AAM handling |"
            ),
            "|---|---:|---:|---|---|---|",
        ]
    )
    for row in context.to_dict("records"):
        lines.append(
            f"| {row['run_label']} | "
            f"{fmt(row.get('TARGET_1_median_interval_sec'))} | "
            f"{fmt(row.get('CONTEXTUAL_OVERRIDE_1_median_interval_sec'))} | "
            f"{row['gaze_stream_available']} | {row['osa_status']} | "
            f"{row['aam_status']} |"
        )
    lines.extend(
        [
            "",
            "## Autonomic sensitivity",
            "",
            (
                "| Run | Status | Seconds | Best HR lag | r | "
                "max-lag null p |"
            ),
            "|---|---|---:|---:|---:|---:|",
        ]
    )
    for row in auto.to_dict("records"):
        lines.append(
            f"| {row['run_label']} | {row['status']} | "
            f"{row.get('n_seconds', 0)} | "
            f"{fmt(row.get('best_lag_sec_hr_relative_to_gamma'), 0)} | "
            f"{fmt(row.get('best_r'))} | "
            f"{fmt(row.get('circular_shift_maxlag_p'))} |"
        )
    lines.extend(
        [
            "",
            (
                "A large HR-gamma correlation would not show that gamma is "
                "muscle. Cognitive effort can jointly alter central activity, "
                "facial tension, respiration, and HR; HR is also much slower "
                "than a 200-400 ms eye movement. These results are a separate "
                "stress/arousal sensitivity panel only."
            ),
            "",
            "## Aperiodic and spectral interpretation",
            "",
        ]
    )
    if aper.empty:
        lines.append("No phase met spectral coverage requirements.")
    else:
        central = (
            aper[aper["roi"] == "central_midline"]
            .pivot_table(
                index=["run_id", "run_label"],
                columns="phase",
                values=[
                    "aperiodic_exponent",
                    "periodic_gamma_residual_log10",
                ],
                aggfunc="first",
            )
        )
        lines.extend(
            [
                "| Run | Delta aperiodic exponent | "
                "Delta gamma residual (log10) |",
                "|---|---:|---:|",
            ]
        )
        for (_, run_label), row in central.iterrows():
            try:
                expdiff = (
                    row[
                        (
                            "aperiodic_exponent",
                            "CONTEXTUAL_OVERRIDE_1",
                        )
                    ]
                    - row[("aperiodic_exponent", "TARGET_1")]
                )
                resdiff = (
                    row[
                        (
                            "periodic_gamma_residual_log10",
                            "CONTEXTUAL_OVERRIDE_1",
                        )
                    ]
                    - row[
                        (
                            "periodic_gamma_residual_log10",
                            "TARGET_1",
                        )
                    ]
                )
            except KeyError:
                expdiff = resdiff = math.nan
            lines.append(
                f"| {run_label} | {fmt(expdiff)} | {fmt(resdiff)} |"
            )
    lines.extend(
        [
            "",
            "## Cross-run inference and limitations",
            "",
            (
                "1. These are repeated self-runs with different stimuli and "
                "operational histories. Cue pairs within a run are not "
                "independent subjects; intervals quantify cue-to-cue "
                "stability only."
            ),
            (
                "2. The analysis was conceived after outcomes existed. It is "
                "diagnostic and hypothesis-generating, not preregistered "
                "confirmation."
            ),
            (
                "3. Fp1 is one frontal channel, and T3/T4 are mixed neural/"
                "cranial sites. There is no bipolar EOG, chin/temporalis EMG, "
                "eye tracker, or source localization."
            ),
            (
                "4. A 125 Hz rate prevents the 70-100 Hz slingshot test. The "
                "45-55 Hz guard band is useful but narrower and closer to "
                "line-frequency contamination."
            ),
            (
                "5. Timing grades matter. Reconstructed or weak ALS timing "
                "cannot support a precise 200-400 ms peak claim even when a "
                "broader condition contrast remains inspectable."
            ),
            (
                "6. Multiple forensic fields were inspected. Pointwise "
                "intervals and p-values are not multiplicity-corrected and "
                "are not discovery tests."
            ),
            (
                "7. A smooth or central scalp pattern is only neural-"
                "compatible. Volume conduction, reference choice, and "
                "spatially diffuse EMG can mimic it; genuine cortex can also "
                "project to perimeter electrodes."
            ),
            "",
            "## Decision for the historical archive",
            "",
            (
                "The cue-locked extension should remain an exploratory OCM/"
                "OSA/AAM confound panel. It can identify recordings that "
                "deserve stronger artifact caution and specify prospective "
                "acquisition requirements. It should not become a new "
                "primary score, retroactively change a run's primary endpoint, "
                "or be used to declare a consciousness mechanism."
            ),
            "",
            (
                "For a prospective test, add bipolar horizontal and vertical "
                "EOG, temporalis/masseter EMG, a verified photodiode/ALS cue-"
                "onset barcode, and preferably a rate high enough to evaluate "
                "a clean above-70 Hz guard band. Predeclare the cue window, "
                "Target adjustment, artifact rule, and multiplicity handling "
                "before outcome inspection."
            ),
            "",
            "## Reproducibility",
            "",
            (
                f"- Source XDF hashes checked: {len(source_hashes)}."
            ),
            "- Complete numeric outputs are in tables/; figures are in figures/.",
            "- No raw XDF or existing analysis output was modified.",
            "",
            "## Scientific references",
            "",
            (
                "- Whitham et al., scalp EMG contamination above 20 Hz: "
                "https://pubmed.ncbi.nlm.nih.gov/17574912/"
            ),
            (
                "- Muthukumaraswamy, separating gamma, muscle, and "
                "microsaccade activity: "
                "https://pmc.ncbi.nlm.nih.gov/articles/PMC3706727/"
            ),
            (
                "- Donoghue et al., periodic and aperiodic spectral "
                "parameterization: "
                "https://www.nature.com/articles/s41593-020-00744-x"
            ),
            (
                "- Goncharova et al., cranial/facial EMG spectral and "
                "topographic contamination: "
                "https://pubmed.ncbi.nlm.nih.gov/12948787/"
            ),
        ]
    )
    (out_dir / "PRAYCG_CueLocked_Gamma_Forensics_Detailed_Report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def self_test(
    out_dir: Path, config: dict[str, Any]
) -> dict[str, Any]:
    rng = np.random.default_rng(12345)
    n = 200
    target = rng.normal(0, 0.35, n)
    override = target + 1.0 + rng.normal(0, 0.15, n)
    paired = override - target
    point, low, high = bootstrap_stat(
        paired, rng, 1000, block_length=10
    )
    direction_pass = point > 0.8 and low > 0
    signs = rng.choice([-1.0, 1.0], size=(1000, n))
    null = np.median(paired[None, :] * signs, axis=1)
    null_pass = abs(float(np.mean(null))) < 0.08
    missing = paired.copy()
    missing[:20] = np.nan
    missing_pass = (
        bootstrap_stat(
            missing, rng, 200, block_length=10
        )[0]
        > 0.8
    )
    result = {
        "module_version": MODULE_VERSION,
        "synthetic_direction_recovered": bool(direction_pass),
        "sign_flip_null_centered": bool(null_pass),
        "missing_values_excluded_not_zero_filled": bool(missing_pass),
        "synthetic_effect_median": point,
        "synthetic_ci95": [low, high],
        "pass": bool(
            direction_pass and null_pass and missing_pass
        ),
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "synthetic_validation.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-audit", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--config",
        type=Path,
        default=(
            Path(__file__).resolve().parents[1]
            / "config"
            / "cue_locked_gamma_forensics_v0_1.json"
        ),
    )
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    config = json.loads(
        args.config.read_text(encoding="utf-8")
    )
    args.out.mkdir(parents=True, exist_ok=True)
    if args.self_test:
        result = self_test(args.out, config)
        print(json.dumps(result, indent=2))
        return 0 if result["pass"] else 1
    if args.data_audit is None:
        parser.error(
            "--data-audit is required unless --self-test is used"
        )

    tables = args.out / "tables"
    figures = args.out / "figures"
    logs = args.out / "logs"
    for directory in (tables, figures, logs):
        directory.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(int(config["random_seed"]))
    inventory_path = (
        args.data_audit
        / "07_Analysis_Outputs"
        / "00_Inventory"
        / "unique_xdf_files.csv"
    )
    inventory = pd.read_csv(inventory_path)
    overrides = config["run_overrides"]
    eligibility_rows = []
    all_cues = []
    all_excluded = []
    all_time_trials = []
    all_time_summary = []
    all_peaks = []
    all_paired = []
    all_topo = []
    all_aper = []
    all_auto = []
    all_context = []
    run_summaries = []
    source_hashes = []

    for inv in inventory.to_dict("records"):
        run_id = inv["unique_xdf_id"]
        spec = overrides.get(run_id, {})
        run_label = spec.get(
            "run_label", run_id + "_Unmapped"
        )
        timing_grade = spec.get(
            "timing_grade",
            "INELIGIBLE_NO_CUE_ONSET_PROVENANCE",
        )
        xdf_path = Path(inv["canonical_path"])
        source_hashes.append(
            {
                "run_id": run_id,
                "file_name": inv["file_name"],
                "sha256": inv["actual_sha256"],
                "hash_verified_by_prior_audit": bool(
                    inv["hash_verified"]
                ),
            }
        )
        if run_id not in overrides:
            eligibility_rows.append(
                {
                    "run_id": run_id,
                    "run_label": run_label,
                    "eeg_samples": np.nan,
                    "target_cues": np.nan,
                    "override_cues": np.nan,
                    "valid_pairs": np.nan,
                    "timing_grade": timing_grade,
                    "eligibility_status": (
                        "INELIGIBLE_NO_IDENTIFIABLE_CUE_ONSETS"
                    ),
                }
            )
            continue
        print(
            f"Loading {run_id} {run_label}...", flush=True
        )
        try:
            streams = load_xdf(xdf_path)
        except Exception as exc:
            eligibility_rows.append(
                {
                    "run_id": run_id,
                    "run_label": run_label,
                    "eeg_samples": np.nan,
                    "target_cues": np.nan,
                    "override_cues": np.nan,
                    "valid_pairs": np.nan,
                    "timing_grade": timing_grade,
                    "eligibility_status": (
                        "INELIGIBLE_XDF_READ_ERROR"
                    ),
                }
            )
            (logs / f"{run_id}_error.txt").write_text(
                repr(exc), encoding="utf-8"
            )
            continue
        eeg = choose_stream(
            streams, name="obci_eeg1", min_channels=8
        )
        if eeg is None:
            eeg = choose_stream(
                streams, stype="EEG", min_channels=8
            )
        cues, bounds, ratings = parse_cues_and_context(
            streams
        )
        if spec.get("cue_source") == "combined_ocm_table":
            external = load_external_cues(
                args.data_audit, run_label
            )
            if not external.empty:
                cues = external
                for phase in PHASES:
                    pc = cues[cues["phase"] == phase]
                    if not pc.empty and phase not in bounds:
                        bounds[phase] = (
                            float(pc["cue_lsl_time"].min() - 3),
                            float(pc["cue_lsl_time"].max() + 3),
                        )
        target_count = (
            int((cues["phase"] == "TARGET_1").sum())
            if not cues.empty
            else 0
        )
        override_count = (
            int(
                (
                    cues["phase"]
                    == "CONTEXTUAL_OVERRIDE_1"
                ).sum()
            )
            if not cues.empty
            else 0
        )
        eeg_samples = (
            len(eeg.get("time_stamps", []))
            if eeg is not None
            else 0
        )
        if eeg is None or eeg_samples == 0:
            eligibility_rows.append(
                {
                    "run_id": run_id,
                    "run_label": run_label,
                    "eeg_samples": eeg_samples,
                    "target_cues": target_count,
                    "override_cues": override_count,
                    "valid_pairs": 0,
                    "timing_grade": timing_grade,
                    "eligibility_status": (
                        "INELIGIBLE_NO_EEG_SAMPLES"
                    ),
                }
            )
            continue
        if (
            cues.empty
            or target_count == 0
            or override_count == 0
        ):
            eligibility_rows.append(
                {
                    "run_id": run_id,
                    "run_label": run_label,
                    "eeg_samples": eeg_samples,
                    "target_cues": target_count,
                    "override_cues": override_count,
                    "valid_pairs": 0,
                    "timing_grade": timing_grade,
                    "eligibility_status": (
                        "INELIGIBLE_MISSING_TARGET_OR_OVERRIDE_CUES"
                    ),
                }
            )
            continue
        raw = np.asarray(eeg["time_series"], dtype=float)
        raw_ts = np.asarray(
            eeg["time_stamps"], dtype=float
        )
        info = eeg.get("info", {})
        nominal = float(
            scalar(
                info.get("nominal_srate"),
                config["sampling_rate_hz"],
            )
            or config["sampling_rate_hz"]
        )
        labels, channel_grade = channel_labels(
            info, config["channel_labels"], raw.shape[1]
        )
        if channel_grade == "UNKNOWN_CHANNEL_ORDER":
            eligibility_rows.append(
                {
                    "run_id": run_id,
                    "run_label": run_label,
                    "eeg_samples": eeg_samples,
                    "target_cues": target_count,
                    "override_cues": override_count,
                    "valid_pairs": 0,
                    "timing_grade": timing_grade,
                    "eligibility_status": (
                        "INELIGIBLE_UNKNOWN_CHANNEL_ORDER"
                    ),
                }
            )
            continue
        if spec.get("time_axis") == "raw_xdf":
            ts = raw_ts
        else:
            ts = (
                float(spec["uniform_start_lsl"])
                + np.arange(len(raw), dtype=float) / nominal
            )
        if not bounds:
            for phase in PHASES:
                pc = cues[cues["phase"] == phase]
                if not pc.empty:
                    bounds[phase] = (
                        float(pc["cue_lsl_time"].min() - 3),
                        float(pc["cue_lsl_time"].max() + 3),
                    )
        roi_indices = {
            roi: [
                labels.index(ch)
                for ch in members
                if ch in labels
            ]
            for roi, members in config["rois"].items()
        }
        cleaned = preprocess(raw)
        gamma = bandpass(
            cleaned,
            nominal,
            *config["bands_hz"]["gamma"],
        )
        guard = bandpass(
            cleaned,
            nominal,
            *config["bands_hz"]["guard"],
        )
        (
            cue_features,
            excluded,
            time_trials,
        ) = epoch_features(
            run_id,
            run_label,
            cues,
            ts,
            cleaned,
            gamma,
            guard,
            roi_indices,
            labels,
            config,
        )
        paired = paired_summaries(
            cue_features,
            run_id,
            run_label,
            config,
            rng,
        )
        valid_pairs = int(
            metric_dict(
                paired, "central_midline_gamma_delta"
            )["n"]
        )
        if (
            valid_pairs >= int(config["minimum_paired_cues"])
            and timing_grade.startswith("PASS")
        ):
            eligibility_status = "ELIGIBLE_MAIN_FORENSICS"
        elif valid_pairs >= int(
            config["minimum_paired_cues"]
        ):
            eligibility_status = (
                "SENSITIVITY_ONLY_TIMING_CAUTION"
            )
        else:
            eligibility_status = (
                "INELIGIBLE_INSUFFICIENT_VALID_PAIRS"
            )
        eligibility_rows.append(
            {
                "run_id": run_id,
                "run_label": run_label,
                "eeg_samples": eeg_samples,
                "target_cues": target_count,
                "override_cues": override_count,
                "valid_pairs": valid_pairs,
                "timing_grade": timing_grade,
                "eligibility_status": eligibility_status,
                "channel_map_grade": channel_grade,
                "eeg_time_axis": spec.get("time_axis"),
            }
        )
        context = context_row(
            run_id, run_label, cues, streams, ratings
        )
        adjustment = artifact_adjustment(
            cue_features,
            rng,
            int(config["bootstrap_iterations"]),
        )
        topo = topography_summary(
            cue_features,
            labels,
            run_id,
            run_label,
            config,
            rng,
        )
        aper = aperiodic_summary(
            cleaned,
            ts,
            bounds,
            roi_indices,
            run_id,
            run_label,
            nominal,
        )
        central_series = 10 * np.log10(
            np.maximum(
                np.nanmean(
                    np.square(
                        gamma[
                            :,
                            roi_indices["central_midline"],
                        ]
                    ),
                    axis=1,
                ),
                EPS,
            )
        )
        auto = autonomic_coupling(
            streams,
            ts,
            central_series,
            bounds,
            run_id,
            run_label,
            rng,
            int(config["null_iterations"]),
        )
        tc_summary = timecourse_summary(
            time_trials, config, rng
        )
        peaks = peak_summary(tc_summary)

        fields = {
            "central_midline_gamma": metric_dict(
                paired, "central_midline_gamma_delta"
            ),
            "jaw_temporal_gamma": metric_dict(
                paired, "jaw_temporal_gamma_delta"
            ),
            "jaw_temporal_guard": metric_dict(
                paired, "jaw_temporal_guard_delta"
            ),
            "ocular_frontal_gamma": metric_dict(
                paired, "ocular_frontal_gamma_delta"
            ),
            "global_log_p2p": metric_dict(
                paired, "global_log_p2p_delta"
            ),
            "perimeter_minus_central_gamma": metric_dict(
                paired,
                "perimeter_minus_central_gamma_delta",
            ),
            "n_pairs": valid_pairs,
            "attenuation_fraction": adjustment[
                "attenuation_fraction"
            ],
        }
        label, reasons = evidence_label(
            fields,
            timing_grade,
            int(config["minimum_paired_cues"]),
        )
        summary = {
            "run_id": run_id,
            "run_label": run_label,
            "timing_grade": timing_grade,
            "eligibility_status": eligibility_status,
            "channel_map_grade": channel_grade,
            "n_pairs": valid_pairs,
            **adjustment,
            "forensic_label": label,
            "forensic_reasons": "; ".join(reasons),
        }
        for roi in (
            "central_midline",
            "jaw_temporal",
            "ocular_frontal",
            "perimeter",
        ):
            peak = (
                peaks[peaks["roi"] == roi]
                if not peaks.empty and "roi" in peaks.columns
                else pd.DataFrame()
            )
            summary[f"{roi}_peak_time_sec"] = (
                float(peak.iloc[0]["peak_time_sec"])
                if not peak.empty
                else math.nan
            )
            summary[f"{roi}_peak_db"] = (
                float(
                    peak.iloc[0][
                        "peak_override_minus_target_db"
                    ]
                )
                if not peak.empty
                else math.nan
            )
        for name, values in fields.items():
            if isinstance(values, dict):
                summary[f"{name}_point"] = values["point"]
                summary[f"{name}_low"] = values["low"]
                summary[f"{name}_high"] = values["high"]
        run_summaries.append(summary)
        all_cues.append(cue_features)
        all_excluded.append(excluded)
        all_time_trials.append(time_trials)
        all_time_summary.append(tc_summary)
        all_peaks.append(peaks)
        all_paired.append(paired)
        all_topo.append(topo)
        all_aper.append(aper)
        all_auto.append(auto)
        all_context.append(context)
        slug = re.sub(
            r"[^A-Za-z0-9]+", "_", run_label
        ).strip("_")
        if not topo.empty:
            plot_topography(
                topo,
                figures / f"{slug}_topography.png",
                run_label,
            )
        if not tc_summary.empty:
            plot_timecourse(
                tc_summary,
                figures / f"{slug}_timecourse.png",
                run_label,
            )

    def combine(frames):
        use = [
            frame
            for frame in frames
            if isinstance(frame, pd.DataFrame)
            and not frame.empty
        ]
        return (
            pd.concat(use, ignore_index=True)
            if use
            else pd.DataFrame()
        )

    eligibility = pd.DataFrame(eligibility_rows)
    run_summary = pd.DataFrame(run_summaries)
    cue_table = combine(all_cues)
    excluded_table = combine(all_excluded)
    time_trials_table = combine(all_time_trials)
    time_summary_table = combine(all_time_summary)
    peaks_table = combine(all_peaks)
    paired_table = combine(all_paired)
    topo_table = combine(all_topo)
    aper_table = combine(all_aper)
    auto_table = pd.DataFrame(all_auto)
    context_table = pd.DataFrame(all_context)
    source_table = pd.DataFrame(source_hashes)
    outputs = {
        "run_eligibility.csv": eligibility,
        "run_forensic_summary.csv": run_summary,
        "cue_epoch_features.csv": cue_table,
        "excluded_cues.csv": excluded_table,
        "cue_timecourse_trials.csv": time_trials_table,
        "cue_timecourse_summary.csv": time_summary_table,
        "cue_timecourse_peaks.csv": peaks_table,
        "paired_effects.csv": paired_table,
        "topography_summary.csv": topo_table,
        "aperiodic_summary.csv": aper_table,
        "autonomic_coupling.csv": auto_table,
        "osa_aam_context.csv": context_table,
        "source_xdf_hashes.csv": source_table,
    }
    for name, frame in outputs.items():
        frame.to_csv(tables / name, index=False)
    if not run_summary.empty:
        plot_forest(
            run_summary, figures / "combined_run_effects.png"
        )
    self_test(args.out, config)
    write_report(
        args.out,
        config,
        eligibility,
        run_summary,
        aper_table,
        auto_table,
        context_table,
        source_table,
        peaks_table,
    )
    provenance = {
        "module_version": MODULE_VERSION,
        "config_sha256": sha256_file(args.config),
        "script_sha256": sha256_file(Path(__file__)),
        "inventory_sha256": sha256_file(inventory_path),
        "source_xdf_count": len(source_table),
        "analyzed_run_count": len(run_summary),
        "primary_score_created": False,
        "command": " ".join(sys.argv),
    }
    (args.out / "analysis_provenance.json").write_text(
        json.dumps(provenance, indent=2),
        encoding="utf-8",
    )
    print(f"Complete: {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
