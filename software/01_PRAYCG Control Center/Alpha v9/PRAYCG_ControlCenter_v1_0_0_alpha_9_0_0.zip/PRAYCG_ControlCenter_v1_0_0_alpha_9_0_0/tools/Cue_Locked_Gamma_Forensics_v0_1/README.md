# PRAYCG Cue-Locked Gamma Forensics v0.1

This is an exploratory secondary extension to OCM/OSA/AAM. It does **not** create or modify a primary PRAYCG score.

The module asks whether 30–45 Hz changes near the three-second task cues have temporal, spectral, spatial, amplitude, and autonomic footprints compatible with craniofacial/ocular artifact. It compares Contextual Override cues with matched times in the same-media Target block whenever those pairs are available. Target controls the movie content and approximate time-within-movie, but it did not display the arithmetic cue; the contrast therefore cannot by itself separate cue visibility, saccades/orienting, arithmetic effort, and associated facial or postural responses.

Outputs retain failures and ineligible recordings. The categorical labels are conservative descriptive triage labels, not source-localization claims:

- ARTIFACT_PATTERN_SUPPORTED
- NEURAL_COMPATIBLE_NOT_ESTABLISHED
- INDETERMINATE
- INDETERMINATE_TIMING_OR_COVERAGE

Even NEURAL_COMPATIBLE_NOT_ESTABLISHED does not establish a cortical generator. Scalp EEG, especially above 20 Hz, cannot identify a brain source from these checks alone.

Launch it from Control Center → Analysis Modules → Cue-Locked Gamma Forensics v0.1, or run from this module folder with the scientific Python environment used by PRAYCG:

    python software\praycg_cue_locked_gamma_forensics_v0_1.py --data-audit <DATA_AUDIT_ROOT> --out <OUTPUT_FOLDER>

Synthetic validation:

    python software\praycg_cue_locked_gamma_forensics_v0_1.py --self-test --out <OUTPUT_FOLDER>

The public alpha package includes the code, frozen configuration, and synthetic summary only. Historical biosignals, participant-level tables, and private outputs are deliberately excluded.
