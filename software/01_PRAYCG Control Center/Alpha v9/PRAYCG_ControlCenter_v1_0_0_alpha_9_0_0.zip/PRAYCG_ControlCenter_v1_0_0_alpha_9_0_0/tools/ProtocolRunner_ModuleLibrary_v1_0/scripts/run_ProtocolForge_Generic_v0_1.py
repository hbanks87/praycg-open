#!/usr/bin/env python3
"""Fixed generic entry for human-reviewed Protocol Forge modules.

The Control Center supplies PRAYCG_PROTOCOL_MANIFEST from its hash-validated
protocol lock. This file executes only the existing Protocol Engine v3.0.
"""
from praycg_protocol_engine_v3_0 import run_full_experiment


if __name__ == "__main__":
    run_full_experiment()
