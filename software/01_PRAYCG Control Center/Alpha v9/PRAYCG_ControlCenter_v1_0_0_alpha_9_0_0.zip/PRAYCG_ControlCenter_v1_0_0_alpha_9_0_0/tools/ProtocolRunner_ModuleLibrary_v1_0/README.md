# PRAYCG Protocol Runner Module Library v1.0

This library supplies three protocol-specific runner entry points over one shared PsychoPy/LSL engine. It remains the v1.0 component bundled with **PRAYCG Control Center v1.0.0-alpha.4**; the component label records lineage, while alpha.4 supplies the current approval, acquisition-session, and launch authority. Carried alpha.2-named lock and authority schemas remain compatibility contracts.

In **Protocol Atlas / Runner**, the Control Center discovers the JSON manifests, validates their structure, displays their declared branch order, and creates a design-time approved snapshot. That snapshot alone is not permission to acquire data. The selected protocol, runner and shared-engine hashes, assigned order, media hashes, reviewed hardware profile and preflight, participant pseudonym, run UUID, output location, and frozen runner policy must also be bound into one runtime session lock created and armed from **Hardware Acquisition / Forge**.

## Included protocols

| Protocol | Fixed acquisition order | Runner entry point |
|---|---|---|
| PRAYCG3 v3.0 | PhaseScrambled Control → Target → Contextual Override | `scripts/run_PRAYCG3_OriginalThreeProng_v3_0.py` |
| PRAYCG4 v4.0 | PhaseScrambled Control → its washout/report → ShotOrderScramble → Target → Contextual Override | `scripts/run_PRAYCG4_ShotOrder_v4_0.py` |
| SMG v1.0 | Semantic-Zero → High-Meaning Target → Arithmetic Override | `scripts/run_SMG_SemanticMeaningGradient_v1_0.py` |

The PRAYCG3 sequence preserves the established three-prong runner structure while moving the order and condition definitions into a versioned manifest. That is implementation continuity, not empirical proof of equivalence; a PsychoPy dry run and hardware acceptance test remain required before live acquisition.

## Alpha.4 lock and provenance model

Protocol selection, design approval, session locking, arming, and launch are separate actions. The approved protocol snapshot records:

- protocol ID and version;
- exact ordered branch list;
- SHA-256 of the protocol manifest;
- SHA-256 and path of the protocol-specific runner entry file;
- the protocol’s scientific-boundary statement.

The runtime session lock additionally binds the approval envelope, shared-engine identity, assigned sequence, active run UUID, participant pseudonym, reviewed hardware profile and preflight evidence, required supplemental evidence, exact media files and hashes, capability resolution, frozen timing/report policy, and the immutable per-run artifact directory. Control Center refuses an authorized launch if those values no longer match. The shared engine revalidates the lock before it creates a logger, marker outlet, or PsychoPy experiment window.

The lock prevents accidental configuration drift and a stale or double launch; it does not establish that the design is causally identified, that the stimulus manipulation succeeded, or that the acquisition hardware is scientifically valid.

## Current launch workflow

1. Select the approved module in **Protocol Atlas / Runner**, review it, and click **Approve & Select Protocol**.
2. If a preregistered Williams-sequence variant is required, use **Prospective Assignment Tools…** to obtain the deterministic assignment, then select the corresponding approved declarative module in the library. The assignment utility reports instructions but cannot open or execute a runner directly.
3. Complete the reviewed hardware profile, current-UUID preflight, session-lock creation, and explicit arm in **Hardware Acquisition / Forge**.
4. Return to **Protocol Atlas / Runner**, choose **Launch with PsychoPy Python interpreter (recommended canonical path)**, and click **Launch Approved Protocol Using Selected Mode**.

The canonical acquisition path directly executes the approved runner with PsychoPy's Python interpreter and the runtime-lock environment. Opening PsychoPy Coder or the PsychoPy application is inspection/debug only; those modes receive no acquisition authority, and pressing Run there is rejected by the shared engine. The Control Center atomically consumes the armed state before process creation, so the same arm cannot authorize a second launch.

## Protocol-aware media prefill

Control Center can pass unambiguous files from the selected stimulus folder into the runner GUI. Every value is still independently checked by the runner. Missing or ambiguous values stay unresolved.

SMG uses the distinct key `semantic_zero_video`; it will not silently reuse a phase-scrambled control. PRAYCG4 similarly requires a distinct `shot_order_video`. Target and Override must be bit-identical where declared by the module.

## Analysis compatibility

Native protocol phase markers are authoritative. Compatibility aliases are additional markers:

- SMG `SEMANTIC_ZERO_1` → canonical `CONTROL_1`;
- SMG `HIGH_MEANING_TARGET_1` → canonical `TARGET_1`;
- SMG `ARITHMETIC_OVERRIDE_1` → canonical `CONTEXTUAL_OVERRIDE_1`;
- the corresponding washouts map to `WASHOUT_1`, `WASHOUT_2`, and `WASHOUT_3`.

Aliases permit the current core analysis frame to segment the data, but they do not assert construct equivalence. Protocol-specific interpretation must use the native identity and module snapshot. PRAYCG4’s native `SHOT_ORDER_SCRAMBLE_1` and `SHOT_ORDER_WASHOUT_1` are retained by the bundled segment parser so HOC-R can inspect the structural-control branch.

## Scientific boundaries

- All three modules currently have a fixed order. Condition differences are therefore entangled with position, exposure, habituation, fatigue, and possible carryover unless a later design adds defensible counterbalancing or randomization.
- A washout interval is measured data, not proof that state has returned to baseline.
- A successful arithmetic response supports task engagement but does not prove that narrative processing was absent.
- ShotOrder preserves more local high-order content than PhaseScrambling, but transitions, audio treatment, familiarity, and residual low-level differences may remain.
- SMG indices and thresholds are proposed operationalizations. They are not validated instruments or diagnostic criteria.
- EEG/HRV/respiration agreement does not by itself establish consciousness, a quantum or metaphysical mechanism, clinical efficacy, or objective meaning.

Use the alpha.4 Control Center's guarded workflow and the package-root `README.md` for current operational boundaries. Older documents and component filenames retained in the package are lineage references, not alternate current workflows.
