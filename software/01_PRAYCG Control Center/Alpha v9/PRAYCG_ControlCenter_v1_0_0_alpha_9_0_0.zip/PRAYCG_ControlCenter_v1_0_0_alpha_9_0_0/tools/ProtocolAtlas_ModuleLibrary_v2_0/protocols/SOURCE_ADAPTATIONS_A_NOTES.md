# Source-derived Atlas adaptations: rest, audio order, repeated video, and event boundaries

These entries are runnable **PRAYCG adaptations/reconstructions**, not exact
replications of the named source studies. Their manifests are the acquisition
specifications that the shared Atlas engine hashes, compiles, and executes. The
thin protocol-specific Python files choose a single packaged manifest; they do
not download code, choose hardware, or execute an external command.

Every entry declares `hardware_stack_effect: NONE` and
`hardware_profile_id: null`. Hardware selection, stream setup, contact/signal
quality review, preflight, and acquisition authority remain in the Control
Center's Acquisition workspace. A protocol cannot rewrite that profile.

## Included entries

| Atlas entry | Runnable design | Required operator asset |
|---|---|---|
| MIPDB-derived eyes-closed rest | operator handoff, then one locked timed rest period | none |
| NARR-derived intact audio | instructions, trigger, 12 s fixation, full WAV, 12 s fixation | reviewed mono WAV |
| NARR-derived coarse-order audio | same timing shell with a provenance-verified coarse derivative | reviewed mono WAV plus derivative provenance |
| NARR-derived fine-order audio | same timing shell with a provenance-verified fine derivative | reviewed mono WAV plus derivative provenance |
| NATVIEW-derived repeated viewing | the same hash-bound video from time zero twice; optional post-video 12 Hz checkerboard | reviewed local video |
| Zacks-derived passive viewing | four forced-muted videos in the fixed 1.2.3 → 6.3.9 → 3.1.3 → 2.4.1 order | four reviewed local videos |
| Zacks-derived active boundary marking | the same forced-muted order with timestamped SPACE presses | four reviewed local videos |

The MIPDB duration and Zacks fixation values are declared PRAYCG operational
choices informed by the retained audits. They are not represented as recovered
source constants. The NATVIEW checkerboard is placed after both movie
presentations so enabling the technical validation does not precede and
directly alter the repeated-viewing contrast. A nominal 12 Hz label is valid
only when the observed PsychoPy flip schedule supports it. The engine records
`callOnFlip` timestamps and an explicit schedule assessment; neither is a
photodiode measurement or proof that the intended light reached the retina.

## Asset review and provenance

No source audio or video is bundled. Template import records are in
`../fixtures`. Before a live run, an operator must document an absolute local
path, SHA-256 digest, source/permission basis, content review, and technical
decode properties for every required file. The runtime session lock separately
binds the exact selected asset hashes. NARR order derivatives additionally need
the intact parent hash, manipulation method and parameters, random seed where
applicable, and resulting derivative hash. A suggestive filename is never
sufficient evidence of stimulus identity.

## Interpretation boundaries

- Eyes-closed rest is a recorded state instruction, not a diagnostic measure or
  a verified measure of wakefulness.
- Intact-versus-scrambled audio differences are not uniquely attributable to
  narrative integration; attention, intelligibility, expectation, imagery,
  arousal, and condition order remain plausible contributors.
- Cross-repeat similarity during naturalistic viewing can reflect repeated
  low-level audiovisual structure and timing as well as higher-order content.
- Passive and active event-boundary runs are different tasks. Boundary presses
  alter attention and add motor activity, so they remain separately labeled.
- An event marker documents what the runner did. It does not establish that a
  participant complied, perceived a manipulation, or entered a hypothesized
  conscious state.

Alpha dry runs validate declarative structure and deterministic compilation.
They do not exercise PsychoPy presentation, a real display/audio path, LSL,
BrainFlow, physiological sensors, or participant-facing safety procedures.
