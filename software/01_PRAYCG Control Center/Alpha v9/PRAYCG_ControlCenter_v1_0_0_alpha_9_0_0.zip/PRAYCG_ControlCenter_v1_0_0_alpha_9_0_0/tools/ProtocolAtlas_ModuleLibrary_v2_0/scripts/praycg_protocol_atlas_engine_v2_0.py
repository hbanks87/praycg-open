#!/usr/bin/env python3
"""Authorized declarative PsychoPy runtime for Protocol Atlas modules.

Actual acquisition is fail-closed: it requires the same carried alpha.2-compatible one-use lease,
PID/start binding, owner validation, heartbeat, exact file hashes, ACQUIRE gate,
and FINALIZE transition used by the established PRAYCG runner.  Only ``dry_run``
compilation is permitted outside that authority path.
"""
from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import os
import random
import statistics
import sys
import time
import uuid
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

SCRIPT_DIR = Path(__file__).resolve().parent
LIBRARY_ROOT = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from praycg_protocol_atlas_core_v2_0 import (  # noqa: E402
    EMD_PROTOCOL_ID,
    AtlasRecord,
    AtlasValidationError,
    build_asset_snapshot,
    canonical_sha256,
    compiled_timeline_identity_sha256,
    compile_timeline,
    hardware_role_compatibility_errors,
    load_protocol_module,
    normalize_asset_bindings,
    sha256_file,
    sha256_path,
)


ENGINE_VERSION = "2.0"
EVENT_SCHEMA = "PRAYCG_ProtocolAtlas_EventLog_v2_0"
RESPONSE_SCHEMA = "PRAYCG_ProtocolAtlas_ResponseLog_v2_0"
RUN_STATE_SCHEMA = "PRAYCG_ProtocolAtlas_RunState_v2_0"
CHECKPOINT_SCHEMA = "PRAYCG_ProtocolAtlas_Checkpoint_v2_0"
UNBOUND_ATLAS_RUNTIME_ENV_KEYS = frozenset({
    "PRAYCG_ATLAS_ASSET_BINDINGS_JSON",
    "PRAYCG_ATLAS_RUN_INDEX",
    "PRAYCG_ATLAS_SESSION_INDEX",
    "PRAYCG_RESUME_CHECKPOINT_JSON",
})


class AtlasAbort(RuntimeError):
    """Operator-requested, explicitly incomplete protocol termination."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _text(value: Any) -> str:
    return str(value or "").strip()


def _validated_session_purpose_binding(lock: Mapping[str, Any]) -> dict[str, Any]:
    """Require a coherent locked purpose and an exactly matching child environment."""
    session = lock.get("session") if isinstance(lock.get("session"), Mapping) else None
    if session is None:
        raise RuntimeError("The Atlas runtime session lock has malformed session-purpose metadata.")
    purpose = _text(session.get("session_purpose"))
    eligibility = session.get("participant_data_eligible")
    bench_mode = session.get("bench_test_mode")
    bench_readiness_bypass = session.get("bench_readiness_bypass_active")
    bench_reason = _text(session.get("bench_test_reason"))
    pseudonym = _text(session.get("participant_pseudonym"))
    if type(bench_mode) is not bool:
        raise RuntimeError("The Atlas runtime session lock bench_test_mode must be an explicit boolean.")
    if type(eligibility) is not bool:
        raise RuntimeError("The Atlas runtime session lock participant_data_eligible must be an explicit boolean.")
    if type(bench_readiness_bypass) is not bool:
        raise RuntimeError("The Atlas runtime session lock bench_readiness_bypass_active must be an explicit boolean.")

    if bench_mode:
        failures: list[str] = []
        if purpose != "BENCH_TEST":
            failures.append("session_purpose must be BENCH_TEST")
        if eligibility is not False:
            failures.append("participant_data_eligible must be false")
        if not bench_reason:
            failures.append("bench_test_reason must be nonempty")
        if not pseudonym.startswith("BENCH-"):
            failures.append("participant_pseudonym must begin with BENCH-")
        if bench_readiness_bypass is not True:
            failures.append("bench_readiness_bypass_active must be true")
        if failures:
            raise RuntimeError("The hash-valid Atlas bench session lock is internally inconsistent: " + "; ".join(failures) + ".")
    else:
        failures = []
        if purpose != "PARTICIPANT_ACQUISITION":
            failures.append("session_purpose must be PARTICIPANT_ACQUISITION")
        if eligibility is not True:
            failures.append("participant_data_eligible must be true")
        if not pseudonym:
            failures.append("participant_pseudonym must be nonempty")
        elif pseudonym.upper().startswith("BENCH-"):
            failures.append("participant_pseudonym must not begin with BENCH-")
        if bench_readiness_bypass is not False:
            failures.append("bench_readiness_bypass_active must be false")
        if failures:
            raise RuntimeError("The hash-valid Atlas participant session lock is internally inconsistent: " + "; ".join(failures) + ".")

    environment_purpose = _text(os.environ.get("PRAYCG_SESSION_PURPOSE"))
    environment_bench = _text(os.environ.get("PRAYCG_BENCH_TEST_MODE"))
    environment_bypass = _text(os.environ.get("PRAYCG_BENCH_READINESS_BYPASS"))
    if environment_purpose not in {"BENCH_TEST", "PARTICIPANT_ACQUISITION"}:
        raise RuntimeError("PRAYCG_SESSION_PURPOSE is missing or invalid; the Atlas runner refuses an unlabeled session.")
    if environment_bench not in {"0", "1"}:
        raise RuntimeError("PRAYCG_BENCH_TEST_MODE must be supplied as exactly 0 or 1 for Atlas.")
    if environment_bypass not in {"0", "1"}:
        raise RuntimeError("PRAYCG_BENCH_READINESS_BYPASS must be supplied as exactly 0 or 1 for Atlas.")
    environment_is_bench = environment_bench == "1"
    environment_has_bypass = environment_bypass == "1"
    if environment_purpose != purpose:
        raise RuntimeError("PRAYCG_SESSION_PURPOSE does not match the hash-valid Atlas session lock.")
    if environment_is_bench is not bench_mode:
        raise RuntimeError("PRAYCG_BENCH_TEST_MODE does not match the hash-valid Atlas session lock.")
    if environment_has_bypass is not bench_readiness_bypass:
        raise RuntimeError("PRAYCG_BENCH_READINESS_BYPASS does not match the hash-valid Atlas session lock.")
    if (environment_purpose == "BENCH_TEST") is not environment_is_bench:
        raise RuntimeError("PRAYCG_SESSION_PURPOSE and PRAYCG_BENCH_TEST_MODE disagree for Atlas.")
    return {
        "session_purpose": purpose,
        "participant_data_eligible": eligibility,
        "bench_test_mode": bench_mode,
        "bench_readiness_bypass_active": bench_readiness_bypass,
        "bench_test_reason": bench_reason,
    }


def _safe_name(value: Any) -> str:
    cleaned = "".join(character if character.isalnum() or character in "-_." else "_" for character in _text(value))
    return cleaned[:96] or "unspecified"


def _legacy_runtime() -> Any:
    """Import the carried alpha.2-compatible authority subsystem only for a real run."""
    legacy_scripts = LIBRARY_ROOT.parent / "ProtocolRunner_ModuleLibrary_v1_0" / "scripts"
    if not legacy_scripts.is_dir():
        raise RuntimeError(f"The required authority-bearing PRAYCG runner library is missing: {legacy_scripts}")
    if str(legacy_scripts) not in sys.path:
        sys.path.insert(0, str(legacy_scripts))
    return importlib.import_module("praycg_protocol_engine_v3_0")


def _json_object_file(path_value: str, label: str) -> dict[str, Any]:
    path = Path(path_value).expanduser().resolve(strict=False)
    if not path.is_file():
        raise AtlasValidationError([f"{label} file is missing: {path}"])
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise AtlasValidationError([f"{label} is not readable JSON: {exc}"]) from exc
    if not isinstance(payload, dict):
        raise AtlasValidationError([f"{label} must contain a JSON object"])
    return payload


def _reject_unbound_atlas_runtime_environment() -> None:
    """Reject controls that are not represented in the canonical session lock."""
    present = sorted(key for key in UNBOUND_ATLAS_RUNTIME_ENV_KEYS if _text(os.environ.get(key)))
    if present:
        raise RuntimeError(
            "Unbound Atlas runtime controls are forbidden in a controlled session: "
            + ", ".join(present)
            + ". Recreate the session through the Control Center."
        )


def _session_index(lock: Mapping[str, Any]) -> int:
    session = lock.get("session") if isinstance(lock.get("session"), Mapping) else {}
    value = session.get("session_index")
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise RuntimeError("The Atlas session lock has no valid positive session_index.")
    return value


def _compiled_run_index(compiled: Mapping[str, Any]) -> int:
    """Return the plan-bound run index; environment overrides are forbidden.

    EEG Moments stores the independently meaningful session and run indices in
    its immutable external-schedule selection.  The mirrored parameter is
    retained for generic logging, but disagreement is a hard error rather than
    an opportunity to choose one value at runtime.
    """
    parameters = compiled.get("parameters") if isinstance(compiled.get("parameters"), Mapping) else {}
    external = (
        compiled.get("external_schedule_selection")
        if isinstance(compiled.get("external_schedule_selection"), Mapping)
        else {}
    )
    external_value = external.get("run_index")
    value = external_value if external.get("status") == "LOCKED_REVIEWED_SCHEDULE_RUN" else parameters.get("run_index", 1)
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise RuntimeError("The compiled Atlas plan has no valid positive run_index.")
    if external.get("status") == "LOCKED_REVIEWED_SCHEDULE_RUN":
        parameter_value = parameters.get("run_index")
        if parameter_value != value:
            raise RuntimeError(
                "The compiled Atlas run_index parameter does not match the locked external schedule selection."
            )
    return value


def _binding_protocol_identity(lock: Mapping[str, Any]) -> Mapping[str, Any]:
    value = lock.get("lock_core", {}).get("selection_identity", {}).get("protocol", {})
    return value if isinstance(value, Mapping) else {}


def _locked_assets(lock: Mapping[str, Any]) -> Mapping[str, Any]:
    session = lock.get("session") if isinstance(lock.get("session"), Mapping) else {}
    for key in ("atlas_asset_snapshot", "media_selection_snapshot", "asset_selection_snapshot"):
        value = session.get(key)
        if isinstance(value, Mapping):
            return value
    return {}


def _binding_from_snapshot(snapshot: Mapping[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in snapshot.items():
        if isinstance(value, Mapping) and _text(value.get("path")):
            result[str(key)] = _text(value.get("path"))
    return result


def _normalize_locked_emd_assets(record: AtlasRecord, bindings: Mapping[str, Any]) -> dict[str, str]:
    """Validate EMD asset paths without reparsing mutable external JSON.

    The Control Center already validated the complete directory and stored its
    digest when it compiled the session plan.  At runtime the directory path
    and bytes are rechecked against that lock, while schedule semantics come
    exclusively from the hash-bound compiled trial rows.
    """
    if record.protocol_id != EMD_PROTOCOL_ID:
        raise RuntimeError("The EMD locked-asset path validator was called for another protocol.")
    contracts = {
        _text(item.get("key")): item
        for item in record.module.get("assets", [])
        if isinstance(item, Mapping) and item.get("source") == "operator_selection"
    }
    if set(bindings) != set(contracts):
        raise RuntimeError(
            "The locked EEG Moments asset key set differs from its protocol contract "
            f"(expected {sorted(contracts)}, observed {sorted(map(str, bindings))})."
        )
    normalized: dict[str, str] = {}
    for key, contract in contracts.items():
        raw = _text(bindings.get(key))
        if not raw:
            raise RuntimeError(f"The locked EEG Moments asset path is missing: {key}")
        try:
            path = Path(raw).expanduser().resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise RuntimeError(f"The locked EEG Moments asset path is unavailable: {key}") from exc
        if contract.get("kind") == "directory" and not path.is_dir():
            raise RuntimeError(f"The locked EEG Moments asset must remain a directory tree: {key}")
        if not path.is_file() and not path.is_dir():
            raise RuntimeError(f"The locked EEG Moments asset path is unsupported: {key}")
        normalized[key] = str(path)
    return normalized


def _locked_emd_compiled_plan(lock: Mapping[str, Any]) -> dict[str, Any]:
    """Read the exact Control Center-compiled EMD plan from session authority."""
    session = lock.get("session") if isinstance(lock.get("session"), Mapping) else {}
    value = session.get("atlas_compiled_timeline")
    if not isinstance(value, Mapping):
        raise RuntimeError(
            "The EEG Moments session lock has no immutable compiled Atlas timeline; create a new session lock."
        )
    compiled = dict(value)
    try:
        compiled_timeline_identity_sha256(compiled)
    except AtlasValidationError as exc:
        raise RuntimeError(f"The locked EEG Moments compiled timeline identity is invalid: {exc}") from exc
    selection = compiled.get("external_schedule_selection")
    if not isinstance(selection, Mapping) or selection.get("status") != "LOCKED_REVIEWED_SCHEDULE_RUN":
        raise RuntimeError("The EEG Moments session lock has no reviewed compiled schedule/run selection.")
    return compiled


def _runtime_asset_snapshot(record: AtlasRecord, assets: Mapping[str, str]) -> dict[str, dict[str, Any]]:
    """Re-hash runtime assets; EMD intentionally does not reparse external JSON."""
    if record.protocol_id != EMD_PROTOCOL_ID:
        return build_asset_snapshot(record, assets)
    snapshot: dict[str, dict[str, Any]] = {}
    for key, value in sorted(assets.items()):
        path = Path(value).expanduser().resolve(strict=True)
        if path.is_dir():
            symlinks = [item for item in path.rglob("*") if item.is_symlink()]
            if symlinks:
                raise RuntimeError(
                    "The locked EEG Moments asset tree now contains symbolic links; create a new reviewed lock."
                )
        snapshot[str(key)] = {
            "path": str(path),
            "path_kind": "directory" if path.is_dir() else "file",
            "sha256": sha256_path(path),
            "size_bytes": path.stat().st_size if path.is_file() else None,
        }
    return snapshot


def _validate_runtime_binding(
    legacy: Any,
    record: AtlasRecord,
    compiled: Mapping[str, Any],
    assets: Mapping[str, str],
    *,
    required_stage: str = "ACQUIRE",
) -> tuple[Path, dict[str, Any]]:
    """Revalidate exact Atlas and session identity at a runtime boundary."""
    lock_path, lock = legacy.load_runtime_session_authority(required_stage=required_stage)
    session = lock.get("session") if isinstance(lock.get("session"), Mapping) else {}
    purpose_binding = _validated_session_purpose_binding(lock)
    run_uuid = _text(os.environ.get("PRAYCG_RUN_UUID"))
    participant = _text(os.environ.get("PRAYCG_PARTICIPANT_PSEUDONYM"))
    if not run_uuid or not participant:
        raise RuntimeError("The Control Center did not supply the run UUID and participant pseudonym.")
    if _text(session.get("session_id")) != run_uuid:
        raise RuntimeError("The Atlas runner UUID does not match the runtime session lock.")
    if _text(session.get("participant_pseudonym")) != participant:
        raise RuntimeError("The Atlas participant pseudonym does not match the runtime session lock.")
    if _text(compiled.get("participant_id")) != participant:
        raise RuntimeError("The compiled Atlas participant identity does not match the runtime session lock.")
    if compiled.get("session_index") != _session_index(lock):
        raise RuntimeError("The compiled Atlas session_index does not match the runtime session lock.")
    if _text(compiled.get("protocol_id")) != record.protocol_id:
        raise RuntimeError("The compiled Atlas protocol_id does not match the approved module.")
    if _text(compiled.get("protocol_version")) != record.protocol_version:
        raise RuntimeError("The compiled Atlas protocol_version does not match the approved module.")

    identity = _binding_protocol_identity(lock)
    expected = {
        "protocol_id": record.protocol_id,
        "protocol_version": record.protocol_version,
        "protocol_module_file_sha256": record.manifest_sha256,
        "protocol_module_canonical_sha256": canonical_sha256(record.module),
        "runner_file_sha256": record.runner_sha256,
        "engine_file_sha256": record.engine_sha256,
    }
    aliases = {
        "protocol_module_file_sha256": ("protocol_module_file_sha256", "manifest_sha256"),
        "protocol_module_canonical_sha256": ("protocol_module_canonical_sha256", "module_canonical_sha256"),
        "runner_file_sha256": ("runner_file_sha256", "runner_sha256"),
        "engine_file_sha256": ("engine_file_sha256", "engine_sha256"),
        "protocol_id": ("protocol_id",),
        "protocol_version": ("protocol_version",),
    }
    failures: list[str] = []
    for field, expected_value in expected.items():
        observed = next((_text(identity.get(alias)) for alias in aliases[field] if _text(identity.get(alias))), "")
        if observed != _text(expected_value):
            failures.append(field)
    if failures:
        raise RuntimeError("The Atlas runner does not match the approved protocol snapshot: " + ", ".join(failures))

    selected_manifest = _text(os.environ.get("PRAYCG_PROTOCOL_MANIFEST"))
    if selected_manifest and Path(selected_manifest).expanduser().resolve(strict=False) != record.manifest_path:
        raise RuntimeError("PRAYCG_PROTOCOL_MANIFEST differs from the authority-bound Atlas module.")

    assigned = session.get("assigned_sequence")
    expected_sequence = [
        _text(node.get("compiled_instance_id"))
        for node in compiled.get("timeline", [])
        if isinstance(node, Mapping)
    ]
    if not isinstance(assigned, list) or list(map(str, assigned)) != expected_sequence:
        raise RuntimeError("The frozen Atlas display timeline does not match the runtime session lock.")
    try:
        local_compiled_hash = compiled_timeline_identity_sha256(compiled)
    except AtlasValidationError as exc:
        raise RuntimeError(f"The compiled Atlas timeline identity is invalid: {exc}") from exc
    compiled_hash = _text(identity.get("compiled_timeline_sha256") or session.get("compiled_timeline_sha256"))
    if not compiled_hash or compiled_hash != local_compiled_hash:
        raise RuntimeError("The compiled Atlas timeline hash differs from the runtime session lock.")

    local_snapshot = _runtime_asset_snapshot(record, assets)
    locked_snapshot = _locked_assets(lock)
    if set(local_snapshot) != set(locked_snapshot):
        raise RuntimeError("The Atlas asset key set differs from the runtime session lock.")
    for key, local in local_snapshot.items():
        locked = locked_snapshot.get(key)
        if not isinstance(locked, Mapping):
            raise RuntimeError(f"The locked Atlas asset record is malformed: {key}")
        locked_path = Path(_text(locked.get("path"))).expanduser().resolve(strict=False)
        local_path = Path(_text(local.get("path"))).expanduser().resolve(strict=False)
        if locked_path != local_path or _text(locked.get("sha256")) != _text(local.get("sha256")):
            raise RuntimeError(f"Atlas asset {key} changed after the runtime session was locked.")

    policy = session.get("runner_configuration_policy")
    if not isinstance(policy, Mapping) or policy.get("policy_version") != "PRAYCG_RunnerConfigurationPolicy_v1_0_alpha_2":
        raise RuntimeError("The runtime session has no recognized carried runner-configuration policy.")

    # The protocol can require semantic roles but cannot select a device or
    # outlet.  Re-read the exact reviewed profile snapshot bound by the lock
    # and fail closed only when a required role is absent.
    profile_path = Path(_text(session.get("hardware_profile"))).expanduser().resolve(strict=False)
    if not profile_path.is_file():
        raise RuntimeError("The runtime session's reviewed hardware-profile snapshot is missing.")
    try:
        profile = json.loads(profile_path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"The reviewed hardware-profile snapshot cannot be read: {exc}") from exc
    if not isinstance(profile, Mapping):
        raise RuntimeError("The reviewed hardware-profile snapshot is malformed.")
    stored_profile_hash = _text(profile.get("canonical_sha256"))
    observed_profile_hash = canonical_sha256({
        key: value for key, value in profile.items() if key != "canonical_sha256"
    })
    bound_profile_hash = _text(lock.get("lock_core", {}).get("hardware_profile_canonical_sha256"))
    if not stored_profile_hash or stored_profile_hash != observed_profile_hash or stored_profile_hash != bound_profile_hash:
        raise RuntimeError("The reviewed hardware-profile snapshot identity differs from the runtime session lock.")
    role_errors = hardware_role_compatibility_errors(record.module, profile)
    if role_errors and purpose_binding.get("bench_readiness_bypass_active") is not True:
        raise RuntimeError("Atlas hardware-role compatibility failed: " + "; ".join(role_errors))
    runtime_lock = dict(lock)
    runtime_session = dict(session)
    if role_errors:
        bypass_record = {
            "schema": "PRAYCG_AtlasBenchHardwareRoleBypass_v1_0",
            "active": True,
            "session_purpose": purpose_binding.get("session_purpose"),
            "participant_data_eligible": purpose_binding.get("participant_data_eligible"),
            "bench_test_mode": purpose_binding.get("bench_test_mode"),
            "bench_readiness_bypass_active": purpose_binding.get("bench_readiness_bypass_active"),
            "hardware_role_findings": list(role_errors),
            "reason": "Missing live hardware roles were bypassed only for this permanently nonparticipant Bench Test session.",
        }
        bypass_record["canonical_sha256"] = canonical_sha256(bypass_record)
        runtime_session["bench_hardware_role_bypass"] = bypass_record
    else:
        runtime_session["bench_hardware_role_bypass"] = {
            "schema": "PRAYCG_AtlasBenchHardwareRoleBypass_v1_0",
            "active": False,
            "hardware_role_findings": [],
        }
    runtime_lock["session"] = runtime_session
    return Path(lock_path), runtime_lock


class AtlasEventLogger:
    FIELDS = (
        "schema_version", "run_uuid", "event_id", "event_index", "event_kind",
        "event_name", "marker", "protocol_id", "protocol_version", "protocol_hash",
        "compiled_timeline_hash", "participant_pseudonym", "session_index",
        "node_id", "node_instance_id", "trial_id", "local_monotonic_seconds",
        "lsl_timestamp_seconds", "unix_time", "response_id", "response_value",
        "response_time_seconds", "payload", "confidence",
    )

    def __init__(self, log_dir: Path, record: AtlasRecord, compiled: Mapping[str, Any], participant: str, run_uuid: str) -> None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = f"ProtocolAtlas_{_safe_name(record.protocol_id)}_{_safe_name(participant)}_{timestamp}_{run_uuid[:8]}"
        log_dir.mkdir(parents=True, exist_ok=True)
        self.csv_path = log_dir / f"{stem}_events.csv"
        self.json_path = log_dir / f"{stem}_events.json"
        self.responses_path = log_dir / f"{stem}_responses.json"
        self.rows: list[dict[str, Any]] = []
        self.responses: list[dict[str, Any]] = []
        self.record = record
        self.compiled = compiled
        self.participant = participant
        self.run_uuid = run_uuid
        self.closed = False
        self._csv = self.csv_path.open("w", encoding="utf-8", newline="")
        self._writer = csv.DictWriter(self._csv, fieldnames=self.FIELDS)
        self._writer.writeheader()

    def log(
        self,
        marker: str,
        *,
        event_kind: str = "marker",
        node: Mapping[str, Any] | None = None,
        trial_id: str = "",
        response_id: str = "",
        response_value: Any = "",
        response_time_seconds: float | None = None,
        payload: Any = None,
        confidence: str = "observed",
        lsl_time: float | None = None,
        local_monotonic_time: float | None = None,
        unix_time: float | None = None,
    ) -> dict[str, Any]:
        if self.closed:
            raise RuntimeError("The Atlas event logger is already closed.")
        index = len(self.rows) + 1
        row = {
            "schema_version": EVENT_SCHEMA,
            "run_uuid": self.run_uuid,
            "event_id": f"{self.run_uuid}:{index:07d}",
            "event_index": index,
            "event_kind": event_kind,
            "event_name": marker,
            "marker": marker,
            "protocol_id": self.record.protocol_id,
            "protocol_version": self.record.protocol_version,
            "protocol_hash": self.record.manifest_sha256,
            "compiled_timeline_hash": self.compiled.get("canonical_sha256"),
            "participant_pseudonym": self.participant,
            "session_index": self.compiled.get("session_index"),
            "node_id": _text(node.get("id")) if isinstance(node, Mapping) else "",
            "node_instance_id": _text(node.get("compiled_instance_id")) if isinstance(node, Mapping) else "",
            "trial_id": trial_id,
            "local_monotonic_seconds": time.monotonic() if local_monotonic_time is None else float(local_monotonic_time),
            "lsl_timestamp_seconds": lsl_time,
            "unix_time": time.time() if unix_time is None else float(unix_time),
            "response_id": response_id,
            "response_value": json.dumps(response_value, ensure_ascii=False) if isinstance(response_value, (dict, list)) else response_value,
            "response_time_seconds": response_time_seconds,
            "payload": json.dumps(payload, ensure_ascii=False, sort_keys=True) if isinstance(payload, (dict, list)) else _text(payload),
            "confidence": confidence,
        }
        self.rows.append(row)
        self._writer.writerow(row)
        self._csv.flush()
        if event_kind == "response":
            self.responses.append({
                "schema": RESPONSE_SCHEMA,
                "run_uuid": self.run_uuid,
                "event_id": row["event_id"],
                "protocol_id": self.record.protocol_id,
                "participant_pseudonym": self.participant,
                "session_index": self.compiled.get("session_index"),
                "node_instance_id": row["node_instance_id"],
                "trial_id": trial_id,
                "response_id": response_id,
                "value": response_value,
                "response_time_seconds": response_time_seconds,
            })
        return row

    def close(self) -> None:
        if self.closed:
            return
        self._csv.flush()
        self._csv.close()
        self.json_path.write_text(json.dumps(self.rows, indent=2, ensure_ascii=False), encoding="utf-8")
        self.responses_path.write_text(json.dumps(self.responses, indent=2, ensure_ascii=False), encoding="utf-8")
        self.closed = True


class AtlasRunState:
    def __init__(self, logger: AtlasEventLogger, record: AtlasRecord, compiled: Mapping[str, Any], assets: Mapping[str, str], session: Mapping[str, Any]) -> None:
        self.path = logger.json_path.with_name(logger.json_path.stem.replace("_events", "") + "_run_state.json")
        self.checkpoint_path = self.path.with_name(self.path.stem.replace("_run_state", "") + "_checkpoint.json")
        self.payload: dict[str, Any] = {
            "schema": RUN_STATE_SCHEMA,
            "created_utc": _utc_now(),
            "state": "CREATED",
            "complete": False,
            "reason": "",
            "run_uuid": logger.run_uuid,
            "participant_pseudonym": _text(session.get("participant_pseudonym")),
            "session_purpose": _text(session.get("session_purpose")),
            "participant_data_eligible": session.get("participant_data_eligible"),
            "bench_test_mode": session.get("bench_test_mode"),
            "bench_readiness_bypass_active": session.get("bench_readiness_bypass_active"),
            "bench_test_reason": _text(session.get("bench_test_reason")),
            "bench_hardware_role_bypass": deepcopy(session.get("bench_hardware_role_bypass", {})),
            "protocol_id": record.protocol_id,
            "protocol_version": record.protocol_version,
            "manifest_sha256": record.manifest_sha256,
            "compiled_timeline_sha256": compiled.get("canonical_sha256"),
            "asset_snapshot": build_asset_snapshot(record, assets),
            "last_completed_index": -1,
            "history": [],
            "artifacts": {
                "events_csv": str(logger.csv_path),
                "events_json": str(logger.json_path),
                "responses_json": str(logger.responses_path),
            },
        }
        self.transition("PRECHECK")

    def _write(self) -> None:
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(self.payload, indent=2, ensure_ascii=False), encoding="utf-8")
        temporary.replace(self.path)

    def transition(self, state: str, reason: str = "") -> None:
        self.payload["state"] = state
        self.payload["complete"] = state == "COMPLETED"
        self.payload["reason"] = reason
        self.payload["history"].append({"state": state, "utc": _utc_now(), "reason": reason})
        self._write()

    def checkpoint(self, completed_index: int) -> None:
        self.payload["last_completed_index"] = completed_index
        self._write()
        checkpoint = {
            "schema": CHECKPOINT_SCHEMA,
            "run_uuid": self.payload["run_uuid"],
            "protocol_id": self.payload["protocol_id"],
            "protocol_version": self.payload["protocol_version"],
            "manifest_sha256": self.payload["manifest_sha256"],
            "compiled_timeline_sha256": self.payload["compiled_timeline_sha256"],
            "session_purpose": self.payload["session_purpose"],
            "participant_data_eligible": self.payload["participant_data_eligible"],
            "bench_test_mode": self.payload["bench_test_mode"],
            "bench_readiness_bypass_active": self.payload["bench_readiness_bypass_active"],
            "bench_test_reason": self.payload["bench_test_reason"],
            "bench_hardware_role_bypass": deepcopy(self.payload["bench_hardware_role_bypass"]),
            "last_completed_index": completed_index,
            "recorded_utc": _utc_now(),
        }
        checkpoint["canonical_sha256"] = canonical_sha256(checkpoint)
        temporary = self.checkpoint_path.with_suffix(self.checkpoint_path.suffix + ".tmp")
        temporary.write_text(json.dumps(checkpoint, indent=2), encoding="utf-8")
        temporary.replace(self.checkpoint_path)


@dataclass
class RuntimeContext:
    legacy: Any
    record: AtlasRecord
    compiled: Mapping[str, Any]
    assets: Mapping[str, str]
    logger: AtlasEventLogger
    run_state: AtlasRunState
    outlet: Any
    window: Any
    policy: Mapping[str, Any]

    def marker(self, name: str, *, node: Mapping[str, Any] | None = None, **kwargs: Any) -> None:
        if not _text(name):
            raise RuntimeError("Atlas runtime refused to emit a blank marker name.")
        timestamp = float(self.legacy.local_clock())
        self.outlet.push_sample([name], timestamp=timestamp)
        self.logger.log(name, node=node, lsl_time=timestamp, **kwargs)

    def marker_on_flip(self, name: str, *, node: Mapping[str, Any] | None = None, **kwargs: Any) -> None:
        """Emit an LSL/event marker from PsychoPy's next-flip callback."""
        if not _text(name):
            raise RuntimeError("Atlas runtime refused to schedule a blank marker name.")
        call_on_flip = getattr(self.window, "callOnFlip", None)
        if not callable(call_on_flip):
            raise RuntimeError("This PsychoPy window cannot schedule flip-synchronized Atlas markers.")
        frozen_kwargs = dict(kwargs)
        frozen_kwargs.setdefault("confidence", "display_flip_synchronized")
        call_on_flip(self.marker, name, node=node, **frozen_kwargs)


def _check_escape(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    if "escape" in ctx.legacy.event.getKeys(keyList=["escape"]):
        ctx.marker("ATLAS_OPERATOR_ABORT", node=node)
        raise AtlasAbort("Operator pressed Escape.")


def _wait_draw(
    ctx: RuntimeContext,
    node: Mapping[str, Any],
    duration: float,
    draw: Any | None = None,
    keys: Sequence[str] = (),
    *,
    trial_id: str = "",
    response_context: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Draw for a bounded interval and record trial-addressable key responses.

    ``trial_id`` and ``response_context`` are optional so every historical
    Atlas caller retains its behavior.  Mature endpoint modules use them to
    join a keypress to the exact declarative trial/step without inferring the
    association from timestamps alone.
    """
    clock = ctx.legacy.core.Clock()
    captured: list[dict[str, Any]] = []
    raw_skip_after = node.get("skippable_after_seconds")
    skip_after = float(raw_skip_after) if isinstance(raw_skip_after, (int, float)) and not isinstance(raw_skip_after, bool) else None
    skip_keys = tuple(map(str, node.get("skip_keys") or ["space"])) if skip_after is not None else ()
    ctx.legacy.event.clearEvents()
    while clock.getTime() < max(0.0, duration):
        if draw is not None:
            draw()
        ctx.window.flip()
        for key, response_time in ctx.legacy.event.getKeys(timeStamped=clock):
            if key == "escape":
                raise AtlasAbort("Operator pressed Escape.")
            if skip_after is not None and key in skip_keys and float(response_time) >= skip_after:
                ctx.marker(
                    "ATLAS_BREAK_SKIPPED_AFTER_THRESHOLD",
                    node=node,
                    event_kind="operator_control",
                    response_id="break_skip",
                    response_value=key,
                    response_time_seconds=float(response_time),
                    payload={
                        "planned_duration_seconds": float(duration),
                        "minimum_elapsed_seconds": skip_after,
                        "observed_elapsed_seconds": float(response_time),
                    },
                )
                return captured
            if keys and key in keys:
                captured.append({"key": key, "time": float(response_time)})
                ctx.marker(
                    f"{_text(node.get('id')).upper()}_KEY_{_safe_name(key).upper()}",
                    node=node,
                    event_kind="response",
                    trial_id=_text(trial_id),
                    response_id=_text(node.get("response_id")) or "keypress",
                    response_value=key,
                    response_time_seconds=float(response_time),
                    payload=dict(response_context or {}),
                )
        ctx.legacy.core.wait(0.001)
    return captured


def _show_text(ctx: RuntimeContext, node: Mapping[str, Any], text: str, *, wait_for_key: bool, duration: float | None = None) -> list[str]:
    stimulus = ctx.legacy.visual.TextStim(
        ctx.window,
        text=text,
        color="white",
        height=float(node.get("text_height_px", 34)),
        wrapWidth=float(node.get("wrap_width_px", 1500)),
    )
    if duration is not None:
        _wait_draw(ctx, node, duration, stimulus.draw)
        return []
    stimulus.draw()
    ctx.window.flip()
    if not wait_for_key:
        return []
    keys = list(node.get("continue_keys") or node.get("advance_keys") or ["space"])
    pressed = ctx.legacy.event.waitKeys(keyList=keys + ["escape"])
    if pressed and "escape" in pressed:
        raise AtlasAbort("Operator pressed Escape.")
    return list(pressed or [])


def _text_entry(ctx: RuntimeContext, node: Mapping[str, Any], prompt: str, response_id: str) -> str:
    buffer = ""
    clock = ctx.legacy.core.Clock()
    ctx.legacy.event.clearEvents()
    while True:
        stimulus = ctx.legacy.visual.TextStim(
            ctx.window,
            text=f"{prompt}\n\n{buffer}\n\nPress Enter to save.",
            color="white",
            height=30,
            wrapWidth=1500,
        )
        stimulus.draw()
        ctx.window.flip()
        for key in ctx.legacy.event.getKeys():
            if key == "escape":
                raise AtlasAbort("Operator pressed Escape.")
            if key in {"return", "num_enter"}:
                value = buffer.strip()
                ctx.marker(
                    f"RESPONSE_{_safe_name(response_id).upper()}",
                    node=node,
                    event_kind="response",
                    response_id=response_id,
                    response_value=value,
                    response_time_seconds=clock.getTime(),
                )
                return value
            if key == "backspace":
                buffer = buffer[:-1]
            elif key == "space":
                buffer += " "
            elif len(key) == 1 and key.isprintable():
                buffer += key
        ctx.legacy.core.wait(0.01)


def _choice(ctx: RuntimeContext, node: Mapping[str, Any], prompt: str, options: Sequence[Any], response_id: str) -> Any:
    if not options:
        raise RuntimeError(f"Response node {node.get('id')} has no options.")
    labels = [f"{index + 1}. {option}" for index, option in enumerate(options)]
    allowed = [str(index + 1) for index in range(min(9, len(options)))]
    stimulus = ctx.legacy.visual.TextStim(
        ctx.window,
        text=prompt + "\n\n" + "\n".join(labels),
        color="white",
        height=30,
        wrapWidth=1500,
    )
    clock = ctx.legacy.core.Clock()
    stimulus.draw()
    ctx.window.flip()
    pressed = ctx.legacy.event.waitKeys(keyList=allowed + ["escape"])
    if not pressed or pressed[0] == "escape":
        raise AtlasAbort("Operator pressed Escape.")
    index = int(pressed[0]) - 1
    value = options[index]
    ctx.marker(
        f"RESPONSE_{_safe_name(response_id).upper()}_{index + 1}",
        node=node,
        event_kind="response",
        response_id=response_id,
        response_value=value,
        response_time_seconds=clock.getTime(),
    )
    return value


def _response_contract(ctx: RuntimeContext, response_id: str) -> Mapping[str, Any]:
    for response in ctx.record.module.get("responses", []):
        if isinstance(response, Mapping) and _text(response.get("id")) == response_id:
            return response
    return {}


def _run_response(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    ids = node.get("response_ids") if isinstance(node.get("response_ids"), list) else [_text(node.get("response_id"))]
    ids = [response_id for response_id in map(_text, ids) if response_id]
    if not ids and _text(node.get("type")) == "questionnaire":
        questionnaire_ids = [
            _text(response.get("id"))
            for response in ctx.record.module.get("responses", [])
            if isinstance(response, Mapping) and _text(response.get("type")) == "questionnaire"
        ]
        for questionnaire_id in questionnaire_ids:
            contract = _response_contract(ctx, questionnaire_id)
            for item in contract.get("items", []):
                if not isinstance(item, Mapping):
                    continue
                item_id = _text(item.get("id"))
                prompt = _text(item.get("prompt")) or item_id.replace("_", " ").title()
                scale = item.get("scale")
                if isinstance(scale, list) and len(scale) == 2 and all(isinstance(value, (int, float)) for value in scale):
                    low, high = int(scale[0]), int(scale[1])
                    # Long 0-100 visual analog items use a typed value rather
                    # than an impossible 101-option single-key display.
                    if high - low > 8:
                        while True:
                            value = _text_entry(ctx, node, f"{prompt} ({low}-{high})", f"{questionnaire_id}.{item_id}")
                            try:
                                numeric = float(value)
                            except ValueError:
                                numeric = low - 1
                            if low <= numeric <= high:
                                break
                            _show_text(ctx, node, f"Please enter a value from {low} through {high}.", wait_for_key=True)
                    else:
                        _choice(ctx, node, prompt, list(range(low, high + 1)), f"{questionnaire_id}.{item_id}")
                else:
                    _text_entry(ctx, node, prompt, f"{questionnaire_id}.{item_id}")
        return
    if not ids and _text(node.get("type")) == "free_recall":
        ids = [f"{node.get('id')}_text"]
    for response_id in ids:
        contract = _response_contract(ctx, response_id)
        response_type = _text(contract.get("type") or node.get("response_type") or "text")
        prompt = _text(contract.get("prompt") or node.get("prompt") or node.get("instruction") or response_id)
        options = contract.get("options") or node.get("options")
        if response_type == "questionnaire":
            for item in contract.get("items", []):
                if not isinstance(item, Mapping):
                    continue
                item_id = _text(item.get("id"))
                item_prompt = _text(item.get("prompt")) or item_id.replace("_", " ").title()
                scale = item.get("scale")
                if isinstance(scale, list) and len(scale) == 2 and all(isinstance(value, (int, float)) for value in scale):
                    low, high = int(scale[0]), int(scale[1])
                    if high - low > 8:
                        while True:
                            value = _text_entry(ctx, node, f"{item_prompt} ({low}-{high})", f"{response_id}.{item_id}")
                            try:
                                numeric = float(value)
                            except ValueError:
                                numeric = low - 1
                            if low <= numeric <= high:
                                break
                            _show_text(ctx, node, f"Please enter a value from {low} through {high}.", wait_for_key=True)
                    else:
                        _choice(ctx, node, item_prompt, list(range(low, high + 1)), f"{response_id}.{item_id}")
                else:
                    _text_entry(ctx, node, item_prompt, f"{response_id}.{item_id}")
        elif response_type in {"multiple_choice", "choice", "scale", "confidence", "rating"}:
            if not isinstance(options, list):
                low = int(contract.get("min", node.get("min", 1)))
                high = int(contract.get("max", node.get("max", 7)))
                options = list(range(low, high + 1))
            _choice(ctx, node, prompt, options, response_id)
        elif response_type in {"permutation", "ranking"}:
            expected = [str(item) for item in (contract.get("items") or node.get("items") or [1, 2, 3, 4, 5])]
            while True:
                value = _text_entry(ctx, node, prompt + f"\nEnter each item once, e.g. {' '.join(expected)}", response_id)
                observed = [item for item in value.replace(",", " ").split() if item]
                if len(observed) == len(expected) and set(observed) == set(expected):
                    break
                _show_text(ctx, node, "That ranking is incomplete or repeats an item. Please try again.", wait_for_key=True)
        else:
            _text_entry(ctx, node, prompt, response_id)


def _media_path(ctx: RuntimeContext, key: str) -> Path:
    value = ctx.assets.get(key)
    if not value:
        raise RuntimeError(f"The required runtime media binding is missing: {key}")
    return Path(value).resolve(strict=True)


def _play_video(ctx: RuntimeContext, node: Mapping[str, Any], path: Path, capture_keys: Sequence[str] = ()) -> dict[str, Any]:
    movie_class = getattr(ctx.legacy.visual, "MovieStim3", None) or getattr(ctx.legacy.visual, "MovieStim", None)
    if movie_class is None:
        raise RuntimeError("This PsychoPy installation has no supported MovieStim implementation.")
    movie = movie_class(ctx.window, str(path), noAudio=bool(node.get("mute_required", False)))
    clock = ctx.legacy.core.Clock()
    maximum_duration = node.get("duration_s")
    maximum_duration = float(maximum_duration) if isinstance(maximum_duration, (int, float)) and not isinstance(maximum_duration, bool) else None
    debounce = max(0.0, float(node.get("response_debounce_s", 0.0)))
    last_accepted: dict[str, float] = {}
    natural_duration = getattr(movie, "duration", None)
    frame_count = 0
    ctx.legacy.event.clearEvents()
    while getattr(movie, "status", None) != ctx.legacy.FINISHED and (maximum_duration is None or clock.getTime() < maximum_duration):
        movie.draw()
        ctx.window.flip()
        frame_count += 1
        for key, response_time in ctx.legacy.event.getKeys(timeStamped=clock):
            if key == "escape":
                raise AtlasAbort("Operator pressed Escape.")
            if not capture_keys or key in capture_keys:
                accepted = key not in last_accepted or float(response_time) - last_accepted[key] >= debounce
                if accepted:
                    last_accepted[key] = float(response_time)
                marker_name = _text(node.get("response_marker")) or f"{_text(node.get('id')).upper()}_KEY_{_safe_name(key).upper()}"
                if not accepted:
                    marker_name += "_DEBOUNCED"
                ctx.marker(
                    marker_name,
                    node=node,
                    event_kind="response",
                    response_id=_text(node.get("response_id")) or "media_keypress",
                    response_value={"key": key, "accepted": accepted},
                    response_time_seconds=float(response_time),
                )
        ctx.legacy.core.wait(0.001)
    try:
        movie.stop()
    except Exception:
        pass
    return {
        "path": str(path),
        "natural_duration_seconds": float(natural_duration) if isinstance(natural_duration, (int, float)) else None,
        "played_duration_seconds": float(clock.getTime()),
        "drawn_frames": frame_count,
        "duration_cap_seconds": maximum_duration,
        "audio_verification": "not_exposed_by_generic_psychopy_runtime",
    }


def _play_audio(ctx: RuntimeContext, node: Mapping[str, Any], path: Path) -> None:
    sound_module = importlib.import_module("psychopy.sound")
    audio = sound_module.Sound(str(path))
    duration = float(node.get("duration_s") or audio.getDuration())
    fixation = None
    if _text(node.get("screen")).casefold() == "fixation":
        fixation = ctx.legacy.visual.TextStim(ctx.window, text="+", color="white", height=56)
    call_on_flip = getattr(ctx.window, "callOnFlip", None)
    if not callable(call_on_flip):
        raise RuntimeError("This PsychoPy window cannot synchronize the audio playback request to a display flip.")
    call_on_flip(audio.play)
    _wait_draw(ctx, node, duration, fixation.draw if fixation is not None else None)
    audio.stop()
    ctx.logger.log(
        "ATLAS_AUDIO_PLAYBACK_DIAGNOSTIC",
        event_kind="playback_diagnostic",
        node=node,
        payload={"path": str(path), "declared_or_native_duration_seconds": duration},
        confidence="runtime_requested_duration",
    )


def _checkerboard_timing_summary(
    records: Sequence[Mapping[str, Any]],
    *,
    nominal_reversal_frequency_hz: float,
    planned_duration_seconds: float,
    maximum_reversal_lateness_seconds: float,
) -> dict[str, Any]:
    """Summarize observed flips without relabeling a failed schedule."""
    expected_last_index = max(0, int(max(0.0, planned_duration_seconds - 1e-9) * nominal_reversal_frequency_hz))
    expected_indices = set(range(1, expected_last_index + 1))
    first_by_reversal: dict[int, float] = {}
    flip_times: list[float] = []
    for row in records:
        elapsed = row.get("elapsed_seconds")
        reversal_index = row.get("reversal_index")
        if isinstance(elapsed, (int, float)) and not isinstance(elapsed, bool):
            flip_times.append(float(elapsed))
        if (
            isinstance(reversal_index, int)
            and not isinstance(reversal_index, bool)
            and reversal_index >= 1
            and isinstance(elapsed, (int, float))
            and not isinstance(elapsed, bool)
        ):
            first_by_reversal.setdefault(reversal_index, float(elapsed))
    intervals = [later - earlier for earlier, later in zip(flip_times, flip_times[1:]) if later > earlier]
    median_interval = statistics.median(intervals) if intervals else None
    estimated_refresh_hz = (1.0 / median_interval) if median_interval and median_interval > 0 else None
    lateness = {
        index: observed - (index / nominal_reversal_frequency_hz)
        for index, observed in first_by_reversal.items()
        if index in expected_indices
    }
    missing = sorted(expected_indices - set(first_by_reversal))
    maximum_lateness = max(lateness.values()) if lateness else None
    median_lateness = statistics.median(lateness.values()) if lateness else None
    refresh_supports_schedule = bool(
        estimated_refresh_hz is not None
        and estimated_refresh_hz >= 2.0 * nominal_reversal_frequency_hz
    )
    if len(flip_times) < 2 or not expected_indices:
        status = "UNAVAILABLE"
    elif missing or maximum_lateness is None or not refresh_supports_schedule or maximum_lateness > maximum_reversal_lateness_seconds:
        status = "DISCREPANT"
    else:
        status = "PASS"
    return {
        "status": status,
        "nominal_reversal_frequency_hz": nominal_reversal_frequency_hz,
        "planned_duration_seconds": planned_duration_seconds,
        "observed_flip_count": len(flip_times),
        "expected_reversal_count": len(expected_indices),
        "observed_reversal_count": len(expected_indices & set(first_by_reversal)),
        "missing_reversal_indices": missing,
        "estimated_refresh_hz": estimated_refresh_hz,
        "median_flip_interval_seconds": median_interval,
        "maximum_reversal_lateness_seconds": maximum_lateness,
        "median_reversal_lateness_seconds": median_lateness,
        "lateness_tolerance_seconds": maximum_reversal_lateness_seconds,
        "refresh_supports_schedule": refresh_supports_schedule,
        "interpretation_boundary": (
            "PASS describes only the observed display schedule. It does not establish retinal delivery, "
            "ALS visibility, EEG validity, or a neural steady-state response."
        ),
    }


def _checkerboard(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    frequency = float(node.get("frequency_hz"))
    duration = float(node.get("duration_s", 10.0))
    tolerance = float(node.get("maximum_reversal_lateness_seconds", 0.025))
    size = float(node.get("size_px", 800))
    grid = int(node.get("grid_size", 8))
    squares = []
    square_size = size / grid
    for row in range(grid):
        for column in range(grid):
            square = ctx.legacy.visual.Rect(
                ctx.window,
                width=square_size,
                height=square_size,
                pos=((column - (grid - 1) / 2) * square_size, (row - (grid - 1) / 2) * square_size),
                lineColor=None,
            )
            squares.append((square, (row + column) % 2))
    fixation = ctx.legacy.visual.TextStim(ctx.window, text="+", color="red", height=40)
    clock = ctx.legacy.core.Clock()
    future_flip_time = getattr(ctx.window, "getFutureFlipTime", None)
    if not callable(future_flip_time):
        raise RuntimeError("This PsychoPy window cannot predict checkerboard flip timing in the stimulus clock.")
    flip_records: list[dict[str, Any]] = []
    frame_index = 0
    first_frame = True
    while True:
        if first_frame:
            predicted_elapsed = 0.0
        else:
            predicted_elapsed = float(future_flip_time(clock=clock))
            if predicted_elapsed >= duration:
                break
        # `frequency_hz` is the declared reversal rate, so the phase changes
        # once per 1/f seconds (not twice per cycle).  Anchor the stimulus
        # clock on the first observed display flip and choose each later phase
        # from PsychoPy's prediction for the flip that will present it.
        reversal_index = int((predicted_elapsed + 1e-12) * frequency)
        phase = reversal_index % 2
        for square, parity in squares:
            square.fillColor = "white" if parity ^ phase else "black"
            square.draw()
        fixation.draw()
        frame_index += 1

        def capture_flip(*, frame: int = frame_index, displayed_phase: int = phase, reversal: int = reversal_index) -> None:
            flip_records.append({
                "frame_index": frame,
                "phase": displayed_phase,
                "reversal_index": reversal,
                "elapsed_seconds": float(clock.getTime()),
                "lsl_timestamp_seconds": float(ctx.legacy.local_clock()),
                "local_monotonic_seconds": time.monotonic(),
                "unix_time": time.time(),
            })

        if first_frame:
            ctx.window.callOnFlip(clock.reset)
        ctx.window.callOnFlip(capture_flip)
        ctx.window.flip()
        first_frame = False
        _check_escape(ctx, node)
    if node.get("record_each_flip_timestamp") is True:
        for record in flip_records:
            ctx.logger.log(
                "ATLAS_CHECKERBOARD_DISPLAY_FLIP",
                event_kind="display_flip",
                node=node,
                trial_id=f"frame_{record['frame_index']:06d}",
                payload={
                    "frame_index": record["frame_index"],
                    "phase": record["phase"],
                    "reversal_index": record["reversal_index"],
                    "elapsed_seconds": record["elapsed_seconds"],
                },
                confidence="psychopy_callOnFlip_observed",
                lsl_time=record["lsl_timestamp_seconds"],
                local_monotonic_time=record["local_monotonic_seconds"],
                unix_time=record["unix_time"],
            )
    summary = _checkerboard_timing_summary(
        flip_records,
        nominal_reversal_frequency_hz=frequency,
        planned_duration_seconds=duration,
        maximum_reversal_lateness_seconds=tolerance,
    )
    ctx.marker(
        f"ATLAS_CHECKERBOARD_TIMING_{summary['status']}",
        node=node,
        event_kind="display_timing_summary",
        payload=summary,
        confidence="derived_from_psychopy_callOnFlip_observations",
    )


def _generated_visual(
    ctx: RuntimeContext,
    node: Mapping[str, Any],
    trial: Mapping[str, Any] | None = None,
    *,
    trial_id: str = "",
    response_context: Mapping[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Render one generated visual and return any captured key responses."""
    spec = dict(trial or node)
    duration = float(spec.get("duration_s", node.get("duration_s", 0.5)))
    kind = _text(spec.get("visual_kind") or spec.get("stimulus") or "circle").casefold()
    color = spec.get("color", "white")
    text = _text(spec.get("text"))
    if text:
        stimulus = ctx.legacy.visual.TextStim(
            ctx.window,
            text=text,
            color=color,
            height=float(spec.get("height_px", spec.get("text_height_px", 54))),
            wrapWidth=float(spec.get("wrap_width_px", 1500)),
        )
    elif kind in {"square", "rectangle"}:
        stimulus = ctx.legacy.visual.Rect(ctx.window, width=float(spec.get("width_px", 180)), height=float(spec.get("height_px", 180)), fillColor=color, lineColor=color)
    else:
        stimulus = ctx.legacy.visual.Circle(ctx.window, radius=float(spec.get("radius_px", 90)), fillColor=color, lineColor=color)
    keys = list(spec.get("keys") or node.get("keys") or [])
    runtime_node = {**dict(node), **{k: v for k, v in spec.items() if k in {"response_id"}}}
    context = {
        key: spec[key]
        for key in (
            "trial_id", "step_id", "condition", "item_id", "correct_key",
            "expected_response", "difficulty", "mismatch_level", "source_condition",
            "task_set", "cycle_index", "phase",
        )
        if key in spec
    }
    context.update(dict(response_context or {}))
    return _wait_draw(
        ctx,
        runtime_node,
        duration,
        stimulus.draw,
        keys,
        trial_id=_text(trial_id or spec.get("trial_id")),
        response_context=context,
    )


def _generated_tone(
    ctx: RuntimeContext,
    node: Mapping[str, Any],
    spec: Mapping[str, Any],
    *,
    trial_id: str,
) -> None:
    """Present a generated pure tone on a display flip and retain latency boundaries."""
    frequency = float(spec.get("frequency_hz"))
    duration = float(spec.get("duration_s", 0.1))
    volume = float(spec.get("volume", 0.15))
    if not 20.0 <= frequency <= 20000.0 or not 0.0 < duration <= 10.0 or not 0.0 <= volume <= 1.0:
        raise RuntimeError("Generated-tone parameters are outside the reviewed runtime bounds.")
    sound_module = importlib.import_module("psychopy.sound")
    tone = sound_module.Sound(value=frequency, secs=duration, volume=volume)
    fixation = ctx.legacy.visual.TextStim(ctx.window, text="+", color="white", height=56)
    call_on_flip = getattr(ctx.window, "callOnFlip", None)
    if not callable(call_on_flip):
        raise RuntimeError("This PsychoPy window cannot synchronize the tone request to a display flip.")
    call_on_flip(tone.play)
    _wait_draw(
        ctx,
        node,
        duration,
        fixation.draw,
        trial_id=trial_id,
        response_context={
            "condition": spec.get("condition"),
            "frequency_hz": frequency,
            "acoustic_latency_status": "REQUIRES_PHYSICAL_AUDIO_CALIBRATION",
        },
    )
    tone.stop()


def _visual_search_array(
    ctx: RuntimeContext,
    node: Mapping[str, Any],
    spec: Mapping[str, Any],
    *,
    trial_id: str,
) -> list[dict[str, Any]]:
    """Render a bounded lateralized target/distractor array for N2pc adaptations."""
    target_side = _text(spec.get("target_side")).casefold()
    if target_side not in {"left", "right"}:
        raise RuntimeError("A visual-search array must declare target_side left or right.")
    target_color = spec.get("target_color", "white")
    distractor_color = spec.get("distractor_color", "white")
    xs = (-420.0, -260.0, 260.0, 420.0)
    ys = (-170.0, 170.0)
    target_x = -260.0 if target_side == "left" else 260.0
    target_y = 170.0 if _text(spec.get("target_vertical")).casefold() != "lower" else -170.0
    drawables: list[Any] = []
    for x in xs:
        for y in ys:
            is_target = x == target_x and y == target_y
            if is_target:
                drawables.append(ctx.legacy.visual.ShapeStim(
                    ctx.window,
                    vertices=[(0, 42), (42, 0), (0, -42), (-42, 0)],
                    pos=(x, y),
                    fillColor=target_color,
                    lineColor=target_color,
                ))
            else:
                drawables.append(ctx.legacy.visual.Circle(
                    ctx.window, radius=36, pos=(x, y), fillColor=distractor_color, lineColor=distractor_color
                ))
    fixation = ctx.legacy.visual.TextStim(ctx.window, text="+", color="red", height=40)

    def draw() -> None:
        for drawable in drawables:
            drawable.draw()
        fixation.draw()

    keys = list(spec.get("keys") or ["left", "right"])
    runtime_node = {**dict(node), "response_id": _text(spec.get("response_id"))}
    return _wait_draw(
        ctx,
        runtime_node,
        float(spec.get("duration_s", 0.2)),
        draw,
        keys,
        trial_id=trial_id,
        response_context={
            "condition": spec.get("condition"),
            "target_side": target_side,
            "correct_key": spec.get("correct_key", target_side),
        },
    )


def _ssvep_timing_summary(
    flip_times: Sequence[float],
    *,
    measured_refresh_hz: float,
    declared_refresh_hz: float,
    refresh_tolerance_hz: float,
) -> dict[str, Any]:
    intervals = [later - earlier for earlier, later in zip(flip_times, flip_times[1:]) if later > earlier]
    expected_interval = 1.0 / measured_refresh_hz
    dropped = [interval for interval in intervals if interval > expected_interval * 1.5]
    observed_refresh = 1.0 / statistics.median(intervals) if intervals else None
    status = "PASS"
    if not intervals or abs(measured_refresh_hz - declared_refresh_hz) > refresh_tolerance_hz or dropped:
        status = "DISCREPANT"
    return {
        "status": status,
        "declared_refresh_hz": declared_refresh_hz,
        "measured_refresh_hz": measured_refresh_hz,
        "observed_refresh_hz": observed_refresh,
        "refresh_tolerance_hz": refresh_tolerance_hz,
        "observed_flip_count": len(flip_times),
        "dropped_frame_interval_count": len(dropped),
        "maximum_flip_interval_seconds": max(intervals) if intervals else None,
        "interpretation_boundary": (
            "PASS covers renderer timing only. It does not establish retinal delivery, photodiode visibility, "
            "EEG validity, or a neural steady-state response."
        ),
    }


def _measure_ssvep_refresh(ctx: RuntimeContext, node: Mapping[str, Any]) -> float:
    getter = getattr(ctx.window, "getActualFrameRate", None)
    if not callable(getter):
        raise RuntimeError("SSVEP requires PsychoPy display refresh measurement support.")
    measured = getter(nIdentical=60, nMaxFrames=240, nWarmUpFrames=30, threshold=1)
    if not isinstance(measured, (int, float)) or isinstance(measured, bool) or measured <= 0:
        raise RuntimeError("SSVEP display refresh could not be measured reliably; the run is blocked.")
    declared = float(node.get("declared_refresh_rate_hz"))
    tolerance = float(node.get("refresh_rate_tolerance_hz"))
    if abs(float(measured) - declared) > tolerance:
        raise RuntimeError(
            f"Measured display refresh {float(measured):.3f} Hz differs from the locked {declared:.3f} Hz "
            f"by more than {tolerance:.3f} Hz."
        )
    targets = node.get("targets") if isinstance(node.get("targets"), list) else []
    maximum_frequency = max(float(target.get("frequency_hz", 0.0)) for target in targets if isinstance(target, Mapping))
    if float(measured) < 2.0 * maximum_frequency:
        raise RuntimeError("Measured display refresh does not satisfy the SSVEP Nyquist boundary.")
    return float(measured)


def _ssvep_drawables(ctx: RuntimeContext, node: Mapping[str, Any]) -> tuple[list[tuple[Mapping[str, Any], Any, Any]], Any]:
    result: list[tuple[Mapping[str, Any], Any, Any]] = []
    size = float(node.get("target_size_px", 115.0))
    for raw in node.get("targets", []):
        target = dict(raw)
        position = tuple(map(float, target["position"]))
        rectangle = ctx.legacy.visual.Rect(
            ctx.window, width=size, height=size, pos=position, fillColor=[-1, -1, -1], lineColor="white", lineWidth=2
        )
        label = ctx.legacy.visual.TextStim(
            ctx.window, text=_text(target.get("label") or target.get("target_id")), pos=position, color="black", height=size * 0.32
        )
        result.append((target, rectangle, label))
    patch_size = float(node.get("photodiode_patch_size_px", 90.0))
    width, height = map(float, ctx.window.size)
    margin = float(node.get("photodiode_patch_margin_px", 20.0))
    patch = ctx.legacy.visual.Rect(
        ctx.window,
        width=patch_size,
        height=patch_size,
        pos=(width / 2 - margin - patch_size / 2, -height / 2 + margin + patch_size / 2),
        fillColor=[-1, -1, -1],
        lineColor=None,
    )
    return result, patch


def _run_ssvep_trials(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    measured_refresh = _measure_ssvep_refresh(ctx, node)
    declared_refresh = float(node.get("declared_refresh_rate_hz"))
    tolerance = float(node.get("refresh_rate_tolerance_hz"))
    targets = {
        _text(target.get("target_id")): dict(target)
        for target in node.get("targets", [])
        if isinstance(target, Mapping)
    }
    trials = _trials_for_node(ctx, node)
    if not trials:
        raise RuntimeError("The locked SSVEP plan contains no trials.")
    drawables, patch = _ssvep_drawables(ctx, node)
    cue_seconds = float(node.get("cue_duration_s", 0.5))
    flicker_seconds = float(node.get("flicker_duration_s", 4.0))
    intertrial_seconds = float(node.get("intertrial_interval_s", 0.5))
    for trial_index, trial in enumerate(trials, start=1):
        trial_id = _text(trial.get("trial_id")) or f"ssvep_{trial_index:04d}"
        selected_id = _text(trial.get("target_id"))
        selected = targets.get(selected_id)
        if selected is None:
            raise RuntimeError(f"SSVEP trial {trial_id} references unknown target {selected_id!r}.")
        cue = ctx.legacy.visual.TextStim(
            ctx.window,
            text=f"Focus on {selected.get('label', selected_id)}",
            color="yellow",
            height=46,
        )
        ctx.marker_on_flip("SSVEP_CUE_ONSET", node=node, trial_id=trial_id, payload=trial)
        _wait_draw(ctx, node, cue_seconds, cue.draw, trial_id=trial_id, response_context=trial)
        ctx.marker_on_flip("SSVEP_FLICKER_ONSET", node=node, trial_id=trial_id, payload=trial)
        clock = ctx.legacy.core.Clock()
        future_flip_time = getattr(ctx.window, "getFutureFlipTime", None)
        if not callable(future_flip_time):
            raise RuntimeError("SSVEP requires PsychoPy future-flip prediction support.")
        flip_times: list[float] = []
        first_frame = True
        while True:
            predicted = 0.0 if first_frame else float(future_flip_time(clock=clock))
            if not first_frame and predicted >= flicker_seconds:
                break
            selected_luminance = -1.0
            for target, rectangle, label in drawables:
                luminance = math.sin(
                    2.0 * math.pi * float(target["frequency_hz"]) * predicted
                    + float(target.get("phase_radians", 0.0))
                )
                rectangle.fillColor = [luminance, luminance, luminance]
                rectangle.lineColor = "yellow" if _text(target.get("target_id")) == selected_id else "white"
                rectangle.draw()
                label.draw()
                if _text(target.get("target_id")) == selected_id:
                    selected_luminance = luminance
            patch.fillColor = [selected_luminance, selected_luminance, selected_luminance]
            patch.draw()

            def capture() -> None:
                flip_times.append(float(clock.getTime()))

            if first_frame:
                ctx.window.callOnFlip(clock.reset)
            ctx.window.callOnFlip(capture)
            ctx.window.flip()
            first_frame = False
            _check_escape(ctx, node)
        summary = _ssvep_timing_summary(
            flip_times,
            measured_refresh_hz=measured_refresh,
            declared_refresh_hz=declared_refresh,
            refresh_tolerance_hz=tolerance,
        )
        ctx.marker(
            f"SSVEP_FRAME_TIMING_{summary['status']}",
            node=node,
            trial_id=trial_id,
            event_kind="display_timing_summary",
            payload={**summary, "target_id": selected_id, "frequency_hz": selected["frequency_hz"]},
            confidence="derived_from_psychopy_callOnFlip_observations",
        )
        ctx.marker_on_flip("SSVEP_FLICKER_OFFSET", node=node, trial_id=trial_id, payload=summary)
        ctx.window.flip()
        if summary["status"] != "PASS":
            raise RuntimeError(f"SSVEP frame timing failed for trial {trial_id}; the run is incomplete.")
        if intertrial_seconds > 0:
            fixation = ctx.legacy.visual.TextStim(ctx.window, text="+", color="white", height=56)
            _wait_draw(ctx, node, intertrial_seconds, fixation.draw, trial_id=trial_id)


_ALS_BARCODE_NODE_TYPES = frozenset({"video", "boundary_media", "media_playlist", "rapid_trials"})


def _als_barcode_design(ctx: RuntimeContext, node: Mapping[str, Any]) -> dict[str, Any] | None:
    """Return the lock-controlled Atlas overlay design for eligible media."""
    if node.get("type") not in _ALS_BARCODE_NODE_TYPES or ctx.policy.get("enable_runner_als_barcode") is not True:
        return None
    instance_id = _text(node.get("compiled_instance_id"))
    top_level_instance_ids = {
        _text(item.get("compiled_instance_id"))
        for item in ctx.compiled.get("timeline", [])
        if isinstance(item, Mapping) and _text(item.get("compiled_instance_id"))
    }
    if not instance_id or instance_id not in top_level_instance_ids:
        return None
    apply_phases = ctx.policy.get("als_barcode_apply_phases")
    if isinstance(apply_phases, list) and instance_id not in set(map(str, apply_phases)):
        return None
    durations = {
        "BLACK_PRE": float(ctx.policy.get("als_barcode_black_pre_sec", 0.50)),
        "PULSE_A": float(ctx.policy.get("als_barcode_white_a_sec", 2.00)),
        "BLACK_GAP": float(ctx.policy.get("als_barcode_black_gap_sec", 0.50)),
        "PULSE_B": float(ctx.policy.get("als_barcode_white_b_sec", 0.75)),
        "BLACK_POST": float(ctx.policy.get("als_barcode_black_post_sec", 1.00)),
    }
    if any(not (0.0 < value <= 10.0) for value in durations.values()):
        raise RuntimeError("The locked Atlas ALS-barcode duration policy is outside its bounded runtime range.")
    size = int(ctx.policy.get("als_barcode_size_px", 180))
    margin = int(ctx.policy.get("als_barcode_margin_px", 40))
    position = _text(ctx.policy.get("als_barcode_position") or "lower_right").casefold()
    window_width, window_height = map(int, ctx.window.size)
    if not 20 <= size <= min(window_width, window_height) or margin < 0 or position not in {
        "lower_right", "lower_left", "upper_right", "upper_left", "center", "fullscreen", "full_screen", "full",
    }:
        raise RuntimeError("The locked Atlas ALS-barcode geometry policy is invalid for this display.")
    if position not in {"fullscreen", "full_screen", "full", "center"} and (
        size + (2 * margin) > window_width or size + (2 * margin) > window_height
    ):
        raise RuntimeError("The locked Atlas ALS-barcode corner geometry would extend outside this display.")
    return {
        "source": "runner_overlay",
        "mode": "long_short",
        "position": position,
        "size_px": size,
        "margin_px": margin,
        "durations_seconds": durations,
    }


def _als_barcode_rect(ctx: RuntimeContext, design: Mapping[str, Any]) -> Any:
    width, height = map(float, ctx.window.size)
    size = float(design["size_px"])
    margin = float(design["margin_px"])
    position = _text(design["position"])
    if position in {"fullscreen", "full_screen", "full"}:
        rectangle_width, rectangle_height, x, y = width, height, 0.0, 0.0
    else:
        rectangle_width = rectangle_height = size
        x = (width / 2.0) - margin - (size / 2.0) if "right" in position else 0.0
        if "left" in position:
            x = -(width / 2.0) + margin + (size / 2.0)
        y = -(height / 2.0) + margin + (size / 2.0) if "lower" in position else 0.0
        if "upper" in position:
            y = (height / 2.0) - margin - (size / 2.0)
    return ctx.legacy.visual.Rect(
        ctx.window,
        width=rectangle_width,
        height=rectangle_height,
        pos=(x, y),
        fillColor="white",
        lineColor="white",
        units="pix",
    )


def _show_als_barcode(ctx: RuntimeContext, node: Mapping[str, Any], design: Mapping[str, Any]) -> None:
    prefix = _safe_name(node.get("id")).upper()
    rectangle = _als_barcode_rect(ctx, design)
    first_segment = True
    for segment, duration in design["durations_seconds"].items():
        is_white = segment in {"PULSE_A", "PULSE_B"}
        clock = ctx.legacy.core.Clock()
        first_flip = True
        while clock.getTime() < float(duration):
            if is_white:
                rectangle.draw()
            if first_flip:
                if first_segment:
                    ctx.marker_on_flip(
                        f"{prefix}_ALS_BARCODE_START",
                        node=node,
                        event_kind="als_barcode",
                        payload=dict(design),
                    )
                    first_segment = False
                ctx.marker_on_flip(
                    f"{prefix}_ALS_{segment}_VISIBLE_FLIP",
                    node=node,
                    event_kind="als_barcode",
                    payload={"segment": segment, "white": is_white, "planned_duration_seconds": duration},
                )
                first_flip = False
            ctx.window.flip()
            _check_escape(ctx, node)
            ctx.legacy.core.wait(0.001)
    ctx.marker_on_flip(f"{prefix}_ALS_BARCODE_END", node=node, event_kind="als_barcode")
    ctx.window.flip()


def _maybe_show_als_barcode(ctx: RuntimeContext, node: Mapping[str, Any]) -> bool:
    design = _als_barcode_design(ctx, node)
    if design is None:
        return False
    _show_als_barcode(ctx, node, design)
    return True


def _constrained_binary_plan(count: int, target_count: int, rng: random.Random) -> list[bool]:
    """Create an exact-count plan with no early target or run above two."""
    if count < 3 or target_count < 0 or target_count > count - 2:
        raise RuntimeError("The requested oddball trial counts cannot satisfy the frozen constraints.")
    candidates = list(range(2, count))
    for _ in range(10000):
        chosen = set(rng.sample(candidates, target_count))
        plan = [index in chosen for index in range(count)]
        if all(not (plan[index] and plan[index - 1] and plan[index - 2]) for index in range(2, count)):
            return plan
    raise RuntimeError("Could not generate a constrained oddball sequence from the frozen seed.")


def _p3b_stimulus(ctx: RuntimeContext, shape: str) -> Any:
    if shape == "diamond":
        return ctx.legacy.visual.ShapeStim(
            ctx.window,
            vertices=[(0, 110), (110, 0), (0, -110), (-110, 0)],
            fillColor="white",
            lineColor="white",
        )
    return ctx.legacy.visual.Circle(ctx.window, radius=105, fillColor="white", lineColor="white")


def _run_p3b_node(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    parameters = ctx.compiled.get("parameters", {})
    seed = int(ctx.compiled.get("randomization_seed", 0))
    instance = int(node.get("repeat_index", 1))
    practice = _text(node.get("id")) == "p3b_practice"
    if practice:
        total = int(node.get("repeat_total", parameters.get("practice_trials", 12)))
        rng = random.Random(seed ^ 0x50334250)
        full_plan = _constrained_binary_plan(total, max(1, round(total * float(parameters.get("target_probability", 0.2)))), rng)
        plan = [full_plan[instance - 1]]
        starting_trial = instance
    else:
        count = int(parameters.get("trials_per_block", 120))
        rng = random.Random(seed ^ (instance * 0x9E3779B1))
        plan = _constrained_binary_plan(count, round(count * float(parameters.get("target_probability", 0.2))), rng)
        starting_trial = 1
    target_shape = "circle" if seed % 2 == 0 else "diamond"
    standard_shape = "diamond" if target_shape == "circle" else "circle"
    stimulus_duration = float(parameters.get("stimulus_duration_seconds", 0.2))
    response_window = float(parameters.get("response_window_seconds", 1.0))
    isi_spec = parameters.get("interstimulus_interval_seconds", {})
    isi_min = float(isi_spec.get("minimum", 0.8)) if isinstance(isi_spec, Mapping) else float(isi_spec)
    isi_max = float(isi_spec.get("maximum", 1.2)) if isinstance(isi_spec, Mapping) else float(isi_spec)
    response_key = _text(parameters.get("response_key")) or "space"
    for offset, is_target in enumerate(plan):
        trial_number = starting_trial + offset
        trial_id = f"block_{instance:02d}_trial_{trial_number:03d}" if not practice else f"practice_{trial_number:03d}"
        role = "target" if is_target else "standard"
        shape = target_shape if is_target else standard_shape
        onset_marker = "P3B_TARGET_ONSET" if is_target else "P3B_STANDARD_ONSET"
        ctx.marker_on_flip(onset_marker, node=node, trial_id=trial_id, payload={"role": role, "shape": shape, "block": instance})
        stimulus = _p3b_stimulus(ctx, shape)
        clock = ctx.legacy.core.Clock()
        ctx.legacy.event.clearEvents()
        isi = random.Random(seed ^ (instance << 20) ^ trial_number).uniform(isi_min, isi_max)
        total_duration = max(response_window, stimulus_duration + isi)
        responded = False
        offset_emitted = False
        while clock.getTime() < total_duration:
            now = clock.getTime()
            if now < stimulus_duration:
                stimulus.draw()
            elif not offset_emitted:
                ctx.marker_on_flip("P3B_STIM_OFFSET", node=node, trial_id=trial_id)
                offset_emitted = True
            ctx.window.flip()
            for key, response_time in ctx.legacy.event.getKeys(timeStamped=clock):
                if key == "escape":
                    raise AtlasAbort("Operator pressed Escape.")
                if key == response_key and not responded:
                    responded = True
                    correct = bool(is_target)
                    ctx.marker(
                        "P3B_RESPONSE",
                        node=node,
                        trial_id=trial_id,
                        event_kind="response",
                        response_id="p3b_trial_response",
                        response_value={
                            "key": key,
                            "correct": correct,
                            "stimulus_role": role,
                            "stimulus_shape": shape,
                            "omission": False,
                            "commission": not correct,
                        },
                        response_time_seconds=float(response_time),
                    )
            ctx.legacy.core.wait(0.001)
        if not offset_emitted:
            ctx.marker_on_flip("P3B_STIM_OFFSET", node=node, trial_id=trial_id)
            ctx.window.flip()
        if not responded:
            ctx.logger.log(
                "P3B_NO_RESPONSE",
                event_kind="response",
                node=node,
                trial_id=trial_id,
                response_id="p3b_trial_response",
                response_value={
                    "key": None,
                    "correct": not is_target,
                    "stimulus_role": role,
                    "stimulus_shape": shape,
                    "omission": bool(is_target),
                    "commission": False,
                },
                response_time_seconds=None,
                confidence="derived_from_observed_absence",
            )
        if practice and bool(node.get("feedback", False)):
            feedback = "Correct" if responded == is_target else "Incorrect"
            _show_text(ctx, node, feedback, wait_for_key=False, duration=0.4)


def _balanced_cues(first: str, second: str, count_each: int, rng: random.Random) -> list[str]:
    values = [first] * count_each + [second] * count_each
    for _ in range(10000):
        rng.shuffle(values)
        if all(not (values[index] == values[index - 1] == values[index - 2] == values[index - 3]) for index in range(3, len(values))):
            return list(values)
    raise RuntimeError("Could not generate a balanced motor cue order from the frozen seed.")


def _required_child(node: Mapping[str, Any], child_id: str) -> Mapping[str, Any]:
    matches = [
        child for child in node.get("children", [])
        if isinstance(child, Mapping) and _text(child.get("id")) == child_id
    ]
    if len(matches) != 1:
        raise RuntimeError(f"Timeline block {node.get('id')} requires exactly one child {child_id!r}.")
    return matches[0]


def _runtime_child(parent: Mapping[str, Any], child: Mapping[str, Any], suffix: str, **updates: Any) -> dict[str, Any]:
    return {
        **dict(child),
        **updates,
        "compiled_instance_id": f"{parent.get('compiled_instance_id')}::{child.get('id')}::{suffix}",
    }


def _run_motor_blocks(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    parameters = ctx.compiled.get("parameters", {})
    plan = parameters.get("default_block_plan", [])
    if not isinstance(plan, list) or not plan:
        raise RuntimeError("The motor protocol has no frozen block plan.")
    repetitions = int(parameters.get("trials_per_cue_class", parameters.get("repetitions_per_block", 15)))
    rest_seconds = float(parameters.get("rest_interval_seconds", 4.0))
    cue_seconds = float(parameters.get("cue_interval_seconds", 4.0))
    break_seconds = float(parameters.get("inter_block_break_seconds", 30.0))
    seed = int(ctx.compiled.get("randomization_seed", 0))
    rest_template = _required_child(node, "motor_rest_trial")
    execution_template = _required_child(node, "motor_execution_cue_trial")
    imagery_template = _required_child(node, "motor_imagery_cue_trial")
    break_template = _required_child(node, "motor_block_break")
    for block_index, label in enumerate(plan, start=1):
        task_mode, effector_pair = str(label).split(":", 1)
        if effector_pair == "left_fist_vs_right_fist":
            first, second = "left_fist", "right_fist"
        elif effector_pair == "both_fists_vs_both_feet":
            first, second = "both_fists", "both_feet"
        else:
            raise RuntimeError(f"Unsupported frozen motor effector pair: {effector_pair}")
        cues = _balanced_cues(first, second, repetitions, random.Random(seed ^ (block_index * 0x4D4F544F)))
        ctx.marker_on_flip(
            f"MOTOR_BLOCK_{block_index:02d}_ONSET",
            node=node,
            payload={"task_mode": task_mode, "effector_pair": effector_pair, "cue_count": len(cues)},
        )
        _show_text(
            ctx,
            node,
            f"Next block: {task_mode.replace('_', ' ').upper()}\n{effector_pair.replace('_vs_', ' versus ').replace('_', ' ')}\n\nPress SPACE when ready.",
            wait_for_key=True,
        )
        for trial_index, cue_class in enumerate(cues, start=1):
            trial_id = f"motor_b{block_index:02d}_t{trial_index:03d}"
            source_alias = "T1" if cue_class == first else "T2"
            rest_node = _runtime_child(
                node,
                rest_template,
                f"b{block_index:02d}_t{trial_index:03d}",
                duration_s=rest_seconds,
            )
            rest_markers = rest_node["markers"]
            ctx.marker_on_flip(
                _text(rest_markers["onset"]),
                node=rest_node,
                trial_id=trial_id,
                payload={"task_mode": task_mode, "effector_pair": effector_pair, "next_cue": cue_class},
            )
            fixation = ctx.legacy.visual.TextStim(ctx.window, text="+", color="white", height=56)
            _wait_draw(ctx, rest_node, rest_seconds, fixation.draw, ["c"])
            ctx.marker_on_flip(_text(rest_markers["offset"]), node=rest_node, trial_id=trial_id)
            ctx.window.flip()
            cue_template = execution_template if task_mode == "motor_execution" else imagery_template
            cue_node = _runtime_child(
                node,
                cue_template,
                f"b{block_index:02d}_t{trial_index:03d}",
                duration_s=cue_seconds,
            )
            cue_markers = cue_node["markers"]
            ctx.marker_on_flip(
                _text(cue_markers["onset"]),
                node=cue_node,
                trial_id=trial_id,
                payload={
                    "task_mode": task_mode,
                    "effector_pair": effector_pair,
                    "cue_class": cue_class,
                    "source_alias": source_alias,
                },
            )
            ctx.marker_on_flip(f"MOTOR_{source_alias}_ONSET", node=cue_node, trial_id=trial_id, payload={"cue_class": cue_class})
            cue_text = cue_class.replace("_", " ").upper()
            if task_mode == "motor_imagery":
                cue_text = "IMAGINE\n" + cue_text
            else:
                cue_text = "MOVE\n" + cue_text
            stimulus = ctx.legacy.visual.TextStim(ctx.window, text=cue_text, color="white", height=72)
            _wait_draw(ctx, cue_node, cue_seconds, stimulus.draw, ["c"])
            ctx.marker_on_flip(f"MOTOR_{source_alias}_OFFSET", node=cue_node, trial_id=trial_id)
            ctx.marker_on_flip(_text(cue_markers["offset"]), node=cue_node, trial_id=trial_id)
            ctx.window.flip()
        if block_index < len(plan):
            break_node = _runtime_child(
                node,
                break_template,
                f"after_b{block_index:02d}",
                duration_s=break_seconds,
            )
            break_markers = break_node["markers"]
            ctx.marker_on_flip(f"MOTOR_BLOCK_{block_index:02d}_OFFSET", node=node)
            ctx.marker_on_flip(_text(break_markers["onset"]), node=break_node)
            skip_after = float(break_node.get("skippable_after_seconds", 0.0))
            _show_text(
                ctx,
                break_node,
                f"Rest. Press SPACE after {skip_after:g} seconds to continue, or wait for the break to end.",
                wait_for_key=False,
                duration=break_seconds,
            )
            ctx.marker_on_flip(_text(break_markers["offset"]), node=break_node)
            ctx.window.flip()
        else:
            ctx.marker_on_flip(f"MOTOR_BLOCK_{block_index:02d}_OFFSET", node=node)
            ctx.window.flip()


def _load_emd_trials(ctx: RuntimeContext) -> list[dict[str, Any]]:
    root = _media_path(ctx, "emd_protocol_assets_folder").resolve(strict=True)
    if not root.is_dir():
        raise RuntimeError("The locked EEG Moments asset binding is not a directory tree.")
    selection = ctx.compiled.get("external_schedule_selection")
    if not isinstance(selection, Mapping) or selection.get("status") != "LOCKED_REVIEWED_SCHEDULE_RUN":
        raise RuntimeError(
            "The compiled EEG Moments plan has no reviewed, immutable schedule/run selection. "
            "Return to the Control Center and create a new session lock."
        )
    session_index = selection.get("session_index")
    if session_index != ctx.compiled.get("session_index"):
        raise RuntimeError(
            "The compiled EEG Moments schedule session_index does not match the acquisition session_index."
        )
    run_index = _compiled_run_index(ctx.compiled)
    if selection.get("run_index") != run_index:
        raise RuntimeError("The compiled EEG Moments schedule run_index is internally inconsistent.")
    observed_tree_hash = sha256_path(root)
    if observed_tree_hash != _text(selection.get("asset_tree_sha256")).casefold():
        raise RuntimeError(
            "The complete EEG Moments schedule/media tree changed after compilation; create a new session lock."
        )
    rows = selection.get("selected_trials")
    expected_count = selection.get("selected_run_trial_count")
    if not isinstance(rows, list) or not rows:
        raise RuntimeError("The compiled EEG Moments selected run contains no trials.")
    if isinstance(expected_count, bool) or not isinstance(expected_count, int) or expected_count != len(rows):
        raise RuntimeError("The compiled EEG Moments selected-run trial count is inconsistent.")
    trials: list[dict[str, Any]] = []
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, Mapping):
            raise RuntimeError(f"Compiled EEG Moments trial {index} is malformed.")
        row = dict(row)
        clip_id = _text(row.get("clip_id"))
        trial_id = _text(row.get("trial_id"))
        relative = Path(_text(row.get("clip_relative_path")))
        if not clip_id or not trial_id or relative.is_absolute() or not _text(relative):
            raise RuntimeError(f"Compiled EEG Moments trial {index} has an invalid id or media path.")
        candidate = root / relative
        if candidate.is_symlink():
            raise RuntimeError(f"Compiled EEG Moments trial {trial_id} now resolves through a symbolic link.")
        path = candidate.resolve(strict=True)
        try:
            path.relative_to(root)
        except ValueError as exc:
            raise RuntimeError(f"Compiled EEG Moments trial {trial_id} escapes the locked asset tree.") from exc
        if not path.is_file() or path.is_symlink():
            raise RuntimeError(f"Compiled EEG Moments trial {trial_id} does not name a regular locked media file.")
        expected_hash = _text(row.get("clip_sha256")).casefold()
        observed_hash = sha256_file(path)
        if len(expected_hash) != 64 or expected_hash != observed_hash:
            raise RuntimeError(f"EEG Moments clip hash mismatch: {clip_id}")
        if row.get("schedule_session_index") != session_index or row.get("schedule_run_index") != run_index:
            raise RuntimeError(f"Compiled EEG Moments trial {trial_id} has mismatched session/run provenance.")
        expected_duration = row.get("expected_duration_seconds")
        required_duration = float(ctx.record.module.get("stimulus_contract", {}).get("expected_clip_duration_seconds", 3.0))
        tolerance = float(ctx.record.module.get("stimulus_contract", {}).get("duration_tolerance_seconds", 0.1))
        if not isinstance(expected_duration, (int, float)) or abs(float(expected_duration) - required_duration) > tolerance:
            raise RuntimeError(f"EEG Moments clip {clip_id} does not declare the required {required_duration:.3f}s duration within tolerance.")
        if ctx.record.module.get("stimulus_contract", {}).get("audio_track_expected") is True and row.get("audio_expected") is not True:
            raise RuntimeError(f"EEG Moments clip {clip_id} does not declare audio_expected=true.")
        trials.append({**row, "path": str(path), "observed_sha256": observed_hash})
    return trials


def _emd_attention_probe(ctx: RuntimeContext, node: Mapping[str, Any], trial: Mapping[str, Any]) -> None:
    probe = trial.get("attention_probe")
    if not isinstance(probe, Mapping):
        return
    prompt = _text(probe.get("prompt"))
    left_label = _text(probe.get("left_label")) or "LEFT"
    right_label = _text(probe.get("right_label")) or "RIGHT"
    stimulus = ctx.legacy.visual.TextStim(
        ctx.window,
        text=f"{prompt}\n\nLEFT: {left_label}\nRIGHT: {right_label}",
        color="white",
        height=32,
        wrapWidth=1500,
    )
    clock = ctx.legacy.core.Clock()
    stimulus.draw()
    ctx.window.flip()
    response = ctx.legacy.event.waitKeys(
        maxWait=float(ctx.compiled.get("parameters", {}).get("attention_response_window_seconds", 5.0)),
        keyList=["left", "right", "escape"],
        timeStamped=clock,
    )
    if response and response[0][0] == "escape":
        raise AtlasAbort("Operator pressed Escape.")
    key = response[0][0] if response else None
    reaction_time = float(response[0][1]) if response else None
    correct_key = _text(probe.get("correct_key")).casefold()
    ctx.marker(
        "EMD_ATTENTION_RESPONSE",
        node=node,
        trial_id=_text(trial.get("trial_id")),
        event_kind="response",
        response_id="emd_attention_response",
        response_value={"key": key, "correct": bool(key and correct_key and key == correct_key), "probe_id": probe.get("probe_id")},
        response_time_seconds=reaction_time,
    )


def _run_emd_trials(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    parameters = ctx.compiled.get("parameters", {})
    trials = _load_emd_trials(ctx)
    selection = ctx.compiled.get("external_schedule_selection", {})
    ctx.marker(
        "EMD_LOCKED_SCHEDULE_SELECTION",
        node=node,
        payload={
            "selection_id": selection.get("selection_id"),
            "selection_sha256": selection.get("selection_sha256"),
            "schedule_id": selection.get("schedule_id"),
            "complete_schedule_sha256": selection.get("complete_schedule_sha256"),
            "media_manifest_sha256": selection.get("media_manifest_sha256"),
            "asset_tree_sha256": selection.get("asset_tree_sha256"),
            "session_index": selection.get("session_index"),
            "run_index": selection.get("run_index"),
            "selected_run_trial_count": selection.get("selected_run_trial_count"),
        },
    )
    for index, trial in enumerate(trials):
        trial_id = _text(trial.get("trial_id"))
        fixation = ctx.legacy.visual.TextStim(ctx.window, text="+", color="white", height=56)
        ctx.marker_on_flip("EMD_PRE_CLIP_ONSET", node=node, trial_id=trial_id)
        _wait_draw(ctx, node, float(parameters.get("pre_clip_interval_seconds", 1.0)), fixation.draw)
        ctx.marker_on_flip("EMD_PRE_CLIP_OFFSET", node=node, trial_id=trial_id)
        ctx.marker_on_flip(
            "EMD_CLIP_ONSET",
            node=node,
            trial_id=trial_id,
            payload={
                "clip_id": trial.get("clip_id"),
                "clip_sha256": trial.get("observed_sha256"),
                "scheduled_repetition": trial.get("scheduled_repetition"),
            },
        )
        clip_node = {
            **dict(node),
            "duration_s": float(parameters.get("clip_duration_seconds", 3.0)),
            "mute_required": False,
        }
        diagnostics = _play_video(ctx, clip_node, Path(_text(trial.get("path"))).resolve(strict=True))
        natural_duration = diagnostics.get("natural_duration_seconds")
        tolerance = float(ctx.record.module.get("stimulus_contract", {}).get("duration_tolerance_seconds", 0.1))
        required_duration = float(parameters.get("clip_duration_seconds", 3.0))
        if natural_duration is not None and abs(float(natural_duration) - required_duration) > tolerance:
            raise RuntimeError(
                f"EEG Moments runtime duration for {trial.get('clip_id')} was {natural_duration:.3f}s; "
                f"expected {required_duration:.3f}s ± {tolerance:.3f}s."
            )
        if trial.get("audio_expected") is True:
            ctx.marker(
                "EMD_AUDIO_EXPECTED_RUNTIME_VERIFICATION_UNAVAILABLE",
                node=node,
                trial_id=trial_id,
                payload="Manifest declares audio; generic PsychoPy backend does not expose decoded audio-track confirmation.",
                confidence="unavailable",
            )
        ctx.marker_on_flip("EMD_CLIP_OFFSET", node=node, trial_id=trial_id, payload=diagnostics)
        ctx.marker_on_flip("EMD_POST_CLIP_ONSET", node=node, trial_id=trial_id)
        _wait_draw(ctx, node, float(parameters.get("post_clip_interval_seconds", 0.25)), fixation.draw)
        ctx.marker_on_flip("EMD_POST_CLIP_OFFSET", node=node, trial_id=trial_id)
        if isinstance(trial.get("attention_probe"), Mapping):
            ctx.marker_on_flip("EMD_ATTENTION_PROBE_ONSET", node=node, trial_id=trial_id)
            _emd_attention_probe(ctx, node, trial)
            ctx.marker_on_flip("EMD_ATTENTION_PROBE_OFFSET", node=node, trial_id=trial_id)
        blink = ctx.legacy.visual.TextStim(ctx.window, text="BLINK", color="white", height=48)
        ctx.marker_on_flip("EMD_BLINK_ONSET", node=node, trial_id=trial_id)
        _wait_draw(ctx, node, float(parameters.get("blink_window_seconds", 1.5)), blink.draw)
        ctx.marker_on_flip("EMD_BLINK_OFFSET", node=node, trial_id=trial_id)
        ctx.window.flip()


def _load_svna_manifest(ctx: RuntimeContext) -> tuple[dict[str, Any], Path, str]:
    operator_value = ctx.assets.get("svna_protocol_assets_folder")
    if operator_value:
        selected = Path(operator_value).resolve(strict=True)
        path = selected / "svna_strip_manifest.json" if selected.is_dir() else selected
        mode = "operator_import"
    else:
        relative = _text(ctx.record.module.get("stimulus_contract", {}).get("generated_demo_manifest_package_relative"))
        package_root = LIBRARY_ROOT.parents[1]
        path = (package_root / relative).resolve(strict=False)
        mode = "generated_demo"
    if not path.is_file():
        raise RuntimeError(f"The selected SVNA strip manifest is missing: {path}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping) or payload.get("schema") != "PRAYCG_SixPanelStripManifest_v1_0":
        raise RuntimeError("The SVNA strip manifest schema is not recognized.")
    if mode == "operator_import":
        for field in ("manifest_id", "license", "provenance", "stimulus_status"):
            value = _text(payload.get(field))
            if not value or value.upper().startswith("REPLACE_"):
                raise RuntimeError(f"The imported SVNA manifest must record nonblank {field}.")
    for group in ("practice_strips", "main_strips"):
        values = payload.get(group)
        if not isinstance(values, list):
            raise RuntimeError(f"SVNA manifest {group} must be a list.")
        seen: set[str] = set()
        for index, strip in enumerate(values, start=1):
            if not isinstance(strip, Mapping):
                raise RuntimeError(f"SVNA {group} strip {index} is malformed.")
            strip_id = _text(strip.get("strip_id"))
            panels = strip.get("panels")
            if not strip_id or strip_id in seen or not isinstance(panels, list) or len(panels) != 6:
                raise RuntimeError(f"SVNA {group} strip {index} must have a unique id and exactly six panels.")
            seen.add(strip_id)
            panel_ids: set[str] = set()
            for panel in panels:
                if not isinstance(panel, Mapping):
                    raise RuntimeError(f"SVNA strip {strip_id} has a malformed panel.")
                panel_id = _text(panel.get("panel_id"))
                if not panel_id or panel_id in panel_ids:
                    raise RuntimeError(f"SVNA strip {strip_id} has a blank or duplicate panel_id.")
                panel_ids.add(panel_id)
                image_value = _text(panel.get("relative_path") or panel.get("path"))
                if image_value:
                    image_path = (path.parent / image_value).resolve(strict=False)
                    if not image_path.is_file():
                        raise RuntimeError(f"SVNA panel image is missing: {image_path}")
                    expected = _text(panel.get("sha256")).casefold()
                    if mode == "operator_import" and (len(expected) != 64 or sha256_file(image_path) != expected):
                        raise RuntimeError(f"SVNA imported panel hash mismatch: {strip_id}/{panel.get('panel_id')}")
    return dict(payload), path, mode


def _svna_drawables(ctx: RuntimeContext, strip: Mapping[str, Any], base: Path) -> list[Any]:
    panels = strip.get("panels", [])
    panel_width = 230.0
    panel_height = 330.0
    gap = 35.0
    total_width = 6 * panel_width + 5 * gap
    left = -total_width / 2 + panel_width / 2
    drawables: list[Any] = []
    for index, panel in enumerate(panels):
        center_x = left + index * (panel_width + gap)
        drawables.append(ctx.legacy.visual.Rect(
            ctx.window,
            width=panel_width,
            height=panel_height,
            pos=(center_x, 70),
            fillColor="#F7F7F7",
            lineColor="#202020",
            lineWidth=2,
        ))
        image_value = _text(panel.get("relative_path") or panel.get("path")) if isinstance(panel, Mapping) else ""
        if image_value:
            drawables.append(ctx.legacy.visual.ImageStim(
                ctx.window,
                image=str((base / image_value).resolve(strict=True)),
                pos=(center_x, 70),
                size=(panel_width - 8, panel_height - 8),
            ))
            continue
        for obj in panel.get("objects", []) if isinstance(panel, Mapping) else []:
            if not isinstance(obj, Mapping):
                continue
            kind = _text(obj.get("kind")).casefold()
            color = obj.get("color", "#202020")
            x = center_x + (float(obj.get("x", 0.5)) - 0.5) * panel_width
            y = 70 + (0.5 - float(obj.get("y", 0.5))) * panel_height
            size = float(obj.get("size", 0.1)) * min(panel_width, panel_height)
            if kind == "circle":
                drawables.append(ctx.legacy.visual.Circle(ctx.window, radius=size / 2, pos=(x, y), fillColor=color, lineColor=color))
            elif kind == "rectangle":
                drawables.append(ctx.legacy.visual.Rect(
                    ctx.window,
                    width=float(obj.get("width", obj.get("size", 0.1))) * panel_width,
                    height=float(obj.get("height", obj.get("size", 0.1))) * panel_height,
                    pos=(x, y),
                    fillColor=color,
                    lineColor=color,
                ))
            elif kind in {"triangle", "star"}:
                vertices = [(0, size), (-size * 0.87, -size * 0.5), (size * 0.87, -size * 0.5)]
                if kind == "star":
                    vertices = []
                    for vertex in range(10):
                        radius = size if vertex % 2 == 0 else size * 0.42
                        angle = 1.57079632679 + vertex * 0.62831853072
                        vertices.append((radius * __import__("math").cos(angle), radius * __import__("math").sin(angle)))
                drawables.append(ctx.legacy.visual.ShapeStim(ctx.window, vertices=vertices, pos=(x, y), fillColor=color, lineColor=color))
            elif kind in {"line", "gap"}:
                x1 = center_x + (float(obj.get("x1", obj.get("x", 0.2))) - 0.5) * panel_width
                x2 = center_x + (float(obj.get("x2", obj.get("x", 0.8))) - 0.5) * panel_width
                y1 = 70 + (0.5 - float(obj.get("y1", obj.get("y", 0.5)))) * panel_height
                y2 = 70 + (0.5 - float(obj.get("y2", obj.get("y", 0.5)))) * panel_height
                drawables.append(ctx.legacy.visual.Line(ctx.window, start=(x1, y1), end=(x2, y2), lineColor=color, lineWidth=4))
    for gutter in range(1, 6):
        x = left + (gutter - 0.5) * panel_width + (gutter - 0.5) * gap
        drawables.append(ctx.legacy.visual.TextStim(ctx.window, text=str(gutter), pos=(x, -135), color="white", height=30))
    return drawables


def _run_svna_ranking(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    payload, manifest_path, mode = _load_svna_manifest(ctx)
    group = "practice_strips" if _text(node.get("type")) == "image_ranking" else "main_strips"
    strips = [dict(strip) for strip in payload.get(group, []) if isinstance(strip, Mapping)]
    if group == "main_strips":
        random.Random(int(ctx.compiled.get("randomization_seed", 0)) ^ 0x53564E41).shuffle(strips)
    minimum_view = float(ctx.compiled.get("parameters", {}).get("minimum_view_seconds_before_first_selection", 2.0))
    for strip in strips:
        strip_id = _text(strip.get("strip_id"))
        ctx.marker_on_flip("SVNA_STRIP_ONSET", node=node, trial_id=strip_id, payload={"mode": mode})
        drawables = _svna_drawables(ctx, strip, manifest_path.parent)
        ranking: list[str] = []
        correction_count = 0
        selection_times: list[float] = []
        clock = ctx.legacy.core.Clock()
        ctx.legacy.event.clearEvents()
        while True:
            for drawable in drawables:
                drawable.draw()
            status = ctx.legacy.visual.TextStim(
                ctx.window,
                text="Rank best to least preferred: " + (" > ".join(ranking) if ranking else "(choose 1-5 after viewing)"),
                pos=(0, -250),
                color="white",
                height=28,
            )
            status.draw()
            ctx.window.flip()
            for key in ctx.legacy.event.getKeys():
                if key == "escape":
                    raise AtlasAbort("Operator pressed Escape.")
                if key in {"backspace", "delete"} and ranking:
                    ranking.pop()
                    correction_count += 1
                    continue
                if key in {"1", "2", "3", "4", "5"} and clock.getTime() >= minimum_view and key not in ranking:
                    ranking.append(key)
                    selection_times.append(clock.getTime())
                    ctx.marker(
                        "SVNA_GUTTER_SELECTED",
                        node=node,
                        trial_id=strip_id,
                        payload={"gutter_id": int(key), "rank": len(ranking), "selection_time_seconds": selection_times[-1]},
                    )
                    continue
                if key in {"return", "num_enter"} and len(ranking) == 5 and set(ranking) == {"1", "2", "3", "4", "5"}:
                    ctx.marker(
                        "SVNA_RANKING_SUBMITTED",
                        node=node,
                        trial_id=strip_id,
                        event_kind="response",
                        response_id="svna_complete_gutter_ranking",
                        response_value={
                            "strip_id": strip_id,
                            "first_choice_gutter": int(ranking[0]),
                            "ordered_gutter_ids_most_to_least_preferred": [int(value) for value in ranking],
                            "selection_timestamps_seconds": selection_times,
                            "correction_count": correction_count,
                            "mode": mode,
                            "practice": group == "practice_strips",
                        },
                        response_time_seconds=clock.getTime(),
                    )
                    ctx.marker_on_flip("SVNA_STRIP_OFFSET", node=node, trial_id=strip_id)
                    ctx.window.flip()
                    break
            else:
                ctx.legacy.core.wait(0.005)
                continue
            break


def _image_manifest_trials(ctx: RuntimeContext, node: Mapping[str, Any]) -> list[dict[str, Any]]:
    manifest_key = _text(node.get("image_manifest_key"))
    root_key = _text(node.get("image_root_key"))
    manifest_path = _media_path(ctx, manifest_key)
    image_root = _media_path(ctx, root_key)
    if not manifest_path.is_file() or not image_root.is_dir():
        raise RuntimeError("The N170 image manifest and image directory must be locked file/directory assets.")
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping) or payload.get("schema") != "PRAYCG_ReviewedImageStimulusManifest_v1_0":
        raise RuntimeError("The reviewed image-stimulus manifest schema is not recognized.")
    if payload.get("rights_reviewed") is not True or not _text(payload.get("license_or_permission")):
        raise RuntimeError("The image-stimulus manifest has no affirmative rights review.")
    stimuli = payload.get("stimuli")
    if not isinstance(stimuli, list) or not stimuli:
        raise RuntimeError("The image-stimulus manifest contains no stimuli.")
    allowed_categories = set(map(str, node.get("required_categories", [])))
    rows: list[dict[str, Any]] = []
    observed_categories: set[str] = set()
    category_counts: dict[str, int] = {}
    for index, item in enumerate(stimuli, start=1):
        if not isinstance(item, Mapping):
            raise RuntimeError(f"Image-stimulus entry {index} is malformed.")
        stimulus_id = _text(item.get("stimulus_id"))
        category = _text(item.get("category"))
        relative = Path(_text(item.get("relative_path")))
        expected_hash = _text(item.get("sha256")).casefold()
        if not stimulus_id or not category or relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError(f"Image-stimulus entry {index} has an invalid id, category, or path.")
        path = (image_root / relative).resolve(strict=True)
        try:
            path.relative_to(image_root)
        except ValueError as exc:
            raise RuntimeError(f"Image-stimulus entry {stimulus_id} escapes its locked directory.") from exc
        if not path.is_file() or len(expected_hash) != 64 or sha256_file(path) != expected_hash:
            raise RuntimeError(f"Image-stimulus entry {stimulus_id} failed its SHA-256 check.")
        if allowed_categories and category not in allowed_categories:
            raise RuntimeError(f"Image-stimulus entry {stimulus_id} uses undeclared category {category!r}.")
        observed_categories.add(category)
        category_counts[category] = category_counts.get(category, 0) + 1
        rows.append({
            "trial_id": f"n170_{stimulus_id}",
            "kind": "image",
            "path": str(path),
            "stimulus_id": stimulus_id,
            "condition": category,
            "duration_s": float(node.get("stimulus_duration_s", 0.3)),
            "isi_s": float(node.get("interstimulus_interval_s", 0.7)),
            "onset_marker": f"N170_{_safe_name(category).upper()}_ONSET",
        })
    if allowed_categories and observed_categories != allowed_categories:
        raise RuntimeError("The image-stimulus manifest does not contain every required category.")
    minimum_per_category = int(node.get("minimum_images_per_category", 1))
    if any(category_counts.get(category, 0) < minimum_per_category for category in allowed_categories):
        raise RuntimeError(
            f"The image-stimulus manifest requires at least {minimum_per_category} images in every category."
        )
    repetitions = int(node.get("repetitions_per_image", 1))
    expanded = [{**row, "trial_id": f"{row['trial_id']}_r{repeat:02d}"} for repeat in range(1, repetitions + 1) for row in rows]
    random.Random(int(ctx.compiled.get("randomization_seed", 0)) ^ 0x4E313730).shuffle(expanded)
    return expanded


def _trials_for_node(ctx: RuntimeContext, node: Mapping[str, Any]) -> list[dict[str, Any]]:
    if _text(node.get("image_manifest_key")):
        return _image_manifest_trials(ctx, node)
    for field in ("trials", "randomized_trials"):
        value = node.get(field)
        if isinstance(value, list):
            return [dict(item) for item in value if isinstance(item, Mapping)]
    asset_key = _text(node.get("trials_asset_key") or node.get("schedule_key"))
    if asset_key:
        payload = json.loads(_media_path(ctx, asset_key).read_text(encoding="utf-8"))
        values = payload.get("trials") if isinstance(payload, Mapping) else payload
        if not isinstance(values, list):
            raise RuntimeError(f"Trial asset {asset_key} does not contain a trials list.")
        return [dict(item) for item in values if isinstance(item, Mapping)]
    template = node.get("trial_template")
    if isinstance(template, Mapping):
        count = int(node.get("trial_count", template.get("trial_count", 1)))
        return [{**dict(template), "trial_id": f"trial_{index + 1:04d}"} for index in range(count)]
    return []


def _run_trials(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    """Run declarative generated/media trials, including compound step trials.

    A compound trial is a normal trial row with a ``steps`` list.  Every step
    remains data-only and may display a generated visual, fixation/blank
    interval, or operator instruction.  This supports bounded belief-update,
    cognitive-load, confidence, and paced-regulation tasks without embedding
    executable protocol code in manifests.
    """
    trials = _trials_for_node(ctx, node)
    if not trials:
        raise RuntimeError(f"Timeline node {node.get('id')} resolved zero trials.")
    for index, trial in enumerate(trials, start=1):
        trial_id = _text(trial.get("trial_id")) or f"trial_{index:04d}"
        onset = _text(trial.get("onset_marker")) or f"{_text(node.get('id')).upper()}_{_safe_name(trial_id).upper()}_ONSET"
        ctx.marker_on_flip(onset, node=node, trial_id=trial_id, payload=trial)

        captured_summary: list[dict[str, Any]] = []
        steps = trial.get("steps")
        if isinstance(steps, list) and steps:
            for step_index, raw_step in enumerate(steps, start=1):
                if not isinstance(raw_step, Mapping):
                    raise RuntimeError(f"Trial {trial_id} step {step_index} is malformed.")
                step = dict(raw_step)
                step_id = _text(step.get("step_id")) or f"step_{step_index:02d}"
                step["step_id"] = step_id
                step_kind = _text(step.get("kind") or step.get("type") or "generated_visual")
                step_onset = _text(step.get("onset_marker")) or (
                    f"{_text(node.get('id')).upper()}_{_safe_name(trial_id).upper()}_"
                    f"{_safe_name(step_id).upper()}_ONSET"
                )
                step_offset = _text(step.get("offset_marker")) or (
                    f"{_text(node.get('id')).upper()}_{_safe_name(trial_id).upper()}_"
                    f"{_safe_name(step_id).upper()}_OFFSET"
                )
                step_payload = {**dict(trial), **step, "steps": None}
                ctx.marker_on_flip(step_onset, node=node, trial_id=trial_id, payload=step_payload)
                if step_kind in {"generated_visual", "cue", "motor_cue", "imagery_cue"}:
                    captured = _generated_visual(
                        ctx, node, step, trial_id=trial_id,
                        response_context={"step_id": step_id},
                    )
                    captured_summary.extend({"step_id": step_id, **item} for item in captured)
                elif step_kind == "generated_tone":
                    _generated_tone(ctx, node, step, trial_id=trial_id)
                elif step_kind == "visual_array":
                    captured = _visual_search_array(ctx, node, step, trial_id=trial_id)
                    captured_summary.extend({"step_id": step_id, **item} for item in captured)
                elif step_kind in {"fixation", "blank", "interval", "rest"}:
                    duration = float(step.get("duration_s", 0.5))
                    if step_kind == "fixation" or step.get("fixation_visible") is True:
                        stimulus = ctx.legacy.visual.TextStim(
                            ctx.window, text=_text(step.get("symbol")) or "+", color="white", height=56
                        )
                        _wait_draw(ctx, node, duration, stimulus.draw, trial_id=trial_id, response_context={"step_id": step_id})
                    else:
                        _wait_draw(ctx, node, duration, trial_id=trial_id, response_context={"step_id": step_id})
                elif step_kind == "instruction":
                    _show_text(ctx, {**dict(node), **step}, _text(step.get("text") or step.get("instruction")), wait_for_key=True)
                else:
                    raise RuntimeError(f"Compound trial {trial_id} has unsupported declarative step kind {step_kind!r}.")
                ctx.marker_on_flip(
                    step_offset, node=node, trial_id=trial_id,
                    payload={"step_id": step_id, "captured_responses": [item for item in captured_summary if item.get("step_id") == step_id]},
                )
                ctx.window.flip()
                step_isi = float(step.get("isi_s", 0.0))
                if step_isi > 0:
                    _wait_draw(ctx, node, step_isi, trial_id=trial_id, response_context={"step_id": step_id, "phase": "step_isi"})
        else:
            kind = _text(trial.get("kind") or trial.get("type") or node.get("trial_kind") or "generated_visual")
            if kind in {"video", "media_clip"}:
                key = _text(trial.get("media_key") or node.get("media_key"))
                _play_video(ctx, node, _media_path(ctx, key), list(trial.get("keys") or node.get("keys") or []))
            elif kind == "image":
                image_path = Path(_text(trial.get("path"))).expanduser().resolve(strict=True)
                stimulus = ctx.legacy.visual.ImageStim(ctx.window, image=str(image_path))
                captured_summary.extend(_wait_draw(
                    ctx, node, float(trial.get("duration_s", 0.5)), stimulus.draw,
                    list(trial.get("keys") or []), trial_id=trial_id, response_context=trial,
                ))
            elif kind == "generated_tone":
                _generated_tone(ctx, node, trial, trial_id=trial_id)
            elif kind == "visual_array":
                captured_summary.extend(_visual_search_array(ctx, node, trial, trial_id=trial_id))
            else:
                captured_summary.extend(_generated_visual(ctx, node, trial, trial_id=trial_id))

        ctx.marker_on_flip(
            _text(trial.get("offset_marker")) or f"{_text(node.get('id')).upper()}_{_safe_name(trial_id).upper()}_OFFSET",
            node=node,
            trial_id=trial_id,
            payload={"captured_responses": captured_summary},
        )
        ctx.window.flip()
        isi = float(trial.get("isi_s", node.get("isi_s", 0.0)))
        if isi > 0:
            _wait_draw(ctx, node, isi, trial_id=trial_id, response_context={"phase": "trial_isi"})
        if bool(trial.get("probe", False)):
            _run_response(ctx, {**dict(node), **dict(trial), "response_id": _text(trial.get("response_id"))})


def _playlist_paths(ctx: RuntimeContext, node: Mapping[str, Any]) -> list[Path]:
    path = _media_path(ctx, _text(node.get("media_set_key")))
    if path.is_dir():
        allowed = {".mp4", ".mov", ".avi", ".mkv"}
        return sorted((item for item in path.iterdir() if item.is_file() and item.suffix.casefold() in allowed), key=lambda item: item.name.casefold())
    payload = json.loads(path.read_text(encoding="utf-8"))
    values = payload.get("media") if isinstance(payload, Mapping) else payload
    if not isinstance(values, list):
        raise RuntimeError("A media playlist manifest must contain a media list.")
    base = path.parent
    return [(base / _text(item.get("path") if isinstance(item, Mapping) else item)).resolve(strict=True) for item in values]


def _execute_marked_node(ctx: RuntimeContext, node: Mapping[str, Any], *, payload: Mapping[str, Any] | None = None) -> None:
    """Present one node with display-boundary markers on actual flips."""
    _maybe_show_als_barcode(ctx, node)
    markers = node.get("markers") if isinstance(node.get("markers"), Mapping) else {}
    onset = _text(markers.get("onset"))
    if not onset:
        raise RuntimeError(f"Timeline node {node.get('id')} has no validated onset marker.")
    ctx.marker_on_flip(onset, node=node, payload=dict(payload or {"type": node.get("type")}))
    _run_node(ctx, node)
    offset = _text(markers.get("offset"))
    if offset:
        ctx.marker_on_flip(offset, node=node)
        # The offset is the observed flip on which the prior content is
        # cleared.  It is not an estimate emitted after the display change.
        ctx.window.flip()


def _run_node(ctx: RuntimeContext, node: Mapping[str, Any]) -> None:
    node_type = _text(node.get("type"))
    family = ctx.record.engine_family
    if family == "generated_erp" and node_type in {"oddball", "block"}:
        if node_type == "oddball":
            _run_p3b_node(ctx, node)
            return
        fixation_template = _required_child(node, "p3b_block_fixation")
        trials_template = _required_child(node, "p3b_oddball_trials")
        break_template = _required_child(node, "p3b_block_break")
        suffix = f"block_{int(node.get('repeat_index', 1)):02d}"
        for child in (fixation_template, trials_template, break_template):
            child_node = _runtime_child(
                node,
                child,
                suffix,
                repeat_index=int(node.get("repeat_index", 1)),
            )
            if _text(child_node.get("type")) == "break" and not _text(child_node.get("instruction")):
                skip_after = float(child_node.get("skippable_after_seconds", 0.0))
                child_node["instruction"] = (
                    f"Rest. Press SPACE after {skip_after:g} seconds to continue, "
                    "or wait for the break to end."
                )
            _execute_marked_node(ctx, child_node)
        return
    if family == "motor_imagery" and node_type == "block":
        _run_motor_blocks(ctx, node)
        return
    if family == "rapid_media" and node_type == "rapid_trials":
        _run_emd_trials(ctx, node)
        return
    if family == "image_ranking" and node_type in {"image_ranking", "ranking_task"}:
        _run_svna_ranking(ctx, node)
        return
    if family == "ssvep" and node_type == "ssvep_trials":
        _run_ssvep_trials(ctx, node)
        return
    if node_type in {"instruction", "wait_for_operator"}:
        _show_text(ctx, node, _text(node.get("text") or node.get("operator_text") or node.get("instruction")), wait_for_key=True)
    elif node_type in {"fixation", "rest", "eyes_closed_rest", "blank", "interval", "break", "blink_window"}:
        duration = float(node.get("duration_s", 1.0))
        cue_sound = None
        if node_type == "eyes_closed_rest" and node.get("start_and_end_audio_cues") is True:
            sound_module = importlib.import_module("psychopy.sound")
            cue_sound = sound_module.Sound(value=440, secs=0.2, volume=0.2)
            ctx.marker_on_flip("EYES_CLOSED_REST_AUDIO_START_CUE", node=node)
            ctx.window.callOnFlip(cue_sound.play)
            ctx.window.flip()
            ctx.legacy.core.wait(0.25)
        if node_type == "fixation" or node.get("generated_fixation") is True or _text(node.get("screen")).casefold() == "fixation" or node.get("fixation_visible") is True:
            stimulus = ctx.legacy.visual.TextStim(ctx.window, text=_text(node.get("symbol")) or "+", color="white", height=56)
            _wait_draw(ctx, node, duration, stimulus.draw)
        elif node_type == "break" and node.get("skippable_after_seconds") is not None:
            skip_after = float(node.get("skippable_after_seconds"))
            message = _text(node.get("instruction")) or (
                f"Rest. Press SPACE after {skip_after:g} seconds to continue, or wait for the break to end."
            )
            _show_text(ctx, node, message, wait_for_key=False, duration=duration)
        elif node_type in {"break", "eyes_closed_rest"} and _text(node.get("instruction")):
            _show_text(ctx, node, _text(node.get("instruction")), wait_for_key=False, duration=min(duration, float(node.get("instruction_duration_s", duration))))
        else:
            _wait_draw(ctx, node, duration)
        if cue_sound is not None:
            ctx.marker_on_flip("EYES_CLOSED_REST_AUDIO_END_CUE", node=node)
            ctx.window.callOnFlip(cue_sound.play)
            ctx.window.flip()
            ctx.legacy.core.wait(0.25)
    elif node_type == "checkerboard":
        _checkerboard(ctx, node)
    elif node_type in {"generated_visual", "cue", "motor_cue", "imagery_cue"}:
        _generated_visual(ctx, node)
    elif node_type in {"video", "media_clip", "boundary_media"}:
        _play_video(ctx, node, _media_path(ctx, _text(node.get("media_key"))), list(node.get("capture_keys_during") or node.get("keys") or []))
    elif node_type == "media_playlist":
        paths = _playlist_paths(ctx, node)
        if not paths:
            raise RuntimeError(f"Media playlist {node.get('id')} contains no playable files.")
        for index, path in enumerate(paths, start=1):
            ctx.marker_on_flip(f"{_text(node.get('id')).upper()}_ITEM_{index:03d}_ONSET", node=node, payload={"path": str(path)})
            _play_video(ctx, node, path, list(node.get("capture_keys_during") or []))
            ctx.marker_on_flip(f"{_text(node.get('id')).upper()}_ITEM_{index:03d}_OFFSET", node=node)
            ctx.window.flip()
    elif node_type == "audio":
        _play_audio(ctx, node, _media_path(ctx, _text(node.get("media_key"))))
    elif node_type in {"rapid_trials", "oddball", "block", "ssvep_trials"}:
        children = node.get("children")
        if node_type == "block" and isinstance(children, list) and children:
            for child_index, child in enumerate(children, start=1):
                if not isinstance(child, Mapping):
                    raise RuntimeError(f"Block {node.get('id')} child {child_index} is malformed.")
                child_node = {
                    **dict(child),
                    "compiled_instance_id": f"{node.get('compiled_instance_id')}::{child.get('id')}::{child_index:03d}",
                }
                _execute_marked_node(ctx, child_node)
        else:
            _run_trials(ctx, node)
    elif node_type in {
        "keypress_capture", "question", "response_prompt", "questionnaire",
        "attention_probe", "confidence", "rating", "image_choice",
        "image_ranking", "ranking_task", "free_recall", "follow_up",
        "delayed_follow_up",
    }:
        _run_response(ctx, node)
    else:
        raise RuntimeError(f"No Atlas runtime dispatcher exists for node type {node_type!r}.")


def _preflight_hold(legacy: Any, outlet: Any, logger: AtlasEventLogger, record: AtlasRecord) -> None:
    window = legacy.visual.Window(size=(980, 680), fullscr=False, units="pix", color=[-1, -1, -1], allowGUI=True)
    message = legacy.visual.TextStim(
        window,
        text=(
            f"Protocol Atlas ready: {record.display_name}\n\n"
            "The StasisMarkers stream is online. In LabRecorder, click Update, confirm the approved acquisition streams, then Start.\n\n"
            "Press SPACE here only after recording has started. Escape cancels the run."
        ),
        color="white",
        height=28,
        wrapWidth=850,
    )
    clock = legacy.core.Clock()
    last_ping = -1.0
    legacy.event.clearEvents()
    try:
        while True:
            message.draw()
            window.flip()
            now = clock.getTime()
            if now - last_ping >= 1.0:
                marker = "ATLAS_LSL_PREFLIGHT_PING"
                timestamp = float(legacy.local_clock())
                outlet.push_sample([marker], timestamp=timestamp)
                logger.log(marker, event_kind="preflight", lsl_time=timestamp)
                last_ping = now
            keys = legacy.event.getKeys(keyList=["space", "escape"])
            if "escape" in keys:
                raise AtlasAbort("Operator cancelled at the LabRecorder preflight hold.")
            if "space" in keys:
                return
            legacy.core.wait(0.01)
    finally:
        window.close()


def _load_resume_index(record: AtlasRecord, compiled: Mapping[str, Any]) -> int:
    # Resume requires a new authority design that binds the checkpoint to the
    # same run UUID, lease, asset snapshot, and schedule.  The controlled runner therefore
    # always begins at the first compiled node.
    if _text(os.environ.get("PRAYCG_RESUME_CHECKPOINT_JSON")):
        raise RuntimeError("Protocol Atlas resume is disabled for controlled acquisition; create a new session.")
    return 0


def _finalized_artifact(path: Path) -> dict[str, Any]:
    exists = path.is_file()
    return {
        "path": str(path),
        "exists": exists,
        "size_bytes": path.stat().st_size if exists else None,
        "sha256": sha256_file(path) if exists else None,
    }


def _advance_finalize(legacy: Any, lock_path: Path, record: AtlasRecord, logger: AtlasEventLogger, run_state: AtlasRunState) -> None:
    lock = legacy.load_platform_json(lock_path)
    report = legacy.validate_platform_session_lock(lock)
    if report.status == "INELIGIBLE" or lock.get("current_stage") != "ACQUIRE":
        raise RuntimeError("The Atlas runtime session is no longer valid at FINALIZE.")
    operator = _text(os.environ.get("PRAYCG_SESSION_OPERATOR")) or _text(lock.get("lock_core", {}).get("operator"))
    legacy.advance_platform_session_gate(
        lock,
        "FINALIZE",
        lock_path,
        operator=operator,
        evidence={
            "run_uuid": logger.run_uuid,
            "protocol_id": record.protocol_id,
            "protocol_version": record.protocol_version,
            "run_state": run_state.payload.get("state"),
            "session_purpose": run_state.payload.get("session_purpose"),
            "participant_data_eligible": run_state.payload.get("participant_data_eligible"),
            "bench_test_mode": run_state.payload.get("bench_test_mode"),
            "bench_readiness_bypass_active": run_state.payload.get("bench_readiness_bypass_active"),
            "bench_test_reason": run_state.payload.get("bench_test_reason"),
            "bench_hardware_role_bypass": run_state.payload.get("bench_hardware_role_bypass"),
            "event_log_json": _finalized_artifact(logger.json_path),
            "event_log_csv": _finalized_artifact(logger.csv_path),
            "response_log_json": _finalized_artifact(logger.responses_path),
            "run_state_manifest": _finalized_artifact(run_state.path),
        },
    )


def _advance_prelog_failure_finalize(legacy: Any, lock_path: Path, record: AtlasRecord, reason: str) -> None:
    """Close ACQUIRE cleanly when setup fails before an event log can exist."""
    lock = legacy.load_platform_json(lock_path)
    report = legacy.validate_platform_session_lock(lock)
    if report.status == "INELIGIBLE" or lock.get("current_stage") != "ACQUIRE":
        return
    operator = _text(os.environ.get("PRAYCG_SESSION_OPERATOR")) or _text(lock.get("lock_core", {}).get("operator"))
    legacy.advance_platform_session_gate(
        lock,
        "FINALIZE",
        lock_path,
        operator=operator,
        evidence={
            "run_uuid": _text(os.environ.get("PRAYCG_RUN_UUID")),
            "protocol_id": record.protocol_id,
            "protocol_version": record.protocol_version,
            "run_state": "INCOMPLETE_BEFORE_EVENT_LOG",
            "reason": reason,
            "session_purpose": lock.get("session", {}).get("session_purpose"),
            "participant_data_eligible": lock.get("session", {}).get("participant_data_eligible"),
            "bench_test_mode": lock.get("session", {}).get("bench_test_mode"),
            "bench_readiness_bypass_active": lock.get("session", {}).get("bench_readiness_bypass_active"),
            "event_log_json": {"path": None, "exists": False, "size_bytes": None, "sha256": None},
            "event_log_csv": {"path": None, "exists": False, "size_bytes": None, "sha256": None},
            "response_log_json": {"path": None, "exists": False, "size_bytes": None, "sha256": None},
            "run_state_manifest": {"path": None, "exists": False, "size_bytes": None, "sha256": None},
        },
    )


def _run_authorized(record: AtlasRecord) -> dict[str, Any]:
    _reject_unbound_atlas_runtime_environment()
    legacy = _legacy_runtime()
    # The imported decorator performs pre-body ACQUIRE validation, atomic token
    # consumption, exact PID/start binding, heartbeat, and terminal lease close.
    @legacy.authorized_runner_lease_guard
    def execute() -> dict[str, Any]:
        lock_path, lock = legacy.load_runtime_session_authority(required_stage="ACQUIRE")
        try:
            participant = _text(os.environ.get("PRAYCG_PARTICIPANT_PSEUDONYM"))
            run_uuid = _text(os.environ.get("PRAYCG_RUN_UUID"))
            session_index = _session_index(lock)
            locked_parameters = lock.get("session", {}).get("protocol_parameters", {})
            if not isinstance(locked_parameters, Mapping):
                raise RuntimeError("The locked Atlas protocol parameters are malformed.")
            locked_seed = lock.get("session", {}).get("protocol_randomization_seed")
            if locked_seed is not None and (isinstance(locked_seed, bool) or not isinstance(locked_seed, int)):
                raise RuntimeError("The locked Atlas randomization seed is malformed.")
            bindings = _binding_from_snapshot(_locked_assets(lock))
            if record.protocol_id == EMD_PROTOCOL_ID:
                # EMD schedule semantics were validated and compiled before
                # authority lock. Live execution re-hashes the locked tree but
                # never reparses schedule/selection JSON or chooses a run from
                # process environment state.
                assets = _normalize_locked_emd_assets(record, bindings)
                compiled = _locked_emd_compiled_plan(lock)
            else:
                assets = normalize_asset_bindings(record, bindings)
                compiled = compile_timeline(
                    record,
                    participant_id=participant,
                    session_index=session_index,
                    seed=locked_seed,
                    parameters=locked_parameters,
                    asset_bindings=assets,
                )
            lock_path, lock = _validate_runtime_binding(legacy, record, compiled, assets, required_stage="ACQUIRE")
            policy = lock.get("session", {}).get("runner_configuration_policy", {})
            log_value = _text(policy.get("session_log_dir"))
            if not log_value:
                raise RuntimeError("The locked runner policy has no session_log_dir.")
            log_dir = Path(log_value).expanduser().resolve(strict=False)
            logger = AtlasEventLogger(log_dir, record, compiled, participant, run_uuid)
            run_state = AtlasRunState(logger, record, compiled, assets, lock.get("session", {}))
        except BaseException as exc:
            try:
                _advance_prelog_failure_finalize(legacy, Path(lock_path), record, repr(exc))
            except Exception as finalize_exc:
                print(f"Protocol Atlas pre-log FINALIZE could not be recorded: {finalize_exc}", file=sys.stderr)
            raise
        outlet = None
        window = None
        runtime_gate_acquired = True
        try:
            info = legacy.StreamInfo(
                "StasisMarkers",
                "Markers",
                1,
                0,
                "string",
                source_id=f"PRAYCG-Atlas-{run_uuid}",
            )
            description = info.desc()
            description.append_child_value("session_purpose", str(run_state.payload["session_purpose"]))
            description.append_child_value("participant_data_eligible", str(bool(run_state.payload["participant_data_eligible"])).lower())
            description.append_child_value("bench_test_mode", str(bool(run_state.payload["bench_test_mode"])).lower())
            description.append_child_value("bench_readiness_bypass_active", str(bool(run_state.payload["bench_readiness_bypass_active"])).lower())
            description.append_child_value("bench_test_reason", str(run_state.payload["bench_test_reason"]))
            description.append_child_value(
                "bench_hardware_role_bypass_active",
                str(bool(run_state.payload["bench_hardware_role_bypass"].get("active"))).lower(),
            )
            outlet = legacy.StreamOutlet(info)
            logger.log("ATLAS_AUTHORITY_BOUND", event_kind="authority", payload={
                "manifest_sha256": record.manifest_sha256,
                "runner_sha256": record.runner_sha256,
                "engine_sha256": record.engine_sha256,
                "compiled_timeline_sha256": compiled.get("canonical_sha256"),
                "session_purpose": run_state.payload["session_purpose"],
                "participant_data_eligible": run_state.payload["participant_data_eligible"],
                "bench_test_mode": run_state.payload["bench_test_mode"],
                "bench_readiness_bypass_active": run_state.payload["bench_readiness_bypass_active"],
                "bench_test_reason": run_state.payload["bench_test_reason"],
                "bench_hardware_role_bypass": run_state.payload["bench_hardware_role_bypass"],
            })
            purpose_markers = [
                f"SESSION_PURPOSE_{run_state.payload['session_purpose']}",
                f"PARTICIPANT_DATA_ELIGIBLE_{'TRUE' if run_state.payload['participant_data_eligible'] else 'FALSE'}",
                f"BENCH_TEST_MODE_{'TRUE' if run_state.payload['bench_test_mode'] else 'FALSE'}",
            ]
            if run_state.payload["bench_test_mode"]:
                purpose_markers.append("BENCH_TEST_REASON_RECORDED")
            if run_state.payload["bench_hardware_role_bypass"].get("active") is True:
                purpose_markers.append("BENCH_HARDWARE_ROLE_BYPASS_ACTIVE")
            for marker in purpose_markers:
                timestamp = float(legacy.local_clock())
                outlet.push_sample([marker], timestamp=timestamp)
                logger.log(
                    marker,
                    event_kind="authority",
                    payload=(
                        run_state.payload["bench_test_reason"]
                        if marker == "BENCH_TEST_REASON_RECORDED"
                        else run_state.payload["bench_hardware_role_bypass"]
                        if marker == "BENCH_HARDWARE_ROLE_BYPASS_ACTIVE"
                        else None
                    ),
                    lsl_time=timestamp,
                )
            for key, value in build_asset_snapshot(record, assets).items():
                timestamp = float(legacy.local_clock())
                marker = f"ATLAS_ASSET_{_safe_name(key).upper()}_{value['sha256'][:12].upper()}"
                outlet.push_sample([marker], timestamp=timestamp)
                logger.log(marker, event_kind="asset", payload=value, lsl_time=timestamp)
            run_state.transition("READY", "authority_and_asset_identity_verified")
            _preflight_hold(legacy, outlet, logger, record)

            # Revalidate after the operator interaction and immediately before
            # the fullscreen protocol window/first analyzable event.
            _validate_runtime_binding(legacy, record, compiled, assets, required_stage="ACQUIRE")
            window = legacy.visual.Window(
                size=(1920, 1080),
                fullscr=bool(policy.get("fullscreen", True)),
                screen=int(float(policy.get("screen_index", 0))),
                units="pix",
                color=[-1, -1, -1],
                allowGUI=False,
            )
            ctx = RuntimeContext(legacy, record, compiled, assets, logger, run_state, outlet, window, dict(policy))
            start_index = _load_resume_index(record, compiled)
            run_state.transition("RUNNING", f"start_index={start_index}")
            ctx.marker("ATLAS_PROTOCOL_START", payload={
                "protocol_id": record.protocol_id,
                "protocol_version": record.protocol_version,
                "sequence_id": compiled.get("sequence_id"),
                "seed": compiled.get("randomization_seed"),
                "resume_index": start_index,
                "visual_boundary_clock": "psychopy_callOnFlip_plus_pylsl_local_clock",
                "als_barcode_policy_enabled": policy.get("enable_runner_als_barcode") is True,
                "als_barcode_scope": "eligible_continuous_media_nodes_only",
                "session_purpose": run_state.payload["session_purpose"],
                "participant_data_eligible": run_state.payload["participant_data_eligible"],
                "bench_test_mode": run_state.payload["bench_test_mode"],
                "bench_readiness_bypass_active": run_state.payload["bench_readiness_bypass_active"],
                "bench_test_reason": run_state.payload["bench_test_reason"],
                "bench_hardware_role_bypass": run_state.payload["bench_hardware_role_bypass"],
            })
            for index, node in enumerate(compiled.get("timeline", [])):
                if index < start_index:
                    continue
                if not isinstance(node, Mapping):
                    raise RuntimeError(f"Compiled Atlas timeline node {index} is malformed.")
                _execute_marked_node(ctx, node, payload={"type": node.get("type"), "index": index})
                run_state.checkpoint(index)
            ctx.marker("ATLAS_PROTOCOL_END")
            run_state.transition("COMPLETED", "all_compiled_timeline_nodes_completed")
        except AtlasAbort as exc:
            if outlet is not None:
                timestamp = float(legacy.local_clock())
                outlet.push_sample(["ATLAS_RUN_INCOMPLETE"], timestamp=timestamp)
                logger.log("ATLAS_RUN_INCOMPLETE", event_kind="abort", payload=str(exc), lsl_time=timestamp)
            run_state.transition("INCOMPLETE", str(exc))
        except BaseException as exc:
            if outlet is not None:
                try:
                    timestamp = float(legacy.local_clock())
                    outlet.push_sample(["ATLAS_RUN_EXCEPTION"], timestamp=timestamp)
                    logger.log("ATLAS_RUN_EXCEPTION", event_kind="exception", payload=repr(exc), lsl_time=timestamp)
                except Exception:
                    pass
            run_state.transition("INCOMPLETE", repr(exc))
            raise
        finally:
            try:
                logger.close()
            finally:
                if runtime_gate_acquired:
                    try:
                        _advance_finalize(legacy, lock_path, record, logger, run_state)
                    except Exception as exc:
                        print(f"Protocol Atlas FINALIZE gate could not be recorded: {exc}", file=sys.stderr)
                if window is not None:
                    try:
                        window.close()
                    except Exception:
                        pass
        return {
            "status": run_state.payload.get("state"),
            "run_state_path": str(run_state.path),
            "events_json": str(logger.json_path),
            "responses_json": str(logger.responses_path),
        }

    return execute()


def dry_run_protocol(
    record: AtlasRecord,
    *,
    participant_id: str = "DRYRUN",
    session_index: int = 1,
    seed: int | None = None,
) -> dict[str, Any]:
    """Compile and inspect a module without PsychoPy, LSL, assets, or authority."""
    compiled = compile_timeline(
        record,
        participant_id=participant_id,
        session_index=session_index,
        seed=seed,
    )
    external_assets = [
        {
            "key": item.get("key"),
            "required": item.get("required"),
            "kind": item.get("kind"),
            "allowed_extensions": item.get("allowed_extensions", []),
        }
        for item in record.module.get("assets", [])
        if isinstance(item, Mapping) and item.get("source") == "operator_selection"
    ]
    return {
        "schema": "PRAYCG_ProtocolAtlas_DryRun_v2_0",
        "status": "PASS",
        "scope": "SCHEMA_AND_DETERMINISTIC_COMPILATION_ONLY",
        "runtime_authority_exercised": False,
        "psychopy_exercised": False,
        "hardware_stack_effect": "NONE",
        "protocol_id": record.protocol_id,
        "protocol_version": record.protocol_version,
        "manifest_sha256": record.manifest_sha256,
        "runner_sha256": record.runner_sha256,
        "engine_sha256": record.engine_sha256,
        "external_assets_not_opened": external_assets,
        "compiled_timeline": compiled,
        "boundaries": list(record.module.get("safety_and_claim_boundaries") or []),
    }


def run_protocol_manifest(
    path_or_manifest: Path | str | Mapping[str, Any],
    *,
    dry_run: bool = False,
    participant_id: str = "DRYRUN",
    session_index: int = 1,
    seed: int | None = None,
) -> dict[str, Any]:
    """Load one reviewed Atlas module and either inspect or run it.

    Mapping inputs are intentionally accepted only for dry-run validation.
    Actual acquisition requires a packaged manifest file so the Control Center
    can bind its byte hash into the one-use launch authority.
    """
    if isinstance(path_or_manifest, Mapping):
        if not dry_run:
            raise AtlasValidationError(["Actual acquisition requires a packaged manifest path, not an in-memory object"])
        from praycg_protocol_atlas_core_v2_0 import validate_protocol_module
        record = validate_protocol_module(path_or_manifest, LIBRARY_ROOT)
    else:
        record = load_protocol_module(Path(path_or_manifest), LIBRARY_ROOT)
    if dry_run:
        return dry_run_protocol(record, participant_id=participant_id, session_index=session_index, seed=seed)
    return _run_authorized(record)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run one reviewed PRAYCG Protocol Atlas module.")
    parser.add_argument("--manifest", required=True, help="Packaged Atlas protocol JSON path")
    parser.add_argument("--dry-run", action="store_true", help="Validate and compile without acquisition")
    parser.add_argument("--participant-id", default="DRYRUN", help="Dry-run pseudonym")
    parser.add_argument("--session-index", type=int, default=1, help="Dry-run session index")
    parser.add_argument("--seed", type=int, help="Optional dry-run randomization seed")
    args = parser.parse_args(argv)
    result = run_protocol_manifest(
        Path(args.manifest),
        dry_run=args.dry_run,
        participant_id=args.participant_id,
        session_index=args.session_index,
        seed=args.seed,
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result.get("status") in {"PASS", "COMPLETED"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
