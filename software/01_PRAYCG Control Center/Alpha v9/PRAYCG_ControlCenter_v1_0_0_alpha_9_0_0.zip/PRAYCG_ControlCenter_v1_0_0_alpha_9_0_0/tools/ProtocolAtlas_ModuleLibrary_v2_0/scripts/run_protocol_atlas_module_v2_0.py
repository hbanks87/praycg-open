#!/usr/bin/env python3
"""Generic reviewed-module entry for PRAYCG Protocol Atlas v2.0."""
from __future__ import annotations

from praycg_protocol_atlas_engine_v2_0 import main


if __name__ == "__main__":
    raise SystemExit(main())
