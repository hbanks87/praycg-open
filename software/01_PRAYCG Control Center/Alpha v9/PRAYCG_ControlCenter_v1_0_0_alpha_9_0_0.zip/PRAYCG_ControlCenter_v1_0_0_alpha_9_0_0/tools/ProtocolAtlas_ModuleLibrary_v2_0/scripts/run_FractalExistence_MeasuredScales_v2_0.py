#!/usr/bin/env python3
"""Launch the three-session measured-scale Fractal Existence protocol."""
from argparse import ArgumentParser
from pathlib import Path

from praycg_protocol_atlas_engine_v2_0 import run_protocol_manifest

MANIFEST = Path(__file__).resolve().parents[1] / "protocols" / "Fractal_existence_measured_scales_v2_0.json"


def main() -> None:
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="Validate and compile without acquisition.")
    parser.add_argument("--participant-id", default="DRYRUN", help="Dry-run pseudonym.")
    parser.add_argument("--session-index", type=int, default=1, help="Dry-run session index.")
    parser.add_argument("--seed", type=int, help="Optional dry-run seed.")
    args = parser.parse_args()
    result = run_protocol_manifest(
        MANIFEST,
        dry_run=args.dry_run,
        participant_id=args.participant_id,
        session_index=args.session_index,
        seed=args.seed,
    )
    if args.dry_run:
        import json
        print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
