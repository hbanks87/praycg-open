#!/usr/bin/env python3
"""Launch the reviewed NARR-derived coarse-order audio adaptation."""
from argparse import ArgumentParser
from pathlib import Path

from praycg_protocol_atlas_engine_v2_0 import run_protocol_manifest


MANIFEST = (
    Path(__file__).resolve().parents[1]
    / "protocols"
    / "NARR_audio_story_coarse_scramble_adaptation_v1_0.json"
)


def main() -> None:
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="Validate and simulate without acquisition.")
    args = parser.parse_args()
    run_protocol_manifest(MANIFEST, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
