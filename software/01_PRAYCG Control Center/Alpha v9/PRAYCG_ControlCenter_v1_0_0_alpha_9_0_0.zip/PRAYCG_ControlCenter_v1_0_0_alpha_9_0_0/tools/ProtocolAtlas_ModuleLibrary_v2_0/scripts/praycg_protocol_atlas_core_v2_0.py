#!/usr/bin/env python3
"""Strict discovery and deterministic compilation for Protocol Atlas v2.0.

The Atlas is a data-only protocol layer.  A manifest may describe stimuli,
timing, generated visual tasks and response collection, but it may not embed or
select executable code.  All execution is dispatched by the packaged, hashed
Atlas engine after the Control Center has completed its normal acquisition
authority flow.
"""
from __future__ import annotations

import hashlib
import json
import os
import random
import re
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, MutableMapping, Sequence


ATLAS_SCHEMA = "PRAYCG_ProtocolAtlasModule_v2_0"
ATLAS_ENGINE_ID = "praycg_protocol_atlas_engine"
ATLAS_ENGINE_VERSION = "2.0"
ATLAS_LOCK_SCHEMA = "PRAYCG_ProtocolAtlasLock_v2_0"
EMD_PROTOCOL_ID = "ATLAS_EEG_MOMENTS_CLIPS_ADAPTATION"
EMD_MEDIA_MANIFEST_SCHEMA = "PRAYCG_ExternalMediaManifest_v1_0"
EMD_SCHEDULE_SCHEMA = "PRAYCG_ClipSchedule_v1_0"
EMD_SELECTION_SCHEMA = "PRAYCG_ClipScheduleSelection_v1_0"

ENGINE_FAMILIES = frozenset({
    "rest",
    "audio_narrative",
    "continuous_media",
    "event_segmentation",
    "rapid_media",
    "generated_erp",
    "motor_imagery",
    "image_ranking",
    "multi_session_composite",
    "ssvep",
})

NODE_TYPES = frozenset({
    "instruction",
    "wait_for_operator",
    "fixation",
    "rest",
    "eyes_closed_rest",
    "blank",
    "interval",
    "break",
    "blink_window",
    "audio",
    "video",
    "media_clip",
    "media_playlist",
    "rapid_trials",
    "checkerboard",
    "ssvep_trials",
    "oddball",
    "generated_visual",
    "cue",
    "motor_cue",
    "imagery_cue",
    "keypress_capture",
    "boundary_media",
    "question",
    "response_prompt",
    "questionnaire",
    "attention_probe",
    "confidence",
    "rating",
    "image_choice",
    "image_ranking",
    "ranking_task",
    "free_recall",
    "block",
    "follow_up",
    "delayed_follow_up",
})

ASSET_KINDS = frozenset({
    "audio",
    "video",
    "image",
    "image_sequence",
    "directory",
    "trial_manifest",
    "schedule",
    "text",
    "anchor",
    "generated_visual",
    "generated_audio",
    "generated_sequence",
})

RANDOMIZATION_MODES = frozenset({
    "none",
    "fixed",
    "seeded_shuffle",
    "latin_square",
    "williams",
    "scheduled",
})

APPROVAL_STATES = frozenset({
    "APPROVED_FOR_ALPHA_TEST",
    "APPROVED_FOR_FEASIBILITY",
    "APPROVED_FOR_USE",
})

# These are semantic acquisition roles, not device names or LSL outlet names.
# Atlas modules may require a role but remain unable to select a hardware
# profile; the reviewed Acquisition-tab profile remains the sole authority.
HARDWARE_ROLES = frozenset({
    "eeg", "eog", "emg", "ecg", "rr_intervals", "heart_rate",
    "respiration", "eda", "ppg", "analog_aux", "als", "markers",
    "video", "audio",
})

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{1,95}$")
_VERSION_RE = re.compile(r"^[0-9]+(?:\.[0-9]+){1,3}(?:-[A-Za-z0-9.-]+)?$")
_MARKER_RE = re.compile(r"^[A-Z0-9][A-Z0-9_.:/-]{1,127}$")
_FORBIDDEN_KEYS = frozenset({
    "command",
    "commands",
    "command_line",
    "executable",
    "executable_path",
    "python_code",
    "source_code",
    "shell",
    "powershell",
    "subprocess",
    "eval",
    "exec",
    "dynamic_import",
    "plugin_entry",
})


class AtlasValidationError(ValueError):
    """Raised when an Atlas entry cannot be safely loaded or compiled."""

    def __init__(self, errors: Iterable[str]):
        self.errors = tuple(str(item) for item in errors if str(item).strip())
        super().__init__("; ".join(self.errors) or "Protocol Atlas validation failed.")


@dataclass(frozen=True)
class AtlasRecord:
    manifest_path: Path
    manifest_sha256: str
    runner_path: Path
    runner_sha256: str
    engine_path: Path
    engine_sha256: str
    protocol_id: str
    protocol_version: str
    display_name: str
    engine_family: str
    required_asset_keys: tuple[str, ...]
    timeline_node_types: tuple[str, ...]
    module: Mapping[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "manifest_path": str(self.manifest_path),
            "manifest_sha256": self.manifest_sha256,
            "runner_path": str(self.runner_path),
            "runner_sha256": self.runner_sha256,
            "engine_path": str(self.engine_path),
            "engine_sha256": self.engine_sha256,
            "protocol_id": self.protocol_id,
            "protocol_version": self.protocol_version,
            "display_name": self.display_name,
            "short_description": str(self.module.get("short_description") or ""),
            "engine_family": self.engine_family,
            "required_asset_keys": list(self.required_asset_keys),
            "timeline_node_types": list(self.timeline_node_types),
            "hardware_stack_effect": "NONE",
            "hardware_profile_id": None,
            "scientific_boundary": list(self.module.get("safety_and_claim_boundaries") or []),
            "module": deepcopy(dict(self.module)),
        }


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_path(path: Path) -> str:
    """Hash one file or a directory tree without following out-of-tree links."""
    path = Path(path).expanduser().resolve(strict=True)
    if path.is_file():
        return sha256_file(path)
    if not path.is_dir():
        raise AtlasValidationError([f"Cannot hash unsupported asset path: {path}"])
    digest = hashlib.sha256()
    for child in sorted((item for item in path.rglob("*") if item.is_file()), key=lambda item: item.relative_to(path).as_posix().casefold()):
        relative = child.relative_to(path).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(sha256_file(child)))
        digest.update(b"\0")
    return digest.hexdigest()


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def compiled_timeline_identity_sha256(compiled_timeline: Mapping[str, Any]) -> str:
    """Validate and return the self-excluding hash of one compiled timeline.

    ``compile_timeline`` stores ``canonical_sha256`` as the hash of the
    compiled payload before that identity field is added.  Re-hashing the
    complete mapping would therefore produce a different digest.  Keeping the
    self-excluding rule in one helper prevents design-time locks and the live
    runner from applying incompatible identity rules.
    """
    if not isinstance(compiled_timeline, Mapping):
        raise AtlasValidationError(["compiled timeline must be an object"])
    stored = str(compiled_timeline.get("canonical_sha256") or "").strip().casefold()
    calculated = canonical_sha256({
        key: value
        for key, value in compiled_timeline.items()
        if key != "canonical_sha256"
    })
    if not re.fullmatch(r"[0-9a-f]{64}", stored) or stored != calculated:
        raise AtlasValidationError(["compiled timeline canonical identity is missing or changed"])
    return calculated


def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except (OSError, ValueError):
        return False


def _text(value: Any) -> str:
    return str(value or "").strip()


def _list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _walk_forbidden(value: Any, location: str, errors: list[str]) -> None:
    if isinstance(value, Mapping):
        for raw_key, child in value.items():
            key = str(raw_key)
            if key.casefold() in _FORBIDDEN_KEYS:
                errors.append(f"{location}.{key} is forbidden; Atlas modules cannot embed executable instructions")
            _walk_forbidden(child, f"{location}.{key}", errors)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _walk_forbidden(child, f"{location}[{index}]", errors)


def _resolve_packaged_file(library_root: Path, relative_value: Any, folder: str, label: str, errors: list[str]) -> Path:
    relative = Path(_text(relative_value))
    candidate = (library_root / relative).resolve(strict=False)
    expected_root = (library_root / folder).resolve(strict=False)
    if relative.is_absolute() or not _within(candidate, expected_root):
        errors.append(f"{label} must stay inside the packaged {folder} directory")
    elif candidate.suffix.lower() != ".py":
        errors.append(f"{label} must be a packaged Python file")
    elif not candidate.is_file():
        errors.append(f"{label} does not exist: {relative_value}")
    return candidate


def _validate_identity(payload: Mapping[str, Any], errors: list[str]) -> None:
    if payload.get("schema") != ATLAS_SCHEMA:
        errors.append(f"schema must be exactly {ATLAS_SCHEMA}")
    protocol_id = _text(payload.get("protocol_id"))
    version = _text(payload.get("protocol_version"))
    if not _ID_RE.fullmatch(protocol_id):
        errors.append("protocol_id must contain only letters, digits, periods, underscores, or hyphens")
    if not _VERSION_RE.fullmatch(version):
        errors.append("protocol_version must be a numeric dotted version")
    for field in ("display_name", "short_description"):
        if not _text(payload.get(field)):
            errors.append(f"{field} must be nonblank")


def _validate_adaptation_and_rights(payload: Mapping[str, Any], errors: list[str]) -> None:
    adaptation = payload.get("adaptation_status")
    if not isinstance(adaptation, Mapping):
        errors.append("adaptation_status must be an object")
    else:
        required = ("classification", "exact_replication", "source_family", "basis", "departures", "verification_state")
        for field in required:
            if field not in adaptation:
                errors.append(f"adaptation_status.{field} is required")
        if not isinstance(adaptation.get("exact_replication"), bool):
            errors.append("adaptation_status.exact_replication must be boolean")
        if not isinstance(adaptation.get("departures"), list):
            errors.append("adaptation_status.departures must be a list")
    source = payload.get("source_attribution")
    if not isinstance(source, Mapping):
        errors.append("source_attribution must be an object")
    else:
        for field in ("primary_source", "title", "license_note"):
            if not _text(source.get(field)):
                errors.append(f"source_attribution.{field} must be nonblank")


def _validate_engine_and_hardware(payload: Mapping[str, Any], errors: list[str]) -> str:
    engine = payload.get("engine")
    family = ""
    if not isinstance(engine, Mapping):
        errors.append("engine must be an object")
    else:
        if engine.get("id") != ATLAS_ENGINE_ID:
            errors.append(f"engine.id must be exactly {ATLAS_ENGINE_ID}")
        if _text(engine.get("version")) != ATLAS_ENGINE_VERSION:
            errors.append(f"engine.version must be exactly {ATLAS_ENGINE_VERSION}")
        family = _text(engine.get("family"))
        if family not in ENGINE_FAMILIES:
            errors.append(f"engine.family is unsupported: {family!r}")
    if payload.get("hardware_stack_effect") != "NONE":
        errors.append("hardware_stack_effect must be exactly NONE")
    if payload.get("hardware_profile_id") is not None:
        errors.append("hardware_profile_id must be null; protocol modules cannot choose hardware")
    acquisition = payload.get("acquisition_contract")
    if not isinstance(acquisition, Mapping):
        errors.append("acquisition_contract must be an object")
    else:
        for field in ("independent_acquisition_required", "operator_controls_hardware_elsewhere"):
            if acquisition.get(field) is not True:
                errors.append(f"acquisition_contract.{field} must be true")
        if not _text(acquisition.get("marker_namespace")):
            errors.append("acquisition_contract.marker_namespace must be nonblank")
        streams = acquisition.get("expected_streams")
        if not isinstance(streams, list):
            errors.append("acquisition_contract.expected_streams must be a list")
        roles = acquisition.get("required_hardware_roles")
        if not isinstance(roles, list) or not roles:
            errors.append("acquisition_contract.required_hardware_roles must be a nonempty list of semantic roles")
        else:
            normalized_roles = [_text(role).casefold() for role in roles]
            if any(not role or role not in HARDWARE_ROLES for role in normalized_roles):
                errors.append("acquisition_contract.required_hardware_roles contains an unsupported semantic role")
            if len(normalized_roles) != len(set(normalized_roles)):
                errors.append("acquisition_contract.required_hardware_roles cannot repeat a role")
        if acquisition.get("emit_runner_registered_events") is not True:
            errors.append("acquisition_contract.emit_runner_registered_events must be true")
        if _text(acquisition.get("event_clock")) != "lsl_local_clock_with_flip_synchronized_visual_events":
            errors.append(
                "acquisition_contract.event_clock must truthfully declare "
                "lsl_local_clock_with_flip_synchronized_visual_events"
            )
    return family


def hardware_role_compatibility_errors(
    protocol: Mapping[str, Any],
    hardware_profile: Mapping[str, Any],
) -> list[str]:
    """Compare only semantic roles; never choose or rewrite hardware.

    This intentionally narrow check does not infer sampling adequacy, channel
    quality, timing validity, or whether a named outlet is live.  Those remain
    the Acquisition-tab profile/preflight responsibilities.
    """
    acquisition = protocol.get("acquisition_contract")
    required = {
        _text(role).casefold()
        for role in acquisition.get("required_hardware_roles", [])
    } if isinstance(acquisition, Mapping) else set()
    resolved_roles = hardware_profile.get("resolved_roles")
    available = {
        _text(role).casefold()
        for role, streams in resolved_roles.items()
        if _text(role)
        and isinstance(streams, list)
        and any(_text(stream) for stream in streams)
    } if isinstance(resolved_roles, Mapping) else set()
    for module in hardware_profile.get("modules", []):
        if not isinstance(module, Mapping):
            continue
        for stream in module.get("streams", []):
            if not isinstance(stream, Mapping):
                continue
            role = _text(stream.get("canonical_role")).casefold()
            has_stream_identity = bool(_text(stream.get("lsl_name")))
            if role and has_stream_identity:
                available.add(role)
            if has_stream_identity:
                available.update(
                    _text(item).casefold()
                    for item in stream.get("embedded_roles", [])
                    if _text(item)
                )
    missing = sorted(required - available)
    return [
        "reviewed hardware profile lacks required semantic role: " + role
        for role in missing
    ]


def _validate_approval(payload: Mapping[str, Any], errors: list[str]) -> None:
    approval = payload.get("approval")
    if not isinstance(approval, Mapping):
        errors.append("approval must be an object for an active Atlas entry")
        return
    if approval.get("status") not in APPROVAL_STATES:
        errors.append("approval.status is not an active reviewed state")
    for field in ("reviewer", "scope", "reviewed_utc"):
        if not _text(approval.get(field)):
            errors.append(f"approval.{field} must be nonblank")


def _validate_assets(payload: Mapping[str, Any], errors: list[str]) -> tuple[set[str], set[str]]:
    assets = payload.get("assets")
    if not isinstance(assets, list):
        errors.append("assets must be a list (use [] for generated/no-media protocols)")
        return set(), set()
    keys: set[str] = set()
    required: set[str] = set()
    for index, asset in enumerate(assets):
        prefix = f"assets[{index}]"
        if not isinstance(asset, Mapping):
            errors.append(f"{prefix} must be an object")
            continue
        key = _text(asset.get("key"))
        if not _ID_RE.fullmatch(key):
            errors.append(f"{prefix}.key is invalid")
        elif key in keys:
            errors.append(f"{prefix}.key is duplicated: {key}")
        keys.add(key)
        for field in ("role", "kind", "source"):
            if not _text(asset.get(field)):
                errors.append(f"{prefix}.{field} must be nonblank")
        if asset.get("kind") not in ASSET_KINDS:
            errors.append(f"{prefix}.kind is unsupported: {asset.get('kind')!r}")
        if not isinstance(asset.get("required"), bool):
            errors.append(f"{prefix}.required must be boolean")
        elif asset.get("required") and asset.get("source") == "operator_selection":
            required.add(key)
        source = asset.get("source")
        if source not in {"operator_selection", "generated"}:
            errors.append(f"{prefix}.source must be operator_selection or generated")
        if source == "operator_selection":
            extensions = asset.get("allowed_extensions")
            if not isinstance(extensions, list) or not extensions:
                errors.append(f"{prefix}.allowed_extensions must be a nonempty list")
            elif any(not _text(value).startswith(".") for value in extensions):
                errors.append(f"{prefix}.allowed_extensions values must be dot-prefixed")
            if asset.get("reviewed_local_only") is not True:
                errors.append(f"{prefix}.reviewed_local_only must be true")
        elif asset.get("allowed_extensions") not in (None, []):
            errors.append(f"{prefix}.generated assets cannot declare file extensions")
    return keys, required


def _node_markers(node: Mapping[str, Any], prefix: str, errors: list[str]) -> tuple[str, str | None]:
    markers = node.get("markers")
    if not isinstance(markers, Mapping):
        errors.append(f"{prefix}.markers must be an object with onset and offset")
        return "", None
    onset = _text(markers.get("onset"))
    raw_offset = markers.get("offset")
    offset = _text(raw_offset) if raw_offset is not None else None
    if not _MARKER_RE.fullmatch(onset):
        errors.append(f"{prefix}.markers.onset is invalid")
    if offset is not None and not _MARKER_RE.fullmatch(offset):
        errors.append(f"{prefix}.markers.offset is invalid")
    return onset, offset


def _validate_timeline(payload: Mapping[str, Any], asset_keys: set[str], errors: list[str]) -> tuple[str, ...]:
    timeline = payload.get("timeline")
    if not isinstance(timeline, list) or not timeline:
        errors.append("timeline must be a nonempty list")
        return ()
    ids: set[str] = set()
    marker_names: set[str] = set()
    node_types: list[str] = []
    media_types = {"audio", "video", "media_clip", "boundary_media"}
    def validate_node(node: Any, prefix: str) -> None:
        if not isinstance(node, Mapping):
            errors.append(f"{prefix} must be an object")
            return
        node_id = _text(node.get("id"))
        node_type = _text(node.get("type"))
        if not _ID_RE.fullmatch(node_id):
            errors.append(f"{prefix}.id is invalid")
        elif node_id in ids:
            errors.append(f"{prefix}.id is duplicated: {node_id}")
        ids.add(node_id)
        if node_type not in NODE_TYPES:
            errors.append(f"{prefix}.type is unsupported: {node_type!r}")
        node_types.append(node_type)
        onset, offset = _node_markers(node, prefix, errors)
        for marker in (onset, offset):
            if marker:
                if marker in marker_names:
                    errors.append(f"{prefix} reuses event marker {marker!r}")
                marker_names.add(marker)
        duration = node.get("duration_s")
        if duration is not None:
            if isinstance(duration, bool) or not isinstance(duration, (int, float)) or float(duration) < 0:
                errors.append(f"{prefix}.duration_s must be a nonnegative number")
        repeat = node.get("repeat", node.get("repeat_count", 1))
        if isinstance(repeat, bool) or not isinstance(repeat, int) or repeat < 1:
            errors.append(f"{prefix}.repeat/repeat_count must be a positive integer")
        if node_type in media_types:
            key = _text(node.get("media_key"))
            if not key or key not in asset_keys:
                errors.append(f"{prefix}.media_key must reference a declared asset")
        if node_type == "media_playlist":
            key = _text(node.get("media_set_key"))
            if not key or key not in asset_keys:
                errors.append(f"{prefix}.media_set_key must reference a declared asset")
        if node_type in {"block", "rapid_trials", "ssvep_trials"}:
            trials = node.get("trials", node.get("trial_template", node.get("randomized_trials")))
            if trials is None and not isinstance(node.get("trial_generator"), Mapping):
                errors.append(f"{prefix} requires trials, trial_template, randomized_trials, or trial_generator")
        generator = node.get("trial_generator")
        if generator is not None:
            if not isinstance(generator, Mapping):
                errors.append(f"{prefix}.trial_generator must be an object")
            else:
                if _text(generator.get("type")) != "balanced_rows":
                    errors.append(f"{prefix}.trial_generator.type must be balanced_rows")
                rows = generator.get("rows")
                rows_parameter = _text(generator.get("rows_parameter"))
                if not isinstance(rows, list) and not rows_parameter:
                    errors.append(f"{prefix}.trial_generator requires rows or rows_parameter")
                if not isinstance(generator.get("trial_template"), Mapping):
                    errors.append(f"{prefix}.trial_generator.trial_template must be an object")
        if node_type == "checkerboard":
            frequency = node.get("frequency_hz")
            if frequency is None or isinstance(frequency, bool) or not isinstance(frequency, (int, float)) or float(frequency) <= 0:
                errors.append(f"{prefix}.frequency_hz must be positive")
            record_flips = node.get("record_each_flip_timestamp")
            if record_flips is not None and not isinstance(record_flips, bool):
                errors.append(f"{prefix}.record_each_flip_timestamp must be boolean")
            tolerance = node.get("maximum_reversal_lateness_seconds")
            if tolerance is not None and (
                isinstance(tolerance, bool)
                or not isinstance(tolerance, (int, float))
                or float(tolerance) <= 0
            ):
                errors.append(f"{prefix}.maximum_reversal_lateness_seconds must be positive")
        if node_type == "ssvep_trials":
            targets = node.get("targets")
            if not isinstance(targets, list) or len(targets) < 2:
                errors.append(f"{prefix}.targets must contain at least two targets")
            else:
                seen_target_ids: set[str] = set()
                for target_index, target in enumerate(targets):
                    target_prefix = f"{prefix}.targets[{target_index}]"
                    if not isinstance(target, Mapping):
                        errors.append(f"{target_prefix} must be an object")
                        continue
                    target_id = _text(target.get("target_id"))
                    if not _ID_RE.fullmatch(target_id) or target_id in seen_target_ids:
                        errors.append(f"{target_prefix}.target_id must be valid and unique")
                    seen_target_ids.add(target_id)
                    frequency = target.get("frequency_hz")
                    if isinstance(frequency, bool) or not isinstance(frequency, (int, float)) or float(frequency) <= 0:
                        errors.append(f"{target_prefix}.frequency_hz must be positive")
                    phase = target.get("phase_radians", 0.0)
                    if isinstance(phase, bool) or not isinstance(phase, (int, float)):
                        errors.append(f"{target_prefix}.phase_radians must be numeric")
                    position = target.get("position")
                    if not isinstance(position, list) or len(position) != 2 or any(
                        isinstance(value, bool) or not isinstance(value, (int, float)) for value in position
                    ):
                        errors.append(f"{target_prefix}.position must be a numeric [x, y] pair")
            declared_refresh = node.get("declared_refresh_rate_hz")
            if isinstance(declared_refresh, bool) or not isinstance(declared_refresh, (int, float)) or float(declared_refresh) <= 0:
                errors.append(f"{prefix}.declared_refresh_rate_hz must be positive")
            tolerance = node.get("refresh_rate_tolerance_hz")
            if isinstance(tolerance, bool) or not isinstance(tolerance, (int, float)) or float(tolerance) <= 0:
                errors.append(f"{prefix}.refresh_rate_tolerance_hz must be positive")

        for asset_reference in ("image_manifest_key", "image_root_key"):
            referenced_key = _text(node.get(asset_reference))
            if referenced_key and referenced_key not in asset_keys:
                errors.append(f"{prefix}.{asset_reference} must reference a declared asset")

        skippable = node.get("skippable")
        if skippable is not None and not isinstance(skippable, bool):
            errors.append(f"{prefix}.skippable must be boolean")
        threshold = node.get("skippable_after_seconds")
        if threshold is not None:
            if node_type != "break":
                errors.append(f"{prefix}.skippable_after_seconds is allowed only on break nodes")
            if isinstance(threshold, bool) or not isinstance(threshold, (int, float)) or float(threshold) < 0:
                errors.append(f"{prefix}.skippable_after_seconds must be a nonnegative number")
            elif not isinstance(duration, (int, float)) or isinstance(duration, bool):
                errors.append(f"{prefix}.skippable_after_seconds requires a numeric duration_s")
            elif float(threshold) >= float(duration):
                errors.append(f"{prefix}.skippable_after_seconds must be less than duration_s")
            if skippable is False:
                errors.append(f"{prefix} cannot declare both skippable=false and skippable_after_seconds")
            skip_keys = node.get("skip_keys", ["space"])
            if not isinstance(skip_keys, list) or not skip_keys or any(not _text(key) for key in skip_keys):
                errors.append(f"{prefix}.skip_keys must be a nonempty list when a skip threshold is declared")

        children = node.get("children")
        if children is not None:
            if not isinstance(children, list):
                errors.append(f"{prefix}.children must be a list")
            else:
                for child_index, child in enumerate(children):
                    validate_node(child, f"{prefix}.children[{child_index}]")

        # Future manifests may place typed nodes in trial_template/nodes or a
        # comparable declarative container.  Validate every nested mapping
        # that identifies itself as a node, not only the current children key.
        def validate_other_typed(value: Any, location: str) -> None:
            if isinstance(value, Mapping):
                if "type" in value and ("id" in value or "markers" in value):
                    validate_node(value, location)
                    return
                for key, child in value.items():
                    validate_other_typed(child, f"{location}.{key}")
            elif isinstance(value, list):
                for nested_index, child in enumerate(value):
                    validate_other_typed(child, f"{location}[{nested_index}]")

        for field, value in node.items():
            if field != "children" and field not in {"markers", "trial_markers"}:
                validate_other_typed(value, f"{prefix}.{field}")

    for index, node in enumerate(timeline):
        validate_node(node, f"timeline[{index}]")
    return tuple(node_types)


def _validate_responses_and_handoff(payload: Mapping[str, Any], errors: list[str]) -> None:
    responses = payload.get("responses")
    if not isinstance(responses, list):
        errors.append("responses must be a list (use [] if the protocol records no participant response)")
    else:
        seen: set[str] = set()
        for index, response in enumerate(responses):
            prefix = f"responses[{index}]"
            if not isinstance(response, Mapping):
                errors.append(f"{prefix} must be an object")
                continue
            response_id = _text(response.get("id"))
            if not _ID_RE.fullmatch(response_id):
                errors.append(f"{prefix}.id is invalid")
            elif response_id in seen:
                errors.append(f"{prefix}.id is duplicated")
            seen.add(response_id)
            if not _text(response.get("type")):
                errors.append(f"{prefix}.type must be nonblank")
    handoff = payload.get("analysis_handoff")
    if not isinstance(handoff, Mapping):
        errors.append("analysis_handoff must be an object")
    else:
        for field in ("expected_events", "outcomes"):
            values = handoff.get(field)
            if not isinstance(values, list) or not values:
                errors.append(f"analysis_handoff.{field} must be a nonempty list")
        for field in ("event_schema", "response_schema"):
            if not _text(handoff.get(field)):
                errors.append(f"analysis_handoff.{field} must be nonblank")


def _validate_operational_metadata(payload: Mapping[str, Any], errors: list[str]) -> None:
    randomization = payload.get("randomization")
    if not isinstance(randomization, Mapping):
        errors.append("randomization must be an object")
    else:
        if randomization.get("mode") not in RANDOMIZATION_MODES:
            errors.append("randomization.mode is unsupported")
        if randomization.get("frozen_before_launch") is not True:
            errors.append("randomization.frozen_before_launch must be true")
        if randomization.get("seed_recorded") is not True:
            errors.append("randomization.seed_recorded must be true")
    stimulus = payload.get("stimulus_contract")
    if not isinstance(stimulus, Mapping):
        errors.append("stimulus_contract must be an object")
    else:
        if stimulus.get("review_required") is not True:
            errors.append("stimulus_contract.review_required must be true")
        if stimulus.get("restricted_media_bundled") is not False:
            errors.append("stimulus_contract.restricted_media_bundled must be false")
        if _text(stimulus.get("hash_algorithm")).upper().replace("_", "-") != "SHA-256":
            errors.append("stimulus_contract.hash_algorithm must be SHA-256")
    boundaries = payload.get("safety_and_claim_boundaries")
    if not isinstance(boundaries, list) or not boundaries or any(not _text(item) for item in boundaries):
        errors.append("safety_and_claim_boundaries must be a nonempty list of statements")
    for field in ("readiness_requirements", "dry_run_tests"):
        values = payload.get(field)
        if not isinstance(values, list) or not values:
            errors.append(f"{field} must be a nonempty list")


def validate_protocol_module(payload: Mapping[str, Any], library_root: Path) -> AtlasRecord:
    """Validate one manifest and resolve its three hashed executable identities."""
    if not isinstance(payload, Mapping):
        raise AtlasValidationError(["Protocol manifest root must be a JSON object"])
    errors: list[str] = []
    _walk_forbidden(payload, "$", errors)
    _validate_identity(payload, errors)
    _validate_adaptation_and_rights(payload, errors)
    family = _validate_engine_and_hardware(payload, errors)
    _validate_approval(payload, errors)
    asset_keys, required_asset_keys = _validate_assets(payload, errors)
    node_types = _validate_timeline(payload, asset_keys, errors)
    _validate_responses_and_handoff(payload, errors)
    _validate_operational_metadata(payload, errors)

    library_root = Path(library_root).expanduser().resolve(strict=False)
    runner_path = _resolve_packaged_file(library_root, payload.get("runner_entry"), "scripts", "runner_entry", errors)
    engine_path = _resolve_packaged_file(library_root, payload.get("engine_entry"), "scripts", "engine_entry", errors)
    if engine_path.name != "praycg_protocol_atlas_engine_v2_0.py":
        errors.append("engine_entry must select the packaged Protocol Atlas v2.0 engine")
    if errors:
        raise AtlasValidationError(errors)
    return AtlasRecord(
        manifest_path=Path(),
        manifest_sha256=canonical_sha256(payload),
        runner_path=runner_path,
        runner_sha256=sha256_file(runner_path),
        engine_path=engine_path,
        engine_sha256=sha256_file(engine_path),
        protocol_id=_text(payload.get("protocol_id")),
        protocol_version=_text(payload.get("protocol_version")),
        display_name=_text(payload.get("display_name")),
        engine_family=family,
        required_asset_keys=tuple(sorted(required_asset_keys)),
        timeline_node_types=node_types,
        module=deepcopy(dict(payload)),
    )


def load_protocol_module(path: Path | str, library_root: Path | str | None = None) -> AtlasRecord:
    path = Path(path).expanduser().resolve(strict=False)
    root = Path(library_root).expanduser().resolve(strict=False) if library_root else path.parent.parent
    protocol_root = (root / "protocols").resolve(strict=False)
    if not path.is_file() or path.suffix.lower() != ".json" or not _within(path, protocol_root):
        raise AtlasValidationError([f"Protocol manifest must be a JSON file inside {protocol_root}"])
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise AtlasValidationError([f"Cannot read {path.name}: {exc}"]) from exc
    record = validate_protocol_module(payload, root)
    return AtlasRecord(
        manifest_path=path,
        manifest_sha256=sha256_file(path),
        runner_path=record.runner_path,
        runner_sha256=record.runner_sha256,
        engine_path=record.engine_path,
        engine_sha256=record.engine_sha256,
        protocol_id=record.protocol_id,
        protocol_version=record.protocol_version,
        display_name=record.display_name,
        engine_family=record.engine_family,
        required_asset_keys=record.required_asset_keys,
        timeline_node_types=record.timeline_node_types,
        module=record.module,
    )


def discover_protocol_modules(library_root: Path | str) -> tuple[list[AtlasRecord], list[str]]:
    root = Path(library_root).expanduser().resolve(strict=False)
    records: list[AtlasRecord] = []
    errors: list[str] = []
    for path in sorted((root / "protocols").glob("*.json")):
        # Underscore/dot-prefixed JSON files are scratch or editor artifacts,
        # never public Atlas modules.  Ignoring them also prevents concurrent
        # validation from briefly admitting a unit-test fixture as a protocol.
        if path.name.startswith(("_", ".", "protocol_atlas_module_schema_")):
            continue
        try:
            records.append(load_protocol_module(path, root))
        except Exception as exc:
            errors.append(f"{path.name}: {exc}")
    identities: dict[tuple[str, str], int] = {}
    for record in records:
        identity = (record.protocol_id.casefold(), record.protocol_version)
        identities[identity] = identities.get(identity, 0) + 1
    duplicates = {identity for identity, count in identities.items() if count > 1}
    for protocol_id, version in sorted(duplicates):
        errors.append(f"Duplicate active Atlas identity: {protocol_id} v{version}")
    records = [
        record for record in records
        if (record.protocol_id.casefold(), record.protocol_version) not in duplicates
    ]
    records.sort(key=lambda item: (item.display_name.casefold(), item.protocol_version))
    return records, errors


def _seed_value(protocol_id: str, participant_id: str, session_index: int, explicit_seed: int | None) -> int:
    if explicit_seed is not None:
        if isinstance(explicit_seed, bool) or not isinstance(explicit_seed, int):
            raise AtlasValidationError(["randomization seed must be an integer"])
        return explicit_seed
    digest = hashlib.sha256(f"{protocol_id}|{participant_id}|{session_index}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big", signed=False)


def resolve_parameters(module: Mapping[str, Any], overrides: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Resolve declared defaults and reject ad-hoc parameters outside the module."""
    declarations = module.get("parameters")
    declarations = declarations if isinstance(declarations, Mapping) else {}
    overrides = dict(overrides or {})
    unknown = sorted(set(overrides) - set(declarations))
    if unknown:
        raise AtlasValidationError(["undeclared protocol parameters: " + ", ".join(unknown)])
    resolved: dict[str, Any] = {}
    for key, declaration in declarations.items():
        if isinstance(declaration, Mapping) and "default" in declaration:
            resolved[str(key)] = deepcopy(declaration.get("default"))
        else:
            resolved[str(key)] = deepcopy(declaration)
    resolved.update(deepcopy(overrides))
    return resolved


def _condition_enabled(node: Mapping[str, Any], parameters: Mapping[str, Any]) -> bool:
    condition = node.get("enabled_when")
    if isinstance(condition, bool):
        return condition
    if isinstance(condition, Mapping):
        parameter = _text(condition.get("parameter"))
        if not parameter or parameter not in parameters:
            raise AtlasValidationError([f"timeline node {node.get('id')} references unknown enabled_when parameter {parameter!r}"])
        observed = parameters.get(parameter)
        if "equals" in condition:
            return observed == condition.get("equals")
        if isinstance(condition.get("in"), list):
            return observed in condition.get("in")
        raise AtlasValidationError([f"timeline node {node.get('id')} has unsupported enabled_when logic"])
    conditional_on = _text(node.get("conditional_on"))
    if conditional_on == "baseline_option_includes_eyes_open":
        return parameters.get("default_baseline_option", parameters.get("baseline_option", "both")) in {"eyes_open", "both"}
    if conditional_on == "baseline_option_includes_eyes_closed":
        return parameters.get("default_baseline_option", parameters.get("baseline_option", "both")) in {"eyes_closed", "both"}
    return True


_TEMPLATE_FIELD_RE = re.compile(r"\{([A-Za-z0-9_.-]+)\}")


def _render_trial_template(value: Any, context: Mapping[str, Any]) -> Any:
    """Resolve bounded field placeholders without evaluating manifest content."""
    if isinstance(value, str):
        def replace(match: re.Match[str]) -> str:
            key = match.group(1)
            if key not in context:
                raise AtlasValidationError([f"trial template references unknown field {key!r}"])
            return str(context[key])

        return _TEMPLATE_FIELD_RE.sub(replace, value)
    if isinstance(value, list):
        return [_render_trial_template(item, context) for item in value]
    if isinstance(value, Mapping):
        return {str(key): _render_trial_template(item, context) for key, item in value.items()}
    return deepcopy(value)


def _trial_order_is_valid(rows: Sequence[Mapping[str, Any]], constraints: Mapping[str, Any]) -> bool:
    leading = constraints.get("leading_excludes")
    if isinstance(leading, Mapping):
        field = _text(leading.get("field"))
        count = int(leading.get("trials", 0))
        excluded = set(map(str, leading.get("values", [])))
        if field and excluded and any(str(row.get(field)) in excluded for row in rows[:count]):
            return False
    maximum = constraints.get("maximum_consecutive")
    rules = maximum if isinstance(maximum, list) else [maximum]
    for rule in rules:
        if not isinstance(rule, Mapping):
            continue
        field = _text(rule.get("field"))
        limit = int(rule.get("count", 0))
        if not field or limit < 1:
            continue
        previous: Any = object()
        run = 0
        for row in rows:
            current = row.get(field)
            run = run + 1 if current == previous else 1
            previous = current
            if run > limit:
                return False
    return True


def _materialize_trial_generator(
    node: Mapping[str, Any],
    parameters: Mapping[str, Any],
    rng: random.Random,
) -> list[dict[str, Any]]:
    """Freeze a balanced declarative trial table into the compiled timeline."""
    generator = node.get("trial_generator")
    if not isinstance(generator, Mapping) or _text(generator.get("type")) != "balanced_rows":
        raise AtlasValidationError([f"timeline node {node.get('id')} has an unsupported trial generator"])
    rows_value = generator.get("rows")
    rows_parameter = _text(generator.get("rows_parameter"))
    if rows_parameter:
        rows_value = parameters.get(rows_parameter)
    if not isinstance(rows_value, list) or not rows_value or any(not isinstance(row, Mapping) for row in rows_value):
        raise AtlasValidationError([f"timeline node {node.get('id')} trial generator resolved no valid rows"])
    repetitions_value = generator.get("repetitions", 1)
    repetitions_parameter = _text(generator.get("repetitions_parameter"))
    if repetitions_parameter:
        repetitions_value = parameters.get(repetitions_parameter)
    if isinstance(repetitions_value, bool) or not isinstance(repetitions_value, int) or repetitions_value < 1:
        raise AtlasValidationError([f"timeline node {node.get('id')} trial repetitions must be a positive integer"])
    template = generator.get("trial_template")
    if not isinstance(template, Mapping):
        raise AtlasValidationError([f"timeline node {node.get('id')} trial generator has no trial_template"])

    generated: list[dict[str, Any]] = []
    serial = 0
    for repetition in range(1, repetitions_value + 1):
        for row_index, raw_row in enumerate(rows_value, start=1):
            serial += 1
            context = {
                **dict(raw_row),
                "row_index": row_index,
                "repetition_index": repetition,
                "serial_index": serial,
            }
            trial = {**dict(raw_row), **dict(_render_trial_template(template, context))}
            trial.setdefault("trial_id", f"{_text(node.get('id'))}_{serial:04d}")
            generated.append(trial)

    constraints = generator.get("sequence_constraints")
    constraints = constraints if isinstance(constraints, Mapping) else {}
    if generator.get("shuffle") is True:
        original = list(generated)
        for _ in range(200):
            remaining = list(original)
            candidate: list[dict[str, Any]] = []
            while remaining:
                eligible_indices = [
                    index
                    for index, item in enumerate(remaining)
                    if _trial_order_is_valid([*candidate, item], constraints)
                ]
                if not eligible_indices:
                    break
                selected_index = eligible_indices[rng.randrange(len(eligible_indices))]
                candidate.append(remaining.pop(selected_index))
            if len(candidate) == len(original):
                generated = candidate
                break
        else:
            raise AtlasValidationError([f"timeline node {node.get('id')} could not satisfy its trial-order constraints"])
    elif not _trial_order_is_valid(generated, constraints):
        raise AtlasValidationError([f"timeline node {node.get('id')} fixed trial order violates its constraints"])
    return generated


def compile_timeline(
    record_or_module: AtlasRecord | Mapping[str, Any],
    *,
    participant_id: str,
    session_index: int = 1,
    seed: int | None = None,
    parameters: Mapping[str, Any] | None = None,
    asset_bindings: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Freeze a deterministic, serializable display plan before acquisition."""
    module = record_or_module.module if isinstance(record_or_module, AtlasRecord) else record_or_module
    protocol_id = _text(module.get("protocol_id"))
    if not _text(participant_id):
        raise AtlasValidationError(["participant_id is required to compile a deterministic plan"])
    if isinstance(session_index, bool) or not isinstance(session_index, int) or session_index < 1:
        raise AtlasValidationError(["session_index must be a positive integer"])
    frozen_seed = _seed_value(protocol_id, _text(participant_id), session_index, seed)
    rng = random.Random(frozen_seed)
    resolved_parameters = resolve_parameters(module, parameters)
    randomization = dict(module.get("randomization") or {})
    mode = _text(randomization.get("mode"))
    timeline = deepcopy(list(module.get("timeline") or []))

    sequence_id = "FIXED"
    sequences = randomization.get("allowed_sequences")
    if mode in {"latin_square", "williams", "scheduled"} and isinstance(sequences, list) and sequences:
        selected_index = (session_index - 1 + frozen_seed) % len(sequences)
        selected = sequences[selected_index]
        sequence_id = _text(selected.get("id")) if isinstance(selected, Mapping) else f"SEQ_{selected_index + 1}"
        order = selected.get("order") if isinstance(selected, Mapping) else selected
        if isinstance(order, list) and order:
            by_id = {_text(node.get("id")): node for node in timeline if isinstance(node, Mapping)}
            if set(map(str, order)) == set(by_id):
                timeline = [by_id[str(node_id)] for node_id in order]
    elif mode == "seeded_shuffle":
        rng.shuffle(timeline)
        sequence_id = f"SEEDED_{frozen_seed}"

    external_schedule_selection: dict[str, Any] | None = None
    if protocol_id == EMD_PROTOCOL_ID:
        if asset_bindings:
            if not isinstance(record_or_module, AtlasRecord):
                raise AtlasValidationError([
                    "EEG Moments asset-bound compilation requires a loaded AtlasRecord"
                ])
            normalized_assets = normalize_asset_bindings(record_or_module, asset_bindings)
            root_value = normalized_assets.get("emd_protocol_assets_folder")
            if not root_value:
                raise AtlasValidationError(["EEG Moments asset directory is required for a lockable plan"])
            external_schedule_selection = compile_emd_schedule_selection(
                record_or_module,
                Path(root_value),
                expected_session_index=session_index,
            )
            frozen_seed = external_schedule_selection["schedule_seed"]
            resolved_parameters = deepcopy(resolved_parameters)
            resolved_parameters["run_index"] = external_schedule_selection["run_index"]
            sequence_id = (
                f"EMD_{external_schedule_selection['selection_id']}"
                f"_S{external_schedule_selection['session_index']:02d}"
                f"_R{external_schedule_selection['run_index']:02d}"
            )
        else:
            frozen_seed = None
            external_schedule_selection = {
                "schema": "PRAYCG_EMDCompiledScheduleSelection_v1_0",
                "status": "ASSET_TREE_REQUIRED_FOR_SESSION_LOCK",
                "session_index": session_index,
                "run_index": None,
                "schedule_seed": None,
                "scope_boundary": (
                    "Design-time preview only. A runtime session cannot lock until a reviewed EEG Moments "
                    "asset directory and emd_run_selection.json are validated."
                ),
            }

    expanded: list[dict[str, Any]] = []
    for node in timeline:
        if not _condition_enabled(node, resolved_parameters):
            continue
        node = deepcopy(dict(node))
        parameter_bindings = {
            "duration_parameter": "duration_s",
            "repeat_parameter": "repeat",
            "frequency_parameter": "frequency_hz",
            "advance_keys_parameter": "continue_keys",
        }
        for declaration_field, runtime_field in parameter_bindings.items():
            parameter_name = _text(node.get(declaration_field))
            if parameter_name:
                if parameter_name not in resolved_parameters:
                    raise AtlasValidationError([f"timeline node {node.get('id')} references unknown parameter {parameter_name!r}"])
                node[runtime_field] = deepcopy(resolved_parameters[parameter_name])
        enabled_sessions = node.get("session_indices", node.get("sessions"))
        if isinstance(enabled_sessions, list) and enabled_sessions and session_index not in enabled_sessions:
            continue
        session_min = node.get("session_min")
        session_max = node.get("session_max")
        if isinstance(session_min, int) and not isinstance(session_min, bool) and session_index < session_min:
            continue
        if isinstance(session_max, int) and not isinstance(session_max, bool) and session_index > session_max:
            continue
        repeat_count = int(node.get("repeat", node.get("repeat_count", 1)))
        for repeat_index in range(1, repeat_count + 1):
            row = deepcopy(dict(node))
            row["repeat_index"] = repeat_index
            row["repeat_total"] = repeat_count
            row["compiled_instance_id"] = f"{row['id']}__{repeat_index:03d}"
            trials = row.get("trials")
            if isinstance(row.get("trial_generator"), Mapping):
                row["trials"] = _materialize_trial_generator(row, resolved_parameters, rng)
                row.pop("trial_generator", None)
                trials = row.get("trials")
            if isinstance(trials, list) and row.get("shuffle_trials") is True:
                rng.shuffle(trials)
            expanded.append(row)
    compiled_core = {
        "schema": "PRAYCG_ProtocolAtlasCompiledTimeline_v2_0",
        "protocol_id": protocol_id,
        "protocol_version": _text(module.get("protocol_version")),
        "participant_id": _text(participant_id),
        "session_index": session_index,
        "randomization_mode": mode,
        "randomization_seed": frozen_seed,
        "sequence_id": sequence_id,
        "parameters": resolved_parameters,
        "timeline": expanded,
    }
    if external_schedule_selection is not None:
        compiled_core["external_schedule_selection"] = external_schedule_selection
    compiled_core["canonical_sha256"] = canonical_sha256(compiled_core)
    return compiled_core


def normalize_asset_bindings(record: AtlasRecord, bindings: Mapping[str, Any] | None) -> dict[str, str]:
    """Resolve and validate operator-selected assets without mutating hardware state."""
    bindings = dict(bindings or {})
    declared = {str(item["key"]): item for item in record.module.get("assets", [])}
    unknown = sorted(set(bindings) - set(declared))
    errors: list[str] = []
    if unknown:
        errors.append("undeclared asset bindings: " + ", ".join(unknown))
    normalized: dict[str, str] = {}
    for key, contract in declared.items():
        if contract.get("source") != "operator_selection":
            continue
        raw = _text(bindings.get(key))
        if not raw:
            if contract.get("required"):
                errors.append(f"required asset is missing: {key}")
            continue
        path = Path(raw).expanduser().resolve(strict=False)
        if not path.is_file() and not path.is_dir():
            errors.append(f"asset does not exist: {key} -> {path}")
            continue
        if contract.get("kind") == "directory" and not path.is_dir():
            errors.append(f"asset {key} must be a directory tree")
            continue
        extensions = {str(item).casefold() for item in contract.get("allowed_extensions", [])}
        if path.is_file() and extensions and path.suffix.casefold() not in extensions:
            errors.append(f"asset {key} has disallowed extension {path.suffix}")
            continue
        normalized[key] = str(path)
    path_owners: dict[str, str] = {}
    for key, value in normalized.items():
        identity = os.path.normcase(str(Path(value).resolve(strict=False)))
        previous_key = path_owners.get(identity)
        if previous_key is not None:
            errors.append(
                f"one selected path cannot satisfy multiple asset roles: {previous_key} and {key}"
            )
        else:
            path_owners[identity] = key
    if errors:
        raise AtlasValidationError(errors)
    review_errors = validate_reviewed_asset_manifest(record, normalized)
    if review_errors:
        raise AtlasValidationError(review_errors)
    if record.protocol_id == EMD_PROTOCOL_ID and normalized.get("emd_protocol_assets_folder"):
        # This validates the complete reviewed schedule/media tree before the
        # Control Center is allowed to snapshot it. Session-index consistency
        # is applied later when the participant-specific plan is compiled.
        compile_emd_schedule_selection(
            record,
            Path(normalized["emd_protocol_assets_folder"]),
            expected_session_index=None,
        )
    return normalized


def validate_reviewed_asset_manifest(record: AtlasRecord, normalized_bindings: Mapping[str, str]) -> list[str]:
    """Machine-enforce operator review, rights notes, paths, and asset hashes."""
    review_key = "reviewed_import_manifest"
    requires_review_manifest = any(
        isinstance(item, Mapping) and item.get("key") == review_key and item.get("required") is True
        for item in record.module.get("assets", [])
    )
    if not requires_review_manifest:
        return []
    errors: list[str] = []
    value = _text(normalized_bindings.get(review_key))
    if not value:
        return ["required reviewed import manifest is missing"]
    path = Path(value).expanduser().resolve(strict=False)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return [f"reviewed import manifest cannot be read: {exc}"]
    if not isinstance(payload, Mapping) or payload.get("schema") != "PRAYCG_ReviewedAssetImportManifest_v1_0":
        return ["reviewed import manifest schema is not recognized"]
    if _text(payload.get("review_status")).upper() not in {"APPROVED", "REVIEWED_APPROVED"}:
        errors.append("reviewed import manifest review_status must be APPROVED")
    for field in ("reviewed_by", "reviewed_utc", "operator_attestation"):
        if not _text(payload.get(field)):
            errors.append(f"reviewed import manifest {field} must be nonblank")
    rows = payload.get("assets")
    if not isinstance(rows, list):
        return errors + ["reviewed import manifest assets must be a list"]
    indexed = {
        _text(row.get("key")): row
        for row in rows
        if isinstance(row, Mapping) and _text(row.get("key"))
    }
    expected_keys = {
        _text(item.get("key"))
        for item in record.module.get("assets", [])
        if isinstance(item, Mapping)
        and item.get("source") == "operator_selection"
        and item.get("required") is True
        and _text(item.get("key")) != review_key
    }
    if set(indexed) != expected_keys:
        errors.append(
            "reviewed import manifest asset keys must exactly equal required operator media keys "
            f"(expected {sorted(expected_keys)}, observed {sorted(indexed)})"
        )
    for key in sorted(expected_keys & set(indexed)):
        row = indexed[key]
        selected_value = _text(normalized_bindings.get(key))
        row_value = _text(row.get("path"))
        if not selected_value or not row_value:
            errors.append(f"reviewed import manifest asset {key} has no selected/recorded path")
            continue
        row_path = Path(row_value).expanduser()
        if not row_path.is_absolute():
            row_path = path.parent / row_path
        row_path = row_path.resolve(strict=False)
        selected_path = Path(selected_value).expanduser().resolve(strict=False)
        if row_path != selected_path:
            errors.append(f"reviewed import manifest path does not match selected asset {key}")
        expected_hash = _text(row.get("sha256")).casefold()
        try:
            observed_hash = sha256_path(selected_path)
        except Exception as exc:
            errors.append(f"reviewed import manifest asset {key} cannot be hashed: {exc}")
            continue
        if len(expected_hash) != 64 or expected_hash != observed_hash:
            errors.append(f"reviewed import manifest SHA-256 does not match asset {key}")
        for field in ("source_citation", "license_or_permission_basis", "content_review_notes"):
            if not _text(row.get(field)):
                errors.append(f"reviewed import manifest asset {key} {field} must be nonblank")
        technical = row.get("technical_review")
        if not isinstance(technical, Mapping) or technical.get("decodes_without_error") is not True:
            errors.append(f"reviewed import manifest asset {key} must record decodes_without_error=true")
        if record.protocol_id.startswith("ATLAS_ZACKS") and (
            not isinstance(technical, Mapping) or technical.get("forced_mute_verified") is not True
        ):
            errors.append(f"reviewed import manifest asset {key} must record forced_mute_verified=true")
        if record.protocol_id.startswith("ATLAS_NATVIEW") and (
            not isinstance(technical, Mapping) or technical.get("starts_at_media_time_zero") is not True
        ):
            errors.append(f"reviewed import manifest asset {key} must record starts_at_media_time_zero=true")
        if record.protocol_id.startswith("ATLAS_NARR") and key == "story_audio":
            inputs = record.module.get("stimulus_contract", {}).get("media_inputs", [])
            required_role = next(
                (
                    _text(item.get("required_variant_role"))
                    for item in inputs
                    if isinstance(item, Mapping) and _text(item.get("key")) == key
                ),
                "",
            )
            if not required_role or _text(row.get("variant_role")) != required_role:
                errors.append(f"reviewed NARR asset {key} variant_role must be {required_role!r}")
            derivative = row.get("derivative_provenance")
            if required_role in {"coarse_scramble", "fine_scramble"}:
                if not isinstance(derivative, Mapping):
                    errors.append(f"reviewed NARR {required_role} asset requires derivative_provenance")
                else:
                    parent_hash = _text(derivative.get("intact_parent_sha256")).casefold()
                    method = _text(derivative.get("method"))
                    derivative_hash = _text(derivative.get("derivative_sha256")).casefold()
                    if len(parent_hash) != 64 or not re.fullmatch(r"[0-9a-f]{64}", parent_hash):
                        errors.append(f"reviewed NARR {required_role} asset requires a valid intact_parent_sha256")
                    if not method:
                        errors.append(f"reviewed NARR {required_role} asset requires a nonblank derivative method")
                    if not isinstance(derivative.get("parameters"), Mapping):
                        errors.append(f"reviewed NARR {required_role} asset derivative parameters must be an object")
                    if derivative_hash != observed_hash:
                        errors.append(f"reviewed NARR {required_role} derivative_sha256 must match the selected WAV")
                    stochastic = any(token in method.casefold() for token in ("random", "shuffle", "stochastic", "permut"))
                    if stochastic and derivative.get("random_seed") is None:
                        errors.append(f"reviewed NARR {required_role} stochastic derivative requires random_seed")
    return errors


def _emd_json_object(path: Path, label: str, errors: list[str]) -> dict[str, Any]:
    if not path.is_file():
        errors.append(f"EEG Moments {label} is missing: {path.name}")
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        errors.append(f"EEG Moments {label} is not readable JSON: {exc}")
        return {}
    if not isinstance(payload, dict):
        errors.append(f"EEG Moments {label} must contain one JSON object")
        return {}
    return payload


def _emd_positive_index(value: Any, label: str, errors: list[str]) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        errors.append(f"EEG Moments {label} must be a positive integer")
        return None
    return value


def _emd_valid_hash(value: Any) -> bool:
    return bool(re.fullmatch(r"[0-9a-f]{64}", _text(value).casefold()))


def _emd_probe_contract(value: Any, label: str, errors: list[str]) -> dict[str, Any] | None:
    if value in (None, False):
        return None
    if not isinstance(value, Mapping):
        errors.append(f"EEG Moments {label} attention_probe must be false, null, or an object")
        return None
    probe = deepcopy(dict(value))
    for field in ("probe_id", "prompt", "left_label", "right_label", "correct_key"):
        if not _text(probe.get(field)):
            errors.append(f"EEG Moments {label} attention_probe.{field} must be nonblank")
    if _text(probe.get("correct_key")).casefold() not in {"left", "right"}:
        errors.append(f"EEG Moments {label} attention_probe.correct_key must be left or right")
    return probe


def compile_emd_schedule_selection(
    record: AtlasRecord,
    asset_root: Path | str,
    *,
    expected_session_index: int | None,
) -> dict[str, Any]:
    """Validate and freeze one reviewed EEG Moments schedule/run selection.

    The selected directory is the atomic external stimulus input. Its digest
    covers the complete schedule, selection file, manifest, every referenced
    audiovisual clip, and any retained review notes. The compiled plan stores
    the exact selected session/run and trial identities; runtime never reads a
    mutable environment variable to choose a different run.
    """
    if record.protocol_id != EMD_PROTOCOL_ID:
        raise AtlasValidationError(["EEG Moments schedule compilation was requested for another protocol"])
    errors: list[str] = []
    root = Path(asset_root).expanduser().resolve(strict=False)
    if not root.is_dir():
        raise AtlasValidationError([f"EEG Moments asset binding must be a directory tree: {root}"])
    symlinks = sorted(
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_symlink()
    )
    if symlinks:
        errors.append(
            "EEG Moments asset directory cannot contain symbolic links: " + ", ".join(symlinks)
        )

    stimulus = record.module.get("stimulus_contract")
    stimulus = stimulus if isinstance(stimulus, Mapping) else {}
    manifest_name = _text(stimulus.get("manifest_filename")) or "emd_media_manifest.json"
    selection_name = _text(stimulus.get("run_selection_filename")) or "emd_run_selection.json"
    schedule_pattern = _text(stimulus.get("schedule_filename_pattern")) or "emd_schedule*.json"
    manifest_path = root / manifest_name
    selection_path = root / selection_name
    manifest_occurrences = sorted(
        (path for path in root.rglob(manifest_name) if path.is_file()),
        key=lambda path: path.relative_to(root).as_posix().casefold(),
    )
    selection_occurrences = sorted(
        (path for path in root.rglob(selection_name) if path.is_file()),
        key=lambda path: path.relative_to(root).as_posix().casefold(),
    )
    schedule_occurrences = sorted(
        (path for path in root.rglob(schedule_pattern) if path.is_file()),
        key=lambda path: path.relative_to(root).as_posix().casefold(),
    )
    if manifest_occurrences != ([manifest_path] if manifest_path.is_file() else []):
        errors.append(
            "EEG Moments asset directory must contain exactly one root-level "
            f"{manifest_name} and no nested shadow copies"
        )
    if selection_occurrences != ([selection_path] if selection_path.is_file() else []):
        errors.append(
            "EEG Moments asset directory must contain exactly one root-level "
            f"{selection_name} and no nested shadow copies"
        )
    schedule_paths = [
        path for path in schedule_occurrences
        if path.parent == root
    ]
    if len(schedule_occurrences) != 1 or len(schedule_paths) != 1:
        errors.append(
            "EEG Moments asset directory must contain exactly one root-level "
            f"{schedule_pattern} file and no nested shadow copies; observed {len(schedule_occurrences)}"
        )
    schedule_path = schedule_paths[0] if len(schedule_paths) == 1 else root / "__missing_schedule__.json"

    media_manifest = _emd_json_object(manifest_path, "media manifest", errors)
    schedule = _emd_json_object(schedule_path, "frozen schedule", errors) if len(schedule_paths) == 1 else {}
    selection = _emd_json_object(selection_path, "run selection", errors)

    if media_manifest and media_manifest.get("schema") != EMD_MEDIA_MANIFEST_SCHEMA:
        errors.append(f"EEG Moments media manifest schema must be {EMD_MEDIA_MANIFEST_SCHEMA}")
    if schedule and schedule.get("schema") != EMD_SCHEDULE_SCHEMA:
        errors.append(f"EEG Moments schedule schema must be {EMD_SCHEDULE_SCHEMA}")
    if selection and selection.get("schema") != EMD_SELECTION_SCHEMA:
        errors.append(f"EEG Moments run selection schema must be {EMD_SELECTION_SCHEMA}")

    manifest_id = _text(media_manifest.get("manifest_id"))
    schedule_id = _text(schedule.get("schedule_id"))
    selection_id = _text(selection.get("selection_id"))
    for value, label in (
        (manifest_id, "media manifest_id"),
        (schedule_id, "schedule_id"),
        (selection_id, "run selection selection_id"),
    ):
        if not value or value.upper().startswith("REPLACE_") or not _ID_RE.fullmatch(value):
            errors.append(
                f"EEG Moments {label} must be a stable identifier containing only letters, numbers, dots, dashes, or underscores"
            )
    if schedule.get("frozen_before_launch") is not True:
        errors.append("EEG Moments schedule must declare frozen_before_launch=true")
    if selection.get("frozen_before_launch") is not True:
        errors.append("EEG Moments run selection must declare frozen_before_launch=true")
    if _text(selection.get("review_status")).upper() not in {"APPROVED", "REVIEWED_APPROVED"}:
        errors.append("EEG Moments run selection review_status must be APPROVED")
    for field in ("reviewed_by", "reviewed_utc", "selection_note"):
        if not _text(selection.get(field)):
            errors.append(f"EEG Moments run selection {field} must be nonblank")
    if not isinstance(schedule.get("seed"), int) or isinstance(schedule.get("seed"), bool):
        errors.append("EEG Moments frozen schedule seed must be a recorded integer")
    generation_method = _text(schedule.get("generation_method"))
    if not generation_method or generation_method.upper().startswith("REPLACE_"):
        errors.append("EEG Moments schedule generation_method is blank or still a template placeholder")

    manifest_hash = sha256_file(manifest_path) if manifest_path.is_file() else ""
    schedule_hash = sha256_file(schedule_path) if schedule_path.is_file() else ""
    selection_hash = sha256_file(selection_path) if selection_path.is_file() else ""
    if _text(selection.get("schedule_filename")) != schedule_path.name:
        errors.append("EEG Moments run selection schedule_filename does not name the sole frozen schedule")
    if _text(selection.get("schedule_id")) != schedule_id:
        errors.append("EEG Moments run selection schedule_id does not match the frozen schedule")
    if not _emd_valid_hash(selection.get("schedule_sha256")) or _text(selection.get("schedule_sha256")).casefold() != schedule_hash:
        errors.append("EEG Moments run selection schedule_sha256 does not match the frozen schedule")
    if _text(selection.get("media_manifest_filename")) != manifest_path.name:
        errors.append("EEG Moments run selection media_manifest_filename must name emd_media_manifest.json")
    if _text(selection.get("media_manifest_id")) != manifest_id:
        errors.append("EEG Moments run selection media_manifest_id does not match the media manifest")
    if not _emd_valid_hash(selection.get("media_manifest_sha256")) or _text(selection.get("media_manifest_sha256")).casefold() != manifest_hash:
        errors.append("EEG Moments run selection media_manifest_sha256 does not match the media manifest")
    if _text(schedule.get("media_manifest_id")) != manifest_id:
        errors.append("EEG Moments schedule media_manifest_id does not match the media manifest")

    selected_session_index = _emd_positive_index(
        selection.get("session_index"), "run selection session_index", errors
    )
    selected_run_index = _emd_positive_index(
        selection.get("run_index"), "run selection run_index", errors
    )
    if expected_session_index is not None:
        expected = _emd_positive_index(expected_session_index, "Control Center session_index", errors)
        if expected is not None and selected_session_index is not None and expected != selected_session_index:
            errors.append(
                "EEG Moments emd_run_selection.json session_index "
                f"({selected_session_index}) does not match the Control Center session_index ({expected})"
            )

    media_root_raw = _text(media_manifest.get("media_root")) or "."
    media_root_relative = Path(media_root_raw)
    media_root = (root / media_root_relative).resolve(strict=False)
    if media_root_relative.is_absolute() or not _within(media_root, root) or not media_root.is_dir():
        errors.append("EEG Moments media_root must be an existing relative directory inside the locked asset tree")
    if not _text(media_manifest.get("license_and_access_note")):
        errors.append("EEG Moments media manifest license_and_access_note must be nonblank")

    allowed_extensions = {
        _text(value).casefold()
        for value in stimulus.get("allowed_media_extensions", [])
        if _text(value)
    }
    required_duration = float(stimulus.get("expected_clip_duration_seconds", 3.0))
    tolerance = float(stimulus.get("duration_tolerance_seconds", 0.1))
    clips: dict[str, dict[str, Any]] = {}
    declared_media_paths: set[str] = set()
    clip_rows = media_manifest.get("clips")
    if not isinstance(clip_rows, list) or not clip_rows:
        errors.append("EEG Moments media manifest clips must be a nonempty list")
        clip_rows = []
    for ordinal, clip in enumerate(clip_rows, start=1):
        label = f"media manifest clip {ordinal}"
        if not isinstance(clip, Mapping):
            errors.append(f"EEG Moments {label} must be an object")
            continue
        clip_id = _text(clip.get("clip_id"))
        if not clip_id or clip_id in clips:
            errors.append(f"EEG Moments {label} has a blank or duplicate clip_id")
            continue
        relative_raw = _text(clip.get("relative_path"))
        relative_path = Path(relative_raw)
        clip_path = (media_root / relative_path).resolve(strict=False)
        if (
            not relative_raw
            or relative_path.is_absolute()
            or not _within(clip_path, root)
            or not clip_path.is_file()
            or clip_path.is_symlink()
        ):
            errors.append(f"EEG Moments clip {clip_id} must reference an existing regular file inside the locked tree")
            continue
        if allowed_extensions and clip_path.suffix.casefold() not in allowed_extensions:
            errors.append(f"EEG Moments clip {clip_id} has disallowed media extension {clip_path.suffix}")
        observed_hash = sha256_file(clip_path)
        expected_hash = _text(clip.get("sha256")).casefold()
        if not _emd_valid_hash(expected_hash) or expected_hash != observed_hash:
            errors.append(f"EEG Moments media manifest SHA-256 does not match clip {clip_id}")
        duration = clip.get("expected_duration_seconds")
        if isinstance(duration, bool) or not isinstance(duration, (int, float)) or abs(float(duration) - required_duration) > tolerance:
            errors.append(
                f"EEG Moments clip {clip_id} must declare {required_duration:.3f}s duration within ±{tolerance:.3f}s"
            )
        if stimulus.get("audio_track_expected") is True and clip.get("audio_expected") is not True:
            errors.append(f"EEG Moments clip {clip_id} must declare audio_expected=true")
        if not _text(clip.get("source_reference")):
            errors.append(f"EEG Moments clip {clip_id} source_reference must be nonblank")
        probe = _emd_probe_contract(clip.get("attention_probe"), f"clip {clip_id}", errors)
        relative_from_root = clip_path.relative_to(root).as_posix()
        if relative_from_root in declared_media_paths:
            errors.append(
                f"EEG Moments clip {clip_id} reuses media path {relative_from_root}; each clip_id must bind one unique file"
            )
        declared_media_paths.add(relative_from_root)
        clips[clip_id] = {
            "clip_id": clip_id,
            "relative_path": relative_from_root,
            "sha256": observed_hash,
            "expected_duration_seconds": float(duration) if isinstance(duration, (int, float)) and not isinstance(duration, bool) else None,
            "audio_expected": clip.get("audio_expected") is True,
            "attention_probe": probe,
        }

    if media_root.is_dir():
        observed_media_paths = {
            path.relative_to(root).as_posix()
            for path in media_root.rglob("*")
            if path.is_file() and path.suffix.casefold() in allowed_extensions
        }
        undeclared = sorted(observed_media_paths - declared_media_paths)
        if undeclared:
            errors.append(
                "EEG Moments asset tree contains audiovisual files absent from emd_media_manifest.json: "
                + ", ".join(undeclared)
            )

    sessions = schedule.get("sessions")
    if not isinstance(sessions, list) or not sessions:
        errors.append("EEG Moments frozen schedule sessions must be a nonempty list")
        sessions = []
    seen_sessions: set[int] = set()
    seen_trial_ids: set[str] = set()
    referenced_clips: set[str] = set()
    selected_trials: list[dict[str, Any]] = []
    selected_run_found = False
    total_run_count = 0
    total_trial_count = 0
    for session_ordinal, session in enumerate(sessions, start=1):
        if not isinstance(session, Mapping):
            errors.append(f"EEG Moments schedule session {session_ordinal} must be an object")
            continue
        schedule_session_index = _emd_positive_index(
            session.get("session_index"), f"schedule session {session_ordinal} session_index", errors
        )
        if schedule_session_index is None:
            continue
        if schedule_session_index in seen_sessions:
            errors.append(f"EEG Moments schedule duplicates session_index {schedule_session_index}")
        seen_sessions.add(schedule_session_index)
        runs = session.get("runs")
        if not isinstance(runs, list) or not runs:
            errors.append(f"EEG Moments schedule session {schedule_session_index} runs must be a nonempty list")
            continue
        seen_runs: set[int] = set()
        for run_ordinal, run in enumerate(runs, start=1):
            if not isinstance(run, Mapping):
                errors.append(f"EEG Moments schedule session {schedule_session_index} run {run_ordinal} must be an object")
                continue
            schedule_run_index = _emd_positive_index(
                run.get("run_index"),
                f"schedule session {schedule_session_index} run {run_ordinal} run_index",
                errors,
            )
            if schedule_run_index is None:
                continue
            total_run_count += 1
            if schedule_run_index in seen_runs:
                errors.append(
                    f"EEG Moments schedule session {schedule_session_index} duplicates run_index {schedule_run_index}"
                )
            seen_runs.add(schedule_run_index)
            is_selected = (
                schedule_session_index == selected_session_index
                and schedule_run_index == selected_run_index
            )
            if is_selected:
                selected_run_found = True
            trials = run.get("trials")
            if not isinstance(trials, list) or not trials:
                errors.append(
                    f"EEG Moments schedule session {schedule_session_index} run {schedule_run_index} trials must be nonempty"
                )
                continue
            previous_clip_id = ""
            for trial_ordinal, trial in enumerate(trials, start=1):
                total_trial_count += 1
                label = f"schedule S{schedule_session_index} R{schedule_run_index} trial {trial_ordinal}"
                if not isinstance(trial, Mapping):
                    errors.append(f"EEG Moments {label} must be an object")
                    continue
                forbidden: list[str] = []
                _walk_forbidden(trial, label, forbidden)
                errors.extend(f"EEG Moments external schedule: {message}" for message in forbidden)
                trial_id = _text(trial.get("trial_id"))
                clip_id = _text(trial.get("clip_id"))
                if not trial_id or trial_id in seen_trial_ids:
                    errors.append(f"EEG Moments {label} has a blank or duplicate trial_id")
                else:
                    seen_trial_ids.add(trial_id)
                if clip_id not in clips:
                    errors.append(f"EEG Moments {label} references undeclared clip {clip_id!r}")
                    continue
                referenced_clips.add(clip_id)
                if previous_clip_id == clip_id and trial.get("allow_immediate_repeat") is not True:
                    errors.append(
                        f"EEG Moments {label} immediately repeats {clip_id} without allow_immediate_repeat=true"
                    )
                previous_clip_id = clip_id
                repetition = _emd_positive_index(
                    trial.get("scheduled_repetition"), f"{label} scheduled_repetition", errors
                )
                raw_probe = trial.get("attention_probe", False)
                if raw_probe is True:
                    probe = deepcopy(clips[clip_id].get("attention_probe"))
                    if not isinstance(probe, Mapping):
                        errors.append(
                            f"EEG Moments {label} requests an attention probe but clip {clip_id} has no valid probe"
                        )
                        probe = None
                else:
                    probe = _emd_probe_contract(raw_probe, label, errors)
                if is_selected:
                    selected_trials.append({
                        "trial_id": trial_id,
                        "clip_id": clip_id,
                        "clip_relative_path": clips[clip_id]["relative_path"],
                        "clip_sha256": clips[clip_id]["sha256"],
                        "expected_duration_seconds": clips[clip_id]["expected_duration_seconds"],
                        "audio_expected": clips[clip_id]["audio_expected"],
                        "scheduled_repetition": repetition,
                        "attention_probe": deepcopy(probe),
                        "condition_label": _text(trial.get("condition_label")) or None,
                        "analysis_label": _text(trial.get("analysis_label")) or None,
                        "schedule_session_index": schedule_session_index,
                        "schedule_run_index": schedule_run_index,
                    })

    unreferenced = sorted(set(clips) - referenced_clips)
    if unreferenced:
        errors.append(
            "EEG Moments media manifest clips are absent from the complete frozen schedule: "
            + ", ".join(unreferenced)
        )
    if selected_session_index is not None and selected_run_index is not None and not selected_run_found:
        errors.append(
            f"EEG Moments frozen schedule has no selected session {selected_session_index}, run {selected_run_index}"
        )
    if selected_run_found and not selected_trials:
        errors.append("EEG Moments selected schedule run has no valid compiled trials")
    for path, expected_hash, label in (
        (manifest_path, manifest_hash, "media manifest"),
        (schedule_path, schedule_hash, "frozen schedule"),
        (selection_path, selection_hash, "run selection"),
    ):
        if expected_hash and (not path.is_file() or sha256_file(path) != expected_hash):
            errors.append(f"EEG Moments {label} changed while the immutable plan was being compiled")
    for clip in clips.values():
        clip_path = root / _text(clip.get("relative_path"))
        expected_hash = _text(clip.get("sha256"))
        if not clip_path.is_file() or sha256_file(clip_path) != expected_hash:
            errors.append(
                f"EEG Moments clip {clip.get('clip_id')} changed while the immutable plan was being compiled"
            )
    if errors:
        raise AtlasValidationError(errors)

    tree_hash = sha256_path(root)
    compiled = {
        "schema": "PRAYCG_EMDCompiledScheduleSelection_v1_0",
        "status": "LOCKED_REVIEWED_SCHEDULE_RUN",
        "selection_id": selection_id,
        "selection_filename": selection_path.name,
        "selection_sha256": selection_hash,
        "schedule_id": schedule_id,
        "schedule_filename": schedule_path.name,
        "complete_schedule_sha256": schedule_hash,
        "schedule_seed": schedule.get("seed"),
        "schedule_generation_method": generation_method,
        "media_manifest_id": manifest_id,
        "media_manifest_filename": manifest_path.name,
        "media_manifest_sha256": manifest_hash,
        "asset_tree_sha256": tree_hash,
        "session_index": selected_session_index,
        "run_index": selected_run_index,
        "complete_schedule_session_count": len(seen_sessions),
        "complete_schedule_run_count": total_run_count,
        "complete_schedule_trial_count": total_trial_count,
        "complete_schedule_referenced_clip_count": len(referenced_clips),
        "selected_run_trial_count": len(selected_trials),
        "selected_trials": selected_trials,
        "selection_boundary": (
            "The schedule and media tree are byte-identity locked. Hash equality does not establish "
            "source-study equivalence, stimulus validity, licensing, or successful playback."
        ),
    }
    compiled["canonical_sha256"] = canonical_sha256(compiled)
    return compiled


def protocol_readiness(
    record: AtlasRecord,
    *,
    asset_bindings: Mapping[str, Any] | None,
    participant_id: str,
    session_index: int,
) -> dict[str, Any]:
    reasons: list[str] = []
    try:
        assets = normalize_asset_bindings(record, asset_bindings)
    except AtlasValidationError as exc:
        reasons.extend(exc.errors)
        assets = {}
    try:
        compiled = compile_timeline(
            record,
            participant_id=participant_id,
            session_index=session_index,
            asset_bindings=assets,
        )
    except AtlasValidationError as exc:
        reasons.extend(exc.errors)
        compiled = None
    status = "PASS" if not reasons else "INELIGIBLE"
    return {
        "schema": "PRAYCG_ProtocolAtlasReadiness_v2_0",
        "status": status,
        "reasons": reasons,
        "protocol_id": record.protocol_id,
        "protocol_version": record.protocol_version,
        "hardware_stack_effect": "NONE",
        "resolved_assets": assets,
        "compiled_timeline": compiled,
    }


def build_asset_snapshot(record: AtlasRecord, bindings: Mapping[str, Any] | None) -> dict[str, dict[str, Any]]:
    normalized = normalize_asset_bindings(record, bindings)
    snapshot: dict[str, dict[str, Any]] = {}
    for key, value in sorted(normalized.items()):
        path = Path(value).resolve(strict=True)
        snapshot[key] = {
            "path": str(path),
            "path_kind": "directory" if path.is_dir() else "file",
            "sha256": sha256_path(path),
            "size_bytes": path.stat().st_size if path.is_file() else None,
        }
    return snapshot


def write_protocol_lock(
    record: AtlasRecord,
    compiled_timeline: Mapping[str, Any],
    asset_bindings: Mapping[str, Any] | None,
    output_path: Path | str,
) -> dict[str, Any]:
    """Write an immutable Atlas selection snapshot for platform integration."""
    output_path = Path(output_path).expanduser().resolve(strict=False)
    asset_snapshot = build_asset_snapshot(record, asset_bindings)
    compiled_identity = compiled_timeline_identity_sha256(compiled_timeline)
    core = {
        "schema": ATLAS_LOCK_SCHEMA,
        "protocol_id": record.protocol_id,
        "protocol_version": record.protocol_version,
        "manifest_path": str(record.manifest_path),
        "protocol_module_file_sha256": record.manifest_sha256,
        "protocol_module_canonical_sha256": canonical_sha256(record.module),
        "runner_path": str(record.runner_path),
        "runner_file_sha256": record.runner_sha256,
        "engine_path": str(record.engine_path),
        "engine_file_sha256": record.engine_sha256,
        "compiled_timeline": deepcopy(dict(compiled_timeline)),
        "compiled_timeline_sha256": compiled_identity,
        "assigned_sequence": [
            str(node.get("compiled_instance_id") or "")
            for node in compiled_timeline.get("timeline", [])
            if isinstance(node, Mapping)
        ],
        "asset_snapshot": asset_snapshot,
        "hardware_stack_effect": "NONE",
        "hardware_profile_id": None,
    }
    lock = deepcopy(core)
    lock["lock_identity_sha256"] = canonical_sha256(core)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_path.with_name(f"{output_path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(lock, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(output_path)
    return lock


def validate_protocol_lock(lock_path: Path | str, library_root: Path | str) -> dict[str, Any]:
    lock_path = Path(lock_path).expanduser().resolve(strict=False)
    if not lock_path.is_file():
        raise AtlasValidationError([f"Atlas protocol lock is missing: {lock_path}"])
    try:
        lock = json.loads(lock_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise AtlasValidationError([f"Atlas protocol lock cannot be read: {exc}"]) from exc
    errors: list[str] = []
    if not isinstance(lock, Mapping) or lock.get("schema") != ATLAS_LOCK_SCHEMA:
        raise AtlasValidationError(["Atlas protocol lock schema is not recognized"])
    core = {key: value for key, value in lock.items() if key != "lock_identity_sha256"}
    if lock.get("lock_identity_sha256") != canonical_sha256(core):
        errors.append("Atlas protocol lock identity has changed")
    try:
        record = load_protocol_module(Path(_text(lock.get("manifest_path"))), library_root)
    except AtlasValidationError as exc:
        errors.extend(exc.errors)
        record = None
    if record is not None:
        checks = {
            "protocol_id": lock.get("protocol_id") == record.protocol_id,
            "protocol_version": lock.get("protocol_version") == record.protocol_version,
            "protocol_module_file_sha256": lock.get("protocol_module_file_sha256") == record.manifest_sha256,
            "protocol_module_canonical_sha256": lock.get("protocol_module_canonical_sha256") == canonical_sha256(record.module),
            "runner_file_sha256": lock.get("runner_file_sha256") == record.runner_sha256,
            "engine_file_sha256": lock.get("engine_file_sha256") == record.engine_sha256,
        }
        errors.extend(f"locked {name} no longer matches the Atlas" for name, passed in checks.items() if not passed)
    compiled = lock.get("compiled_timeline")
    if not isinstance(compiled, Mapping):
        errors.append("compiled timeline is missing or changed")
    else:
        try:
            compiled_identity = compiled_timeline_identity_sha256(compiled)
        except AtlasValidationError as exc:
            errors.extend(exc.errors)
        else:
            if lock.get("compiled_timeline_sha256") != compiled_identity:
                errors.append("compiled timeline lock identity is missing or changed")
    snapshot = lock.get("asset_snapshot")
    if not isinstance(snapshot, Mapping):
        errors.append("asset snapshot is malformed")
    else:
        for key, value in snapshot.items():
            if not isinstance(value, Mapping):
                errors.append(f"asset snapshot {key} is malformed")
                continue
            try:
                path = Path(_text(value.get("path"))).expanduser().resolve(strict=True)
                if sha256_path(path) != value.get("sha256"):
                    errors.append(f"asset {key} changed after the Atlas lock")
            except Exception as exc:
                errors.append(f"asset {key} cannot be revalidated: {exc}")
    if errors:
        raise AtlasValidationError(errors)
    return {**dict(lock), "validation": "PASS", "record": record.as_dict() if record else None}


__all__ = [
    "APPROVAL_STATES",
    "ASSET_KINDS",
    "ATLAS_ENGINE_ID",
    "ATLAS_ENGINE_VERSION",
    "ATLAS_LOCK_SCHEMA",
    "ATLAS_SCHEMA",
    "AtlasRecord",
    "AtlasValidationError",
    "ENGINE_FAMILIES",
    "HARDWARE_ROLES",
    "NODE_TYPES",
    "canonical_sha256",
    "compiled_timeline_identity_sha256",
    "build_asset_snapshot",
    "compile_timeline",
    "discover_protocol_modules",
    "hardware_role_compatibility_errors",
    "load_protocol_module",
    "normalize_asset_bindings",
    "protocol_readiness",
    "resolve_parameters",
    "sha256_file",
    "sha256_path",
    "validate_protocol_module",
    "validate_reviewed_asset_manifest",
    "validate_protocol_lock",
    "write_protocol_lock",
]
