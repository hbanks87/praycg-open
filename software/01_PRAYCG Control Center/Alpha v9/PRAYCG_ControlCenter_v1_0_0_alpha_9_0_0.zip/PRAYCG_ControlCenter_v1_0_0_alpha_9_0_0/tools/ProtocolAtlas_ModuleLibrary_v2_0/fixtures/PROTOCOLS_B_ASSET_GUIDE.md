# Protocol Atlas asset guide: EMD and SVNA adaptations

These files define import contracts; they do not provide third-party research
stimuli or permission to use them. Keep study assets outside the installed
software directory, select the study's asset folder in the Control Center, and
lock paths and SHA-256 hashes before acquisition.

## EEG Moments-derived repeated clips

The selected folder must contain:

- `emd_media_manifest.json`, made from
  `EMD_external_media_manifest_template_v1_0.json`;
- one frozen schedule named `emd_schedule*.json`, made from
  `EMD_schedule_template_v1_0.json`;
- `emd_run_selection.json`, made from
  `EMD_run_selection_template_v1_0.json`; and
- every locally reviewed audiovisual clip referenced by the media manifest.

The run-selection file binds exact manifest and schedule filenames, identifiers,
and SHA-256 digests; separate positive `session_index` and `run_index` values;
and frozen/reviewed metadata. The session index entered in the Control Center
must equal the selected session. The run index comes only from this file.

Every clip needs a stable identifier, relative path, SHA-256 digest, expected
three-second duration, audio expectation, and source/license record. A question
may be attached to a clip, but the locked schedule and selection determine which
trials are compiled. The compiler records the exact selected trial rows and the
selection, schedule, manifest, clip, and complete-directory identities. The
runner must reject a missing or changed tree member, a schedule that references
an unknown clip, a mismatched manifest/schedule/selection identity, a duplicate
session/run/trial identifier, or invalid repetition counts.

The packaged timing contract is 1.00 seconds of fixation, 3.00 seconds of
audiovisual clip playback, 0.25 seconds of post-clip fixation, and 1.50 seconds
for the blink cue. On probe trials, the recorded question/response interval is
inserted after post-clip fixation and before the blink cue. This is a PRAYCG
adaptation of the public task timing, not an exact replication.

## SVNA-derived gutter ranking

The default geometric demo requires no external assets. It is stored under
`examples/no_copyright_media_demo/protocol_atlas/` so its CC0 status is explicit.
It is for software validation and operator training only. Its primitive panels
are not replacements for a validated visual-narrative stimulus set.

For an imported study, the selected folder must contain
`svna_strip_manifest.json`, made from
`SVNA_operator_strip_manifest_template_v1_0.json`, and every referenced panel
image. Each strip must have one unique strip identifier and exactly six ordered,
uniquely identified panels. Each image needs a relative path and SHA-256 digest.

The participant ranks all five gutters exactly once. The submitted result is a
permutation of `1, 2, 3, 4, 5`; duplicates and omissions must be rejected before
submission. The five rows derived from one strip remain a single dependent
choice set for analysis. They are not five independent samples.
