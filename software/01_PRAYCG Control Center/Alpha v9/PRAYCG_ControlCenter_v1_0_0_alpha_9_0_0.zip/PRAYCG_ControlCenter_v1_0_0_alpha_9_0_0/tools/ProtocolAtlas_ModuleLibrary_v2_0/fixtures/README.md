# Protocol Atlas asset-import templates

This directory contains metadata templates, not research stimuli. No NARR audio,
NATVIEW movie, or Zacks everyday-event video is bundled with the public package.

For an operator-supplied asset, copy the matching template outside the installed
software tree, enter an absolute local path, calculate the file's SHA-256 digest,
record the license or permission basis, review the content and technical
properties, and change `review_status` only after that review. A live protocol
must fail closed when a required path, digest, approval, or media property is
missing or inconsistent. Import review establishes provenance and technical
readiness; it does not establish construct validity or reproduce the source study.

Scrambled NARR derivatives additionally require their intact parent digest,
derivation method, parameters, seed where applicable, and derivative digest. This
prevents a file labeled “scrambled” from being treated as a verified manipulation
solely because of its filename.
