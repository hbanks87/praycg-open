"""Focused contract tests for the first four source-derived Atlas families."""
from __future__ import annotations

import ast
import json
import sys
import unittest
from pathlib import Path


LIBRARY_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = LIBRARY_ROOT / "scripts"
PROTOCOLS = LIBRARY_ROOT / "protocols"
FIXTURES = LIBRARY_ROOT / "fixtures"
sys.path.insert(0, str(SCRIPTS))

from praycg_protocol_atlas_core_v2_0 import (  # noqa: E402
    compile_timeline,
    discover_protocol_modules,
    validate_reviewed_asset_manifest,
)
from praycg_protocol_atlas_engine_v2_0 import dry_run_protocol  # noqa: E402


FILES = {
    "mipdb": "MIPDB_eyes_closed_rest_adaptation_v1_0.json",
    "narr_intact": "NARR_audio_story_intact_adaptation_v1_0.json",
    "narr_coarse": "NARR_audio_story_coarse_scramble_adaptation_v1_0.json",
    "narr_fine": "NARR_audio_story_fine_scramble_adaptation_v1_0.json",
    "natview": "NATVIEW_repeated_naturalistic_video_adaptation_v1_0.json",
    "zacks_passive": "ZACKS_everyday_event_passive_adaptation_v1_0.json",
    "zacks_active": "ZACKS_everyday_event_boundary_marking_adaptation_v1_0.json",
}


def load(name: str) -> dict:
    return json.loads((PROTOCOLS / FILES[name]).read_text(encoding="utf-8"))


class SourceAdaptationContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.records, cls.errors = discover_protocol_modules(LIBRARY_ROOT)
        cls.by_id = {record.protocol_id: record for record in cls.records}

    def test_whole_atlas_discovers_without_errors(self) -> None:
        self.assertEqual(self.errors, [])
        expected = {
            "ATLAS_MIPDB_EYES_CLOSED_REST_ADAPTATION",
            "ATLAS_NARR_AUDIO_INTACT_ADAPTATION",
            "ATLAS_NARR_AUDIO_COARSE_SCRAMBLE_ADAPTATION",
            "ATLAS_NARR_AUDIO_FINE_SCRAMBLE_ADAPTATION",
            "ATLAS_NATVIEW_REPEATED_VIDEO_ADAPTATION",
            "ATLAS_ZACKS_EVENT_PASSIVE_ADAPTATION",
            "ATLAS_ZACKS_EVENT_BOUNDARY_ADAPTATION",
        }
        self.assertTrue(expected.issubset(self.by_id))

    def test_every_adaptation_is_hardware_independent_and_candid(self) -> None:
        for name in FILES:
            with self.subTest(name=name):
                module = load(name)
                self.assertEqual(module["hardware_stack_effect"], "NONE")
                self.assertIsNone(module["hardware_profile_id"])
                self.assertTrue(module["acquisition_contract"]["independent_acquisition_required"])
                self.assertTrue(module["acquisition_contract"]["operator_controls_hardware_elsewhere"])
                self.assertFalse(module["adaptation_status"]["exact_replication"])
                self.assertEqual(module["approval"]["status"], "APPROVED_FOR_ALPHA_TEST")
                self.assertFalse(module["stimulus_contract"]["restricted_media_bundled"])
                self.assertEqual(module["stimulus_contract"]["hash_algorithm"], "SHA-256")

    def test_individual_runners_are_thin_static_dispatchers(self) -> None:
        forbidden_imports = {"subprocess", "socket", "requests", "urllib", "importlib"}
        for name in FILES:
            module = load(name)
            runner = LIBRARY_ROOT / module["runner_entry"]
            with self.subTest(name=name, runner=runner.name):
                tree = ast.parse(runner.read_text(encoding="utf-8"), filename=str(runner))
                imported = {
                    alias.name.split(".")[0]
                    for node in ast.walk(tree)
                    if isinstance(node, ast.Import)
                    for alias in node.names
                }
                imported.update(
                    (node.module or "").split(".")[0]
                    for node in ast.walk(tree)
                    if isinstance(node, ast.ImportFrom)
                )
                self.assertFalse(imported & forbidden_imports)
                text = runner.read_text(encoding="utf-8")
                self.assertIn(FILES[name], text)
                self.assertIn("run_protocol_manifest(MANIFEST", text)

    def test_mipdb_rest_needs_no_external_asset(self) -> None:
        module = load("mipdb")
        self.assertEqual(module["assets"], [])
        rest = next(node for node in module["timeline"] if node["type"] == "eyes_closed_rest")
        self.assertEqual(rest["duration_s"], 180.0)
        self.assertEqual(rest["markers"]["onset"], "MIPDB_EC_REST_ONSET")
        self.assertEqual(rest["markers"]["offset"], "MIPDB_EC_REST_OFFSET")
        self.assertIn("not a recovered historical constant", module["source_attribution"]["adaptation_note"])

    def test_narr_variants_preserve_the_audited_timing_shell(self) -> None:
        expected_roles = {
            "narr_intact": "intact",
            "narr_coarse": "coarse_scramble",
            "narr_fine": "fine_scramble",
        }
        for name, role in expected_roles.items():
            with self.subTest(name=name):
                module = load(name)
                self.assertEqual(module["randomization"]["mode"], "fixed")
                types = [node["type"] for node in module["timeline"]]
                self.assertEqual(types, ["instruction", "wait_for_operator", "fixation", "audio", "fixation", "instruction"])
                fixations = [node["duration_s"] for node in module["timeline"] if node["type"] == "fixation"]
                self.assertEqual(fixations, [12.0, 12.0])
                audio = next(node for node in module["timeline"] if node["type"] == "audio")
                self.assertEqual(audio["media_key"], "story_audio")
                media = module["stimulus_contract"]["media_inputs"][0]
                self.assertEqual(media["required_variant_role"], role)
                self.assertEqual(module["assets"][0]["allowed_extensions"], [".wav"])
                self.assertTrue(module["assets"][0]["reviewed_local_only"])
                if name != "narr_intact":
                    self.assertTrue(media["derivative_provenance_required"])
                    self.assertTrue(media["intact_parent_sha256_required"])

    def test_natview_reuses_one_asset_and_places_optional_flicker_last(self) -> None:
        module = load("natview")
        videos = [node for node in module["timeline"] if node["type"] == "video"]
        self.assertEqual([node["media_key"] for node in videos], ["repeated_video", "repeated_video"])
        self.assertTrue(module["stimulus_contract"]["equality_constraints"][0]["same_sha256_required"])
        video_indices = [module["timeline"].index(node) for node in videos]
        checkerboards = [node for node in module["timeline"] if node["type"] == "checkerboard"]
        self.assertEqual(len(checkerboards), 3)
        self.assertTrue(all(module["timeline"].index(node) > max(video_indices) for node in checkerboards))
        self.assertTrue(all(node["frequency_hz"] == 12.0 for node in checkerboards))
        self.assertTrue(all(node["enabled_when"]["parameter"] == "include_checkerboard_validation" for node in checkerboards))
        record = self.by_id[module["protocol_id"]]
        default_plan = compile_timeline(record, participant_id="PILOT_001")
        enabled_plan = compile_timeline(
            record,
            participant_id="PILOT_001",
            parameters={"include_checkerboard_validation": True},
        )
        self.assertNotIn("checkerboard", [node["type"] for node in default_plan["timeline"]])
        self.assertEqual([node["type"] for node in enabled_plan["timeline"]].count("checkerboard"), 3)

    def test_zacks_passive_and_active_are_separate_and_always_muted(self) -> None:
        passive = load("zacks_passive")
        active = load("zacks_active")
        self.assertNotEqual(passive["protocol_id"], active["protocol_id"])
        expected_keys = ["event_video_123", "event_video_639", "event_video_313", "event_video_241"]
        passive_media = [node for node in passive["timeline"] if node["type"] == "video"]
        active_media = [node for node in active["timeline"] if node["type"] == "boundary_media"]
        self.assertEqual([node["media_key"] for node in passive_media], expected_keys)
        self.assertEqual([node["media_key"] for node in active_media], expected_keys)
        self.assertTrue(all(node["mute_required"] is True for node in passive_media + active_media))
        self.assertTrue(all(node["capture_keys_during"] == [] for node in passive_media))
        self.assertTrue(all(node["capture_keys_during"] == ["space"] for node in active_media))
        self.assertEqual(passive["responses"], [])
        self.assertEqual(active["responses"][0]["id"], "subjective_event_boundary")
        self.assertTrue(any("keypress" in item.lower() for item in active["analysis_handoff"]["confound_flags"]))

    def test_public_package_contains_templates_not_media(self) -> None:
        for name in (
            "NARR_audio_import_manifest.template.json",
            "NATVIEW_video_import_manifest.template.json",
            "ZACKS_video_set_import_manifest.template.json",
        ):
            with self.subTest(name=name):
                payload = json.loads((FIXTURES / name).read_text(encoding="utf-8"))
                self.assertEqual(payload["review_status"], "UNREVIEWED_TEMPLATE")
                for asset in payload["assets"]:
                    self.assertEqual(asset["path"], "")
                    self.assertEqual(asset["sha256"], "")

    def test_unreviewed_template_cannot_authorize_a_live_asset(self) -> None:
        record = self.by_id["ATLAS_NARR_AUDIO_INTACT_ADAPTATION"]
        errors = validate_reviewed_asset_manifest(
            record,
            {
                "reviewed_import_manifest": str(FIXTURES / "NARR_audio_import_manifest.template.json"),
                "story_audio": str(FIXTURES / "not_a_story.wav"),
            },
        )
        self.assertTrue(any("review_status must be APPROVED" in error for error in errors))

    def test_dry_runs_are_deterministic_and_do_not_touch_hardware(self) -> None:
        selected_ids = {load(name)["protocol_id"] for name in FILES}
        for protocol_id in selected_ids:
            with self.subTest(protocol_id=protocol_id):
                record = self.by_id[protocol_id]
                first = dry_run_protocol(record, participant_id="PILOT_001", session_index=1)
                second = dry_run_protocol(record, participant_id="PILOT_001", session_index=1)
                self.assertEqual(first["status"], "PASS")
                self.assertFalse(first["runtime_authority_exercised"])
                self.assertFalse(first["psychopy_exercised"])
                self.assertEqual(first["hardware_stack_effect"], "NONE")
                self.assertEqual(first["compiled_timeline"]["canonical_sha256"], second["compiled_timeline"]["canonical_sha256"])


if __name__ == "__main__":
    unittest.main()
