from __future__ import annotations

import json
import sys
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

import pytest


LIBRARY_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = LIBRARY_ROOT / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

from praycg_protocol_atlas_core_v2_0 import (  # noqa: E402
    AtlasValidationError,
    canonical_sha256,
    compile_timeline,
    discover_protocol_modules,
    hardware_role_compatibility_errors,
    load_protocol_module,
    normalize_asset_bindings,
    protocol_readiness,
    validate_protocol_lock,
    validate_protocol_module,
    write_protocol_lock,
)
from praycg_protocol_atlas_engine_v2_0 import (  # noqa: E402
    AtlasEventLogger,
    AtlasRunState,
    RuntimeContext,
    _als_barcode_design,
    _checkerboard,
    _checkerboard_timing_summary,
    _run_node,
    _wait_draw,
    dry_run_protocol,
)
from praycg_protocol_atlas_engine_v2_0 import (  # noqa: E402
    _validate_runtime_binding,
    _validated_session_purpose_binding,
)


def valid_module() -> dict:
    return {
        "schema": "PRAYCG_ProtocolAtlasModule_v2_0",
        "protocol_id": "TEST_REST",
        "protocol_version": "1.0",
        "display_name": "Test Rest",
        "short_description": "Generated rest protocol used by focused tests.",
        "adaptation_status": {
            "classification": "PRAYCG_ADAPTATION_RECONSTRUCTION",
            "exact_replication": False,
            "source_family": "test",
            "basis": "software validation",
            "departures": ["not a scientific study"],
            "verification_state": "SYNTHETIC_ONLY",
        },
        "source_attribution": {
            "primary_source": "PRAYCG",
            "title": "Synthetic test fixture",
            "license_note": "No external media.",
        },
        "approval": {
            "status": "APPROVED_FOR_ALPHA_TEST",
            "reviewer": "Hoyt Banks",
            "scope": "PROTOCOL_DEFINITION",
            "reviewed_utc": "2026-09-13T00:00:00Z",
        },
        "runner_entry": "scripts/run_protocol_atlas_module_v2_0.py",
        "engine_entry": "scripts/praycg_protocol_atlas_engine_v2_0.py",
        "engine": {"id": "praycg_protocol_atlas_engine", "version": "2.0", "family": "rest"},
        "hardware_stack_effect": "NONE",
        "hardware_profile_id": None,
        "acquisition_contract": {
            "independent_acquisition_required": True,
            "operator_controls_hardware_elsewhere": True,
            "marker_namespace": "TEST",
            "expected_streams": ["StasisMarkers"],
            "required_hardware_roles": ["eeg"],
            "emit_runner_registered_events": True,
            "event_clock": "lsl_local_clock_with_flip_synchronized_visual_events",
        },
        "randomization": {"mode": "fixed", "frozen_before_launch": True, "seed_recorded": True},
        "assets": [],
        "stimulus_contract": {
            "restricted_media_bundled": False,
            "review_required": True,
            "hash_algorithm": "SHA-256",
        },
        "timeline": [
            {
                "id": "REST_1",
                "type": "eyes_closed_rest",
                "duration_s": 60.0,
                "markers": {"onset": "TEST:REST_1:ONSET", "offset": "TEST:REST_1:OFFSET"},
            }
        ],
        "responses": [],
        "analysis_handoff": {
            "event_schema": "PRAYCG_ProtocolAtlas_EventLog_v2_0",
            "response_schema": "PRAYCG_ProtocolAtlas_ResponseLog_v2_0",
            "expected_events": ["TEST:REST_1:ONSET", "TEST:REST_1:OFFSET"],
            "outcomes": ["rest coverage"],
        },
        "safety_and_claim_boundaries": ["Not diagnostic."],
        "readiness_requirements": ["Acquisition preflight passed."],
        "dry_run_tests": ["Compile timeline."],
    }


def test_generated_only_module_validates_and_dry_runs_without_psychopy_or_assets():
    record = validate_protocol_module(valid_module(), LIBRARY_ROOT)
    result = dry_run_protocol(record, participant_id="PTEST", session_index=1)
    assert result["status"] == "PASS"
    assert result["runtime_authority_exercised"] is False
    assert result["external_assets_not_opened"] == []
    assert result["compiled_timeline"]["timeline"][0]["compiled_instance_id"] == "REST_1__001"


@pytest.mark.parametrize(
    ("field", "value", "message"),
    [
        ("hardware_stack_effect", "CHANGE_PROFILE", "hardware_stack_effect"),
        ("hardware_profile_id", "openbci", "hardware_profile_id"),
    ],
)
def test_hardware_authority_is_rejected(field, value, message):
    module = valid_module()
    module[field] = value
    with pytest.raises(AtlasValidationError, match=message):
        validate_protocol_module(module, LIBRARY_ROOT)


def test_embedded_command_is_rejected_recursively():
    module = valid_module()
    module["parameters"] = {"nested": {"command": "python unreviewed.py"}}
    with pytest.raises(AtlasValidationError, match="cannot embed executable instructions"):
        validate_protocol_module(module, LIBRARY_ROOT)


def test_operator_asset_is_required_for_readiness_but_not_schema_dry_run(tmp_path):
    module = valid_module()
    module["assets"] = [{
        "key": "movie",
        "role": "stimulus",
        "kind": "video",
        "required": True,
        "source": "operator_selection",
        "allowed_extensions": [".mp4"],
        "reviewed_local_only": True,
    }]
    module["timeline"][0] = {
        "id": "MOVIE_1",
        "type": "video",
        "media_key": "movie",
        "markers": {"onset": "TEST:MOVIE_1:ONSET", "offset": "TEST:MOVIE_1:OFFSET"},
    }
    record = validate_protocol_module(module, LIBRARY_ROOT)
    assert dry_run_protocol(record)["status"] == "PASS"
    readiness = protocol_readiness(record, asset_bindings={}, participant_id="P1", session_index=1)
    assert readiness["status"] == "INELIGIBLE"
    assert "required asset is missing: movie" in readiness["reasons"]


def test_one_path_cannot_satisfy_two_declared_asset_roles(tmp_path):
    module = valid_module()
    module["assets"] = [
        {
            "key": key,
            "role": key,
            "kind": "trial_manifest",
            "required": True,
            "source": "operator_selection",
            "allowed_extensions": [".json"],
            "reviewed_local_only": True,
        }
        for key in ("anchor_schedule", "stimulus_manifest")
    ]
    record = validate_protocol_module(module, LIBRARY_ROOT)
    shared = tmp_path / "shared.json"
    shared.write_text("{}", encoding="utf-8")

    with pytest.raises(AtlasValidationError, match="cannot satisfy multiple asset roles"):
        normalize_asset_bindings(
            record,
            {"anchor_schedule": str(shared), "stimulus_manifest": str(shared)},
        )


def test_williams_sequence_and_seed_are_frozen_deterministically():
    module = valid_module()
    module["timeline"].append({
        "id": "REST_2",
        "type": "rest",
        "duration_s": 5,
        "markers": {"onset": "TEST:REST_2:ONSET", "offset": "TEST:REST_2:OFFSET"},
    })
    module["randomization"] = {
        "mode": "williams",
        "frozen_before_launch": True,
        "seed_recorded": True,
        "allowed_sequences": [
            {"id": "AB", "order": ["REST_1", "REST_2"]},
            {"id": "BA", "order": ["REST_2", "REST_1"]},
        ],
    }
    record = validate_protocol_module(module, LIBRARY_ROOT)
    first = compile_timeline(record, participant_id="P001", session_index=1)
    second = compile_timeline(record, participant_id="P001", session_index=1)
    assert first == second
    assert first["canonical_sha256"] == second["canonical_sha256"]
    assert first["sequence_id"] in {"AB", "BA"}


def test_protocol_lock_detects_asset_change(tmp_path):
    module = valid_module()
    module["assets"] = [{
        "key": "schedule",
        "role": "trial schedule",
        "kind": "schedule",
        "required": True,
        "source": "operator_selection",
        "allowed_extensions": [".json"],
        "reviewed_local_only": True,
    }]
    module["timeline"][0]["schedule_key"] = "schedule"
    manifest_path = LIBRARY_ROOT / "protocols" / "_temporary_test_manifest.json"
    schedule = tmp_path / "schedule.json"
    schedule.write_text('{"trials": []}', encoding="utf-8")
    try:
        manifest_path.write_text(json.dumps(module), encoding="utf-8")
        discovered, discovery_errors = discover_protocol_modules(LIBRARY_ROOT)
        assert discovery_errors == []
        assert "TEST_REST" not in {record.protocol_id for record in discovered}
        record = load_protocol_module(manifest_path, LIBRARY_ROOT)
        compiled = compile_timeline(record, participant_id="P1")
        lock_path = tmp_path / "atlas_lock.json"
        lock = write_protocol_lock(record, compiled, {"schedule": str(schedule)}, lock_path)
        assert lock["compiled_timeline_sha256"] == compiled["canonical_sha256"]
        assert validate_protocol_lock(lock_path, LIBRARY_ROOT)["validation"] == "PASS"
        schedule.write_text('{"trials": [{"changed": true}]}', encoding="utf-8")
        with pytest.raises(AtlasValidationError, match="changed after the Atlas lock"):
            validate_protocol_lock(lock_path, LIBRARY_ROOT)
    finally:
        manifest_path.unlink(missing_ok=True)


def test_live_runtime_binding_uses_compiled_timeline_self_excluding_hash(monkeypatch, tmp_path):
    """A valid Control Center timeline must survive the live boundary check."""
    record = validate_protocol_module(valid_module(), LIBRARY_ROOT)
    compiled = compile_timeline(record, participant_id="P1", session_index=1)
    protocol_identity = {
        "protocol_id": record.protocol_id,
        "protocol_version": record.protocol_version,
        "protocol_module_file_sha256": record.manifest_sha256,
        "protocol_module_canonical_sha256": canonical_sha256(record.module),
        "runner_file_sha256": record.runner_sha256,
        "engine_file_sha256": record.engine_sha256,
    }
    lock = {
        "lock_core": {"selection_identity": {"protocol": protocol_identity}},
        "session": {
            "session_id": "RUN1",
            "session_index": 1,
            "participant_pseudonym": "P1",
            "session_purpose": "PARTICIPANT_ACQUISITION",
            "participant_data_eligible": True,
            "bench_test_mode": False,
            "bench_readiness_bypass_active": False,
            "bench_test_reason": "",
            "assigned_sequence": [
                node["compiled_instance_id"] for node in compiled["timeline"]
            ],
            "compiled_timeline_sha256": compiled["canonical_sha256"],
            "atlas_asset_snapshot": {},
            "runner_configuration_policy": {
                "policy_version": "PRAYCG_RunnerConfigurationPolicy_v1_0_alpha_2"
            },
        },
    }
    profile = {"status": "APPROVED", "resolved_roles": {"eeg": ["obci_eeg1"]}, "modules": []}
    profile["canonical_sha256"] = canonical_sha256(profile)
    profile_path = tmp_path / "hardware_profile.json"
    profile_path.write_text(json.dumps(profile), encoding="utf-8")
    lock["lock_core"]["hardware_profile_canonical_sha256"] = profile["canonical_sha256"]
    lock["session"]["hardware_profile"] = str(profile_path)

    class FakeLegacy:
        @staticmethod
        def load_runtime_session_authority(*, required_stage):
            assert required_stage == "ACQUIRE"
            return tmp_path / "runtime_session_lock.json", lock

    monkeypatch.setenv("PRAYCG_RUN_UUID", "RUN1")
    monkeypatch.setenv("PRAYCG_PARTICIPANT_PSEUDONYM", "P1")
    monkeypatch.setenv("PRAYCG_SESSION_PURPOSE", "PARTICIPANT_ACQUISITION")
    monkeypatch.setenv("PRAYCG_BENCH_TEST_MODE", "0")
    monkeypatch.setenv("PRAYCG_BENCH_READINESS_BYPASS", "0")
    path, observed = _validate_runtime_binding(
        FakeLegacy,
        record,
        compiled,
        {},
    )
    assert path == tmp_path / "runtime_session_lock.json"
    assert observed["lock_core"] == lock["lock_core"]
    assert observed["session"]["bench_hardware_role_bypass"] == {
        "schema": "PRAYCG_AtlasBenchHardwareRoleBypass_v1_0",
        "active": False,
        "hardware_role_findings": [],
    }
    monkeypatch.setenv("PRAYCG_BENCH_TEST_MODE", "1")
    with pytest.raises(RuntimeError, match="PRAYCG_BENCH_TEST_MODE"):
        _validate_runtime_binding(FakeLegacy, record, compiled, {})


def test_live_runtime_binding_bypasses_missing_roles_only_for_hash_bound_bench_session(monkeypatch, tmp_path):
    record = validate_protocol_module(valid_module(), LIBRARY_ROOT)
    compiled = compile_timeline(record, participant_id="BENCH-RUN1", session_index=1)
    protocol_identity = {
        "protocol_id": record.protocol_id,
        "protocol_version": record.protocol_version,
        "protocol_module_file_sha256": record.manifest_sha256,
        "protocol_module_canonical_sha256": canonical_sha256(record.module),
        "runner_file_sha256": record.runner_sha256,
        "engine_file_sha256": record.engine_sha256,
    }
    profile = {"status": "APPROVED", "resolved_roles": {}, "modules": []}
    profile["canonical_sha256"] = canonical_sha256(profile)
    profile_path = tmp_path / "hardware_profile.json"
    profile_path.write_text(json.dumps(profile), encoding="utf-8")
    lock = {
        "lock_core": {
            "selection_identity": {"protocol": protocol_identity},
            "hardware_profile_canonical_sha256": profile["canonical_sha256"],
        },
        "session": {
            "session_id": "RUN1",
            "session_index": 1,
            "participant_pseudonym": "BENCH-RUN1",
            "session_purpose": "BENCH_TEST",
            "participant_data_eligible": False,
            "bench_test_mode": True,
            "bench_readiness_bypass_active": True,
            "bench_test_reason": "cap-off software validation",
            "assigned_sequence": [node["compiled_instance_id"] for node in compiled["timeline"]],
            "compiled_timeline_sha256": compiled["canonical_sha256"],
            "atlas_asset_snapshot": {},
            "runner_configuration_policy": {
                "policy_version": "PRAYCG_RunnerConfigurationPolicy_v1_0_alpha_2"
            },
            "hardware_profile": str(profile_path),
        },
    }

    class FakeLegacy:
        @staticmethod
        def load_runtime_session_authority(*, required_stage):
            assert required_stage == "ACQUIRE"
            return tmp_path / "runtime_session_lock.json", lock

    monkeypatch.setenv("PRAYCG_RUN_UUID", "RUN1")
    monkeypatch.setenv("PRAYCG_PARTICIPANT_PSEUDONYM", "BENCH-RUN1")
    monkeypatch.setenv("PRAYCG_SESSION_PURPOSE", "BENCH_TEST")
    monkeypatch.setenv("PRAYCG_BENCH_TEST_MODE", "1")
    monkeypatch.setenv("PRAYCG_BENCH_READINESS_BYPASS", "1")
    _path, runtime_lock = _validate_runtime_binding(FakeLegacy, record, compiled, {})
    bypass = runtime_lock["session"]["bench_hardware_role_bypass"]
    assert bypass["active"] is True
    assert bypass["participant_data_eligible"] is False
    assert bypass["hardware_role_findings"] == [
        "reviewed hardware profile lacks required semantic role: eeg"
    ]

    lock["session"].update({
        "participant_pseudonym": "P1",
        "session_purpose": "PARTICIPANT_ACQUISITION",
        "participant_data_eligible": True,
        "bench_test_mode": False,
        "bench_readiness_bypass_active": False,
        "bench_test_reason": "",
    })
    participant_compiled = compile_timeline(record, participant_id="P1", session_index=1)
    lock["session"]["assigned_sequence"] = [
        node["compiled_instance_id"] for node in participant_compiled["timeline"]
    ]
    lock["session"]["compiled_timeline_sha256"] = participant_compiled["canonical_sha256"]
    monkeypatch.setenv("PRAYCG_PARTICIPANT_PSEUDONYM", "P1")
    monkeypatch.setenv("PRAYCG_SESSION_PURPOSE", "PARTICIPANT_ACQUISITION")
    monkeypatch.setenv("PRAYCG_BENCH_TEST_MODE", "0")
    monkeypatch.setenv("PRAYCG_BENCH_READINESS_BYPASS", "0")
    with pytest.raises(RuntimeError, match="Atlas hardware-role compatibility failed"):
        _validate_runtime_binding(FakeLegacy, record, participant_compiled, {})


@pytest.mark.parametrize(
    ("session", "environment_purpose", "environment_bench", "message"),
    [
        (
            {
                "participant_pseudonym": "BENCH-RUN1",
                "session_purpose": "BENCH_TEST",
                "participant_data_eligible": False,
                "bench_test_mode": True,
                "bench_readiness_bypass_active": True,
                "bench_test_reason": "cap-off signal-path validation",
            },
            "BENCH_TEST",
            "1",
            None,
        ),
        (
            {
                "participant_pseudonym": "P1",
                "session_purpose": "PARTICIPANT_ACQUISITION",
                "participant_data_eligible": True,
                "bench_test_mode": False,
                "bench_readiness_bypass_active": False,
                "bench_test_reason": "",
            },
            "PARTICIPANT_ACQUISITION",
            "0",
            None,
        ),
        (
            {
                "participant_pseudonym": "BENCH-RUN1",
                "session_purpose": "BENCH_TEST",
                "participant_data_eligible": False,
                "bench_test_mode": True,
                "bench_readiness_bypass_active": True,
                "bench_test_reason": "",
            },
            "BENCH_TEST",
            "1",
            "bench_test_reason",
        ),
        (
            {
                "participant_pseudonym": "P1",
                "session_purpose": "BENCH_TEST",
                "participant_data_eligible": False,
                "bench_test_mode": True,
                "bench_readiness_bypass_active": True,
                "bench_test_reason": "test",
            },
            "BENCH_TEST",
            "1",
            "BENCH-",
        ),
        (
            {
                "participant_pseudonym": "BENCH-RUN1",
                "session_purpose": "PARTICIPANT_ACQUISITION",
                "participant_data_eligible": True,
                "bench_test_mode": False,
                "bench_readiness_bypass_active": False,
                "bench_test_reason": "",
            },
            "PARTICIPANT_ACQUISITION",
            "0",
            "must not begin",
        ),
        (
            {
                "participant_pseudonym": "P1",
                "session_purpose": "PARTICIPANT_ACQUISITION",
                "participant_data_eligible": True,
                "bench_test_mode": False,
                "bench_readiness_bypass_active": False,
                "bench_test_reason": "",
            },
            "BENCH_TEST",
            "0",
            "PRAYCG_SESSION_PURPOSE",
        ),
        (
            {
                "participant_pseudonym": "BENCH-RUN1",
                "session_purpose": "BENCH_TEST",
                "participant_data_eligible": False,
                "bench_test_mode": True,
                "bench_readiness_bypass_active": True,
                "bench_test_reason": "test",
            },
            "BENCH_TEST",
            "0",
            "PRAYCG_BENCH_TEST_MODE",
        ),
    ],
)
def test_atlas_purpose_contract_is_fail_closed(monkeypatch, session, environment_purpose, environment_bench, message):
    monkeypatch.setenv("PRAYCG_SESSION_PURPOSE", environment_purpose)
    monkeypatch.setenv("PRAYCG_BENCH_TEST_MODE", environment_bench)
    monkeypatch.setenv(
        "PRAYCG_BENCH_READINESS_BYPASS",
        "1" if session["bench_readiness_bypass_active"] else "0",
    )
    lock = {"session": session}
    if message is None:
        assert _validated_session_purpose_binding(lock) == {
            "session_purpose": session["session_purpose"],
            "participant_data_eligible": session["participant_data_eligible"],
            "bench_test_mode": session["bench_test_mode"],
            "bench_readiness_bypass_active": session["bench_readiness_bypass_active"],
            "bench_test_reason": session["bench_test_reason"],
        }
    else:
        with pytest.raises(RuntimeError, match=message):
            _validated_session_purpose_binding(lock)


def test_atlas_run_state_and_checkpoint_persist_bench_label(tmp_path, monkeypatch):
    record = validate_protocol_module(valid_module(), LIBRARY_ROOT)
    compiled = compile_timeline(record, participant_id="BENCH-RUN1", session_index=1)
    session = {
        "participant_pseudonym": "BENCH-RUN1",
        "session_purpose": "BENCH_TEST",
        "participant_data_eligible": False,
        "bench_test_mode": True,
        "bench_readiness_bypass_active": True,
        "bench_test_reason": "cap-off signal-path validation",
    }
    monkeypatch.setenv("PRAYCG_SESSION_PURPOSE", "BENCH_TEST")
    monkeypatch.setenv("PRAYCG_BENCH_TEST_MODE", "1")
    monkeypatch.setenv("PRAYCG_BENCH_READINESS_BYPASS", "1")
    _validated_session_purpose_binding({"session": session})
    logger = AtlasEventLogger(tmp_path, record, compiled, "BENCH-RUN1", "RUN1")
    try:
        run_state = AtlasRunState(logger, record, compiled, {}, session)
        run_state.checkpoint(0)
        persisted = json.loads(run_state.path.read_text(encoding="utf-8"))
        checkpoint = json.loads(run_state.checkpoint_path.read_text(encoding="utf-8"))
        for payload in (persisted, checkpoint):
            assert payload["session_purpose"] == "BENCH_TEST"
            assert payload["participant_data_eligible"] is False
            assert payload["bench_test_mode"] is True
            assert payload["bench_readiness_bypass_active"] is True
            assert payload["bench_test_reason"] == "cap-off signal-path validation"
    finally:
        logger.close()


def test_compiled_timeline_self_hash_tamper_fails_at_protocol_lock(tmp_path):
    record = validate_protocol_module(valid_module(), LIBRARY_ROOT)
    compiled = compile_timeline(record, participant_id="P1", session_index=1)
    lock_path = tmp_path / "atlas_lock.json"
    write_protocol_lock(record, compiled, {}, lock_path)
    payload = json.loads(lock_path.read_text(encoding="utf-8"))
    payload["compiled_timeline"]["participant_id"] = "P2"
    core = {key: value for key, value in payload.items() if key != "lock_identity_sha256"}
    payload["lock_identity_sha256"] = canonical_sha256(core)
    lock_path.write_text(json.dumps(payload), encoding="utf-8")
    with pytest.raises(AtlasValidationError, match="compiled timeline canonical identity"):
        validate_protocol_lock(lock_path, LIBRARY_ROOT)


def test_actual_run_rejects_in_memory_manifest_before_importing_psychopy():
    from praycg_protocol_atlas_engine_v2_0 import run_protocol_manifest

    with pytest.raises(AtlasValidationError, match="packaged manifest path"):
        run_protocol_manifest(deepcopy(valid_module()), dry_run=False)


def test_nested_timeline_children_are_validated_recursively():
    module = valid_module()
    module["timeline"] = [{
        "id": "BLOCK_1",
        "type": "block",
        "trials": "generated",
        "markers": {"onset": "TEST:BLOCK:ONSET", "offset": "TEST:BLOCK:OFFSET"},
        "children": [{
            "id": "BAD_CHILD",
            "type": "not_a_runtime_node",
            "markers": {"onset": "TEST:CHILD:ONSET", "offset": "TEST:CHILD:OFFSET"},
        }],
    }]
    with pytest.raises(AtlasValidationError, match=r"timeline\[0\]\.children\[0\]\.type is unsupported"):
        validate_protocol_module(module, LIBRARY_ROOT)


def test_nested_ids_and_markers_share_global_uniqueness_scope():
    module = valid_module()
    module["timeline"].append({
        "id": "BLOCK_1",
        "type": "block",
        "trials": "generated",
        "markers": {"onset": "TEST:BLOCK:ONSET", "offset": "TEST:BLOCK:OFFSET"},
        "children": [{
            "id": "REST_1",
            "type": "fixation",
            "duration_s": 1,
            "markers": {"onset": "TEST:REST_1:ONSET", "offset": "TEST:CHILD:OFFSET"},
        }],
    })
    with pytest.raises(AtlasValidationError) as caught:
        validate_protocol_module(module, LIBRARY_ROOT)
    assert "id is duplicated" in str(caught.value)
    assert "reuses event marker" in str(caught.value)


def test_typed_node_hidden_outside_children_is_still_validated():
    module = valid_module()
    module["timeline"] = [{
        "id": "BLOCK_1",
        "type": "block",
        "trials": {
            "template": {
                "id": "HIDDEN_TRIAL_NODE",
                "type": "not_a_runtime_node",
                "markers": {"onset": "TEST:HIDDEN:ONSET", "offset": "TEST:HIDDEN:OFFSET"},
            }
        },
        "markers": {"onset": "TEST:BLOCK:ONSET", "offset": "TEST:BLOCK:OFFSET"},
    }]
    with pytest.raises(AtlasValidationError, match=r"timeline\[0\]\.trials\.template\.type is unsupported"):
        validate_protocol_module(module, LIBRARY_ROOT)


@pytest.mark.parametrize("threshold", [-1, 10, 11])
def test_skip_threshold_must_be_bounded_by_break_duration(threshold):
    module = valid_module()
    module["timeline"][0] = {
        "id": "BREAK_1",
        "type": "break",
        "duration_s": 10,
        "skippable_after_seconds": threshold,
        "markers": {"onset": "TEST:BREAK:ONSET", "offset": "TEST:BREAK:OFFSET"},
    }
    with pytest.raises(AtlasValidationError, match="skippable_after_seconds"):
        validate_protocol_module(module, LIBRARY_ROOT)


def test_semantic_hardware_role_check_is_narrow_and_fail_closed():
    module = valid_module()
    assert hardware_role_compatibility_errors(module, {"resolved_roles": {"eeg": ["stream"]}}) == []
    assert hardware_role_compatibility_errors(module, {"resolved_roles": {"heart_rate": ["stream"]}}) == [
        "reviewed hardware profile lacks required semantic role: eeg"
    ]
    assert hardware_role_compatibility_errors(module, {"resolved_roles": {"eeg": []}}) == [
        "reviewed hardware profile lacks required semantic role: eeg"
    ]
    assert hardware_role_compatibility_errors(module, {
        "resolved_roles": {},
        "modules": [{"streams": [{"canonical_role": "eeg", "lsl_name": "obci_eeg1"}]}],
    }) == []


def test_checkerboard_timing_summary_distinguishes_pass_discrepant_and_unavailable():
    records = [
        {"elapsed_seconds": index / 60.0, "reversal_index": int((index / 60.0) * 12.0)}
        for index in range(60)
    ]
    passed = _checkerboard_timing_summary(
        records,
        nominal_reversal_frequency_hz=12.0,
        planned_duration_seconds=1.0,
        maximum_reversal_lateness_seconds=0.025,
    )
    assert passed["status"] == "PASS"
    missing = [row for row in records if row["reversal_index"] != 5]
    discrepant = _checkerboard_timing_summary(
        missing,
        nominal_reversal_frequency_hz=12.0,
        planned_duration_seconds=1.0,
        maximum_reversal_lateness_seconds=0.025,
    )
    assert discrepant["status"] == "DISCREPANT"
    unavailable = _checkerboard_timing_summary(
        [],
        nominal_reversal_frequency_hz=12.0,
        planned_duration_seconds=1.0,
        maximum_reversal_lateness_seconds=0.025,
    )
    assert unavailable["status"] == "UNAVAILABLE"


def test_checkerboard_runtime_records_observed_flips_and_summary():
    logged = []
    markers = []

    class Window:
        size = (1920, 1080)

        def __init__(self):
            self.elapsed = 0.0
            self.callbacks = []

        def callOnFlip(self, function, *args, **kwargs):
            self.callbacks.append((function, args, kwargs))

        def getFutureFlipTime(self, *, clock):
            return (self.elapsed + (1.0 / 60.0)) - clock.offset

        def flip(self):
            self.elapsed += 1.0 / 60.0
            callbacks, self.callbacks = self.callbacks, []
            for function, args, kwargs in callbacks:
                function(*args, **kwargs)

    window = Window()

    class Clock:
        def __init__(self):
            self.offset = 0.0

        def getTime(self):
            return window.elapsed - self.offset

        def reset(self):
            self.offset = window.elapsed

    class Drawable:
        def __init__(self, *args, **kwargs):
            self.fillColor = kwargs.get("fillColor")

        def draw(self):
            return None

    ctx = SimpleNamespace(
        legacy=SimpleNamespace(
            core=SimpleNamespace(Clock=Clock),
            event=SimpleNamespace(getKeys=lambda **kwargs: []),
            local_clock=lambda: 100.0 + window.elapsed,
            visual=SimpleNamespace(Rect=Drawable, TextStim=Drawable),
        ),
        window=window,
        logger=SimpleNamespace(log=lambda marker, **kwargs: logged.append((marker, kwargs))),
        marker=lambda marker, **kwargs: markers.append((marker, kwargs)),
    )
    _checkerboard(ctx, {
        "id": "CHECKER",
        "type": "checkerboard",
        "frequency_hz": 12.0,
        "duration_s": 1.0,
        "maximum_reversal_lateness_seconds": 0.025,
        "record_each_flip_timestamp": True,
    })
    flip_rows = [row for row in logged if row[0] == "ATLAS_CHECKERBOARD_DISPLAY_FLIP"]
    assert len(flip_rows) >= 59
    assert markers[-1][0] == "ATLAS_CHECKERBOARD_TIMING_PASS"
    assert markers[-1][1]["payload"]["observed_flip_count"] == len(flip_rows)


def test_als_overlay_applies_only_to_lock_selected_eligible_nodes_and_fits_display():
    policy = {
        "enable_runner_als_barcode": True,
        "als_barcode_apply_phases": ["VIDEO__001"],
        "als_barcode_position": "lower_right",
        "als_barcode_size_px": 180,
        "als_barcode_margin_px": 40,
    }
    compiled = {"timeline": [{"compiled_instance_id": "VIDEO__001"}]}
    ctx = SimpleNamespace(policy=policy, compiled=compiled, window=SimpleNamespace(size=(1920, 1080)))
    design = _als_barcode_design(ctx, {
        "id": "VIDEO",
        "compiled_instance_id": "VIDEO__001",
        "type": "video",
    })
    assert design is not None
    assert design["source"] == "runner_overlay"
    assert _als_barcode_design(ctx, {
        "id": "VIDEO",
        "compiled_instance_id": "VIDEO__002",
        "type": "video",
    }) is None
    assert _als_barcode_design(ctx, {
        "id": "INSTRUCTION",
        "compiled_instance_id": "VIDEO__001",
        "type": "instruction",
    }) is None

    too_large = SimpleNamespace(
        policy={**policy, "als_barcode_size_px": 1000, "als_barcode_margin_px": 100},
        compiled=compiled,
        window=SimpleNamespace(size=(1920, 1080)),
    )
    with pytest.raises(RuntimeError, match="extend outside"):
        _als_barcode_design(too_large, {
            "id": "VIDEO",
            "compiled_instance_id": "VIDEO__001",
            "type": "video",
        })


def test_flip_synchronized_marker_is_not_emitted_before_flip():
    emitted = []

    class Window:
        callbacks = []

        def callOnFlip(self, function, *args, **kwargs):
            self.callbacks.append((function, args, kwargs))

        def flip(self):
            callbacks, self.callbacks = self.callbacks, []
            for function, args, kwargs in callbacks:
                function(*args, **kwargs)

    class Outlet:
        def push_sample(self, sample, timestamp):
            emitted.append((sample, timestamp))

    class Logger:
        def log(self, marker, **kwargs):
            emitted.append((marker, kwargs))

    ctx = RuntimeContext(
        legacy=SimpleNamespace(local_clock=lambda: 12.5),
        record=None,
        compiled={},
        assets={},
        logger=Logger(),
        run_state=None,
        outlet=Outlet(),
        window=Window(),
        policy={},
    )
    ctx.marker_on_flip("TEST_VISUAL_ONSET", node={"id": "NODE"})
    assert emitted == []
    ctx.window.flip()
    assert emitted[0] == (["TEST_VISUAL_ONSET"], 12.5)
    assert emitted[1][1]["confidence"] == "display_flip_synchronized"


def test_wait_draw_honors_declared_skip_threshold_and_logs_control():
    markers = []

    class Clock:
        def getTime(self):
            return 0.0

    class Event:
        returned = False

        @staticmethod
        def clearEvents():
            return None

        def getKeys(self, **kwargs):
            if self.returned:
                return []
            self.returned = True
            return [("space", 6.0)]

    ctx = SimpleNamespace(
        legacy=SimpleNamespace(
            core=SimpleNamespace(Clock=Clock, wait=lambda value: None),
            event=Event(),
        ),
        window=SimpleNamespace(flip=lambda: None),
        marker=lambda name, **kwargs: markers.append((name, kwargs)),
    )
    _wait_draw(
        ctx,
        {"id": "BREAK", "skippable_after_seconds": 5.0},
        20.0,
    )
    assert markers[0][0] == "ATLAS_BREAK_SKIPPED_AFTER_THRESHOLD"
    assert markers[0][1]["response_time_seconds"] == 6.0


def test_motor_eyes_open_rest_draws_declared_fixation():
    draws = []

    class Clock:
        def __init__(self):
            self.calls = 0

        def getTime(self):
            self.calls += 1
            return 0.0 if self.calls == 1 else 2.0

    class TextStim:
        def __init__(self, window, **kwargs):
            draws.append(("created", kwargs))

        def draw(self):
            draws.append(("drawn", None))

    ctx = SimpleNamespace(
        record=SimpleNamespace(engine_family="motor_imagery"),
        legacy=SimpleNamespace(
            core=SimpleNamespace(Clock=Clock, wait=lambda value: None),
            event=SimpleNamespace(clearEvents=lambda: None, getKeys=lambda **kwargs: []),
            visual=SimpleNamespace(TextStim=TextStim),
        ),
        window=SimpleNamespace(flip=lambda: None),
    )
    _run_node(ctx, {
        "id": "EYES_OPEN_BASELINE",
        "type": "rest",
        "duration_s": 1.0,
        "generated_fixation": True,
    })
    assert draws[0][1]["text"] == "+"
    assert ("drawn", None) in draws
