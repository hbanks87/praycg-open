#!/usr/bin/env python3
"""Integrity tests for the alpha.8 public-dataset protocol expansion."""
from __future__ import annotations

import importlib.util
import json
import sys
from collections import Counter
from pathlib import Path


LIBRARY_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = LIBRARY_ROOT.parents[1]
PROTOCOL_ROOT = LIBRARY_ROOT / "protocols"
SCRIPT_ROOT = LIBRARY_ROOT / "scripts"

NEW_PROTOCOLS = {
    "ATLAS_ERP_CORE_N170_ADAPTATION",
    "ATLAS_ERP_CORE_MMN_ADAPTATION",
    "ATLAS_ERP_CORE_N2PC_ADAPTATION",
    "ATLAS_ERP_CORE_N400_ADAPTATION",
    "ATLAS_ERP_CORE_FLANKER_LRP_ERN_ADAPTATION",
    "ATLAS_NIETO_INNER_SPEECH_DIRECTION_ADAPTATION",
    "ATLAS_NIETO_INNER_SPEECH_TRIAD_CONTROL_ADAPTATION",
    "ATLAS_MEDITATION_VS_ACTIVE_THINKING_ADAPTATION",
    "ATLAS_MEDITATION_THOUGHT_PROBE_ADAPTATION",
    "ATLAS_LOVING_KINDNESS_SELF_OTHER_ADAPTATION",
    "ATLAS_OPENBMI_4_TARGET_SSVEP_ADAPTATION",
    "ATLAS_WANG_40_TARGET_JFPM_SSVEP_ADAPTATION",
}


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def load_core():
    path = SCRIPT_ROOT / "praycg_protocol_atlas_core_v2_0.py"
    spec = importlib.util.spec_from_file_location("atlas_core_alpha8_tests", path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def manifest_by_id() -> dict[str, dict]:
    result = {}
    for path in PROTOCOL_ROOT.glob("*.json"):
        if path.name.startswith((".", "_", "protocol_atlas_module_schema_")):
            continue
        payload = load(path)
        result[payload["protocol_id"]] = payload
    return result


def test_alpha8_discovers_exactly_40_atlas_protocols_and_12_new_entries() -> None:
    core = load_core()
    records, errors = core.discover_protocol_modules(LIBRARY_ROOT)
    assert errors == []
    assert len(records) == 40
    ids = {record.protocol_id for record in records}
    assert NEW_PROTOCOLS <= ids
    assert len(NEW_PROTOCOLS) == 12


def test_every_new_protocol_compiles_deterministically_and_has_a_thin_runner() -> None:
    core = load_core()
    records, errors = core.discover_protocol_modules(LIBRARY_ROOT)
    assert errors == []
    selected = {record.protocol_id: record for record in records if record.protocol_id in NEW_PROTOCOLS}
    assert set(selected) == NEW_PROTOCOLS
    for record in selected.values():
        first = core.compile_timeline(record, participant_id="ALPHA8_TEST", session_index=2, seed=8108)
        second = core.compile_timeline(record, participant_id="ALPHA8_TEST", session_index=2, seed=8108)
        assert first == second
        assert first["canonical_sha256"]
        wrapper = record.runner_path.read_text(encoding="utf-8")
        assert "run_protocol_manifest" in wrapper
        assert "--dry-run" in wrapper
        assert "subprocess" not in wrapper


def test_balanced_compiled_trials_and_inner_speech_contamination_contracts() -> None:
    core = load_core()
    records, _ = core.discover_protocol_modules(LIBRARY_ROOT)
    by_id = {record.protocol_id: record for record in records}

    direction = by_id["ATLAS_NIETO_INNER_SPEECH_DIRECTION_ADAPTATION"]
    compiled = core.compile_timeline(direction, participant_id="BALANCE", seed=99)
    trials = next(node["trials"] for node in compiled["timeline"] if node["id"] == "inner_direction_trials")
    assert Counter(trial["direction"] for trial in trials) == {"UP": 40, "DOWN": 40, "LEFT": 40, "RIGHT": 40}
    assert set(direction.module["acquisition_contract"]["required_hardware_roles"]) == {"eeg", "eog", "emg"}
    assert "Acquisition runner only" in direction.module["analysis_handoff"]["decoder_boundary"]

    triad = by_id["ATLAS_NIETO_INNER_SPEECH_TRIAD_CONTROL_ADAPTATION"]
    triad_compiled = core.compile_timeline(triad, participant_id="BALANCE", seed=100)
    triad_trials = next(node["trials"] for node in triad_compiled["timeline"] if node["id"] == "inner_triad_trials")
    assert Counter(trial["condition"] for trial in triad_trials) == {
        "inner_speech": 80,
        "pronounced_speech": 80,
        "visualized_direction": 80,
    }
    assert set(triad.module["acquisition_contract"]["required_hardware_roles"]) == {"eeg", "eog", "emg", "audio"}


def test_erp_core_expansion_keeps_external_images_separate_and_generated_tasks_balanced() -> None:
    core = load_core()
    records, _ = core.discover_protocol_modules(LIBRARY_ROOT)
    by_id = {record.protocol_id: record for record in records}

    n170 = by_id["ATLAS_ERP_CORE_N170_ADAPTATION"].module
    assert n170["stimulus_contract"]["mode"] == "external_media_import_only"
    assert all(asset["source"] == "operator_selection" for asset in n170["assets"])
    fixture = load(LIBRARY_ROOT / "fixtures" / "N170_reviewed_image_manifest_TEMPLATE_v1_0.json")
    assert fixture["rights_reviewed"] is False

    mmn_record = by_id["ATLAS_ERP_CORE_MMN_ADAPTATION"]
    mmn = core.compile_timeline(mmn_record, participant_id="ERP", seed=41)
    mmn_trials = next(node["trials"] for node in mmn["timeline"] if node["id"] == "mmn_trials")
    assert Counter(trial["condition"] for trial in mmn_trials) == {"standard": 160, "deviant": 40}
    assert all(trial["condition"] != "deviant" for trial in mmn_trials[:2])

    n400_record = by_id["ATLAS_ERP_CORE_N400_ADAPTATION"]
    n400 = core.compile_timeline(n400_record, participant_id="ERP", seed=42)
    n400_trials = next(node["trials"] for node in n400["timeline"] if node["id"] == "n400_trials")
    assert Counter(trial["condition"] for trial in n400_trials) == {"related": 40, "unrelated": 40}


def test_meditation_families_use_locked_generated_instructions_and_probes() -> None:
    manifests = manifest_by_id()
    for protocol_id in {
        "ATLAS_MEDITATION_VS_ACTIVE_THINKING_ADAPTATION",
        "ATLAS_MEDITATION_THOUGHT_PROBE_ADAPTATION",
        "ATLAS_LOVING_KINDNESS_SELF_OTHER_ADAPTATION",
    }:
        module = manifests[protocol_id]
        assert module["stimulus_contract"]["mode"] == "generated_only"
        assert all(asset["source"] == "generated" for asset in module["assets"])
        assert module["stimulus_contract"]["generated_recipe_locked"] is True
    probes = manifests["ATLAS_MEDITATION_THOUGHT_PROBE_ADAPTATION"]
    assert probes["parameters"]["probe_count"] == 6
    assert any(response["id"] == "meditation_state_probe" for response in probes["responses"])


def test_ssvep_recipes_have_refresh_photodiode_and_frame_failure_contracts() -> None:
    manifests = manifest_by_id()
    openbmi = manifests["ATLAS_OPENBMI_4_TARGET_SSVEP_ADAPTATION"]
    wang = manifests["ATLAS_WANG_40_TARGET_JFPM_SSVEP_ADAPTATION"]
    open_node = next(node for node in openbmi["timeline"] if node["type"] == "ssvep_trials")
    wang_nodes = [node for node in wang["timeline"] if node["type"] == "ssvep_trials"]
    assert len(open_node["targets"]) == 4
    assert len(wang_nodes) == 6
    assert all(len(node["targets"]) == 40 for node in wang_nodes)
    for module in (openbmi, wang):
        assert module["engine"]["family"] == "ssvep"
        assert "als" in module["acquisition_contract"]["required_hardware_roles"]
        assert any("fails closed" in boundary.casefold() for boundary in module["safety_and_claim_boundaries"])


def test_ssvep_timing_summary_detects_refresh_mismatch_and_dropped_frames() -> None:
    engine_path = SCRIPT_ROOT / "praycg_protocol_atlas_engine_v2_0.py"
    spec = importlib.util.spec_from_file_location("atlas_engine_alpha8_tests", engine_path)
    assert spec is not None and spec.loader is not None
    sys.path.insert(0, str(SCRIPT_ROOT))
    engine = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = engine
    spec.loader.exec_module(engine)
    good = [index / 60.0 for index in range(120)]
    bad = list(good)
    bad[60] = bad[59] + 0.05
    assert engine._ssvep_timing_summary(good, measured_refresh_hz=60.0, declared_refresh_hz=60.0, refresh_tolerance_hz=1.0)["status"] == "PASS"
    assert engine._ssvep_timing_summary(good, measured_refresh_hz=59.9, declared_refresh_hz=75.0, refresh_tolerance_hz=1.0)["status"] == "DISCREPANT"
    assert engine._ssvep_timing_summary(bad, measured_refresh_hz=60.0, declared_refresh_hz=60.0, refresh_tolerance_hz=1.0)["status"] == "DISCREPANT"


def test_experimental_imports_are_catalog_only_and_openmiir_is_rights_blocked() -> None:
    catalog = load(LIBRARY_ROOT / "experimental_imports_catalog_v1_0.json")
    assert catalog["execution_authority"] == "NONE_CATALOG_ONLY"
    assert len(catalog["candidates"]) == 6
    by_id = {item["candidate_id"]: item for item in catalog["candidates"]}
    assert by_id["EXPERIMENTAL_OPENMIIR"]["status"] == "BLOCKED_MEDIA_RIGHTS_AUDIT"
    discovered_ids = set(manifest_by_id())
    proposed = {runner_id for item in catalog["candidates"] for runner_id in item["proposed_runners"]}
    assert discovered_ids.isdisjoint(proposed)


def test_protocol_workflow_covers_all_43_runnable_entries() -> None:
    workflow = load(PACKAGE_ROOT / "control_center" / "config" / "protocol_stimulus_workflow_v1_0.json")
    ids = [row["protocol_id"] for row in workflow["protocols"]]
    assert len(ids) == 43
    assert len(ids) == len(set(ids))
    assert NEW_PROTOCOLS <= set(ids)
