#!/usr/bin/env python3
"""Focused integrity tests for the second Protocol Atlas alpha wave."""
from __future__ import annotations

import ast
import importlib.util
import json
import sys
import unittest
from pathlib import Path
from typing import Any, Iterable


LIBRARY_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = LIBRARY_ROOT.parents[1]
PROTOCOL_ROOT = LIBRARY_ROOT / "protocols"
FIXTURE_ROOT = LIBRARY_ROOT / "fixtures"
SCRIPT_ROOT = LIBRARY_ROOT / "scripts"

MANIFESTS = {
    "p3b": "ERP_CORE_P3b_visual_oddball_adaptation_v1_0.json",
    "motor": "PhysioNet_EEGMMIDB_motor_imagery_adaptation_v1_0.json",
    "emd": "EEG_Moments_repeated_clips_adaptation_v1_0.json",
    "svna": "SVNA_gutter_ranking_adaptation_v1_0.json",
}

FORBIDDEN_KEYS = {
    "command",
    "commands",
    "command_line",
    "executable",
    "executable_path",
    "python_code",
    "source_code",
    "shell",
    "powershell",
    "subprocess",
    "eval",
    "exec",
    "dynamic_import",
    "plugin_entry",
}


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _walk(value: Any) -> Iterable[Any]:
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from _walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk(child)


def _timeline_nodes(nodes: list[dict[str, Any]]) -> Iterable[dict[str, Any]]:
    for node in nodes:
        yield node
        children = node.get("children")
        if isinstance(children, list):
            yield from _timeline_nodes(children)


class ProtocolAtlasAdaptationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.modules = {key: _load(PROTOCOL_ROOT / name) for key, name in MANIFESTS.items()}

    def test_common_declarative_safety_and_hardware_independence(self) -> None:
        for key, module in self.modules.items():
            with self.subTest(protocol=key):
                self.assertEqual(module["schema"], "PRAYCG_ProtocolAtlasModule_v2_0")
                self.assertFalse(module["adaptation_status"]["exact_replication"])
                self.assertIn("ADAPTATION", module["adaptation_status"]["classification"])
                self.assertEqual(module["engine"]["id"], "praycg_protocol_atlas_engine")
                self.assertEqual(module["engine"]["version"], "2.0")
                self.assertEqual(module["engine_entry"], "scripts/praycg_protocol_atlas_engine_v2_0.py")
                self.assertEqual(module["hardware_stack_effect"], "NONE")
                self.assertIsNone(module["hardware_profile_id"])
                acquisition = module["acquisition_contract"]
                self.assertTrue(acquisition["independent_acquisition_required"])
                self.assertTrue(acquisition["operator_controls_hardware_elsewhere"])
                self.assertFalse(acquisition["may_select_or_modify_hardware"])
                self.assertEqual(module["approval"]["status"], "APPROVED_FOR_ALPHA_TEST")
                self.assertEqual(module["approval"]["reviewer"], "Hoyt Banks")
                self.assertFalse(module["stimulus_contract"]["restricted_media_bundled"])
                self.assertTrue(module["stimulus_contract"]["review_required"])
                self.assertEqual(module["stimulus_contract"]["hash_algorithm"], "SHA-256")
                for item in _walk(module):
                    if isinstance(item, dict):
                        self.assertFalse(FORBIDDEN_KEYS.intersection(map(str.casefold, item.keys())))

    def test_timelines_are_explicit_and_recursive_node_ids_are_unique(self) -> None:
        for key, module in self.modules.items():
            nodes = list(_timeline_nodes(module["timeline"]))
            ids = [node["id"] for node in nodes]
            with self.subTest(protocol=key):
                self.assertEqual(len(ids), len(set(ids)))
                self.assertGreater(len(nodes), 2)
                for node in nodes:
                    self.assertIn("type", node)
                    self.assertIn("onset", node["markers"])
                    self.assertIn("offset", node["markers"])

    def test_all_manifest_wrappers_are_thin_and_safe(self) -> None:
        allowed_imports = {"argparse", "pathlib", "praycg_protocol_atlas_engine_v2_0"}
        for key, module in self.modules.items():
            wrapper = LIBRARY_ROOT / module["runner_entry"]
            tree = ast.parse(wrapper.read_text(encoding="utf-8"), filename=str(wrapper))
            imported: set[str] = set()
            call_names: set[str] = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imported.update(alias.name.split(".")[0] for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imported.add(node.module.split(".")[0])
                elif isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        call_names.add(node.func.id)
                    elif isinstance(node.func, ast.Attribute):
                        call_names.add(node.func.attr)
            with self.subTest(protocol=key):
                self.assertTrue(wrapper.is_file())
                self.assertLessEqual(imported, allowed_imports)
                self.assertTrue({"run_protocol_manifest"}.issubset(call_names))
                self.assertFalse({"eval", "exec", "compile", "system", "Popen", "run"}.intersection(call_names))

    def test_core_validator_accepts_each_adaptation(self) -> None:
        core_path = SCRIPT_ROOT / "praycg_protocol_atlas_core_v2_0.py"
        spec = importlib.util.spec_from_file_location("atlas_core_for_adaptation_tests", core_path)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        core = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = core
        spec.loader.exec_module(core)
        for key, filename in MANIFESTS.items():
            with self.subTest(protocol=key):
                record = core.load_protocol_module(PROTOCOL_ROOT / filename, LIBRARY_ROOT)
                self.assertEqual(record.module["hardware_stack_effect"], "NONE")

    def test_p3b_has_balanced_generated_target_contract(self) -> None:
        module = self.modules["p3b"]
        self.assertEqual(module["engine"]["family"], "generated_erp")
        self.assertTrue(all(asset["source"] == "generated" for asset in module["assets"]))
        trials = module["parameters"]["trials_per_block"]
        targets = trials * module["parameters"]["target_probability"]
        self.assertEqual(targets, int(targets))
        self.assertEqual(module["randomization"]["counterbalance"]["levels"], ["circle_target", "diamond_target"])
        self.assertIn("P3B_TARGET_ONSET", module["analysis_handoff"]["expected_events"])

    def test_motor_task_keeps_execution_and_imagery_separate(self) -> None:
        module = self.modules["motor"]
        self.assertEqual(module["engine"]["family"], "motor_imagery")
        self.assertEqual(set(module["parameters"]["task_modes"]), {"motor_execution", "motor_imagery"})
        self.assertEqual(
            set(module["parameters"]["effector_pairs"]),
            {"left_fist_vs_right_fist", "both_fists_vs_both_feet"},
        )
        self.assertEqual(set(module["parameters"]["baseline_options"]), {"eyes_open", "eyes_closed", "both", "none"})
        self.assertEqual(module["parameters"]["trials_per_cue_class"], 15)
        self.assertNotIn("repetitions_per_block", module["parameters"])
        self.assertIn("MOTOR_EXECUTION_CUE_ONSET", module["analysis_handoff"]["expected_events"])
        self.assertIn("MOTOR_IMAGERY_CUE_ONSET", module["analysis_handoff"]["expected_events"])

    def test_emd_timing_and_external_only_contract(self) -> None:
        module = self.modules["emd"]
        nodes = {node["id"]: node for node in _timeline_nodes(module["timeline"])}
        self.assertEqual(nodes["emd_pre_clip_blank"]["duration_s"], 1.0)
        self.assertEqual(nodes["emd_clip"]["duration_s"], 3.0)
        self.assertEqual(nodes["emd_post_clip_blank"]["duration_s"], 0.25)
        self.assertEqual(nodes["emd_blink_window"]["duration_s"], 1.5)
        self.assertEqual(module["stimulus_contract"]["mode"], "external_media_import_only")
        self.assertTrue(all(asset["source"] == "operator_selection" for asset in module["assets"]))
        self.assertTrue(all(asset["reviewed_local_only"] for asset in module["assets"]))
        fixture = _load(FIXTURE_ROOT / "EMD_external_media_manifest_template_v1_0.json")
        self.assertGreaterEqual(len(fixture["clips"]), 2)
        self.assertNotIn("schedule", fixture)
        schedule = _load(FIXTURE_ROOT / "EMD_schedule_template_v1_0.json")
        self.assertTrue(schedule["frozen_before_launch"])
        trial_ids = [
            trial["trial_id"]
            for session in schedule["sessions"]
            for run in session["runs"]
            for trial in run["trials"]
        ]
        self.assertEqual(len(trial_ids), len(set(trial_ids)))

    def test_svna_demo_and_import_contracts_preserve_one_five_way_choice_set(self) -> None:
        module = self.modules["svna"]
        self.assertTrue(module["parameters"]["require_permutation_of_all_gutters"])
        self.assertEqual(module["parameters"]["valid_gutter_ids"], [1, 2, 3, 4, 5])
        self.assertEqual(module["analysis_handoff"]["inferential_unit"], "strip_or_participant_strip_choice_set")
        demo_path = (
            PACKAGE_ROOT
            / "examples"
            / "no_copyright_media_demo"
            / "protocol_atlas"
            / "SVNA_public_safe_demo_strips_v1_0.json"
        )
        demo = _load(demo_path)
        self.assertEqual(demo["license"], "CC0-1.0")
        all_strips = demo["practice_strips"] + demo["main_strips"]
        self.assertGreaterEqual(len(demo["main_strips"]), 3)
        for strip in all_strips:
            self.assertEqual(len(strip["panels"]), 6)
            self.assertEqual(len({panel["panel_id"] for panel in strip["panels"]}), 6)
        source_map = {asset["key"]: asset["source"] for asset in module["assets"]}
        self.assertEqual(source_map["svna_public_safe_demo_strips"], "generated")
        self.assertEqual(source_map["svna_protocol_assets_folder"], "operator_selection")
        self.assertEqual(
            module["stimulus_contract"]["generated_demo_manifest_package_relative"],
            demo_path.relative_to(PACKAGE_ROOT).as_posix(),
        )


if __name__ == "__main__":
    unittest.main()
