from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace


LIBRARY_ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = LIBRARY_ROOT / "scripts"
PACKAGE_ROOT = LIBRARY_ROOT.parents[1]
EVALUATOR_ROOT = PACKAGE_ROOT / "tools" / "Mature_Endpoint_Evaluator_v1_0"
for path in (SCRIPTS, EVALUATOR_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from praycg_protocol_atlas_core_v2_0 import discover_protocol_modules, load_protocol_module  # noqa: E402
from praycg_protocol_atlas_engine_v2_0 import _run_trials, dry_run_protocol  # noqa: E402
from praycg_mature_endpoint_evaluator_v1_0 import evaluate  # noqa: E402


CATALOG_PATH = PACKAGE_ROOT / "config" / "praycg_mature_endpoint_atlas_catalog_v1_0.json"


def _catalog() -> dict:
    return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))


def test_all_mature_endpoint_modules_discover_and_dry_run():
    catalog = _catalog()
    records, errors = discover_protocol_modules(LIBRARY_ROOT)
    assert errors == []
    by_id = {record.protocol_id: record for record in records}
    assert catalog["protocol_count"] == 17
    for row in catalog["protocols"]:
        record = by_id[row["protocol_id"]]
        assert record.module["endpoint_contract"]["schema"] == "PRAYCG_MatureEndpointContract_v1_0"
        assert record.module["hardware_stack_effect"] == "NONE"
        result = dry_run_protocol(record, participant_id="PTEST", session_index=1)
        assert result["status"] == "PASS"
        assert result["protocol_id"] == row["protocol_id"]


def test_praycg_g_uses_five_distinct_arms_and_bit_identical_target_override_asset():
    record = load_protocol_module(LIBRARY_ROOT / "protocols" / "PRAYCG_G_mature_gradient_v2_0.json", LIBRARY_ROOT)
    nodes = {node["id"]: node for node in record.module["timeline"]}
    expected = {
        "phase_scrambled_block",
        "shot_order_block",
        "semantic_zero_block",
        "high_meaning_block",
        "analytic_override_block",
    }
    assert expected.issubset(nodes)
    high_video = next(node for node in nodes["high_meaning_block"]["children"] if node["id"] == "high_meaning_video")
    override_video = next(node for node in nodes["analytic_override_block"]["children"] if node["id"] == "analytic_override_video")
    assert high_video["media_key"] == override_video["media_key"] == "target_override_video"
    endpoint_ids = {row["id"] for row in record.module["endpoint_contract"]["endpoint_families"]}
    assert {"MRED_RECOGNITION", "MRED_INTEGRATION", "MRED_RESOLUTION", "A_MRED"}.issubset(endpoint_ids)


def test_neutral_belief_update_has_trial_addressable_compound_steps():
    record = load_protocol_module(LIBRARY_ROOT / "protocols" / "PRAYCG_D_neutral_belief_update_v1_0.json", LIBRARY_ROOT)
    trial_node = next(node for node in record.module["timeline"] if node["id"] == "d_update_trials")
    assert len(trial_node["trials"]) >= 8
    for trial in trial_node["trials"]:
        steps = {step["step_id"]: step for step in trial["steps"]}
        assert {"initial_choice", "initial_confidence", "new_evidence", "updated_choice", "updated_confidence", "feedback"}.issubset(steps)
        assert steps["initial_choice"]["correct_key"] in {"1", "2"}
        assert steps["updated_choice"]["correct_key"] in {"1", "2"}
        assert steps["initial_choice"]["response_id"] == "initial_urn_choice"
        assert steps["updated_choice"]["response_id"] == "updated_urn_choice"


def test_compound_trial_runtime_emits_step_markers_and_captured_response(monkeypatch):
    emitted = []

    def fake_generated(ctx, node, trial, *, trial_id="", response_context=None):
        assert trial_id == "trial_001"
        assert response_context == {"step_id": "choice"}
        return [{"key": "2", "time": 0.25}]

    import praycg_protocol_atlas_engine_v2_0 as engine

    monkeypatch.setattr(engine, "_generated_visual", fake_generated)
    ctx = SimpleNamespace(
        marker_on_flip=lambda name, **kwargs: emitted.append((name, kwargs)),
        window=SimpleNamespace(flip=lambda: None),
        legacy=SimpleNamespace(),
    )
    node = {
        "id": "COMPOUND",
        "trials": [{
            "trial_id": "trial_001",
            "steps": [{
                "step_id": "choice",
                "kind": "generated_visual",
                "text": "Choose",
                "keys": ["1", "2"],
                "response_id": "choice",
                "correct_key": "2",
            }],
        }],
    }
    _run_trials(ctx, node)
    names = [row[0] for row in emitted]
    assert "COMPOUND_TRIAL_001_CHOICE_ONSET" in names
    assert "COMPOUND_TRIAL_001_CHOICE_OFFSET" in names
    assert "COMPOUND_TRIAL_001_OFFSET" in names
    final = next(kwargs for name, kwargs in emitted if name == "COMPOUND_TRIAL_001_OFFSET")
    assert final["payload"]["captured_responses"] == [{"step_id": "choice", "key": "2", "time": 0.25}]


def test_endpoint_evaluator_scores_complete_positive_belief_update_and_caps_claim(tmp_path):
    manifest_path = LIBRARY_ROOT / "protocols" / "PRAYCG_D_neutral_belief_update_v1_0.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    protocol_id = manifest["protocol_id"]
    events = [
        {"protocol_id": protocol_id, "event_kind": "marker", "marker": marker}
        for marker in manifest["analysis_handoff"]["expected_events"]
    ]
    trial_node = next(node for node in manifest["timeline"] if node["id"] == "d_update_trials")
    event_index = len(events)
    for trial in trial_node["trials"]:
        for step in trial["steps"]:
            if not step.get("keys") or not step.get("response_id"):
                continue
            event_index += 1
            value = step.get("correct_key") or step["keys"][0]
            events.append({
                "event_id": f"E{event_index}",
                "protocol_id": protocol_id,
                "event_kind": "response",
                "trial_id": trial["trial_id"],
                "response_id": step["response_id"],
                "response_value": value,
                "response_time_seconds": 0.5,
            })
    events_path = tmp_path / "events.json"
    events_path.write_text(json.dumps(events), encoding="utf-8")
    gates = {
        "schema": "PRAYCG_MatureEndpointGateStatus_v1_0",
        "protocol_id": protocol_id,
        "gates": [
            {"id": row["id"], "status": "PASS"}
            for row in manifest["endpoint_contract"]["quality_gates"]
        ],
    }
    gates_path = tmp_path / "gates.json"
    gates_path.write_text(json.dumps(gates), encoding="utf-8")
    analysis = {
        "schema": "PRAYCG_MatureEndpointAnalysisStatus_v1_0",
        "protocol_id": protocol_id,
        "primary_endpoint_status": "POSITIVE",
        "preregistered": True,
        "adequately_powered": True,
        "multiplicity_controlled": True,
        "independent_replication": True,
    }
    analysis_path = tmp_path / "analysis.json"
    analysis_path.write_text(json.dumps(analysis), encoding="utf-8")

    report = evaluate(manifest_path, events_path=events_path, gates_path=gates_path, analysis_path=analysis_path)
    assert report["event_coverage"]["coverage_ratio"] == 1.0
    assert report["response_coverage"]["trial_response_completion_ratio"] == 1.0
    assert report["response_coverage"]["accuracy_among_answered"] == 1.0
    assert report["decision"]["label"] == "EXPLORATORY_INTERESTING"
    assert report["decision"]["claim_was_capped"] is True


def test_endpoint_evaluator_refuses_unassessed_required_gates(tmp_path):
    manifest_path = LIBRARY_ROOT / "protocols" / "API_A_calibration_recovery_v2_0.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    events = [
        {"protocol_id": manifest["protocol_id"], "event_kind": "marker", "marker": marker}
        for marker in manifest["analysis_handoff"]["expected_events"]
    ]
    events_path = tmp_path / "events.json"
    events_path.write_text(json.dumps(events), encoding="utf-8")
    report = evaluate(manifest_path, events_path=events_path)
    assert report["decision"]["label"] == "NOT_EVALUABLE"
    assert any("Required gates remain unassessed" in reason for reason in report["decision"]["reasons"])


def test_mature_catalog_is_preserved_with_forty_total_atlas_modules():
    catalog = _catalog()
    records, errors = discover_protocol_modules(LIBRARY_ROOT)
    assert errors == []
    assert len(records) == 40
    assert len(catalog["protocols"]) == 17
    mature_ids = {row["protocol_id"] for row in catalog["protocols"]}
    assert mature_ids.issubset({record.protocol_id for record in records})


def test_protocol_specific_templates_match_every_declared_quality_gate():
    catalog = _catalog()
    gate_root = PACKAGE_ROOT / "config" / "mature_endpoint_gate_templates"
    analysis_root = PACKAGE_ROOT / "config" / "mature_endpoint_analysis_templates"
    for row in catalog["protocols"]:
        manifest = json.loads((LIBRARY_ROOT / "protocols" / row["manifest"]).read_text(encoding="utf-8"))
        protocol_id = manifest["protocol_id"]
        contract = manifest["endpoint_contract"]
        gate_template = json.loads((gate_root / f"{protocol_id}_gate_status_TEMPLATE.json").read_text(encoding="utf-8"))
        analysis_template = json.loads((analysis_root / f"{protocol_id}_analysis_status_TEMPLATE.json").read_text(encoding="utf-8"))
        declared = [(gate["id"], bool(gate.get("required", False)), gate.get("rule", "")) for gate in contract["quality_gates"]]
        templated = [(gate["id"], gate["required"], gate["rule"]) for gate in gate_template["gates"]]
        assert templated == declared
        assert all(gate["status"] == "NOT_ASSESSED" for gate in gate_template["gates"])
        assert analysis_template["primary_endpoint_status"] == "NOT_RUN"
        assert analysis_template["maximum_claim_without_special_measurement"] == contract["maximum_claim_without_special_measurement"]


def test_dyadic_praycg_g_has_identity_common_drive_and_two_participant_boundaries():
    record = load_protocol_module(LIBRARY_ROOT / "protocols" / "PRAYCG_G_dyadic_hyperscanning_v2_0.json", LIBRARY_ROOT)
    gate_ids = {gate["id"] for gate in record.module["endpoint_contract"]["quality_gates"]}
    assert {"dyad_identity_binding", "cross_stream_clock_alignment", "common_drive_surrogate", "partner_specific_artifact"}.issubset(gate_ids)
    response_ids = {response["id"] for response in record.module["responses"]}
    for condition in ("phase_scrambled", "shot_order", "semantic_zero", "high_meaning", "analytic_override"):
        assert f"{condition}_a_immediate" in response_ids
        assert f"{condition}_b_immediate" in response_ids
        assert f"{condition}_a_delayed" in response_ids
        assert f"{condition}_b_delayed" in response_ids
    boundary_text = " ".join(record.module["safety_and_claim_boundaries"]).lower()
    assert "synchrony is not empathy" in boundary_text
    assert "telepathy" in boundary_text


def test_conformity_flow_runner_preserves_disclosure_agency_and_delayed_private_recheck():
    record = load_protocol_module(LIBRARY_ROOT / "protocols" / "Conformity_flow_boundary_layer_v1_0.json", LIBRARY_ROOT)
    gate_ids = {gate["id"] for gate in record.module["endpoint_contract"]["quality_gates"]}
    assert {"consensus_disclosure", "agency_preservation", "performance_adjustment"}.issubset(gate_ids)
    timeline_ids = {node["id"] for node in record.module["timeline"]}
    timeline_ids.update(child["id"] for node in record.module["timeline"] for child in node.get("children", []))
    assert any("recheck" in node_id for node_id in timeline_ids)
    text = json.dumps(record.module, ensure_ascii=False).lower()
    assert "simulated" in text
    assert "private" in text
    assert "voluntary" in text
