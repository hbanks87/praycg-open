#!/usr/bin/env python3
"""Fail-closed tests for the EEG Moments external schedule/run lock."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest


LIBRARY_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_ROOT = LIBRARY_ROOT / "scripts"
CONTROL_CENTER_SCRIPT_ROOT = LIBRARY_ROOT.parents[1] / "control_center" / "scripts"
PROTOCOL_PATH = LIBRARY_ROOT / "protocols" / "EEG_Moments_repeated_clips_adaptation_v1_0.json"
if str(SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPT_ROOT))
if str(CONTROL_CENTER_SCRIPT_ROOT) not in sys.path:
    sys.path.insert(0, str(CONTROL_CENTER_SCRIPT_ROOT))

import praycg_protocol_atlas_engine_v2_0 as atlas_engine  # noqa: E402
from praycg_protocol_atlas_core_v2_0 import (  # noqa: E402
    AtlasValidationError,
    compile_emd_schedule_selection,
    compile_timeline,
    load_protocol_module,
    normalize_asset_bindings,
    sha256_file,
    sha256_path,
)
from praycg_protocol_library_v2_0 import atlas_runtime_plan  # noqa: E402


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


def _fixture_tree(root: Path, *, session_index: int = 3, run_index: int = 2) -> tuple[Any, Path]:
    root.mkdir(parents=True)
    media = root / "media"
    media.mkdir()
    clip_a = media / "clip_a.mp4"
    clip_b = media / "clip_b.mp4"
    clip_c = media / "clip_c.mp4"
    clip_a.write_bytes(b"alpha-three-test-clip-a")
    clip_b.write_bytes(b"alpha-three-test-clip-b")
    clip_c.write_bytes(b"alpha-three-test-clip-c-unselected")

    manifest_path = root / "emd_media_manifest.json"
    manifest = {
        "schema": "PRAYCG_ExternalMediaManifest_v1_0",
        "manifest_id": "EMD_MEDIA_TEST_001",
        "media_root": "media",
        "license_and_access_note": "Synthetic bytes used only for software-lock tests.",
        "clips": [
            {
                "clip_id": "CLIP_A",
                "relative_path": "clip_a.mp4",
                "sha256": sha256_file(clip_a),
                "expected_duration_seconds": 3.0,
                "audio_expected": True,
                "source_reference": "Synthetic test fixture A",
            },
            {
                "clip_id": "CLIP_B",
                "relative_path": "clip_b.mp4",
                "sha256": sha256_file(clip_b),
                "expected_duration_seconds": 3.0,
                "audio_expected": True,
                "source_reference": "Synthetic test fixture B",
            },
            {
                "clip_id": "CLIP_C",
                "relative_path": "clip_c.mp4",
                "sha256": sha256_file(clip_c),
                "expected_duration_seconds": 3.0,
                "audio_expected": True,
                "source_reference": "Synthetic test fixture C, used only outside the selected run",
            },
        ],
    }
    _write_json(manifest_path, manifest)

    schedule_path = root / "emd_schedule_test.json"
    schedule = {
        "schema": "PRAYCG_ClipSchedule_v1_0",
        "schedule_id": "EMD_SCHEDULE_TEST_001",
        "media_manifest_id": manifest["manifest_id"],
        "seed": 93117,
        "generation_method": "fixed synthetic contract test schedule",
        "frozen_before_launch": True,
        "sessions": [
            {
                "session_index": session_index,
                "runs": [
                    {
                        "run_index": 1,
                        "trials": [
                            {"trial_id": "S03_R01_T001", "clip_id": "CLIP_A", "scheduled_repetition": 1, "attention_probe": False},
                            {"trial_id": "S03_R01_T002", "clip_id": "CLIP_B", "scheduled_repetition": 1, "attention_probe": False},
                            {"trial_id": "S03_R01_T003", "clip_id": "CLIP_C", "scheduled_repetition": 1, "attention_probe": False},
                        ],
                    },
                    {
                        "run_index": 2,
                        "trials": [
                            {"trial_id": "S03_R02_T001", "clip_id": "CLIP_B", "scheduled_repetition": 2, "attention_probe": False},
                            {"trial_id": "S03_R02_T002", "clip_id": "CLIP_A", "scheduled_repetition": 2, "attention_probe": False},
                        ],
                    },
                ],
            }
        ],
    }
    _write_json(schedule_path, schedule)

    selection_path = root / "emd_run_selection.json"
    selection = {
        "schema": "PRAYCG_ClipScheduleSelection_v1_0",
        "selection_id": "EMD_SELECTION_TEST_001",
        "schedule_filename": schedule_path.name,
        "schedule_id": schedule["schedule_id"],
        "schedule_sha256": sha256_file(schedule_path),
        "media_manifest_filename": manifest_path.name,
        "media_manifest_id": manifest["manifest_id"],
        "media_manifest_sha256": sha256_file(manifest_path),
        "session_index": session_index,
        "run_index": run_index,
        "frozen_before_launch": True,
        "review_status": "APPROVED",
        "reviewed_by": "Alpha software test",
        "reviewed_utc": "2026-09-13T00:00:00Z",
        "selection_note": "Exercises separate session and within-session run selection.",
    }
    _write_json(selection_path, selection)
    (root / "review_note.txt").write_text("reviewed tree state one", encoding="utf-8")
    return load_protocol_module(PROTOCOL_PATH, LIBRARY_ROOT), schedule_path


def _refresh_selection(root: Path) -> None:
    selection_path = root / "emd_run_selection.json"
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    manifest_path = root / selection["media_manifest_filename"]
    schedule_path = root / selection["schedule_filename"]
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    schedule = json.loads(schedule_path.read_text(encoding="utf-8"))
    selection["media_manifest_id"] = manifest["manifest_id"]
    selection["media_manifest_sha256"] = sha256_file(manifest_path)
    selection["schedule_id"] = schedule["schedule_id"]
    selection["schedule_sha256"] = sha256_file(schedule_path)
    _write_json(selection_path, selection)


def test_success_freezes_exact_selected_run_and_all_external_identities(tmp_path: Path) -> None:
    record, schedule_path = _fixture_tree(tmp_path / "emd")
    root = schedule_path.parent
    bindings = {"emd_protocol_assets_folder": str(root)}

    normalized = normalize_asset_bindings(record, bindings)
    compiled = compile_timeline(
        record,
        participant_id="PSEUDONYM_001",
        session_index=3,
        asset_bindings=normalized,
    )
    selection = compiled["external_schedule_selection"]

    assert selection["status"] == "LOCKED_REVIEWED_SCHEDULE_RUN"
    assert selection["session_index"] == 3
    assert selection["run_index"] == 2
    assert selection["schedule_seed"] == 93117
    assert selection["schedule_generation_method"] == "fixed synthetic contract test schedule"
    assert compiled["randomization_seed"] == 93117
    assert compiled["parameters"]["run_index"] == 2
    assert [row["trial_id"] for row in selection["selected_trials"]] == ["S03_R02_T001", "S03_R02_T002"]
    assert all(row["schedule_session_index"] == 3 for row in selection["selected_trials"])
    assert all(row["schedule_run_index"] == 2 for row in selection["selected_trials"])
    assert selection["selection_sha256"] == sha256_file(root / "emd_run_selection.json")
    assert selection["complete_schedule_sha256"] == sha256_file(schedule_path)
    assert selection["media_manifest_sha256"] == sha256_file(root / "emd_media_manifest.json")
    assert selection["asset_tree_sha256"] == sha256_path(root)

    adapter_record = {
        **record.as_dict(),
        "module_family": "PROTOCOL_ATLAS_V2",
        "library_root": str(LIBRARY_ROOT),
    }
    adapter_compiled = atlas_runtime_plan(
        adapter_record,
        participant_id="PSEUDONYM_001",
        session_index=3,
        asset_bindings=bindings,
    )
    assert adapter_compiled["external_schedule_selection"]["run_index"] == 2
    assert adapter_compiled["external_schedule_selection"]["selected_trials"] == selection["selected_trials"]


def test_manifest_claims_match_the_strict_external_schedule_runtime() -> None:
    record = load_protocol_module(PROTOCOL_PATH, LIBRARY_ROOT)
    module = record.module
    preview = compile_timeline(record, participant_id="DESIGN_PREVIEW", session_index=1)
    assert preview["external_schedule_selection"]["status"] == "ASSET_TREE_REQUIRED_FOR_SESSION_LOCK"
    assert preview["randomization_seed"] is None
    parameters = module["parameters"]
    assert not {
        "attention_probe_mode",
        "attention_probes_per_run",
        "attention_probe_probability_alternative",
        "alpha_pilot_max_trials",
        "resume_requires_exact_session_and_schedule_hash",
    }.intersection(parameters)
    assert module["randomization"]["trial_randomization_mode"].startswith("none_at_runtime")
    source_scale = module["stimulus_contract"]["source_family_scale_reference_only"]
    assert source_scale["runtime_status"] == "REFERENCE_ONLY_NOT_GENERATED_OR_ENFORCED_BY_THIS_RUNNER"
    clip_node = next(
        child
        for node in module["timeline"]
        for child in node.get("children", [])
        if child.get("id") == "emd_clip"
    )
    assert "scale_mode" not in clip_node
    assert "actual_onset" not in clip_node["record_fields"]
    assert "played_frames" not in clip_node["record_fields"]
    readiness = set(module["readiness_requirements"])
    assert not {
        "clip_duration_and_audio_preflight_passed",
        "available_disk_space_checked",
        "marker_round_trip_check_passed",
    }.intersection(readiness)
    assert "resume_is_disabled_for_controlled_acquisition" in module["dry_run_tests"]


def test_exact_metadata_names_and_one_schedule_are_required(tmp_path: Path) -> None:
    record, schedule_path = _fixture_tree(tmp_path / "emd")
    duplicate = schedule_path.with_name("emd_schedule_duplicate.json")
    duplicate.write_bytes(schedule_path.read_bytes())
    with pytest.raises(AtlasValidationError, match="exactly one"):
        compile_emd_schedule_selection(record, schedule_path.parent, expected_session_index=3)

    duplicate.unlink()
    (schedule_path.parent / "emd_run_selection.json").rename(schedule_path.parent / "selection.json")
    with pytest.raises(AtlasValidationError, match="run selection is missing"):
        compile_emd_schedule_selection(record, schedule_path.parent, expected_session_index=3)


def test_selection_session_run_and_identity_mismatches_fail_closed(tmp_path: Path) -> None:
    record, schedule_path = _fixture_tree(tmp_path / "emd")
    root = schedule_path.parent

    with pytest.raises(AtlasValidationError, match="does not match the Control Center session_index"):
        compile_emd_schedule_selection(record, root, expected_session_index=4)

    selection_path = root / "emd_run_selection.json"
    selection = json.loads(selection_path.read_text(encoding="utf-8"))
    selection["run_index"] = 99
    _write_json(selection_path, selection)
    with pytest.raises(AtlasValidationError, match="has no selected session 3, run 99"):
        compile_emd_schedule_selection(record, root, expected_session_index=3)

    selection["run_index"] = 2
    selection["media_manifest_id"] = "WRONG_MANIFEST"
    _write_json(selection_path, selection)
    with pytest.raises(AtlasValidationError, match="media_manifest_id does not match"):
        compile_emd_schedule_selection(record, root, expected_session_index=3)


def test_schedule_and_media_mutations_are_rejected(tmp_path: Path) -> None:
    record, schedule_path = _fixture_tree(tmp_path / "emd")
    root = schedule_path.parent

    schedule = json.loads(schedule_path.read_text(encoding="utf-8"))
    schedule["generation_method"] = "changed after review"
    _write_json(schedule_path, schedule)
    with pytest.raises(AtlasValidationError, match="schedule_sha256 does not match"):
        compile_emd_schedule_selection(record, root, expected_session_index=3)

    _refresh_selection(root)
    clip = root / "media" / "clip_c.mp4"
    clip.write_bytes(b"mutated media outside the selected run")
    with pytest.raises(AtlasValidationError, match="SHA-256 does not match clip CLIP_C"):
        compile_emd_schedule_selection(record, root, expected_session_index=3)


def test_duplicate_trial_identity_is_rejected_even_when_selection_hashes_match(tmp_path: Path) -> None:
    record, schedule_path = _fixture_tree(tmp_path / "emd")
    root = schedule_path.parent
    schedule = json.loads(schedule_path.read_text(encoding="utf-8"))
    schedule["sessions"][0]["runs"][1]["trials"][0]["trial_id"] = "S03_R01_T001"
    _write_json(schedule_path, schedule)
    _refresh_selection(root)

    with pytest.raises(AtlasValidationError, match="duplicate trial_id"):
        compile_emd_schedule_selection(record, root, expected_session_index=3)


def test_runtime_uses_compiled_rows_and_rejects_any_locked_tree_mutation(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    record, schedule_path = _fixture_tree(tmp_path / "emd")
    root = schedule_path.parent
    compiled = compile_timeline(
        record,
        participant_id="PSEUDONYM_001",
        session_index=3,
        asset_bindings={"emd_protocol_assets_folder": str(root)},
    )
    ctx = SimpleNamespace(
        record=record,
        compiled=compiled,
        assets={"emd_protocol_assets_folder": str(root)},
    )

    def _unexpected_json_parse(*_args: Any, **_kwargs: Any) -> Any:
        raise AssertionError("runtime must not parse an external schedule, selection, or media manifest")

    monkeypatch.setattr(atlas_engine.json, "loads", _unexpected_json_parse)
    locked_plan = atlas_engine._locked_emd_compiled_plan(
        {"session": {"atlas_compiled_timeline": compiled}}
    )
    assert locked_plan["canonical_sha256"] == compiled["canonical_sha256"]
    locked_assets = atlas_engine._normalize_locked_emd_assets(
        record,
        {"emd_protocol_assets_folder": str(root)},
    )
    runtime_snapshot = atlas_engine._runtime_asset_snapshot(record, locked_assets)
    assert runtime_snapshot["emd_protocol_assets_folder"]["sha256"] == sha256_path(root)
    trials = atlas_engine._load_emd_trials(ctx)
    assert [trial["trial_id"] for trial in trials] == ["S03_R02_T001", "S03_R02_T002"]

    (root / "review_note.txt").write_text("reviewed tree state two", encoding="utf-8")
    with pytest.raises(RuntimeError, match="complete EEG Moments schedule/media tree changed"):
        atlas_engine._load_emd_trials(ctx)
