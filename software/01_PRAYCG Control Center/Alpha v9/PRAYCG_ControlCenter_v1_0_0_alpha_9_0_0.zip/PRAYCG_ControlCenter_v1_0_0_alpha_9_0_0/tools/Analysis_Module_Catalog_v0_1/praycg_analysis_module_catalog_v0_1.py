#!/usr/bin/env python3
"""Governed, non-authoritative discovery and preflight for analysis modules.

The catalog reads data-only descriptors from the package registry.  It never
imports, executes, promotes, or rewrites a registered analysis module.
"""
from __future__ import annotations

import argparse
import json
import re
import uuid
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Mapping, Sequence


REGISTRY_SCHEMA = "PRAYCG_AnalysisModuleRegistry_v0_1"
DESCRIPTOR_SCHEMA = "PRAYCG_AnalysisModuleDescriptor_v0_1"
VALIDATION_SCHEMA = "PRAYCG_AnalysisModuleCatalogValidation_v0_1"
PREFLIGHT_SCHEMA = "PRAYCG_AnalysisModulePreflight_v0_1"
RUN_IDENTITY_SCHEMA = "PRAYCG_AnalysisRunIdentityResolution_v0_1"
REGISTRY_CLASSIFICATION = "NON_AUTHORITATIVE_DISCOVERY_AND_PREFLIGHT"
MODULE_CLASSIFICATIONS = frozenset(
    {
        "EXPLORATORY_SECONDARY_ANALYSIS",
        "PACKAGED_ANALYSIS_COMPONENT_REFERENCE",
    }
)
NORMALIZED_CONTRACT = "NORMALIZED_GUI_RUN_FOLDER_V0_1"
REFERENCE_ONLY_CONTRACT = "REFERENCE_ONLY_UNNORMALIZED"
NO_AUTHORITY = "NONE"
AUTHORITY_FIELDS = (
    "primary_endpoint_authority",
    "master_suite_eligibility_effect",
    "canonical_gate_effect",
    "runtime_authority",
)
REGISTRY_FIELDS = frozenset(
    {
        "schema",
        "registry_id",
        "version",
        "classification",
        *AUTHORITY_FIELDS,
        "modules",
        "boundary",
    }
)
DESCRIPTOR_FIELDS = frozenset(
    {
        "schema",
        "module_id",
        "module_version",
        "display_name",
        "classification",
        "entry_point",
        "execution_eligible",
        "launch",
        "preflight",
        "dependency_paths",
        *AUTHORITY_FIELDS,
        "claims_boundary",
    }
)
LAUNCH_FIELDS = frozenset(
    {"mode", "gui_argument", "run_folder_argument", "contract_status"}
)
PREFLIGHT_FIELDS = frozenset(
    {
        "requires_run_folder",
        "run_identity_required",
        "required_artifact_groups",
        "optional_artifact_patterns",
    }
)
GROUP_FIELDS = frozenset({"group_id", "match", "patterns"})
MODULE_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
VERSION_RE = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:-[a-z0-9][a-z0-9.-]*)?$")
WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:")
IDENTITY_KEYS = frozenset({"run_uuid", "immutable_run_uuid", "session_id", "expected_run_uuid"})
IDENTITY_FILE_HINTS = ("run", "session", "lease", "owner", "manifest", "state", "arm", "prefill")
MAX_IDENTITY_JSON_FILES = 256
MAX_IDENTITY_JSON_BYTES = 2 * 1024 * 1024
BOUNDARY = (
    "Discovery and preflight verify packaged descriptor paths, declared artifact presence, "
    "and unambiguous run identity only. They do not execute a module, grant a primary "
    "endpoint, change Master Suite eligibility, advance a canonical gate, or validate a claim. "
    "Catalog authority fields describe this catalog only; they neither grant nor revoke authority "
    "defined by an underlying component's own governed contract."
)


def package_root() -> Path:
    return Path(__file__).resolve().parents[2]


PACKAGE_ROOT = package_root()
DEFAULT_REGISTRY = PACKAGE_ROOT / "config" / "analysis_module_registry_v0_1.json"


def _read_json_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ValueError(f"{path.name} must contain one JSON object")
    return value


def _exact_fields(
    value: Mapping[str, Any],
    expected: frozenset[str],
    label: str,
    errors: list[str],
) -> None:
    missing = sorted(expected.difference(value))
    unexpected = sorted(set(value).difference(expected))
    if missing:
        errors.append(f"{label} is missing required fields: {', '.join(missing)}")
    if unexpected:
        errors.append(f"{label} has unsupported fields: {', '.join(unexpected)}")


def _text(value: Any, label: str, errors: list[str], *, minimum: int = 1) -> str:
    result = value.strip() if isinstance(value, str) else ""
    if len(result) < minimum:
        errors.append(f"{label} must be a nonempty string")
    return result


def _duplicates(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    repeated: set[str] = set()
    for value in values:
        if value in seen:
            repeated.add(value)
        seen.add(value)
    return sorted(repeated)


def _safe_relative_parts(value: Any, label: str, errors: list[str], *, glob: bool) -> str:
    raw = _text(value, label, errors)
    if not raw:
        return ""
    normalized = raw.replace("\\", "/")
    path = PurePosixPath(normalized)
    if normalized.startswith("/") or WINDOWS_DRIVE_RE.match(normalized):
        errors.append(f"{label} must be relative")
        return ""
    if any(part in {"", ".", ".."} for part in path.parts):
        errors.append(f"{label} must not contain empty, dot, or traversal components")
        return ""
    if not glob and any(character in normalized for character in "*?[]"):
        errors.append(f"{label} must be a path, not a wildcard pattern")
        return ""
    return normalized


def _packaged_file(
    root: Path,
    value: Any,
    label: str,
    errors: list[str],
) -> Path | None:
    normalized = _safe_relative_parts(value, label, errors, glob=False)
    if not normalized:
        return None
    root_resolved = root.resolve(strict=False)
    candidate = (root_resolved / Path(*PurePosixPath(normalized).parts)).resolve(strict=False)
    try:
        candidate.relative_to(root_resolved)
    except ValueError:
        errors.append(f"{label} resolves outside the package")
        return None
    if not candidate.is_file():
        errors.append(f"{label} is not a packaged file: {normalized}")
    return candidate


def _string_list(value: Any, label: str, errors: list[str], *, allow_empty: bool) -> list[str]:
    if not isinstance(value, list) or (not value and not allow_empty):
        qualifier = "an array" if allow_empty else "a nonempty array"
        errors.append(f"{label} must be {qualifier} of unique strings")
        return []
    result: list[str] = []
    for index, item in enumerate(value):
        text = _text(item, f"{label}[{index}]", errors)
        if text:
            result.append(text)
    repeated = _duplicates(result)
    if repeated:
        errors.append(f"{label} repeats values: {', '.join(repeated)}")
    return result


def _validate_authority(value: Mapping[str, Any], label: str, errors: list[str]) -> None:
    for field in AUTHORITY_FIELDS:
        if value.get(field) != NO_AUTHORITY:
            errors.append(f"{label}.{field} must be {NO_AUTHORITY}")


def validate_descriptor(descriptor: Any, *, root: Path = PACKAGE_ROOT) -> dict[str, Any]:
    """Validate one data-only descriptor without importing its entry point."""
    errors: list[str] = []
    if not isinstance(descriptor, dict):
        return {
            "status": "FAIL",
            "module_id": None,
            "entry_point": None,
            "errors": ["descriptor must be an object"],
        }
    _exact_fields(descriptor, DESCRIPTOR_FIELDS, "descriptor", errors)
    if descriptor.get("schema") != DESCRIPTOR_SCHEMA:
        errors.append(f"descriptor.schema must be {DESCRIPTOR_SCHEMA}")
    module_id = _text(descriptor.get("module_id"), "descriptor.module_id", errors)
    if module_id and not MODULE_ID_RE.fullmatch(module_id):
        errors.append("descriptor.module_id must use 3-64 lower-snake-case characters")
    version = _text(descriptor.get("module_version"), "descriptor.module_version", errors)
    if version and not VERSION_RE.fullmatch(version):
        errors.append("descriptor.module_version must be a three-part semantic version")
    _text(descriptor.get("display_name"), "descriptor.display_name", errors)
    if descriptor.get("classification") not in MODULE_CLASSIFICATIONS:
        errors.append(
            "descriptor.classification must be one of: "
            + ", ".join(sorted(MODULE_CLASSIFICATIONS))
        )
    if not isinstance(descriptor.get("execution_eligible"), bool):
        errors.append("descriptor.execution_eligible must be boolean")
    _validate_authority(descriptor, "descriptor", errors)
    _text(descriptor.get("claims_boundary"), "descriptor.claims_boundary", errors, minimum=20)

    entry = _packaged_file(root, descriptor.get("entry_point"), "descriptor.entry_point", errors)
    if entry is not None and entry.suffix.casefold() != ".py":
        errors.append("descriptor.entry_point must identify a Python file")

    launch = descriptor.get("launch")
    if not isinstance(launch, dict):
        errors.append("descriptor.launch must be an object")
    else:
        _exact_fields(launch, LAUNCH_FIELDS, "descriptor.launch", errors)
        if launch.get("mode") not in {"GUI", "GUI_OR_CLI", "CLI"}:
            errors.append("descriptor.launch.mode must be GUI, GUI_OR_CLI, or CLI")
        if launch.get("gui_argument") not in (None, "--gui"):
            errors.append("descriptor.launch.gui_argument must be null or --gui")
        run_folder_argument = launch.get("run_folder_argument")
        if run_folder_argument is not None and (
            not isinstance(run_folder_argument, str)
            or not re.fullmatch(r"--[a-z][a-z0-9-]*", run_folder_argument)
        ):
            errors.append(
                "descriptor.launch.run_folder_argument must be null or a long CLI option"
            )
        contract_status = launch.get("contract_status")
        if contract_status not in {NORMALIZED_CONTRACT, REFERENCE_ONLY_CONTRACT}:
            errors.append("descriptor.launch.contract_status is unsupported")
        if descriptor.get("execution_eligible") is True:
            if contract_status != NORMALIZED_CONTRACT:
                errors.append(
                    "execution-eligible descriptors require the normalized GUI/run-folder contract"
                )
            if launch.get("mode") != "GUI":
                errors.append("execution-eligible descriptors must declare GUI mode")
            if run_folder_argument != "--run-folder":
                errors.append("execution-eligible descriptors must accept --run-folder")
        elif contract_status == NORMALIZED_CONTRACT:
            errors.append(
                "normalized GUI/run-folder descriptors must be explicitly execution-eligible"
            )

    preflight = descriptor.get("preflight")
    if not isinstance(preflight, dict):
        errors.append("descriptor.preflight must be an object")
    else:
        _exact_fields(preflight, PREFLIGHT_FIELDS, "descriptor.preflight", errors)
        if preflight.get("requires_run_folder") is not True:
            errors.append("descriptor.preflight.requires_run_folder must be true")
        if not isinstance(preflight.get("run_identity_required"), bool):
            errors.append("descriptor.preflight.run_identity_required must be boolean")
        groups = preflight.get("required_artifact_groups")
        group_ids: list[str] = []
        if not isinstance(groups, list) or not groups:
            errors.append("descriptor.preflight.required_artifact_groups must be a nonempty array")
        else:
            for index, group in enumerate(groups):
                group_label = f"descriptor.preflight.required_artifact_groups[{index}]"
                if not isinstance(group, dict):
                    errors.append(f"{group_label} must be an object")
                    continue
                _exact_fields(group, GROUP_FIELDS, group_label, errors)
                group_id = _text(group.get("group_id"), f"{group_label}.group_id", errors)
                if group_id:
                    group_ids.append(group_id)
                    if not MODULE_ID_RE.fullmatch(group_id):
                        errors.append(f"{group_label}.group_id must use lower snake case")
                if group.get("match") not in {"AT_LEAST_ONE", "EXACTLY_ONE"}:
                    errors.append(f"{group_label}.match is unsupported")
                patterns = _string_list(group.get("patterns"), f"{group_label}.patterns", errors, allow_empty=False)
                for pattern_index, pattern in enumerate(patterns):
                    _safe_relative_parts(pattern, f"{group_label}.patterns[{pattern_index}]", errors, glob=True)
        repeated_groups = _duplicates(group_ids)
        if repeated_groups:
            errors.append(f"descriptor.preflight repeats group IDs: {', '.join(repeated_groups)}")
        optional_patterns = _string_list(
            preflight.get("optional_artifact_patterns"),
            "descriptor.preflight.optional_artifact_patterns",
            errors,
            allow_empty=True,
        )
        for index, pattern in enumerate(optional_patterns):
            _safe_relative_parts(
                pattern,
                f"descriptor.preflight.optional_artifact_patterns[{index}]",
                errors,
                glob=True,
            )

    dependencies = _string_list(
        descriptor.get("dependency_paths"),
        "descriptor.dependency_paths",
        errors,
        allow_empty=True,
    )
    for index, dependency in enumerate(dependencies):
        _packaged_file(root, dependency, f"descriptor.dependency_paths[{index}]", errors)

    return {
        "status": "PASS" if not errors else "FAIL",
        "module_id": module_id or None,
        "entry_point": str(entry) if entry is not None else None,
        "execution_eligible": descriptor.get("execution_eligible") is True,
        "errors": errors,
    }


def validate_registry(
    registry_path: Path = DEFAULT_REGISTRY,
    *,
    root: Path = PACKAGE_ROOT,
) -> dict[str, Any]:
    """Validate the registry and every declared module as packaged metadata."""
    registry_path = Path(registry_path).expanduser().resolve(strict=False)
    errors: list[str] = []
    try:
        registry = _read_json_object(registry_path)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
        return {
            "schema": VALIDATION_SCHEMA,
            "status": "FAIL",
            "registry_path": str(registry_path),
            "module_count": 0,
            "valid_module_count": 0,
            "modules": [],
            "errors": [f"Registry load failed: {type(exc).__name__}: {exc}"],
            "authority_boundary": _authority_boundary(),
            "boundary": BOUNDARY,
        }

    _exact_fields(registry, REGISTRY_FIELDS, "registry", errors)
    if registry.get("schema") != REGISTRY_SCHEMA:
        errors.append(f"registry.schema must be {REGISTRY_SCHEMA}")
    if registry.get("registry_id") != "praycg_packaged_analysis_modules":
        errors.append("registry.registry_id must be praycg_packaged_analysis_modules")
    version = _text(registry.get("version"), "registry.version", errors)
    if version and not VERSION_RE.fullmatch(version):
        errors.append("registry.version must be a three-part semantic version")
    if registry.get("classification") != REGISTRY_CLASSIFICATION:
        errors.append(f"registry.classification must be {REGISTRY_CLASSIFICATION}")
    _validate_authority(registry, "registry", errors)
    _text(registry.get("boundary"), "registry.boundary", errors, minimum=20)

    raw_modules = registry.get("modules")
    reports: list[dict[str, Any]] = []
    module_ids: list[str] = []
    if not isinstance(raw_modules, list) or not raw_modules:
        errors.append("registry.modules must be a nonempty array")
        raw_modules = []
    for index, descriptor in enumerate(raw_modules):
        report = validate_descriptor(descriptor, root=root)
        report["registry_index"] = index
        report["descriptor"] = descriptor if isinstance(descriptor, dict) else None
        reports.append(report)
        if report.get("module_id"):
            module_ids.append(str(report["module_id"]))
        errors.extend(f"modules[{index}]: {message}" for message in report["errors"])
    repeated_ids = _duplicates(module_ids)
    if repeated_ids:
        errors.append(f"registry.modules repeats module IDs: {', '.join(repeated_ids)}")

    return {
        "schema": VALIDATION_SCHEMA,
        "status": "PASS" if not errors else "FAIL",
        "registry_path": str(registry_path),
        "module_count": len(raw_modules),
        "valid_module_count": sum(report["status"] == "PASS" for report in reports),
        "modules": reports,
        "errors": errors,
        "authority_boundary": _authority_boundary(),
        "boundary": BOUNDARY,
    }


def _authority_boundary() -> dict[str, str]:
    return {field: NO_AUTHORITY for field in AUTHORITY_FIELDS}


def _canonical_uuid(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        return str(uuid.UUID(value.strip()))
    except (ValueError, AttributeError):
        return None


def _walk_identity_fields(
    value: Any,
    *,
    source: str,
    found: dict[str, set[str]],
    malformed: list[dict[str, str]],
    path: str = "$",
    depth: int = 0,
) -> None:
    if depth > 20:
        return
    if isinstance(value, dict):
        for key, child in value.items():
            child_path = f"{path}.{key}"
            if str(key) in IDENTITY_KEYS:
                if child in (None, ""):
                    continue
                canonical = _canonical_uuid(child)
                if canonical is None:
                    malformed.append({"source": source, "field": child_path, "value": str(child)[:160]})
                else:
                    found.setdefault(canonical, set()).add(f"{source}:{child_path}")
            else:
                _walk_identity_fields(
                    child,
                    source=source,
                    found=found,
                    malformed=malformed,
                    path=child_path,
                    depth=depth + 1,
                )
    elif isinstance(value, list):
        for index, child in enumerate(value[:1000]):
            _walk_identity_fields(
                child,
                source=source,
                found=found,
                malformed=malformed,
                path=f"{path}[{index}]",
                depth=depth + 1,
            )


def resolve_run_identity(run_folder: Path) -> dict[str, Any]:
    """Resolve one UUID conservatively from the folder and bounded JSON evidence."""
    folder = Path(run_folder).expanduser().resolve(strict=False)
    found: dict[str, set[str]] = {}
    malformed: list[dict[str, str]] = []
    unreadable: list[dict[str, str]] = []
    if not folder.is_dir():
        return {
            "schema": RUN_IDENTITY_SCHEMA,
            "status": "MISSING_FOLDER",
            "run_folder": str(folder),
            "run_uuid": None,
            "candidates": [],
            "malformed_fields": [],
            "unreadable_identity_files": [],
            "warnings": [],
        }

    folder_uuid = _canonical_uuid(folder.name)
    if folder_uuid:
        found.setdefault(folder_uuid, set()).add("run-folder-name")

    json_paths = sorted(
        (path for path in folder.rglob("*.json") if path.is_file()),
        key=lambda path: path.relative_to(folder).as_posix().casefold(),
    )
    warnings: list[str] = []
    if len(json_paths) > MAX_IDENTITY_JSON_FILES:
        warnings.append(
            f"Only the first {MAX_IDENTITY_JSON_FILES} JSON files were inspected for run identity."
        )
        json_paths = json_paths[:MAX_IDENTITY_JSON_FILES]
    for path in json_paths:
        try:
            relative = path.relative_to(folder).as_posix()
            resolved = path.resolve(strict=True)
            resolved.relative_to(folder)
            if path.is_symlink():
                warnings.append(f"Skipped symlink while resolving run identity: {relative}")
                continue
            size = path.stat().st_size
            if size > MAX_IDENTITY_JSON_BYTES:
                warnings.append(f"Skipped oversized JSON while resolving run identity: {relative}")
                continue
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as exc:
            relative = path.name
            try:
                relative = path.relative_to(folder).as_posix()
            except ValueError:
                pass
            if any(hint in path.name.casefold() for hint in IDENTITY_FILE_HINTS):
                unreadable.append(
                    {"source": relative, "error": f"{type(exc).__name__}: {exc}"[:300]}
                )
            else:
                warnings.append(f"Ignored unreadable non-identity JSON: {relative}")
            continue
        _walk_identity_fields(
            payload,
            source=relative,
            found=found,
            malformed=malformed,
        )

    candidates = [
        {"run_uuid": value, "sources": sorted(sources)}
        for value, sources in sorted(found.items())
    ]
    if malformed or unreadable:
        status = "MALFORMED"
        selected: str | None = None
    elif len(candidates) > 1:
        status = "AMBIGUOUS"
        selected = None
    elif len(candidates) == 1:
        status = "RESOLVED"
        selected = candidates[0]["run_uuid"]
    else:
        status = "MISSING"
        selected = None
    return {
        "schema": RUN_IDENTITY_SCHEMA,
        "status": status,
        "run_folder": str(folder),
        "run_uuid": selected,
        "candidates": candidates,
        "malformed_fields": malformed,
        "unreadable_identity_files": unreadable,
        "warnings": warnings,
    }


def _glob_files(folder: Path, patterns: Sequence[str]) -> list[Path]:
    found: dict[str, Path] = {}
    root = folder.resolve(strict=True)
    for pattern in patterns:
        for path in root.glob(pattern):
            try:
                if path.is_symlink() or not path.is_file():
                    continue
                resolved = path.resolve(strict=True)
                resolved.relative_to(root)
            except (OSError, ValueError):
                continue
            found[str(resolved).casefold()] = resolved
    return sorted(found.values(), key=lambda path: path.relative_to(root).as_posix().casefold())


def _artifact_group_report(folder: Path, group: Mapping[str, Any]) -> dict[str, Any]:
    patterns = [str(value) for value in group.get("patterns", [])]
    matches = _glob_files(folder, patterns)
    match_policy = str(group.get("match"))
    if not matches:
        status = "MISSING"
    elif match_policy == "EXACTLY_ONE" and len(matches) != 1:
        status = "AMBIGUOUS"
    else:
        status = "RESOLVED"
    return {
        "group_id": group.get("group_id"),
        "match_policy": match_policy,
        "status": status,
        "match_count": len(matches),
        "matches": [str(path) for path in matches],
    }


def preflight_module(
    descriptor: Mapping[str, Any],
    static_report: Mapping[str, Any],
    *,
    run_folder: Path,
    run_identity: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Check declared inputs without constructing or running a command."""
    folder = Path(run_folder).expanduser().resolve(strict=False)
    errors: list[str] = []
    warnings: list[str] = []
    groups: list[dict[str, Any]] = []
    identity = dict(run_identity or resolve_run_identity(folder))
    if static_report.get("status") != "PASS":
        errors.append("The packaged descriptor failed static validation.")
    if descriptor.get("execution_eligible") is not True:
        errors.append(
            "This is a reference-only catalog entry; its interface is not eligible for generic execution."
        )
    if not folder.is_dir():
        errors.append("The selected run folder does not exist or is not a directory.")
    else:
        for group in descriptor.get("preflight", {}).get("required_artifact_groups", []):
            if isinstance(group, dict):
                groups.append(_artifact_group_report(folder, group))
    identity_required = descriptor.get("preflight", {}).get("run_identity_required") is True
    if identity_required:
        if identity.get("status") in {"AMBIGUOUS", "MALFORMED", "MISSING_FOLDER"}:
            errors.append(f"Run identity is {identity.get('status')}; no module may be bound to it.")
        elif identity.get("status") == "MISSING":
            warnings.append("No run UUID was found; the descriptor requires a run-bound identity.")
    elif identity.get("status") != "RESOLVED":
        warnings.append(
            "A single run UUID is not required by this descriptor; identity findings are informational."
        )
    warnings.extend(str(value) for value in identity.get("warnings", []))
    ambiguous_groups = [str(group.get("group_id")) for group in groups if group.get("status") == "AMBIGUOUS"]
    missing_groups = [str(group.get("group_id")) for group in groups if group.get("status") == "MISSING"]
    if ambiguous_groups:
        errors.append("Required artifact groups are ambiguous: " + ", ".join(ambiguous_groups))
    if missing_groups:
        warnings.append("Required artifact groups are missing: " + ", ".join(missing_groups))

    optional_patterns = descriptor.get("preflight", {}).get("optional_artifact_patterns", [])
    optional_matches = _glob_files(folder, optional_patterns) if folder.is_dir() else []
    if errors:
        status = "INELIGIBLE"
    elif (identity_required and identity.get("status") != "RESOLVED") or missing_groups:
        status = "INCOMPLETE"
    else:
        status = "READY_FOR_OPERATOR_REVIEW"
    return {
        "schema": PREFLIGHT_SCHEMA,
        "status": status,
        "module_id": descriptor.get("module_id"),
        "display_name": descriptor.get("display_name"),
        "execution_eligible": descriptor.get("execution_eligible") is True,
        "contract_status": descriptor.get("launch", {}).get("contract_status"),
        "run_folder": str(folder),
        "run_identity": identity,
        "required_artifact_groups": groups,
        "optional_artifact_matches": [str(path) for path in optional_matches],
        "errors": errors,
        "warnings": warnings,
        "authority_boundary": _authority_boundary(),
        "boundary": BOUNDARY,
    }


def preflight_catalog(
    registry_path: Path,
    run_folder: Path,
    *,
    module_id: str | None = None,
    root: Path = PACKAGE_ROOT,
) -> dict[str, Any]:
    validation = validate_registry(registry_path, root=root)
    identity = resolve_run_identity(run_folder)
    selected = [
        report
        for report in validation["modules"]
        if module_id is None or report.get("module_id") == module_id
    ]
    errors = list(validation["errors"])
    if module_id is not None and not selected:
        errors.append(f"No registered module has module_id {module_id!r}")
    reports = [
        preflight_module(
            report["descriptor"],
            report,
            run_folder=run_folder,
            run_identity=identity,
        )
        for report in selected
        if isinstance(report.get("descriptor"), dict)
    ]
    statuses = {report["status"] for report in reports}
    if errors or not reports or "INELIGIBLE" in statuses:
        status = "INELIGIBLE"
    elif "INCOMPLETE" in statuses:
        status = "INCOMPLETE"
    else:
        status = "READY_FOR_OPERATOR_REVIEW"
    return {
        "schema": "PRAYCG_AnalysisModuleCatalogPreflight_v0_1",
        "status": status,
        "registry_validation_status": validation["status"],
        "run_folder": str(Path(run_folder).expanduser().resolve(strict=False)),
        "run_identity": identity,
        "module_count": len(reports),
        "modules": reports,
        "errors": errors,
        "authority_boundary": _authority_boundary(),
        "boundary": BOUNDARY,
    }


def _summary_text(report: Mapping[str, Any]) -> str:
    lines = [
        f"Status: {report.get('status')}",
        "",
        BOUNDARY,
        "",
    ]
    if report.get("module_id"):
        lines.extend(
            [
                f"Module: {report.get('display_name') or report.get('module_id')}",
                f"Module ID: {report.get('module_id')}",
                "",
            ]
        )
    identity = report.get("run_identity")
    if isinstance(identity, dict):
        lines.extend(
            [
                f"Run identity: {identity.get('status')}",
                f"Run UUID: {identity.get('run_uuid') or '(not resolved)'}",
                "",
            ]
        )
    for group in report.get("required_artifact_groups", []):
        lines.append(
            f"{group.get('group_id')}: {group.get('status')} ({group.get('match_count')} match(es))"
        )
        for value in group.get("matches", []):
            lines.append(f"  {value}")
    if report.get("errors"):
        lines.extend(["", "Errors:"])
        lines.extend(f"- {message}" for message in report["errors"])
    if report.get("warnings"):
        lines.extend(["", "Cautions:"])
        lines.extend(f"- {message}" for message in report["warnings"])
    return "\n".join(lines)


def launch_gui(
    registry_path: Path = DEFAULT_REGISTRY,
    run_folder: Path | None = None,
    *,
    module_id: str | None = None,
) -> int:
    """Open the operator catalog. No control in this UI launches a module."""
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    validation = validate_registry(registry_path)
    descriptors = [
        report
        for report in validation["modules"]
        if isinstance(report.get("descriptor"), dict)
    ]
    window = tk.Tk()
    window.title("PRAYCG Analysis Module Catalog v0.1 — governed discovery")
    window.geometry("1120x720")

    banner = ttk.Label(
        window,
        text=(
            "DISCOVERY / PREFLIGHT ONLY — this catalog cannot launch analysis, grant primary-endpoint "
            "status, change Master Suite eligibility, or advance workflow gates."
        ),
        foreground="#8b1a1a",
        wraplength=1060,
    )
    banner.pack(fill="x", padx=10, pady=(10, 5))

    chooser = ttk.Frame(window)
    chooser.pack(fill="x", padx=10, pady=5)
    ttk.Label(chooser, text="Run folder:").pack(side="left")
    run_var = tk.StringVar(value=str(Path(run_folder).expanduser()) if run_folder else "")
    run_entry = ttk.Entry(chooser, textvariable=run_var)
    run_entry.pack(side="left", fill="x", expand=True, padx=6)

    body = ttk.Panedwindow(window, orient="horizontal")
    body.pack(fill="both", expand=True, padx=10, pady=5)
    left = ttk.Frame(body)
    right = ttk.Frame(body)
    body.add(left, weight=1)
    body.add(right, weight=3)
    tree = ttk.Treeview(left, columns=("static", "eligible"), show="tree headings", selectmode="browse")
    tree.heading("#0", text="Module")
    tree.heading("static", text="Static")
    tree.heading("eligible", text="Catalog contract")
    tree.column("#0", width=235)
    tree.column("static", width=70, anchor="center")
    tree.column("eligible", width=95, anchor="center")
    tree.pack(fill="both", expand=True)
    detail = tk.Text(right, wrap="word")
    detail.pack(fill="both", expand=True)

    rows: dict[str, dict[str, Any]] = {}
    for report in descriptors:
        descriptor = report["descriptor"]
        item = tree.insert(
            "",
            "end",
            iid=str(descriptor["module_id"]),
            text=str(descriptor["display_name"]),
            values=(
                report["status"],
                "NORMALIZED" if descriptor.get("execution_eligible") else "REFERENCE",
            ),
        )
        rows[item] = report

    def show_static(_event: Any = None) -> None:
        selection = tree.selection()
        if not selection:
            return
        report = rows[selection[0]]
        descriptor = report["descriptor"]
        text = {
            "status": report["status"],
            "module_id": descriptor.get("module_id"),
            "display_name": descriptor.get("display_name"),
            "classification": descriptor.get("classification"),
            "entry_point": descriptor.get("entry_point"),
            "execution_eligible": descriptor.get("execution_eligible"),
            "launch_contract": descriptor.get("launch"),
            "static_errors": report.get("errors", []),
            "claims_boundary": descriptor.get("claims_boundary"),
            "authority_boundary": _authority_boundary(),
            "boundary": BOUNDARY,
        }
        detail.delete("1.0", "end")
        detail.insert("end", json.dumps(text, indent=2))

    def browse() -> None:
        selected = filedialog.askdirectory(title="Select a PRAYCG run folder")
        if selected:
            run_var.set(selected)

    def preflight_selected() -> None:
        selection = tree.selection()
        if not selection:
            messagebox.showinfo("Select a module", "Select one registered module to preflight.")
            return
        raw_folder = run_var.get().strip()
        if not raw_folder:
            messagebox.showinfo("Select a run", "Choose a run folder before preflight.")
            return
        report = preflight_catalog(
            Path(registry_path),
            Path(raw_folder),
            module_id=selection[0],
        )
        module_report = report["modules"][0] if report["modules"] else report
        detail.delete("1.0", "end")
        detail.insert("end", _summary_text(module_report))

    ttk.Button(chooser, text="Browse…", command=browse).pack(side="left", padx=3)
    ttk.Button(chooser, text="Preflight Selected", command=preflight_selected).pack(side="left", padx=3)
    ttk.Button(chooser, text="Close", command=window.destroy).pack(side="left", padx=3)
    tree.bind("<<TreeviewSelect>>", show_static)

    initial = module_id if module_id in rows else (next(iter(rows), None))
    if initial:
        tree.selection_set(initial)
        tree.focus(initial)
        show_static()
    elif validation["errors"]:
        detail.insert("end", _summary_text(validation))
    window.mainloop()
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PRAYCG governed analysis-module catalog v0.1")
    output_mode = parser.add_mutually_exclusive_group()
    output_mode.add_argument("--gui", action="store_true", help="Open the catalog UI (also the default).")
    output_mode.add_argument("--json", action="store_true", help="Print machine-readable discovery or preflight output.")
    parser.add_argument("--run-folder", type=Path, help="Optional run folder to prefill or preflight.")
    parser.add_argument("--module-id", help="Limit preflight or initial GUI selection to one registered module ID.")
    parser.add_argument("--registry", type=Path, default=DEFAULT_REGISTRY)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.json:
        if args.run_folder:
            report = preflight_catalog(
                args.registry,
                args.run_folder,
                module_id=args.module_id,
            )
            print(json.dumps(report, indent=2))
            if report["status"] == "READY_FOR_OPERATOR_REVIEW":
                return 0
            return 3 if report["status"] == "INCOMPLETE" else 2
        report = validate_registry(args.registry)
        print(json.dumps(report, indent=2))
        return 0 if report["status"] == "PASS" else 2
    try:
        return launch_gui(args.registry, args.run_folder, module_id=args.module_id)
    except Exception as exc:
        print(f"Analysis Module Catalog UI could not start: {type(exc).__name__}: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
