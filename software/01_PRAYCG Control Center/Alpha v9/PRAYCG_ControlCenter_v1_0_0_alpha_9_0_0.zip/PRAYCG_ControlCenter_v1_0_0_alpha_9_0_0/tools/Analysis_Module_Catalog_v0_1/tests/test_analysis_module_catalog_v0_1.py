from __future__ import annotations

import copy
import io
import json
import sys
import tempfile
import unittest
import uuid
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock


TOOL_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(TOOL_ROOT))

import praycg_analysis_module_catalog_v0_1 as catalog  # noqa: E402


REGISTRY = PACKAGE_ROOT / "config" / "analysis_module_registry_v0_1.json"


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


class AnalysisModuleCatalogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.registry = json.loads(REGISTRY.read_text(encoding="utf-8"))

    def test_packaged_registry_and_descriptors_pass(self) -> None:
        report = catalog.validate_registry(REGISTRY)
        self.assertEqual(report["status"], "PASS", report["errors"])
        self.assertEqual(report["module_count"], 10)
        self.assertEqual(report["valid_module_count"], 10)
        self.assertTrue(all(module["status"] == "PASS" for module in report["modules"]))

    def test_broader_packaged_analysis_estate_is_discoverable_but_reference_only(self) -> None:
        modules = {module["module_id"]: module for module in self.registry["modules"]}
        reference_ids = {
            "master_comprehensive_suite_v1_6_0",
            "full_chained_analysis_v1_6_1",
            "hocr_shotorder_v1_6_0",
            "confound_expansion_v1_5_7",
            "master_sync_visualizer_v1_4_0",
            "offline_master_interpreter_v1_6_0",
            "cue_locked_gamma_forensics_v0_1",
        }
        self.assertTrue(reference_ids.issubset(modules))
        for module_id in reference_ids:
            descriptor = modules[module_id]
            self.assertFalse(descriptor["execution_eligible"])
            self.assertEqual(
                descriptor["launch"]["contract_status"],
                catalog.REFERENCE_ONLY_CONTRACT,
            )
            self.assertTrue(all(descriptor[field] == "NONE" for field in catalog.AUTHORITY_FIELDS))

    def test_reference_only_contract_cannot_be_flipped_to_generic_execution(self) -> None:
        value = copy.deepcopy(self.registry)
        descriptor = next(
            module
            for module in value["modules"]
            if module["module_id"] == "master_comprehensive_suite_v1_6_0"
        )
        descriptor["execution_eligible"] = True
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "registry.json"
            write_json(path, value)
            report = catalog.validate_registry(path)
        self.assertEqual(report["status"], "FAIL")
        self.assertIn(
            "normalized GUI/run-folder contract",
            "\n".join(report["errors"]),
        )

    def test_registry_and_modules_cannot_grant_scientific_or_runtime_authority(self) -> None:
        report = catalog.validate_registry(REGISTRY)
        for field in catalog.AUTHORITY_FIELDS:
            self.assertEqual(self.registry[field], "NONE")
            self.assertEqual(report["authority_boundary"][field], "NONE")
            for module in self.registry["modules"]:
                self.assertEqual(module[field], "NONE")

    def test_authority_path_and_duplicate_mutations_fail_closed(self) -> None:
        value = copy.deepcopy(self.registry)
        value["primary_endpoint_authority"] = "PRIMARY"
        value["modules"][0]["master_suite_eligibility_effect"] = "ELIGIBLE"
        value["modules"][0]["entry_point"] = "../../outside.py"
        value["modules"].append(copy.deepcopy(value["modules"][1]))
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "registry.json"
            write_json(path, value)
            report = catalog.validate_registry(path)
        combined = "\n".join(report["errors"])
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("primary_endpoint_authority must be NONE", combined)
        self.assertIn("master_suite_eligibility_effect must be NONE", combined)
        self.assertIn("traversal", combined)
        self.assertIn("repeats module IDs", combined)

    def test_run_identity_must_resolve_to_exactly_one_full_uuid(self) -> None:
        first = "85ea9a0e-a8c6-447e-b97f-c6d56857a047"
        second = "21dd8544-f523-4485-9d24-19c7222bcb2a"
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / "run"
            run.mkdir()
            write_json(run / "run_state.json", {"run_uuid": first})
            resolved = catalog.resolve_run_identity(run)
            self.assertEqual(resolved["status"], "RESOLVED")
            self.assertEqual(resolved["run_uuid"], first)
            write_json(run / "session_state.json", {"session_id": second})
            ambiguous = catalog.resolve_run_identity(run)
            self.assertEqual(ambiguous["status"], "AMBIGUOUS")
            self.assertIsNone(ambiguous["run_uuid"])

    def test_malformed_identity_artifact_is_ineligible(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / "run"
            run.mkdir()
            (run / "run_manifest.json").write_text("{broken", encoding="utf-8")
            identity = catalog.resolve_run_identity(run)
            self.assertEqual(identity["status"], "MALFORMED")
            report = catalog.preflight_catalog(
                REGISTRY,
                run,
                module_id="micro_handoff_v0_1",
            )
        self.assertEqual(report["status"], "INELIGIBLE")

    def test_synthetic_declared_inputs_reach_operator_review_only(self) -> None:
        run_uuid = "2b6ef9fa-32a7-4804-866f-e73f54638bc7"
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / "run"
            (run / "derived").mkdir(parents=True)
            write_json(run / "run_identity.json", {"run_uuid": run_uuid})
            (run / "derived" / "cardiac_beats.csv").write_text("time,ibi\n0,0.8\n", encoding="utf-8")
            (run / "derived" / "respiration.csv").write_text("time,value\n0,1\n", encoding="utf-8")
            report = catalog.preflight_catalog(
                REGISTRY,
                run,
                module_id="continuous_autonomic_resp_dual_path_v1_0",
            )
        self.assertEqual(report["status"], "READY_FOR_OPERATOR_REVIEW", report["errors"])
        self.assertEqual(report["run_identity"]["run_uuid"], run_uuid)
        self.assertTrue(all(value == "NONE" for value in report["authority_boundary"].values()))

    def test_exactly_one_policy_refuses_ambiguous_artifacts(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / str(uuid.uuid4())
            run.mkdir()
            (run / "first.xdf").write_bytes(b"one")
            (run / "second.xdf").write_bytes(b"two")
            (run / "task_events.json").write_text("{}", encoding="utf-8")
            report = catalog.preflight_catalog(
                REGISTRY,
                run,
                module_id="cai_sid_exploratory_v0_2",
            )
        self.assertEqual(report["status"], "INELIGIBLE")
        group = next(
            item
            for item in report["modules"][0]["required_artifact_groups"]
            if item["group_id"] == "xdf_recording"
        )
        self.assertEqual(group["status"], "AMBIGUOUS")
        self.assertEqual(group["match_count"], 2)

    def test_default_and_explicit_gui_accept_optional_run_folder(self) -> None:
        with mock.patch.object(catalog, "launch_gui", return_value=0) as launch:
            self.assertEqual(catalog.main([]), 0)
            launch.assert_called_once_with(catalog.DEFAULT_REGISTRY, None, module_id=None)
        run = Path("selected-run")
        with mock.patch.object(catalog, "launch_gui", return_value=0) as launch:
            self.assertEqual(catalog.main(["--gui", "--run-folder", str(run)]), 0)
            launch.assert_called_once_with(catalog.DEFAULT_REGISTRY, run, module_id=None)

    def test_json_discovery_does_not_start_gui(self) -> None:
        output = io.StringIO()
        with mock.patch.object(catalog, "launch_gui") as launch, redirect_stdout(output):
            code = catalog.main(["--json"])
        self.assertEqual(code, 0)
        launch.assert_not_called()
        self.assertEqual(json.loads(output.getvalue())["status"], "PASS")

    def test_catalog_contains_no_module_execution_mechanism(self) -> None:
        source = (TOOL_ROOT / "praycg_analysis_module_catalog_v0_1.py").read_text(encoding="utf-8")
        for forbidden in ("importlib", "runpy", "subprocess", "os.system", "eval(", "exec("):
            self.assertNotIn(forbidden, source)
        self.assertNotIn("Launch Selected", source)


if __name__ == "__main__":
    unittest.main()
