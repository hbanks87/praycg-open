#!/usr/bin/env python3
"""Run simple no-argument ``test_*`` functions without requiring pytest.

This intentionally small runner supports the assertion-style Micro Handoff tests
bundled with the alpha release. It does not claim pytest fixture,
parameterization, plugin, or collection compatibility.
"""
from __future__ import annotations

import argparse
import importlib.util
import inspect
import json
import sys
import traceback
from pathlib import Path


def run_test_file(test_file: Path) -> dict[str, object]:
    test_file = test_file.resolve()
    result: dict[str, object] = {
        "schema": "PRAYCG_PlainFunctionTestResult_v1",
        "runner": "plain_no_argument_test_functions",
        "test_file": test_file.name,
        "scope_boundary": (
            "Executes module-owned, no-argument functions named test_*. "
            "Pytest fixtures, parameterization, hooks, and plugins are unsupported."
        ),
        "tests": [],
    }
    if not test_file.is_file():
        result.update({"status": "FAIL", "error": "test file does not exist", "total": 0, "passed": 0, "failed": 0})
        return result

    module_name = f"_praycg_plain_tests_{test_file.stem}"
    try:
        spec = importlib.util.spec_from_file_location(module_name, test_file)
        if spec is None or spec.loader is None:
            raise ImportError("could not create an import specification")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
    except Exception:
        result.update(
            {
                "status": "FAIL",
                "error": "test module could not be imported",
                "traceback": traceback.format_exc(),
                "total": 0,
                "passed": 0,
                "failed": 1,
            }
        )
        return result

    discovered = [
        (name, value)
        for name, value in vars(module).items()
        if name.startswith("test_")
        and inspect.isfunction(value)
        and value.__module__ == module.__name__
    ]
    discovered.sort(key=lambda item: item[0])
    if not discovered:
        result.update({"status": "FAIL", "error": "no compatible test functions were discovered", "total": 0, "passed": 0, "failed": 1})
        return result

    rows: list[dict[str, str]] = []
    for name, test_function in discovered:
        parameters = inspect.signature(test_function).parameters
        if parameters:
            rows.append(
                {
                    "name": name,
                    "status": "FAIL",
                    "error": "test requires arguments; this runner does not supply fixtures",
                }
            )
            continue
        try:
            test_function()
        except Exception:
            rows.append(
                {
                    "name": name,
                    "status": "FAIL",
                    "traceback": traceback.format_exc(),
                }
            )
        else:
            rows.append({"name": name, "status": "PASS"})

    passed = sum(row["status"] == "PASS" for row in rows)
    failed = len(rows) - passed
    result.update(
        {
            "status": "PASS" if failed == 0 else "FAIL",
            "tests": rows,
            "total": len(rows),
            "passed": passed,
            "failed": failed,
        }
    )
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run simple PRAYCG assertion-style tests")
    parser.add_argument("test_file", type=Path)
    args = parser.parse_args()
    result = run_test_file(args.test_file)
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
