#!/usr/bin/env python3
"""Capture a privacy-minimized, machine-resolved Python environment record."""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path


SCHEMA = "PRAYCG_ResolvedEnvironment_v0_1"
VERSION = "0.1"


def default_output() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA", Path.cwd())) / "PRAYCG" / "environment_locks"
    return base / "environment_resolved_v1_0_0_alpha_4.json"


def capture() -> dict:
    packages = sorted(
        (
            {
                "name": distribution.metadata.get("Name") or distribution.name or "UNKNOWN_DISTRIBUTION",
                "version": distribution.version or "UNKNOWN_VERSION",
            }
            for distribution in importlib.metadata.distributions()
        ),
        key=lambda item: item["name"].casefold(),
    )
    return {
        "schema": SCHEMA,
        "version": VERSION,
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "release": "PRAYCG_ControlCenter_v1_0_0_alpha_4",
        "python_version": platform.python_version(),
        "implementation": platform.python_implementation(),
        "operating_system": platform.system(),
        "operating_system_release": platform.release(),
        "machine": platform.machine(),
        "packages": packages,
        "privacy_note": (
            "This record intentionally omits the Python executable path, user name, host name, "
            "environment variables, credentials, and package source URLs."
        ),
        "interpretation_boundary": (
            "This is a reproducibility record for one resolved software environment; it does not "
            "establish device compatibility, successful acquisition, or scientific validity."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=default_output())
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(capture(), indent=2) + "\n", encoding="utf-8")
    print(args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
