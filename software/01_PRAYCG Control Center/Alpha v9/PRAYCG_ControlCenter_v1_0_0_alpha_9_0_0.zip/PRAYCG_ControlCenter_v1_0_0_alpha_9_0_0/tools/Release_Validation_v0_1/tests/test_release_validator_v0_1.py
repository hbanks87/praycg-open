from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock


VALIDATOR_DIR = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = VALIDATOR_DIR.parents[1]


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


validator = load_module(
    "praycg_release_validator_under_test",
    VALIDATOR_DIR / "praycg_release_validator_v0_1.py",
)
plain_runner = load_module(
    "praycg_plain_function_runner_under_test",
    VALIDATOR_DIR / "praycg_plain_function_test_runner_v0_1.py",
)


def write_frozen_demo_pack(
    package_root: Path,
    *,
    status: str = "DEMO_ONLY",
    license_id: str = "CC0-1.0",
    include_raw_recording: bool = False,
) -> Path:
    pack_root = (
        package_root
        / "examples"
        / "no_copyright_media_demo"
        / "stimulus_library"
        / "packs"
        / "SYNTHETIC_PUBLIC_SCAN_TEST"
    )
    media_path = pack_root / "media" / "sample.wav"
    media_path.parent.mkdir(parents=True)
    media_path.write_bytes(b"synthetic ledger-bound media bytes")
    files = [media_path]
    if include_raw_recording:
        raw_path = pack_root / "media" / "sample.xdf"
        raw_path.write_bytes(b"synthetic raw recording bytes")
        files.append(raw_path)

    ledger = []
    for path in files:
        data = path.read_bytes()
        ledger.append({
            "path": path.relative_to(pack_root).as_posix(),
            "sha256": hashlib.sha256(data).hexdigest(),
            "byte_count": len(data),
            "mime_type": "audio/wav" if path.suffix == ".wav" else "application/octet-stream",
        })
    manifest = {
        "schema": "PRAYCG_StimulusPack_v1_0",
        "pack_id": "SYNTHETIC_PUBLIC_SCAN_TEST",
        "pack_version": "1.0.0-test",
        "display_name": "Synthetic public scan test pack",
        "scientific_status": status,
        "status_boundary": "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION",
        "distribution": {
            "bundled": True,
            "license_id": license_id,
            "source_material_bundled": False,
            "redistribution_reviewed": True,
        },
        "generator": {
            "engine_id": "test_fixture",
            "engine_version": "1.0",
            "seed": 1,
            "deterministic_claim": True,
        },
        "compatibility": [{
            "protocol_id": "SYNTHETIC_TEST",
            "protocol_version": "1.0",
            "bindings": {"stimulus": "media/sample.wav"},
        }],
        "asset_roles": [{
            "asset_id": "stimulus",
            "role": "synthetic_test_audio",
            "path": "media/sample.wav",
            "media_type": "audio",
            "parent_asset_id": None,
            "derivation": "synthetic test bytes",
            "scientific_use": "FLOW_TEST_ONLY",
        }],
        "file_ledger": ledger,
        "claims_boundary": [
            "This synthetic fixture tests public-package scanner policy only."
        ],
    }
    if status == "PILOT_CANDIDATE":
        manifest["review"] = {
            "reviewer": "Synthetic Test Reviewer",
            "reviewed_utc": "2026-09-14T00:00:00Z",
            "scope": "Public scanner unit-test fixture only",
        }
    payload = json.dumps(
        manifest,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    manifest["manifest_content_sha256"] = hashlib.sha256(payload).hexdigest()
    (pack_root / "stimulus_pack_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return pack_root


class ReleaseValidatorHygieneTests(unittest.TestCase):
    def test_protocol_inventory_ignores_scratch_json_manifests(self):
        with tempfile.TemporaryDirectory() as td:
            package = Path(td)
            atlas = package / validator.ATLAS_ROOT / "protocols"
            native = package / validator.NATIVE_PROTOCOL_ROOT / "protocols"
            atlas.mkdir(parents=True)
            native.mkdir(parents=True)
            atlas_payload = {
                "protocol_id": "ATLAS_REAL",
                "protocol_version": "1.0",
                "display_name": "Atlas Real",
                "runner_entry": "runner.py",
                "engine_entry": "engine.py",
                "adaptation_status": {},
                "hardware_stack_effect": "NONE",
            }
            native_payload = {
                "protocol_id": "NATIVE_REAL",
                "protocol_version": "1.0",
                "display_name": "Native Real",
                "runner_entry": "runner.py",
            }
            (atlas / "atlas_real.json").write_text(json.dumps(atlas_payload), encoding="utf-8")
            (atlas / "_temporary_test_manifest.json").write_text(
                json.dumps({**atlas_payload, "protocol_id": "TEST_REST"}), encoding="utf-8"
            )
            (native / "native_real.json").write_text(json.dumps(native_payload), encoding="utf-8")
            (native / ".editor_scratch.json").write_text(
                json.dumps({**native_payload, "protocol_id": "NATIVE_SCRATCH"}), encoding="utf-8"
            )

            inventory = validator._protocol_inventory(package)

            self.assertEqual(inventory["atlas_protocol_count"], 1)
            self.assertEqual(inventory["native_protocol_count"], 1)
            self.assertEqual(inventory["total_runnable_protocol_count"], 2)

    def test_declared_suite_manifest_names_every_supported_surface(self):
        suites = validator.declared_test_suites(PACKAGE_ROOT)
        self.assertEqual(
            [suite["id"] for suite in suites],
            [
                "release_validator_hygiene",
                "control_center_regression",
                "protocol_stimulus_flow_alpha8",
                "control_center_alpha8_layout_integration",
                "hardware_launch_click_gate_alpha8",
                "study_workspace",
                "analysis_orchestrator",
                "results_bundle_builder",
                "control_center_alpha8_workspace_integration",
                "alpha900_hardware_forge_stream_contracts",
                "control_center_alpha900_integration",
                "protocol_ai_docs_builder",
                "protocol_atlas_pytest",
                "protocol_atlas_individualized_runner_dry_runs",
                "master_comprehensive_suite_regression",
                "micro_handoff_assertion_tests",
                "cue_locked_gamma_forensics_synthetic_self_test",
                "stimulus_forge_library",
                "hardware_forge_catalog",
                "hardware_selection_profile_workflow",
                "generic_eda_ppg_bridge",
                "analysis_module_catalog",
            ],
        )
        by_id = {suite["id"]: suite for suite in suites}
        self.assertEqual(by_id["stimulus_forge_library"]["runner"], "pytest")
        self.assertTrue(by_id["control_center_regression"]["shard_by_file"])
        self.assertEqual(
            set(by_id["control_center_regression"]["exclude_files"]),
            {
                "test_control_center_alpha8_layout_integration.py",
                "test_hardware_launch_click_gate_alpha8.py",
                "test_protocol_stimulus_flow_alpha8.py",
                "test_control_center_alpha8_integration.py",
                "test_alpha900_hardware_forge_stream_contracts.py",
                "test_control_center_alpha900_integration.py",
            },
        )
        self.assertNotIn(
            "test_bench_test_mode_alpha82.py",
            by_id["control_center_regression"]["exclude_files"],
        )

    def test_staged_test_evidence_is_bound_to_exact_package_contents(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            package = Path(temporary_directory)
            source = package / "module.py"
            source.write_text("VALUE = 1\n", encoding="utf-8")
            suites = validator.declared_test_suites(package)
            fingerprint = validator.package_test_fingerprint(package)
            evidence = {
                "schema": validator.TEST_EVIDENCE_SCHEMA,
                "package": validator.RELEASE_PACKAGE,
                "version": validator.RELEASE_VERSION,
                "generated_utc": "2026-09-14T00:00:00Z",
                "status": "PASS",
                "python_version": "3.11.9",
                "python_implementation": "CPython",
                "supported_python_target": "3.11",
                "supported_python_target_exercised": True,
                "package_fingerprint_before": fingerprint,
                "package_fingerprint_after": fingerprint,
                "package_stable_during_tests": True,
                "cleanup_status": "PASS",
                "automated_tests": {
                    "status": "PASS",
                    "declared_suite_count": len(suites),
                    "executed_suite_count": len(suites),
                    "reported_test_count": len(suites),
                    "all_declared_suites_executed": True,
                    "suites": [{"id": row["id"], "status": "PASS"} for row in suites],
                },
            }
            evidence_path = package / "evidence.json"
            evidence_path.write_text(json.dumps(evidence), encoding="utf-8")
            source.write_text("VALUE = 2\n", encoding="utf-8")

            with mock.patch.object(validator.sys, "version_info", (3, 11, 9)):
                with self.assertRaisesRegex(ValueError, "fingerprint"):
                    validator.load_automated_test_evidence(package, evidence_path)

    def test_sharded_unittest_aggregates_every_file_deterministically(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            tests = root / "tests"
            tests.mkdir()
            (tests / "test_b.py").write_text(
                "import unittest\nclass B(unittest.TestCase):\n    def test_b(self): self.assertTrue(True)\n",
                encoding="utf-8",
            )
            (tests / "test_a.py").write_text(
                "import unittest\nclass A(unittest.TestCase):\n    def test_a(self): self.assertEqual(2 + 2, 4)\n",
                encoding="utf-8",
            )
            suite = {
                "id": "synthetic_sharded_suite",
                "runner": "unittest_discovery",
                "path": tests,
                "pattern": "test_*.py",
                "shard_by_file": True,
            }

            result = validator.run_declared_test_suite(suite, root)

            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["reported_test_count"], 2)
            self.assertEqual([row["file"] for row in result["shards"]], ["test_a.py", "test_b.py"])

    def test_zero_collected_tests_are_an_explicit_release_failure(self):
        suite = {
            "id": "synthetic_empty_suite",
            "runner": "unittest_discovery",
            "path": PACKAGE_ROOT / "synthetic_empty_suite",
        }
        completed = types.SimpleNamespace(
            returncode=0,
            stdout="",
            stderr="Ran 0 tests in 0.000s\n\nOK\n",
        )
        with mock.patch.object(validator.subprocess, "run", return_value=completed):
            result = validator._run_command(
                suite,
                ["python", "-m", "unittest"],
                package=PACKAGE_ROOT,
            )

        self.assertEqual(result["reported_test_count"], 0)
        self.assertEqual(result["status"], "FAIL_ZERO_TESTS")

    def test_protocol_atlas_smoke_count_is_read_before_output_excerpt_is_truncated(self):
        suite = {
            "id": "synthetic_atlas_smoke",
            "runner": "protocol_atlas_smoke",
            "path": PACKAGE_ROOT / "synthetic_smoke.py",
        }
        completed = types.SimpleNamespace(
            returncode=0,
            stdout='{"wrapper_dry_run_count": 40, "padding": "' + ("x" * 13000) + '"}',
            stderr="",
        )
        with mock.patch.object(validator.subprocess, "run", return_value=completed):
            result = validator._run_command(
                suite,
                ["python", "synthetic_smoke.py"],
                package=PACKAGE_ROOT,
            )

        self.assertEqual(result["reported_test_count"], 40)
        self.assertEqual(result["status"], "PASS")

    def test_alpha9_release_profile_and_manifest_inventory(self):
        tests = validator.run_automated_tests(PACKAGE_ROOT, skip=True)
        manifest = validator.build_version_manifest(
            PACKAGE_ROOT,
            tests,
            validation_status="PENDING_TEST",
        )
        inventory = manifest["protocol_federation"]

        self.assertEqual(validator.RELEASE_VERSION, "1.0.0-alpha.9.0.0")
        self.assertEqual(validator.CHECKSUM_NAME, "SHA256SUMS_v1_0_0_alpha_9_0_0.txt")
        self.assertEqual(manifest["package"], "PRAYCG_ControlCenter_v1_0_0_alpha_9_0_0")
        self.assertEqual(
            manifest["workflow_contract"]["ai_docs_builder_authority"],
            "DOCUMENT_GENERATION_ONLY_NO_EXECUTABLE_CODE_OR_RUNTIME_AUTHORITY",
        )
        self.assertFalse(manifest["workflow_contract"]["protocol_lock_selects_or_reconfigures_hardware"])
        self.assertEqual(inventory["native_protocol_count"], 3)
        extension = PACKAGE_ROOT / "VERSION_MANIFEST_MATURE_ENDPOINT_ATLAS_v1_0.json"
        if extension.is_file():
            self.assertEqual(inventory["atlas_protocol_count"], 40)
            self.assertEqual(inventory["total_runnable_protocol_count"], 43)
            self.assertEqual(inventory["mature_endpoint_protocol_count"], 17)
        else:
            self.assertEqual(inventory["atlas_protocol_count"], 11)
            self.assertEqual(inventory["total_runnable_protocol_count"], 14)
        self.assertFalse(inventory["arbitrary_downloaded_code_allowed"])
        self.assertEqual(manifest["hardware_platform"]["adapter_count"], 11)
        self.assertEqual(manifest["hardware_platform"]["adapter_route_count"], 14)
        self.assertEqual(manifest["hardware_platform"]["runtime_authority"], "NONE")

    def test_installers_reject_an_unqualified_non_311_python(self):
        installer = (PACKAGE_ROOT / "INSTALL_PRAYCG_v1_0_0_alpha_9_0_0.bat").read_text(encoding="utf-8")
        launcher = (PACKAGE_ROOT / "run_PRAYCG_ControlCenter_v1_0_0_alpha_9_0_0.bat").read_text(encoding="utf-8")
        guard = "sys.version_info[:2] == (3, 11)"
        self.assertIn(guard, installer)
        self.assertIn(guard, launcher)

    def test_alpha9_public_entrypoint_and_template_are_consistently_wired(self):
        installer = (PACKAGE_ROOT / "INSTALL_PRAYCG_v1_0_0_alpha_9_0_0.bat").read_text(encoding="utf-8")
        launcher = (PACKAGE_ROOT / "run_PRAYCG_ControlCenter_v1_0_0_alpha_9_0_0.bat").read_text(encoding="utf-8")
        environment = (PACKAGE_ROOT / "environment.yml").read_text(encoding="utf-8")
        template_path = (
            PACKAGE_ROOT
            / "control_center"
            / "config"
            / "praycg_control_center_config_TEMPLATE_v1_0_0_alpha_9.json"
        )
        template = json.loads(template_path.read_text(encoding="utf-8"))

        self.assertIn("requirements_PRAYCG_v1_0_0_alpha_9_0_0.txt", installer)
        self.assertIn("praycg_control_center_v1_0_0_alpha_9.py", launcher)
        self.assertIn("requirements_PRAYCG_v1_0_0_alpha_9_0_0.txt", environment)
        self.assertEqual(template["version"], validator.RELEASE_VERSION)
        self.assertEqual(template["schema"], "PRAYCG_ControlCenter_Config_TEMPLATE_v1_0_alpha_9")
        self.assertTrue(
            template["tools"]["protocol_ai_doc_builder"].endswith(
                "tools/Protocol_AI_Doc_Builder_v0_1/praycg_protocol_ai_doc_builder_v0_1.py"
            )
        )

    def test_generated_test_cache_cleanup_is_narrow(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            cache = root / "component" / ".pytest_cache"
            cache.mkdir(parents=True)
            (cache / "README.md").write_text("generated", encoding="utf-8")
            preserved = root / "component" / "research_cache"
            preserved.mkdir()
            (preserved / "keep.txt").write_text("keep", encoding="utf-8")

            result = validator.remove_generated_test_caches(root)

            self.assertEqual(result["status"], "PASS")
            self.assertFalse(cache.exists())
            self.assertTrue((preserved / "keep.txt").is_file())

    def test_bytecode_cleanup_removes_files_and_empty_cache_directories(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            source = root / "module.py"
            source.write_text("VALUE = 1\n", encoding="utf-8")
            cache = root / "nested" / "__pycache__"
            cache.mkdir(parents=True)
            (cache / "module.cpython-311.pyc").write_bytes(b"synthetic bytecode")
            (cache / "module.pyo").write_bytes(b"synthetic optimized bytecode")

            result = validator.remove_python_bytecode_caches(root)

            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["removed_bytecode_file_count"], 2)
            self.assertEqual(result["removed_cache_directory_count"], 1)
            self.assertTrue(source.is_file())
            self.assertFalse(cache.exists())

    def test_skipped_tests_cannot_receive_a_pass_status(self):
        tests = validator.run_automated_tests(PACKAGE_ROOT, skip=True)
        status = validator._overall_status(
            True,
            tests,
            {"status": "PASS"},
            {"status": "PASS"},
        )
        self.assertEqual(tests["status"], "SKIPPED_BY_REQUEST")
        self.assertEqual(status, "CAUTION_WITH_DECLARED_LIMITATIONS")

    def test_unsupported_python_target_cannot_receive_a_pass_status(self):
        status = validator._overall_status(
            True,
            {"status": "PASS"},
            {"status": "PASS"},
            {"status": "PASS"},
            supported_python_target=False,
        )
        self.assertEqual(status, "CAUTION_WITH_DECLARED_LIMITATIONS")

    def test_plain_function_runner_executes_every_no_argument_test(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            test_file = Path(temporary_directory) / "test_synthetic.py"
            test_file.write_text(
                "def test_one():\n"
                "    assert 2 + 2 == 4\n\n"
                "def test_two():\n"
                "    assert 'alpha'.upper() == 'ALPHA'\n",
                encoding="utf-8",
            )
            result = plain_runner.run_test_file(test_file)

            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["total"], 2)
            self.assertEqual(result["passed"], 2)

    def test_retrospective_example_is_explicitly_synthetic_and_generic(self):
        template_dir = (
            PACKAGE_ROOT
            / "tools"
            / "MasterComprehensiveSuite_v1_6_1_CURRENT"
            / "templates"
        )
        generic = template_dir / "synthetic_manual_confound_addendum_example.json"
        payload = json.loads(generic.read_text(encoding="utf-8"))
        serialized = json.dumps(payload).lower()

        self.assertEqual(
            sorted(path.name for path in template_dir.glob("*_manual_confound_addendum_example.json")),
            [generic.name],
        )
        self.assertTrue(payload["synthetic"])
        self.assertEqual(payload["example_status"], "SYNTHETIC_DEMONSTRATION_ONLY")
        self.assertEqual(payload["run"], "SYNTHETIC_DEMO_RUN")
        self.assertNotIn("joaquin", serialized)
        self.assertNotRegex(serialized, r"\btrain\b")
        self.assertNotIn("her run", serialized)

    def test_public_scan_allows_only_strict_hash_bound_cc0_demo_media(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            pack_root = write_frozen_demo_pack(root)

            report = validator.scan_public_package(root)

            relative_media = (pack_root / "media" / "sample.wav").relative_to(root).as_posix()
            self.assertEqual(report["status"], "PASS", report)
            self.assertEqual(report["verified_demo_media_policy"]["allowed_media_paths"], [relative_media])
            self.assertEqual(
                report["verified_demo_media_policy"]["pack_audits"][0]["status"],
                "VERIFIED_CC0_DEMO_ONLY",
            )

    def test_stimulus_contract_loader_restores_bytecode_policy_without_cache(self):
        platform_core = sys.modules[validator.scan_public_package.__module__]
        original_source = (
            PACKAGE_ROOT
            / "tools"
            / "Stimulus_Forge_Library_v1_0"
            / "praycg_stimulus_common_v1_0.py"
        )
        with tempfile.TemporaryDirectory() as temporary_directory:
            temporary_root = Path(temporary_directory)
            copied_source = (
                temporary_root
                / "tools"
                / "Stimulus_Forge_Library_v1_0"
                / "praycg_stimulus_common_v1_0.py"
            )
            copied_source.parent.mkdir(parents=True)
            copied_source.write_text(original_source.read_text(encoding="utf-8"), encoding="utf-8")
            old_policy = sys.dont_write_bytecode
            sys.modules.pop(platform_core._STIMULUS_COMMON_MODULE_NAME, None)
            try:
                sys.dont_write_bytecode = False
                with mock.patch.object(platform_core, "PACKAGE_ROOT", temporary_root):
                    loaded = platform_core._load_stimulus_pack_contract()
                self.assertTrue(callable(loaded.validate_pack))
                self.assertFalse(sys.dont_write_bytecode)
                self.assertFalse((copied_source.parent / "__pycache__").exists())
            finally:
                sys.dont_write_bytecode = old_policy
                sys.modules.pop(platform_core._STIMULUS_COMMON_MODULE_NAME, None)

    def test_public_scan_rejects_media_outside_exact_demo_pack_tree(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            media = root / "examples" / "no_copyright_media_demo" / "unmanaged.wav"
            media.parent.mkdir(parents=True)
            media.write_bytes(b"unmanaged media")

            report = validator.scan_public_package(root)

            self.assertEqual(report["status"], "INELIGIBLE")
            self.assertTrue(any(row["path"] == media.relative_to(root).as_posix() for row in report["findings"]))

    def test_public_scan_rejects_tampered_or_unmanifested_demo_media(self):
        for scenario in ("tampered", "unmanifested"):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as temporary_directory:
                root = Path(temporary_directory)
                pack_root = write_frozen_demo_pack(root)
                if scenario == "tampered":
                    with (pack_root / "media" / "sample.wav").open("ab") as handle:
                        handle.write(b"tampering")
                else:
                    (pack_root / "media" / "unmanifested.wav").write_bytes(b"unmanifested")

                report = validator.scan_public_package(root)

                self.assertEqual(report["status"], "INELIGIBLE")
                self.assertEqual(report["verified_demo_media_policy"]["allowed_media_count"], 0)
                self.assertEqual(
                    report["verified_demo_media_policy"]["pack_audits"][0]["status"],
                    "REJECTED_FAIL_CLOSED",
                )

    def test_public_scan_rejects_non_demo_or_non_cc0_pack_media(self):
        scenarios = (
            {"status": "PILOT_CANDIDATE", "license_id": "CC0-1.0"},
            {"status": "DEMO_ONLY", "license_id": "MIT"},
        )
        for scenario in scenarios:
            with self.subTest(**scenario), tempfile.TemporaryDirectory() as temporary_directory:
                root = Path(temporary_directory)
                write_frozen_demo_pack(root, **scenario)

                report = validator.scan_public_package(root)

                self.assertEqual(report["status"], "INELIGIBLE")
                self.assertEqual(report["verified_demo_media_policy"]["allowed_media_count"], 0)

    def test_public_scan_never_allows_raw_biosignal_data_from_demo_pack(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            root = Path(temporary_directory)
            pack_root = write_frozen_demo_pack(root, include_raw_recording=True)

            report = validator.scan_public_package(root)

            raw_relative = (pack_root / "media" / "sample.xdf").relative_to(root).as_posix()
            self.assertEqual(report["status"], "INELIGIBLE")
            self.assertTrue(any(row["path"] == raw_relative for row in report["findings"]))
            self.assertEqual(report["verified_demo_media_policy"]["allowed_media_count"], 1)


if __name__ == "__main__":
    unittest.main()
