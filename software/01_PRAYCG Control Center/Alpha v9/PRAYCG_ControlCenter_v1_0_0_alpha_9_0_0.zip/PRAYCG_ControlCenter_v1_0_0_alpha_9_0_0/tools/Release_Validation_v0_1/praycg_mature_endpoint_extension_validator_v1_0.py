#!/usr/bin/env python3
"""Validate the PRAYCG Mature Endpoint Atlas v1.0 extension.

This validator is intentionally software-scoped. It verifies package structure,
declarative protocol discovery/compilation, endpoint contracts/templates,
regression tests, static endpoint-evaluator behavior, and public-package hygiene.
It does not validate human feasibility, hardware, physiology, constructs, or claims.
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SCHEMA = "PRAYCG_MatureEndpointAtlasBuildValidation_v1_0"
VALIDATION_NAME = "BUILD_VALIDATION_MATURE_ENDPOINT_ATLAS_v1_0.json"
CHECKSUM_NAME = "SHA256SUMS_v1_0_0_alpha_8_5_4.txt"


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"Expected JSON object: {path}")
    return payload


def evidence_command(args: list[str]) -> list[str]:
    """Keep reproducibility metadata without publishing a workstation path."""
    if args and Path(args[0]).resolve(strict=False) == Path(sys.executable).resolve(strict=False):
        return ["python", *args[1:]]
    return list(args)


def run_command(name: str, args: list[str], cwd: Path, timeout: int = 180) -> dict[str, Any]:
    started = time.monotonic()
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    proc = subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True, timeout=timeout)
    combined = f"{proc.stdout}\n{proc.stderr}"
    passed = re.search(r"(\d+) passed", combined)
    subtests = re.search(r"(\d+) subtests passed", combined)
    return {
        "id": name,
        "status": "PASS" if proc.returncode == 0 else "FAIL",
        "returncode": proc.returncode,
        "duration_seconds": round(time.monotonic() - started, 3),
        "reported_passed_tests": int(passed.group(1)) if passed else None,
        "reported_passed_subtests": int(subtests.group(1)) if subtests else 0,
        "command": evidence_command(args),
        "stdout_tail": proc.stdout[-4000:],
        "stderr_tail": proc.stderr[-4000:],
        "_stdout_full": proc.stdout,
    }


def remove_caches(root: Path) -> dict[str, Any]:
    removed_files = 0
    removed_dirs = 0
    for path in sorted(root.rglob("*.py[co]"), reverse=True):
        try:
            path.unlink()
            removed_files += 1
        except FileNotFoundError:
            pass
    for path in sorted(root.rglob("__pycache__"), key=lambda p: len(p.parts), reverse=True):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
            removed_dirs += 1
    for name in (".pytest_cache", ".mypy_cache", ".ruff_cache"):
        for path in sorted(root.rglob(name), key=lambda p: len(p.parts), reverse=True):
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
                removed_dirs += 1
    remaining = [str(path.relative_to(root)) for path in root.rglob("*.py[co]")]
    remaining += [str(path.relative_to(root)) for path in root.rglob("__pycache__")]
    return {
        "status": "PASS" if not remaining else "FAIL",
        "removed_bytecode_files": removed_files,
        "removed_cache_directories": removed_dirs,
        "remaining": remaining,
    }


def structure_audit(root: Path) -> dict[str, Any]:
    atlas = root / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0"
    scripts = atlas / "scripts"
    sys.path.insert(0, str(scripts))
    from praycg_protocol_atlas_core_v2_0 import discover_protocol_modules  # type: ignore

    catalog = load_json(root / "config" / "praycg_mature_endpoint_atlas_catalog_v1_0.json")
    extension = load_json(root / "VERSION_MANIFEST_MATURE_ENDPOINT_ATLAS_v1_0.json")
    records, discovery_errors = discover_protocol_modules(atlas)
    by_id = {record.protocol_id: record for record in records}
    failures: list[str] = list(discovery_errors)
    rows: list[dict[str, Any]] = []
    if extension.get("package") != root.name:
        failures.append("extension manifest package identity does not match the selected package root")
    if catalog.get("base_platform") != root.name:
        failures.append("mature endpoint catalog base_platform does not match the selected package root")
    if len(records) != 40:
        failures.append(f"expected 40 Atlas modules, discovered {len(records)}")
    if catalog.get("protocol_count") != 17 or len(catalog.get("protocols", [])) != 17:
        failures.append("mature catalog does not contain exactly 17 protocols")
    inventory = extension.get("runnable_protocol_inventory", {})
    expected_inventory = {
        "total_runnable_protocol_count": 43,
        "native_protocol_count": 3,
        "pre_existing_atlas_protocol_count": 23,
        "mature_endpoint_protocol_count": 17,
        "atlas_protocol_count_total": 40,
    }
    for key, value in expected_inventory.items():
        if inventory.get(key) != value:
            failures.append(f"extension inventory {key}={inventory.get(key)!r}; expected {value!r}")

    gate_root = root / "config" / "mature_endpoint_gate_templates"
    analysis_root = root / "config" / "mature_endpoint_analysis_templates"
    for item in catalog.get("protocols", []):
        pid = item.get("protocol_id")
        row_failures: list[str] = []
        record = by_id.get(pid)
        if record is None:
            row_failures.append("not discovered")
            failures.append(f"{pid}: not discovered")
            continue
        manifest = record.module
        contract = manifest.get("endpoint_contract", {})
        if contract.get("schema") != "PRAYCG_MatureEndpointContract_v1_0":
            row_failures.append("invalid endpoint contract schema")
        if manifest.get("hardware_stack_effect") != "NONE" or manifest.get("hardware_profile_id") is not None:
            row_failures.append("hardware authority boundary violated")
        gate_ids = [gate.get("id") for gate in contract.get("quality_gates", [])]
        if not gate_ids or len(gate_ids) != len(set(gate_ids)):
            row_failures.append("missing or duplicate gate ids")
        endpoint_ids = [entry.get("id") for entry in contract.get("endpoint_families", [])]
        if not endpoint_ids or len(endpoint_ids) != len(set(endpoint_ids)):
            row_failures.append("missing or duplicate endpoint-family ids")
        gate_path = gate_root / f"{pid}_gate_status_TEMPLATE.json"
        analysis_path = analysis_root / f"{pid}_analysis_status_TEMPLATE.json"
        if not gate_path.is_file() or not analysis_path.is_file():
            row_failures.append("protocol-specific template missing")
        else:
            gate_template = load_json(gate_path)
            templated = [(g.get("id"), g.get("required"), g.get("rule"), g.get("status")) for g in gate_template.get("gates", [])]
            declared = [(g.get("id"), bool(g.get("required", False)), g.get("rule", ""), "NOT_ASSESSED") for g in contract.get("quality_gates", [])]
            if templated != declared:
                row_failures.append("gate template does not match contract")
            analysis_template = load_json(analysis_path)
            if analysis_template.get("primary_endpoint_status") != "NOT_RUN":
                row_failures.append("analysis template is not fail-closed")
            if analysis_template.get("maximum_claim_without_special_measurement") != contract.get("maximum_claim_without_special_measurement"):
                row_failures.append("analysis template claim ceiling mismatch")
        if not record.runner_path.is_file() or not record.engine_path.is_file():
            row_failures.append("runner or engine missing")
        if row_failures:
            failures.extend(f"{pid}: {failure}" for failure in row_failures)
        rows.append({
            "protocol_id": pid,
            "status": "PASS" if not row_failures else "FAIL",
            "quality_gate_count": len(gate_ids),
            "endpoint_family_count": len(endpoint_ids),
            "failures": row_failures,
        })

    # High-value identity checks that must remain explicit.
    for filename in ("PRAYCG_G_mature_gradient_v2_0.json", "PRAYCG_G_dyadic_hyperscanning_v2_0.json"):
        manifest = load_json(atlas / "protocols" / filename)
        media_keys: dict[str, str] = {}
        for node in manifest.get("timeline", []):
            for child in node.get("children", []):
                if child.get("id") in {"high_meaning_video", "analytic_override_video"}:
                    media_keys[child["id"]] = child.get("media_key")
        if media_keys != {"high_meaning_video": "target_override_video", "analytic_override_video": "target_override_video"}:
            failures.append(f"{filename}: Target/Override asset identity contract failed")

    return {
        "status": "PASS" if not failures else "FAIL",
        "discovered_atlas_protocol_count": len(records),
        "mature_protocol_count": len(catalog.get("protocols", [])),
        "discovery_errors": discovery_errors,
        "failures": failures,
        "mature_protocols": rows,
    }


def static_evaluator_audit(root: Path) -> dict[str, Any]:
    evaluator_root = root / "tools" / "Mature_Endpoint_Evaluator_v1_0"
    sys.path.insert(0, str(evaluator_root))
    from praycg_mature_endpoint_evaluator_v1_0 import evaluate  # type: ignore

    catalog = load_json(root / "config" / "praycg_mature_endpoint_atlas_catalog_v1_0.json")
    protocols = root / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0" / "protocols"
    rows = []
    failures = []
    for item in catalog["protocols"]:
        manifest = protocols / item["manifest"]
        report = evaluate(manifest)
        label = report.get("decision", {}).get("label")
        passed = label == "CALIBRATION_ONLY"
        if not passed:
            failures.append(f"{item['protocol_id']}: static evaluator label {label!r}")
        rows.append({"protocol_id": item["protocol_id"], "decision": label, "status": "PASS" if passed else "FAIL"})
    return {"status": "PASS" if not failures else "FAIL", "protocol_count": len(rows), "failures": failures, "protocols": rows}


def public_scan(root: Path) -> dict[str, Any]:
    core = root / "platform_core"
    sys.path.insert(0, str(core))
    prior_bytecode_policy = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        from praycg_platform_core_v1_0_alpha_4 import scan_public_package  # type: ignore
        return scan_public_package(root, allowed_emails=["hoytbanks@gmail.com"])
    finally:
        sys.dont_write_bytecode = prior_bytecode_policy


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--test-evidence", type=Path, help="Previously generated PRAYCG_MatureEndpointAtlasTestEvidence_v1_0 JSON.")
    parser.add_argument("--smoke-evidence", type=Path, help="Previously generated PRAYCG_ProtocolAtlasReleaseSmoke_v0_1 JSON.")
    args = parser.parse_args()
    root = args.package.resolve()
    output = args.output.resolve() if args.output else root / VALIDATION_NAME
    if output == root / VALIDATION_NAME:
        output.unlink(missing_ok=True)

    compile_result = run_command(
        "python_compileall",
        [sys.executable, "-m", "compileall", "-q", "."],
        cwd=root,
        timeout=180,
    )
    compile_result.pop("_stdout_full", None)
    structure = structure_audit(root)

    tests: list[dict[str, Any]] = []
    if args.test_evidence:
        evidence = load_json(args.test_evidence.resolve())
        tests.append({
            "id": "all_bundled_regression_tests",
            "status": evidence.get("status"),
            "returncode": evidence.get("returncode"),
            "duration_seconds": evidence.get("duration_seconds"),
            "reported_passed_tests": evidence.get("reported_passed_test_count"),
            "reported_passed_subtests": evidence.get("reported_passed_subtest_count", 0),
            "command": evidence_command(list(evidence.get("command") or [])),
            "stdout_tail": str(evidence.get("stdout", ""))[-4000:],
            "stderr_tail": str(evidence.get("stderr", ""))[-4000:],
            "evidence_path": args.test_evidence.resolve().relative_to(root).as_posix(),
            "evidence_schema": evidence.get("schema"),
        })
    elif not args.skip_tests:
        tests.append(run_command(
            "all_bundled_regression_tests",
            [
                sys.executable, "-m", "pytest", "-q",
                "tools/Release_Validation_v0_1/tests",
                "control_center/tests",
                "tools/ProtocolAtlas_ModuleLibrary_v2_0/tests",
                "tools/MasterComprehensiveSuite_v1_6_1_CURRENT/tests",
                "tools/Micro_Handoff_v0_1/tests",
                "tools/Stimulus_Forge_Library_v1_0/tests",
                "tools/Hardware_Forge_v0_1/tests",
                "tools/Acquisition/Generic_EDA_PPG_Stream_Bridge_v0_1/tests",
                "tools/Analysis_Module_Catalog_v0_1/tests",
            ],
            cwd=root,
            timeout=240,
        ))
        for test in tests:
            test.pop("_stdout_full", None)

    if args.smoke_evidence:
        smoke_payload = load_json(args.smoke_evidence.resolve())
        smoke = {
            "id": "atlas_40_wrapper_smoke",
            "status": smoke_payload.get("status"),
            "returncode": 0 if smoke_payload.get("status") == "PASS" else 2,
            "duration_seconds": None,
            "reported_passed_tests": None,
            "reported_passed_subtests": 0,
            "command": ["evidence", args.smoke_evidence.resolve().relative_to(root).as_posix()],
            "stdout_tail": "",
            "stderr_tail": "",
        }
    else:
        release_smoke_path = root / "tools" / "Release_Validation_v0_1" / "praycg_protocol_atlas_release_smoke_v0_1.py"
        smoke = run_command(
            "atlas_40_wrapper_smoke",
            [sys.executable, release_smoke_path.relative_to(root).as_posix(), "--package", "."],
            cwd=root,
            timeout=180,
        )
        try:
            smoke_payload = json.loads(smoke.get("_stdout_full", ""))
        except Exception:
            smoke_payload = {"status": smoke["status"], "parse_error": True}
        smoke.pop("_stdout_full", None)

    evaluator = static_evaluator_audit(root)
    time.sleep(1.0)
    cleanup = remove_caches(root)
    scan = public_scan(root)

    supported_python_target_exercised = platform.python_version_tuple()[:2] == ("3", "11")
    checks = [
        compile_result["status"],
        structure["status"],
        smoke["status"],
        evaluator["status"],
        cleanup["status"],
        scan.get("status"),
        "PASS" if supported_python_target_exercised else "FAIL",
    ]
    checks.extend(test["status"] for test in tests)
    status = "PASS" if all(value == "PASS" for value in checks) else "FAIL"
    total_tests = sum(test.get("reported_passed_tests") or 0 for test in tests)
    total_subtests = sum(test.get("reported_passed_subtests") or 0 for test in tests)
    result = {
        "schema": SCHEMA,
        "extension_version": "1.0",
        "generated_utc": utc_now(),
        "package": root.name,
        "status": status,
        "validation_scope": "Software syntax, declarative discovery/compilation, endpoint-contract/template integrity, static evaluator behavior, bundled regression tests, and public-package hygiene only.",
        "environment": {
            "python_version": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "operating_system": platform.system(),
            "machine": platform.machine(),
            "supported_python_target": "3.11",
            "supported_python_target_exercised": supported_python_target_exercised,
        },
        "inventory": {
            "total_runnable_protocol_count": 43,
            "native_protocol_count": 3,
            "atlas_protocol_count": 40,
            "mature_endpoint_protocol_count": 17,
        },
        "python_compile": compile_result,
        "structure_audit": structure,
        "atlas_release_smoke": smoke_payload,
        "static_endpoint_evaluator_audit": evaluator,
        "automated_tests": {
            "status": "PASS" if tests and all(test["status"] == "PASS" for test in tests) else ("SKIPPED" if not tests else "FAIL"),
            "suite_count": len(tests),
            "reported_passed_test_count": total_tests,
            "reported_passed_subtest_count": total_subtests,
            "suites": tests,
        },
        "cache_cleanup": cleanup,
        "public_package_scan": scan,
        "hash_inventory": {
            "artifact": CHECKSUM_NAME,
            "status": "PENDING_GENERATION" if not (root / CHECKSUM_NAME).is_file() else "PRESENT",
            "excludes": [VALIDATION_NAME, CHECKSUM_NAME],
        },
        "not_performed": {
            "physical_hardware_validation": "NOT_PERFORMED",
            "interactive_psychopy_validation": "NOT_PERFORMED",
            "human_subject_feasibility": "NOT_PERFORMED",
            "irb_or_ethics_approval": "NOT_PERFORMED",
            "construct_or_psychometric_validation": "NOT_PERFORMED",
            "physiological_endpoint_validation": "NOT_PERFORMED",
            "clinical_validation": "NOT_PERFORMED",
            "confirmation_grade_replication": "NOT_PERFORMED",
        },
        "claim_boundary": "PASS means the packaged software behaved as specified in this environment. It does not validate a scientific endpoint, apparatus, participant procedure, construct, diagnosis, treatment, or metaphysical claim.",
    }
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": status,
        "output": str(output),
        "reported_passed_tests": total_tests,
        "reported_passed_subtests": total_subtests,
        "atlas_protocols": structure["discovered_atlas_protocol_count"],
        "wrapper_dry_runs": smoke_payload.get("wrapper_dry_run_count"),
        "public_scan": scan.get("status"),
    }, indent=2))
    return 0 if status == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
