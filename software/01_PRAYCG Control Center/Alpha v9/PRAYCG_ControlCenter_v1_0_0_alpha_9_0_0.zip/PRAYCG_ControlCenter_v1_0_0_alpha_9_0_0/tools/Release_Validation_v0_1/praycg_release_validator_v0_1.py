#!/usr/bin/env python3
"""Compile, test, inventory, and public-safety scan a PRAYCG package."""
from __future__ import annotations

import argparse
import compileall
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
VALIDATOR_DIR = Path(__file__).resolve().parent
RELEASE_VERSION = "1.0.0-alpha.9.0.0"
RELEASE_PACKAGE = "PRAYCG_ControlCenter_v1_0_0_alpha_9_0_0"
CHECKSUM_NAME = "SHA256SUMS_v1_0_0_alpha_9_0_0.txt"
BUILD_VALIDATION_NAME = "BUILD_VALIDATION_v1_0_0_alpha_9_0_0.json"
VERSION_MANIFEST_NAME = "VERSION_MANIFEST_v1_0_0_alpha_9_0_0.json"
TEST_EVIDENCE_SCHEMA = "PRAYCG_AutomatedTestEvidence_v1_0_alpha_9_0_0"
ATLAS_ROOT = Path("tools") / "ProtocolAtlas_ModuleLibrary_v2_0"
NATIVE_PROTOCOL_ROOT = Path("tools") / "ProtocolRunner_ModuleLibrary_v1_0"
VALIDATION_EXECUTION_MODE = "sequential"

# Prior-release publication artifacts must not compete with the Alpha 9 entry
# point. Carried implementation modules and research-method documents may
# remain, but old installers, checksums, build claims, and manifests may not.
STALE_PUBLIC_ARTIFACTS = (
    "BUILD_VALIDATION_v1_0_0_alpha_2.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_2.bat",
    "RELEASE_NOTES_v1_0_0_alpha_2.md",
    "requirements_PRAYCG_v1_0_0_alpha_2.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_2.bat",
    "SHA256SUMS_v1_0_0_alpha_2.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_2.json",
    "docs/PRAYCG_ControlCenter_v1_0_0_alpha_2_Installation_Guide.docx",
    "docs/PRAYCG_ControlCenter_v1_0_0_alpha_2_Installation_Guide.md",
    "docs/PRAYCG_v1_0_0_alpha_2_Detailed_Workflow_Guide.docx",
    "docs/PRAYCG_v1_0_0_alpha_2_Detailed_Workflow_Guide.md",
    "docs/PRAYCG_Master_Protocol_and_Theory_v1_0_1_alpha.docx",
    "docs/PRAYCG_Master_Protocol_and_Theory_v1_0_1_alpha.md",
    "BUILD_VALIDATION_v1_0_0_alpha_3.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_3.bat",
    "RELEASE_NOTES_v1_0_0_alpha_3.md",
    "requirements_PRAYCG_v1_0_0_alpha_3.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_3.bat",
    "SHA256SUMS_v1_0_0_alpha_3.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_3.json",
    "docs/PRAYCG_ControlCenter_v1_0_0_alpha_3_Installation_Guide.docx",
    "docs/PRAYCG_ControlCenter_v1_0_0_alpha_3_Installation_Guide.md",
    "docs/PRAYCG_v1_0_0_alpha_3_Detailed_Workflow_Guide.docx",
    "docs/PRAYCG_v1_0_0_alpha_3_Detailed_Workflow_Guide.md",
    "docs/build_alpha3_documents.py",
    "docs/requirements_DOCUMENT_BUILD_v1_0_0_alpha_3.txt",
    "BUILD_VALIDATION_v1_0_0_alpha_4.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_4.bat",
    "requirements_PRAYCG_v1_0_0_alpha_4.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_4.bat",
    "SHA256SUMS_v1_0_0_alpha_4.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_4.json",
    "BUILD_VALIDATION_v1_0_0_alpha_5.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_5.bat",
    "requirements_PRAYCG_v1_0_0_alpha_5.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_5.bat",
    "SHA256SUMS_v1_0_0_alpha_5.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_5.json",
    "BUILD_VALIDATION_v1_0_0_alpha_6.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_6.bat",
    "requirements_PRAYCG_v1_0_0_alpha_6.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_6.bat",
    "SHA256SUMS_v1_0_0_alpha_6.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_6.json",
    "config/module_registry_v1_0_alpha_6.json",
    "control_center/config/praycg_control_center_config_TEMPLATE_v1_0_0_alpha_6.json",
    "control_center/scripts/praycg_control_center_v1_0_0_alpha_6.py",
    "BUILD_VALIDATION_v1_0_0_alpha_6_1.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_6_1.bat",
    "requirements_PRAYCG_v1_0_0_alpha_6_1.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_6_1.bat",
    "SHA256SUMS_v1_0_0_alpha_6_1.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_6_1.json",
    "config/module_registry_v1_0_alpha_6_1.json",
    "control_center/config/praycg_control_center_config_TEMPLATE_v1_0_0_alpha_6_1.json",
    "control_center/scripts/praycg_control_center_v1_0_0_alpha_6_1.py",
    "RELEASE_NOTES_v1_0_0_alpha_8.md",
    "BUILD_VALIDATION_v1_0_0_alpha_8_2.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_8_2.bat",
    "RELEASE_NOTES_v1_0_0_alpha_8_2.md",
    "requirements_PRAYCG_v1_0_0_alpha_8_2.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_8_2.bat",
    "SHA256SUMS_v1_0_0_alpha_8_2.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_8_2.json",
    "BUILD_VALIDATION_v1_0_0_alpha_8_5_3.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_8_5_3.bat",
    "RELEASE_NOTES_v1_0_0_alpha_8_5_3.md",
    "requirements_PRAYCG_v1_0_0_alpha_8_5_3.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_8_5_3.bat",
    "SHA256SUMS_v1_0_0_alpha_8_5_3.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_8_5_3.json",
    "BUILD_VALIDATION_v1_0_0_alpha_8_5_4.json",
    "INSTALL_PRAYCG_v1_0_0_alpha_8_5_4.bat",
    "RELEASE_NOTES_v1_0_0_alpha_8_5_4.md",
    "requirements_PRAYCG_v1_0_0_alpha_8_5_4.txt",
    "run_PRAYCG_ControlCenter_v1_0_0_alpha_8_5_4.bat",
    "SHA256SUMS_v1_0_0_alpha_8_5_4.txt",
    "VERSION_MANIFEST_v1_0_0_alpha_8_5_4.json",
)
sys.path.insert(0, str(PACKAGE_ROOT / "platform_core"))
from praycg_platform_core_v1_0_alpha_4 import inventory_hashes, optional_dependency_status, scan_public_package, utc_now, write_json  # noqa: E402


def declared_test_suites(package: Path) -> list[dict[str, Any]]:
    """Return only the automated suites this validator knows how to execute."""
    return [
        {
            "id": "release_validator_hygiene",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Release_Validation_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "control_center_regression",
            "runner": "unittest_discovery",
            "path": package / "control_center" / "tests",
            "pattern": "test_*.py",
            "shard_by_file": True,
            "exclude_files": [
                "test_control_center_alpha8_layout_integration.py",
                "test_hardware_launch_click_gate_alpha8.py",
                "test_protocol_stimulus_flow_alpha8.py",
                "test_control_center_alpha8_integration.py",
                "test_alpha900_hardware_forge_stream_contracts.py",
                "test_control_center_alpha900_integration.py",
            ],
            "class_shards": {
                "test_active_alpha3_compatibility_regression.py": [
                    "ActiveAlpha3CommandPathTests",
                    "ActiveAlpha3HardwarePreflightTests",
                    "ActiveAlpha3PlatformGateTests",
                    "ActiveAlpha3PlatformIntegrationTests",
                    "ActiveAlpha3RunnerRuntimeBindingTests",
                    "ActiveAlpha3MicroHandoffIntegrationTests",
                    "ActiveAlpha3HarnessIdentityTests",
                    "ActiveAlpha3ConsolidationTests",
                ],
            },
        },
        {
            "id": "protocol_stimulus_flow_alpha8",
            "runner": "pytest",
            "path": package / "control_center" / "tests" / "test_protocol_stimulus_flow_alpha8.py",
        },
        {
            "id": "control_center_alpha8_layout_integration",
            "runner": "pytest",
            "path": package / "control_center" / "tests" / "test_control_center_alpha8_layout_integration.py",
        },
        {
            "id": "hardware_launch_click_gate_alpha8",
            "runner": "pytest",
            "path": package / "control_center" / "tests" / "test_hardware_launch_click_gate_alpha8.py",
        },
        {
            "id": "study_workspace",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Study_Workspace_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "analysis_orchestrator",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Analysis_Orchestrator_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "results_bundle_builder",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Results_Bundle_Builder_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "control_center_alpha8_workspace_integration",
            "runner": "pytest",
            "path": package / "control_center" / "tests" / "test_control_center_alpha8_integration.py",
        },
        {
            "id": "alpha900_hardware_forge_stream_contracts",
            "runner": "pytest",
            "path": package / "control_center" / "tests" / "test_alpha900_hardware_forge_stream_contracts.py",
        },
        {
            "id": "control_center_alpha900_integration",
            "runner": "pytest",
            "path": package / "control_center" / "tests" / "test_control_center_alpha900_integration.py",
        },
        {
            "id": "protocol_ai_docs_builder",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Protocol_AI_Doc_Builder_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "protocol_atlas_pytest",
            "runner": "pytest",
            "path": package / ATLAS_ROOT / "tests",
        },
        {
            "id": "protocol_atlas_individualized_runner_dry_runs",
            "runner": "protocol_atlas_smoke",
            "path": package / "tools" / "Release_Validation_v0_1" / "praycg_protocol_atlas_release_smoke_v0_1.py",
        },
        {
            "id": "master_comprehensive_suite_regression",
            "runner": "unittest_discovery",
            "path": package / "tools" / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "micro_handoff_assertion_tests",
            "runner": "plain_no_argument_test_functions",
            "path": package / "tools" / "Micro_Handoff_v0_1" / "tests" / "test_micro_handoff_v0_1.py",
        },
        {
            "id": "cue_locked_gamma_forensics_synthetic_self_test",
            "runner": "module_synthetic_self_test",
            "path": package / "tools" / "Cue_Locked_Gamma_Forensics_v0_1" / "software" / "praycg_cue_locked_gamma_forensics_v0_1.py",
        },
        {
            "id": "stimulus_forge_library",
            "runner": "pytest",
            "path": package / "tools" / "Stimulus_Forge_Library_v1_0" / "tests",
        },
        {
            "id": "hardware_forge_catalog",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Hardware_Forge_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "hardware_selection_profile_workflow",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Hardware_Workflow_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "generic_eda_ppg_bridge",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1" / "tests",
            "pattern": "test_*.py",
        },
        {
            "id": "analysis_module_catalog",
            "runner": "unittest_discovery",
            "path": package / "tools" / "Analysis_Module_Catalog_v0_1" / "tests",
            "pattern": "test_*.py",
        },
    ]


def _display_path(path: Path, package: Path) -> str:
    try:
        return path.resolve().relative_to(package.resolve()).as_posix()
    except ValueError:
        return path.name


def _reported_test_count(runner: str, stdout: str, stderr: str) -> int | None:
    combined = f"{stdout}\n{stderr}"
    if runner == "unittest_discovery":
        match = re.search(r"\bRan\s+(\d+)\s+tests?\b", combined)
        return int(match.group(1)) if match else None
    if runner == "plain_no_argument_test_functions":
        match = re.search(r'"total"\s*:\s*(\d+)', stdout)
        return int(match.group(1)) if match else None
    if runner == "module_synthetic_self_test":
        return 1
    if runner == "pytest":
        match = re.search(r"\b(\d+)\s+passed\b", combined)
        return int(match.group(1)) if match else None
    if runner == "protocol_atlas_smoke":
        match = re.search(r'"wrapper_dry_run_count"\s*:\s*(\d+)', stdout)
        return int(match.group(1)) if match else None
    return None


def _run_command(
    suite: dict[str, Any],
    command: list[str],
    *,
    package: Path,
    timeout_seconds: int = 300,
) -> dict[str, Any]:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    creation_flags = 0
    if os.name == "nt":
        # Keep a test process' console-control events inside its own process
        # group. Without this boundary, a child interrupted during shutdown can
        # raise KeyboardInterrupt in the release validator and abort the whole
        # sequential validation run.
        creation_flags = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
    print(f"[validation] {suite['id']}", file=sys.stderr, flush=True)
    started = time.perf_counter()
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            cwd=package,
            env=env,
            timeout=timeout_seconds,
            creationflags=creation_flags,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "id": suite["id"],
            "runner": suite["runner"],
            "path": _display_path(suite["path"], package),
            "status": "FAIL_TIMEOUT",
            "timeout_seconds": timeout_seconds,
            "duration_seconds": round(time.perf_counter() - started, 3),
            "stdout": (exc.stdout or "")[-12000:] if isinstance(exc.stdout, str) else "",
            "stderr": (exc.stderr or "")[-12000:] if isinstance(exc.stderr, str) else "",
        }
    duration = round(time.perf_counter() - started, 3)
    full_stdout = completed.stdout
    full_stderr = completed.stderr
    stdout = full_stdout[-12000:]
    stderr = full_stderr[-12000:]
    # Count from the complete captured output before truncating the evidence
    # excerpt. Atlas smoke emits its count near the beginning of a large JSON
    # document, so counting the tail silently under-reported successful runs.
    reported_test_count = _reported_test_count(suite["runner"], full_stdout, full_stderr)
    if completed.returncode != 0:
        status = "FAIL"
    elif reported_test_count == 0:
        status = "FAIL_ZERO_TESTS"
    else:
        status = "PASS"
    return {
        "id": suite["id"],
        "runner": suite["runner"],
        "path": _display_path(suite["path"], package),
        "status": status,
        "returncode": completed.returncode,
        "reported_test_count": reported_test_count,
        "duration_seconds": duration,
        "stdout": stdout,
        "stderr": stderr,
    }


def _run_sharded_unittest_suite(suite: dict[str, Any], package: Path) -> dict[str, Any]:
    """Run each unittest file independently, then aggregate every shard.

    Process isolation prevents module-level test state from crossing files.
    Shards run one at a time to keep packaging memory predictable and results
    are returned in filename order for deterministic reports.
    """
    path = Path(suite["path"])
    excluded_files = {str(value) for value in suite.get("exclude_files", [])}
    test_files = sorted(
        item
        for item in path.glob(str(suite["pattern"]))
        if item.is_file() and item.name not in excluded_files
    )
    if not test_files:
        return {
            "id": suite["id"],
            "runner": suite["runner"],
            "path": _display_path(path, package),
            "status": "FAIL_ZERO_TESTS",
            "reported_test_count": 0,
            "shard_count": 0,
            "shards": [],
            "error": "no unittest files matched the declared pattern",
        }

    configured_class_shards = suite.get("class_shards", {})
    shard_specs: list[tuple[Path, str | None]] = []
    for test_file in test_files:
        class_names = configured_class_shards.get(test_file.name, [])
        if class_names:
            shard_specs.extend((test_file, str(class_name)) for class_name in class_names)
        else:
            shard_specs.append((test_file, None))

    def run_shard(shard_spec: tuple[Path, str | None]) -> dict[str, Any]:
        test_file, class_name = shard_spec
        shard_label = f"{test_file.name}::{class_name}" if class_name else test_file.name
        shard_suite = {
            "id": f"{suite['id']}::{shard_label}",
            "runner": "unittest_discovery",
            "path": path,
        }
        command = [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(path),
            "-p",
            test_file.name,
            "-v",
        ]
        if class_name:
            command.extend(["-k", class_name])
        return _run_command(shard_suite, command, package=package)

    started = time.perf_counter()
    shard_results = [run_shard(shard_spec) for shard_spec in shard_specs]
    duration = round(time.perf_counter() - started, 3)
    counts = [row.get("reported_test_count") for row in shard_results]
    known_counts = [int(value) for value in counts if isinstance(value, int)]
    status = "PASS" if all(row.get("status") == "PASS" for row in shard_results) else "FAIL"
    stdout = "\n".join(
        f"[{test_file.name}{'::' + class_name if class_name else ''}]\n{row.get('stdout', '')}"
        for (test_file, class_name), row in zip(shard_specs, shard_results)
        if row.get("stdout")
    )[-12000:]
    stderr = "\n".join(
        f"[{test_file.name}{'::' + class_name if class_name else ''}]\n{row.get('stderr', '')}"
        for (test_file, class_name), row in zip(shard_specs, shard_results)
        if row.get("stderr")
    )[-12000:]
    return {
        "id": suite["id"],
        "runner": suite["runner"],
        "path": _display_path(path, package),
        "status": status,
        "returncode": 0 if status == "PASS" else 1,
        "reported_test_count": sum(known_counts),
        "duration_seconds": duration,
        "shard_count": len(shard_results),
        "shards": [
            {
                "file": test_file.name,
                "class_filter": class_name,
                "status": row.get("status"),
                "returncode": row.get("returncode"),
                "reported_test_count": row.get("reported_test_count"),
                "duration_seconds": row.get("duration_seconds"),
            }
            for (test_file, class_name), row in zip(shard_specs, shard_results)
        ],
        "stdout": stdout,
        "stderr": stderr,
    }


def run_declared_test_suite(suite: dict[str, Any], package: Path) -> dict[str, Any]:
    path = Path(suite["path"])
    runner = str(suite["runner"])
    required_kind = "directory" if runner == "unittest_discovery" else "path" if runner == "pytest" else "file"
    present = path.is_dir() if required_kind == "directory" else path.exists() if required_kind == "path" else path.is_file()
    if not present:
        return {
            "id": suite["id"],
            "runner": runner,
            "path": _display_path(path, package),
            "status": "FAIL_MISSING_SUITE",
            "error": f"declared test {required_kind} is missing",
        }
    if runner == "unittest_discovery":
        if suite.get("shard_by_file"):
            return _run_sharded_unittest_suite(suite, package)
        command = [
            sys.executable,
            "-m",
            "unittest",
            "discover",
            "-s",
            str(path),
            "-p",
            str(suite["pattern"]),
            "-v",
        ]
        return _run_command(suite, command, package=package)
    if runner == "pytest":
        command = [sys.executable, "-m", "pytest", str(path), "-q"]
        return _run_command(suite, command, package=package)
    if runner == "protocol_atlas_smoke":
        command = [sys.executable, str(path), "--package", str(package)]
        return _run_command(suite, command, package=package)
    if runner == "plain_no_argument_test_functions":
        command = [
            sys.executable,
            str(VALIDATOR_DIR / "praycg_plain_function_test_runner_v0_1.py"),
            str(path),
        ]
        return _run_command(suite, command, package=package)
    if runner == "module_synthetic_self_test":
        with tempfile.TemporaryDirectory(prefix="praycg_clgf_self_test_") as temporary_output:
            command = [
                sys.executable,
                str(path),
                "--out",
                temporary_output,
                "--self-test",
            ]
            return _run_command(suite, command, package=package)
    return {
        "id": suite["id"],
        "runner": runner,
        "path": _display_path(path, package),
        "status": "FAIL_UNSUPPORTED_RUNNER",
    }


def run_automated_tests(package: Path, *, skip: bool) -> dict[str, Any]:
    suites = declared_test_suites(package)
    if skip:
        return {
            "status": "SKIPPED_BY_REQUEST",
            "declared_suite_count": len(suites),
            "executed_suite_count": 0,
            "reported_test_count": 0,
            "all_declared_suites_executed": False,
            "suites": [
                {
                    "id": suite["id"],
                    "runner": suite["runner"],
                    "path": _display_path(Path(suite["path"]), package),
                    "status": "SKIPPED_BY_REQUEST",
                }
                for suite in suites
            ],
            "scope_boundary": "No automated-test result may be inferred when --skip-tests is used.",
        }
    # Each declared suite runs in an isolated child process. Suites are
    # deliberately sequential so validation cannot create a burst of heavy
    # Python interpreters while the Codex UI is open.
    results = [run_declared_test_suite(suite, package) for suite in suites]
    executed = [
        row
        for row in results
        if row["status"] in {"PASS", "FAIL", "FAIL_TIMEOUT", "FAIL_ZERO_TESTS"}
    ]
    counts = [row.get("reported_test_count") for row in results]
    known_counts = [int(value) for value in counts if isinstance(value, int)]
    status = "PASS" if all(row["status"] == "PASS" for row in results) else "FAIL"
    return {
        "status": status,
        "declared_suite_count": len(results),
        "executed_suite_count": len(executed),
        "reported_test_count": sum(known_counts),
        "all_declared_suites_executed": len(executed) == len(results),
        "suites": results,
        "scope_boundary": (
            "Covers only the named bundled suites. Passing tests do not establish physical hardware, "
            "interactive PsychoPy, Docker, external BIDS, scientific-validity, or confirmatory-study validity."
        ),
    }


def package_test_fingerprint(package: Path) -> str:
    """Bind staged test evidence to the exact non-generated package contents."""
    excluded = {BUILD_VALIDATION_NAME, CHECKSUM_NAME, VERSION_MANIFEST_NAME}
    rows = inventory_hashes(package, exclude_names=excluded)
    payload = json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def write_automated_test_evidence(package: Path, output: Path) -> dict[str, Any]:
    """Execute the automated gate as a separately verifiable release stage."""
    initial_bytecode_cleanup = remove_python_bytecode_caches(package)
    initial_test_cache_cleanup = remove_generated_test_caches(package)
    fingerprint_before = package_test_fingerprint(package)
    tests = run_automated_tests(package, skip=False)
    final_bytecode_cleanup = remove_python_bytecode_caches(package)
    final_test_cache_cleanup = remove_generated_test_caches(package)
    fingerprint_after = package_test_fingerprint(package)
    supported = sys.version_info[:2] == (3, 11)
    stable = fingerprint_before == fingerprint_after
    cleanup_passed = all(
        row.get("status") == "PASS"
        for row in (
            initial_bytecode_cleanup,
            initial_test_cache_cleanup,
            final_bytecode_cleanup,
            final_test_cache_cleanup,
        )
    )
    status = "PASS" if tests.get("status") == "PASS" and supported and stable and cleanup_passed else "FAIL"
    evidence = {
        "schema": TEST_EVIDENCE_SCHEMA,
        "package": RELEASE_PACKAGE,
        "version": RELEASE_VERSION,
        "generated_utc": utc_now(),
        "status": status,
        "python_version": platform.python_version(),
        "python_implementation": platform.python_implementation(),
        "supported_python_target": "3.11",
        "supported_python_target_exercised": supported,
        "package_fingerprint_before": fingerprint_before,
        "package_fingerprint_after": fingerprint_after,
        "package_stable_during_tests": stable,
        "cleanup_status": "PASS" if cleanup_passed else "FAIL",
        "automated_tests": tests,
    }
    write_json(output, evidence)
    return evidence


def load_automated_test_evidence(package: Path, evidence_path: Path) -> dict[str, Any]:
    """Validate and consume package-bound evidence from the staged test gate."""
    raw = evidence_path.read_bytes()
    evidence = json.loads(raw.decode("utf-8"))
    if not isinstance(evidence, dict):
        raise ValueError("test evidence must be a JSON object")
    errors: list[str] = []
    if evidence.get("schema") != TEST_EVIDENCE_SCHEMA:
        errors.append("schema mismatch")
    if evidence.get("package") != RELEASE_PACKAGE or evidence.get("version") != RELEASE_VERSION:
        errors.append("release identity mismatch")
    if evidence.get("status") != "PASS" or evidence.get("cleanup_status") != "PASS":
        errors.append("test evidence did not pass")
    if not evidence.get("supported_python_target_exercised"):
        errors.append("test evidence was not produced under Python 3.11")
    if sys.version_info[:2] != (3, 11):
        errors.append("test evidence must be consumed under Python 3.11")
    tests = evidence.get("automated_tests")
    expected_ids = [row["id"] for row in declared_test_suites(package)]
    actual_ids = [row.get("id") for row in tests.get("suites", [])] if isinstance(tests, dict) else []
    if not isinstance(tests, dict) or tests.get("status") != "PASS":
        errors.append("automated test result is absent or not PASS")
    elif (
        tests.get("declared_suite_count") != len(expected_ids)
        or tests.get("executed_suite_count") != len(expected_ids)
        or not tests.get("all_declared_suites_executed")
        or actual_ids != expected_ids
    ):
        errors.append("declared suite coverage does not match this validator")
    fingerprint = package_test_fingerprint(package)
    if (
        evidence.get("package_fingerprint_before") != fingerprint
        or evidence.get("package_fingerprint_after") != fingerprint
        or not evidence.get("package_stable_during_tests")
    ):
        errors.append("package fingerprint does not match tested contents")
    if errors:
        raise ValueError("; ".join(errors))
    tests = dict(tests)
    tests["execution_evidence"] = {
        "schema": TEST_EVIDENCE_SCHEMA,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "generated_utc": evidence.get("generated_utc"),
        "python_version": evidence.get("python_version"),
        "package_fingerprint": fingerprint,
        "mode": "VERIFIED_STAGED_GATE",
    }
    return tests


def remove_python_bytecode_caches(root: Path) -> dict[str, Any]:
    """Remove generated Python bytecode, then verify no bytecode remains."""
    root = root.resolve()
    removed_files: list[str] = []
    removed_directories: list[str] = []
    errors: list[str] = []
    for pattern in ("*.pyc", "*.pyo"):
        for path in sorted(root.rglob(pattern)):
            if not path.is_file():
                continue
            try:
                path.unlink()
                removed_files.append(_display_path(path, root))
            except OSError as exc:
                errors.append(f"{_display_path(path, root)}: {type(exc).__name__}")
    for path in sorted(root.rglob("__pycache__"), key=lambda item: len(item.parts), reverse=True):
        if not path.is_dir():
            continue
        try:
            path.rmdir()
            removed_directories.append(_display_path(path, root))
        except OSError as exc:
            errors.append(f"{_display_path(path, root)}: {type(exc).__name__}")
    remaining_files = sorted(
        {
            _display_path(path, root)
            for pattern in ("*.pyc", "*.pyo")
            for path in root.rglob(pattern)
            if path.is_file()
        }
    )
    remaining_directories = sorted(
        _display_path(path, root)
        for path in root.rglob("__pycache__")
        if path.is_dir()
    )
    return {
        "status": "PASS" if not errors and not remaining_files and not remaining_directories else "FAIL",
        "removed_bytecode_file_count": len(removed_files),
        "removed_cache_directory_count": len(removed_directories),
        "remaining_bytecode_files": remaining_files,
        "remaining_cache_directories": remaining_directories,
        "errors": errors,
    }


def remove_generated_test_caches(root: Path) -> dict[str, Any]:
    """Remove only recognized, regenerated test caches beneath the package."""
    root = root.resolve()
    removed: list[str] = []
    errors: list[str] = []
    for path in sorted(root.rglob(".pytest_cache"), key=lambda item: len(item.parts), reverse=True):
        if not path.is_dir():
            continue
        try:
            path.relative_to(root)
            shutil.rmtree(path)
            removed.append(_display_path(path, root))
        except (OSError, ValueError) as exc:
            errors.append(f"{_display_path(path, root)}: {type(exc).__name__}")
    remaining = sorted(
        _display_path(path, root)
        for path in root.rglob(".pytest_cache")
        if path.is_dir()
    )
    return {
        "status": "PASS" if not errors and not remaining else "FAIL",
        "removed_cache_directory_count": len(removed),
        "remaining_cache_directories": remaining,
        "errors": errors,
    }


def _load_json_object(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"{path.name} must contain one JSON object")
    return payload


def _protocol_inventory(package: Path) -> dict[str, Any]:
    atlas_protocols: list[dict[str, Any]] = []
    atlas_dir = package / ATLAS_ROOT / "protocols"
    for path in sorted(atlas_dir.glob("*.json")):
        if path.name.startswith(("_", ".", "protocol_atlas_module_schema_")):
            continue
        payload = _load_json_object(path)
        adaptation = payload.get("adaptation_status") if isinstance(payload.get("adaptation_status"), dict) else {}
        atlas_protocols.append(
            {
                "protocol_id": payload.get("protocol_id"),
                "protocol_version": payload.get("protocol_version"),
                "display_name": payload.get("display_name"),
                "manifest": path.relative_to(package).as_posix(),
                "runner_entry": payload.get("runner_entry"),
                "engine_entry": payload.get("engine_entry"),
                "adaptation_classification": adaptation.get("classification"),
                "verification_state": adaptation.get("verification_state"),
                "hardware_stack_effect": payload.get("hardware_stack_effect"),
            }
        )

    native_protocols: list[dict[str, Any]] = []
    native_dir = package / NATIVE_PROTOCOL_ROOT / "protocols"
    for path in sorted(native_dir.glob("*.json")):
        if path.name.startswith(("_", ".", "protocol_module_schema_")):
            continue
        payload = _load_json_object(path)
        native_protocols.append(
            {
                "protocol_id": payload.get("protocol_id"),
                "protocol_version": payload.get("protocol_version"),
                "display_name": payload.get("display_name"),
                "manifest": path.relative_to(package).as_posix(),
                "runner_entry": payload.get("runner_entry"),
            }
        )
    return {
        "total_runnable_protocol_count": len(atlas_protocols) + len(native_protocols),
        "native_protocol_count": len(native_protocols),
        "atlas_protocol_count": len(atlas_protocols),
        "native_protocols": native_protocols,
        "atlas_protocols": atlas_protocols,
    }


def build_version_manifest(
    package: Path,
    tests: dict[str, Any],
    *,
    validation_status: str,
) -> dict[str, Any]:
    """Build the Alpha 9 manifest from the package's actual governed catalogs."""
    protocol_inventory = _protocol_inventory(package)

    def catalog_count(relative_path: str, key: str) -> int:
        try:
            records = _load_json_object(package / relative_path).get(key, [])
            return len(records) if isinstance(records, list) else 0
        except Exception:
            return 0

    stimulus_pack_count = catalog_count(
        "tools/Stimulus_Forge_Library_v1_0/config/stimulus_pack_catalog_v1_0.json",
        "packs",
    )
    try:
        hardware_adapters = _load_json_object(
            package / "config" / "hardware_adapter_catalog_v1_0.json"
        ).get("adapters", [])
        if not isinstance(hardware_adapters, list):
            hardware_adapters = []
    except Exception:
        hardware_adapters = []
    hardware_adapter_count = len(hardware_adapters)
    hardware_route_count = sum(
        len(adapter.get("routes", []))
        for adapter in hardware_adapters
        if isinstance(adapter, dict) and isinstance(adapter.get("routes"), list)
    )
    analysis_module_count = catalog_count("config/analysis_module_registry_v0_1.json", "modules")
    analysis_orchestration_module_count = catalog_count("config/analysis_orchestration_registry_v0_1.json", "modules")
    mature_endpoint_protocol_count = catalog_count(
        "config/praycg_mature_endpoint_atlas_catalog_v1_0.json",
        "protocols",
    )
    public_dataset_protocol_count = catalog_count(
        "config/public_dataset_protocol_catalog_v1_0.json",
        "protocols",
    )
    experimental_import_count = catalog_count(
        "tools/ProtocolAtlas_ModuleLibrary_v2_0/experimental_imports_catalog_v1_0.json",
        "candidates",
    )
    return {
        "schema": "PRAYCG_PublicPackageManifest_v1_0_alpha_9_0_0",
        "package": RELEASE_PACKAGE,
        "version": RELEASE_VERSION,
        "release_date": "2026-09-15",
        "release_type": "public_hardware_forge_stream_contract_and_observability_foundation",
        "entry_point": "run_PRAYCG_ControlCenter_v1_0_0_alpha_9_0_0.bat",
        "installer": "INSTALL_PRAYCG_v1_0_0_alpha_9_0_0.bat",
        "requirements": "requirements_PRAYCG_v1_0_0_alpha_9_0_0.txt",
        "control_center": "control_center/scripts/praycg_control_center_v1_0_0_alpha_9.py",
        "control_center_schema": "PRAYCG_ControlCenter_Config_v1_0_alpha_9",
        "platform_core": {
            "version": "1.0.0-alpha.4",
            "entry": "platform_core/praycg_platform_core_v1_0_alpha_4.py",
            "release_relationship": "CARRIED_UNCHANGED_IN_ALPHA_9_FROM_ALPHA_8_5_4",
        },
        "platform_workspaces": [
            "Home",
            "Choose Protocol",
            "Prepare Materials",
            "Connect & Check Equipment",
            "Run Session",
            "Review Results",
            "Settings",
        ],
        "operator_experience": {
            "guided_workflow": True,
            "plain_language_navigation": True,
            "explicit_named_protocol_file_pickers": True,
            "multi_role_folder_guessing": False,
            "runner_generated_protocols_skip_file_selection": True,
            "live_profile_stream_monitor": True,
            "visible_active_equipment_session_id": True,
            "visible_preflight_progress_window": True,
            "self_contained_als_barcode_bridge_recovery": True,
            "guarded_windows_force_stop_after_exact_revalidation": True,
            "current_session_als_outlet_startup_wait_seconds": 20,
            "missing_serial_device_blocks_bridge_spawn": True,
            "explicit_bench_mode_live_status_and_freshness_instructions": True,
            "bench_barcode_display_only_without_hardware": True,
            "stable_mutable_hardware_profile_draft_path": True,
            "organized_runner_pre_arm_gate_rows": True,
            "session_confirmation_hash_locks_selected_inputs": "SHA-256",
        },
        "workflow_contract": {
            "ordered_flow": [
                "LOCK_REVIEWED_PROTOCOL",
                "SELECT_OR_FORGE_COMPATIBLE_STIMULI",
                "VALIDATE_BUILD_AND_LOCK_HARDWARE_PROFILE",
                "CONNECT_AND_LAUNCH_PROFILE_STREAMS",
                "COMPLETE_LIVE_CHECKS_AND_ARM",
                "LAUNCH_LOCKED_PROTOCOL_RUNNER",
                "RUN_SEPARATELY_GOVERNED_ANALYSIS",
            ],
            "protocol_lock_filters_stimulus_options": True,
            "protocol_lock_selects_or_reconfigures_hardware": False,
            "ai_docs_builder_authority": "DOCUMENT_GENERATION_ONLY_NO_EXECUTABLE_CODE_OR_RUNTIME_AUTHORITY",
        },
        "stimulus_platform": {
            "catalog": "tools/Stimulus_Forge_Library_v1_0/config/stimulus_pack_catalog_v1_0.json",
            "pack_count": stimulus_pack_count,
            "default_status": "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION",
            "install_model": "read-only package source copied into the user stimulus workspace",
            "master_media_tag": "MASTER_PRAYCG_STIMULUS_MEDIA",
            "legacy_master_migration": (
                "Explicit alpha.4-row upgrade only after folder, MP4 header, prior-report, sidecar, and live-hash checks; "
                "backup required and no scientific or acquisition promotion."
            ),
            "protocol_switch_policy": "Retain only an exact still-compatible candidate; otherwise clear and stale pre-acquisition context.",
            "runtime_authority": "NONE",
        },
        "hardware_platform": {
            "catalog": "config/hardware_adapter_catalog_v1_0.json",
            "adapter_count": hardware_adapter_count,
            "adapter_route_count": hardware_route_count,
            "admission_levels": [
                "CATALOG_ONLY", "SIMULATOR_VERIFIED", "BENCH_VERIFIED", "HUMAN_CONNECTED_APPROVED"
            ],
            "physical_device_approval_during_packaging": "NOT_PERFORMED",
            "hardware_forge": "tools/Hardware_Forge_v1_0/praycg_hardware_forge_v1_0.py",
            "generic_lsl_intake": "tools/Hardware_Forge_v1_0/praycg_generic_lsl_intake_v1_0.py",
            "stream_contract_validator": "tools/Hardware_Forge_v1_0/praycg_stream_contract_v1_0.py",
            "contract_acquisition_supervisor": "tools/Acquisition_Supervisor_v1_0/praycg_acquisition_supervisor_v1_0.py",
            "runtime_authority": "NONE",
        },
        "analysis_plugin_foundation": {
            "registry": "config/analysis_module_registry_v0_1.json",
            "module_count": analysis_module_count,
            "catalog_authority": "DISCOVERY_AND_PREFLIGHT_ONLY",
            "primary_endpoint_authority": "NONE",
            "master_suite_eligibility_effect": "NONE",
        },
        "study_workspace_and_analysis_orchestration": {
            "workspace": "tools/Study_Workspace_v0_1/praycg_study_workspace_v0_1.py",
            "workflow_stages": ["Protocol", "Stimuli", "Hardware", "Arm", "Run", "QC", "Analyze", "Review", "Export"],
            "upstream_change_policy": "PRESERVE_EVIDENCE_AND_STALE_DEPENDENT_LOCKS",
            "analysis_registry": "config/analysis_orchestration_registry_v0_1.json",
            "registered_execution_module_count": analysis_orchestration_module_count,
            "analysis_plan_policy": "IMMUTABLE_PRE_OUTCOME_LOCK_POST_LOCK_ADDITIONS_POST_HOC_EXPLORATORY",
            "execution_policy": "DEPENDENCY_GRAPH_NO_RUN_EVERYTHING",
            "results_builder": "tools/Results_Bundle_Builder_v0_1/praycg_results_bundle_builder_v0_1.py",
            "results_policy": "LOCAL_REVIEW_ONLY_NO_UPLOAD_RAW_BIOSIGNALS_EXCLUDED_PUBLICATION_NOT_APPROVED",
        },
        "protocol_federation": {
            "adapter": "control_center/scripts/praycg_protocol_library_v2_0.py",
            "stimulus_flow_model": "control_center/scripts/praycg_protocol_stimulus_flow_v1_0.py",
            "ai_docs_builder": "tools/Protocol_AI_Doc_Builder_v0_1/praycg_protocol_ai_doc_builder_v0_1.py",
            "atlas_library": ATLAS_ROOT.as_posix(),
            "native_library": NATIVE_PROTOCOL_ROOT.as_posix(),
            "authorized_library_boundary": (
                "Exact package-owned Atlas and native roots only; external candidates are staging-only."
            ),
            "arbitrary_downloaded_code_allowed": False,
            "mature_endpoint_catalog": "config/praycg_mature_endpoint_atlas_catalog_v1_0.json",
            "mature_endpoint_protocol_count": mature_endpoint_protocol_count,
            "public_dataset_catalog": "config/public_dataset_protocol_catalog_v1_0.json",
            "public_dataset_protocol_count": public_dataset_protocol_count,
            "experimental_import_catalog": (
                "tools/ProtocolAtlas_ModuleLibrary_v2_0/experimental_imports_catalog_v1_0.json"
            ),
            "experimental_import_count": experimental_import_count,
            "experimental_import_execution_authority": "NONE_CATALOG_ONLY",
            "atlas_parameter_policy": (
                "Reviewed manifest defaults are frozen; Alpha 9 exposes no general authorized parameter UI."
            ),
            "atlas_resume_policy": (
                "Checkpoints are evidence only; resume is disabled and environment overrides fail closed."
            ),
            **protocol_inventory,
        },
        "mature_endpoint_atlas": {
            "extension_version": "1.0",
            "protocol_count": mature_endpoint_protocol_count,
            "catalog": "config/praycg_mature_endpoint_atlas_catalog_v1_0.json",
            "extension_manifest": "VERSION_MANIFEST_MATURE_ENDPOINT_ATLAS_v1_0.json",
            "evaluator": "tools/Mature_Endpoint_Evaluator_v1_0/praycg_mature_endpoint_evaluator_v1_0.py",
            "validation": "BUILD_VALIDATION_MATURE_ENDPOINT_ATLAS_v1_0.json",
            "claim_boundary": (
                "Software-alpha runners and structural endpoint contracts only; no scientific, clinical, "
                "physiological, causal, diagnostic, treatment, or metaphysical validity is granted."
            ),
        },
        "hardware_authority_boundary": {
            "sole_operator_workspace": "Connect & Check Equipment",
            "selection_profile_model": "tools/Hardware_Workflow_v0_1/praycg_hardware_workflow_v0_1.py",
            "protocol_hardware_stack_effect": "NONE",
            "protocol_bound_hardware_profile": None,
            "compatibility_rule": (
                "Required hardware roles are checked against the exact lock-bound reviewed profile; "
                "runner-provided marker roles are not hardware requirements. A protocol may not select, "
                "start, or reconfigure hardware."
            ),
            "connect_launch_click_gate": (
                "Every rendered control rereads the saved UI lock and revalidates/re-derives its exact profile-bound "
                "action or transport variant immediately before bridge dispatch."
            ),
        },
        "runtime_authority": {
            "model": "single shared-log-root owner plus exact process-bound one-use lease",
            "canonical_gate_order": [
                "SELECT", "CONNECT", "PREFLIGHT", "SESSION_LOCK", "ARM", "ACQUIRE",
                "FINALIZE", "QC", "ANALYZE", "EXPORT", "VERIFY",
            ],
            "atlas_lock_additions": [
                "module family",
                "Atlas manifest, individualized runner, and shared-engine hashes",
                "external asset snapshot",
                "participant/session-specific compiled timeline and SHA-256",
                "asset-aware compilation C = Compile(T, I, p, j, A*)",
                "recursive nested-node validation and thresholded skip behavior",
                "EMD full-tree selection/schedule/manifest/clip and exact-trial binding",
                "public-dataset balanced trial generators materialized into the immutable compiled timeline",
                "SSVEP target/frequency/phase recipes plus declared display refresh parameters",
            ],
            "visual_marker_boundary": (
                "Visual onsets are scheduled on the presenting PsychoPy flip; they are not physical photon onset."
            ),
            "atlas_als_boundary": (
                "Enabled overlays cover declared top-level continuous-node boundaries and require separate "
                "physical placement plus offset/uncertainty validation."
            ),
            "security_boundary": (
                "The controls reduce accidental overlap, stale execution, and ordinary local mutation; "
                "they are not a defense against a hostile administrator or equivalent local access."
            ),
        },
        "carried_analysis_components": {
            "master_suite": "v1.6.1 chain with v1.6.0 canonical core",
            "cai_sid": "v0.2 exploratory frozen candidate",
            "continuous_autonomic_respdualpath": "v1.0 exploratory",
            "micro_handoff": "v0.1 exploratory frozen candidate",
            "cue_locked_gamma_forensics": "v0.1 exploratory secondary confound extension",
        },
        "validation": {
            "status": validation_status,
            "declared_suite_count": tests.get("declared_suite_count"),
            "executed_suite_count": tests.get("executed_suite_count"),
            "reported_test_or_dry_run_count": tests.get("reported_test_count"),
            "catalog_acceptance_target": (
                f"{protocol_inventory['total_runnable_protocol_count']} total entries: "
                f"{protocol_inventory['native_protocol_count']} native plus "
                f"{protocol_inventory['atlas_protocol_count']} Atlas"
            ),
            "atlas_wrapper_acceptance_target": (
                f"{protocol_inventory['atlas_protocol_count']} of "
                f"{protocol_inventory['atlas_protocol_count']} individualized dry runs"
            ),
            "scope": "Software checks only; see BUILD_VALIDATION_v1_0_0_alpha_9_0_0.json.",
        },
        "not_validated_during_packaging": [
            "physical hardware",
            "ALS placement",
            "interactive PsychoPy display/audio/input/frame timing",
            "Atlas runner-internal EEG watchdog",
            "Atlas custom video safe-fit/letterboxing",
            "human feasibility",
            "external BIDS Validator",
            "analysis-only Docker execution",
            "construct, clinical, or confirmatory validity",
            "source-study equivalence",
            "privacy, licensing, claim-boundary, or publication approval for any user-built local results bundle",
        ],
        "public_exclusions": [
            "participant data",
            "private biosignals",
            "historical participant-level outputs",
            "copyrighted or restricted research media",
            "private source PDFs",
            "credentials",
            "local settings",
            "live acquisition logs",
        ],
        "retained_public_safe_method_metadata": [
            "deidentified Cue-Locked Gamma Forensics run labels and timing-anchor overrides; no signal samples, participant identity, responses, or outcome tables",
        ],
    }


def release_identity_check(package: Path) -> dict[str, Any]:
    """Fail closed on competing public artifacts or an inconsistent Alpha 9 identity."""
    required = (
        "README.md",
        "RELEASE_NOTES_v1_0_0_alpha_9_0_0.md",
        "INSTALL_PRAYCG_v1_0_0_alpha_9_0_0.bat",
        "run_PRAYCG_ControlCenter_v1_0_0_alpha_9_0_0.bat",
        "requirements_PRAYCG_v1_0_0_alpha_9_0_0.txt",
        VERSION_MANIFEST_NAME,
        "config/module_registry_v1_0_alpha_9.json",
        "config/analysis_orchestration_registry_v0_1.json",
        "config/hardware_adapter_catalog_v1_0.json",
        "config/analysis_module_registry_v0_1.json",
        "config/public_dataset_protocol_catalog_v1_0.json",
        "control_center/config/praycg_control_center_config_TEMPLATE_v1_0_0_alpha_9.json",
        "control_center/scripts/praycg_control_center_v1_0_0_alpha_9.py",
        "control_center/scripts/praycg_live_stream_monitor_v1_0.py",
        "control_center/scripts/praycg_protocol_stimulus_flow_v1_0.py",
        "platform_core/praycg_platform_core_v1_0_alpha_4.py",
        "tools/Protocol_AI_Doc_Builder_v0_1/praycg_protocol_ai_doc_builder_v0_1.py",
        "tools/Hardware_Workflow_v0_1/praycg_hardware_workflow_v0_1.py",
        "tools/Stimulus_Forge_Library_v1_0/config/stimulus_pack_catalog_v1_0.json",
        "tools/Hardware_Forge_v0_1/praycg_hardware_forge_v0_1.py",
        "tools/Hardware_Forge_v1_0/praycg_hardware_forge_v1_0.py",
        "tools/Hardware_Forge_v1_0/praycg_generic_lsl_intake_v1_0.py",
        "tools/Hardware_Forge_v1_0/praycg_stream_contract_v1_0.py",
        "tools/Hardware_Forge_v1_0/schemas/stream_contract_v1_0.schema.json",
        "tools/Hardware_Forge_v1_0/contracts/polar_h10_rr_v1_0.json",
        "tools/Acquisition_Supervisor_v1_0/praycg_acquisition_supervisor_v1_0.py",
        "tools/Analysis_Module_Catalog_v0_1/praycg_analysis_module_catalog_v0_1.py",
        "tools/Study_Workspace_v0_1/praycg_study_workspace_v0_1.py",
        "tools/Study_Workspace_v0_1/study_workspace_v0_1.schema.json",
        "tools/Analysis_Orchestrator_v0_1/praycg_analysis_orchestrator_v0_1.py",
        "tools/Analysis_Orchestrator_v0_1/praycg_run_integrity_qc_v0_1.py",
        "tools/Results_Bundle_Builder_v0_1/praycg_results_bundle_builder_v0_1.py",
        "README_MATURE_ENDPOINT_ATLAS_v1_0.md",
        "RUN_MATURE_ENDPOINT_VALIDATION_v1_0.bat",
        "VERSION_MANIFEST_MATURE_ENDPOINT_ATLAS_v1_0.json",
        "BUILD_VALIDATION_MATURE_ENDPOINT_ATLAS_v1_0.json",
        "TEST_EVIDENCE_MATURE_ENDPOINT_ATLAS_v1_0.json",
        "ATLAS_SMOKE_EVIDENCE_MATURE_ENDPOINT_ATLAS_v1_0.json",
        "config/praycg_mature_endpoint_atlas_catalog_v1_0.json",
        "tools/Mature_Endpoint_Evaluator_v1_0/praycg_mature_endpoint_evaluator_v1_0.py",
        "tools/ProtocolAtlas_ModuleLibrary_v2_0/tests/test_mature_endpoint_atlas_v1_0.py",
        "tools/ProtocolAtlas_ModuleLibrary_v2_0/experimental_imports_catalog_v1_0.json",
        "tools/ProtocolAtlas_ModuleLibrary_v2_0/tests/test_public_dataset_expansion_alpha8.py",
        "tools/Release_Validation_v0_1/praycg_mature_endpoint_extension_validator_v1_0.py",
    )
    missing = [item for item in required if not (package / item).is_file()]
    stale = [item for item in STALE_PUBLIC_ARTIFACTS if (package / item).exists()]
    generated_qc_artifacts = sorted(
        path.relative_to(package).as_posix()
        for path in (package / "docs").glob("render_alpha6_*")
        if path.exists()
    )
    errors: list[str] = []
    if package.name != RELEASE_PACKAGE:
        errors.append(f"package directory must be named {RELEASE_PACKAGE}")
    if missing:
        errors.append("missing required public artifacts")
    if stale:
        errors.append("prior-release public artifacts remain in the Alpha 9 package")
    if generated_qc_artifacts:
        errors.append("temporary document-render QA artifacts remain in the public package")
    try:
        manifest = _load_json_object(package / VERSION_MANIFEST_NAME)
        if manifest.get("package") != RELEASE_PACKAGE or manifest.get("version") != RELEASE_VERSION:
            errors.append("version manifest identity does not match Alpha 9")
        inventory = manifest.get("protocol_federation") or {}
        if inventory.get("atlas_protocol_count") != 40 or inventory.get("native_protocol_count") != 3:
            errors.append("version manifest must inventory 40 Atlas and 3 native protocols")
        if inventory.get("mature_endpoint_protocol_count") != 17:
            errors.append("version manifest must inventory 17 mature endpoint protocols")
        if inventory.get("public_dataset_protocol_count") != 12:
            errors.append("version manifest must inventory 12 public-dataset expansion protocols")
        if inventory.get("experimental_import_count") != 6:
            errors.append("version manifest must inventory 6 experimental imports")
    except Exception as exc:
        errors.append(f"version manifest could not be validated: {type(exc).__name__}: {exc}")
    try:
        registry = _load_json_object(package / "config" / "module_registry_v1_0_alpha_9.json")
        if registry.get("version") != RELEASE_VERSION:
            errors.append("module registry version does not match Alpha 9")
        federation = registry.get("protocol_federation") or {}
        if federation.get("atlas_entry_count") != 40 or federation.get("arbitrary_downloaded_code_allowed") is not False:
            errors.append("module registry Atlas count or arbitrary-code boundary is inconsistent")
        if federation.get("experimental_import_entry_count") != 6:
            errors.append("module registry must inventory 6 catalog-only experimental imports")
    except Exception as exc:
        errors.append(f"module registry could not be validated: {type(exc).__name__}: {exc}")
    try:
        public_catalog = _load_json_object(package / "config" / "public_dataset_protocol_catalog_v1_0.json")
        protocols = public_catalog.get("protocols")
        if (
            public_catalog.get("schema") != "PRAYCG_PublicDatasetProtocolCatalog_v1_0"
            or public_catalog.get("version") != RELEASE_VERSION
            or public_catalog.get("base_platform") != RELEASE_PACKAGE
            or public_catalog.get("protocol_count") != 12
            or not isinstance(protocols, list)
            or len(protocols) != 12
        ):
            errors.append("public-dataset protocol catalog identity or count is inconsistent")
    except Exception as exc:
        errors.append(f"public-dataset protocol catalog could not be validated: {type(exc).__name__}: {exc}")
    try:
        experimental = _load_json_object(
            package / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0" / "experimental_imports_catalog_v1_0.json"
        )
        candidates = experimental.get("candidates")
        if (
            experimental.get("schema") != "PRAYCG_ExperimentalProtocolImportCatalog_v1_0"
            or experimental.get("version") != RELEASE_VERSION
            or experimental.get("execution_authority") != "NONE_CATALOG_ONLY"
            or not isinstance(candidates, list)
            or len(candidates) != 6
        ):
            errors.append("experimental-import catalog identity, count, or authority is inconsistent")
        openmiir = next(
            (row for row in candidates or [] if isinstance(row, dict) and row.get("candidate_id") == "EXPERIMENTAL_OPENMIIR"),
            None,
        )
        if not openmiir or openmiir.get("status") != "BLOCKED_MEDIA_RIGHTS_AUDIT":
            errors.append("OpenMIIR must remain blocked pending a media-rights audit")
    except Exception as exc:
        errors.append(f"experimental-import catalog could not be validated: {type(exc).__name__}: {exc}")
    return {
        "status": "PASS" if not errors else "FAIL",
        "release_package": RELEASE_PACKAGE,
        "release_version": RELEASE_VERSION,
        "missing_required_artifacts": missing,
        "stale_public_artifacts": stale,
        "temporary_document_qc_artifacts": generated_qc_artifacts,
        "errors": errors,
    }


def _remove_regenerated_artifacts(package: Path, output: Path) -> list[str]:
    """Remove prior generated reports so the public scan cannot inspect stale output."""
    removed: list[str] = []
    candidates = [package / CHECKSUM_NAME]
    try:
        output.relative_to(package)
    except ValueError:
        pass
    else:
        candidates.append(output)
    for path in candidates:
        if path.is_file():
            path.unlink()
            removed.append(_display_path(path, package))
    return removed


def _overall_status(
    compile_ok: bool,
    tests: dict[str, Any],
    cleanup: dict[str, Any],
    scan: dict[str, Any],
    release_hygiene: dict[str, Any] | None = None,
    *,
    supported_python_target: bool = True,
) -> str:
    hygiene = release_hygiene or {"status": "PASS"}
    if (
        not compile_ok
        or tests["status"] == "FAIL"
        or cleanup["status"] == "FAIL"
        or hygiene["status"] == "FAIL"
        or scan["status"] == "INELIGIBLE"
    ):
        return "FAIL"
    if (
        tests["status"] != "PASS"
        or scan["status"] == "CAUTION"
        or not supported_python_target
    ):
        return "CAUTION_WITH_DECLARED_LIMITATIONS"
    return "PASS_WITH_DECLARED_LIMITATIONS"


def main() -> int:
    parser = argparse.ArgumentParser(description="PRAYCG Release Validator v0.1 (Alpha 9 release profile)")
    parser.add_argument("--package", type=Path, default=PACKAGE_ROOT)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--write-test-evidence", type=Path)
    parser.add_argument("--test-evidence", type=Path)
    args = parser.parse_args()
    package = args.package.resolve()
    output = (args.out or package / BUILD_VALIDATION_NAME).resolve()

    if args.write_test_evidence and args.test_evidence:
        parser.error("--write-test-evidence and --test-evidence are mutually exclusive")
    if args.write_test_evidence and args.skip_tests:
        parser.error("--write-test-evidence cannot be combined with --skip-tests")
    if args.write_test_evidence:
        evidence = write_automated_test_evidence(package, args.write_test_evidence.resolve())
        print(json.dumps(evidence, indent=2))
        return 0 if evidence["status"] == "PASS" else 2

    compile_ok = compileall.compile_dir(str(package), quiet=1, force=True, workers=1)
    if args.test_evidence:
        try:
            tests = load_automated_test_evidence(package, args.test_evidence.resolve())
        except Exception as exc:
            suites = declared_test_suites(package)
            tests = {
                "status": "FAIL",
                "declared_suite_count": len(suites),
                "executed_suite_count": 0,
                "reported_test_count": 0,
                "all_declared_suites_executed": False,
                "suites": [],
                "evidence_error": f"{type(exc).__name__}: {exc}",
            }
    else:
        tests = run_automated_tests(package, skip=args.skip_tests)
    bytecode_cleanup = remove_python_bytecode_caches(package)
    test_cache_cleanup = remove_generated_test_caches(package)
    regenerated_artifacts_removed = _remove_regenerated_artifacts(package, output)
    provisional_manifest = build_version_manifest(package, tests, validation_status="PENDING_FINAL_PUBLIC_SCAN")
    write_json(package / VERSION_MANIFEST_NAME, provisional_manifest)
    release_hygiene = release_identity_check(package)
    source_scan = scan_public_package(package, allowed_emails=["hoytbanks@gmail.com"])

    result: dict[str, Any] = {
        "schema": "PRAYCG_BuildValidation_v1_0_alpha_9_0_0",
        "version": RELEASE_VERSION,
        "generated_utc": utc_now(),
        "validation_scope": (
            "Software syntax compilation, the explicitly listed automated suites, generated-bytecode cleanup, "
            "public-package scanning, release-identity checks, and a package-file hash inventory."
        ),
        "python_compile": "PASS" if compile_ok else "FAIL",
        "validation_environment": {
            "python_version": platform.python_version(),
            "python_implementation": platform.python_implementation(),
            "supported_python_target": "3.11",
            "supported_python_target_exercised": sys.version_info[:2] == (3, 11),
            "operating_system": platform.system(),
            "machine": platform.machine(),
        },
        "automated_tests": tests,
        "bytecode_cleanup_before_public_scan": bytecode_cleanup,
        "generated_test_cache_cleanup_before_public_scan": test_cache_cleanup,
        "regenerated_artifacts_removed_before_scan": regenerated_artifacts_removed,
        "release_identity_and_hygiene": release_hygiene,
        "public_package_scan": source_scan,
        "pre_generated_report_scan_status": source_scan["status"],
        "optional_dependencies": optional_dependency_status(),
        "not_performed": {
            "physical_hardware_validation": "NOT_PERFORMED_REQUIRES_PHYSICAL_DEVICES_AND_OPERATOR",
            "new_adapter_bench_validation": "NOT_PERFORMED_ALL_IMPORTED_ADAPTERS_REMAIN_CATALOG_OR_SIMULATOR_ONLY",
            "generic_eda_ppg_physiological_validation": "NOT_PERFORMED_REQUIRES_EXACT_DEVICE_PROFILE_AND_PHYSICAL_SIGNAL",
            "human_connected_electrical_safety_review": "NOT_PERFORMED_REQUIRED_SEPARATELY_FOR_APPLICABLE_COMMUNITY_HARDWARE",
            "als_barcode_placement_validation": "NOT_PERFORMED_REQUIRES_PHYSICAL_DISPLAY_SENSOR_TEST",
            "ssvep_display_and_photodiode_validation": "NOT_PERFORMED_REQUIRES_PHYSICAL_60_HZ_DISPLAY_AND_ALS_SENSOR_TEST",
            "psychopy_end_to_end_validation": "NOT_PERFORMED_REQUIRES_INTERACTIVE_PROTOCOL_RUN",
            "analysis_only_docker_validation": "NOT_PERFORMED_BY_THIS_VALIDATOR",
            "external_bids_validator": "NOT_PERFORMED_BY_THIS_VALIDATOR",
            "human_feasibility_validation": "NOT_PERFORMED_REQUIRES_APPROVED_PILOT",
            "third_party_media_rights_review": "NOT_ASSESSED_BY_SOFTWARE_RELEASE_VALIDATION",
            "source_study_equivalence": "NOT_ASSESSED_BY_SOFTWARE_RELEASE_VALIDATION",
            "scientific_or_clinical_validity": "NOT_ASSESSED_BY_SOFTWARE_RELEASE_VALIDATION",
            "results_bundle_publication_review": "NOT_PERFORMED_BUILDER_IS_LOCAL_ONLY_AND_HAS_NO_UPLOAD_OR_PUBLICATION_AUTHORITY",
        }
    }
    combined_cleanup = {
        "status": "PASS"
        if bytecode_cleanup["status"] == "PASS" and test_cache_cleanup["status"] == "PASS"
        else "FAIL"
    }
    result["status"] = _overall_status(
        compile_ok,
        tests,
        combined_cleanup,
        source_scan,
        release_hygiene,
        supported_python_target=sys.version_info[:2] == (3, 11),
    )

    # Scan a provisional copy of this report too. This second pass prevents raw
    # captured test output from bypassing the public-package scan merely because
    # the validation report is generated by the validator itself.
    write_json(output, result)
    complete_scan = scan_public_package(package, allowed_emails=["hoytbanks@gmail.com"])
    result["public_package_scan"] = complete_scan
    result["status"] = _overall_status(
        compile_ok,
        tests,
        combined_cleanup,
        complete_scan,
        release_hygiene,
        supported_python_target=sys.version_info[:2] == (3, 11),
    )
    write_json(
        package / VERSION_MANIFEST_NAME,
        build_version_manifest(package, tests, validation_status=result["status"]),
    )

    inventory = inventory_hashes(package, exclude_names={output.name, CHECKSUM_NAME})
    result["hash_inventory"] = {
        "status": "GENERATED",
        "file_count": len(inventory),
        "artifact": CHECKSUM_NAME,
        "excludes": [output.name, CHECKSUM_NAME]
    }
    write_json(output, result)
    (package / CHECKSUM_NAME).write_text(
        "".join(f"{row['sha256']}  {row['path']}\n" for row in inventory),
        encoding="utf-8"
    )
    print(json.dumps(result, indent=2))
    if result["status"] == "PASS_WITH_DECLARED_LIMITATIONS":
        return 0
    if result["status"] == "CAUTION_WITH_DECLARED_LIMITATIONS":
        return 3
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
