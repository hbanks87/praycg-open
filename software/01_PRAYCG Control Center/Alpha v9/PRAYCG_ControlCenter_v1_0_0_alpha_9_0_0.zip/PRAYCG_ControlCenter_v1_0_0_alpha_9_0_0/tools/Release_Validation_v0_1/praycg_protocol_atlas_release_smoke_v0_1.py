#!/usr/bin/env python3
"""Dry-run every packaged Protocol Atlas module without acquisition side effects."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


BASE_EXPECTED_ATLAS_PROTOCOL_COUNT = 11
MATURE_EXTENSION_EXPECTED_ATLAS_PROTOCOL_COUNT = 40


def run(package: Path) -> dict:
    package = package.resolve()
    library = package / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0"
    scripts = library / "scripts"
    sys.path.insert(0, str(scripts))

    from praycg_protocol_atlas_core_v2_0 import discover_protocol_modules  # noqa: PLC0415
    from praycg_protocol_atlas_engine_v2_0 import dry_run_protocol  # noqa: PLC0415

    records, discovery_errors = discover_protocol_modules(library)
    failures: list[str] = list(discovery_errors)
    summaries: list[dict] = []
    expected_count = (
        MATURE_EXTENSION_EXPECTED_ATLAS_PROTOCOL_COUNT
        if (package / "VERSION_MANIFEST_MATURE_ENDPOINT_ATLAS_v1_0.json").is_file()
        else BASE_EXPECTED_ATLAS_PROTOCOL_COUNT
    )
    if len(records) != expected_count:
        failures.append(
            f"expected {expected_count} Atlas protocols, discovered {len(records)}"
        )

    child_environment = dict(os.environ)
    child_environment["PYTHONDONTWRITEBYTECODE"] = "1"
    for index, record in enumerate(records, start=1):
        try:
            first = dry_run_protocol(
                record,
                participant_id="PUBLIC_RELEASE_SMOKE",
                session_index=index,
            )
            second = dry_run_protocol(
                record,
                participant_id="PUBLIC_RELEASE_SMOKE",
                session_index=index,
            )
            checks = {
                "status": first.get("status") == "PASS",
                "deterministic_timeline": first.get("compiled_timeline") == second.get("compiled_timeline"),
                "no_runtime_authority": first.get("runtime_authority_exercised") is False,
                "no_psychopy": first.get("psychopy_exercised") is False,
                "no_hardware_effect": first.get("hardware_stack_effect") == "NONE",
                "individualized_runner_exists": record.runner_path.is_file(),
                "shared_engine_exists": record.engine_path.is_file(),
            }
            wrapper = subprocess.run(
                [sys.executable, str(record.runner_path), "--dry-run"],
                cwd=package,
                env=child_environment,
                capture_output=True,
                text=True,
                timeout=60,
            )
            checks["individualized_runner_exit_zero"] = wrapper.returncode == 0
            failed_checks = sorted(key for key, passed in checks.items() if not passed)
            if failed_checks:
                failures.append(f"{record.protocol_id}: " + ", ".join(failed_checks))
            summaries.append(
                {
                    "protocol_id": record.protocol_id,
                    "protocol_version": record.protocol_version,
                    "engine_family": record.engine_family,
                    "compiled_timeline_sha256": first.get("compiled_timeline", {}).get("canonical_sha256"),
                    "checks": checks,
                    "wrapper_stderr_tail": wrapper.stderr[-1000:] if wrapper.returncode else "",
                }
            )
        except Exception as exc:
            failures.append(f"{record.protocol_id}: {type(exc).__name__}: {exc}")

    return {
        "schema": "PRAYCG_ProtocolAtlasReleaseSmoke_v0_1",
        "status": "PASS" if not failures else "FAIL",
        "protocol_count": len(records),
        "wrapper_dry_run_count": sum(
            1
            for row in summaries
            if row.get("checks", {}).get("individualized_runner_exit_zero") is True
        ),
        "discovery_error_count": len(discovery_errors),
        "failures": failures,
        "protocols": summaries,
        "scope_boundary": (
            "Schema validation, deterministic timeline compilation, and individualized --dry-run entry only. "
            "No runtime authority, PsychoPy window, media playback, participant input, marker outlet, or hardware "
            "acquisition was exercised."
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = run(args.package)
    if args.output:
        output = args.output.resolve()
        output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
