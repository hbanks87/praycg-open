#!/usr/bin/env python3
"""Run the complete bundled PRAYCG regression suite and write evidence JSON."""
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00', 'Z')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.package.resolve()
    output = args.output.resolve()
    command = [
        sys.executable, '-m', 'pytest', '-q',
        'tools/Release_Validation_v0_1/tests',
        'control_center/tests',
        'tools/ProtocolAtlas_ModuleLibrary_v2_0/tests',
        'tools/MasterComprehensiveSuite_v1_6_1_CURRENT/tests',
        'tools/Micro_Handoff_v0_1/tests',
        'tools/Stimulus_Forge_Library_v1_0/tests',
        'tools/Hardware_Forge_v0_1/tests',
        'tools/Acquisition/Generic_EDA_PPG_Stream_Bridge_v0_1/tests',
        'tools/Analysis_Module_Catalog_v0_1/tests',
    ]
    env = dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    started = time.monotonic()
    proc = subprocess.run(command, cwd=root, env=env, text=True, capture_output=True, timeout=240)
    combined = f'{proc.stdout}\n{proc.stderr}'
    passed = re.search(r'(\d+) passed', combined)
    subtests = re.search(r'(\d+) subtests passed', combined)
    result = {
        'schema': 'PRAYCG_MatureEndpointAtlasTestEvidence_v1_0',
        'generated_utc': utc_now(),
        'package': root.name,
        'status': 'PASS' if proc.returncode == 0 else 'FAIL',
        'returncode': proc.returncode,
        'duration_seconds': round(time.monotonic() - started, 3),
        'reported_passed_test_count': int(passed.group(1)) if passed else None,
        'reported_passed_subtest_count': int(subtests.group(1)) if subtests else 0,
        'python_version': platform.python_version(),
        'command': ['python', *command[1:]],
        'stdout': proc.stdout,
        'stderr': proc.stderr,
        'scope_boundary': 'Bundled software regression tests only; no physical hardware, human participant, construct, clinical, or scientific validation.',
    }
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('status', 'reported_passed_test_count', 'reported_passed_subtest_count', 'duration_seconds')}, indent=2))
    return proc.returncode


if __name__ == '__main__':
    raise SystemExit(main())
