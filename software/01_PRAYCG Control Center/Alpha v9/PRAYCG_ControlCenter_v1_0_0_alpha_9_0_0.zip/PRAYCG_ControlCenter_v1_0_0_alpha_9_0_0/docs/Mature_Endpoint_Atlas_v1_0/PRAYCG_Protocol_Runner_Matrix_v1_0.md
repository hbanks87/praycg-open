# PRAYCG Mature Protocol Runner Matrix v1.0

The table below describes the 17 new mature PRAYCG modules. All remain feasibility/alpha candidates. Required hardware roles are semantic roles checked against the separately selected acquisition profile; a protocol cannot select or reconfigure hardware.

| # | Runner | Primary construct/contrast | Primary endpoint families | Required roles | Required assets | Claim cap |
| ---: | --- | --- | --- | --- | --- | --- |
| 1 | **PR-AYC-G Mature Meaning Gradient — Five-Arm Runner**<br>`ATLAS_PRAYCG_G_MATURE_GRADIENT` | narrative recognition, delayed integration, and resolutive recovery under layered sensory/task controls<br>**Contrast:** HighMeaning versus PhaseScrambled, ShotOrder, SemanticZero, and identical-stimulus AnalyticOverride | `MRED_RECOGNITION`, `MRED_INTEGRATION`, `MRED_RESOLUTION`, `A_MRED` | eeg, rr_intervals, respiration, markers | `phase_scrambled_video` (video); `shot_order_video` (video); `semantic_zero_video` (video); `target_override_video` (video); `reviewed_media_manifest` (trial_manifest); `locked_anchor_schedule` (anchor); `stimulus_fingerprint_manifest` (trial_manifest) | `EXPLORATORY_INTERESTING` |
| 2 | **PR-AYC-T Trust Offloading — Adult Dyad Feasibility Runner**<br>`ATLAS_PRAYCG_T_TRUST_OFFLOADING` | trusted-context reduction in calibrated load while preserving or improving performance<br>**Contrast:** TrustedPartnerSupport versus Solo, NeutralCopresence, and InformationMatchedComputer | `TOD_PRIMARY`, `TOD_RECOVERY`, `TOD_HUMAN_SPECIFICITY` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 3 | **PR-AYC-D Neutral Belief Update and Dissonance Runner**<br>`ATLAS_PRAYCG_D_NEUTRAL_BELIEF_UPDATE` | physiological mismatch and evidence-proportional belief updating in a neutral reversible domain<br>**Contrast:** post-evidence versus pre-evidence choice/confidence, stratified by evidence direction and transparent versus opaque source framing | `NORMATIVE_UPDATE`, `MISMATCH_LOAD`, `UPDATE_RECOVERY` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 4 | **API-A v2 Autonomic Availability, Mobilization, and Recovery Calibration**<br>`ATLAS_API_A_CALIBRATION_RECOVERY` | autonomic availability and recovery capacity under bounded perturbation<br>**Contrast:** challenge and regulation trajectories relative to subject-specific natural and paced-respiration baselines | `API_A_LEGACY`, `API_A_CAPACITY`, `API_A_MOBILIZATION`, `API_A_RECOVERY`, `API_A_CONFIDENCE` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 5 | **Gratitude Cardio-Affective Tensor Lite — Respiration-Controlled Runner**<br>`ATLAS_GRATITUDE_CARDIO_AFFECTIVE_LITE` | gratitude-related cardio-affective regulation after separating paced respiration<br>**Contrast:** (GratitudeNatural - NeutralNatural) and interaction with paced breathing | `G_INDUCTION`, `G_AUTONOMIC`, `G_RECOVERY` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 6 | **Gratitude–Neurochemical Tensor Experimental Protocol — Proxy-Bounded Full Runner**<br>`ATLAS_GRATITUDE_NEUROCHEMICAL_TENSOR_PROXY` | gratitude/rumination cardio-neural state trajectories under respiration control<br>**Contrast:** gratitude versus neutral and mild rumination, crossed with natural versus paced breathing | `G_PROXY`, `NNE_PROXY`, `QH_PROXY`, `THETA_PERSISTENCE`, `GNT_RECOVERY` | eeg, rr_intervals, respiration, eda, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 7 | **Unified Presence Availability — Anti-Circular Multimodal Runner**<br>`ATLAS_UNIFIED_PRESENCE_AVAILABILITY` | availability to receive, regulate, and integrate perturbation across report, autonomic, task, and EEG streams<br>**Contrast:** non-EEG availability predictor across neutral, paced, meaning, gratitude, and load conditions predicting independent theta persistence/recovery outcomes | `UPA_PREDICTOR`, `UPA_EEG_OUTCOME`, `UPA_RECOVERY`, `UPA_CONVERGENCE` | eeg, rr_intervals, respiration, markers | `meaning_video` (video); `meaning_anchor_schedule` (anchor); `meaning_stimulus_manifest` (trial_manifest) | `EXPLORATORY_INTERESTING` |
| 8 | **Biological Anchor Integration — Child-Safe Dyadic Feasibility Runner**<br>`ATLAS_BIOLOGICAL_ANCHOR_CHILD_SAFE` | safe parent/caregiver-child co-regulation and recovery<br>**Contrast:** responsive anchor presence and cooperative play versus neutral co-presence and caregiver paced-breathing control | `CHILD_RECOVERY`, `DIRECTIONAL_COUPLING`, `RESPONSIVE_BEHAVIOR` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 9 | **Father's Day Presence — Child-Safe Observational Runner**<br>`ATLAS_FATHERS_DAY_PRESENCE` | safe responsive father/caregiver-child play, recovery, and optional memory/meaning<br>**Contrast:** responsive play and cooperative repair versus neutral co-presence and caregiver paced-breathing control | `RELATIONAL_AVAILABILITY`, `CHILD_REENGAGEMENT`, `OPTIONAL_MEMORY_MEANING` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 10 | **Fractal Existence — Measured Human-Scale Longitudinal Runner**<br>`ATLAS_FRACTAL_EXISTENCE_MEASURED_SCALES` | cross-scale association among measured breath, trial, block, and session dynamics<br>**Contrast:** adjacent measured-scale coupling exceeding time-shifted, phase-randomized, label-shuffled, stimulus-shuffled, and pseudo-pair nulls | `LOCAL_LAYER_VALIDITY`, `ADJACENT_SCALE_COUPLING`, `SURROGATE_EXCEEDANCE`, `LONGITUDINAL_STABILITY` | eeg, rr_intervals, respiration, markers | `meaning_video` (video); `meaning_anchor_schedule` (anchor); `scale_definition_manifest` (trial_manifest) | `EXPLORATORY_INTERESTING` |
| 11 | **Thermodynamic Weight of Thought — Metabolic-Gated Feasibility Runner**<br>`ATLAS_THERMODYNAMIC_WEIGHT_THOUGHT` | excess independently measured metabolic energy during cognitive load after motor, respiration, and artifact correction<br>**Contrast:** high-conflict versus low-load and baseline after motor/respiration correction | `LOAD_PROXY`, `DELTA_E_REG`, `MASS_EQUIVALENT`, `LANDAUER_BOUND` | eeg, rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `CALIBRATION_ONLY` |
| 12 | **First-Person Presence and Physiology — Neurophenomenology Runner**<br>`ATLAS_FIRST_PERSON_PRESENCE` | first-person presence, availability, time density, and meaning linked to independent physiology<br>**Contrast:** within-person condition differences modeled beyond arousal, valence, effort, demand, and respiration | `PHENOMENOLOGY_PROFILE`, `PHYSIOLOGY_ASSOCIATION`, `REPORT_PHYSIOLOGY_DISSOCIATION`, `RECOVERY_CARRYOVER` | eeg, rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 13 | **Zero-State Baseline Calibration — Distribution and Uncertainty Runner**<br>`ATLAS_ZERO_STATE_BASELINE_CALIBRATION` | subject-specific baseline distributions and biome-conditioned uncertainty<br>**Contrast:** within-person differentiation of regulated rest from boredom, sleepiness, numbness, paced regulation, and neutral task demand | `BASELINE_DISTRIBUTION`, `STATE_DIFFERENTIATION`, `SAFE_PERTURBATION_REFERENCE` | eeg, rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 14 | **Personalized Safe Transition and Recovery Calibration**<br>`ATLAS_PERSONALIZED_TRANSITION_CALIBRATION` | subject-specific transition and recovery surfaces under bounded safe load<br>**Contrast:** multichannel prediction of performance/report degradation within safe conditions, validated on held-out blocks/sessions | `TRANSITION_PROBABILITY`, `RECOVERY_SURFACE`, `STOP_SAFETY` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 15 | **Rhythmic Autonomic Stabilization — Nonclinical Feasibility Runner**<br>`ATLAS_RHYTHMIC_AUTONOMIC_STABILIZATION` | nonclinical autonomic settling under simple rhythm and paced respiration<br>**Contrast:** steady rhythm and alternating cue conditions versus neutral rest and paced-breathing control | `RHYTHM_EFFECT`, `PACING_EFFECT`, `RHYTHM_RECOVERY` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |
| 16 | **PR-AYC-G Dyadic Narrative Hyperscanning — Mature Controlled Runner**<br>`ATLAS_PRAYCG_G_DYADIC_HYPERSCANNING` | inter-subject temporal persistence, meaning/update alignment, and dyadic recovery under layered common-drive controls<br>**Contrast:** HighMeaning versus PhaseScrambled, ShotOrder, SemanticZero, and identical-stimulus AnalyticOverride, with dyadic surrogate nulls | `DYAD_RECOGNITION`, `TAU_COH_THETA`, `UPDATE_VECTOR_ALIGNMENT`, `DYAD_RESOLUTION`, `COMMON_DRIVE_RESIDUAL` | eeg, rr_intervals, respiration, markers | `phase_scrambled_video` (video); `shot_order_video` (video); `semantic_zero_video` (video); `target_override_video` (video); `reviewed_media_manifest` (trial_manifest); `locked_anchor_schedule` (anchor); `stimulus_fingerprint_manifest` (trial_manifest) | `EXPLORATORY_INTERESTING` |
| 17 | **Conformity–Flow Boundary Layer — Safe Adult Feasibility Runner**<br>`ATLAS_CONFORMITY_FLOW_BOUNDARY_LAYER` | movement toward a disclosed group attractor versus flow-like low-resistance updating with preserved agency<br>**Contrast:** consensus emphasis versus low-pressure private update; near-skill neutral/open-monitoring versus self-monitoring, below-skill, and overload blocks | `C_H_TO_G`, `DELAYED_SELF_REVERSION`, `CONFORMITY_LOAD_RELIEF`, `FLOW_Z_H`, `REGIME_CLASSIFIER` | rr_intervals, respiration, markers | Generated/instruction-only; no required external stimulus asset. | `EXPLORATORY_INTERESTING` |

## Detailed module notes

### 1. PR-AYC-G Mature Meaning Gradient — Five-Arm Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/PRAYCG_G_mature_gradient_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_PRAYCG_G_MatureGradient_v2_0.py`  
**Source family:** PR-AYC-G narrative meaning and availability  
**Purpose:** Counterbalanced phase-scrambled, shot-order, semantic-zero, high-meaning, and identical-stimulus analytic-override branches with separate recognition, integration, and resolution endpoints.

**Minimum evidence:** EEG with artifact sentinels when available; RR intervals/HRV; respiration; flip-synchronized markers; immediate and delayed reports; asset/anchor hashes

**Manipulation checks:**

- Target meaning and recognition exceed semantic-zero and damaged controls
- Override analytic effort and final-sum compliance are adequate
- Target and Override asset hashes are identical
- Control audio and visual QC pass

**Falsification/constraint criteria:**

- Target does not exceed semantic-zero on meaning/recognition
- apparent endpoint disappears after sensory/artifact/respiration/gaze control
- Target and Override differ in rendered asset identity
- delayed effect is equally explained by prior-condition echo, fatigue, or task relief

**Readiness before a real feasibility run:**

- all seven assets selected and hash locked
- Target/Override same SHA-256
- control audio QC passed
- frame-verified anchors locked
- EEG/RR/respiration/marker streams visible
- artifact channels documented
- sequence ID frozen
- participant comfort and media consent confirmed

**Safety and claim boundaries:**

- This protocol tests psychophysiological state trajectories; it does not prove consciousness, objective meaning, empathy as a force, memory biology, quantum mechanisms, or clinical efficacy.
- Recognition, integration, and resolution are separate endpoints and may dissociate.
- A 90-second washout measures after-state; it is not assumed to reset physiology or cognition.
- Phase scrambling is a meaning-damaged sensory control, not a physiologically inert or perfect meaning-null condition.
- Target and Override must be the identical cue-embedded media file; instruction is the manipulation.

### 2. PR-AYC-T Trust Offloading — Adult Dyad Feasibility Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/PRAYCG_T_trust_offloading_v1_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_PRAYCG_T_TrustOffloading_v1_0.py`  
**Source family:** PR-AYC-T trust and regulated load sharing  
**Purpose:** Counterbalanced solo, neutral co-presence, standardized trusted-partner support, and information-matched computer support during objective low-stakes cognitive trials.

**Minimum evidence:** RR/ECG; respiration; flip-synchronized trial events; trial accuracy/RT; trust/support/effort reports

**Manipulation checks:**

- trusted condition raises felt trust/support without lowering compliance
- task accuracy and response coverage adequate
- partner follows standardized script

**Falsification/constraint criteria:**

- trusted support does not reduce load or improve recovery after performance adjustment
- computer cue performs equivalently and no human-specific effect remains
- effect is explained by respiration, task difficulty, or partner signaling
- trust induction fails

**Readiness before a real feasibility run:**

- two consenting adults
- standardized partner script rehearsed
- task practice completed
- RR/respiration/markers visible
- condition sequence frozen
- partner cannot see correct answers
- stop procedure understood

**Safety and claim boundaries:**

- This protocol must not be used to rank relationships, infer love, diagnose attachment, or judge a partner.
- Adults only for the default runner; no deception, humiliation, betrayal, or unreliable-partner manipulation is included.
- The endpoint is a calibrated psychophysiological load proxy, not literal joules unless independent metabolic measurement is added.
- A null or adverse response is not evidence that trust is absent in the relationship.

### 3. PR-AYC-D Neutral Belief Update and Dissonance Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/PRAYCG_D_neutral_belief_update_v1_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_PRAYCG_D_NeutralBeliefUpdate_v1_0.py`  
**Source family:** PR-AYC-D cognitive dissonance and safe belief updating  
**Purpose:** Neutral Bayesian-style evidence-update trials with trial-addressable initial choice, confidence, contradictory evidence, updated choice, confidence, and transparent-source comparison.

**Minimum evidence:** trial event/response logs; RR/ECG; respiration; initial and updated choices/confidence; post-task safety/mismatch report

**Manipulation checks:**

- initial choices and confidence recorded
- new evidence direction is frozen
- participant comprehends urn probabilities
- response coverage adequate

**Falsification/constraint criteria:**

- updates do not track evidence direction
- mismatch physiology is absent or fully explained by error/motor/respiration
- source framing effect disappears after comprehension
- delayed recovery absent or non-specific

**Readiness before a real feasibility run:**

- practice urn trial passed
- RR/respiration/markers visible
- compound trial engine dry run passed
- participant understands voluntary stopping
- trial seed frozen
- no identity-relevant content substituted

**Safety and claim boundaries:**

- The default task uses neutral probability judgments only; it must not be replaced with identity, political, religious, traumatic, humiliating, or high-stakes beliefs without a separately reviewed protocol.
- Belief updating is not a virtue score, intelligence test, or measure of moral worth.
- Physiological mismatch does not prove lying, guilt, truth, or pathology.
- The opaque-source condition withholds explanation but does not deceive participants about harm, identity, or social evaluation.

### 4. API-A v2 Autonomic Availability, Mobilization, and Recovery Calibration

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/API_A_calibration_recovery_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_API_A_CalibrationRecovery_v2_0.py`  
**Source family:** autonomic availability and regulatory recovery  
**Purpose:** Natural baseline, paced-respiration calibration, low/high cognitive challenge, recovery, affiliative regulation, and second recovery with coverage/confidence outputs.

**Minimum evidence:** RR intervals or raw ECG; respiration; markers; task performance; calm/safety/numbness/effort reports

**Manipulation checks:**

- paced breathing changes respiration as intended without distress
- high-load performance is above chance with higher effort than low load
- RR coverage and beat plausibility pass

**Falsification/constraint criteria:**

- index cannot distinguish regulated calm from numbness/sleepiness
- recovery metrics are unstable across repeat sessions
- respiration fully explains the apparent condition effect
- missingness/beat artifacts dominate

**Readiness before a real feasibility run:**

- valid RR stream with beat timestamps
- respiration stream visible
- marker stream visible
- seated low-risk task context
- task practice passed
- stop criteria reviewed

**Safety and claim boundaries:**

- API-A means autonomic availability proxy in this package, not presence, consciousness, mental health, consent, truth, or personal worth.
- The legacy scalar is retained for compatibility; v2 prioritizes mobilization, recovery, and confidence rather than a single rank.
- No diagnostic or treatment decision may be made from this protocol.
- Paced breathing must remain comfortable and must stop for dizziness or distress.

### 5. Gratitude Cardio-Affective Tensor Lite — Respiration-Controlled Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Gratitude_cardio_affective_lite_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_Gratitude_CardioAffective_Lite_v2_0.py`  
**Source family:** gratitude cardio-affective physiology  
**Purpose:** Four counterbalanced neutral/gratitude by natural/paced-breathing conditions for autonomic and report endpoints without direct neurochemical inference.

**Minimum evidence:** RR/ECG; respiration; condition markers; gratitude/warmth/arousal/calm reports

**Manipulation checks:**

- gratitude report exceeds neutral
- paced conditions change respiratory timing
- no dizziness/distress

**Falsification/constraint criteria:**

- gratitude induction fails
- effect is fully explained by paced breathing
- autonomic change occurs without gratitude/warmth difference
- result does not replicate within participant

**Readiness before a real feasibility run:**

- RR and respiration streams visible
- comfortable 0.1 Hz breathing practice
- safe non-traumatic gratitude memory selected
- condition sequence frozen
- stop rights understood

**Safety and claim boundaries:**

- This Lite protocol does not estimate norepinephrine, serotonin, oxytocin, dopamine, cortisol, or any other neurochemical concentration.
- Gratitude ratings and HRV do not measure moral character, relationship quality, spirituality, or clinical benefit.
- Paced breathing is a control and intervention component; its contribution must be modeled rather than subtracted as mere noise.

### 6. Gratitude–Neurochemical Tensor Experimental Protocol — Proxy-Bounded Full Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Gratitude_neurochemical_tensor_proxy_full_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_Gratitude_NeurochemicalTensor_ProxyFull_v2_0.py`  
**Source family:** gratitude neurochemical tensor hypothesis translated to observable proxy endpoints  
**Purpose:** Six-condition neutral/gratitude/mild-rumination by natural/paced-breathing design with EEG, autonomic, EDA, artifact, and recovery endpoints; neurochemical claims remain unavailable without direct assays.

**Minimum evidence:** EEG; RR/ECG; respiration; EDA; markers; condition reports; EOG/EMG or artifact sentinels strongly recommended

**Manipulation checks:**

- gratitude and rumination reports separate as intended
- paced breathing changes respiration
- distress remains within preregistered safe bounds
- EEG artifact gates pass

**Falsification/constraint criteria:**

- theta endpoint is explained by respiration, EMG/EOG, ECG leakage, motion, or line noise
- gratitude induction fails
- proxy predictors reuse EEG outcome features
- rumination condition causes unacceptable distress
- effects do not survive condition order/carryover model

**Readiness before a real feasibility run:**

- EEG/RR/respiration/EDA/markers visible
- EOG/EMG or artifact limitations documented
- safe gratitude and low-stakes unfinished-task prompts selected
- paced breathing practice tolerated
- sequence locked
- distress stop rule reviewed

**Safety and claim boundaries:**

- The words norepinephrine, serotonin, oxytocin, dopamine, and cortisol may appear only as unvalidated latent/proxy hypotheses unless directly assayed.
- EEG/HRV/EDA cannot identify a neurotransmitter concentration.
- The mild-rumination prompt must remain low stakes and non-traumatic; participants may substitute neutral thought or stop immediately.
- No clinical benefit, moral worth, or spiritual claim is permitted.

### 7. Unified Presence Availability — Anti-Circular Multimodal Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Unified_presence_availability_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_UnifiedPresence_Availability_v2_0.py`  
**Source family:** unified presence / availability construct validation  
**Purpose:** Counterbalanced neutral, paced-regulation, meaningful-media, gratitude, and cognitive-load blocks with a non-EEG availability predictor and independent EEG outcome.

**Minimum evidence:** EEG; RR/ECG; respiration; markers; task accuracy/RT; presence/meaning/safety/numbness reports; asset anchors

**Manipulation checks:**

- conditions differ on intended report/task dimensions
- meaning media is accessible
- paced breathing works
- load task performance adequate

**Falsification/constraint criteria:**

- UPA predicts EEG only when EEG-derived features leak into predictor
- effects disappear after respiration/artifact/sensory control
- one condition drives all apparent cross-condition association
- report and physiology systematically contradict without modeled explanation

**Readiness before a real feasibility run:**

- meaning video and anchors hash locked
- EEG/RR/respiration/markers visible
- artifact sentinels documented
- task practice passed
- sequence frozen
- anti-circular feature list preregistered

**Safety and claim boundaries:**

- Unified Presence is a construct-validation program, not a consciousness meter, personhood score, diagnostic index, or spiritual ranking.
- The predictor and EEG outcome must remain mathematically separate.
- Disagreement between report and physiology is a result to explain, not permission to override the participant.

### 8. Biological Anchor Integration — Child-Safe Dyadic Feasibility Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Biological_anchor_child_safe_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_BiologicalAnchor_ChildSafe_v2_0.py`  
**Source family:** child-safe dyadic co-regulation and biological anchor  
**Purpose:** Guardian-consented, child-assented observational co-regulation protocol with neutral co-presence, caregiver paced breathing, responsive anchor presence, cooperative play, and positive close.

**Minimum evidence:** time-synchronized parent and child labels; at least parent physiology plus child behavior; respiration; markers; assent/stop events; blinded behavioral coding when video is used

**Manipulation checks:**

- child assent remains positive
- responsive behavior differs from neutral/paced control
- task difficulty and motion documented
- dual-stream identities verified

**Falsification/constraint criteria:**

- child distress or withdrawal occurs
- effect is explained by motion/task or caregiver breathing alone
- directional result does not exceed reverse/time-shift/pseudo-dyad nulls
- privacy/stream identity uncertain

**Readiness before a real feasibility run:**

- guardian consent and child assent
- age-appropriate explanation
- stream identities physically traced
- privacy/retention plan
- play materials selected
- stop signal practiced
- operator trained to prioritize child behavior over data

**Safety and claim boundaries:**

- Child safety and assent supersede protocol completion; stop immediately for distress, withdrawal, freezing, or a desire to leave.
- No forced eye contact, touch, affection, disclosure, frustration, attachment test, or relationship ranking is permitted.
- Physiology cannot determine whether a child loves, trusts, consents, tells the truth, or has a secure attachment.
- Video/audio require explicit consent, restricted access, de-identification/retention rules, and no public release.

### 9. Father's Day Presence — Child-Safe Observational Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Fathers_day_presence_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_FathersDay_Presence_v2_0.py`  
**Source family:** father/caregiver-child relational presence and play  
**Purpose:** Neutral co-presence, caregiver paced-breathing control, responsive play, cooperative puzzle/repair, positive close, and optional age-appropriate recall endpoints.

**Minimum evidence:** condition markers; caregiver physiology; child behavior and assent; respiration; operator coding; child physiology only if tolerated

**Manipulation checks:**

- responsive behavior differs from neutral/paced condition
- child remains comfortable and willing
- puzzle difficulty/motion documented

**Falsification/constraint criteria:**

- child distress/withdrawal
- paced breathing explains the effect
- task/motion explains the effect
- recall prompt is leading or privacy-sensitive
- result fails pseudo-dyad/time-shift control when dyadic physiology is analyzed

**Readiness before a real feasibility run:**

- guardian consent and child assent
- privacy/retention plan
- age-appropriate activities
- sensor tolerance checked
- stop signal practiced
- positive close guaranteed

**Safety and claim boundaries:**

- No calculation may assign mass, thermodynamic weight, value, or quality to love, fatherhood, parenting, or a relationship.
- Child assent and comfort override completion; no forced affection, touch, eye contact, disclosure, competition, or frustration.
- This is not a custody, parenting fitness, attachment, truth, or developmental diagnostic tool.
- Sensitive family video/audio must not be publicly released.

### 10. Fractal Existence — Measured Human-Scale Longitudinal Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Fractal_existence_measured_scales_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_FractalExistence_MeasuredScales_v2_0.py`  
**Source family:** multi-scale Presence Functional and cross-scale self-similarity  
**Purpose:** Three-session breath-cycle, trial, block, and session-scale protocol with cross-scale models and surrogate tests; unmeasured biological/cosmic scales are explicitly excluded.

**Minimum evidence:** EEG; RR/ECG; respiration; markers; trial performance; session reports; frozen scale/window/lag definitions

**Manipulation checks:**

- each local scale endpoint is measurable
- session timing and assets stable
- sufficient repeated observations per scale
- lag window physiology justified

**Falsification/constraint criteria:**

- local layer model fails
- cross-scale coupling does not exceed nulls
- best lags are arbitrary/outside preregistered range
- component-vector scaling fails even if scalar composite correlates
- result driven by common stimulus/respiration/artifact

**Readiness before a real feasibility run:**

- three-session commitment and spacing plan
- scale definition manifest frozen
- EEG/RR/respiration/markers visible
- meaning asset/anchors hash locked
- artifact and surrogate code frozen
- session index correctly set

**Safety and claim boundaries:**

- This runner tests only measured human timescales; it cannot support claims about quantum, molecular, cellular, planetary, cosmic, soul, or universal scales.
- Cross-scale correlation is not fractality unless it exceeds preregistered nulls and component-level scaling supports the scalar projection.
- Optional Hurst/multifractal metrics remain exploratory unless independently preregistered.

### 11. Thermodynamic Weight of Thought — Metabolic-Gated Feasibility Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Thermodynamic_weight_thought_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_ThermodynamicWeightThought_v2_0.py`  
**Source family:** cognitive load, metabolic energy contrast, and bounded mass-equivalent translation  
**Purpose:** Baseline, motor, respiration, low-load, and high-conflict blocks with strict separation between psychophysiological load proxies and independently measured metabolic energy.

**Minimum evidence:** EEG; RR/ECG; respiration; markers; task accuracy/RT; effort/conflict report; independent calibrated metabolic power for thermodynamic endpoints

**Manipulation checks:**

- high-conflict task is harder than low load
- motor and respiration controls are valid
- metabolic stream units/calibration/timing documented when used

**Falsification/constraint criteria:**

- no independent metabolic measurement but thermodynamic claim attempted
- condition energy difference vanishes after motor/respiration/artifact correction
- load functional does not predict independent metabolic power
- effect fails replication

**Readiness before a real feasibility run:**

- EEG/RR/respiration/markers visible
- motor and task practice passed
- stop criteria reviewed
- metabolic calibration manifest supplied only when a real synchronized calibrated stream exists
- analysis plan freezes baseline/motor/respiration corrections

**Safety and claim boundaries:**

- EEG, HRV, respiration, EDA, and task performance do not directly measure ATP use, caloric expenditure, or the mass of a thought.
- Mass-equivalent values may be calculated only from independently measured/calibrated energy contrasts and refer to that energy contrast, never an idea, person, love, consciousness, or worth.
- Landauer calculations are theoretical bounds, not counts of psychological bits erased.
- No gravitational fluctuation or information-mass claim is supported by this runner.

### 12. First-Person Presence and Physiology — Neurophenomenology Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/First_person_presence_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_FirstPersonPresence_v2_0.py`  
**Source family:** neurophenomenology of presence and availability  
**Purpose:** Rest, external attention, interoception, cognitive load, safe meaningful recall, and recovery with non-leading block-level experience reports.

**Minimum evidence:** EEG; RR/ECG; respiration; markers; block reports; task performance

**Manipulation checks:**

- reports show adequate variance and confidence
- load task compliance adequate
- meaning recall remains safe and self-selected

**Falsification/constraint criteria:**

- associations reduce to arousal/valence/effort/respiration
- demand characteristics explain reports
- report confidence is too low
- physiology is used to override stated experience

**Readiness before a real feasibility run:**

- non-leading report prompts reviewed
- EEG/RR/respiration/markers visible
- task practice passed
- privacy plan for free text
- safe recall prompt selected
- stop rights understood

**Safety and claim boundaries:**

- First-person report is an independent evidence stream, not proof of mechanism; physiology is also not proof of subjective experience.
- No physiological metric may override a participant’s stated experience, consent, distress, or wish to stop.
- Meaningful recall must remain safe and participant-selected; no trauma disclosure is required.

### 13. Zero-State Baseline Calibration — Distribution and Uncertainty Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Zero_state_baseline_calibration_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_ZeroStateCalibration_v2_0.py`  
**Source family:** subject-specific baseline manifold calibration  
**Purpose:** Eyes-open/closed rest, paced respiration, neutral task, and recovery for subject-specific baseline distributions that distinguish calm from boredom, sleepiness, and numbness.

**Minimum evidence:** EEG; RR/ECG; respiration; markers; calm/numbness/boredom/sleepiness reports; task performance

**Manipulation checks:**

- stable stream coverage
- reports distinguish at least some states
- environment documented
- repeat session feasible

**Falsification/constraint criteria:**

- baseline unstable without identifiable cause
- rest/boredom/numbness cannot be separated
- first-person reports systematically contradict model with no account
- repeat sessions fail to reproduce distributions

**Readiness before a real feasibility run:**

- quiet environment documented
- EEG/RR/respiration/markers visible
- eyes-closed safety checked
- task practice passed
- repeat-session plan documented

**Safety and claim boundaries:**

- No person may be ranked by a zero-state baseline; it is a personal reference distribution with uncertainty.
- The protocol is not diagnostic and cannot be used for employment, school, insurance, custody, policing, or spiritual ranking.
- Eyes-closed rest may be stopped immediately for discomfort or sleepiness.

### 14. Personalized Safe Transition and Recovery Calibration

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Personalized_transition_calibration_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_PersonalizedTransitionCalibration_v2_0.py`  
**Source family:** safe cardio-cognitive transition mapping  
**Purpose:** Baseline, paced regulation, low and moderate cognitive load, operator safety gates, positive regulation, and recovery for uncertainty-bounded transition surfaces without seeking unsafe thresholds.

**Minimum evidence:** RR/ECG; respiration; markers; task accuracy/RT; distress/overwhelm/dizziness/agency/willingness reports

**Manipulation checks:**

- task difficulty increases performance demand without unsafe distress
- operator gates completed
- participant agency remains high

**Falsification/constraint criteria:**

- model is no better than HR alone
- transition surface fails held-out task/session
- calm cannot be separated from freeze/numbness/compliance
- thresholds unstable without identifiable cause
- any unsafe escalation occurs

**Readiness before a real feasibility run:**

- setting-appropriate screening complete
- RR/respiration/markers visible
- operator stop rules in writing
- participant stop signal practiced
- task practice passed
- positive recovery plan ready

**Safety and claim boundaries:**

- No participant is pushed toward panic, trauma, severe distress, chest pain, severe breathlessness, unsafe blood pressure, or a lethal/clinical threshold.
- A stop request ends the protocol immediately; physiological appearance never overrides consent or subjective distress.
- Thresholds are not moral, diagnostic, employment, insurance, custody, policing, or spiritual scores.
- This alpha runner uses cognitive load only; physical and social-evaluation ladders require separate medical/ethics review.

### 15. Rhythmic Autonomic Stabilization — Nonclinical Feasibility Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Rhythmic_autonomic_stabilization_v1_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_RhythmicAutonomicStabilization_v1_0.py`  
**Source family:** rhythmic autonomic stabilization  
**Purpose:** Neutral rest, steady visual rhythm, paced breathing, alternating left/right visual cues, and recovery without trauma-memory activation or therapeutic claims.

**Minimum evidence:** RR/ECG; respiration; markers; calm/effort/dizziness/distress reports

**Manipulation checks:**

- rhythm viewed as instructed
- paced breathing changes respiration
- no visual/breath discomfort

**Falsification/constraint criteria:**

- rhythm effect equals paced breathing effect after respiration adjustment
- effect is explained by visual discomfort or gaze movement
- no recovery difference
- distress/dizziness invalidates condition

**Readiness before a real feasibility run:**

- RR/respiration/markers visible
- visual comfort checked
- comfortable breathing practice
- stop criteria reviewed
- condition sequence frozen

**Safety and claim boundaries:**

- This runner is nonclinical and contains no trauma-memory recall, exposure, reconsolidation, bilateral-stimulation therapy, or treatment claim.
- Do not use it for PTSD or trauma treatment outside a separately approved clinician-supervised study.
- Stop immediately for dizziness, visual discomfort, distress, or breathing discomfort.

### 16. PR-AYC-G Dyadic Narrative Hyperscanning — Mature Controlled Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/PRAYCG_G_dyadic_hyperscanning_v2_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_PRAYCG_G_DyadicHyperscanning_v2_0.py`  
**Source family:** PR-AYC-G dyadic narrative meaning, update-vector alignment, and inter-subject temporal persistence  
**Purpose:** Two-participant phase-scrambled, shot-order, semantic-zero, intact high-meaning, and identical-stimulus analytic-override runner with inter-subject persistence and separate report/recovery endpoints.

**Minimum evidence:** two synchronized EEG streams; two RR streams; two respiration streams when available; shared flip-synchronized markers; participant-specific immediate/delayed reports; asset/anchor hashes; stimulus fingerprint regressors

**Manipulation checks:**

- high-meaning recognition exceeds semantic-zero and damaged controls
- analytic-override task compliance adequate for both participants
- Target and Override are bit-identical
- participant streams and reports are never swapped
- surrogate/null model frozen before analysis

**Falsification/constraint criteria:**

- effect is reproduced by shared sensory regressors or common respiration
- effect is localized to paired artifact/motion/gaze
- participant identity or stream mapping is ambiguous
- Target does not exceed meaning controls
- dyadic structure does not exceed circular-shift/phase-randomized surrogate nulls

**Readiness before a real feasibility run:**

- two consenting adults and two pseudonyms
- two EEG streams with fixed channel maps
- two RR streams
- two respiration streams when available
- participant/stream identity trace and photos
- artifact channels documented for both participants
- all seven media/QC assets hash locked
- Target and Override same SHA-256
- control audio/visual QC passed
- frame-verified anchors
- surrogate/null plan frozen
- sequence frozen

**Safety and claim boundaries:**

- Inter-subject synchrony is not empathy, shared consciousness, telepathy, quantum coupling, truth, love, or relationship quality.
- This runner requires two independently consented adults and must not be used to rank couples, families, coworkers, or compatibility.
- A common stimulus and common room can generate common timing; sensory, respiratory, motion, gaze, and artifact explanations are tested first.
- Participant-specific reports remain primary evidence about each person’s experience; one participant’s physiology does not reveal the other’s private state.

### 17. Conformity–Flow Boundary Layer — Safe Adult Feasibility Runner

**Manifest:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/protocols/Conformity_flow_boundary_layer_v1_0.json`  
**Runner:** `tools/ProtocolAtlas_ModuleLibrary_v2_0/scripts/run_ConformityFlow_BoundaryLayer_v1_0.py`  
**Source family:** conformity pressure, adaptive coordination, challenge–skill fit, self-monitoring, and flow  
**Purpose:** Disclosed simulated-consensus updating plus below/near/above-skill and self-monitoring/open-monitoring task blocks, with delayed private rechecks and agency-preserving flow endpoints.

**Minimum evidence:** trial-level first/group/revised/delayed judgments; task accuracy/RT; RR/ECG; respiration; markers; pressure/authenticity/agency/flow/overload reports

**Manipulation checks:**

- consensus-emphasis raises perceived pressure without coercion
- near-skill block is better matched than below/above blocks
- self-monitoring instruction raises self-evaluation
- open-monitoring instruction preserves agency
- task performance remains above chance

**Falsification/constraint criteria:**

- group shift is not predicted by group distance or consensus emphasis
- alignment provides no immediate relief and no delayed mismatch pattern
- full flow model does not outperform challenge–skill fit alone
- self-monitoring and overload do not predict flow exits
- regime classifier cannot exceed preregistered chance/surrogate performance

**Readiness before a real feasibility run:**

- healthy consenting adult sample
- no authority-dependent recruitment
- disclosed simulated consensus approved
- private response environment
- task practice complete
- RR/respiration/markers visible
- stop/debrief procedure ready
- condition sequence frozen

**Safety and claim boundaries:**

- This protocol must not be used for persuasion, political targeting, recruitment, discipline, employment, schooling, vulnerability detection, or character ranking.
- The default runner uses disclosed simulated prior-pilot consensus and private responses; it excludes humiliation, exclusion, shaming, public exposure, and authority coercion.
- Flow scores do not measure Zen, enlightenment, spiritual superiority, productivity worth, or mental health.
- Alignment can be adaptive coordination or identity-conflicting conformity; the protocol must report authenticity, agency, and delayed private response rather than treating movement as good or bad.

