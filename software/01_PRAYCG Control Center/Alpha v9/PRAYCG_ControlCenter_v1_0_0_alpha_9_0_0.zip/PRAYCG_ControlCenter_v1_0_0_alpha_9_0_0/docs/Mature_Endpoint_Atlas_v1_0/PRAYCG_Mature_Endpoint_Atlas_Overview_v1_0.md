# PRAYCG Mature Endpoint Atlas v1.0

## Purpose

This extension converts the retained PRAYCG conceptual protocols into governed Protocol Atlas modules that can be dry-run, session-locked, launched, event-marked, and handed to a separate analysis workflow. It is integrated into **PRAYCG Control Center v1.0.0-alpha.8**, not a claim that the protocols are scientifically validated.

The extension still contributes **17 mature PRAYCG runners**. Alpha.8 also includes 12 public-dataset adaptations, so the federated Control Center now discovers **43 runnable protocol entries: 3 native + 40 Atlas**.

The central change is not simply “more endpoints.” It is a stricter separation of:

1. **Recognition** — what was accessed or understood during/immediately after a condition;
2. **Integration** — what persists or reorganizes during a delayed window;
3. **Resolution/recovery** — how the system settles, remains activated, or fails to return;
4. **Manipulation validity** — whether the intended condition actually occurred;
5. **Endpoint availability** — whether timing, signal, artifact, respiration, task, order, and special-measurement gates passed; and
6. **Claim grade** — the strongest interpretation permitted by the frozen manifest and observed evidence.

A failed manipulation, missing stream, unassessed confound, or unavailable special measurement is not converted into a positive composite. It produces a bounded result such as `NOT_EVALUABLE`, `CONFOUNDED_USEFUL`, `CALIBRATION_ONLY`, or `FAIL_NULL`.

## What was added

- 17 declarative Atlas manifests with explicit endpoint contracts;
- 17 individualized thin runner wrappers using the shared Atlas engine;
- a five-arm mature PR-AYC-G meaning-gradient runner;
- a separate two-participant PR-AYC-G hyperscanning runner;
- safe adult PR-AYC-T trust-offloading and PR-AYC-D neutral belief-update runners;
- API-A v2 calibration/mobilization/recovery;
- Lite and proxy-bounded full gratitude runners;
- anti-circular Unified Presence, child-safe Biological Anchor, Father’s Day observational, measured-scale Fractal Existence, and metabolic-gated Thermodynamic Weight of Thought runners;
- first-person presence, zero-state, safe transition, rhythmic autonomic, and Conformity–Flow runners;
- a data-only compound-trial extension for trial-addressable choice, confidence, evidence, revised choice, and feedback sequences; and
- a Mature Endpoint Evaluator that audits run structure and claim ceilings without inventing physiology.

## Non-negotiable scientific boundary

The new software can schedule conditions and record evidence. It does not prove consciousness, objective meaning, empathy as a physical force, neurochemical concentrations, molecular memory, quantum mechanisms, thermodynamic mass of ideas, clinical efficacy, moral character, relationship quality, spiritual rank, or metaphysical truth.

The package uses the strongest observable translation currently defensible:

- reports remain reports;
- behavior remains behavior;
- physiology remains physiology;
- direct molecular/metabolic claims require direct independent measurements;
- between-person synchrony must survive common-drive and surrogate controls; and
- theoretical translation layers remain separate from empirical conclusions.

## Software status

Every added manifest is labeled `SOFTWARE_ALPHA_CANDIDATE` and is approved only for software alpha dry-run and feasibility preparation. `APPROVED_FOR_ALPHA_TEST` is not IRB approval, clinical approval, apparatus validation, or source-study equivalence.

## Where to start

Read these documents in order:

1. `PRAYCG_Mature_Endpoint_Atlas_Execution_Guide_v1_0.md`
2. `PRAYCG_Protocol_Runner_Matrix_v1_0.md`
3. `PRAYCG_Endpoint_Definitions_and_Decision_Rules_v1_0.md`
4. `PRAYCG_Deferred_Protocol_Register_v1_0.md`
5. `PRAYCG_ProtocolAtlas_Compound_Trials_v1_0.md`

The machine-readable catalog is `config/praycg_mature_endpoint_atlas_catalog_v1_0.json`.
