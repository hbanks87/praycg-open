# PRAYCG Mature Endpoint Atlas Execution Guide v1.0

## 1. Install and launch

1. Extract the complete package to a writable folder.
2. Run `INSTALL_PRAYCG_v1_0_0_alpha_8_5_4.bat` on Windows with Python 3.11 available.
3. Launch `run_PRAYCG_ControlCenter_v1_0_0_alpha_8_5_4.bat`.
4. Use **Settings** to confirm the bundled paths, PsychoPy interpreter, and LabRecorder path if used.

The mature extension does not change the Control Center’s acquisition-authority sequence.

## 2. Choose the protocol

In **Choose Protocol**, select the intended runner, review its summary, and click **Use This Protocol**. This confirms the reviewed protocol design; it does not start equipment or authorize acquisition.

## 3. Prepare materials

In **Prepare Materials**, every operator-supplied input appears as a separate named row. Use **Choose File** or **Choose Folder** for that exact role. Do not rely on filenames or a shared folder to assign several similar inputs.

If the page says **Ready — this file-selection step is skipped**, the protocol generates its own visuals or prompts. Rhythmic Autonomic Stabilization is one such protocol and does not need a separately locked stimulus. Native PRAYCG protocols use the compatible prepared-materials list on the same page.

For mature PR-AYC-G, the named rows are:

- phase-scrambled control;
- shot-order control;
- semantic-zero control;
- one shared target/override video;
- reviewed media/QC manifest;
- frame-verified anchor schedule; and
- stimulus fingerprint.

The target and analytic override use the single **Shared target / override video** binding. Only the instruction changes.

## 4. Connect equipment independently

In **Connect & Check Equipment**, select a reviewed hardware profile. The protocol’s required roles are checked against that profile, but the protocol cannot choose, start, or reconfigure hardware.

Typical roles are:

- `eeg`
- `eog` / `emg` artifact sentinels where available
- `rr_intervals` or raw ECG
- `respiration`
- `eda`
- `markers`

Dyadic PR-AYC-G requires two independently labeled participant stream sets even though the Atlas hardware-role vocabulary is generic. The operator must preserve participant/stream identity in the acquisition profile and run evidence.

## 5. Run the 30-second check

Before confirming the session setup:

- confirm every required stream is visible;
- confirm plausible sample rate and timestamps;
- check flatline, clipping, non-finite values, gaps, and beat plausibility;
- document EOG/EMG/motion/gaze availability;
- confirm respiration belt direction and usable amplitude;
- confirm marker visibility;
- verify participant comfort, stop signal, and condition-specific safety rules; and
- perform any protocol-specific manipulation practice.

A visible stream is not automatically a scientifically adequate stream.

## 6. Dry-run the runner

Each new runner can be compiled without acquisition authority:

```bat
py -3.11 tools\ProtocolAtlas_ModuleLibrary_v2_0\scripts\run_PRAYCG_G_MatureGradient_v2_0.py --dry-run --participant-id TEST01 --session-index 1
```

Dry-run checks schema, wrapper binding, deterministic compilation, sequence assignment, and timeline identity. It does not open external assets, validate physical hardware, establish real frame/audio timing, or test participant feasibility.

## 7. Confirm the governed session

In **Connect & Check Equipment**, choose **Confirm Session Setup**, review readiness, and then choose **Mark Ready to Run**. These operator labels preserve the technical authority sequence:

Follow the Control Center sequence:

`SELECT → CONNECT → PREFLIGHT → SESSION_LOCK → ARM → ACQUIRE → FINALIZE → QC → ANALYZE → EXPORT → VERIFY`

The session lock binds:

- protocol manifest, runner, engine, and hashes;
- participant pseudonym and session index;
- assigned deterministic timeline/sequence;
- selected asset paths and hashes;
- reviewed hardware-profile snapshot; and
- run UUID and authority lease.

A changed asset, protocol, runner, engine, participant/session binding, or timeline requires a new lock.

## 8. During acquisition

- Follow the exact operator/participant scripts.
- Do not improvise a stronger social, emotional, breathing, cognitive, child, or dyadic manipulation.
- A stop request ends the run.
- Log deviations and interrupted blocks.
- Treat washouts as measured after-state windows, not guaranteed resets.
- For dyadic work, preserve participant A/B labels and note any stream swap, electrode adjustment, talking, shared movement, or partner cueing.

## 9. Finalize and preserve evidence

Preserve the run-local:

- immutable session lock;
- event CSV/JSON;
- response JSON;
- run state/checkpoint;
- acquisition files;
- stream/QC evidence;
- media and anchor hashes;
- operator deviations; and
- finalized artifact hashes.

Interrupted runs are incomplete evidence. Resume is disabled; repeat with a new UUID and new lock.

## 10. Analyze in two layers

### Layer A — structural/readiness audit

Use the Mature Endpoint Evaluator:

```bat
py -3.11 tools\Mature_Endpoint_Evaluator_v1_0\praycg_mature_endpoint_evaluator_v1_0.py ^
  --manifest tools\ProtocolAtlas_ModuleLibrary_v2_0\protocols\PRAYCG_D_neutral_belief_update_v1_0.json ^
  --events path\to\ProtocolAtlas_*_events.json ^
  --responses path\to\ProtocolAtlas_*_responses.json ^
  --gates path\to\gate_status.json ^
  --analysis-results path\to\analysis_status.json ^
  --output-dir path\to\endpoint_report
```

This checks protocol identity, expected markers, response linkage, directly scored trial behavior, required gate adjudication, and claim caps.

### Layer B — physiological/scientific analysis

Use a separately frozen analysis plan for EEG, HRV, respiration, EDA, metabolic, or dyadic models. The evaluator does not calculate these endpoints. The plan must define:

- exclusions and missing-data rules;
- channel/feature definitions;
- artifact and physiological controls;
- time windows and anchors;
- surrogate/null models;
- multiplicity control;
- primary versus secondary endpoints;
- participant/session structure;
- carryover and sequence terms; and
- claim grading.

## 11. Recommended first execution order

1. `ATLAS_ZERO_STATE_BASELINE_CALIBRATION`
2. `ATLAS_API_A_CALIBRATION_RECOVERY`
3. `ATLAS_GRATITUDE_CARDIO_AFFECTIVE_LITE`
4. `ATLAS_FIRST_PERSON_PRESENCE`
5. `ATLAS_PRAYCG_D_NEUTRAL_BELIEF_UPDATE`
6. `ATLAS_PRAYCG_T_TRUST_OFFLOADING`
7. `ATLAS_PRAYCG_G_MATURE_GRADIENT`
8. `ATLAS_PRAYCG_G_DYADIC_HYPERSCANNING`

Child, thermodynamic, multi-session fractal, full proxy-tensor, and social-pressure protocols should follow only after the simpler measurement and operator paths are stable.

## 12. Minimum feasibility progression

- software dry-run;
- bench run without a participant;
- self/engineering run where ethically appropriate;
- small supervised feasibility pilot;
- apparatus and burden revision;
- preregistration/OSF lock-in;
- adequately powered study; and
- independent replication.

Skipping directly from dry-run to confirmatory interpretation is not supported.

## Protocol-specific endpoint adjudication files

Before analysis, copy the matching files from:

- `config/mature_endpoint_gate_templates/`; and
- `config/mature_endpoint_analysis_templates/`.

Do not replace `NOT_ASSESSED` with `PASS` from expectation or visual impression. Attach the run-specific evidence path, hash, table, or report used for each adjudication. Required gates left unassessed make the endpoint `NOT_EVALUABLE`. Run the Mature Endpoint Evaluator only after the frozen event/response logs, gate record, and separate analysis-status record exist.
