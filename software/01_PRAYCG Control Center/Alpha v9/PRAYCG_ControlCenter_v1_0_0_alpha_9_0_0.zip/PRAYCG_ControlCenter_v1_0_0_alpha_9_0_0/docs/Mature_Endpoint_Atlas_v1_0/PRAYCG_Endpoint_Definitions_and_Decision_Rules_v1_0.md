# PRAYCG Mature Endpoint Definitions and Decision Rules v1.0

## 1. The endpoint clocks

### Recognition

Recognition is the immediate accessibility of condition-relevant information: comprehension, semantic access, task response, salience, felt meaning, or condition-specific report. It is not automatically equivalent to integration, memory consolidation, empathy, or truth.

### Integration

Integration is delayed carryover or reorganized state after the condition. A washout period is treated as a **measurement window**, not an automatic reset. Prior-condition echo, fatigue, habituation, task relief, and sequence must be modeled.

### Resolution/recovery

Resolution is a trajectory, not simply “back to baseline.” Candidate outputs include recovery slope, time to a preregistered personal band, recovery area under the curve, half-life, settling stability, unresolved load, and report/physiology disagreement.

### Availability/capacity

Availability is a bounded description of physiological and behavioral capacity to engage, mobilize, and recover. API-A and Unified Presence do not measure consciousness, consent, truth, or personal worth.

### Confidence

Every endpoint needs a confidence layer: stream coverage, beat validity, timing uncertainty, artifact burden, missingness, respiration adequacy, task compliance, and manipulation validity. A number without confidence is not promoted to a mature endpoint.

## 2. MRED family

The mature PR-AYC-G family separates:

- `MRED_RECOGNITION`: immediate semantic/meaning access after sensory and artifact adjustment;
- `MRED_INTEGRATION`: delayed carryover measured in the condition-specific washout;
- `MRED_RESOLUTION`: recovery/closure/settling trajectory; and
- `A_MRED`: availability gate that requires timing, identity, signal, artifact, respiration, manipulation, order/carryover, anti-circularity, high-order control, override attention, and anchor-lock checks.

The dyadic extension adds surrogate-normalized inter-subject persistence and common-drive residuals. Synchrony is never treated as a direct empathy readout.

## 3. API-A v2

The legacy scalar is retained only for continuity:

`API_A_v1 = -0.35·z(HR) + 0.35·z(RMSSD) + 0.15·z(SDNN) - 0.15·z(|HR slope|)`

The mature endpoint is decomposed into:

- personal regulatory baseline/capacity;
- challenge mobilization adjusted for task performance;
- post-challenge recovery;
- calm-versus-numbness/sleepiness separation; and
- coverage/confidence.

A high scalar is not automatically “better,” and a low scalar is not diagnosis or moral information.

## 4. Gratitude endpoints

The Lite runner estimates induction strength, respiration-adjusted autonomic change, and the gratitude-by-pacing interaction. The full runner estimates proxy constructs from EEG/autonomic/EDA/report streams. Neurochemical names remain labels for hypotheses unless direct synchronized assays are collected. HRV, EEG, or EDA cannot be converted into norepinephrine, oxytocin, dopamine, serotonin, cortisol, ATP, or receptor occupancy.

## 5. Unified Presence anti-circularity

The non-EEG availability predictor and EEG outcome are separated. A predictor may not reuse the outcome channel or outcome-derived features. The protocol tests prediction/association, not a self-confirming composite.

## 6. Child-safe dyadic endpoints

Biological Anchor and Father’s Day runners prioritize assent, re-engagement latency, recovery, cooperative engagement, and directionally tested parent-to-child regulation. They do not rank parents, infer attachment diagnosis, or engineer distress. Stop/assent events are first-class outcomes, not missing data.

## 7. Fractal Existence measured-scale endpoint

Only measured human scales are admitted: breath cycles, trials, blocks, and repeated sessions. Cross-scale correlation is not sufficient evidence of fractality. A claimed scale relation must exceed preregistered surrogate/null models and remain interpretable at the component level.

## 8. Thermodynamic Weight of Thought

Without independently measured, synchronized, calibrated metabolic power, the runnable outputs are cognitive-load and control proxies only. The following are gated:

- `ΔE_reg`: independently measured excess energy after motor/respiration/artifact correction;
- `Δm_eq = ΔE_reg / c²`: mass-equivalent of the measured energy contrast, not the mass of an idea; and
- `N_bound = ΔE_reg / (k_B T ln 2)`: a theoretical Landauer upper-bound accounting quantity, not psychological bit count.

If the metabolic gate is absent, thermodynamic outputs are `NOT_EVALUABLE` and the protocol remains `CALIBRATION_ONLY`.

## 9. Conformity–Flow separation

The runner separates:

- movement toward a disclosed simulated group estimate;
- immediate load relief from alignment;
- delayed private reversion/persistence;
- authenticity and agency;
- challenge–skill fit;
- self-monitoring load;
- overload; and
- performance stability.

Movement toward consensus is not scored as good or bad. Low self-monitoring is not automatically flow; dissociation, underload, ordinary effort, and overload remain alternative regimes.

## 10. Required gate sequence

The default required gates are:

1. `timing_integrity`
2. `branch_or_condition_identity`
3. `signal_coverage`
4. `artifact_burden`
5. `respiration_dual_path`
6. `manipulation_check`
7. `order_carryover`
8. `anti_circularity`

Protocols add specialized gates, including:

- PR-AYC-G anchor lock, high-order control, and override attention;
- dyadic identity, clock alignment, common-drive surrogate, and partner-specific artifact;
- child assent/governance;
- thermodynamic metabolic measurement;
- conformity disclosure and agency preservation; and
- flow/task performance adjustment.

No required gate defaults to pass. It must be adjudicated from evidence.

## 11. Decision labels

| Label | Operational meaning |
| --- | --- |
| `CONFIRMATION_CANDIDATE` | Positive, preregistered, adequately powered, multiplicity-controlled, independently replicated result, and permitted by the manifest. It still is not final proof. |
| `EXPLORATORY_INTERESTING` | Valid manipulation and required gates pass; a bounded positive or informative pattern remains, but confirmation requirements or claim ceiling are unmet. |
| `CONFOUNDED_USEFUL` | Data may inform design or calibration, but at least one non-structural confound/gate remains failed or partial. |
| `CALIBRATION_ONLY` | Software/task/measurement calibration is interpretable, but no primary endpoint analysis or required special measurement supports a scientific endpoint. |
| `FAIL_NULL` | A valid evaluable test produced a null result for the preregistered primary endpoint. This constrains the hypothesis. |
| `NOT_EVALUABLE` | Protocol identity, required events, timing, coverage, required gate adjudication, or minimal response completeness is missing/failed. |

## 12. Interpretation order

Use this order for every run:

1. stream identity and timing;
2. stimulus/media identity and provenance;
3. artifact and signal quality;
4. audiovisual/common drive;
5. task, gaze, attention, and motor burden;
6. respiration as both possible common drive and valid state event;
7. manipulation checks and self-report context;
8. endpoint estimate and uncertainty;
9. carryover/order/fatigue;
10. claim grade and explicit alternative explanations.

The order prevents a compelling theory label from outrunning the recorded evidence.
