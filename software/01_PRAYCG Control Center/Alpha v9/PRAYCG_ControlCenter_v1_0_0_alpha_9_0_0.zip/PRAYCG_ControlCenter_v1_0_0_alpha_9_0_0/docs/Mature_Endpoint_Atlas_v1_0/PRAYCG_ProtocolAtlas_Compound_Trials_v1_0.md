# PRAYCG Protocol Atlas Compound Trials v1.0

## Why this extension exists

The original Atlas v2.0 could display generated trials, media, rest, and questionnaires, but a mature belief-update or social-cognitive task needs multiple deterministic events within one trial. The shared engine now supports a data-only `steps` list inside a normal trial row.

No manifest may embed Python, shell commands, executable paths, dynamic imports, or arbitrary plugins. The shared hashed engine remains the only executor.

## Example

```json
{
  "id": "d_update_trials",
  "type": "rapid_trials",
  "trials": [
    {
      "trial_id": "belief_001",
      "condition": "neutral_belief_update",
      "steps": [
        {
          "step_id": "initial_choice",
          "kind": "generated_visual",
          "text": "Which urn is more likely? 1 = A, 2 = B",
          "duration_s": 9.0,
          "keys": ["1", "2"],
          "response_id": "initial_urn_choice",
          "correct_key": "1"
        },
        {
          "step_id": "new_evidence",
          "kind": "generated_visual",
          "text": "New evidence ...",
          "duration_s": 5.0
        },
        {
          "step_id": "updated_choice",
          "kind": "generated_visual",
          "text": "After the new evidence, which urn is more likely?",
          "duration_s": 7.0,
          "keys": ["1", "2"],
          "response_id": "updated_urn_choice",
          "correct_key": "2"
        }
      ]
    }
  ]
}
```

## Supported step kinds

- `generated_visual`
- `cue`
- `motor_cue`
- `imagery_cue`
- `fixation`
- `blank`
- `interval`
- `rest`
- `instruction`

Each step receives deterministic onset/offset markers. Response events carry the exact `trial_id`, `response_id`, response time, and contextual payload such as `step_id`, `condition`, `correct_key`, difficulty, mismatch level, task set, or phase when supplied.

## Marker pattern

For node `D_UPDATE_TRIALS`, trial `belief_001`, step `updated_choice`, the default markers are:

- `D_UPDATE_TRIALS_BELIEF_001_ONSET`
- `D_UPDATE_TRIALS_BELIEF_001_UPDATED_CHOICE_ONSET`
- response marker keyed to the node and pressed key
- `D_UPDATE_TRIALS_BELIEF_001_UPDATED_CHOICE_OFFSET`
- `D_UPDATE_TRIALS_BELIEF_001_OFFSET`

The response/event log provides trial-addressable joins without inferring association only from timestamps.

## What the extension does not do

- It does not analyze responses during acquisition.
- It does not adapt difficulty from private physiology.
- It does not select hardware.
- It does not allow unreviewed code in a manifest.
- It does not transform a behavioral response into a physiological or psychological diagnosis.
- It does not make timing more accurate than the validated display/input stack.

## Current users of compound trials

- PR-AYC-D neutral belief update;
- Conformity–Flow disclosed consensus updating; and
- any future reviewed task that needs bounded choice → evidence → revised choice sequences.
