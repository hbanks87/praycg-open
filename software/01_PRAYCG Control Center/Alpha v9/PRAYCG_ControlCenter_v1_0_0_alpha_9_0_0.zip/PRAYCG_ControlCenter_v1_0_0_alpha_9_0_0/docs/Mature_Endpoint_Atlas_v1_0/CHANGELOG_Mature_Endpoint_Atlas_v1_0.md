# PRAYCG Mature Endpoint Atlas v1.0 — Change Log

## Alpha.7 ease-of-use update

- Replaced technical top-level navigation with a seven-step plain-language workflow.
- Added one explicit picker and readiness status for every operator-selected protocol file.
- Removed ambiguous multi-file folder guessing; one path cannot silently fill two distinct asset roles.
- Added a clear skip state for runner-generated protocols that need no external stimulus files.
- Renamed the final acquisition actions **Confirm Session Setup** and **Mark Ready to Run** while preserving the underlying session-lock and arm gates.
- Kept selected input paths and SHA-256 hashes in the immutable combined session lock.

## Added

- 17 mature PRAYCG protocol manifests and thin runners.
- Explicit `PRAYCG_MatureEndpointContract_v1_0` in every new manifest.
- Recognition/integration/resolution separation where applicable.
- Required manipulation, timing, signal, artifact, respiration, order/carryover, and anti-circularity gates.
- Five-arm PR-AYC-G meaning gradient.
- Separate dyadic PR-AYC-G hyperscanning runner with stream-identity and common-drive-surrogate gates.
- Adult trust-offloading and neutral belief-update protocols.
- API-A v2 capacity/mobilization/recovery/confidence decomposition.
- Gratitude Lite and proxy-bounded full designs.
- Anti-circular Unified Presence predictor/outcome split.
- Child-safe Biological Anchor and Father’s Day observational runners.
- Measured human-scale Fractal Existence protocol.
- Metabolic-gated Thermodynamic Weight of Thought protocol.
- First-person presence, zero-state, safe transition, rhythmic autonomic, and Conformity–Flow runners.
- Shared-engine compound trial steps and trial-addressable response logging.
- Mature Endpoint Evaluator with JSON and Markdown outputs.
- Machine-readable mature runner catalog.
- Execution guide, endpoint rules, protocol matrix, compound-trial specification, and deferred register.

## Preserved

- Control Center v1.0.0-alpha.6.1 authority model, carried into the alpha.8 usability release.
- Separate hardware selection and reviewed acquisition profile.
- Existing 11 Atlas adaptations.
- Existing three native PRAYCG protocols.
- Deterministic compilation, asset locking, one-use session authority, finalization, and public-safety boundaries.

## Not claimed

- physical apparatus validation;
- human feasibility;
- psychometric or construct validity;
- clinical validity or treatment efficacy;
- source-study equivalence;
- direct neurochemical or metabolic inference without direct measurement;
- proof of consciousness, quantum mechanisms, objective meaning, moral character, or metaphysical theory.
