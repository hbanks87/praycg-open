# PRAYCG Deferred Protocol Register v1.0

## Purpose

The retained framework contains more theory/protocol documents than should be converted into a push-button human-subject runner. This register distinguishes protocols that are runnable now from those that require specialized measurement, computational treatment, stronger ethics/governance, clinical oversight, or a different experimental platform.

“Deferred” does not mean discarded. It means the Control Center should not make the protocol look ready merely because a timeline can be displayed.

## A. Admitted to the mature Atlas now

The 17 modules in `praycg_mature_endpoint_atlas_catalog_v1_0.json` were selected because they can be represented as bounded observable tasks, reports, rest/recovery windows, or controlled media conditions using the current Atlas grammar. Their endpoints remain exploratory and gate-dependent.

## B. Specialized-measurement protocols — not general Atlas runners yet

| Retained family | Why deferred | Required next layer |
| --- | --- | --- |
| Opto-Structural / opto-electrostructural memory (D04, D182–D185, D197) | Scalp EEG/HRV cannot establish structural optical memory, molecular coupling, cytoskeletal or nuclear mechanisms. | Cell/tissue preparation, optical spectroscopy/microscopy, molecular assays, electrophysiology, blinded controls, specialist lab governance. |
| Direct Gratitude Neurochemical claims (D05–D07) | Current runner measures proxies only. | Direct synchronized assay plan with validated collection timing, assay reliability, preregistered analytes, and correction for sampling stress/circadian effects. |
| Salience-network fMRI/EEG/HRV (D31) | Current Control Center does not govern MRI scanner triggers, safety, sequence metadata, or BIDS-fMRI acquisition. | Scanner-specific integration, MRI safety, trigger validation, BIDS-fMRI, site approval. |
| Thermodynamic energy / fractal mass (D37, D126–D127) | EEG/HRV cannot directly measure energy or mass. | Calibrated indirect calorimetry or another independently validated metabolic-power stream, synchronization and uncertainty budget. |
| Sleep boundary/entropic recovery (D64–D66) | Overnight sleep staging and clinical sleep safety are not implemented. | PSG/EEG/EOG/EMG staging, actigraphy or validated wearables, overnight operator plan, circadian controls, sleep-lab review. |
| Scar tissue / transplant / organ-donor / somatic systems (D48–D49, D69–D70, D104–D106) | Requires clinical cohorts, imaging, histology, immunology, medication and disease controls. | Clinical collaboration, IRB, medical oversight, records governance, tissue/imaging/assay plan. |
| Malignant oscillatory coupling and cancer-related protocols (D187) | High-stakes clinical and mechanistic claims. | Oncology collaboration, validated cellular/clinical endpoints, medical governance. |
| Trauma/epigenetic/reconsolidation protocols (D184, D189, D194–D195) | Trauma induction/treatment exceeds the nonclinical Control Center boundary. | Clinician-led protocol, risk management, treatment firewall, emergency plan, validated trauma measures. |

## C. Computational/translation-layer protocols — analysis modules, not participant runners

| Retained family | Correct implementation form |
| --- | --- |
| Master Quantum Fractal Equation (D24) | Symbolic/numerical model with dimensional analysis, identifiability tests, synthetic data, and explicit empirical mapping. |
| String/brane correspondence (D68) | Mathematical/computational translation study; no human EEG result can validate string theory. |
| Universal wave function / MWI / wash-back / death-boundary global conservation (D59–D60, D74) | Formal mathematical analysis and philosophy-of-physics comparison, not a human-subject endpoint. |
| Birth/mutation/evolution (D71–D76) | Developmental/genomic/population models with domain data; not a generic psychophysiology runner. |
| Three-body, gravity, holographic, cosmological, planetary protocols (D90–D91, D128–D129, D140–D144, D167–D171) | Simulation, public-data analysis, astronomy/physics collaboration, or clearly labeled metaphorical translation. |
| Gate optionality/public-data proxy (D199–D202) | Separate reproducible data-analysis package with dataset provenance and benchmark nulls. |

## D. Ethically sensitive behavioral protocols — task validation required before admission

| Retained family | Present status |
| --- | --- |
| Burnout longitudinal capacity (D56–D57) | Potentially admissible as observational repeated measurement; do not induce overwork or sleep loss. Needs burden, privacy, employer-firewall, and longitudinal missingness plan. |
| Fractal morality/justice/punishment (D77–D80) | Do not operationalize as moral-worth, guilt, criminality, psychopathy, or “punishment fit” scores. A future protocol would need hypothetical low-stakes decisions, fairness audits, and strict non-forensic governance. |
| Courage/cowardice (D81–D82) | A safe approach/avoidance task is possible, but “cowardice” labels must be removed from participant output and fairness validated before Atlas admission. |
| Virtue/nobility/mastery/willpower (D88–D89, D117–D118, D130–D133) | Requires construct validation and protection against character ranking, religious/moral coercion, and discriminatory use. |
| Grief/forgiveness/sovereignty (D96–D99, D151–D152) | Requires non-traumatic, participant-selected content, privacy safeguards, distress monitoring, and a clear therapy/non-therapy boundary. |
| Audience intent/social performance (D153–D156) | Feasible only with mild evaluation, no humiliation, no employment/school ranking, and explicit audience/deception governance. |
| Cultural tuning (D20–D21) | Feasible as measurement-invariance/social-psychology work, but culture cannot be reduced to a single individual score without cross-cultural validation and fairness review. |
| Altered states/psychedelic protocol (D87) | No substance administration in this package. Meditation-only work requires screening, stopping rules, and no enlightenment/clinical claim. |

## E. Child and family boundary

Only the child-safe Biological Anchor and Father’s Day observational runners are included. They require child assent, guardian consent, minimal burden, privacy, positive closeout, and no engineered distress. The software must not be used for custody, parenting rank, attachment diagnosis, school discipline, or family surveillance.

## F. Admission criteria for a future runner

A deferred protocol should enter the Atlas only when all of the following are available:

1. observable construct and falsifiable contrast;
2. safe and standardized task/stimulus;
3. validated measurement channel for every literal claim;
4. timing and provenance contract;
5. manipulation checks;
6. artifact/common-drive controls;
7. explicit null and falsification criteria;
8. participant/operator stopping rules;
9. misuse/governance firewall;
10. dry-run and bench evidence;
11. separate analysis plan; and
12. ethics/clinical/site approval where required.

A timeline alone is not sufficient admission evidence.
