# PRAYCG Control Center v0.94 Protocol-Library Method

> **Retained lineage note:** This document preserves the native PRAYCG3/PRAYCG4/SMG protocol-library method introduced in v0.94. It is not the current installation or operator guide and does not describe the separate Protocol Atlas v2.0 typed engine. For the active alpha.4 operating boundary, use the package-root README and the guarded sequence displayed by the Control Center; the retained Master Protocol and Theory document in this folder remains historical method context.

## Scope

Control Center v0.94 retains v0.93's separation of orchestration from protocol definition. A protocol module declares ordered branches, media roles, task mode, washout/report names, required self-reports, integrity constraints, analysis aliases, and a scientific-boundary statement. A shared engine supplies the timing, LSL, ALS-barcode, EEG-watchdog, media-integrity, self-report, and run-lifecycle machinery.

The resulting software supports reproducible acquisition structure. It does not validate a scientific theory by itself.

## PRAYCG3: original three-prong protocol

The fixed order is:

1. `CONTROL_1`: PhaseScrambled Control;
2. `WASHOUT_1` and `CONTROL_1_AFTER_WASHOUT_1`;
3. `TARGET_1`: intact target, cues ignored;
4. `WASHOUT_2` and the target report;
5. `CONTEXTUAL_OVERRIDE_1`: the bit-identical target under a running-sum task;
6. `WASHOUT_3` and the override report;
7. final reflection baseline/report.

This is the v0.92 three-prong sequence formalized as PRAYCG3. The new engine is intended to retain its acquisition behavior, but code-level continuity is not evidence of empirical equivalence. Before participant use, verify media, audio, cue timing, barcode placement, markers, LabRecorder capture, abort behavior, and output manifests in a non-participant dry run.

## PRAYCG4: ShotOrder four-branch protocol

The fixed order is:

1. PhaseScrambled Control;
2. the control washout and completed control report;
3. `SHOT_ORDER_SCRAMBLE_1`;
4. `SHOT_ORDER_WASHOUT_1` and the ShotOrder report;
5. Target;
6. target washout/report;
7. Contextual Override;
8. override washout/report;
9. final reflection baseline/report.

The software therefore satisfies the requested placement: ShotOrder begins only after the PhaseScrambled washout and its report have ended.

Conceptually, the three main contrasts address different alternatives:

\[
\Delta_{T,P}=Y_T-Y_P, \qquad
\Delta_{T,S}=Y_T-Y_S, \qquad
\Delta_{T,O}=Y_T-Y_O,
\]

where \(T\) is Target, \(P\) is PhaseScrambled, \(S\) is ShotOrderScramble, \(O\) is Override, and \(Y\) is a predeclared outcome after timing/artifact/confound gates.

These deltas are descriptive within a fixed-order run. They are not unbiased causal estimators because condition and order are perfectly confounded. Stronger future designs should predeclare whether order is fixed for theoretical reasons or use a defensible counterbalancing/randomization scheme that respects carryover and repeated-media constraints.

## Semantic Meaning Gradient protocol

The SMG module operationalizes a conditional design from the D205 theory document:

1. a coherent Semantic-Zero candidate designed to be low in agency, attachment, consequence, repair, threat, and human stakes;
2. a High-Meaning Target;
3. the same target media under an Arithmetic Override task.

A chaotic or phase-scrambled clip is not automatically a valid semantic zero because perceptual disorder can produce salience, puzzle demand, threat, or meaning-making. Accordingly, the runner uses a separate `semantic_zero_video` input and collects post-condition manipulation checks.

### Rating normalization

Runner ratings use integers 0–9. Any proposed index requiring unit-interval inputs must declare the mapping before analysis. The default linear mapping would be

\[
x_{[0,1]}=\frac{x_{[0,9]}}{9},
\]

but an alternative mapping must be justified and locked independently of the observed physiological result.

### Proposed Semantic-Zero Index

After normalization,

\[
\mathrm{SZI}=(1-M)(1-E)(1-A)(1-T)(1-P),
\]

where \(M\), \(E\), \(A\), \(T\), and \(P\) denote Meaning, Empathy, Absorption, Threat, and Puzzle Demand. The source document’s threshold of 0.60 remains a proposed, unvalidated decision rule. Because this is a product, one large disqualifying component can sharply lower the score; that behavior should be treated as a design choice, not as a discovered psychometric fact.

### Proposed Override Purity Index

\[
\mathrm{OPI}=C\,L\,(1-E)(1-M)(1-N),
\]

where \(C\) is Task Compliance, \(L\) is Analytic Effort, and \(N\) is Narrative Engagement. Proposed 0.50 and 0.65 thresholds are recorded as exploratory and strong candidates, respectively, not validated cutoffs. A correct sum is relevant evidence for engagement, but it cannot establish complete suppression of narrative processing.

### Meaning contrast and carryover

If a dimensionless meaning score is independently specified,

\[
\Delta M=M_{\mathrm{target}}-M_{\mathrm{semantic\ zero}}.
\]

The proposed \(\Delta M\geq0.35\) rule is conditional on the score’s construction and scale. The proposed carryover summary is

\[
\mathrm{MCS}=\operatorname{mean}(S_w,A_w,R_w,D_w),
\]

using normalized Story Active, Emotional Afterglow, Replay, and Felt Return Delay ratings during washout. Missing terms remain missing; they are not replaced with favorable zeros. The aggregation rule and minimum required term count must be predeclared before confirmatory use.

### Time-varying meaning score

A bounded semantic-density function may be written as

\[
M(t)=\sigma\!\left(\sum_{j=1}^{k}w_jx_j(t)-\sum_{r=1}^{q}v_rz_r(t)\right),
\]

with nonnegative weights fixed independently of the physiological outcomes, explicit feature coding rules, and a declared logistic function \(\sigma(u)=1/(1+e^{-u})\). For interpretability, weights should be normalized or otherwise scale-identified.

The source proposal that directly adds \(\operatorname{Var}(M(t))\) to \(\max|dM/dt|\) mixes quantities with different units. v0.94 therefore continues to record variance and maximum slope separately unless a time unit and dimensionless scaling are predeclared. No raw sum is computed by the runner.

### Multimodal Reception Index

A composite of z-scored EEG, heart-rate, HRV, and self-report terms is not computed during acquisition. It requires, at minimum:

- a reference distribution for every z-score;
- polarity and scaling rules;
- artifact and entrainment definitions;
- contamination and missing-data rules;
- a fixed aggregation rule;
- validation on data not used to tune the weights or thresholds.

Without those definitions, a numerical composite would appear more precise than the measurement model permits.

### Manipulation gate

If the Semantic-Zero or Override manipulation is not established, the appropriate outcome is `PROTOCOL_MANIPULATION_NOT_ESTABLISHED`. This is not logically equivalent to falsifying the larger theory. Conversely, a passing manipulation plus a favorable exploratory result is not confirmation without replication and protection against analysis flexibility.

## Protocol aliases and analysis

Native markers remain the scientific record. SMG emits canonical aliases to permit the existing analysis frame to segment Semantic-Zero, High-Meaning, and Arithmetic Override in the positions normally occupied by Control, Target, and Contextual Override. The run manifest retains both identities. The alias is a software compatibility mapping, not an assertion that the constructs are identical.

PRAYCG4 emits a native ShotOrder phase. The bundled core parser retains that segment and its washout so the HOC-R module can detect it. Existing downstream modules that were written only for the canonical three branches may remain three-branch analyses; their output must not be represented as a complete PRAYCG4 analysis unless ShotOrder applicability is explicitly reported.

## Acceptance status

Static validation can establish schema consistency, hash-lock behavior, path containment, compile success, and exact manifest order. It cannot establish PsychoPy frame timing, audiovisual performance, LSL transport, LabRecorder capture, ALS visibility, EEG quality, or participant comprehension. Those remain hardware/runtime acceptance tests.
