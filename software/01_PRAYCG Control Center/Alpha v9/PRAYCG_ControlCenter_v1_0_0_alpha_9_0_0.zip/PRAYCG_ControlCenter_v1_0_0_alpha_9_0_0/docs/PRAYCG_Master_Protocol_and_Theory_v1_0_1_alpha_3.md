# PRAYCG Master Protocol and Theory v1.0.1 Alpha

**Protocol, theory, analysis, and platform architecture for PRAYCG Control Center v1.0.0-alpha.3**  
**Author:** Hoyt Banks  
**Contact:** hoytbanks@gmail.com  
**Repository:** [hbanks87/praycg-open](https://github.com/hbanks87/praycg-open)  
**OSF project:** [PRAYCG, project 8n75v](https://osf.io/8n75v/overview?view_only=928f1fa1974b40e89252101d0ba356d3)  
**Document status:** Alpha methods specification. Software and synthetic checks are reported separately from physical-hardware, construct, and prospective validation.  
**Documentation license:** CC BY 4.0 unless a file states otherwise

## Executive summary

PRAYCG v1.0.0-alpha.3 is a gated modular research platform organized around one operator-facing Control Center. The architecture preserves distinct protocol, acquisition, analysis, export, and verification services, but no longer exposes a second Platform Workbench that duplicates the primary workflow. The additions were made to answer different questions that one comparison cannot answer by itself and to prevent a draft, missing stream, failed preflight, or incompatible analysis from being treated as a valid run:

1. **PRAYCG3** retains the original three-condition logic: damaged sensory/narrative structure, intact target, and intact target under an analytic working-memory task.
2. **PRAYCG4** adds a ShotOrder structural control so local shots can remain recognizable while their larger temporal order is disrupted.
3. **Semantic Meaning Gradient (SMG)** asks whether responses scale across a deliberately low-meaning state, a high-meaning target, and the same target under arithmetic override.
4. **CAI/SID v0.2** converts fast access-like activity, slower integration-like activity, delayed joint support, artifact, and task burden into a bounded exploratory index.
5. **Continuous Autonomic/RespDualPath v1.0** adds time-resolved cardiac and respiratory estimates alongside coarse branch-level summaries, while preserving respiration as both physiology and a possible artifact source.
6. **The prospective package** creates fixed Williams-design sequence variants, deterministic assignment, hashing, preregistration materials, and promotion gates without changing the public fixed-order protocols.
7. **Micro Handoff v0.1** operationalizes a narrower hypothesis: whether local temporal-gamma activation is followed over a fixed short-lag bank by posterior/parietal-temporal theta activation.
8. **HOC-R, OSA, OHC, AAM, and RespDualPath** make alternative explanations visible instead of allowing a Target difference to be interpreted automatically as meaning, narrative reception, or persistent state change.
9. **Cue-Locked Gamma Forensics v0.1** tests whether cue-related 30–45 Hz findings carry temporal, spectral, spatial, amplitude, or autonomic signatures compatible with ocular or craniofacial artifact. It is an exploratory OCM/OSA/AAM extension, not a new primary score.
10. **Protocol Forge, Protocol Atlas, prospective assignment, and the module registry**, exposed under Runner / PsychoPy, separate native PRAYCG branch protocols from allowlisted typed Atlas tasks without allowing a draft manifest or assignment utility to execute arbitrary code.
11. **Hardware Registry, run/profile-bound transport preflight, separate detailed live checks, and Acquisition Supervisor**, exposed together under Acquisition, keep device description, source identity, signal role, transport evidence, and scientific validity conceptually distinct. Observer mode is the default; managed recovery is experimental and off by default.
12. **Study/session locking, capability resolution, post-run evidence gates, and BIDS export** bind protocol, hardware, stimuli, timing, analysis availability, and operator-reviewed workflow artifacts while preserving XDF as source provenance and RR intervals as irregular events. Post-run evidence recording is auditable bookkeeping, not scientific validation.
13. **Separated lock semantics and runtime enforcement** distinguish an approved design-time protocol snapshot from the preflight-dependent lock and arm state of a particular session. The shared engine verifies approval-envelope, runner, engine, media, run, policy, state, and history identities before any logger, LSL marker outlet, or PsychoPy window is created.
14. **Runnable Protocol Atlas v2.0** federates 11 reviewed acquisition adaptations with the native PRAYCG3/PRAYCG4/SMG library. Each Atlas entry has a declarative task contract, individualized thin runner, shared typed engine, deterministic timeline, event/response handoff, source and rights notes, explicit claim boundary, and no authority to select hardware.

The central methodological principle is that **software-valid does not mean construct-valid**. A formula can be implemented correctly and still fail to measure the intended phenomenon. Every new measure therefore retains an evidence grade, a missing-data policy, falsification conditions, and a public claim boundary.

## How to read the status labels

| Label | Meaning |
|---|---|
| **Packaged acquisition protocol/adaptation** | The runner, manifest, and engine path exist and pass structural/dry-run checks. Physical display, device, marker, and end-to-end acquisition validation must be reported separately. |
| **Implemented exploratory analysis** | The code computes the declared output reproducibly, but the construct has not been prospectively validated. |
| **Prospective template** | The software infrastructure exists, but real stimuli, approvals, apparatus validation, registration, or participant data are still required. |
| **Proposed formula** | A theory document defines the quantity, but the current runner or analysis does not compute it as a validated endpoint. |
| **Diagnostic** | Useful for inspection or sensitivity analysis; not a confirmatory endpoint. |
| **Unavailable/missing** | The evidence was not estimable. It must not be converted to a favorable zero or a favorable score. |

## Common notation

Let $t$ denote synchronized PRAYCG time, $i$ a participant or run, $b$ a contiguous block instance, and $c$ a condition. Define:

$$
\sigma(x)=\frac{1}{1+e^{-x}},
\qquad
[x]_+=\max(x,0),
\qquad
\operatorname{clip}_{[0,1]}(x)=\min(1,\max(0,x)).
$$

The preferred within-run Baseline 1 robust transform is

$$
z_{B1}(x_t)
=0.67448975\frac{x_t-\operatorname{median}_{B1}(x)}{\operatorname{MAD}_{B1}(x)},
$$

where

$$
\operatorname{MAD}_{B1}(x)
=\operatorname{median}_{B1}\left|x_t-\operatorname{median}_{B1}(x)\right|.
$$

The constant $0.67448975$ makes the median/MAD transform comparable in scale to an ordinary standard score under a normal reference distribution. In the implemented CAI candidate, transformed values are clipped at ±6. A full-run fallback is permitted only for explicitly graded legacy CAI inputs and is recorded. Micro Handoff allows no full-run fallback.

---

## 1. PRAYCG3 v3.0 — original three-prong protocol

### Implemented sequence

PRAYCG3 preserves the original fixed-order acquisition structure:

```text
BASELINE_1
→ CONTROL_1
→ WASHOUT_1 → control report
→ TARGET_1
→ WASHOUT_2 → target report
→ CONTEXTUAL_OVERRIDE_1
→ WASHOUT_3 → override report
→ BASELINE_2_REFLECTION
→ final report
```

`CONTROL_1` is the PhaseScrambled control. `TARGET_1` is the natural target. `CONTEXTUAL_OVERRIDE_1` uses the same cue-embedded target media while the participant performs the running-sum task. Baseline 1, Baseline 2/final reflection, every washout/report, and the final report are retained.

### What each comparison asks

For an outcome $Y$, define condition summaries $\bar Y_P$, $\bar Y_T$, and $\bar Y_O$ for PhaseScrambled, Target, and Override:

$$
\Delta_{T-P}=\bar Y_T-\bar Y_P,
$$

$$
\Delta_{T-O}=\bar Y_T-\bar Y_O.
$$

- $\Delta_{T-P}$ asks whether the intact target differs from a control in which recognizable and high-order structure has been damaged.
- $\Delta_{T-O}$ asks whether the response differs when the same target is viewed under a competing analytic/working-memory stance.

Neither contrast identifies “meaning” by itself. Target versus PhaseScrambled changes more than meaning, while Target versus Override changes task demands, cue monitoring, and possibly visual sampling.

### Why Baseline 1, washouts, and Baseline 2 matter

Baseline 1 defines the run-local reference distribution. Washouts are treated as measured post-condition states, not blank intervals and not guaranteed biological resets. Baseline 2/final reflection asks whether the final state differs from the initial baseline after the entire sequence:

$$
\Delta B_2(Y)=\operatorname{summary}(Y_{B2})-\operatorname{summary}(Y_{B1}).
$$

This is a **cumulative after-state contrast**. Because Baseline 2 follows all three branches, it cannot be attributed uniquely to Target. It may include Target carryover, Override relief, fatigue, habituation, respiration, cumulative exposure, or drift.

### Fixed-order limitation

In the public PRAYCG3 runner, condition and period are inseparable. A conceptual decomposition is

$$
\widehat\Delta_{a-b}
=(\tau_a-\tau_b)
+(\pi_{p(a)}-\pi_{p(b)})
+(\lambda_{\mathrm{prev}(a)\to a}-\lambda_{\mathrm{prev}(b)\to b})
+\varepsilon,
$$

where $\tau$ is the condition effect, $\pi$ is the period/fatigue/habituation effect, and $\lambda$ is carryover from the preceding branch. One fixed sequence cannot estimate these terms separately. This is why the public fixed-order runner remains useful for continuity and exploratory within-run description, while the prospective package uses counterbalanced variants.

### Plain-language explanation

PRAYCG3 asks three practical questions: What happens when the media is structurally damaged? What happens when it is watched naturally? What happens when the same meaningful media must compete with a deliberate arithmetic task? It preserves the original protocol so older and newer data remain structurally comparable, but its fixed order prevents strong causal claims about condition alone.

---

## 2. PRAYCG4 v4.0 — adding ShotOrder structural control

### Implemented sequence

PRAYCG4 inserts ShotOrder immediately after the completed PhaseScrambled washout/report:

```text
BASELINE_1
→ CONTROL_1
→ WASHOUT_1 → control report
→ SHOT_ORDER_SCRAMBLE_1
→ SHOT_ORDER_WASHOUT_1 → ShotOrder report
→ TARGET_1
→ WASHOUT_2 → target report
→ CONTEXTUAL_OVERRIDE_1
→ WASHOUT_3 → override report
→ BASELINE_2_REFLECTION
→ final report
```

### Formal ShotOrder operator

Let the intact target be divided at declared shot boundaries into (m) local segments:

$$
V_T=S_1\oplus S_2\oplus\cdots\oplus S_m,
$$

where $\oplus$ denotes temporal concatenation. A ShotOrder derivative applies a recorded permutation $\pi$:

$$
V_{SO}=S_{\pi(1)}\oplus S_{\pi(2)}\oplus\cdots\oplus S_{\pi(m)}.
$$

The intended manipulation is:

- preserve the within-shot pixels, faces, bodies, objects, voices, and biological motion as much as the editing procedure permits;
- reduce or alter cross-shot adjacency, causal continuity, anticipation, and narrative order;
- record the input path/hash, shot boundaries, permutation, processing settings, and output hash.

This is not perfect matching. New cut transitions, audio discontinuities, shot-length structure, familiarity, and residual low-level differences can remain.

### Three structural contrasts

PRAYCG4 supports the declared contrasts

$$
\Delta_{T-P}=\bar Y_T-\bar Y_{Phase},
$$

$$
\Delta_{T-SO}=\bar Y_T-\bar Y_{ShotOrder},
$$

$$
\Delta_{T-O}=\bar Y_T-\bar Y_{Override}.
$$

Their intended interpretation is narrower when considered jointly:

| Contrast | Primary question | Major remaining caution |
|---|---|---|
| Target − PhaseScrambled | Does the intact target differ from strongly structure-damaged sensory input? | Phase scrambling also damages local objects, faces, contours, and motion structure. |
| Target − ShotOrder | Does intact larger-scale sequence add something beyond locally intact shots? | Editing artifacts, familiarity, audio treatment, and fixed order remain. |
| Target − Override | Does natural viewing differ from analytic task engagement with the same target? | Task load, cue monitoring, gaze/AOI changes, and task relief remain. |

### Why ShotOrder was added

PhaseScrambling is useful but too destructive to serve as the only control for a narrative question. Research on scrambled visual controls likewise warns that phase scrambling can alter image properties beyond the intended high-level manipulation; this supports treating it as a useful but incomplete control rather than a pure “meaning-null” stimulus ([Stojanoski & Cusack, 2014](https://doi.org/10.1167/14.12.6)). ShotOrder creates an intermediate rung: more local content is retained, while the larger temporal sequence is disrupted.

### Plain-language explanation

PhaseScrambling asks, “Does intact media differ from visual/audio material whose structure has been heavily damaged?” ShotOrder asks, “If the individual shots are still there but the story order is broken, does the response change?” The two controls together help separate low-level drive, recognizable local content, and larger narrative-temporal organization.

---

## 3. Semantic Meaning Gradient v1.0

### Implemented acquisition states

The SMG runner operationalizes three conditional states:

```text
SEMANTIC_ZERO_1
→ washout/report
→ HIGH_MEANING_TARGET_1
→ washout/report
→ ARITHMETIC_OVERRIDE_1
→ washout/report
```

It retains Baseline 1, Baseline 2/final reflection, and the final report. Compatibility aliases map these native labels to the current analysis frame, but the native SMG labels remain in provenance.

The Semantic-Zero stimulus must be a distinct, coherent, deliberately low-meaning stimulus. PhaseScrambled or chaotic media is not substituted automatically because randomness can create novelty, threat, prediction error, or puzzle demand.

### 3.1 Proposed Semantic Meaning Density

The D205 theory defines a bounded candidate function

$$
\operatorname{SMD}(t)=\sigma\!\left[
w_H\,H(t)+w_A\,A(t)+w_V\,V(t)+w_C\,C(t)+w_R\,R(t)+w_K\,K(t)+w_T\,T(t)
-w_P\,P_{puzzle}(t)-w_O\,O_{overload}(t)
\right].
$$

The positive terms represent:

- $H(t)$: human/social presence;
- $A(t)$: agency or goal-directed action;
- $V(t)$: vulnerability, need, grief, fear, hope, or tenderness;
- $C(t)$: causal continuity;
- $R(t)$: repair, reunion, care, forgiveness, protection, or restored attachment;
- $K(t)$: stakes or consequence;
- $T(t)$: visible transformation of state or relationship.

The subtractive terms represent puzzle demand and sensory overload. All input scales and directions must be declared. Weights should be nonnegative, normalized under an explicit convention—for example, positive weights summing to one separately from penalty weights—and fixed without examining the physiological outcomes used to test the theory. Without common input scaling, a numerical weight does not have a stable cross-feature interpretation.

This formula is a **proposed stimulus annotation model**, not an objective meter of meaning. Several inputs require manual coding, transcripts, post-block reports, or future validated automated detectors.

### 3.2 Mean, total area, peak, and arc summaries

The duration-normalized mean, unnormalized area, and peak summaries are

$$
M_{mean}=\frac{1}{T}\int_0^T \operatorname{SMD}(t)\,dt,
$$

$$
M_{area}=\int_0^T \operatorname{SMD}(t)\,dt,
$$

$$
M_{peak}=\max_t \operatorname{SMD}(t).
$$

The earlier symbol $M_{total}$ was paired with the $1/T$ formula. Mathematically, that quantity is a time average, not a total: it remains on the SMD scale. A true accumulated area omits $1/T$ and has units of time when SMD is dimensionless. Comparing $M_{area}$ across stimuli therefore requires equal duration or an explicit duration model.

The D205 proposal also wrote

$$
M_{arc}=\operatorname{Var}[\operatorname{SMD}(t)]
+\max_t\left|\frac{d\operatorname{SMD}(t)}{dt}\right|.
$$

The raw sum is dimensionally incoherent: variance is dimensionless when SMD is dimensionless, while the slope has units of inverse time. The v1.0 runner therefore keeps variance and maximum absolute slope separate. If a future preregistration requires one arc index, it must first declare a time scale $T_0$ and dimensionless weights, for example

$$
M_{arc}^{*}=a\,\operatorname{Var}[\operatorname{SMD}(t)]
+b\,T_0\max_t\left|\frac{d\operatorname{SMD}(t)}{dt}\right|,
$$

with $a,b\ge0$ frozen before outcome review.

### 3.3 Proposed Meaning Response Index

The source theory proposes

$$
MRI_i=
\frac{
z(PNCC_{\theta,i})+z(PNCC_{HR,i})+z(PNCC_{RMSSD,i})
+z(Meaning_i)+z(Absorption_i)+z(Empathy_i)
}{
1+A_{artifact,i}+E_{entrainment,i}+C_{contamination,i}
}.
$$

This expresses a useful design principle: convergent carryover, physiology, and subjective report should be attenuated by artifact and stimulus-locking concerns. However, **the current runner does not compute MRI**. A legitimate implementation still requires a declared z-score reference distribution, component direction, missing-data policy, entrainment definition, contamination rule, weighting rule, and prospective validation.

### 3.4 Manipulation-validity indices

All self-report inputs must first be mapped explicitly to ([0,1]).

Semantic-Zero Validity Index:

$$
SZI=(1-Meaning)(1-Empathy)(1-Absorption)(1-Threat)(1-PuzzleDemand).
$$

Override Performance Index:

$$
OPI=TaskCompliance\cdot AnalyticEffort\cdot(1-Empathy)\cdot(1-Meaning)\cdot(1-NarrativeEngagement).
$$

Meaning separation:

$$
\Delta M=M_{target}-M_{semantic\text{-}zero}.
$$

Meaning Carryover Score:

$$
MCS_i=\frac{
StoryActive_{washout}+EmotionalAfterglow_{washout}+Replay_{washout}+FeltReturnDelay_{washout}
}{4}.
$$

The proposed thresholds are $SZI\ge0.60$, $OPI\ge0.50$ exploratory or $OPI\ge0.65$ strong, and $\Delta M\ge0.35$. These are **unvalidated candidate thresholds**, not discovered biological constants.

The multiplicative form makes the manipulation checks conjunctive. For example, an otherwise low-rated Semantic-Zero condition with high puzzle demand receives a low SZI. That is intentional: a control that provokes strong puzzle solving has not instantiated the proposed low-meaning/low-demand state.

### 3.5 Proposed post-narrative carryover

With $[x]_+=\max(x,0)$, the source theory proposes

$$
PNCC_{\theta,i}
=\frac{
\int_0^{T_w}[\kappa_{\theta,washout,i}(t)-\kappa_{\theta,pre,i}]_+\,dt
}{1+A_{artifact,i}},
$$

and

$$
PNCC_{phys,i}=w_{HR}WCI_{HR,i}+w_{RMSSD}WCI_{RMSSD,i}.
$$

These formulas express persistence above a pre-condition reference while penalizing artifact. They remain candidate signatures. A slow return, HR decrease, or RMSSD increase can also arise from fatigue, relief, breathing, posture, or drift.

### Why SMG was added

PRAYCG3 and PRAYCG4 compare kinds of structure and task context. SMG asks a different question: whether responses vary with a deliberately designed **gradient of semantic and social content**. It also makes failed manipulations visible. If the Semantic-Zero stimulus evokes strong meaning or puzzle demand, or if the arithmetic task fails to suppress engagement despite high compliance, the intended contrast was not established.

### Plain-language explanation

SMG does not assume that a random-looking video is meaningless. It first checks whether the low-meaning condition was actually experienced as low in meaning, empathy, threat, absorption, and puzzle demand. It then asks whether the high-meaning target and its post-stimulus carryover differ, and whether a demanding arithmetic task reduces that response.

---

## Runnable Protocol Atlas v2.0 — hardware-independent acquisition expansion

### Purpose and scope

The Atlas turns the Control Center from a library of three PRAYCG-specific protocols into a governed acquisition platform that can host many task families without giving a protocol power over the hardware stack. Alpha.3 contains 11 reviewed Atlas adaptations in addition to the native PRAYCG3, PRAYCG4, and SMG entries.

An Atlas entry is an **adaptation or operational reconstruction**. A source publication or public dataset can establish the historical design that inspired it, but it does not automatically establish that the PRAYCG implementation is an exact replication, that the same stimuli were used, or that published psychometric validity transfers to this software. Every manifest therefore records whether exactness was established, lists departures, and states a verification level.

### Formal separation of protocol and hardware authority

Let a protocol module be

$$
M=(I,V,E,R,A,T,Q,H,B),
$$

where $I$ is protocol identity, $V$ its version, $E$ the allowlisted engine family, $R$ the packaged runner identity, $A$ the asset contract, $T$ the declarative timeline, $Q$ the response and analysis-handoff contract, $H$ the hardware effect, and $B$ the safety/claim boundary. For every active Atlas module,

$$
H(M)=\mathrm{NONE},
\qquad
\mathrm{hardware\_profile\_id}(M)=\varnothing.
$$

Hardware is selected independently in Acquisition. Let $R_H(M)$ be the finite set of semantic hardware roles explicitly required by the module, and let $R_H(D)$ be the roles in the exact lock-bound reviewed hardware profile. Runner-generated `Markers` and `PRAYCGMarkers` are not hardware requirements. Alpha.3 requires

$$
R_H(M)\setminus\{\mathrm{Markers},\mathrm{PRAYCGMarkers}\}
\subseteq R_H(D).
$$

This is a compatibility condition, not a live-signal or scientific-adequacy result. The runtime session is permitted only when a reviewed protocol snapshot $P$, that independently reviewed hardware profile $D$, current profile preflight evidence $F$, a participant/session plan $C$, and any required assets $A^*$ are bound together:

$$
\mathrm{Eligible}_{run}
=
\mathrm{Valid}(P)
\land \mathrm{Valid}(D)
\land \mathrm{Acceptable}(F)
\land \mathrm{Valid}(C)
\land \mathrm{Valid}(A^*)
\land \mathrm{HumanReview}.
$$

No term substitutes for another. A protocol cannot make a failed device preflight pass; a connected device cannot make an unsuitable protocol scientifically valid.

### Deterministic timeline compilation

The Atlas freezes session order before acquisition. If no explicit seed is preregistered, the engine computes a deterministic integer from protocol ID $I$, participant pseudonym $p$, and positive session index $j$:

$$
s_{I,p,j}
=
\operatorname{uint64}\!\left(
\operatorname{SHA256}(I\,\|\,p\,\|\,j)_{0:8}
\right).
$$

The compiled plan is explicitly asset-dependent:

$$
C
=
\operatorname{Compile}(T,I,p,j,A^*)
=
\operatorname{Expand}
\left[
\pi_{s_{I,p,j},j}(T;A^*)
\right],
$$

where $\pi$ is the manifest-declared fixed, seeded-shuffle, Latin-square, Williams, or scheduled ordering operator and `Expand` assigns every repeated or nested node a unique compiled instance ID. Asset dependence is explicit because a frozen external schedule can determine the realized trials. Validation descends recursively through every child node before compilation; a malformed child cannot hide beneath a valid parent. The canonical JSON of $C$ receives its own SHA-256. The runner independently recomputes or revalidates this plan from the locked participant, session index, and assets; a different order or trial list cannot be substituted silently.

Determinism is an audit property, not evidence that randomization is scientifically optimal. Allocation concealment, counterbalancing adequacy, and sample-size planning still belong in the prospective protocol.

### Asset identity and rights boundary

Operator-selected assets must match each module's declared type and extension contract, be reviewed locally, and resolve unambiguously. For a file $f$,

$$
h(f)=\operatorname{SHA256}(\operatorname{bytes}(f)).
$$

For a directory $D$ containing files $f_k$ with normalized relative paths $r_k$ sorted case-insensitively, the Atlas uses

$$
h(D)=\operatorname{SHA256}\!\left(
\operatorname{concat}_{k=1}^{K}
\left(r_k,\mathtt{NUL},h(f_k),\mathtt{NUL}\right)
\right).
$$

This binds both names and contents. It does not prove copyright permission, stimulus appropriateness, absence of hidden encoding differences, or perceptual equivalence. Restricted media are not bundled. The operator remains responsible for lawful access and study-specific review.

The EEG Moments-derived protocol uses the directory identity as a complete acquisition contract rather than locking only a convenient manifest. Its root must contain `emd_media_manifest.json`, exactly one `emd_schedule*.json`, `emd_run_selection.json`, and every referenced audiovisual clip. The selection binds distinct positive session and run indices, exact filenames, manifest/schedule IDs and hashes, and reviewed/frozen metadata. The Control Center's session index must equal the selection's session index; the run index is read only from the selection. Compilation validates unique session/run/trial IDs and the complete schedule and clip references, then embeds the exact selected trial rows and the selection/schedule/manifest/tree identities in $C$. The live engine consumes those compiled rows and rechecks the tree and selected clip hashes. Thus any changed member requires a new session lock; no environment variable can silently choose another run.

Generated/no-media protocols still receive an immutable acquisition input: their compiled timeline file is hash-bound into the runtime session. This preserves the one-use launch authority without inventing a stimulus file.

The authorized alpha.3 interface freezes the reviewed parameter defaults in the manifest. It exposes no general Atlas parameter-editing UI at lock time. A different duration, optional task, response rule, or other parameter is a new reviewed/versioned candidate, not an unbound runtime choice.

### Atlas protocol families included in alpha.3

| Source-family adaptation | Engine/task logic | Primary operational distinction |
|---|---|---|
| MIPDB eyes-closed rest | Timed rest | Three-minute operational default after instructions and operator gate; no external media. |
| NARR intact audio | Audio narrative | Reviewed WAV bracketed by pre/post fixation. |
| NARR coarse scramble | Audio narrative/order control | Coarse sentence-order derivative with provenance requirement. |
| NARR fine scramble | Audio narrative/order control | Fine sentence-order derivative with provenance requirement. |
| NATVIEW repeated video | Continuous/repeated media | One bit-identical video viewed twice; the declared 12 Hz checkerboard is disabled under packaged defaults. |
| Zacks passive | Naturalistic event viewing | Four reviewed videos played muted, with fixed operator gates and fixation. |
| Zacks active boundary marking | Event segmentation | Separate active variant records participant keypresses as perceived event boundaries. |
| ERP CORE-derived P3b | Generated visual oddball | Generated standard/target shapes, practice, and main blocks. |
| PhysioNet EEGMMIDB-derived motor | Motor execution/imagery | Eyes-open/closed baselines and separately labeled generated motor cue trials. |
| EEG Moments-derived clips | Rapid audiovisual media | Complete locked directory with manifest, one schedule, run selection, referenced clips, and exact compiled selected-trial rows. |
| SVNA-derived gutter ranking | Image ranking | CC0 geometric demonstration strips or a separately reviewed import; ranking is an ordered permutation. |

These entries broaden acquisition capability; they do not make PRAYCG-specific measures universally applicable. By default, an Atlas run receives a protocol-specific event/response handoff while the Master Comprehensive Suite is marked unavailable. A separate reviewed analysis adapter must establish condition mapping, feature meaning, required hardware, missingness policy, and inferential scope.

### Typed engine and executable-code boundary

Manifests can select only allowlisted node types, randomization modes, and packaged engine families. They cannot contain shell commands, executable paths, Python source, dynamic imports, or plugin entry points. Individualized runners are thin static wrappers that select one reviewed manifest; experimental behavior remains in the single hashed Atlas engine. Authorized discovery resolves exactly the package-owned Atlas root and its package-owned native compatibility sibling. A different configured root cannot acquire execution authority.

Protocol Forge governs candidates in the native PRAYCG declarative grammar. An external Atlas candidate instead must be staged outside the active library, validated against the Atlas schema and typed-engine boundary, human-reviewed, versioned, and deliberately included in a future package. Neither path is an in-place arbitrary Python plugin mechanism.

The engine supports timed instructions/rest/fixation, audio/video, checkerboards and generated visual trials, P3b oddball blocks, motor/imagery cues, in-media event keypresses, structured questions, confidence/ratings, free recall, ranking, scheduled sessions, and progress checkpoints. Unsupported node types fail rather than being skipped, including unsupported nested children. A break declared with `skippable_after_seconds` accepts its declared `skip_keys` (SPACE by default) only after that threshold and records `ATLAS_BREAK_SKIPPED_AFTER_THRESHOLD`.

Checkpoint files are evidence only in alpha.3. Resume is disabled, and a resume variable fails closed. An interrupted run remains incomplete; the reviewed recovery workflow finalizes that record, and any retry begins with a new UUID, preflight, session lock, and arm. Inherited Atlas session/run/parameter variables likewise cannot change the locked compiled plan.

### Runtime evidence chain

For a launch to proceed, the following identities must agree at the relevant gates:

$$
\begin{aligned}
&h(M) = h(M_{approved}) = h(M_{runtime}),\\
&h(R) = h(R_{approved}) = h(R_{runtime}),\\
&h(E) = h(E_{approved}) = h(E_{runtime}),\\
&h(C) = h(C_{locked}) = h(C_{recomputed}),\\
&\forall a\in A^*: h(a)=h(a_{locked}),\\
&\mathrm{UUID}_{child}=\mathrm{UUID}_{lock},
\quad p_{child}=p_{lock}.
\end{aligned}
$$

The same one-use owner/lease/PID binding used by native PRAYCG runners is consumed before the experiment UI. Atlas then performs an operator-visible LabRecorder hold, revalidates the binding, opens the fullscreen window, emits node/trial markers, records responses, writes progress checkpoints as evidence, and attempts the truthful `FINALIZE` transition. Escape or an exception is recorded as incomplete; it is not silently promoted to a completed or resumable run.

### Presentation-marker and optical-witness boundary

For a visual Atlas node, onset is scheduled through PsychoPy `callOnFlip` on the same display flip that first presents the node. Let $t^{LSL}_{flip}$ denote the callback's marker time. The recorded event supports the bounded statement “the software issued this marker at the PsychoPy flip boundary.” It does not establish photon onset $t_{photon}$, audio onset, or sub-frame accuracy:

$$
t^{LSL}_{flip}\ \not\equiv\ t_{photon}.
$$

These times are not equivalent without an independently validated display/optical timing model.

When a lock-bound runtime policy enables the Atlas ALS overlay, alpha.3 presents it only around top-level continuous `video`, `boundary_media`, `media_playlist`, and `rapid_trials` nodes. Overlay markers establish intended pattern timing, not retinal delivery or PT19 visibility. The separate run-bound barcode placement test and a measured offset/uncertainty report remain necessary.

The packaged NATVIEW defaults leave its checkerboard disabled, and alpha.3 has no general authorized parameter UI with which to enable it. In a separately reviewed candidate that enables it, the engine records each `ATLAS_CHECKERBOARD_DISPLAY_FLIP` and classifies timing as `PASS`, `DISCREPANT`, or `UNAVAILABLE` against `maximum_reversal_lateness_seconds`. Even `PASS` is software timing evidence, not a physical display validation.

The Atlas engine does not yet implement a runner-internal EEG dropout watchdog or an enforced custom video safe-fit/letterboxing policy. Its present boundary is the separate Acquisition preflight/supervisor plus PsychoPy's native movie behavior. Actual fit/cropping, codec/audio behavior, live stream continuity, input timing, and optical/display timing require supervised apparatus tests.

### Plain-language explanation

The Atlas is a library of experiment blueprints. The blueprint says what appears, when it appears, which buttons matter, and which files are allowed. Acquisition separately says which sensors are connected and whether they are healthy. Just before a run, the Control Center seals the chosen blueprint, participant/session order, sensor profile, and exact files into one tamper-evident record. This makes many protocols plug-and-play at the operator level without treating them as interchangeable scientifically.

### Current validation boundary

Release acceptance requires discovery of the 14-entry federated catalog (3 native plus 11 Atlas) and successful dry-run execution of all 11 individualized Atlas wrappers. The Atlas entries also receive schema validation, recursive timeline validation, deterministic asset-aware compilation, wrapper inspection, and asset-contract tests. Those checks do not demonstrate actual monitor timing, audio latency, frame accuracy, key-device behavior, LabRecorder synchronization, physical OpenBCI/ALS/Polar/Vernier acquisition, video fit/cropping, in-run EEG watchdog behavior, participant tolerability, or recovery after every real-world failure. Each protocol requires supervised apparatus testing and a feasibility pilot before scientific use. Alpha findings must report which validation layers were actually completed.

---

## 4. CAI/SID v0.2 — Controlled Access-Integration Index

### Construct boundary

CAI means **Controlled Access-Integration Index**, not Conscious Access Index. It asks a bounded operational question:

> How much above-reference support is present in specified fast access-like and slower integration-like features, with an additional reward for delayed joint support and explicit artifact/task-load penalties?

CAI is unitless and bounded. It is not a probability, diagnosis, direct consciousness measurement, proof of narrative reception, or validated measure of meaning.

### 4.1 Why v0.1 was revised

An earlier proposal used a hand-weighted logistic score:

$$
CAI_{v0.1}(t)=G_{QC}(t)\,\sigma(2Z(t)),
$$

$$
\begin{aligned}
Z(t)=&\,1.15E_{fast}+1.00Y_{slow}+1.20K_{loop}+0.90D_{gate}+0.55R_{auto}\\
&-1.15A_{artifact}-0.85X_{task}-0.80C_{confound}-1.10.
\end{aligned}
$$

Those coefficients were theoretical choices, not fitted biological constants. More importantly, the earlier loop logic could treat fast-low/slow-low similarity as favorable loop evidence. v0.2 removed that ambiguity, adopted an equal-weight primary support composite, and separated contextual and autonomic evidence from primary CAI.

### 4.2 Fast access-like component

Let $z_M,z_T,z_N,z_V$ denote Baseline-1-referenced MeaningGamma, TSP, optional NIP, and VisualGamma. With $I_j(t)=1$ when component $j$ is available at $t$, the implemented available-input mean is

$$
L_E(t)=
\frac{0.45I_Mz_M+0.35I_Tz_T+0.20I_Nz_N}
{0.45I_M+0.35I_T+0.20I_N}
-0.10[z_V(t)]_+,
$$

and

$$
E(t)=\sigma(L_E(t)).
$$

The denominator renormalizes only over available positive inputs. The selected source column and adapter grade are recorded. General gamma is not assumed to be measurement-equivalent to MeaningGamma.

### 4.3 Slow integration-like component

For Baseline-1-referenced theta integration, NAS, and posterior alpha, let $I_\theta(t)$, $I_{NAS}(t)$, and $I_\alpha(t)$ indicate availability. The implemented available-input mean is

$$
L_Y(t)=
\frac{0.50I_{\theta}z_{\theta}+0.30I_{NAS}z_{NAS}+0.20I_{\alpha}z_{\alpha}}
{0.50I_{\theta}+0.30I_{NAS}+0.20I_{\alpha}},
$$

$$
Y(t)=\sigma(L_Y(t)).
$$

The value is missing when the availability-weight denominator is zero. These are candidate feature families. They do not independently prove comprehension, memory consolidation, or conscious integration.

### 4.4 Retrospective future-slow value

Within the same contiguous block instance (b), v0.2 computes

$$
Y_{future}(t)=
\operatorname{mean}\{Y(s):s\in b,\ t+8\le s\le t+30\}.
$$

At least five future samples are required. There is no branch-end median fill; values near the end of a block become missing when future coverage is insufficient. Because this term uses future samples, CAI is an offline retrospective estimate, not a live causal state readout.

### 4.5 Corrected positive loop

Define above-neutral evidence

$$
e^+(t)=[E(t)-0.5]_+,
\qquad
y^+(t)=[Y_{future}(t)-0.5]_+.
$$

The positive product is

$$
K_{product}^{+}(t)=2\sqrt{e^+(t)y^+(t)}.
$$

If a local correlation is estimable in the declared 31-second window,

$$
\rho^+(t)=[\operatorname{corr}_{local}(E,Y_{future})]_+,
$$

$$
K(t)=0.70K_{product}^{+}(t)+0.30\rho^+(t).
$$

If correlation is not estimable, the implementation uses $K=K_{product}^{+}$ and records correlation unavailability. This does not invent a positive correlation term, but it changes the effective weighting: with an estimable correlation, $K=0.70K_{product}^{+}+0.30\rho^+$, whereas the fallback assigns full weight to the product. Consequently, otherwise identical rows with and without an estimable correlation are not strictly score-comparable. The availability flag must travel with summaries, and sensitivity analyses should compare common-availability rows.

#### Why fast-low/slow-low is not positive loop evidence

If $E\le0.5$ or $Y_{future}\le0.5$, then one positive-excess term is zero. For the first case,

$$
K_{product}^{+}=2\sqrt{0\cdot y^+}=0.
$$

Symmetrically, for the second case,

$$
K_{product}^{+}=2\sqrt{e^+\cdot0}=0.
$$

Thus jointly low signals can be similar or correlated, but they do not support the positive loop. The geometric mean also imposes an “AND-like” rule: both above-neutral components are required, and an imbalance is penalized relative to two jointly high components.

### 4.6 Artifact and task penalties

The implemented artifact latent uses available standardized artifact components:

$$
L_A(t)=\operatorname{weighted\_available}
\left(0.55z_{artifact},0.25z_{HF},0.20z_{P2P}\right),
$$

$$
A(t)=\sigma(L_A(t)),
\qquad
X(t)=\sigma(z_{task}(t)).
$$

Only above-neutral penalty evidence is used:

$$
A^+(t)=\operatorname{clip}_{[0,1]}(2[A(t)-0.5]),
$$

$$
X^+(t)=\operatorname{clip}_{[0,1]}(2[X(t)-0.5]).
$$

Hard QC fails when declared standardized artifact sentinels exceed their thresholds: artifact (>5), high-frequency sentinel (>5), or P2P (>5) when P2P is available. A hard-failed row is missing, not zero.

### 4.7 Primary v0.2 composite

Fast and slow positive evidence are

$$
E^+(t)=\operatorname{clip}_{[0,1]}(2[E(t)-0.5]),
$$

$$
Y^+(t)=\operatorname{clip}_{[0,1]}(2[Y(t)-0.5]).
$$

The equal-weight support and penalty terms are

$$
Support(t)=\frac{E^+(t)+Y^+(t)+K(t)}{3},
$$

$$
Penalty(t)=\frac{A^+(t)+X^+(t)}{2}.
$$

The current primary score is

$$
CAI_{core}(t)=Support(t)[1-Penalty(t)].
$$

If required fast, slow, loop, artifact, or task values are unavailable, or hard QC fails, $CAI_{core}(t)$ is missing.

#### Boundedness

Because each support and penalty component lies in $[0,1]$, their arithmetic means also lie in $[0,1]$. Therefore

$$
0\le Support\le1,
\qquad
0\le1-Penalty\le1,
$$

and

$$
0\le CAI_{core}\le1.
$$

This mathematical bound does **not** make CAI a probability. Probability requires empirical calibration against an independently defined event or state.

### 4.8 Contextual reliability is separate

When independent DGA/context information exists,

$$
Reliability_{context}
=D_{gate}(1-ConfoundLoad)(1-ExtractionLoad),
$$

$$
CAI_{context\text{-}gated}
=CAI_{core}\,Reliability_{context}.
$$

This is an attribution-confidence sensitivity output. It does not replace primary CAI and is not an independent physiological channel.

### 4.9 Time summaries and SID-style density

For valid duration $T_{valid}$,

$$
Mean\_CAI=\frac{\int_{\mathcal V}CAI_{core}(t)\,dt}{T_{valid}},
$$

$$
CAI_{load}=\int_{\mathcal V}CAI_{core}(t)\,dt,
$$

$$
CAI_{occupancy}(\tau)
=\frac{\operatorname{valid\ time}\{CAI_{core}(t)\ge\tau\}}{T_{valid}}.
$$

The current exploratory occupancy threshold is $\tau=0.50$. A general interval density is

$$
SID_{[a,b]}=
\frac{\int_{[a,b]\cap\mathcal V}CAI_{core}(t)\,dt}
{T_{valid,[a,b]}},
$$

where $\mathcal V$ is the set of valid time points and $T_{valid,[a,b]}$ is valid duration within the interval. SID is missing when valid duration is zero or below a declared minimum; reports must carry valid-time coverage. It is computed discretely on the available time grid. Moving-block bootstrap intervals use 30-second blocks and 1,000 replicates. They describe within-run temporal stability; they do not turn one participant into a population sample.

### Why CAI/SID was added

Earlier PRAYCG analyses produced multiple partially overlapping features. CAI/SID creates one frozen, inspectable candidate that averages positive fast evidence, positive slow evidence, and a delayed joint-support term, then explicitly penalizes artifact and task burden. Fast and slow terms can contribute separately; joint elevation is specifically rewarded through the loop term. Its purpose is falsifiability and disciplined comparison—not to compress consciousness into a number.

### Plain-language explanation

CAI asks how much positive fast and slow evidence is present, whether they also support each other across the declared delay, and whether artifact or task load weakens that interpretation. One current component may contribute without the other, while the loop reward requires both positive fast evidence and positive future-slow evidence. It refuses to count “both low” as a positive loop and refuses to turn bad data into a low score.

---

## 5. Continuous Autonomic/RespDualPath v1.0

### Why continuous arrays were added

A branch average cannot answer when heart rate changed, whether an HRV estimate was supported by enough beats, whether a sigh caused the apparent response, or whether a post-Target pattern began only after the arithmetic task ended. The v1.0 module therefore represents autonomic state as synchronized time series rather than a condition-coded constant.

The implemented outputs remain separate from primary CAI.

### 5.1 Time grids and beat-event table

The primary display/alignment grid is 4 Hz:

$$
t_k=t_0+k\Delta t,
\qquad
\Delta t=0.25\ \mathrm{s}.
$$

The report grid is 1 Hz. A new 4 Hz or 1 Hz row is a repeated estimate, not a new independent biological observation.

For retained beat (j),

$$
IBI_j=\frac{RR_j}{1000}\ \mathrm{s},
\qquad
HR_j=\frac{60}{IBI_j}=\frac{60000}{RR_j}\ \mathrm{bpm}.
$$

The implemented physiological range is

$$
300\ \mathrm{ms}\le RR_j\le2000\ \mathrm{ms},
$$

equivalent to approximately 200–30 bpm. Values outside the range are excluded and recorded; v1.0 does not silently correct them.

### 5.2 Interpolated HR versus beat-derived HRV

Valid instantaneous HR is linearly interpolated onto the 4 Hz grid only when the nearest valid beat is within 3 seconds and the surrounding source gap is no more than 6 seconds. Every non-exact value carries an interpolation flag.

The critical rule is:

> Interpolation may support display and time alignment of HR, but interpolated samples are never used to manufacture HRV observations.

### 5.3 Rolling HRV

For valid beat intervals in a centered window $W_k$,

$$
RMSSD_{W_k}
=\sqrt{\frac{1}{N_{diff}}\sum_{j=1}^{N_{diff}}(RR_{j+1}-RR_j)^2}.
$$

v1.0 uses a 30-second centered window and requires at least 15 differences between adjacent retained intervals. The implementation applies `diff` after invalid RR intervals have been removed; a retained pair can therefore bridge an excluded interval and is not guaranteed to be consecutive in the original beat-event sequence. The same retained-series adjacency limitation applies to pNN50 below. The event table and exclusion counts must be reviewed, and promotion would require an original-adjacency guard.

For the 60-second centered window,

$$
SDNN_{W_k}
=\sqrt{\frac{1}{N-1}\sum_{j=1}^{N}(RR_j-\overline{RR})^2},
$$

$$
pNN50_{W_k}
=\frac{1}{N-1}\sum_{j=1}^{N-1}\mathbf 1(|RR_{j+1}-RR_j|>50\ \mathrm{ms}).
$$

At least 30 valid beats are required for SDNN and pNN50. The output also reports valid-pair counts, beat counts, expected-beat coverage, and the fraction excluded. These definitions follow conventional time-domain HRV quantities, while the short, overlapping PRAYCG windows remain exploratory and should not be treated as independent or clinical measurements ([1996 ESC/NASPE Task Force standard](https://pubmed.ncbi.nlm.nih.gov/8598068/)).

### 5.4 Respiration signal

The implementation interpolates raw belt samples onto the 4 Hz grid with a maximum 1-second source distance, fills internal gaps for filtering, and applies an offline fourth-order zero-phase Butterworth bandpass from 0.05 to 0.7 Hz:

$$
r_f(t)=\operatorname{Bandpass}_{0.05-0.7\,Hz}(r_{raw}(t)).
$$

The analytic signal is

$$
z_r(t)=r_f(t)+i\mathcal H[r_f(t)],
$$

where $\mathcal H$ is the Hilbert transform. The implemented phase and amplitude are

$$
\phi_r(t)=\operatorname{unwrap}(\operatorname{arg} z_r(t)),
$$

$$
a_r(t)=|z_r(t)|,
\qquad
Depth(t)=2a_r(t).
$$

`Depth(t)` is peak-to-peak analytic amplitude in the respiration belt's relative sensor units. Without calibration against volume, it is not tidal volume and should not be reported in liters.

Instantaneous breathing rate is

$$
BR(t)=\frac{60}{2\pi}\frac{d\phi_r(t)}{dt},
$$

followed by a centered five-second rolling median. Values outside 2–60 breaths/minute are invalid. Phase is also invalid when amplitude is below 20% of the median amplitude or the row is inside a hold candidate.

Respiratory velocity and acceleration are

$$
v_r(t)=\frac{dr_f(t)}{dt},
\qquad
a_r^{(2)}(t)=\frac{d^2r_f(t)}{dt^2}.
$$

### 5.5 Sigh, hold, and motion candidates

The implemented sigh candidate marks robust amplitude peaks satisfying

$$
z_{robust}(a_r(t))\ge3.0
$$

with an 8-second refractory interval.

The implemented motion caution is

$$
MotionRisk(t)=\max\left(
|z_{robust}(v_r(t))|,
|z_{robust}(a_r^{(2)}(t))|
\right),
$$

with a caution threshold of 4.0.

The current hold detector is a permissive candidate. It marks a contiguous interval of at least 4 seconds when either

$$
a_r(t)<0.20\operatorname{median}(a_r)
$$

or

$$
|z_{robust}(v_r(t))|<0.05.
$$

The source theory described the stricter conjunction “low amplitude **and** low velocity.” The shipped v1.0 implementation uses **OR**, so hold labels must remain candidate events and should be sensitivity-tested before scientific promotion.

### 5.6 Dual-path rule

The same respiratory event can legitimately receive both labels:

$$
RespStateEvent(t)=1,
\qquad
RespArtifactCaution(t)=1.
$$

This is not contradictory. A sigh may be a genuine autonomic event while its chest/head movement or breathing-linked physiology also contaminates EEG or changes HRV. The state event is preserved; the overlapping clean-EEG interpretation is weakened.

### 5.7 HR–respiration lag coupling

Within each centered 60-second window, the implementation evaluates Pearson correlation over a fixed lag grid

$$
\ell\in\{-10.00,-9.75,\ldots,9.75,10.00\}\ \mathrm{s}.
$$

For lag $\ell$,

$$
r_{HR,Resp}(\ell;t)
=\operatorname{corr}_{W_t}(HR(u),r_f(u+\ell)).
$$

The diagnostic best lag is

$$
\ell^*(t)=\operatorname{argmax}_{\ell}|r_{HR,Resp}(\ell;t)|,
$$

and the signed correlation at that lag is retained. In each centered window, the implementation requires at least 80% finite-pair coverage in the unshifted HR/respiration pair before performing the lag search; each individual lag correlation then requires at least 10 paired values. The whole-run best-lag summary uses the per-lag finite pairs and does not impose the same 80% gate. These scopes must not be conflated. Searching many lags is multiplicity-sensitive; the best correlation is not a confirmatory statistic by itself.

For $B=200$ circular-shift replicates, respiration is shifted by an admissible offset of at least 30 seconds, the entire lag search is repeated, and the empirical two-sided absolute-tail diagnostic is

$$
p_{shift}
=\frac{1+\sum_{b\in\mathcal B_{valid}}\mathbf 1(|r_b^*|\ge|r_{obs}^*|)}
{1+B_{valid}},
$$

where $\mathcal B_{valid}$ contains only shift replicates for which the searched statistic is estimable and $B_{valid}=|\mathcal B_{valid}|$. The requested replicate count is 200, but the valid denominator must be reported if any replicate is unavailable.

### 5.8 Implemented versus future autonomic formulas

The source proposal also described HR–respiration coherence, phase-locking value, a regulatory-recovery composite, continuous autonomic support $R_{auto}(t)$, and continuous AAM. Those formulas are scientifically useful candidates, including

$$
Coh_{HR,Resp}(f,t)=
\frac{|S_{HR,Resp}(f,t)|^2}{S_{HR,HR}(f,t)S_{Resp,Resp}(f,t)},
$$

$$
PLV(t)=\left|\frac{1}{N}\sum_{n\in W_t}e^{i(\phi_{HR}(n)-\phi_{Resp}(n))}\right|,
$$

but v1.0 does **not** currently implement coherence or PLV and does not insert $R_{auto}(t)$ into primary CAI. They must remain proposed future extensions until their estimators, windows, quality rules, nulls, and validation criteria are frozen.

### Plain-language explanation

The module keeps a clean record of actual heartbeats, draws a clearly flagged HR line between them, computes HRV only from real retained beat intervals, reconstructs breathing, and asks whether HR and breathing move together more than expected after time shifting. A breath can be meaningful physiology and a measurement problem at the same time.

---

## 6. Prospective PRAYCG3/PRAYCG4 package v0.1

### Why a separate prospective package was needed

The public PRAYCG3 and PRAYCG4 protocols preserve continuity with the historical fixed-order design. Changing their order in place would make protocol identity ambiguous. The prospective package therefore creates separately named, immutable variants while leaving the public runners unchanged.

### 6.1 Williams first-order balance

With $q$ conditions, a Williams design aims to balance both period and first-order carryover. Informally, across the complete sequence set:

$$
N_{p,c}\approx \text{constant for every period }p\text{ and condition }c,
$$

and

$$
N_{a\rightarrow b}\approx \text{constant for every ordered pair }a\ne b.
$$

For an even number of treatments, $q$ sequences are sufficient; for an odd number, the reversed sequences are added, yielding $2q$. This is why PRAYCG3 has six variants and PRAYCG4 has four. The design follows the residual-effect balancing logic introduced by E. J. Williams ([Williams, 1949](https://doi.org/10.1071/CH9490149)).

The generated sequences are:

| Variant | Fixed condition order |
|---|---|
| PRAYCG3P_SEQ01 | Phase → Target → Override |
| PRAYCG3P_SEQ02 | Target → Override → Phase |
| PRAYCG3P_SEQ03 | Override → Phase → Target |
| PRAYCG3P_SEQ04 | Override → Target → Phase |
| PRAYCG3P_SEQ05 | Phase → Override → Target |
| PRAYCG3P_SEQ06 | Target → Phase → Override |
| PRAYCG4P_SEQ01 | Phase → ShotOrder → Override → Target |
| PRAYCG4P_SEQ02 | ShotOrder → Target → Phase → Override |
| PRAYCG4P_SEQ03 | Target → Override → ShotOrder → Phase |
| PRAYCG4P_SEQ04 | Override → Phase → Target → ShotOrder |

Each assigned sequence is fixed before the run starts. The runner never searches for a favorable order.

### 6.2 Deterministic assignment

The current template sorts variants by sequence index and assigns participant $p$ and stimulus $s$ by

$$
j(p,s)=\operatorname{mod}((p-1)+(s-1),m),
$$

where $m$ is the number of variants. This stimulus offset prevents every stimulus from occupying the same sequence within a participant while remaining fully reproducible.

This is a template allocation rule, not concealed randomization. A confirmatory study must declare allocation, masking, exclusions, and analysis before outcome inspection.

### 6.3 Independent outcomes

Prospective reports add recognition, comprehension, recognition confidence, comprehension confidence, narrative coherence, subjective meaning, absorption, afterglow, washout activity, extraction load, and confound burden. The first six are declared independent validity outcomes and are not inputs used to construct CAI.

This separation matters. If the same report both defines CAI and “validates” CAI, the validation is circular.

### 6.4 ALS and provenance

Every video phase requires runner-registered ALS barcode events. The implemented Acquisition button performs a run/profile-bound **ALS Barcode Placement Test** that checks whether the on-screen optical pattern is visible to the PT19 through the selected setup. It does not by itself record or verify the runner launch path, working directory, expected runner event registration, or recovered timing offset.

Before participant collection, a separate prospective apparatus-validation record must verify the launch path, working directory, expected script, runner event registration, optical visibility, and recovered offset with uncertainty on the actual acquisition computer. The implemented visibility report and this broader script-location/timing record answer different questions. Neither establishes neural validity, but without both, anchor-level timing can be misassigned.

The freeze package hashes the protocol engine, protocol manifest, runner, CAI code/configuration, allocation file, stimuli, derivatives, anchors, and other declared inputs:

$$
h_f=SHA256(\operatorname{bytes}(f)).
$$

A later file is identical to the frozen file only if its recorded hash matches. A hash proves file identity, not scientific validity.

### 6.5 Prospective mixed model

A suitable preregistered participant-by-stimulus analysis can be written conceptually as

$$
Y_{isc}=\beta_0+\beta_c+\pi_{period}+u_i+v_s+\epsilon_{isc},
$$

where $u_i\sim N(0,\sigma_u^2)$ is a participant random effect, $v_s\sim N(0,\sigma_v^2)$ is a stimulus random effect, and $\beta_c$ represents the predeclared condition contrasts. Additional carryover terms may be included only if declared in advance and estimable from the design.

### 6.6 Current readiness boundary

The package is **not collection-ready by default**. Real stimuli and derivatives, locked anchor files, ethics/consent approvals where required, real-hardware ALS validation, blinded feasibility data, final variance inputs, multiplicity rules, exclusions, and OSF registration are still required.

### Plain-language explanation

The prospective package prevents “condition” from always meaning “the part that happened second or third.” It rotates condition order across fixed variants, locks each assigned runner, checks that timing markers really work, and fingerprints all critical files so the registered study can be reproduced.

---

## 7. Micro Handoff v0.1

### Hypothesis and boundary

Micro Handoff tests whether a posterior-temporal 30–45 Hz activation proxy is followed, within a requested nominal 100–1000 ms lag bank, by a posterior/parietal-temporal 4–8 Hz activation proxy.

It does not prove that consciousness is generated in discrete 25 ms or 40 Hz frames. “RPM” and “density” are engineering metaphors for exploratory displays, not established biological quantities.

Scalp gamma is particularly vulnerable to ocular and muscle contamination; miniature saccades can generate broadband gamma-range EEG transients ([Yuval-Greenberg et al., 2008](https://pubmed.ncbi.nlm.nih.gov/18466752/)). That is why the candidate preserves jaw, ocular, and global-amplitude sentinels and treats hard failures as missing.

### 7.1 Sampling and causal feature windows

The requested output cadence is nominally

$$
\Delta t=0.025\ \mathrm{s}.
$$

The implementation must place outputs on acquired samples. For sampling rate $f_s$, it uses

$$
n_{step}=\max\{1,\operatorname{round}(0.025f_s)\},
\qquad
\Delta t_{real}=\frac{n_{step}}{f_s}.
$$

Thus the realized step is 24 ms at both 125 Hz and 250 Hz, not exactly 25 ms. The reported cadence must be the realized value. This is a refresh grid, not spectral resolution. At time $t$:

- temporal gamma uses a trailing 250 ms Hann-window periodogram at T5/T6, 30–45 Hz;
- theta integration uses a trailing 500 ms Hann-window periodogram at Pz/P3/P4/T5/T6, 4–8 Hz;
- visual gamma at O1/O2 is retained as a comparison family;
- T3/T4 high-frequency power, Fp1 peak-to-peak, and global neural peak-to-peak are artifact sentinels.

Only samples at or before (t) enter either spectral estimate. Because the windows differ in length, a planted raw-signal lag need not equal the diagnostic feature-series lag exactly.

### 7.2 Fast and slow activations

Using valid Baseline 1 rows only,

$$
F(t)=\sigma\left(z_{B1}[\log P_{30-45Hz,T5/T6}(t)]\right),
$$

$$
S(t)=\sigma\left(z_{B1}[\log P_{4-8Hz,Pz/P3/P4/T5/T6}(t)]\right).
$$

Both are bounded activation proxies, not probabilities.

### 7.3 Artifact quality

Let $Z_s(t)$ be the maximum positive standardized jaw-HF/Fp1 sentinel value and $Z_g(t)$ global neural peak-to-peak. The soft quality score is

$$
Q(t)=
\exp[-0.50(Z_s(t)-2)_+]
\exp[-0.15(Z_g(t)-4)_+].
$$

Rows become missing if sentinel artifact exceeds 5, global P2P exceeds 8, a timestamp gap crosses a feature window, required values are nonfinite, or the row is outside an identified block.

### 7.4 State agreement, positive directional handoff, and density

Define a 100 ms smooth of fast activation and a 250 ms smooth of slow activation. The positive changes are

$$
O(t)=\operatorname{clip}_{[0,1]}\left(
\frac{[F_{100}(t)-F_{100}(t-0.1)]_+}{0.25}
\right),
$$

$$
R(t,\tau)=\operatorname{clip}_{[0,1]}\left(
\frac{[S_{250}(t+\tau)-S_{250}(t+\tau-0.1)]_+}{0.25}
\right).
$$

For every requested nominal lag

$$
\tau\in\{0.1,0.2,\ldots,1.0\}\ \mathrm{s},
$$

the implementation uses the nearest whole-sample offset

$$
n_\tau=\max\{1,\operatorname{round}(\tau/\Delta t_{real})\},
\qquad
\tau_{real}=n_\tau\Delta t_{real}.
$$

The 100 ms differences and smoothing windows are discretized in the same way. Nominal and realized lags should both be retained in provenance.

state coordination is

$$
C(t,\tau)=1-|F(t)-S(t+\tau)|,
$$

paired quality is

$$
Q_{pair}(t,\tau)=\sqrt{Q(t)Q(t+\tau)},
$$

positive directional handoff is

$$
H(t,\tau)=Q_{pair}(t,\tau)\sqrt{O(t)R(t,\tau)},
$$

mean activation is

$$
A(t,\tau)=\frac{F(t)+S(t+\tau)}{2},
$$

and activation-weighted coordination density is

$$
D(t,\tau)=Q_{pair}(t,\tau)A(t,\tau)C(t,\tau).
$$

The primary candidate values are equal-weight means across the complete lag bank:

$$
\bar H(t)=\frac{1}{10}\sum_{\tau}H(t,\tau),
\qquad
\bar D(t)=\frac{1}{10}\sum_{\tau}D(t,\tau).
$$

No condition-specific winning lag is selected. A 500 ms trace and a full-run best lag are diagnostic only.

### 7.5 Why the three outputs are separate

The separation prevents three different states from being conflated:

| State | (C) | (H) | (D) | Interpretation |
|---|---:|---:|---:|---|
| Low fast, low slow | Can be high | Low | Low | Similarity without positive activation or handoff. |
| High fast, high slow, stationary | High | Low | High | Sustained activated coordination without positive transition. |
| Fast rises, then slow rises | Potentially high | High | Potentially high | Candidate positive directional handoff. |

The geometric means in $Q_{pair}$ and $H$ impose joint support: one poor-quality endpoint or one absent positive transition limits the score.

### 7.6 Nulls and uncertainty

The module does not treat nominal 25 ms rows (24 ms at 125 or 250 Hz) as independent observations. It summarizes non-overlapping 30-second blocks and evaluates time-structure nulls on a nominal 100 ms diagnostic grid that is likewise realized on available rows.

- **Circular-shift null:** disrupts absolute alignment while preserving each series’ internal shape.
- **Phase-randomized null:** preserves the approximate spectrum while disrupting specific timing structure.
- **Block-label permutation:** tests label association when exchangeability is defensible.
- **Artifact-matched contrast:** checks whether condition differences persist under comparable artifact distributions.

### 7.7 Synthetic acceptance

All 14 declared synthetic software checks passed. A planted 500 ms raw-signal handoff was recovered at a 600 ms diagnostic lag, within the declared ±100 ms tolerance for unequal causal spectral windows. The suite also verified low-low, stationary high-high, reverse-direction, independent, artifact, timestamp-gap, null, and deterministic-repeat behavior.

This validates declared software behavior on synthetic fixtures. It does not validate a consciousness construct.

### 7.8 Historical-use boundary

This public alpha package does not include an immutable, independently verifiable aggregate artifact supporting numerical claims about prior Micro Handoff runs. No historical count, contrast, interval, lag range, or null-test result is therefore asserted in this specification. If private retrospective results are cited elsewhere, they must be accompanied by a frozen aggregate report, input/configuration/code hashes, eligibility and missingness tables, and a clear statement of participant and stimulus dependence. Such results remain hypothesis-generating and cannot supply population inference or prospective construct validation.

### Plain-language explanation

Micro Handoff asks whether fast activity rises and is followed shortly afterward by a rise in slower activity. It separately reports whether the two signals merely look alike, whether both are strongly active, and whether a positive fast-to-slow change occurred. The public specification makes no numerical claim about historical runs without a packaged, hash-verifiable aggregate artifact.

---

## Cue-Locked Gamma Forensics v0.1

### Role and claim boundary

Cue-Locked Gamma Forensics (CLGF) is an `EXPLORATORY_SECONDARY_CONFOUND_EXTENSION` to OCM/OSA/AAM. It does not create a PRAYCG primary score, alter Master Suite eligibility, or classify a signal as cortical or muscular with certainty. Its narrower question is:

> When 30–45 Hz power differs around arithmetic cues, are the timing, spectral breadth, scalp distribution, amplitude behavior, and autonomic association more compatible with a cue-evoked artifact explanation, or does the result remain indeterminate after those checks?

The intended comparison uses the same cue-embedded movie at matched within-movie times when available. Target instructs the participant to ignore the numbers; Override requires a running sum. This controls much of the media content and time within movie, but not cue orienting, gaze, arithmetic effort, facial tension, posture, or arousal. The contrast is diagnostic rather than causal.

### Cue epochs and baseline correction

For cue $i$, condition $c$, region $r$, and time relative to the runner marker $u$, let $L_{i,c,r}(u)$ be log-transformed 30–45 Hz power. The frozen windows are

$$
W_{pre}=[-0.70,-0.10),\quad
W_{early}=[0.15,0.45),\quad
W_{late}=[0.45,0.85),
$$

$$
W_{sustained}=[0.85,2.25),\quad
W_{maintenance}=[2.25,2.85)\ \text{seconds}.
$$

The within-cue change for window (W) is

$$
d_{i,c,r,W}=\operatorname{median}_{u\in W}L_{i,c,r}(u)
-\operatorname{median}_{u\in W_{pre}}L_{i,c,r}(u).
$$

For a cue paired by schedule index and approximate movie time, the Override-minus-Target diagnostic is

$$
D_{i,r,W}=d_{i,Override,r,W}-d_{i,Target,r,W}.
$$

Run summaries use robust location statistics and bootstrap intervals as declared by the frozen configuration. At least 20 paired cues are required. Missing, boundary-truncated, artifact-rejected, or timing-ineligible cues remain excluded with a reason; they are not replaced by zero.

### Temporal saccade-lock diagnostic

The early window covers the approximate latency at which a visual cue can induce orienting or eye movement. A sharp, repeatable early positive (D) is artifact-compatible, especially when it converges with ocular/perimeter channels or broad high-frequency power. It is not decisive: attention and visual evoked activity can also be time-locked, while variable saccades can smear an artifact into a broader average. A sustained elevation is likewise not proof of neural origin because sustained jaw, forehead, or postural tension can be broad and persistent.

### Spectral guard-band diagnostic

At the 125 Hz sampling rate used by the applicable legacy recordings, Nyquist frequency is 62.5 Hz. A proposed 70–100 Hz test is impossible on those data and must not be fabricated. The implemented CLGF output therefore reports 30–45 Hz and the available 45–55 Hz guard band separately. It does not currently compute a breadth ratio. A future version could preregister such a ratio only after defining its aggregation level and a numerical stabilizer $\epsilon$ in the units of the denominator; that proposed quantity must not be attributed to v0.1.

Broad co-elevation is compatible with muscle contamination, not “100% muscle.” Line noise, filtering, spectral leakage, sensor noise, and true broadband neural changes are possible. A quiet guard band weakens one broadband-artifact account but does not prove a localized oscillatory generator. A future higher-sampling acquisition may predeclare a wider 70–100 Hz sentinel.

### Spatial/perimeter diagnostic

Let $R_P$ be the declared perimeter/ocular-temporal channels and $R_C$ the central-midline comparison. First aggregate paired cue contrasts within each region,

$$
\widetilde D_{r,W}=\operatorname{median}_{i\in\mathcal I_{r,W}}D_{i,r,W},
$$

where $\mathcal I_{r,W}$ is the set of eligible paired cues for region $r$ and window $W$. A descriptive spatial contrast is then

$$
T_{peri-central,W}
=\operatorname{median}_{r\in R_P}\widetilde D_{r,W}
-\operatorname{median}_{r\in R_C}\widetilde D_{r,W}.
$$

A positive perimeter-dominant pattern is artifact-compatible. A central or posterior pattern can remain neural-compatible, but scalp topography is not source localization. Volume conduction, reference choice, channel loss, and montage asymmetry remain relevant. The legacy 16-channel order is used only when confirmed by metadata or explicitly graded as an assumption.

### Autonomic association diagnostic

For gamma trace $g_t$ and autonomic trace $a_t$, CLGF may evaluate

$$
r(\ell)=\operatorname{corr}(g_t,a_{t+\ell})
$$

over a declared lag bank. Circular time shifts estimate a null while preserving much of each series’ autocorrelation:

$$
r^{(b)}_{null}(\ell)
=\operatorname{corr}\!\left(g_t,a_{\operatorname{mod}(t+\ell+s_b,T)}\right).
$$

An association supports only shared-state or arousal covariation. It cannot show that autonomic arousal caused the EEG feature, that muscle caused both, or that either signal measured meaning. Multiple lags, channels, bands, windows, and autonomic variables create multiplicity; uncorrected findings remain secondary.

### Conservative synthesis

Strong convergence of early cue locking, broad guard-band increase, perimeter/ocular dominance, extreme amplitude, and autonomic covariation supports `ARTIFACT_PATTERN_SUPPORTED`. Incomplete or conflicting evidence yields `INDETERMINATE` or `INDETERMINATE_TIMING_OR_COVERAGE`. `NEURAL_COMPATIBLE_NOT_ESTABLISHED` means only that the tested artifact pattern did not converge; it does not establish a cortical source.

Synthetic validation recovered a planted directional effect, centered the sign-flip null, and verified exclusion rather than zero-filling of missing samples. This establishes specified software behavior on synthetic data only.

### Plain-language explanation

The module asks whether task-related gamma behaves like a quick cue-triggered eye/facial response, broad high-frequency tension, an edge-of-head pattern, or a signal that rises with bodily arousal. None is a lie detector. Their value is convergence: the more artifact-compatible fingerprints agree, the less defensible it is to tell a purely cognitive story. If they do not agree, the result remains unresolved rather than “proven neural.”

---

## 8. Confound-defense modules

These modules do not “correct away” every confound. They determine whether required evidence exists, compute bounded diagnostics where possible, and constrain interpretation.

### 8.1 HOC-R — High-Order Control Residualization

Two shipped paths currently carry the HOC-R label and must not be conflated. The standalone HOC-R launcher reports descriptive branch means and branch deltas for available PRAYCG measures. It does not residualize an outcome. The Confound Expansion path inventories low-level visual, low-level audio, cue, and high-order social/visual regressors. When enough complete data exist, that path truncates the supplied outcome and regressor tables to a common row count, assumes the remaining row order is aligned, and fits

$$
\mathbf y=\mathbf X\boldsymbol\beta+\boldsymbol\varepsilon
$$

by ordinary least squares with an intercept, and reports in-sample

$$
R^2=1-\frac{\sum_t(y_t-\hat y_t)^2}{\sum_t(y_t-\bar y)^2}.
$$

The Confound Expansion output reports model availability, terms, row count, and in-sample training $R^2$. It does not join rows by time or condition, compute an adjusted condition contrast, or replace the outcome with a causal residual endpoint. Neither shipped HOC-R path establishes that a Target effect survives adjustment. Row alignment, scaling, rank, overlap, and regressor measurement quality must be audited independently. If face/body/object/AOI regressors are absent, Target versus PhaseScrambled remains high-order-control-cautioned.

### 8.2 OSA — Override Spatial Attention/AOI burden

Cue duty cycle is

$$
duty=\frac{cue\ display\ duration}{cue\ interval}.
$$

Each available 0–9 report is mapped to ([0,1]) by (x/9). The report burden is the mean of available cue-legibility, cue-blur/smallness, eye-strain/squint, running-sum-stall, and task-load ratings:

$$
B_{report}=\operatorname{mean\_available}(L,B,E,S,T).
$$

The OSA score is

$$
OSA=\operatorname{mean\_available}(duty,B_{report}).
$$

The current flag is raised when $OSA\ge0.35$ and no gaze/AOI evidence is found. The threshold is exploratory. The purpose is to prevent Target-minus-Override from being called pure “task theft” when cue monitoring may have changed where the participant looked.

### 8.3 OHC — Order, habituation, and carryover

OHC records inferred branch order, washout duration, and whether the historical default order was used. The current implementation recognizes only Control, Target, and Override; a ShotOrder branch is not modeled. Any recognized nondefault order is labeled counterbalanced, but the code does not verify that it came from a valid Williams allocation. In the default Target-before-Override sequence, the implemented heuristic assigns habituation risk 1.0 and carryover risk 0.8 unless a washout of at least 600 seconds is documented; even then, carryover risk remains 0.3.

These are warning heuristics, not fitted probabilities. Their function is to make the non-identifiability in the fixed-order contrast explicit.

### 8.4 AAM — Afterglow Attribution Model

For feature vectors $\mathbf x$ and $\mathbf y$, similarity is

$$
sim(\mathbf{x},\mathbf{y})=
\frac{\mathbf{x}^{\top}\mathbf{y}}
{\sqrt{\mathbf{x}^{\top}\mathbf{x}}\sqrt{\mathbf{y}^{\top}\mathbf{y}}}.
$$

The current implementation selects, in input-column order, the first 30 numeric feature columns whose names contain `tsp`, `nip`, `theta`, `alpha`, `meaninggamma`, `taskgamma`, `hr`, `rmssd`, `sdnn`, or `resp`. It forms each condition vector from the column means. It does not unit-normalize those features or remove semantically duplicate columns. Cosine similarity is therefore sensitive to column ordering, scale, duplication, and which columns happen to be present. It computes Baseline-2 similarity to post-Target Washout 2 and post-Override Washout 3 where available. Narrative-afterglow-like evidence is the mean of available terms:

$$
NAI=\operatorname{mean\_available}
\left(sim(B2,W2),TargetEcho_{B2},TargetAfterglow,TargetStoryActive_{W2}\right).
$$

Task-completion-relief-like evidence is

$$
TCRI=\operatorname{mean\_available}
\left(OverrideTaskLoad,TaskCompliance,RunningSumStall,sim(B2,W3)\right).
$$

Then

$$
AAM=NAI-TCRI.
$$

Current descriptive labels use (AAM>0.20) for Target-afterglow-like, (AAM<-0.20) for task-relief-like, and the middle range for mixed/ambiguous. Missing evidence remains unavailable; the available-term means can differ in composition and therefore require provenance review.

### 8.5 RespDualPath v0.1 confound audit

The earlier confound-layer implementation prefers `resp_signal_window_mean` where available and otherwise falls back to averaging matching respiration columns. Those fallback columns can represent different units or constructs; dimensional coherence is not guaranteed and the selected inputs must be reported. It then computes

$$
d_t=|r_t-r_{t-1}|,
$$

$$
\theta_d=\operatorname{mean}(d)+2.5\operatorname{SD}(d).
$$

Rows with $d_t>\theta_d$ become respiratory-event candidates. They receive a state-event flag when they occur in declared target/override/washout/Baseline-2 phases and an artifact flag when the available artifact score exceeds 1.0.

The newer Continuous Autonomic/RespDualPath v1.0 is the preferred time-resolved path when raw cardiac and belt data are available. The v0.1 confound module remains a simpler audit for legacy feature tables, with the fallback limitation above.

### Why these modules were added

An apparent Target effect can arise from intact faces and objects, different gaze position, task difficulty, presentation order, task-ending relief, breathing, or artifact. These modules force the report to state which alternatives were measured, which were not, and which remain plausible.

---

## 9. Canonical frame, gates, and status-aware chaining

As the suite grew, data routing became part of scientific validity. The canonical frame requires explicit time, condition, block instance, source column, adapter, evidence grade, and missingness. Repeated instances of the same condition receive unique block IDs so future-window calculations cannot leak across blocks.

The general gate logic is

$$
\mathrm{Status}\in\{\mathrm{PASS},\mathrm{CAUTION},\mathrm{INELIGIBLE},\mathrm{NOT\_APPLICABLE},\mathrm{FAILED}\}.
$$

- `PASS` means declared computational requirements were satisfied.
- `CAUTION` means computation is possible but limitations must travel with the result.
- `INELIGIBLE` means the declared endpoint must not be interpreted for that run.
- `NOT_APPLICABLE` means the protocol lacks the condition or input needed for that module.
- `FAILED` means execution failed and downstream modules must not silently treat the missing output as evidence.

Status-aware chaining allows exploratory outputs to be produced for troubleshooting after a failed primary gate, but those outputs cannot inherit confirmatory status or change Master Suite eligibility.

### Why this was added

A mathematically correct formula applied to the wrong folder, duplicated block, incompatible protocol, missing baseline, or silently adapted feature can still produce a plausible-looking wrong answer. Provenance and gates make those errors inspectable.

---

## Platform architecture and staged internal gates

### One operator-facing Control Center

The platform services remain modular in code, but their user-facing controls are grouped by operator task:

- **Runner / PsychoPy** owns approved protocol selection, **Prospective Assignment Tools…**, protocol launch, and **Advanced Protocol Builder…**.
- **Acquisition** is the sole routine operator hardware workspace. It contains Hardware Profile, Connect & Launch, Live Checks, and Monitor, Record & Arm.
- **Analysis** owns canonical analysis, chained and exploratory modules, output review, **Finalize Interrupted Run**, the four operator-reviewed post-run evidence buttons, and the **Prepare BIDS Export / Verify…** action.
- **Settings** owns path configuration, release validation, developer/package checks, and read-only developer/path-maintenance links to hardware utilities.

This arrangement avoids a second operator console with its own selections and state. It does not collapse the backend services into one untestable component or remove their file-level provenance. The active session context is shared across tabs, but automatically populated paths and selections remain reviewable rather than self-validating.

### Module registry

The module registry is a package-relative allow-list of built-in entry points, display names, and classifications. A path is accepted only when it is relative, contains no traversal, and resolves inside the package. The federated protocol selector reads exactly two package-owned roots: the native PRAYCG compatibility library and the exact packaged Protocol Atlas v2.0 directory. A stale or alternative configured Atlas root is rebased or rejected; it cannot become runner authority. Registration means “discoverable by this build,” not “scientifically validated.” Exploratory modules retain explicit fields such as `primary_score=false` and `master_suite_eligibility_effect=NONE`.

### Protocol Forge

Protocol Forge is exposed by the **Advanced Protocol Builder…** button under Runner / PsychoPy for the native PRAYCG grammar. Its operator actions are **Validate Three Layers**, **Write Dry-Run Timeline**, and **Human Review + Compile Snapshot**. It does not execute arbitrary code from a draft. **Prospective Assignment Tools…** reports a deterministic Williams-sequence assignment and canonical launch instructions but does not open a runner directly. Protocol Atlas uses a separate strict schema and typed engine; each individualized Atlas runner is a small package-owned wrapper around one reviewed manifest. An external Atlas proposal is staged outside the active library, reviewed, versioned, and packaged in a future release rather than executed in place. The two engines share the Control Center's approval and acquisition-authority boundary but do not pretend their task grammars are interchangeable.

Three validation layers are preserved:

1. **Structural:** required fields, value types, supported cue modes, named phases, reports, and scientific boundary.
2. **Semantic/cross-field:** unique phases, required-media coverage, Baseline 1, Baseline 2/final reflection, cue-schedule requirements, and fixed-order warnings.
3. **Package boundary:** the runner is a relative Python entry inside the selected library and actually exists.

A dry run writes the timeline but starts no acquisition. Approval records the reviewer and creates an approval envelope whose snapshot core hashes the canonical module file/content, fixed runner, and shared Protocol Engine. An AI-generated module remains a draft until a human reviewer is named and all layers pass. The resulting approved protocol snapshot is a design-time object; ordinary sessions may reuse the same unchanged snapshot without repeating Forge, but a changed module, runner, engine, or approval-envelope byte invalidates that identity and requires a new candidate.

The bundled Study Session Builder command line is also bounded to design/session preparation. Its only public actions are `prepare` and `lock`; it exposes no command for `ARM`, `ACQUIRE`, `FINALIZE`, or any post-run gate. Producing a prepared draft or lock outside the main interface therefore cannot claim a live runner process or substitute for the Control Center's run-bound checks and authority path.

For file (F), provenance uses

$$
H_F=\operatorname{SHA256}(\operatorname{bytes}(F)).
$$

Hash equality establishes byte identity, not theoretical validity, stimulus equivalence, absence of bias, or successful presentation.

### Hardware Registry and canonical roles

Hardware Registry remains a backend service and is used routinely through **Acquisition → 1. Hardware Profile**; Settings retains read-only developer/path-maintenance links. Hardware modules separate the device from the scientific role. A stream definition can describe LSL name, source identity or explicit dynamic-source policy, canonical role, nominal sampling behavior, channel count, units, and trust level. Canonical roles include EEG, EOG, EMG, ECG, irregular RR intervals, heart rate, respiration, EDA, PPG, generic analog auxiliary data, ALS, and markers. Atlas hardware-role compatibility is checked against the exact lock-bound reviewed profile; runner marker roles are excluded because the runner supplies them. The current full-profile preflight does not enforce every descriptive field, and role compatibility alone does not establish a live or scientifically adequate signal.

Trust levels are `BUILT_IN_TESTED`, `BUILT_IN_ALPHA`, and `COMMUNITY_UNVERIFIED`. The package ships built-in-alpha descriptions for OpenBCI EEG, OpenBCI EEG+ALS, Polar RR, and Vernier respiration, plus unverified generic EOG/EMG and EDA/PPG templates. A configuration file alone cannot promote a device.

The OpenBCI EEG+ALS bridge does not represent ALS as a seventeenth EEG channel. It publishes separate outlets with separate roles: `obci_eeg1` for EEG, `OpenBCIAnalogAux` for the raw auxiliary channel group, `ALS_PT19_Timing` for the derived PT19 optical timing witness, and `OpenBCIStatusMarkers` for bridge status events. This separation prevents an optical timing channel from being silently analyzed as scalp EEG while preserving access to the raw auxiliary samples and derivation path.

For a regular stream with timestamps $t_1,\ldots,t_n$, the observed rate is

$$
\widehat f_s=\frac{n-1}{t_n-t_1}.
$$

Timestamp monotonicity requires $t_{k+1}>t_k$. The 30-second full-profile preflight is bound to the current acquisition UUID and reviewed hardware-profile hash. For each declared LSL name it requires exactly one candidate and enforces the module's fixed, connection-specific, or dynamic run-bound `source_id` policy. It records sample and numeric-sample counts, observed duration, effective rate, strictly increasing/duplicate timestamps, maximum gap, the count of gaps above $\max(0.1\ \mathrm{s},5/f_{nominal})$, observed/expected channel counts, and exact per-channel flatness. It also performs a simple 300–2000 ms RR range/event-coverage check and simple respiratory variation/flatness check when those roles are available, and lists declared device checks that were not performed.

These are short transport and simple signal-health diagnostics. They do not establish saturation or rail behavior, true electrode/contact quality, calibrated noise scale, ALS-pulse visibility, comprehensive physiology, cortical origin, or construct validity. Duplicate same-name outlets and source-identity mismatches are ineligible; unperformed declared checks and other declared concerns remain visible as cautions.

For a selected EEG+ALS profile, the Control Center additionally invokes the detailed 30-second EEG/ALS checker with `--stream-health-only`. The EEG path evaluates engineering heuristics for effective rate, timestamp behavior, flat/noisy/saturated-channel indicators, and completeness. The ALS path requires outlet availability and a `source_id` bound to the current run UUID, but it deliberately neither draws a controlled pulse nor classifies pulse visibility. This prevents opportunistic background variation from being treated as barcode evidence. **ALS Barcode Placement Test** is the sole controlled screen-pulse/placement gate.

### Live checks, unified preflight, and ALS placement test

**Start New Acquisition Session / UUID** is the first live action under **Acquisition → 2. Connect & Launch**. The current-process UUID is supplied explicitly to the OpenBCI and Polar bridges and to the profile preflight CLI through `--run-uuid`; these bridges use dynamic run-bound identities. Vernier retains its reviewed connection-specific `source_id`. Creating the UUID begins the evidence-freshness interval and makes any carried arm or prior-run preflight authority stale. Running or repeating the full-profile preflight does not, by itself, invalidate a same-UUID ALS placement result. **Refresh Visible LSL Streams**, **Signal Quality / Contact Index 0–100**, **ALS Barcode Placement Test**, and **ALS Holder Calibration** are separate actions under **Acquisition → 3. Live Checks**. **Run 30-Second Profile Preflight** is under **Acquisition → 4. Monitor, Record & Arm**. The preflight writes `PASS`, `CAUTION`, or `INELIGIBLE` with reasons; the readiness gate also considers relevant supplemental evidence and never arms automatically. The ALS placement report is bound to the active run UUID and reviewed hardware-profile hash. It shows run/profile-bound optical visibility, but not the script path, working directory, runner event registration, or recovered offset. Those require a separate prospective apparatus-validation record.

### Study/session lock and capability resolver

The approved protocol snapshot is created at design time and can be selected before hardware exists. Alpha.3 exposes no separate session-draft form. Before bridges are launched, the operator uses **Start New Acquisition Session / UUID** to create the live identity for the current Control Center process. That action is blocked while any shared log-root owner, live runner, or unresolved persistent `ACQUIRE` authority exists. It allocates a UUID only when `logs/protocol_runs/<run_uuid>/` does not already exist, then assigns that path as `session_artifact_root`. BrainFlow logs, LSL checks, contact-quality output, supervisor output, the profile and detailed preflight records, `als_barcode_placement_test/`, the internal draft and lock, copied protocol/hardware snapshots, authorized-runner lease/process-binding/consume/exit records, and runner logs are routed beneath this dedicated directory. LabRecorder remains operator-saved and should be directed into the same run directory. A later UUID never reuses an existing directory and therefore does not overwrite the preceding session's evidence. One cross-Control-Center authority record sits above the per-run directories at `logs/protocol_runs/active_acquisition_owner.json`; its immutable terminal markers and safely inactive predecessor archive also remain at that shared root. These are launch-authority records, not outcome data.

When **Create Session Lock** is clicked after the run/profile-bound preflight, the Control Center prompts for operator and participant pseudonym, uses `PRAYCG_ALPHA` as the default study ID unless acquisition configuration supplies another value, and internally builds the draft from the selected protocol approval envelope, reviewed hardware profile, active stimulus/media snapshot, assigned branch order, preflight and supplemental evidence, capability resolution, and private output roots. It also writes `hardware_profile_snapshot.json` and `approved_protocol_snapshot.json` into the same run directory. A convenience path can create a UUID if none exists, but preflight evidence from another UUID or prior process is never accepted.

Only after required streams are live and current preflight evidence is recorded can **Acquisition → 4. Monitor, Record & Arm** create the per-session lock. The canonical `PRAYCG_RuntimeSessionLock_v0_2` binds the actual reviewed inputs for that session and freezes research-critical baseline, washout, stillness, final-reflection, report, channel-map, EEG-watchdog, ALS-barcode, movie-display sizing/calibration, and session-log settings. The operator should use **Open Active Session Lock** to inspect it before **Arm Acquisition Session**. `INELIGIBLE` blocks locking/arming; a permitted `CAUTION` requires an explicit recorded disposition. Any change to a bound approval envelope, runner/engine, stimulus/media, sequence, hardware profile, supplemental evidence, participant pseudonym, or run UUID invalidates the arm state and requires a new acquisition session, preflight, and lock. In particular, changing or clearing the active stimulus context while the lock is at `SESSION_LOCK` or `ARM` immediately disarms it and marks that lock stale.

The canonical launch is **Launch with PsychoPy Python interpreter (recommended canonical path)**. Every child process begins from an environment in which inherited PRAYCG runtime-authority variables have been removed. The Control Center supplies freshly assembled authority values only to the one explicitly authorized direct runner after the acquisition claim succeeds. Coder, PsychoPy-application, debug, analysis, acquisition-utility, and other child tools therefore receive none; pressing Run in a debug window is rejected. Before it writes prefill, and again immediately before lease issue and `ACQUIRE`, the Control Center re-resolves the current stimulus and requires the stimulus ID, folder identity, recognized media/evidence key set, exact paths, and current file SHA-256 values to equal the session lock. A newly supplied optional anchor, ShotOrder manifest, semantic-density sidecar, or other recognized evidence key is rejected if it was not locked. Prefill is constructed only from the immutable locked media snapshot, never from the current mutable UI selection.

For an authorized launch, the Control Center first atomically claims `logs/protocol_runs/active_acquisition_owner.json`. A crash-released operating-system lock on `active_acquisition_owner.guard.lock` serializes owner inspection, safe archival, and creation; exclusive file creation determines the winner. The owner core binds the shared protocol-runs root, owner ID, exact Control Center instance/PID/process-start identity, run UUID, session-lock path and immutable identity, current `ARM` state hash, expected run-local lease path, terminal-marker path, and claim time. Only one cooperating Control Center using that log root wins; a live, uncertain, malformed, or unresolved prior owner blocks. A later claim may archive a prior owner only after its persistent evidence is classified safely inactive.

The winning Control Center next issues a one-use lease inside the run directory and binds that exact lease back into the owner record before `ACQUIRE`. The persisted lease stores a SHA-256 digest of the claim token, not the raw token, and binds the current `ARM` state, lock identity, run UUID, launch command/mode/executable, protocol module/runner/engine hashes, stimulus/folder, and media-snapshot hash. The owner-to-lease binding fixes the lease path and ID, lease-core hash, token digest, and armed-state hash. The Control Center then uses an exclusive on-disk transition claim to advance `ARM → ACQUIRE` before its one common process-launch call. The evidence event must be exactly `AUTHORIZED_RUNNER_PROCESS_CLAIMED_BEFORE_SPAWN` and must match the locked run UUID, a supported direct mode (`psychopy_python` or `regular_python`), the locked protocol ID/version, the approved runner SHA-256, the issued lease path/ID/core hash/token digest/armed-state hash, and the canonical owner path/ID/core hash. The gate engine resolves the owner, verifies its exact owner-to-lease binding, and rejects a missing, malformed, substituted, or noncanonical owner. This claim means that one bounded process capability was reserved for launch, not that usable data were acquired.

After spawn, the Control Center writes an exclusive process-binding record for the exact child PID and, when the operating system exposes it, process-start identity. The child must match that record, atomically consumes the raw one-use token, removes it from its environment at that first consume attempt, and starts a lease heartbeat before showing the runner configuration UI. The token is supplied only through this authorized child environment and is omitted from the Control Center's Running Tools record. Also before the UI, the shared engine requires the matching lock at `ACQUIRE` and revalidates the semantic launch claim—including the canonical owner and exact lease binding—plus lock identity, state hash, and history chain. After the UI returns, and before it creates the local event logger, LSL marker outlet, or PsychoPy experiment window, the engine revalidates the complete protocol module, fixed runner, shared engine, assigned sequence, media, run UUID, participant pseudonym, frozen policy, and entered configuration against the locked binding. Debug modes carry no session-lock or lease capability and cannot satisfy the first precondition. On normal or handled-abort exit, the runner closes the event logger; records existence, byte size, and SHA-256 for the event JSON, event CSV, and run-state manifest; and only then advances `ACQUIRE → FINALIZE`. The runner writes a terminal lease exit marker; if runner cleanup is bypassed, the Control Center process observer attempts a PID/start-bound exit-marker fallback. The owner receives its own immutable terminal record and is released only when the bound lease is terminal and the lock is at `FINALIZE` or later. Pre-`ACQUIRE` cancellation is limited to the same owning Control Center while the lock remains at `ARM` and any bound lease is terminal and inactive. If spawning the child fails after the claim, the Control Center kills/reaps any created child, terminalizes the lease, attempts an explicit launch-failure `FINALIZE`, and releases the owner only after those prerequisites validate.

The implementation uses layered identities rather than one informal checksum. Let $P$ be the approval-envelope hash, whose snapshot core contains the canonical protocol-module identity and file hashes for the fixed runner and shared engine. Let $C_s$ denote the complete pseudonymous session record, including media/evidence selections and the frozen runner policy; let $I$ denote selection identity; let $P_s$ and $H_p$ denote the embedded approved protocol snapshot and reviewed hardware profile. The pre-lock draft identity is

$$
D=\operatorname{SHA256}\!\left(\operatorname{Canonicalize}(C_s,I,P_s,H_p)\right).
$$

Let $F$ be the canonical preflight-report hash, $R$ the capability-resolution hash, and $O$ the recorded operator/caution disposition. The immutable lock core contains $D$, the session identity, $R$, $I$, $P$, the reviewed profile identity, $F$, the preflight statuses, and $O$:

$$
L=\operatorname{SHA256}\!\left(\operatorname{Canonicalize}(\mathrm{lock\_core})\right).
$$

Runtime state is separately hashed so ordered gate transitions can be recorded without changing $L$:

$$
S_k=\operatorname{SHA256}\!\left(\operatorname{Canonicalize}(L,\mathrm{status}_k,\mathrm{stage}_k,\mathrm{gates}_k,\mathrm{history}_k,\mathrm{validation}_k)\right).
$$

Define $h_e(e)=\operatorname{SHA256}(\operatorname{Canonicalize}(e))$ when the evidence is a mapping and `null` otherwise. Each history event binds its stage, time, operator, evidence and conditional evidence hash to the previous event hash:

$$
E_k=\operatorname{SHA256}\!\left(\operatorname{Canonicalize}(g_k,t_k,o_k,e_k,h_e(e_k),E_{k-1})\right),
\qquad E_0=\varnothing.
$$

This is a tamper-evident bookkeeping chain, not a digital signature or proof that the evidence is scientifically valid.

Each transition also requires an exclusive on-disk claim for its expected predecessor. Abstractly, for a proposed transition from stage $g_{k-1}$ to $g_k$,

$$
T_k=\mathrm{I}[S=S_{k-1}]\,\mathrm{I}[g=g_{k-1}]\,
    \mathrm{I}[\operatorname{ExclusiveClaim}(L,g_{k-1}\!\to g_k)=1].
$$

The transition is committed only when $T_k=1$ and the bound files revalidate. This is local filesystem concurrency control, not a distributed consensus protocol or a guarantee that a launched process subsequently collected valid data.

The arm gate is not defined by the existence of $L$ alone. In Boolean form,

$$
E_{arm}=V_P\land V_H\land V_{streams}\land V_{session}
\land\left[Q_F=\mathrm{PASS}\;\lor\;(Q_F=\mathrm{CAUTION}\land O_{documented})\right]
\land V_{ALS\mid required},
$$

where each $V$ denotes the corresponding declared validity check and $O_{documented}$ is a permitted, recorded operator disposition rather than a hidden conversion of caution to pass. If $Q_F=\mathrm{INELIGIBLE}$, then $E_{arm}=0$. This logical ordering prevents design approval, profile existence, stream presence, or a hash by itself from masquerading as operational readiness.

Let $C_A$ denote the semantic acquisition-claim predicate, and let $M_D$ denote the two supported direct modes, `psychopy_python` and `regular_python`. The predicate is true only when the event label is exact, the launch mode belongs to $M_D$, and the claimed run UUID, protocol ID/version, and runner hash equal the corresponding locked values:

$$
C_A=I[e=e_{authorized}]\land I[m\in M_D]
\land I[u=u_L]\land I[(p,v)=(p_L,v_L)]\land I[h_R=h_{R,L}].
$$

Let $O_I$ denote a valid global acquisition owner created at the canonical shared log-root path. Its immutable core binds the protocol-runs root, owner ID, Control Center instance/PID/start identity, run UUID, lock path/identity, current `ARM` state, expected run-local lease path, and terminal-marker path. Let $L_I$ denote a valid run-local lease issued from that same `ARM` state. Its core must bind the lock identity, armed-state hash, run/protocol/module/runner/engine/stimulus/media identities, supported direct launch command, and the digest of a fresh token. Let $B_{OL}$ mean that the owner is in `LEASE_BOUND`, its exact lease path/ID/core hash/token digest/armed-state hash equal the issued lease, and all owner and lease identity fields carried in the `ACQUIRE` evidence resolve to those canonical records. Thus the complete structured acquisition claim is

$$
C_A^*=C_A\land O_I\land L_I\land B_{OL}.
$$

The Control Center obtains $O_I$, issues $L_I$, and commits $B_{OL}$ before asking the gate engine to commit $T_{ACQUIRE}$. Let $A_E$ mean that authority-bearing environment values are absent from every other child and that the raw token is supplied only through the claimed direct child's environment. The pre-spawn reservation is therefore

$$
E_{reserve}=E_{arm}\land V_{lock,state,history}\land C_A^*\land T_{ACQUIRE},
$$

and the authorized process spawn requires

$$
E_{spawn}=E_{reserve}\land A_E.
$$

Let $L_B(j,\tau_j)$ mean that the Control Center has exclusively bound the lease to child PID $j$ and its operating-system process-start identity $\tau_j$ when that identity is available. Let $L_C(j,\tau_j)$ mean that the same child has atomically consumed the raw token exactly once after its digest matches the lease. The configuration-UI precondition is

$$
E_{UI}=E_{spawn}\land L_B(j,\tau_j)\land L_C(j,\tau_j)
\land I[g=\mathrm{ACQUIRE}]\land C_A^*\land V_{lock,state,history}.
$$

After the UI returns, define $V_{full}$ as equality of the complete protocol-module, fixed-runner, shared-engine, assigned-sequence, media-file hashes, run UUID, participant pseudonym, frozen policy, and entered configuration with the lock. The first logger, LSL-outlet, or experiment-window side effect requires

$$
E_{side}=E_{UI}\land V_{full}.
$$

The global owner uses exclusive creation to serialize cooperating Control Centers that share this log root; it is local filesystem concurrency control, not distributed consensus. The runner maintains a periodic lease heartbeat from token consumption through the configuration UI and runner lifetime. The owner, heartbeat, and PID/start binding provide liveness and recovery evidence; they are not evidence of signal quality or successful stimulus presentation, and a heartbeat-update failure is recorded rather than being treated as scientific data. These predicates are authorization invariants, not validation of acquisition or theory.

The capability resolver derives availability from required condition labels and canonical signal roles. “Unavailable” is a planned, informative state. For example, HOC-R ShotOrder is unavailable without a ShotOrder branch; continuous autonomic analysis may be partial with only one physiological role; CLGF requires EEG plus a cue-generating condition and runner markers for actual execution.

### Acquisition Supervisor

The supervisor is exposed under **Acquisition → 4. Monitor, Record & Arm**. Observer mode monitors identity, sample arrival, effective rate, timestamp order, and gaps, producing segment-aware outputs. It does not fill lost samples or merge a restarted stream into an uninterrupted segment. Managed recovery is experimental, off by default, limited to trusted built-in module IDs, restart-limited, cooled down, and protected against duplicate processes. If a signed/trusted launch command is absent, the supervisor records the condition and restarts nothing.

### XDF and BIDS export

The exporter is exposed through **Analysis → Prepare BIDS Export / Verify…**, where it inherits the active run context subject to operator review. XDF remains the acquisition source record. The exporter writes a provenance report and, when optional dependencies are available, converts a regular EEG stream to BrainVision through MNE-BIDS. Runner markers become events tables. Regular physiology is exported only after strictly increasing timestamps and a declared regularity tolerance pass. Irregular RR intervals remain beat events:

$$
\mathcal R=\{(t_k,RR_k,q_k)\}_{k=1}^{N},
$$

where $q_k$ records source/interpolation quality. The exporter does not invent a uniform time series. Any later interpolation must be a named derivative with flags. Internal structural checks are not the external BIDS Validator; the release must report whether the external validator was actually available and run.

### Privacy and release gate

Release validation is exposed under **Settings**. The public scanner rejects raw EEG/physiology formats, common media files, private keys or credential-like assignments, and absolute Windows user paths. Unapproved email addresses are cautions. The approved public contact address is allow-listed. Passing this scan reduces a known class of packaging errors; it is not a comprehensive privacy guarantee.

The authority mechanism has a bounded threat model. The global owner claim, runtime lock, hashes, exclusive transition/lease files, one-use token, and PID/start binding reduce accidental cross-window overlap/double launch and make ordinary local state or file mutation detectable. They are not a security defense against a hostile local administrator, malware, a compromised Python/PsychoPy interpreter, or another actor with equivalent process and filesystem access. Acquisition therefore still requires a trusted, access-controlled workstation.

### Gate state machine

The architecture separates design-time protocol approval, expanded operator actions, and the canonical runtime state:

```text
DRAFT → VALIDATE → REVIEW → APPROVED PROTOCOL SNAPSHOT

Operator workflow: select approved protocol → select reviewed hardware profile
→ start new acquisition UUID → start streams → complete live checks

Canonical state: SELECT → CONNECT → PREFLIGHT → SESSION_LOCK → ARM → ACQUIRE
→ FINALIZE → QC → ANALYZE → EXPORT → VERIFY
```

Design approval establishes a reviewed, byte-identifiable protocol candidate; it is not a hardware or session result. `ACQUIRE` records the exclusive pre-spawn authorization claim; it is not evidence that acquisition completed or produced usable data. A later gate cannot repair an earlier failure. “Software PASS” means code behaved as tested. “Preflight PASS” means specified short-run checks passed for the selected live profile. “QC PASS” means declared data-quality rules passed. “Scientific support” requires appropriate design, uncertainty, alternatives, independent outcomes, and replication. These meanings are deliberately non-interchangeable.

The Analysis workspace exposes **Finalize Interrupted Run** for a validated lock left at `ACQUIRE`. It first requires readable, internally valid persistent owner and lease records and a safely inactive runner verdict derived from their exact binding, child PID/start identity, heartbeat, and terminal evidence. A matching live owning Control Center, matching live child PID/start identity, or fresh heartbeat is active; an expired heartbeat cannot override a matching live process. Without valid immutable terminal evidence, inactivity requires an expired claim/heartbeat window and a recorded process identity that is definitively dead or mismatched. A terminal owner without its valid terminal marker remains unresolved. Missing, corrupt, invalid, unknown/unverifiable, or still-live authority blocks recovery. An inactive child does not itself clear the `ACQUIRE` stage or release the global owner: the action still requires a named operator, reason, and reviewed incomplete-run artifact, closes the inactive lease, records an explicitly incomplete `FINALIZE`, and only then releases the owner. If owner release cannot be validated, later start/launch actions continue to fail closed. This is recovery bookkeeping and cannot represent successful acquisition. A Running Tools row that carried runtime authority cannot use generic Restart. A restarted Control Center cannot rely on an empty GUI process list; it consults the persistent owner, lock, lease, process-binding, heartbeat, and terminal records. **Start New Acquisition Session / UUID** is blocked while any live or unresolved authority exists, including an inactive lease whose lock or owner still remains at `ACQUIRE`, and it allocates only a UUID whose directory does not already exist. A safely inactive pre-`ACQUIRE` owner from a dead Control Center may be archived by a later atomic claim; it is never silently overwritten. After interrupted-run finalization, any retry requires a new UUID, repeated required checks, a new session lock, and a new arm; no prior process row, token, lease, or owner can recreate the consumed authority.

After `FINALIZE`, Analysis exposes **Record QC Evidence**, **Record Analysis Evidence**, **Record Export Evidence**, and **Record Verification Evidence**. Every manual transition first calls active-session-lock validation, including revalidation of the externally bound artifacts, before the evidence picker or gate advance. Each action then requires a named operator to select a reviewed artifact, stores its path, byte count, and SHA-256 in the next history event, and advances exactly one canonical gate. This records what was reviewed and when. It does not independently verify the artifact's scientific correctness, promote an exploratory module, or replace external BIDS validation.

The canonical alpha.2 marker/timing contract is `config/marker_timing_contract_v1_0_alpha_2.json`; the alpha.1 contract remains compatibility material. The alpha.2 contract requires the run UUID plus event index, event kind, marker, and phase fields, and states the lock-authority and run-identity rules. A populated field makes identity and ordering auditable, but does not by itself establish sub-frame timing accuracy or causal interpretation.

---

## 10. Unified inferential logic

The additions form a ladder rather than one omnibus proof:

1. **Manipulation:** Did the intended stimulus/task state actually occur according to independent reports and QC?
2. **Measurement:** Were timing, channels, coverage, artifact sentinels, cardiac beats, respiration, and required features adequate?
3. **Within-run contrast:** Did the frozen endpoint differ across declared conditions?
4. **Alternative explanations:** Do ShotOrder, HOC-R, OSA, OHC, AAM, respiration, or artifact weaken the attribution?
5. **Time structure:** Does the effect exceed declared circular-shift, phase-randomized, or label nulls where applicable?
6. **Prospective validity:** Does the frozen candidate predict independent recognition, comprehension, confidence, or other criteria in new participants and stimuli?
7. **Reliability and calibration:** Is it stable enough for a declared secondary role, and if probabilistic language is ever used, has that probability been independently calibrated?

The primary prospective condition model can be summarized as

$$
Outcome\sim Condition+Period+(1|Participant)+(1|Stimulus),
$$

with the three predeclared PRAYCG4 contrasts:

$$
Target-PhaseScrambled,
\qquad
Target-ShotOrder,
\qquad
Target-Override.
$$

Multiplicity correction, exclusions, lag windows, nulls, coverage thresholds, and any carryover terms must be frozen before confirmatory outcome review.

## 11. Promotion and falsification criteria

CAI/SID and Micro Handoff should remain exploratory unless all relevant gates are passed. Evidence against or constraining a candidate includes:

- failure to exceed time-shift or phase-randomized nulls;
- reversal under counterbalancing;
- disappearance under reasonable artifact, lag, or missingness sensitivity analyses;
- dependence on one optional component or one stimulus;
- failure to predict independent behavioral/report outcomes;
- poor test-retest or held-out reliability;
- failure in new participants and stimuli;
- inability to distinguish the intended condition from ShotOrder, task, gaze, respiratory, or order explanations.

Null and reversed results must be retained. A failed manipulation means the intended hypothesis was not adequately tested; it does not automatically prove or disprove the underlying theory.

## 12. Public claim boundaries

Permitted wording includes:

- “The frozen exploratory CAI v0.2 score was higher/lower under this operational model.”
- “The Micro Handoff directional candidate was/was not supported relative to the declared nulls.”
- “ShotOrder adds a locally intact but temporally disrupted structural control.”
- “Continuous autonomic arrays estimate the timing, quality, and respiratory dependence of measured autonomic changes.”
- “The result requires prospective, independent replication.”

Prohibited wording includes:

- “CAI measures or proves consciousness.”
- “A bounded CAI value is the probability of consciousness.”
- “Gamma-to-theta handoff proves discrete 40 Hz conscious frames.”
- “Target greater than Control proves meaning or narrative reception.”
- “Baseline 2 proves Target afterglow.”
- “HRV increase proves meaning, parasympathetic truth, or emotional recovery.”
- “A file hash proves scientific validity.”

## 13. Methodological references and source hierarchy

The authoritative source hierarchy for a software result is:

1. the versioned implementation and frozen configuration;
2. the versioned mathematical specification and protocol manifest;
3. generated provenance, QC, warnings, and source hashes;
4. theory proposals, release notes, and explanatory documents.

Where a theory proposal differs from shipped v1.0.0-alpha.3 code, this document reports both and labels the implemented behavior as the current computational definition. External references provide methodological context; they do not validate PRAYCG-specific constructs.

- Task Force of the European Society of Cardiology and the North American Society of Pacing and Electrophysiology. “Heart rate variability: standards of measurement, physiological interpretation and clinical use.” *Circulation* 93 (1996): 1043–1065. [PubMed](https://pubmed.ncbi.nlm.nih.gov/8598068/)
- Williams, E. J. “Experimental Designs Balanced for the Estimation of Residual Effects of Treatments.” *Australian Journal of Scientific Research, Series A* 2 (1949): 149–168. [DOI](https://doi.org/10.1071/CH9490149)
- Stojanoski, B., and Cusack, R. “Time to wave good-bye to phase scrambling: Creating controlled scrambled images using diffeomorphic transformations.” *Journal of Vision* 14(12) (2014). [DOI](https://doi.org/10.1167/14.12.6)
- Yuval-Greenberg, S., Tomer, O., Keren, A. S., Nelken, I., and Deouell, L. Y. “Transient induced gamma-band response in EEG as a manifestation of miniature saccades.” *Neuron* 58(3) (2008): 429–441. [PubMed](https://pubmed.ncbi.nlm.nih.gov/18466752/)

## Final perspective

The alpha architecture and its inherited analysis additions were not made to multiply endpoints until one became positive. They were made to decompose a difficult inference into narrower, falsifiable questions and to make invalid, unavailable, and incompatible states visible:

- Is the signal low-level sensory drive, locally recognizable structure, or coherent temporal order?
- Does an analytic task alter the response, and can cue monitoring or task relief explain it?
- Do fast and slow candidate signals jointly exceed baseline, or are they merely both low or both stationary?
- Did the autonomic change occur at the relevant time, with adequate beat and respiration quality?
- Does the result survive artifact, order, carryover, and time-structure nulls?
- Does a frozen candidate generalize prospectively to new participants and stimuli and predict independent outcomes?

That structure is the scientific significance of the upgrade: it makes positive, null, mixed, and ineligible results interpretable under the same declared rules while keeping the strongest claims conditional on future prospective validation.

