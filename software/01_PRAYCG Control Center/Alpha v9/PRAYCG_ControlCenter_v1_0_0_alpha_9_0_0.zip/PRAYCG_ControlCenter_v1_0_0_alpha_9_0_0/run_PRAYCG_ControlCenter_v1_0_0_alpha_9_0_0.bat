@echo off
setlocal
cd /d "%~dp0"
set "PRAYCG_SCRIPT=control_center\scripts\praycg_control_center_v1_0_0_alpha_9.py"

echo Starting PRAYCG Control Center v1.0.0-alpha.9.0.0 ...
echo Alpha 9 adapter discovery does not replace physical equipment validation.

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" goto local_python311
where py >nul 2>nul
if not errorlevel 1 goto python_launcher
where python >nul 2>nul
if not errorlevel 1 goto path_python

echo ERROR: No usable Python installation was found.
echo Install Python 3.11, then run this starter again.
pause
exit /b 2

:local_python311
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%PRAYCG_SCRIPT%"
goto finished
:python_launcher
py -3.11 "%PRAYCG_SCRIPT%"
goto finished
:path_python
python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)"
if errorlevel 1 (
  echo ERROR: The python command is not Python 3.11. Install Python 3.11 or add it to PATH.
  pause
  exit /b 3
)
python "%PRAYCG_SCRIPT%"
:finished
if errorlevel 1 (
  echo Control Center exited with an error. Review the message above.
  pause
)
endlocal
