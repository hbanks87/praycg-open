#!/usr/bin/env python3
"""Federated discovery and immutable selection locks for the runnable Protocol Atlas.

The public alpha keeps the proven PRAYCG3/PRAYCG4/SMG engine intact while
presenting those modules beside Protocol Atlas v2 adaptations.  This adapter is
deliberately narrow: it discovers only the two packaged, allowlisted libraries
and never executes a runner or arbitrary manifest-supplied command.
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

from praycg_protocol_library_v1_0 import (
    discover_protocol_modules as discover_legacy_modules,
    load_protocol_module as load_legacy_module,
)


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
ATLAS_LIBRARY_NAME = "ProtocolAtlas_ModuleLibrary_v2_0"
LEGACY_LIBRARY_NAME = "ProtocolRunner_ModuleLibrary_v1_0"
PACKAGED_ATLAS_ROOT = (PACKAGE_ROOT / "tools" / ATLAS_LIBRARY_NAME).resolve(strict=False)
PACKAGED_LEGACY_ROOT = (PACKAGE_ROOT / "tools" / LEGACY_LIBRARY_NAME).resolve(strict=False)
ATLAS_SCRIPTS = PACKAGED_ATLAS_ROOT / "scripts"
if str(ATLAS_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(ATLAS_SCRIPTS))

from praycg_protocol_atlas_core_v2_0 import (  # noqa: E402
    ATLAS_SCHEMA,
    AtlasRecord,
    build_asset_snapshot as build_atlas_asset_snapshot,
    compile_timeline as compile_atlas_timeline,
    discover_protocol_modules as discover_atlas_modules,
    load_protocol_module as load_atlas_module,
    normalize_asset_bindings as normalize_atlas_asset_bindings,
)


LOCK_SCHEMA = "PRAYCG_FederatedProtocolLock_v2_0"
FAMILY_NATIVE = "PRAYCG_NATIVE_V1"
FAMILY_ATLAS = "PROTOCOL_ATLAS_V2"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except (OSError, ValueError):
        return False


def _allowed_roots(atlas_root: Path) -> tuple[Path, Path]:
    atlas = Path(atlas_root).expanduser().resolve(strict=False)
    if atlas != PACKAGED_ATLAS_ROOT:
        raise ValueError(
            "Runnable Protocol Atlas discovery is restricted to this release's packaged Atlas root. "
            "External folders are candidate/review staging only."
        )
    return PACKAGED_ATLAS_ROOT, PACKAGED_LEGACY_ROOT


def _timeline_ids(module: Mapping[str, Any]) -> List[str]:
    rows: List[str] = []
    for index, node in enumerate(module.get("timeline", []), start=1):
        if isinstance(node, Mapping):
            value = str(node.get("id") or node.get("node_id") or f"NODE_{index}").strip()
            if value:
                rows.append(value)
    return rows


def _atlas_dict(record: AtlasRecord, library_root: Path) -> Dict[str, Any]:
    value = record.as_dict()
    order = _timeline_ids(record.module)
    boundary = value.get("scientific_boundary")
    if isinstance(boundary, list):
        boundary_text = " ".join(str(item).strip() for item in boundary if str(item).strip())
    else:
        boundary_text = str(boundary or "")
    value.update({
        "module_family": FAMILY_ATLAS,
        "library_root": str(Path(library_root).resolve(strict=False)),
        "branch_count": len(order),
        "branch_order": order,
        "scientific_boundary": boundary_text,
        "asset_mode": "protocol_asset_bindings",
    })
    return value


def _legacy_dict(record: Mapping[str, Any], library_root: Path) -> Dict[str, Any]:
    value = dict(record)
    engine = (Path(library_root) / "scripts" / "praycg_protocol_engine_v3_0.py").resolve(strict=False)
    value.update({
        "module_family": FAMILY_NATIVE,
        "library_root": str(Path(library_root).resolve(strict=False)),
        "engine_path": str(engine),
        "engine_sha256": sha256_file(engine) if engine.is_file() else "",
        "engine_family": "praycg_fixed_branch",
        "required_asset_keys": list(value.get("module", {}).get("integrity_constraints", {}).get("required_media_keys", [])),
        "asset_mode": "legacy_stimulus_library",
    })
    return value


def load_protocol_module(path: Path, atlas_root: Path) -> Dict[str, Any]:
    manifest = Path(path).expanduser().resolve(strict=False)
    atlas, legacy = _allowed_roots(atlas_root)
    if not manifest.is_file():
        raise ValueError(f"Protocol manifest does not exist: {manifest}")
    try:
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Protocol manifest cannot be read: {exc}") from exc
    schema = payload.get("schema") if isinstance(payload, dict) else None
    if schema == ATLAS_SCHEMA:
        if not _within(manifest, atlas / "protocols"):
            raise ValueError("Atlas protocol manifest is outside the packaged Atlas library.")
        return _atlas_dict(load_atlas_module(manifest, atlas), atlas)
    if schema == "PRAYCG_ProtocolModule_v1_0":
        if not _within(manifest, legacy / "protocols"):
            raise ValueError("Native PRAYCG protocol manifest is outside the packaged compatibility library.")
        return _legacy_dict(load_legacy_module(manifest, legacy), legacy)
    raise ValueError(f"Unsupported protocol schema: {schema!r}")


def discover_protocol_modules(atlas_root: Path) -> Tuple[List[Dict[str, Any]], List[str]]:
    try:
        atlas, legacy = _allowed_roots(atlas_root)
    except ValueError as exc:
        return [], [str(exc)]
    records: List[Dict[str, Any]] = []
    errors: List[str] = []
    atlas_records, atlas_errors = discover_atlas_modules(atlas)
    records.extend(_atlas_dict(record, atlas) for record in atlas_records)
    errors.extend(f"Atlas: {message}" for message in atlas_errors)
    if legacy.is_dir():
        legacy_records, legacy_errors = discover_legacy_modules(legacy)
        records.extend(_legacy_dict(record, legacy) for record in legacy_records)
        errors.extend(f"Native: {message}" for message in legacy_errors)
    else:
        errors.append(f"Native compatibility library is missing: {legacy}")

    counts: Dict[tuple[str, str], int] = {}
    for record in records:
        identity = (str(record["protocol_id"]).casefold(), str(record["protocol_version"]))
        counts[identity] = counts.get(identity, 0) + 1
    duplicates = {identity for identity, count in counts.items() if count > 1}
    for protocol_id, version in sorted(duplicates):
        errors.append(f"Duplicate federated protocol identity is not allowed: {protocol_id} v{version}")
    records = [
        record for record in records
        if (str(record["protocol_id"]).casefold(), str(record["protocol_version"])) not in duplicates
    ]
    records.sort(key=lambda record: (str(record.get("module_family")), str(record.get("display_name", "")).casefold()))
    return records, errors


def write_protocol_lock(record: Mapping[str, Any], lock_path: Path) -> Dict[str, Any]:
    lock_path = Path(lock_path).expanduser().resolve(strict=False)
    lock = {
        "schema": LOCK_SCHEMA,
        "locked_unix_time": time.time(),
        "module_family": record["module_family"],
        "library_root": record["library_root"],
        "protocol_id": record["protocol_id"],
        "protocol_version": record["protocol_version"],
        "display_name": record["display_name"],
        "manifest_path": record["manifest_path"],
        "manifest_sha256": record["manifest_sha256"],
        "runner_path": record["runner_path"],
        "runner_sha256": record["runner_sha256"],
        "engine_path": record["engine_path"],
        "engine_sha256": record["engine_sha256"],
        "branch_count": record["branch_count"],
        "branch_order": list(record["branch_order"]),
        "scientific_boundary": record["scientific_boundary"],
        "hardware_stack_effect": "NONE" if record["module_family"] == FAMILY_ATLAS else "INDEPENDENT_PROFILE_ONLY",
    }
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = lock_path.with_name(f"{lock_path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps(lock, indent=2), encoding="utf-8")
    temporary.replace(lock_path)
    return lock


def validate_protocol_lock(lock_path: Path, atlas_root: Path) -> Dict[str, Any]:
    lock_path = Path(lock_path).expanduser().resolve(strict=False)
    if not lock_path.is_file():
        raise FileNotFoundError("No protocol is locked.")
    try:
        lock = json.loads(lock_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"Protocol lock cannot be read: {exc}") from exc
    if not isinstance(lock, dict) or lock.get("schema") != LOCK_SCHEMA:
        raise ValueError("Protocol lock has an unsupported schema.")
    atlas, legacy = _allowed_roots(atlas_root)
    expected_root = atlas if lock.get("module_family") == FAMILY_ATLAS else legacy if lock.get("module_family") == FAMILY_NATIVE else None
    recorded_root = Path(str(lock.get("library_root") or "")).expanduser().resolve(strict=False)
    if expected_root is None or recorded_root != expected_root:
        raise ValueError("Locked protocol library family or root is not allowlisted by this package.")
    record = load_protocol_module(Path(str(lock.get("manifest_path") or "")), atlas)
    checks = {
        "module_family": record["module_family"] == lock.get("module_family"),
        "protocol_id": record["protocol_id"] == str(lock.get("protocol_id", "")),
        "protocol_version": record["protocol_version"] == str(lock.get("protocol_version", "")),
        "manifest_sha256": record["manifest_sha256"] == str(lock.get("manifest_sha256", "")),
        "runner_path": Path(record["runner_path"]).resolve(strict=False) == Path(str(lock.get("runner_path", ""))).expanduser().resolve(strict=False),
        "runner_sha256": record["runner_sha256"] == str(lock.get("runner_sha256", "")),
        "engine_path": Path(record["engine_path"]).resolve(strict=False) == Path(str(lock.get("engine_path", ""))).expanduser().resolve(strict=False),
        "engine_sha256": record["engine_sha256"] == str(lock.get("engine_sha256", "")),
        "branch_order": record["branch_order"] == lock.get("branch_order"),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ValueError("Locked protocol no longer matches the packaged library: " + ", ".join(failed))
    return {**lock, "validation": "PASS", "record": record}


def atlas_runtime_plan(
    record: Mapping[str, Any],
    *,
    participant_id: str,
    session_index: int = 1,
    asset_bindings: Mapping[str, Any] | None = None,
) -> Dict[str, Any]:
    """Compile one deterministic Atlas plan from an already discovered record."""
    if record.get("module_family") != FAMILY_ATLAS:
        raise ValueError("A deterministic Atlas plan was requested for a native PRAYCG module.")
    atlas_root = Path(str(record.get("library_root") or "")).expanduser().resolve(strict=False)
    loaded = load_atlas_module(Path(str(record.get("manifest_path") or "")), atlas_root)
    return compile_atlas_timeline(
        loaded,
        participant_id=str(participant_id or "").strip(),
        session_index=session_index,
        asset_bindings=asset_bindings,
    )


def atlas_asset_snapshot(
    record: Mapping[str, Any],
    bindings: Mapping[str, Any] | None,
) -> Dict[str, Dict[str, Any]]:
    """Return the core-validated immutable external-asset snapshot for Atlas."""
    if record.get("module_family") != FAMILY_ATLAS:
        raise ValueError("Atlas asset resolution was requested for a native PRAYCG module.")
    atlas_root = Path(str(record.get("library_root") or "")).expanduser().resolve(strict=False)
    loaded = load_atlas_module(Path(str(record.get("manifest_path") or "")), atlas_root)
    return build_atlas_asset_snapshot(loaded, bindings)


def normalize_atlas_bindings(
    record: Mapping[str, Any],
    bindings: Mapping[str, Any] | None,
) -> Dict[str, str]:
    """Validate user-selected Atlas asset paths against the manifest contract."""
    if record.get("module_family") != FAMILY_ATLAS:
        raise ValueError("Atlas asset resolution was requested for a native PRAYCG module.")
    atlas_root = Path(str(record.get("library_root") or "")).expanduser().resolve(strict=False)
    loaded = load_atlas_module(Path(str(record.get("manifest_path") or "")), atlas_root)
    return normalize_atlas_asset_bindings(loaded, bindings)


__all__ = [
    "FAMILY_ATLAS",
    "FAMILY_NATIVE",
    "LOCK_SCHEMA",
    "atlas_asset_snapshot",
    "atlas_runtime_plan",
    "discover_protocol_modules",
    "load_protocol_module",
    "normalize_atlas_bindings",
    "validate_protocol_lock",
    "write_protocol_lock",
]
