#!/usr/bin/env python3
"""Deterministic active-context resolution for PRAYCG Control Center v1.0.0-alpha.4.

The resolver never silently chooses between multiple plausible raw or analysis
artifacts.  It returns RESOLVED, MISSING, or AMBIGUOUS records so the GUI can
show what will be passed to each downstream tool before launch.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence


CONTEXT_SCHEMA = "PRAYCG_ActiveResearchContext_v1_0"


def _resolved_path(value: Any) -> Optional[Path]:
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        return Path(raw).expanduser().resolve()
    except OSError:
        return Path(raw).expanduser()


def same_path(left: Any, right: Any) -> bool:
    a, b = _resolved_path(left), _resolved_path(right)
    if a is None or b is None:
        return False
    return str(a).casefold() == str(b).casefold()


def read_json(path: Path) -> Dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def collect_files(root: Optional[Path], patterns: Sequence[str]) -> List[Path]:
    if root is None or not root.is_dir():
        return []
    found: Dict[str, Path] = {}
    for pattern in patterns:
        try:
            for path in root.glob(pattern):
                if path.is_file():
                    found[str(path.resolve()).casefold()] = path.resolve()
        except OSError:
            continue
    return sorted(found.values(), key=lambda path: (len(path.parts), str(path).casefold()))


def resolution(
    candidates: Iterable[Path],
    *,
    source: str,
    preferred_names: Sequence[str] = (),
    preferred_paths: Sequence[Path] = (),
) -> Dict[str, Any]:
    unique: Dict[str, Path] = {}
    for candidate in candidates:
        try:
            path = Path(candidate).expanduser().resolve()
        except OSError:
            path = Path(candidate).expanduser()
        if path.is_file() or path.is_dir():
            unique[str(path).casefold()] = path
    values = list(unique.values())
    preferred_keys = {str(Path(path).expanduser().resolve()).casefold() for path in preferred_paths if path}
    exact = [path for path in values if str(path).casefold() in preferred_keys]
    if len(exact) == 1:
        return _record("RESOLVED", exact[0], values, "EXPLICIT_CONFIG", "Exact configured path")
    names = {name.casefold() for name in preferred_names}
    named = [path for path in values if path.name.casefold() in names]
    if len(named) == 1:
        return _record("RESOLVED", named[0], values, source, "Unique preferred filename")
    if len(values) == 1:
        return _record("RESOLVED", values[0], values, source, "Unique detected match")
    if not values:
        return _record("MISSING", None, [], source, "No matching artifact found")
    return _record("AMBIGUOUS", None, values, source, f"{len(values)} plausible artifacts require selection")


def _record(status: str, path: Optional[Path], candidates: Iterable[Path], source: str, message: str) -> Dict[str, Any]:
    return {
        "status": status,
        "path": str(path) if path else "",
        "source": source,
        "message": message,
        "candidates": [str(value) for value in candidates],
    }


def empty_context() -> Dict[str, Any]:
    return {
        "schema": CONTEXT_SCHEMA,
        "version": "1.0",
        "updated_local": datetime.now().isoformat(timespec="seconds"),
        "stimulus": {},
        "run": {},
        "analysis": {},
        "readiness": {},
        "issues": [],
    }


def infer_run_config(run_folder: Path) -> Dict[str, Any]:
    candidates = collect_files(run_folder, ["*run_config_media_selection.json", "**/*run_config_media_selection.json"])
    record = resolution(candidates, source="RUN_FOLDER_SCAN")
    payload = read_json(Path(record["path"])) if record.get("status") == "RESOLVED" else {}
    return {"resolution": record, "payload": payload}


def resolve_raw_run(run_folder: Path) -> Dict[str, Any]:
    run_folder = run_folder.expanduser().resolve()
    config_result = infer_run_config(run_folder)
    payload = config_result["payload"]
    config = payload.get("config", {}) if isinstance(payload.get("config"), dict) else {}

    configured_xdf = _resolved_path(config.get("xdf_path") or payload.get("xdf_path"))
    xdf = resolution(
        collect_files(run_folder, ["*.xdf", "**/*.xdf"]),
        source="RUN_FOLDER_SCAN",
        preferred_paths=[configured_xdf] if configured_xdf else [],
    )
    event_json_candidates = collect_files(run_folder, ["*events.json", "**/*events.json"])
    event_csv_candidates = collect_files(run_folder, ["*events.csv", "**/*events.csv"])
    event_candidates = event_json_candidates + event_csv_candidates
    configured_event = _resolved_path(config.get("event_log_path") or payload.get("event_log_path"))
    if configured_event:
        events = resolution(event_candidates, source="RUN_FOLDER_SCAN", preferred_paths=[configured_event])
    elif event_json_candidates:
        events = resolution(event_json_candidates, source="RUN_FOLDER_SCAN_JSON_PREFERRED")
    else:
        events = resolution(event_csv_candidates, source="RUN_FOLDER_SCAN_CSV_FALLBACK")
    channel_map = resolution(
        collect_files(run_folder, ["*channel_map*.csv", "**/*channel_map*.csv"]),
        source="RUN_FOLDER_SCAN",
        preferred_paths=[_resolved_path(config.get("channel_map_path"))] if config.get("channel_map_path") else [],
    )

    def configured_file(key: str) -> Dict[str, Any]:
        value = _resolved_path(config.get(key))
        if value and value.is_file():
            return _record("RESOLVED", value, [value], "RUN_MEDIA_CONFIG", "Exact path from run media-selection record")
        return _record("MISSING", None, [], "RUN_MEDIA_CONFIG", f"{key} was not recorded or no longer exists")

    return {
        "folder": str(run_folder),
        "label": str(config.get("run_label") or run_folder.name),
        "run_uuid": str(payload.get("run_uuid") or ""),
        "protocol_schema": str(payload.get("schema") or ""),
        "run_config_media_selection": config_result["resolution"],
        "xdf": xdf,
        "events": events,
        "channel_map": channel_map,
        "cue_schedule_json": configured_file("cue_schedule_json"),
        "predeclared_anchor_file": configured_file("predeclared_anchor_file"),
        "target_video": configured_file("target_video"),
        "override_video": configured_file("override_video"),
        "control_video": configured_file("control_video"),
        "media_hashes": payload.get("hashes", {}) if isinstance(payload.get("hashes"), dict) else {},
    }


def _core_matches_run(core: Path, run: Dict[str, Any]) -> bool:
    cfg = read_json(core / "config" / "run_config.json")
    selected_xdf = run.get("xdf", {}).get("path", "")
    selected_event = run.get("events", {}).get("path", "")
    if selected_xdf and same_path(cfg.get("xdf_path"), selected_xdf):
        return True
    if selected_event and same_path(cfg.get("event_log_path"), selected_event):
        return True
    run_folder = _resolved_path(run.get("folder"))
    if run_folder:
        for key in ("xdf_path", "event_log_path"):
            candidate = _resolved_path(cfg.get(key))
            if candidate:
                try:
                    candidate.relative_to(run_folder)
                    return True
                except ValueError:
                    pass
    return False


def resolve_analysis_outputs(
    analysis_root: Path,
    run: Dict[str, Any],
    run_folder: Optional[Path] = None,
    core_override: Optional[Path] = None,
    chain_override: Optional[Path] = None,
) -> Dict[str, Any]:
    core_candidates: List[Path] = []
    roots = [root for root in [run_folder, analysis_root] if root and root.is_dir()]
    seen = set()
    for root in roots:
        for canonical in collect_files(root, ["**/tables/praycg_analysis_frame_v1_6_0.csv"]):
            core = canonical.parent.parent
            key = str(core).casefold()
            if key not in seen and _core_matches_run(core, run):
                seen.add(key)
                core_candidates.append(core)
    if core_override and (core_override / "tables" / "praycg_analysis_frame_v1_6_0.csv").is_file():
        core_record = _record("RESOLVED", core_override.resolve(), [core_override.resolve()], "MANUAL_SELECTION", "Manually selected canonical core output")
    else:
        core_record = resolution(core_candidates, source="RUN_PROVENANCE_MATCH")

    chain_candidates: List[Path] = []
    core_path = _resolved_path(core_record.get("path"))
    if core_path:
        for root in roots:
            for manifest in collect_files(root, ["**/chain_manifest.json"]):
                payload = read_json(manifest)
                if same_path(payload.get("core_analysis_folder"), core_path):
                    chain_candidates.append(manifest.parent)
    if chain_override and (chain_override / "chain_manifest.json").is_file():
        manifest = read_json(chain_override / "chain_manifest.json")
        if core_path and same_path(manifest.get("core_analysis_folder"), core_path):
            chain_record = _record("RESOLVED", chain_override.resolve(), [chain_override.resolve()], "MANUAL_SELECTION", "Manually selected chain matched to the active core output")
        else:
            chain_record = _record("INCOMPATIBLE", None, [chain_override.resolve()], "MANUAL_SELECTION", "Selected chain does not reference the active core output")
    else:
        chain_record = resolution(chain_candidates, source="CORE_PROVENANCE_MATCH")
    preferred = chain_record.get("path") or core_record.get("path") or ""
    return {
        "core": core_record,
        "chain": chain_record,
        "preferred_review_folder": preferred,
    }


def readiness(context: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
    stimulus = context.get("stimulus", {})
    run = context.get("run", {})
    analysis = context.get("analysis", {})
    master = stimulus.get("master_mp4", {})
    xdf = run.get("xdf", {})
    core = analysis.get("core", {})
    chain = analysis.get("chain", {})

    def gate(ok: bool, ready: str, blocked: str) -> Dict[str, str]:
        return {"status": "READY" if ok else "BLOCKED", "message": ready if ok else blocked}

    return {
        "mediaprep": gate(master.get("status") == "RESOLVED", "Selected master stimulus is ready.", "Select a registered stimulus with one valid master MP4."),
        "master_suite": gate(xdf.get("status") == "RESOLVED", "Raw run XDF is resolved.", "Select a run folder containing one unambiguous XDF."),
        "als_barcode": gate(xdf.get("status") == "RESOLVED", "Run/XDF is ready for barcode validation.", "Select a run folder containing one unambiguous XDF."),
        "chain": gate(core.get("status") == "RESOLVED", "Matching core analysis is ready.", "Complete or manually select one matching core v1.6.0 output."),
        "hocr": gate(core.get("status") == "RESOLVED", "Matching core analysis is ready.", "Complete or manually select one matching core v1.6.0 output."),
        "confounds": gate(core.get("status") == "RESOLVED", "Matching core analysis is ready.", "Complete or manually select one matching core v1.6.0 output."),
        "visualizer": gate(bool(chain.get("path") or core.get("path")), "Compatible analysis output is ready.", "Complete or select a matching core/chained analysis output."),
        "interpreter": gate(bool(chain.get("path") or core.get("path")), "Compatible analysis output is ready.", "Complete or select a matching core/chained analysis output."),
    }


def summarize_context(context: Dict[str, Any]) -> str:
    stimulus = context.get("stimulus", {})
    run = context.get("run", {})
    analysis = context.get("analysis", {})
    lines = [
        f"Stimulus: {stimulus.get('id') or 'none'}",
        f"Master: {stimulus.get('master_mp4', {}).get('status', 'MISSING')} | {stimulus.get('master_mp4', {}).get('path', '')}",
        f"Run: {run.get('label') or 'none'} | {run.get('folder', '')}",
        f"Run UUID: {run.get('run_uuid') or 'not recorded'}",
        f"XDF: {run.get('xdf', {}).get('status', 'MISSING')} | {run.get('xdf', {}).get('path', '')}",
        f"Events: {run.get('events', {}).get('status', 'MISSING')} | {run.get('events', {}).get('path', '')}",
        f"Channel map: {run.get('channel_map', {}).get('status', 'MISSING')} | {run.get('channel_map', {}).get('path', '')}",
        f"Cue schedule: {(run.get('cue_schedule_json', {}).get('path') or stimulus.get('cue_schedule_json', {}).get('path') or 'not resolved')}",
        f"Locked anchor: {(run.get('predeclared_anchor_file', {}).get('path') or stimulus.get('locked_anchor_json', {}).get('path') or 'not resolved')}",
        f"Media manifest: {stimulus.get('media_manifest_json', {}).get('path') or 'not resolved'}",
        f"StimulusFingerprint: {stimulus.get('stimulus_fingerprint_folder') or 'not resolved'}",
        f"Target video: {(run.get('target_video', {}).get('path') or stimulus.get('target_video', {}).get('path') or 'not resolved')}",
        f"Core analysis: {analysis.get('core', {}).get('status', 'MISSING')} | {analysis.get('core', {}).get('path', '')}",
        f"Chained analysis: {analysis.get('chain', {}).get('status', 'MISSING')} | {analysis.get('chain', {}).get('path', '')}",
        "",
        "Tool readiness:",
    ]
    for name, record in context.get("readiness", {}).items():
        lines.append(f"- {name}: {record.get('status')} — {record.get('message')}")
    for section_name, section in (("run", run), ("analysis", analysis)):
        for key, record in section.items():
            if isinstance(record, dict) and record.get("status") == "AMBIGUOUS":
                lines.append(f"\nAMBIGUOUS {section_name}.{key}:")
                lines.extend(f"  {candidate}" for candidate in record.get("candidates", []))
    return "\n".join(lines)
