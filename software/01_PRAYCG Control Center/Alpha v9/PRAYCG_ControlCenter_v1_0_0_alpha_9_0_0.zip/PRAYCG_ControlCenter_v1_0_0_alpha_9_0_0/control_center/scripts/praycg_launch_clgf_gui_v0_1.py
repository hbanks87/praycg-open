#!/usr/bin/env python3
"""Small launcher GUI for Cue-Locked Gamma Forensics v0.1."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

PACKAGE_ROOT = Path(__file__).resolve().parents[2]
ENGINE = PACKAGE_ROOT / "tools" / "Cue_Locked_Gamma_Forensics_v0_1" / "software" / "praycg_cue_locked_gamma_forensics_v0_1.py"


def main() -> int:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--data-audit")
    parser.add_argument("--out")
    args, _unknown = parser.parse_known_args()
    root = tk.Tk(); root.title("Cue-Locked Gamma Forensics v0.1")
    root.geometry("820x360")
    audit = tk.StringVar(value=args.data_audit or "")
    out = tk.StringVar(value=args.out or str(Path.home() / "PRAYCG" / "analysis" / "Exploratory_CueLockedGammaForensics_v0_1"))
    def row(index: int, label: str, variable: tk.StringVar, folder: bool = True) -> None:
        ttk.Label(root, text=label, width=22).grid(row=index, column=0, sticky="w", padx=8, pady=6)
        ttk.Entry(root, textvariable=variable).grid(row=index, column=1, sticky="ew", padx=8, pady=6)
        def browse() -> None:
            value = filedialog.askdirectory(title=label) if folder else filedialog.askopenfilename(title=label)
            if value: variable.set(value)
        ttk.Button(root, text="Browse", command=browse).grid(row=index, column=2, padx=8, pady=6)
    row(0, "Data audit root", audit)
    row(1, "Output folder", out)
    root.columnconfigure(1, weight=1)
    ttk.Label(root, text="Exploratory confound extension only. It does not create a primary score, change Master Suite eligibility, or establish a brain-versus-muscle verdict.", foreground="#7a1e1e", wraplength=760).grid(row=2, column=0, columnspan=3, sticky="w", padx=8, pady=8)
    status = tk.StringVar(value="Select the data-audit root that contains 07_Analysis_Outputs/00_Inventory/unique_xdf_files.csv.")
    ttk.Label(root, textvariable=status, wraplength=760).grid(row=3, column=0, columnspan=3, sticky="w", padx=8, pady=8)
    def launch(self_test: bool = False) -> None:
        target = Path(out.get()).expanduser()
        cmd = [sys.executable, str(ENGINE), "--out", str(target)]
        if self_test:
            cmd.append("--self-test")
        else:
            inventory = Path(audit.get()).expanduser() / "07_Analysis_Outputs" / "00_Inventory" / "unique_xdf_files.csv"
            if not inventory.is_file():
                messagebox.showerror("Inventory not found", f"Expected data-audit inventory:\n{inventory}")
                return
            cmd.extend(["--data-audit", audit.get()])
        subprocess.Popen(cmd, cwd=str(ENGINE.parent))
        status.set(f"Launched. Results will be written to {target}")
    ttk.Button(root, text="Run synthetic self-test", command=lambda: launch(True)).grid(row=4, column=0, padx=8, pady=10)
    ttk.Button(root, text="Run exploratory forensics", command=lambda: launch(False)).grid(row=4, column=1, sticky="w", padx=8, pady=10)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
