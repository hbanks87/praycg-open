#!/usr/bin/env python3
"""PRAYCG Control Center v1.0.0-alpha.8.5.4 MediaPrep diagnostic wrapper.

The current package contains one canonical MediaPrep bundle: v1.9 ShotOrder.
This wrapper opens a visible diagnostic window, launches that GUI
with the correct working directory, checks dependencies, and exposes the live
log so MediaPrep cannot fail silently.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

try:
    import tkinter as tk
    from tkinter import messagebox, ttk
except Exception as exc:  # pragma: no cover
    print("Tkinter is required for the MediaPrep diagnostic launcher.", file=sys.stderr)
    raise

APP_TITLE = "PRAYCG MediaPrep Launcher — Control Center v1.0.0-alpha.8.5.4"
ROOT = Path(__file__).resolve().parents[2]
LOG_ROOT = ROOT / "logs" / "control_center" / "mediaprep_v0_92"
LOG_ROOT.mkdir(parents=True, exist_ok=True)

CANDIDATES: List[Tuple[str, Path]] = [
    ("MediaPrep v1.9 ShotOrder", ROOT / "tools" / "MediaPrep_StimulusFingerprint_v1_9_SHOTORDER" / "scripts" / "run_PRAYCG_MediaPrep_v1_8.py"),
    ("MediaPrep v1.9 direct GUI fallback", ROOT / "tools" / "MediaPrep_StimulusFingerprint_v1_9_SHOTORDER" / "scripts" / "praycg_media_prep_gui_v1_8.py"),
]

REQUIRED_IMPORTS = [
    ("tkinter", "tkinter"),
    ("numpy", "numpy"),
    ("opencv-python / cv2", "cv2"),
    ("scipy", "scipy"),
    ("moviepy", "moviepy"),
    ("imageio", "imageio"),
    ("imageio-ffmpeg", "imageio_ffmpeg"),
    ("Pillow / PIL", "PIL"),
]

MEDIAPREP_PIP_PACKAGES = [
    "moviepy==1.0.3",
    "imageio",
    "imageio-ffmpeg",
    "decorator",
    "proglog",
    "requests",
    "tqdm",
    "pillow",
    "numpy",
    "scipy",
    "opencv-python",
]


def python_cmd() -> List[str]:
    # Use the interpreter that launched this wrapper.  This avoids py/Windows PATH ambiguity.
    return [sys.executable]


def tail_text(path: Path, max_chars: int = 6000) -> str:
    try:
        txt = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return ""
    return txt[-max_chars:]


class MediaPrepLauncher(tk.Tk):
    def __init__(self, forwarded_args: Optional[List[str]] = None) -> None:
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("980x720")
        self.minsize(820, 560)
        self.proc: Optional[subprocess.Popen] = None
        self.log_path: Optional[Path] = None
        self.selected_idx = tk.IntVar(value=self._first_existing_index())
        self.status = tk.StringVar(value="Ready. This window will launch MediaPrep with visible diagnostics.")
        self.auto_started = False
        self.forwarded_args = list(forwarded_args or [])
        self._build_ui()
        self.after(350, self._auto_launch_once)

    def _first_existing_index(self) -> int:
        for i, (_label, path) in enumerate(CANDIDATES):
            if path.exists():
                return i
        return 0

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=12)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="PRAYCG MediaPrep Launcher v1.9", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        ttk.Label(
            outer,
            text=(
                "This diagnostic launcher opens first, then starts the bundled MediaPrep GUI as a separate process. "
                "If MediaPrep exits early, the exact log is shown here instead of failing silently."
            ),
            wraplength=900,
        ).pack(anchor="w", pady=(4, 10))

        row = ttk.Frame(outer)
        row.pack(fill="x", pady=(0, 8))
        ttk.Label(row, text="MediaPrep entry point:").pack(side="left")
        self.combo = ttk.Combobox(row, state="readonly", width=70)
        self.combo["values"] = [f"{i+1}. {label} — {'FOUND' if path.exists() else 'MISSING'}" for i, (label, path) in enumerate(CANDIDATES)]
        self.combo.current(self.selected_idx.get())
        self.combo.bind("<<ComboboxSelected>>", lambda e: self.selected_idx.set(self.combo.current()))
        self.combo.pack(side="left", fill="x", expand=True, padx=8)

        btns = ttk.Frame(outer)
        btns.pack(fill="x", pady=(0, 8))
        ttk.Button(btns, text="Launch Selected MediaPrep", command=self.launch_selected).pack(side="left", padx=(0, 6))
        ttk.Button(btns, text="Try Next Candidate", command=self.try_next).pack(side="left", padx=6)
        ttk.Button(btns, text="Run Dependency Check", command=self.run_dependency_check).pack(side="left", padx=6)
        ttk.Button(btns, text="Install/Fix MediaPrep Dependencies", command=self.install_mediaprep_dependencies).pack(side="left", padx=6)
        ttk.Button(btns, text="Stop MediaPrep", command=self.stop_process).pack(side="left", padx=6)
        ttk.Button(btns, text="Open Log Folder", command=self.open_log_folder).pack(side="left", padx=6)
        ttk.Button(btns, text="Exit", command=self.destroy).pack(side="right")

        ttk.Label(outer, textvariable=self.status, foreground="#003366").pack(anchor="w", pady=(0, 6))
        path_frame = ttk.LabelFrame(outer, text="Resolved paths")
        path_frame.pack(fill="x", pady=(0, 8))
        self.path_text = tk.Text(path_frame, height=7, wrap="none")
        self.path_text.pack(fill="x", expand=False)
        self.update_path_text()
        self.combo.bind("<<ComboboxSelected>>", lambda e: (self.selected_idx.set(self.combo.current()), self.update_path_text()))

        log_frame = ttk.LabelFrame(outer, text="Live MediaPrep log")
        log_frame.pack(fill="both", expand=True)
        self.log = tk.Text(log_frame, wrap="word")
        y = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        self.log.configure(yscrollcommand=y.set)
        self.log.pack(side="left", fill="both", expand=True)
        y.pack(side="right", fill="y")

        self._log("Launcher opened.")
        self._log(f"Package root: {ROOT}")
        self._log(f"Python: {sys.executable}")

    def _auto_launch_once(self) -> None:
        # Auto-start only once, so the Control Center button still behaves like a normal launcher.
        if self.auto_started:
            return
        self.auto_started = True
        self.launch_selected()

    def _log(self, msg: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        self.log.insert("end", f"[{stamp}] {msg.rstrip()}\n")
        self.log.see("end")
        self.update_idletasks()

    def update_path_text(self) -> None:
        self.path_text.configure(state="normal")
        self.path_text.delete("1.0", "end")
        idx = self.selected_idx.get()
        label, script = CANDIDATES[idx]
        lines = [
            f"selected_label: {label}",
            f"selected_script: {script}",
            f"script_exists: {script.exists()}",
            f"working_directory: {script.parent}",
            f"python_executable: {sys.executable}",
            f"log_directory: {LOG_ROOT}",
            f"prefill_arguments: {self.forwarded_args}",
        ]
        self.path_text.insert("end", "\n".join(lines))
        self.path_text.configure(state="disabled")


    def _child_env(self) -> dict:
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        env["PRAYCG_MEDIAPREP_STAGE_LOGGING"] = "1"
        return env

    def launch_selected(self) -> None:
        if self.proc is not None and self.proc.poll() is None:
            messagebox.showinfo("MediaPrep already running", "A MediaPrep process is already running from this launcher.")
            return
        idx = self.selected_idx.get()
        label, script = CANDIDATES[idx]
        self.update_path_text()
        if not script.exists():
            self.status.set("Selected MediaPrep script is missing.")
            self._log(f"MISSING: {script}")
            messagebox.showerror("MediaPrep script missing", f"The selected MediaPrep script does not exist:\n\n{script}\n\nTry another candidate or click Use Bundled Paths in Control Center.")
            return

        self.log_path = LOG_ROOT / f"mediaprep_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{idx+1}.log"
        cmd = python_cmd() + [str(script)] + self.forwarded_args
        self._log("Launching MediaPrep...")
        self._log("Command: " + json.dumps(cmd))
        self._log("CWD: " + str(script.parent))
        self.status.set(f"Launching {label} ...")
        try:
            log_f = self.log_path.open("w", encoding="utf-8", errors="replace")
            log_f.write(f"# {APP_TITLE}\n# label={label}\n# command={cmd}\n# cwd={script.parent}\n# started={datetime.now().isoformat()}\n\n")
            log_f.flush()
            self.proc = subprocess.Popen(
                cmd,
                cwd=str(script.parent),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                env=self._child_env(),
            )
        except Exception as exc:
            tb = traceback.format_exc()
            self.status.set("Launch failed before process start.")
            self._log(tb)
            messagebox.showerror("MediaPrep launch failed", f"Could not start MediaPrep.\n\n{exc}\n\nCommand:\n{cmd}")
            return

        threading.Thread(target=self._pump_output, args=(self.proc, self.log_path), daemon=True).start()
        self.after(2500, self._check_quick_exit)

    def _pump_output(self, proc: subprocess.Popen, log_path: Path) -> None:
        try:
            with log_path.open("a", encoding="utf-8", errors="replace") as f:
                if proc.stdout is not None:
                    for line in proc.stdout:
                        f.write(line)
                        f.flush()
                        self.after(0, self._log, line.rstrip())
                rc = proc.wait()
                f.write(f"\n# process_exit_code={rc}\n")
        except Exception as exc:
            self.after(0, self._log, f"Output pump error: {exc}")

    def _check_quick_exit(self) -> None:
        if self.proc is None:
            return
        rc = self.proc.poll()
        if rc is None:
            self.status.set("MediaPrep process is still running. If the MediaPrep GUI is visible, use that window normally.")
            self._log("MediaPrep process is alive after startup window. GUI should be visible or still importing dependencies.")
            return
        self.status.set(f"MediaPrep exited quickly with code {rc}.")
        tail = tail_text(self.log_path) if self.log_path else ""
        self._log(f"MediaPrep exited quickly with code {rc}.")
        if tail:
            self._log("Last log lines:\n" + tail[-2500:])
        messagebox.showwarning(
            "MediaPrep exited quickly",
            f"MediaPrep exited shortly after launch with code {rc}.\n\nLog:\n{self.log_path}\n\nLast lines:\n{tail[-2500:]}",
        )

    def try_next(self) -> None:
        n = len(CANDIDATES)
        start = self.selected_idx.get()
        for step in range(1, n + 1):
            idx = (start + step) % n
            if CANDIDATES[idx][1].exists():
                self.selected_idx.set(idx)
                self.combo.current(idx)
                self.update_path_text()
                self.launch_selected()
                return
        messagebox.showerror("No candidates", "No bundled MediaPrep candidate scripts were found.")

    def run_dependency_check(self) -> None:
        self._log("Running dependency check in a child Python process...")
        code = """
import importlib, sys, json
mods = %r
out = []
for label, mod in mods:
    try:
        importlib.import_module(mod)
        out.append([label, mod, 'OK', ''])
    except Exception as e:
        out.append([label, mod, 'MISSING_OR_ERROR', repr(e)])
print(json.dumps(out, indent=2))
""" % (REQUIRED_IMPORTS,)
        try:
            cp = subprocess.run(python_cmd() + ["-c", code], cwd=str(ROOT), capture_output=True, text=True, timeout=35)
            self._log("Dependency check exit code: " + str(cp.returncode))
            self._log(cp.stdout.strip() or "<no stdout>")
            if cp.stderr.strip():
                self._log("STDERR:\n" + cp.stderr.strip())
            if cp.returncode != 0:
                messagebox.showwarning("Dependency check", "Dependency check returned nonzero. See the log window.")
        except subprocess.TimeoutExpired:
            self._log("Dependency check timed out after 35 seconds.")
            messagebox.showwarning("Dependency check timeout", "Dependency import check timed out after 35 seconds. This can indicate a stuck import or broken environment.")
        except Exception as exc:
            self._log("Dependency check failed: " + repr(exc))
            messagebox.showerror("Dependency check failed", str(exc))

    def install_mediaprep_dependencies(self) -> None:
        """Install the minimal packages needed for MediaPrep to import and open.

        The uploaded v0.82 logs showed MediaPrep was failing before the GUI appeared
        because the current Python environment lacked moviepy.  This button runs pip
        in the same interpreter used by the launcher so dependency installation and
        launch environment match.
        """
        if not messagebox.askyesno(
            "Install MediaPrep dependencies?",
            "This will run pip in the current Python environment:\n\n"
            f"{sys.executable}\n\n"
            "Packages include moviepy, imageio, imageio-ffmpeg, pillow, numpy, scipy, and opencv-python.\n\n"
            "Continue?",
        ):
            return
        self._log("Installing/Fixing MediaPrep dependencies in the current Python environment...")
        cmd = python_cmd() + ["-m", "pip", "install", "--upgrade"] + MEDIAPREP_PIP_PACKAGES
        self._log("Command: " + json.dumps(cmd))
        self.status.set("Installing MediaPrep dependencies. This can take a few minutes...")

        def worker() -> None:
            try:
                proc = subprocess.Popen(
                    cmd,
                    cwd=str(ROOT),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                )
                if proc.stdout is not None:
                    for line in proc.stdout:
                        self.after(0, self._log, line.rstrip())
                rc = proc.wait()
                self.after(0, self._log, f"Dependency install exit code: {rc}")
                self.after(0, self.status.set, "Dependency install finished." if rc == 0 else f"Dependency install failed with code {rc}.")
                if rc == 0:
                    self.after(0, messagebox.showinfo, "Dependencies installed", "MediaPrep dependencies installed. Run Dependency Check, then launch MediaPrep again.")
                else:
                    self.after(0, messagebox.showerror, "Dependency install failed", "pip returned a nonzero exit code. See the live log window.")
            except Exception as exc:
                self.after(0, self._log, "Dependency install failed: " + repr(exc))
                self.after(0, messagebox.showerror, "Dependency install failed", str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def stop_process(self) -> None:
        if self.proc is None or self.proc.poll() is not None:
            self.status.set("No running MediaPrep process to stop.")
            return
        try:
            self.proc.terminate()
            self.status.set("Terminate requested for MediaPrep.")
            self._log("Terminate requested.")
        except Exception as exc:
            self._log("Terminate failed: " + repr(exc))
            messagebox.showerror("Stop failed", str(exc))

    def open_log_folder(self) -> None:
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(LOG_ROOT))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(LOG_ROOT)])
            else:
                subprocess.Popen(["xdg-open", str(LOG_ROOT)])
        except Exception as exc:
            messagebox.showerror("Open log folder failed", str(exc))


if __name__ == "__main__":
    app = MediaPrepLauncher(sys.argv[1:])
    app.mainloop()
