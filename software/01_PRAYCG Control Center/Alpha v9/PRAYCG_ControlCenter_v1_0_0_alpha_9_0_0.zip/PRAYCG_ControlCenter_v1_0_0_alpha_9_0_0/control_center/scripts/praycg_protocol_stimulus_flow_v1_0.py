#!/usr/bin/env python3
"""Protocol-lock-driven discovery for the alpha.8 Stimulus Library and Forge.

This is a non-UI selection model.  It gives a Treeview (or another file-nav
widget) ordinary rows to render, but it neither launches a preparation engine
nor grants acquisition authority.  Protocols are read from the existing
federated Protocol Atlas; packs are revalidated with the frozen Stimulus Pack
validator every time a locked workflow is resolved.
"""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_ROOT = Path(__file__).resolve().parent
STIMULUS_TOOL_ROOT = PACKAGE_ROOT / "tools" / "Stimulus_Forge_Library_v1_0"

import sys

for _path in (SCRIPTS_ROOT, STIMULUS_TOOL_ROOT):
    if str(_path) not in sys.path:
        sys.path.insert(0, str(_path))

from praycg_protocol_library_v2_0 import (  # noqa: E402
    FAMILY_ATLAS,
    FAMILY_NATIVE,
    PACKAGED_ATLAS_ROOT,
    discover_protocol_modules,
    validate_protocol_lock,
    write_protocol_lock,
)
from praycg_stimulus_common_v1_0 import (  # noqa: E402
    StimulusContractError,
    catalog_pack_root,
    contained_path,
    load_catalog,
    read_json,
    resolve_bindings,
    sha256_file,
    validate_pack,
)


MODEL_SCHEMA = "PRAYCG_ProtocolStimulusSelectionModel_v1_0"
WORKFLOW_SCHEMA = "PRAYCG_ProtocolStimulusWorkflow_v1_0"
ENGINE_SCHEMA = "PRAYCG_StimulusForgeEngineRegistry_v1_0"
MATURE_CATALOG_SCHEMA = "PRAYCG_MatureEndpointAtlasCatalog_v1_0"
PUBLIC_EXPANSION_CATALOG_SCHEMA = "PRAYCG_PublicDatasetProtocolCatalog_v1_0"
MASTER_MEDIA_TAG = "MASTER_PRAYCG_STIMULUS_MEDIA"
HEX64 = re.compile(r"^[0-9a-f]{64}$")
ACCEPTED_MASTER_VALIDATION = {"PASS", "PASS_BASIC_VALIDATION", "PASS_WITH_WARNINGS"}
ACCEPTED_PACK_VALIDATION = {"PASS", "CAUTION"}
LEGACY_MASTER_MIGRATION_SCHEMA = "PRAYCG_LegacyMasterTagMigration_v1_0"


class WorkflowSelectionError(RuntimeError):
    """Raised when the governed selection model cannot safely resolve a request."""


def _identity(protocol_id: Any, protocol_version: Any) -> tuple[str, str]:
    return str(protocol_id or "").strip(), str(protocol_version or "").strip()


def _within(path: Path, root: Path) -> bool:
    try:
        path.resolve(strict=False).relative_to(root.resolve(strict=False))
        return True
    except (OSError, ValueError):
        return False


def _node_fragment(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.casefold()).strip("-") or "item"


def _candidate_suffix(path: Path) -> str:
    return hashlib.sha256(str(path.resolve(strict=False)).casefold().encode("utf-8")).hexdigest()[:12]


def _has_mp4_file_type_box(path: Path) -> bool:
    """Perform a small dependency-free ISO-BMFF signature check."""
    try:
        with path.open("rb") as handle:
            header = handle.read(32)
    except OSError:
        return False
    return len(header) >= 12 and header[4:8] == b"ftyp"


def _blocked_candidate(candidate_id: str, display_name: str, source_kind: str, reasons: list[str]) -> dict[str, Any]:
    return {
        "node_type": "stimulus",
        "candidate_id": candidate_id,
        "display_name": display_name,
        "source_kind": source_kind,
        "status": "BLOCKED",
        "selection_allowed": False,
        "participant_acquisition_eligible": False,
        "reasons": reasons or ["No compatible, validated stimulus contract was established."],
        "plain_language_status": "Not shown as an available stimulus because " + " ".join(reasons),
    }


def _legacy_master_migration_reasons(
    row: Mapping[str, Any],
    *,
    stimulus_root: Path,
    duplicate_ids: set[str],
) -> list[str]:
    """Fail-closed checks for an untagged master created by the alpha.4 UI."""
    reasons: list[str] = []
    stimulus_id = str(row.get("stimulus_id") or "").strip()
    if not stimulus_id:
        reasons.append("stimulus_id is missing")
    elif stimulus_id in duplicate_ids:
        reasons.append("stimulus_id is duplicated in the registry")

    tags = row.get("tags", [])
    if tags is not None and not isinstance(tags, list):
        reasons.append("tags is present but is not an array")
    stimulus_class = str(row.get("stimulus_class") or "").strip()
    if stimulus_class and stimulus_class != MASTER_MEDIA_TAG:
        reasons.append("stimulus_class already declares a different class")
    if "active_for_selection" in row and row.get("active_for_selection") is not True:
        reasons.append("registry row was explicitly inactive and will not be reactivated")
    validation_status = str(row.get("validation_status") or "")
    if validation_status not in ACCEPTED_MASTER_VALIDATION:
        reasons.append("recorded master-media validation status is not accepted")

    root = Path(stimulus_root).expanduser().resolve(strict=False)
    folder_text = str(row.get("folder") or "").strip()
    master_text = str(row.get("master_mp4") or "").strip()
    if not folder_text:
        reasons.append("folder is missing")
    if not master_text:
        reasons.append("master_mp4 is missing")
    if reasons:
        return reasons

    folder = Path(folder_text).expanduser().resolve(strict=False)
    master = Path(master_text).expanduser().resolve(strict=False)
    expected_master = (folder / "master" / "stimulus_master.mp4").resolve(strict=False)
    try:
        if not root.is_dir() or root.is_symlink():
            reasons.append("configured stimulus root is missing or is a symbolic link")
        if not folder.is_dir() or folder.is_symlink():
            reasons.append("declared stimulus folder is missing or is a symbolic link")
        if folder.parent != root or folder.name != stimulus_id:
            reasons.append("declared folder does not match the alpha.4 stimulus-root/stimulus-id layout")
        if not _within(folder, root):
            reasons.append("declared stimulus folder is outside the configured stimulus root")
        if master != expected_master:
            reasons.append("master_mp4 does not match the alpha.4 master/stimulus_master.mp4 layout")
        if master.parent.is_symlink():
            reasons.append("master media directory is a symbolic link")
        if not (
            master.is_file()
            and not master.is_symlink()
            and master.suffix.casefold() == ".mp4"
            and master.stat().st_size > 0
            and _has_mp4_file_type_box(master)
        ):
            reasons.append("master is not a non-empty, regular MP4 with an ISO-BMFF file-type header")
    except OSError:
        reasons.append("master paths could not be inspected")
    if not _within(master, folder):
        reasons.append("master MP4 is outside the declared stimulus folder")

    recorded_hash = str(row.get("sha256") or "")
    if not HEX64.fullmatch(recorded_hash):
        reasons.append("registry row has no valid lowercase SHA-256 identity")
    elif master.is_file():
        try:
            if sha256_file(master) != recorded_hash:
                reasons.append("live master MP4 hash does not match the registry")
        except OSError:
            reasons.append("live master MP4 could not be hashed")

    validation_path = master.parent / "master_media_validation_report.json"
    hash_path = master.parent / "master_sha256.txt"
    try:
        validation = json.loads(validation_path.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError):
        validation = None
        reasons.append("alpha.4 master-media validation report is missing or unreadable")
    if isinstance(validation, dict):
        if validation.get("schema") != "PRAYCG_MasterStimulus_Validation_v0_1":
            reasons.append("alpha.4 validation report schema is not recognized")
        if str(validation.get("stimulus_id") or "") != stimulus_id:
            reasons.append("validation report stimulus_id does not match the registry")
        copied_to = str(validation.get("copied_to") or "").strip()
        if not copied_to or Path(copied_to).expanduser().resolve(strict=False) != master:
            reasons.append("validation report master path does not match the registry")
        if str(validation.get("sha256") or "") != recorded_hash:
            reasons.append("validation report hash does not match the registry")
        if str(validation.get("status") or "") != validation_status:
            reasons.append("validation report status does not match the registry")
    try:
        if hash_path.read_text(encoding="utf-8-sig").strip() != recorded_hash:
            reasons.append("master_sha256.txt does not match the registry")
    except (OSError, UnicodeError):
        reasons.append("master_sha256.txt is missing or unreadable")
    return reasons


def migrate_legacy_master_registry(
    registry_path: Path,
    stimulus_root: Path,
) -> dict[str, Any]:
    """Explicitly tag only hash-verified alpha.4 master rows; never promote status."""
    path = Path(registry_path).expanduser().resolve(strict=False)
    root = Path(stimulus_root).expanduser().resolve(strict=False)
    try:
        original_bytes = path.read_bytes()
        payload = json.loads(original_bytes.decode("utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise WorkflowSelectionError(f"The stimulus registry cannot be migrated: {exc}") from exc
    if not isinstance(payload, dict) or payload.get("schema") not in {
        "PRAYCG_StimulusRegistry_v0_1",
        "PRAYCG_StimulusRegistry_v1_0",
    }:
        raise WorkflowSelectionError("The stimulus registry schema is not recognized for this migration.")
    if not isinstance(payload.get("stimuli", []), list):
        raise WorkflowSelectionError("The stimulus registry has no valid stimuli collection.")
    if "packs" in payload and not isinstance(payload.get("packs"), list):
        raise WorkflowSelectionError("The stimulus registry has a malformed packs collection.")

    rows = payload.get("stimuli", [])
    identifiers = [str(row.get("stimulus_id") or "") for row in rows if isinstance(row, dict)]
    duplicate_ids = {value for value in identifiers if value and identifiers.count(value) > 1}
    migrated: list[str] = []
    already_tagged: list[str] = []
    skipped: list[dict[str, Any]] = []
    generated_utc = datetime.now(timezone.utc).isoformat()
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            skipped.append({"row_index": index, "stimulus_id": "", "reasons": ["registry row is not an object"]})
            continue
        stimulus_id = str(row.get("stimulus_id") or "")
        tags = row.get("tags")
        if isinstance(tags, list) and MASTER_MEDIA_TAG in tags:
            already_tagged.append(stimulus_id)
            continue
        reasons = _legacy_master_migration_reasons(row, stimulus_root=root, duplicate_ids=duplicate_ids)
        if reasons:
            skipped.append({"row_index": index, "stimulus_id": stimulus_id, "reasons": reasons})
            continue
        preserved_tags = [str(value) for value in (tags or []) if str(value)]
        row["tags"] = list(dict.fromkeys([*preserved_tags, MASTER_MEDIA_TAG]))
        row["stimulus_class"] = MASTER_MEDIA_TAG
        row["active_for_selection"] = True
        row["compatibility_migration"] = {
            "schema": LEGACY_MASTER_MIGRATION_SCHEMA,
            "generated_utc": generated_utc,
            "source_release": "1.0.0-alpha.4",
            "target_release": "1.0.0-alpha.9.0.0",
            "result": "TAG_ADDED_AFTER_LIVE_REVALIDATION",
            "scientific_status_promoted": False,
        }
        migrated.append(stimulus_id)

    backup_path = ""
    if migrated:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        backup = path.with_name(f"{path.stem}.pre_alpha5_master_tag_migration.{stamp}{path.suffix}")
        counter = 1
        while backup.exists():
            backup = path.with_name(f"{path.stem}.pre_alpha5_master_tag_migration.{stamp}.{counter}{path.suffix}")
            counter += 1
        backup.write_bytes(original_bytes)
        temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
        try:
            temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
            temporary.replace(path)
        finally:
            if temporary.exists():
                temporary.unlink()
        backup_path = str(backup)

    if migrated and skipped:
        status = "PASS_WITH_SKIPS"
    elif migrated:
        status = "PASS"
    else:
        status = "NO_CHANGES"
    return {
        "schema": LEGACY_MASTER_MIGRATION_SCHEMA,
        "status": status,
        "registry_path": str(path),
        "stimulus_root": str(root),
        "migrated_ids": migrated,
        "already_tagged_ids": already_tagged,
        "skipped": skipped,
        "backup_path": backup_path,
        "scientific_status_promoted": False,
        "authority_boundary": (
            "The exact master-media tag was added only after conservative file and legacy-report checks. "
            "No scientific status, participant eligibility, session lock, or acquisition authority was promoted."
        ),
    }


class ProtocolStimulusWorkflowModel:
    """Resolve Protocol Atlas locks into filtered stimulus and Forge choices."""

    def __init__(
        self,
        package_root: Path | None = None,
        *,
        workflow_config_path: Path | None = None,
        media_probe: bool = False,
    ) -> None:
        self.package_root = Path(package_root or PACKAGE_ROOT).expanduser().resolve(strict=False)
        self.atlas_root = (self.package_root / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0").resolve(strict=False)
        self.stimulus_tool_root = (self.package_root / "tools" / "Stimulus_Forge_Library_v1_0").resolve(strict=False)
        self.workflow_config_path = Path(
            workflow_config_path
            or self.package_root / "control_center" / "config" / "protocol_stimulus_workflow_v1_0.json"
        ).expanduser().resolve(strict=False)
        self.engine_registry_path = self.stimulus_tool_root / "engine_registry_v1_0.json"
        self.mature_catalog_path = self.package_root / "config" / "praycg_mature_endpoint_atlas_catalog_v1_0.json"
        self.public_expansion_catalog_path = self.package_root / "config" / "public_dataset_protocol_catalog_v1_0.json"
        self.media_probe = bool(media_probe)

    def _load_workflow(self) -> dict[str, Any]:
        try:
            payload = json.loads(self.workflow_config_path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise WorkflowSelectionError(f"The protocol-to-stimulus workflow catalog cannot be read: {exc}") from exc
        if not isinstance(payload, dict) or payload.get("schema") != WORKFLOW_SCHEMA:
            raise WorkflowSelectionError("The protocol-to-stimulus workflow catalog has an unsupported schema.")
        if payload.get("master_media_tag") != MASTER_MEDIA_TAG:
            raise WorkflowSelectionError(f"The workflow catalog must use the exact governed tag {MASTER_MEDIA_TAG}.")
        return payload

    def _load_mature_catalog(self) -> dict[str, Any]:
        try:
            payload = json.loads(self.mature_catalog_path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise WorkflowSelectionError(f"The mature endpoint catalog cannot be read: {exc}") from exc
        if not isinstance(payload, dict) or payload.get("schema") != MATURE_CATALOG_SCHEMA:
            raise WorkflowSelectionError("The mature endpoint catalog has an unsupported schema.")
        if payload.get("base_platform") != self.package_root.name:
            raise WorkflowSelectionError("The mature endpoint catalog does not name this release as its base platform.")
        return payload

    def _load_public_expansion_catalog(self) -> dict[str, Any]:
        try:
            payload = json.loads(self.public_expansion_catalog_path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise WorkflowSelectionError(f"The public-dataset protocol catalog cannot be read: {exc}") from exc
        if not isinstance(payload, dict) or payload.get("schema") != PUBLIC_EXPANSION_CATALOG_SCHEMA:
            raise WorkflowSelectionError("The public-dataset protocol catalog has an unsupported schema.")
        if payload.get("base_platform") != self.package_root.name:
            raise WorkflowSelectionError("The public-dataset protocol catalog does not name this release as its base platform.")
        return payload

    def _load_engine_registry(self) -> tuple[dict[str, dict[str, Any]], list[str]]:
        errors: list[str] = []
        try:
            payload = json.loads(self.engine_registry_path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            return {}, [f"The Stimulus Forge engine registry cannot be read: {exc}"]
        if not isinstance(payload, dict) or payload.get("schema") != ENGINE_SCHEMA:
            return {}, ["The Stimulus Forge engine registry has an unsupported schema."]
        engines: dict[str, dict[str, Any]] = {}
        for index, row in enumerate(payload.get("engines", [])):
            if not isinstance(row, dict) or not str(row.get("id") or "").strip():
                errors.append(f"Engine registry row {index} has no valid id.")
                continue
            engine_id = str(row["id"])
            if engine_id in engines:
                errors.append(f"Duplicate Stimulus Forge engine id: {engine_id}.")
                continue
            engines[engine_id] = dict(row)
        return engines, errors

    def _discover_protocols(self) -> tuple[list[dict[str, Any]], list[str]]:
        # The existing federated adapter itself verifies that this is the exact
        # package-owned Atlas root; an external folder cannot become authority.
        return discover_protocol_modules(self.atlas_root)

    def catalog_validation(self) -> dict[str, Any]:
        """Cross-check the new flow map against all existing governed catalogs."""
        errors: list[str] = []
        try:
            workflow = self._load_workflow()
        except WorkflowSelectionError as exc:
            return {"status": "FAIL", "errors": [str(exc)]}
        engines, engine_errors = self._load_engine_registry()
        errors.extend(engine_errors)
        discovered, discovery_errors = self._discover_protocols()
        errors.extend(discovery_errors)
        try:
            stimulus_catalog = load_catalog(self.stimulus_tool_root)
        except StimulusContractError as exc:
            stimulus_catalog = {}
            errors.append(str(exc))
        try:
            mature_catalog = self._load_mature_catalog()
        except WorkflowSelectionError as exc:
            mature_catalog = {}
            errors.append(str(exc))
        try:
            public_expansion_catalog = self._load_public_expansion_catalog()
        except WorkflowSelectionError as exc:
            public_expansion_catalog = {}
            errors.append(str(exc))

        flow_rows = [row for row in workflow.get("protocols", []) if isinstance(row, dict)]
        flow_counts: dict[tuple[str, str], int] = {}
        for index, row in enumerate(flow_rows):
            key = _identity(row.get("protocol_id"), row.get("protocol_version"))
            flow_counts[key] = flow_counts.get(key, 0) + 1
            if not all(key):
                errors.append(f"Workflow protocol row {index} has an incomplete identity.")
            if not str(row.get("navigation_group") or "").strip():
                errors.append(f"Workflow protocol {key} has no navigation_group.")
            if not str(row.get("plain_language") or "").strip():
                errors.append(f"Workflow protocol {key} has no plain-language explanation.")
            if not isinstance(row.get("accepts_master_media_tag"), bool):
                errors.append(f"Workflow protocol {key} must explicitly declare accepts_master_media_tag.")
            direct = row.get("direct_engines")
            pipeline = row.get("pipeline_engines")
            mature_preparation = str(row.get("preparation_mode") or "").startswith("MATURE_")
            if not isinstance(direct, list) or (not direct and not mature_preparation):
                errors.append(f"Workflow protocol {key} must expose at least one direct engine or validation utility.")
                direct = []
            if not isinstance(pipeline, list):
                errors.append(f"Workflow protocol {key} has a malformed pipeline_engines list.")
                pipeline = []
            for engine_id in list(direct) + list(pipeline):
                if engine_id not in engines:
                    errors.append(f"Workflow protocol {key} references an unregistered engine: {engine_id}.")
            for engine_id in direct:
                mode = str(engines.get(engine_id, {}).get("invocation_mode") or "")
                if mode not in {"STANDALONE_PACK_TEMPLATE", "VALIDATION_UTILITY"}:
                    errors.append(f"Direct engine {engine_id} for {key} is not directly invocable.")
            for engine_id in pipeline:
                if str(engines.get(engine_id, {}).get("invocation_mode") or "") != "PIPELINE_STAGE":
                    errors.append(f"Pipeline engine {engine_id} for {key} is not registered as a pipeline stage.")

        duplicate_flow = sorted(key for key, count in flow_counts.items() if count != 1)
        for key in duplicate_flow:
            errors.append(f"Protocol workflow identity must occur exactly once: {key[0]} v{key[1]}.")
        discovered_keys = {_identity(row.get("protocol_id"), row.get("protocol_version")) for row in discovered}
        flow_keys = set(flow_counts)
        for key in sorted(discovered_keys - flow_keys):
            errors.append(f"Discovered protocol has no stimulus workflow: {key[0]} v{key[1]}.")
        for key in sorted(flow_keys - discovered_keys):
            errors.append(f"Stimulus workflow references no discovered protocol: {key[0]} v{key[1]}.")

        catalog_rows = [row for row in stimulus_catalog.get("protocols", []) if isinstance(row, dict)]
        catalog_counts: dict[tuple[str, str], int] = {}
        for row in catalog_rows:
            key = _identity(row.get("protocol_id"), row.get("protocol_version"))
            catalog_counts[key] = catalog_counts.get(key, 0) + 1
        mature_rows = [row for row in mature_catalog.get("protocols", []) if isinstance(row, dict)]
        mature_counts: dict[tuple[str, str], int] = {}
        for index, row in enumerate(mature_rows):
            key = _identity(row.get("protocol_id"), row.get("protocol_version"))
            mature_counts[key] = mature_counts.get(key, 0) + 1
            if not all(key):
                errors.append(f"Mature endpoint catalog row {index} has an incomplete identity.")
        if mature_catalog and mature_catalog.get("protocol_count") != len(mature_rows):
            errors.append("The mature endpoint catalog protocol_count does not match its protocol rows.")
        public_rows = [row for row in public_expansion_catalog.get("protocols", []) if isinstance(row, dict)]
        public_counts: dict[tuple[str, str], int] = {}
        for index, row in enumerate(public_rows):
            key = _identity(row.get("protocol_id"), row.get("protocol_version"))
            public_counts[key] = public_counts.get(key, 0) + 1
            if not all(key):
                errors.append(f"Public-dataset catalog row {index} has an incomplete identity.")
        if public_expansion_catalog and public_expansion_catalog.get("protocol_count") != len(public_rows):
            errors.append("The public-dataset catalog protocol_count does not match its protocol rows.")
        overlap = sorted(
            set(catalog_counts).intersection(mature_counts)
            | set(catalog_counts).intersection(public_counts)
            | set(mature_counts).intersection(public_counts)
        )
        for key in overlap:
            errors.append(f"Protocol identity appears in both stimulus catalogs: {key[0]} v{key[1]}.")
        for key in sorted(discovered_keys):
            membership_count = catalog_counts.get(key, 0) + mature_counts.get(key, 0) + public_counts.get(key, 0)
            if membership_count != 1:
                errors.append(f"Governed stimulus catalogs must contain exactly one row for {key[0]} v{key[1]}.")
        for key in sorted(set(catalog_counts).union(mature_counts).union(public_counts) - discovered_keys):
            errors.append(f"A governed stimulus catalog references no discovered protocol: {key[0]} v{key[1]}.")

        record_map = {
            _identity(row.get("protocol_id"), row.get("protocol_version")): row
            for row in discovered
        }
        for key, count in sorted(mature_counts.items()):
            if count != 1:
                errors.append(f"Mature endpoint identity must occur exactly once: {key[0]} v{key[1]}.")
                continue
            record = record_map.get(key)
            row = next(
                (item for item in mature_rows if _identity(item.get("protocol_id"), item.get("protocol_version")) == key),
                {},
            )
            if record and Path(str(record.get("manifest_path") or "")).name != str(row.get("manifest") or ""):
                errors.append(f"Mature endpoint manifest identity does not match discovery for {key[0]} v{key[1]}.")
            contracts = [
                item for item in (record or {}).get("module", {}).get("assets", [])
                if isinstance(item, dict) and item.get("source") == "operator_selection"
            ]
            expected_mode = "MATURE_PROTOCOL_ASSET_FOLDER" if contracts else "MATURE_RUNNER_GENERATED"
            flow = next(
                (item for item in flow_rows if _identity(item.get("protocol_id"), item.get("protocol_version")) == key),
                {},
            )
            if flow and flow.get("preparation_mode") != expected_mode:
                errors.append(
                    f"Mature endpoint workflow mode for {key[0]} v{key[1]} must be {expected_mode}."
                )

        return {
            "schema": "PRAYCG_ProtocolStimulusCatalogValidation_v1_0",
            "status": "PASS" if not errors else "FAIL",
            "errors": errors,
            "facts": {
                "protocol_count": len(discovered_keys),
                "workflow_count": len(flow_keys),
                "frozen_stimulus_catalog_count": len(catalog_counts),
                "mature_endpoint_catalog_count": len(mature_counts),
                "public_dataset_catalog_count": len(public_counts),
                "engine_count": len(engines),
                "master_media_tag": workflow.get("master_media_tag"),
            },
            "boundary": "PASS establishes internal catalog consistency, not scientific validity or acquisition authority.",
        }

    def _flow_map(self) -> dict[tuple[str, str], dict[str, Any]]:
        workflow = self._load_workflow()
        result: dict[tuple[str, str], dict[str, Any]] = {}
        for row in workflow.get("protocols", []):
            if isinstance(row, dict):
                key = _identity(row.get("protocol_id"), row.get("protocol_version"))
                if key in result:
                    raise WorkflowSelectionError(f"Duplicate protocol workflow identity: {key[0]} v{key[1]}.")
                result[key] = dict(row)
        return result

    def protocol_navigation(self) -> dict[str, Any]:
        """Return file-navigation nodes; callers need no combobox state."""
        records, discovery_errors = self._discover_protocols()
        try:
            flows = self._flow_map()
        except WorkflowSelectionError as exc:
            flows = {}
            discovery_errors = list(discovery_errors) + [str(exc)]
        nodes: list[dict[str, Any]] = []
        group_ids: dict[str, str] = {}
        for record in records:
            key = _identity(record.get("protocol_id"), record.get("protocol_version"))
            flow = flows.get(key)
            group = str((flow or {}).get("navigation_group") or "Unconfigured Protocols")
            group_id = group_ids.setdefault(group, f"protocol-folder::{_node_fragment(group)}")
            module = record.get("module") if isinstance(record.get("module"), dict) else {}
            nodes.append(
                {
                    "node_type": "protocol",
                    "node_id": f"protocol::{key[0]}::{key[1]}",
                    "parent_id": group_id,
                    "protocol_id": key[0],
                    "protocol_version": key[1],
                    "display_name": str(record.get("display_name") or key[0]),
                    "module_family": record.get("module_family"),
                    "manifest_path": record.get("manifest_path"),
                    "branch_count": record.get("branch_count"),
                    "branch_order": list(record.get("branch_order") or []),
                    "description": str(module.get("short_description") or record.get("description") or ""),
                    "scientific_boundary": str(record.get("scientific_boundary") or ""),
                    "workflow_status": "READY_TO_LOCK" if flow else "BLOCKED_NO_STIMULUS_WORKFLOW",
                    "plain_language_next_step": (
                        "Select this file-like row, review its design, then lock it to filter the next tab."
                        if flow
                        else "This protocol cannot be locked through alpha.8 because no governed stimulus workflow exists."
                    ),
                }
            )
        folders = [
            {
                "node_type": "folder",
                "node_id": node_id,
                "parent_id": "",
                "display_name": group,
                "plain_language": "Expand this folder to inspect protocols in this family.",
            }
            for group, node_id in group_ids.items()
        ]
        folders.sort(key=lambda row: str(row["display_name"]).casefold())
        nodes.sort(key=lambda row: (str(row["parent_id"]), str(row["display_name"]).casefold()))
        return {
            "schema": MODEL_SCHEMA,
            "status": "PASS" if not discovery_errors else "CAUTION",
            "navigation_mode": "TREE_FILE_NAVIGATION",
            "errors": discovery_errors,
            "nodes": folders + nodes,
            "plain_language": (
                "Choose one protocol as though you were choosing a file. Locking it determines which stimulus "
                "packs, master-media folders, and preparation engines can appear on the next tab."
            ),
        }

    def lock_protocol(self, protocol_node_id: str, lock_path: Path) -> dict[str, Any]:
        """Create the existing immutable protocol lock from a navigation row."""
        validation = self.catalog_validation()
        if validation["status"] != "PASS":
            raise WorkflowSelectionError("Protocol selection is blocked by catalog errors: " + "; ".join(validation["errors"]))
        records, errors = self._discover_protocols()
        if errors:
            raise WorkflowSelectionError("Protocol discovery is not clean: " + "; ".join(errors))
        matches = [
            row for row in records
            if f"protocol::{row.get('protocol_id')}::{row.get('protocol_version')}" == protocol_node_id
        ]
        if len(matches) != 1:
            raise WorkflowSelectionError("The selected protocol navigation row did not resolve exactly once.")
        write_protocol_lock(matches[0], Path(lock_path))
        return validate_protocol_lock(Path(lock_path), self.atlas_root)

    def _protocol_catalog_row(self, protocol_id: str, protocol_version: str) -> dict[str, Any]:
        catalog = load_catalog(self.stimulus_tool_root)
        matches = [
            dict(row) for row in catalog.get("protocols", [])
            if isinstance(row, dict) and _identity(row.get("protocol_id"), row.get("protocol_version")) == (protocol_id, protocol_version)
        ]
        if len(matches) == 1:
            return {**matches[0], "catalog_kind": "FROZEN_STIMULUS_PACK_CATALOG"}
        if matches:
            raise WorkflowSelectionError(
                f"The Stimulus Library catalog does not contain exactly one contract for {protocol_id} v{protocol_version}."
            )
        public_expansion = self._load_public_expansion_catalog()
        public_matches = [
            dict(row) for row in public_expansion.get("protocols", [])
            if isinstance(row, dict) and _identity(row.get("protocol_id"), row.get("protocol_version")) == (protocol_id, protocol_version)
        ]
        if len(public_matches) == 1:
            records, discovery_errors = self._discover_protocols()
            record_matches = [
                row for row in records
                if _identity(row.get("protocol_id"), row.get("protocol_version")) == (protocol_id, protocol_version)
            ]
            if discovery_errors or len(record_matches) != 1:
                raise WorkflowSelectionError("Public-dataset protocol discovery is not clean and unique.")
            record = record_matches[0]
            if Path(str(record.get("manifest_path") or "")).name != str(public_matches[0].get("manifest") or ""):
                raise WorkflowSelectionError(
                    f"The public-dataset catalog manifest does not match discovery for {protocol_id} v{protocol_version}."
                )
            contracts = [
                dict(item) for item in record.get("module", {}).get("assets", [])
                if isinstance(item, dict) and item.get("source") == "operator_selection"
            ]
            return {
                **public_matches[0],
                "catalog_kind": "PUBLIC_DATASET_EXPANSION",
                "expected_asset_keys": list(record.get("required_asset_keys") or []),
                "operator_asset_keys": [str(item.get("key") or "") for item in contracts if str(item.get("key") or "")],
                "sample_options": [],
            }
        if public_matches:
            raise WorkflowSelectionError(
                f"The public-dataset catalog does not contain exactly one contract for {protocol_id} v{protocol_version}."
            )
        mature = self._load_mature_catalog()
        mature_matches = [
            dict(row) for row in mature.get("protocols", [])
            if isinstance(row, dict) and _identity(row.get("protocol_id"), row.get("protocol_version")) == (protocol_id, protocol_version)
        ]
        records, discovery_errors = self._discover_protocols()
        record_matches = [
            row for row in records
            if _identity(row.get("protocol_id"), row.get("protocol_version")) == (protocol_id, protocol_version)
        ]
        if discovery_errors:
            raise WorkflowSelectionError("Protocol discovery is not clean: " + "; ".join(discovery_errors))
        if len(mature_matches) != 1 or len(record_matches) != 1:
            raise WorkflowSelectionError(
                f"The governed catalogs do not contain exactly one contract for {protocol_id} v{protocol_version}."
            )
        record = record_matches[0]
        if Path(str(record.get("manifest_path") or "")).name != str(mature_matches[0].get("manifest") or ""):
            raise WorkflowSelectionError(
                f"The mature endpoint catalog manifest does not match discovery for {protocol_id} v{protocol_version}."
            )
        contracts = [
            dict(item) for item in record.get("module", {}).get("assets", [])
            if isinstance(item, dict) and item.get("source") == "operator_selection"
        ]
        return {
            **mature_matches[0],
            "catalog_kind": "MATURE_ENDPOINT_ATLAS",
            "expected_asset_keys": list(record.get("required_asset_keys") or []),
            "operator_asset_keys": [str(item.get("key") or "") for item in contracts if str(item.get("key") or "")],
            "sample_options": [],
        }

    def _engine_rows(self, flow: Mapping[str, Any]) -> list[dict[str, Any]]:
        engines, errors = self._load_engine_registry()
        if errors:
            raise WorkflowSelectionError("The Stimulus Forge registry is invalid: " + "; ".join(errors))
        rows: list[dict[str, Any]] = []
        for stage, key in (("DIRECT", "direct_engines"), ("PIPELINE_STAGE", "pipeline_engines")):
            for engine_id in flow.get(key, []):
                engine = engines.get(str(engine_id))
                if not engine:
                    raise WorkflowSelectionError(f"The locked workflow references an unavailable engine: {engine_id}.")
                rows.append(
                    {
                        **engine,
                        "node_type": "prep_engine",
                        "node_id": f"prep-engine::{engine_id}",
                        "stage_role": stage,
                        "direct_launch_allowed": engine.get("invocation_mode") in {"STANDALONE_PACK_TEMPLATE", "VALIDATION_UTILITY"},
                        "plain_language_status": (
                            "Available as a reviewed direct Forge choice for this locked protocol."
                            if stage == "DIRECT"
                            else "Used inside the selected preparation pipeline; it is not a standalone launch choice."
                        ),
                    }
                )
        return rows

    def _pack_candidate(
        self,
        *,
        root: Path,
        source_kind: str,
        protocol_id: str,
        protocol_version: str,
        expected_asset_keys: list[str],
        registry_row: Mapping[str, Any] | None = None,
        catalog_row: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        root = Path(root).expanduser().resolve(strict=False)
        declared = dict(registry_row or catalog_row or {})
        pack_id = str(declared.get("pack_id") or root.name)
        candidate_id = (
            f"bundled::{pack_id}" if source_kind == "BUNDLED_SAMPLE_PACK"
            else f"installed::{pack_id}::{_candidate_suffix(root)}"
        )
        display_name = str(declared.get("display_name") or pack_id)
        reasons: list[str] = []
        if source_kind == "INSTALLED_PACK":
            if declared.get("active_for_selection") is not True:
                reasons.append("its installed-registry row is inactive")
            if str(declared.get("validation_status") or "") not in ACCEPTED_PACK_VALIDATION:
                reasons.append("its installed-registry validation status is not PASS or CAUTION")
            recorded_hash = str(declared.get("manifest_content_sha256") or "")
            if not HEX64.fullmatch(recorded_hash):
                reasons.append("its installed-registry row has no valid manifest identity hash")
        if not root.is_dir() or root.is_symlink():
            reasons.append("the pack folder is missing or is a symbolic link")
        if reasons:
            return _blocked_candidate(candidate_id, display_name, source_kind, reasons)

        report = validate_pack(root, media_probe=self.media_probe)
        if report.status not in ACCEPTED_PACK_VALIDATION:
            reasons.extend(report.errors or ["live pack validation did not pass"])
            return _blocked_candidate(candidate_id, display_name, source_kind, reasons)
        try:
            manifest = read_json(root / "stimulus_pack_manifest.json")
        except StimulusContractError as exc:
            return _blocked_candidate(candidate_id, display_name, source_kind, [str(exc)])
        if not isinstance(manifest, dict):
            return _blocked_candidate(candidate_id, display_name, source_kind, ["the pack manifest is not a JSON object"])
        if str(manifest.get("pack_id") or "") != pack_id:
            reasons.append("its manifest pack_id does not match its registry or bundled-catalog identity")
        if source_kind == "INSTALLED_PACK":
            if str(manifest.get("manifest_content_sha256") or "") != str(declared.get("manifest_content_sha256") or ""):
                reasons.append("its live manifest hash no longer matches the installed registry")
            declared_version = str(declared.get("pack_version") or "")
            if not declared_version or declared_version != str(manifest.get("pack_version") or ""):
                reasons.append("its live pack version does not match the installed registry")
        matches = [
            row for row in manifest.get("compatibility", [])
            if isinstance(row, dict) and _identity(row.get("protocol_id"), row.get("protocol_version")) == (protocol_id, protocol_version)
        ]
        if len(matches) != 1:
            reasons.append(f"it does not declare exactly one compatibility row for {protocol_id} v{protocol_version}")
        bindings = dict(matches[0].get("bindings") or {}) if len(matches) == 1 else {}
        missing_assets = sorted(set(expected_asset_keys).difference(bindings))
        if missing_assets:
            reasons.append("its compatibility row omits required assets: " + ", ".join(missing_assets))
        if reasons:
            return _blocked_candidate(candidate_id, display_name, source_kind, reasons)
        try:
            resolved_bindings = resolve_bindings(root, protocol_id)
        except StimulusContractError as exc:
            return _blocked_candidate(candidate_id, display_name, source_kind, [str(exc)])
        scientific_status = str(manifest.get("scientific_status") or "UNKNOWN")
        return {
            "node_type": "stimulus",
            "candidate_id": candidate_id,
            "display_name": str(manifest.get("display_name") or display_name),
            "source_kind": source_kind,
            "source_path": str(root),
            "pack_id": pack_id,
            "pack_version": manifest.get("pack_version"),
            "manifest_content_sha256": manifest.get("manifest_content_sha256"),
            "scientific_status": scientific_status,
            "validation_status": report.status,
            "delivery_mode": matches[0].get("delivery_mode"),
            "bindings": resolved_bindings,
            "selection_allowed": True,
            "participant_acquisition_eligible": scientific_status == "STUDY_LOCKED",
            "status": "AVAILABLE",
            "why_visible": f"Its live manifest explicitly supports {protocol_id} v{protocol_version}, and its files and hashes passed the pack contract.",
            "plain_language_status": (
                "Available for software demonstration only; it cannot arm participant acquisition."
                if scientific_status == "DEMO_ONLY"
                else "Available for review. Final acquisition eligibility remains governed by the session lock."
            ),
        }

    def _master_candidate(
        self,
        row: Mapping[str, Any],
        *,
        protocol_id: str,
        accepts_master: bool,
    ) -> dict[str, Any]:
        stimulus_id = str(row.get("stimulus_id") or "UNNAMED_MASTER")
        candidate_id = f"master::{stimulus_id}"
        reasons: list[str] = []
        tags = row.get("tags")
        if not isinstance(tags, list) or MASTER_MEDIA_TAG not in tags:
            reasons.append(f"it is not explicitly tagged {MASTER_MEDIA_TAG}")
        if not accepts_master:
            reasons.append(f"{protocol_id} does not accept a generic PRAYCG master-media input")
        if row.get("active_for_selection") is False:
            reasons.append("its registry row is inactive")
        if str(row.get("validation_status") or "") not in ACCEPTED_MASTER_VALIDATION:
            reasons.append("its recorded master-media validation status is not accepted")
        folder_text = str(row.get("folder") or "").strip()
        master_text = str(row.get("master_mp4") or "").strip()
        if not folder_text:
            reasons.append("its registry row has no folder")
        if not master_text:
            reasons.append("its registry row has no master_mp4")
        if reasons:
            return _blocked_candidate(candidate_id, stimulus_id, "MASTER_PRAYCG_MEDIA", reasons)
        folder = Path(folder_text).expanduser().resolve(strict=False)
        master = Path(master_text).expanduser().resolve(strict=False)
        if not folder.is_dir() or folder.is_symlink():
            reasons.append("its folder is missing or is a symbolic link")
        try:
            valid_master_file = (
                master.is_file()
                and not master.is_symlink()
                and master.suffix.casefold() == ".mp4"
                and master.stat().st_size > 0
                and _has_mp4_file_type_box(master)
            )
        except OSError:
            valid_master_file = False
        if not valid_master_file:
            reasons.append("its master is not a non-empty, regular MP4 file with an ISO-BMFF file-type header")
        if not _within(master, folder):
            reasons.append("its master MP4 is outside the declared stimulus folder")
        recorded_hash = str(row.get("sha256") or "")
        if not HEX64.fullmatch(recorded_hash):
            reasons.append("its registry row has no valid lowercase SHA-256 identity")
        elif master.is_file():
            try:
                if sha256_file(master) != recorded_hash:
                    reasons.append("its master MP4 hash no longer matches the registry")
            except OSError:
                reasons.append("its master MP4 could not be read for hash verification")
        if reasons:
            return _blocked_candidate(candidate_id, stimulus_id, "MASTER_PRAYCG_MEDIA", reasons)
        return {
            "node_type": "stimulus",
            "candidate_id": candidate_id,
            "display_name": stimulus_id,
            "source_kind": "MASTER_PRAYCG_MEDIA",
            "source_path": str(folder),
            "master_mp4": str(master),
            "master_sha256": recorded_hash,
            "scientific_status": "PREPARATION_INPUT_ONLY",
            "validation_status": str(row.get("validation_status")),
            "selection_allowed": True,
            "participant_acquisition_eligible": False,
            "status": "AVAILABLE_FOR_PREPARATION",
            "why_visible": f"It has the exact {MASTER_MEDIA_TAG} tag and a hash-verified MP4 accepted as input by {protocol_id}.",
            "plain_language_status": "Select this folder to prefill MediaPrep. Prepared derivatives still require their own validation and session lock.",
        }

    @staticmethod
    def _read_registry(registry_path: Path | None) -> tuple[dict[str, Any], list[str]]:
        if registry_path is None:
            return {"stimuli": [], "packs": []}, []
        path = Path(registry_path).expanduser().resolve(strict=False)
        if not path.is_file():
            return {"stimuli": [], "packs": []}, [f"The installed stimulus registry does not exist: {path}"]
        try:
            payload = json.loads(path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            return {"stimuli": [], "packs": []}, [f"The installed stimulus registry cannot be read: {exc}"]
        if not isinstance(payload, dict):
            return {"stimuli": [], "packs": []}, ["The installed stimulus registry is not a JSON object."]
        errors: list[str] = []
        for key in ("stimuli", "packs"):
            if not isinstance(payload.get(key, []), list):
                errors.append(f"The installed stimulus registry has a malformed {key} collection.")
                payload[key] = []
        return payload, errors

    @staticmethod
    def _stimulus_tree(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
        labels = {
            "BUNDLED_SAMPLE_PACK": "Bundled Sample Packs",
            "INSTALLED_PACK": "Installed Stimulus Packs",
            "MASTER_PRAYCG_MEDIA": "Master PRAYCG Stimulus Media",
        }
        folders: list[dict[str, Any]] = []
        nodes: list[dict[str, Any]] = []
        present = {str(row.get("source_kind")) for row in candidates}
        for source_kind in labels:
            if source_kind in present:
                folders.append(
                    {
                        "node_type": "folder",
                        "node_id": f"stimulus-folder::{_node_fragment(source_kind)}",
                        "parent_id": "",
                        "display_name": labels[source_kind],
                    }
                )
        for row in candidates:
            value = dict(row)
            value["node_id"] = str(value["candidate_id"])
            value["parent_id"] = f"stimulus-folder::{_node_fragment(str(value['source_kind']))}"
            nodes.append(value)
        nodes.sort(key=lambda row: (str(row["parent_id"]), str(row["display_name"]).casefold()))
        return folders + nodes

    def resolve_locked_workflow(
        self,
        lock_path: Path,
        *,
        stimulus_registry_path: Path | None = None,
    ) -> dict[str, Any]:
        """Return only stimulus/prep choices compatible with a live protocol lock."""
        catalog_check = self.catalog_validation()
        if catalog_check["status"] != "PASS":
            return {
                "schema": MODEL_SCHEMA,
                "status": "BLOCKED",
                "reasons": catalog_check["errors"],
                "stimulus_nodes": [],
                "prep_engines": [],
                "plain_language": "The next tab remains empty because the package's workflow catalogs do not agree.",
            }
        try:
            lock = validate_protocol_lock(Path(lock_path), self.atlas_root)
        except (FileNotFoundError, ValueError) as exc:
            return {
                "schema": MODEL_SCHEMA,
                "status": "BLOCKED",
                "reasons": [str(exc)],
                "stimulus_nodes": [],
                "prep_engines": [],
                "plain_language": "Choose and lock one protocol before selecting or preparing a stimulus.",
            }
        protocol_id, protocol_version = _identity(lock.get("protocol_id"), lock.get("protocol_version"))
        flow = self._flow_map().get((protocol_id, protocol_version))
        if not flow:
            return {
                "schema": MODEL_SCHEMA,
                "status": "BLOCKED",
                "reasons": [f"No governed stimulus workflow exists for {protocol_id} v{protocol_version}."],
                "stimulus_nodes": [],
                "prep_engines": [],
            }
        try:
            protocol_catalog = self._protocol_catalog_row(protocol_id, protocol_version)
            prep_engines = self._engine_rows(flow)
            stimulus_catalog = load_catalog(self.stimulus_tool_root)
        except (WorkflowSelectionError, StimulusContractError) as exc:
            return {
                "schema": MODEL_SCHEMA,
                "status": "BLOCKED",
                "reasons": [str(exc)],
                "stimulus_nodes": [],
                "prep_engines": [],
            }
        expected_asset_keys = [str(value) for value in protocol_catalog.get("expected_asset_keys", [])]
        is_self_contained_atlas = protocol_catalog.get("catalog_kind") in {"MATURE_ENDPOINT_ATLAS", "PUBLIC_DATASET_EXPANSION"}
        compatible: list[dict[str, Any]] = []
        excluded: list[dict[str, Any]] = []

        # Bundled samples are first-class rows.  They do not need to be copied or
        # opened through a secondary menu merely to be seen and inspected.
        for entry in ([] if is_self_contained_atlas else stimulus_catalog.get("packs", [])):
            if not isinstance(entry, dict):
                continue
            candidate = self._pack_candidate(
                root=catalog_pack_root(entry, self.stimulus_tool_root),
                source_kind="BUNDLED_SAMPLE_PACK",
                protocol_id=protocol_id,
                protocol_version=protocol_version,
                expected_asset_keys=expected_asset_keys,
                catalog_row=entry,
            )
            (compatible if candidate.get("selection_allowed") else excluded).append(candidate)

        registry, registry_errors = self._read_registry(stimulus_registry_path)
        for row in ([] if is_self_contained_atlas else registry.get("packs", [])):
            if not isinstance(row, dict):
                continue
            candidate = self._pack_candidate(
                root=Path(str(row.get("path") or "")),
                source_kind="INSTALLED_PACK",
                protocol_id=protocol_id,
                protocol_version=protocol_version,
                expected_asset_keys=expected_asset_keys,
                registry_row=row,
            )
            (compatible if candidate.get("selection_allowed") else excluded).append(candidate)

        legacy_rows = [row for row in registry.get("stimuli", []) if isinstance(row, dict)]
        duplicate_master_ids = {
            str(row.get("stimulus_id") or "")
            for row in legacy_rows
            if str(row.get("stimulus_id") or "")
            and sum(1 for other in legacy_rows if str(other.get("stimulus_id") or "") == str(row.get("stimulus_id") or "")) > 1
        }
        for row in ([] if is_self_contained_atlas else legacy_rows):
            stimulus_id = str(row.get("stimulus_id") or "")
            if stimulus_id in duplicate_master_ids:
                candidate = _blocked_candidate(
                    f"master::{stimulus_id}", stimulus_id, "MASTER_PRAYCG_MEDIA",
                    ["its stimulus_id is duplicated in the registry, so selection would be ambiguous"],
                )
            else:
                candidate = self._master_candidate(
                    row,
                    protocol_id=protocol_id,
                    accepts_master=bool(flow.get("accepts_master_media_tag")),
                )
            (compatible if candidate.get("selection_allowed") else excluded).append(candidate)

        # A participant-facing session must never infer eligibility merely from
        # visibility.  The existing combined session lock remains authoritative.
        direct_choices = [row for row in prep_engines if row.get("direct_launch_allowed")]
        preferred_direct = next(
            (row["id"] for row in direct_choices if row.get("invocation_mode") == "STANDALONE_PACK_TEMPLATE"),
            None,
        )
        if is_self_contained_atlas:
            operator_asset_keys = [str(value) for value in protocol_catalog.get("operator_asset_keys", [])]
            launch_action = {
                "action_id": "choose_protocol_files" if operator_asset_keys else "no_external_stimulus_required",
                "label": "Choose Required Protocol Files" if operator_asset_keys else "No External Files Required",
                "prefill_protocol_id": protocol_id,
                "enabled_when": "the operator is preparing the locked Atlas protocol" if operator_asset_keys else "never",
            }
        elif flow.get("preparation_mode") == "NATIVE_MEDIAPREP":
            launch_action = {
                "action_id": "launch_mediaprep",
                "label": "Launch MediaPrep",
                "tool_config_key": "mediaprep_gui",
                "prefill_protocol_id": protocol_id,
                "enabled_when": "a compatible MASTER_PRAYCG_STIMULUS_MEDIA row or ready pack is selected",
            }
        else:
            launch_action = {
                "action_id": "launch_stimulus_forge",
                "label": "Launch Stimulus Forge",
                "prefill_engine_id": preferred_direct,
                "prefill_protocol_id": protocol_id,
                "enabled_when": "a direct engine remains available for the locked protocol",
            }
        status = "READY" if is_self_contained_atlas or (compatible and direct_choices) else "BLOCKED"
        reasons = list(registry_errors)
        if not compatible and not is_self_contained_atlas:
            reasons.append("No compatible, live-validated stimulus or preparation input is available.")
        if not direct_choices and not is_self_contained_atlas:
            reasons.append("No directly invocable preparation or validation engine is available.")
        return {
            "schema": MODEL_SCHEMA,
            "status": status if not registry_errors else ("CAUTION" if status == "READY" else status),
            "protocol_lock_status": "PASS",
            "protocol": {
                "protocol_id": protocol_id,
                "protocol_version": protocol_version,
                "display_name": lock.get("display_name"),
                "module_family": lock.get("module_family"),
                "manifest_sha256": lock.get("manifest_sha256"),
            },
            "workflow": {
                "navigation_group": flow.get("navigation_group"),
                "preparation_mode": flow.get("preparation_mode"),
                "accepts_master_media_tag": flow.get("accepts_master_media_tag"),
                "required_asset_keys": expected_asset_keys,
                "plain_language": flow.get("plain_language"),
            },
            "stimulus_navigation_mode": "TREE_FILE_NAVIGATION",
            "stimulus_nodes": self._stimulus_tree(compatible),
            "compatible_stimuli": compatible,
            "excluded_stimuli": excluded,
            "prep_engines": prep_engines,
            "recommended_launch_action": launch_action,
            "reasons": reasons,
            "plain_language": (
                (
                    f"{lock.get('display_name')} is locked. Use the Atlas asset-folder control for its reviewed local "
                    "files; exact paths and hashes are validated again when the session lock is created."
                    if protocol_catalog.get("operator_asset_keys")
                    else f"{lock.get('display_name')} is locked. Its task is runner-generated and requires no external stimulus pack."
                )
                if is_self_contained_atlas
                else (
                    f"{lock.get('display_name')} is locked. Only assets and preparation tools that explicitly support "
                    f"{protocol_id} v{protocol_version} are shown. Visibility never bypasses the session lock."
                )
            ),
            "authority_boundary": (
                "This result is navigation and prefill evidence only. It cannot arm hardware, launch a runner, "
                "promote DEMO_ONLY media, or certify scientific suitability."
            ),
        }

    def preflight_candidate_for_locked_protocol(
        self,
        lock_path: Path,
        candidate_id: str,
        *,
        stimulus_registry_path: Path | None = None,
    ) -> dict[str, Any]:
        """Re-resolve a stale UI selection and fail closed if it disappeared."""
        workflow = self.resolve_locked_workflow(lock_path, stimulus_registry_path=stimulus_registry_path)
        if workflow.get("status") not in {"READY", "CAUTION"}:
            return {
                "status": "BLOCKED",
                "candidate_id": candidate_id,
                "reasons": list(workflow.get("reasons") or ["The locked workflow is not ready."]),
            }
        matches = [row for row in workflow.get("compatible_stimuli", []) if row.get("candidate_id") == candidate_id]
        if len(matches) != 1 or not matches[0].get("selection_allowed"):
            return {
                "status": "BLOCKED",
                "candidate_id": candidate_id,
                "reasons": ["The requested stimulus is inactive, unvalidated, incompatible, missing, or ambiguous for the current lock."],
            }
        return {
            "status": "PASS",
            "candidate_id": candidate_id,
            "candidate": matches[0],
            "authority_boundary": "PASS allows UI selection/prefill only; the combined session lock remains authoritative.",
        }


__all__ = [
    "LEGACY_MASTER_MIGRATION_SCHEMA",
    "MASTER_MEDIA_TAG",
    "MODEL_SCHEMA",
    "ProtocolStimulusWorkflowModel",
    "WorkflowSelectionError",
    "migrate_legacy_master_registry",
]
