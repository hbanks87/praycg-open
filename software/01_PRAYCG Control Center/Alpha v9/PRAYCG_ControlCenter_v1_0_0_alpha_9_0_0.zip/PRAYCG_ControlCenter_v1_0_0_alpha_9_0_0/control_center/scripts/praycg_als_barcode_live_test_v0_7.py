#!/usr/bin/env python3
"""PRAYCG ALS Barcode Live Test v0.7.

Displays the PRAYCG2.2 long/short ALS barcode and optionally records one LSL channel
from a live stream to classify PASS / WEAK / CLIPPED / MISSING.

Default barcode:
  black 0.50 s -> white A 2.00 s -> black gap 0.50 s -> white B 0.75 s -> black post 1.00 s

This is a setup/QC tool. It is not a biological measurement endpoint.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


def _import_pylsl():
    try:
        from pylsl import StreamInlet, resolve_byprop, local_clock
        return StreamInlet, resolve_byprop, local_clock
    except Exception:
        return None, None, None


def robust_median(xs: List[float]) -> float:
    vals = sorted(x for x in xs if math.isfinite(x))
    if not vals:
        return float('nan')
    n = len(vals)
    return vals[n//2] if n % 2 else 0.5 * (vals[n//2-1] + vals[n//2])


def percentile(xs: List[float], q: float) -> float:
    vals = sorted(x for x in xs if math.isfinite(x))
    if not vals:
        return float('nan')
    idx = int(round((len(vals)-1) * q))
    return vals[max(0, min(idx, len(vals)-1))]


def stream_run_uuid(info: Any) -> str:
    try:
        return str(info.desc().child_value("run_uuid") or "")
    except Exception:
        return ""


def source_run_fragment(source_id: str) -> str:
    """Return the bridge's 12-hex run fragment when encoded in source_id."""
    matches = re.findall(r"(?:^|_)([0-9a-fA-F]{12})(?=_|$)", str(source_id or ""))
    return matches[-1].lower() if matches else ""


def select_run_bound_stream(streams: List[Any], run_uuid: str) -> Tuple[Optional[Any], str, List[Dict[str, str]]]:
    """Choose the one outlet belonging to the current Control Center session."""
    identities: List[Dict[str, str]] = []
    active = str(run_uuid or "").strip()
    fragment = active.replace("-", "")[:12]
    matching: List[Any] = []
    for info in streams:
        try:
            source_id = str(info.source_id() or "")
        except Exception:
            source_id = ""
        candidate_run = stream_run_uuid(info)
        identities.append({
            "source_id": source_id,
            "run_uuid": candidate_run,
            "run_uuid_fragment": source_run_fragment(source_id),
        })
        if active and (candidate_run == active or (fragment and fragment in source_id.replace("-", ""))):
            matching.append(info)
    if active:
        if len(matching) == 1:
            return matching[0], "CURRENT_SESSION", identities
        if len(matching) > 1:
            return None, "AMBIGUOUS_CURRENT_SESSION", identities
        if streams:
            return None, "WRONG_SESSION", identities
        return None, "NOT_FOUND", identities
    if len(streams) == 1:
        return streams[0], "UNBOUND_SINGLE_OUTLET", identities
    if len(streams) > 1:
        return None, "AMBIGUOUS_UNBOUND", identities
    return None, "NOT_FOUND", identities


class LSLRecorder:
    def __init__(
        self,
        stream_name: str,
        channel_index_1based: int,
        duration_sec: float,
        out_dir: Path,
        run_uuid: str = "",
        resolve_timeout_sec: float = 15.0,
    ):
        self.stream_name = stream_name
        self.channel_index_1based = channel_index_1based
        self.duration_sec = duration_sec
        self.out_dir = out_dir
        self.run_uuid = str(run_uuid or "").strip()
        self.resolve_timeout_sec = max(0.1, min(float(resolve_timeout_sec), 60.0))
        self.samples: List[Tuple[float, float]] = []
        self.error: Optional[str] = None
        self.started_lsl: Optional[float] = None
        self.source_id = ""
        self.source_run_uuid = ""
        self.selection_status = "NOT_PREPARED"
        self.candidate_identities: List[Dict[str, str]] = []
        self._inlet: Any = None
        self._local_clock: Any = None
        self._start = threading.Event()

    def prepare(self) -> bool:
        StreamInlet, resolve_byprop, local_clock = _import_pylsl()
        if StreamInlet is None:
            self.error = 'pylsl not installed; no ALS stream can be checked.'
            return False
        try:
            # An old LSL advertisement can remain visible briefly after its
            # bridge is stopped.  Keep resolving for the requested session
            # until the startup window expires instead of immediately treating
            # that transient advertisement as a permanent session mismatch.
            deadline = time.monotonic() + self.resolve_timeout_sec
            info: Optional[Any] = None
            selection = "NOT_FOUND"
            identities: List[Dict[str, str]] = []
            while True:
                remaining = max(0.0, deadline - time.monotonic())
                wait = max(0.05, min(1.0, remaining))
                streams = resolve_byprop('name', self.stream_name, timeout=wait)
                info, selection, identities = select_run_bound_stream(list(streams), self.run_uuid)
                if info is not None or selection.startswith("AMBIGUOUS"):
                    break
                if not self.run_uuid or remaining <= 0.0:
                    break
                time.sleep(min(0.20, max(0.0, deadline - time.monotonic())))
            self.selection_status = selection
            self.candidate_identities = identities
            if info is None:
                if selection == "WRONG_SESSION":
                    observed = ", ".join(
                        identity.get("run_uuid") or identity.get("run_uuid_fragment") or "not declared"
                        for identity in identities
                    )
                    self.error = (
                        f"ALS outlet {self.stream_name!r} is healthy but belongs to an earlier equipment session "
                        f"({observed}). The barcode window is not competing for the sensor; the older PRAYCG bridge "
                        "still owns the board. Close this window and start the barcode test from Control Center; "
                        "Alpha 8.5.4 will offer a guarded stop-and-restart for the current session."
                    )
                elif selection.startswith("AMBIGUOUS"):
                    self.error = f"Multiple ALS outlets match {self.stream_name!r}; stop duplicate bridges before testing."
                else:
                    self.error = f'LSL stream not found: {self.stream_name}'
                return False
            self.source_id = str(info.source_id() or "")
            self.source_run_uuid = stream_run_uuid(info)
            self._inlet = StreamInlet(info, max_buflen=10, recover=True)
            try:
                self._inlet.open_stream(timeout=3.0)
            except TypeError:
                self._inlet.open_stream()
            self._local_clock = local_clock
            # Empty any buffered samples before the first displayed barcode
            # segment so the analysis clock begins with the controlled pulse.
            while True:
                chunk, _timestamps = self._inlet.pull_chunk(timeout=0.0, max_samples=512)
                if not chunk:
                    break
            return True
        except Exception as exc:
            self.error = repr(exc)
            return False

    def start_recording(self) -> None:
        if self.started_lsl is None and self._local_clock is not None:
            self.started_lsl = float(self._local_clock())
            self._start.set()

    def run(self) -> None:
        if self._inlet is None or self._local_clock is None:
            self.error = self.error or "ALS inlet was not prepared."
            return
        try:
            if not self._start.wait(timeout=15.0):
                self.error = "Barcode display did not signal the recording start."
                return
            deadline = float(self.started_lsl or self._local_clock()) + self.duration_sec
            while self._local_clock() < deadline:
                sample, ts = self._inlet.pull_sample(timeout=0.05)
                if sample is None:
                    continue
                if self.channel_index_1based == -1:
                    idx = len(sample) - 1
                else:
                    idx = max(0, min(len(sample)-1, self.channel_index_1based - 1))
                try:
                    val = float(sample[idx])
                except Exception:
                    val = float('nan')
                self.samples.append((float(ts), val))
        except Exception as exc:
            self.error = repr(exc)
        finally:
            try:
                self._inlet.close_stream()
            except Exception:
                pass


def classify_samples(samples: List[Tuple[float, float]], design: Dict[str, float], started_lsl: Optional[float] = None) -> Dict[str, Any]:
    if not samples:
        return {'status': 'NO_DATA', 'reason': 'No LSL samples were recorded.'}
    t0 = float(started_lsl) if started_lsl is not None else samples[0][0]
    times = [t - t0 for t, _ in samples]
    vals = [v for _, v in samples]
    total = design['black_pre'] + design['white_a'] + design['black_gap'] + design['white_b'] + design['black_post']
    def seg(start: float, end: float) -> List[float]:
        return [v for t, v in zip(times, vals) if start <= t < end and math.isfinite(v)]
    b1 = seg(0, design['black_pre'])
    a = seg(design['black_pre'], design['black_pre'] + design['white_a'])
    gap_start = design['black_pre'] + design['white_a']
    g = seg(gap_start, gap_start + design['black_gap'])
    b_start = gap_start + design['black_gap']
    b = seg(b_start, b_start + design['white_b'])
    post = seg(b_start + design['white_b'], total)
    med_b1 = robust_median(b1)
    med_a = robust_median(a)
    med_g = robust_median(g)
    med_b = robust_median(b)
    med_post = robust_median(post)
    finite = [x for x in vals if math.isfinite(x)]
    span = (max(finite) - min(finite)) if finite else float('nan')
    black_ref = robust_median(b1 + g + post)
    white_ref = robust_median(a + b)
    amp = white_ref - black_ref if math.isfinite(white_ref) and math.isfinite(black_ref) else float('nan')
    p99 = percentile(finite, .99) if finite else float('nan')
    p01 = percentile(finite, .01) if finite else float('nan')
    clipped = False
    if finite and span > 0:
        near_top = sum(1 for x in finite if x >= p99 - 1e-12) / len(finite)
        clipped = near_top > 0.95
    polarity = 1.0 if not math.isfinite(amp) or amp >= 0 else -1.0
    score = 0.0
    for w in [(med_a, med_b1), (med_a, med_g), (med_b, med_g), (med_b, med_post)]:
        if all(math.isfinite(x) for x in w):
            score += max(0.0, polarity * (w[0] - w[1]))
    if clipped:
        status = 'CLIPPED'
    elif math.isfinite(amp) and abs(amp) > max(1e-6, 0.10 * max(abs(span), 1e-6)) and score > 0:
        status = 'PASS'
    elif math.isfinite(amp) and abs(amp) > 0:
        status = 'WEAK'
    else:
        status = 'MISSING'
    return {
        'status': status,
        'n_samples': len(samples),
        'span': span,
        'amplitude_white_minus_black': amp,
        'observed_polarity': 'higher_on_white' if amp >= 0 else 'lower_on_white',
        'median_black_pre': med_b1,
        'median_white_a': med_a,
        'median_gap': med_g,
        'median_white_b': med_b,
        'median_post': med_post,
        'clipped': clipped,
        'barcode_score_raw': score,
        'duration_recorded_sec': times[-1] - times[0] if len(times) > 1 else 0,
    }


def display_tk_barcode(args: argparse.Namespace, design: Dict[str, float], on_start: Optional[Any] = None) -> None:
    import tkinter as tk
    root = tk.Tk()
    root.title('PRAYCG ALS Barcode Live Test v0.7')
    if args.fullscreen:
        root.attributes('-fullscreen', True)
    else:
        root.geometry('900x600')
    root.configure(bg='black')
    w = root.winfo_screenwidth()
    h = root.winfo_screenheight()
    canvas = tk.Canvas(root, bg='black', highlightthickness=0)
    canvas.pack(fill='both', expand=True)
    size = int(args.size_px)
    margin = int(args.margin_px)
    pos = args.pulse_position.lower()
    if pos == 'fullscreen':
        rect = (0, 0, w, h)
    else:
        x1 = margin if 'left' in pos else w - margin - size
        y1 = margin if ('upper' in pos or 'top' in pos) else h - margin - size
        rect = (x1, y1, x1 + size, y1 + size)
    schedule = [
        ('black_pre', False, design['black_pre']),
        ('white_a', True, design['white_a']),
        ('black_gap', False, design['black_gap']),
        ('white_b', True, design['white_b']),
        ('black_post', False, design['black_post']),
    ]
    def show_segment(i: int = 0):
        canvas.delete('all')
        if i >= len(schedule):
            root.destroy()
            return
        name, white, dur = schedule[i]
        if white:
            canvas.create_rectangle(*rect, fill='white', outline='white')
        canvas.create_text(w/2, 40, fill='gray80', text=f'ALS barcode test: {name} ({dur:.2f}s)')
        if bool(getattr(args, 'display_only', False)):
            canvas.create_text(
                w/2,
                85,
                fill='#ffb347',
                text='BENCH DISPLAY ONLY — NO ALS SENSOR DATA — DOES NOT VALIDATE PLACEMENT',
                font=('Segoe UI', 14, 'bold'),
            )
        if i == 0 and on_start is not None:
            root.update_idletasks()
            on_start()
        root.after(int(dur * 1000), lambda: show_segment(i+1))
    root.bind('<Escape>', lambda e: root.destroy())
    root.after(250, show_segment)
    root.mainloop()


def show_message(title: str, message: str, *, error: bool = False) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk(); root.withdraw()
        (messagebox.showerror if error else messagebox.showinfo)(title, message, parent=root)
        root.destroy()
    except Exception:
        pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--stream-name', default='obci_eeg1')
    ap.add_argument('--channel-index', type=int, default=-1, help='1-based channel index; -1 = last channel')
    ap.add_argument('--run-uuid', default='', help='Optional Control Center run UUID for evidence binding')
    ap.add_argument('--hardware-profile-sha256', default='', help='Optional reviewed hardware-profile identity')
    ap.add_argument('--out-dir', default='als_pulse_tests')
    ap.add_argument('--fullscreen', action='store_true')
    ap.add_argument('--pulse-position', default='lower_right', choices=['lower_right','lower_left','upper_right','upper_left','fullscreen'])
    ap.add_argument('--size-px', type=int, default=180)
    ap.add_argument('--margin-px', type=int, default=40)
    ap.add_argument('--black-pre-sec', type=float, default=0.50)
    ap.add_argument('--white-a-sec', type=float, default=2.00)
    ap.add_argument('--black-gap-sec', type=float, default=0.50)
    ap.add_argument('--white-b-sec', type=float, default=0.75)
    ap.add_argument('--black-post-sec', type=float, default=1.00)
    ap.add_argument(
        '--display-only',
        action='store_true',
        help='Display the barcode without resolving or recording ALS; writes BENCH_DISPLAY_ONLY evidence only',
    )
    ap.add_argument(
        '--resolve-timeout-sec',
        type=float,
        default=15.0,
        help='Seconds to wait for the current-session ALS outlet after a guarded bridge restart',
    )
    args = ap.parse_args()
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    design = {'black_pre': args.black_pre_sec, 'white_a': args.white_a_sec, 'black_gap': args.black_gap_sec, 'white_b': args.white_b_sec, 'black_post': args.black_post_sec}
    total = sum(design.values()) + 1.0
    rec = LSLRecorder(
        args.stream_name,
        args.channel_index,
        total,
        out_dir,
        args.run_uuid,
        args.resolve_timeout_sec,
    )
    if args.display_only:
        rec.selection_status = 'BENCH_DISPLAY_ONLY'
        display_tk_barcode(args, design)
        result = {
            'status': 'BENCH_DISPLAY_ONLY',
            'reason': (
                'The barcode display sequence ran without an ALS sensor or OpenBCI bridge. '
                'This exercises the display/UI only and does not validate sensor placement or satisfy readiness.'
            ),
        }
    elif rec.prepare():
        th = threading.Thread(target=rec.run, daemon=True)
        th.start()
        display_tk_barcode(args, design, rec.start_recording)
        th.join(timeout=max(0.1, total + 1.0))
        result = classify_samples(rec.samples, design, rec.started_lsl)
        if result.get('status') == 'NO_DATA' and rec.error:
            result['reason'] = rec.error
    else:
        blocked_status = {
            'WRONG_SESSION': 'SESSION_MISMATCH',
            'AMBIGUOUS_CURRENT_SESSION': 'AMBIGUOUS_STREAM',
            'AMBIGUOUS_UNBOUND': 'AMBIGUOUS_STREAM',
            'NOT_FOUND': 'NO_STREAM',
        }.get(rec.selection_status, 'INLET_ERROR')
        result = {'status': blocked_status, 'reason': rec.error or 'ALS stream could not be prepared.'}
    result.update({
        'schema': 'PRAYCG_ALS_Barcode_Live_Test_v0_7',
        'created_utc': datetime.utcnow().isoformat() + 'Z',
        'stream_name': args.stream_name,
        'channel_index_1based': args.channel_index,
        'run_uuid': args.run_uuid or None,
        'hardware_profile_sha256': args.hardware_profile_sha256 or None,
        'source_id': rec.source_id or None,
        'source_run_uuid': rec.source_run_uuid or None,
        'stream_selection_status': rec.selection_status,
        'candidate_identities': rec.candidate_identities,
        'resolve_timeout_sec': rec.resolve_timeout_sec,
        'bench_display_only': bool(args.display_only),
        'physical_als_evidence': not bool(args.display_only),
        'display_mode': 'tkinter_fullscreen' if args.fullscreen else 'tkinter_windowed',
        'pulse_position': args.pulse_position,
        'size_px': args.size_px,
        'margin_px': args.margin_px,
        'design': design,
        'lsl_error': rec.error,
        'boundary': (
            'BENCH_DISPLAY_ONLY contains no ALS samples and cannot satisfy placement or acquisition readiness.'
            if args.display_only
            else 'ALS barcode validates physical display timing only; it is not a biological endpoint.'
        )
    })
    path = out_dir / f'als_barcode_live_test_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
    path.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
    print(f'Wrote: {path}')
    if result.get('status') == 'BENCH_DISPLAY_ONLY':
        show_message(
            'ALS barcode: BENCH DISPLAY ONLY',
            f"The visual barcode sequence completed without ALS hardware.\n\n"
            f"This does not validate placement and cannot satisfy readiness.\n\nEvidence saved to:\n{path}",
        )
    elif result.get('status') in {'PASS', 'WEAK'}:
        show_message(
            f"ALS barcode test: {result['status']}",
            f"Samples: {result.get('n_samples', 0)}\n"
            f"White-minus-black response: {result.get('amplitude_white_minus_black')}\n\n"
            f"Evidence saved to:\n{path}",
        )
    else:
        show_message(
            f"ALS barcode test: {result.get('status', 'FAILED')}",
            f"{result.get('reason') or rec.error or 'The controlled light response was not detected.'}\n\n"
            f"Stream selection: {rec.selection_status}\nEvidence saved to:\n{path}",
            error=True,
        )
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
