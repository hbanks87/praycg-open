#!/usr/bin/env python3
"""PRAYCG Control Center v1.0.0-alpha.4 dependency-aware v1.6.1 chain launcher."""
from __future__ import annotations

import argparse
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

ROOT = Path(__file__).resolve().parents[2]
TARGET = ROOT / "tools" / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_chain_runner_v1_6_1.py"


class ChainLauncher(tk.Tk):
    def __init__(self, analysis_folder: str = "", output_folder: str = "", run_label: str = "", profile: str = "human_translation") -> None:
        super().__init__()
        self.title("PRAYCG Full Analysis Chain v1.6.1")
        self.geometry("920x620")
        self.proc: subprocess.Popen | None = None
        self.output_dir = ""
        self.messages: queue.Queue[str] = queue.Queue()
        self.analysis_var = tk.StringVar(value=analysis_folder)
        self.output_var = tk.StringVar(value=output_folder)
        self.label_var = tk.StringVar(value=run_label or "PRAYCG_Run")
        self.profile_var = tk.StringVar(value=profile or "human_translation")
        self.status_var = tk.StringVar(value="Core output prefilled; review it, then click Run Full Chain." if analysis_folder else "Select a completed Master Suite v1.6.0 output folder.")
        self._build()
        self.after(100, self._drain_messages)

    def _build(self) -> None:
        outer = ttk.Frame(self, padding=12); outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Master Comprehensive Chained Analysis v1.6.1", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        ttk.Label(outer, text="Runs modules only when their prerequisites exist and records PASS, primary-gate failure, missing input, protocol-not-applicable, exploratory-only, and software-error states separately.", wraplength=870).pack(anchor="w", pady=(2, 10))
        self._path_row(outer, "Core v1.6.0 output", self.analysis_var, self._pick_analysis)
        self._path_row(outer, "Optional output folder", self.output_var, self._pick_output)
        fields = ttk.Frame(outer); fields.pack(fill="x", pady=5)
        ttk.Label(fields, text="Run label", width=22).pack(side="left")
        ttk.Entry(fields, textvariable=self.label_var, width=32).pack(side="left", padx=4)
        ttk.Label(fields, text="NUPI profile").pack(side="left", padx=(14, 4))
        ttk.Combobox(fields, textvariable=self.profile_var, values=("human_translation", "biological_translation"), state="readonly", width=24).pack(side="left")
        buttons = ttk.Frame(outer); buttons.pack(fill="x", pady=8)
        ttk.Button(buttons, text="Run Full Chain", command=self.run_chain).pack(side="left")
        ttk.Button(buttons, text="Stop", command=self.stop).pack(side="left", padx=6)
        ttk.Button(buttons, text="Open Output", command=self.open_output).pack(side="left")
        ttk.Label(outer, textvariable=self.status_var).pack(anchor="w", pady=(0, 6))
        self.log = tk.Text(outer, wrap="word", height=25); self.log.pack(fill="both", expand=True)

    def _path_row(self, parent, label, variable, command) -> None:
        row = ttk.Frame(parent); row.pack(fill="x", pady=3)
        ttk.Label(row, text=label, width=22).pack(side="left")
        ttk.Entry(row, textvariable=variable).pack(side="left", fill="x", expand=True, padx=4)
        ttk.Button(row, text="Browse", command=command).pack(side="left")

    def _pick_analysis(self) -> None:
        value = filedialog.askdirectory(title="Select completed Master Suite v1.6.0 output")
        if value: self.analysis_var.set(value)

    def _pick_output(self) -> None:
        value = filedialog.askdirectory(title="Select a new/empty output location")
        if value: self.output_var.set(value)

    def run_chain(self) -> None:
        if self.proc and self.proc.poll() is None:
            return messagebox.showinfo("Already running", "The analysis chain is already running.")
        analysis = Path(self.analysis_var.get().strip()).expanduser()
        canonical = analysis / "tables" / "praycg_analysis_frame_v1_6_0.csv"
        if not TARGET.is_file(): return messagebox.showerror("Runner missing", str(TARGET))
        if not canonical.is_file(): return messagebox.showerror("Not a v1.6.0 output", f"Missing canonical frame:\n{canonical}")
        cmd = [sys.executable, str(TARGET), "--analysis-folder", str(analysis), "--run-label", self.label_var.get().strip() or "PRAYCG_Run", "--profile", self.profile_var.get()]
        requested = self.output_var.get().strip()
        if requested:
            out = Path(requested).expanduser()
            if out.exists() and any(out.iterdir()):
                return messagebox.showerror("Output not empty", "Choose a new or empty output folder so an earlier result cannot be overwritten.")
            cmd += ["--out-dir", str(out)]
            self.output_dir = str(out)
        else:
            self.output_dir = ""
        self.log.delete("1.0", "end"); self.log.insert("end", ">>> " + subprocess.list2cmdline(cmd) + "\n\n")
        self.status_var.set("Running dependency-aware chain...")
        threading.Thread(target=self._worker, args=(cmd,), daemon=True).start()

    def _worker(self, cmd) -> None:
        env = os.environ.copy(); env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
        self.proc = subprocess.Popen(cmd, cwd=str(TARGET.parent), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        for line in self.proc.stdout or []:
            self.messages.put(line)
            if line.startswith("CHAIN_OUTPUT=") and not self.output_dir:
                self.output_dir = line.split("=", 1)[1].strip()
        rc = self.proc.wait(); self.messages.put(f"\nChain exited with code {rc}.\n"); self.messages.put(f"__STATUS__{rc}")

    def _drain_messages(self) -> None:
        try:
            while True:
                item = self.messages.get_nowait()
                if item.startswith("__STATUS__"):
                    rc = int(item.removeprefix("__STATUS__")); self.status_var.set("Chain completed." if rc == 0 else f"Chain stopped or failed (exit {rc}).")
                else:
                    self.log.insert("end", item); self.log.see("end")
        except queue.Empty:
            pass
        self.after(100, self._drain_messages)

    def stop(self) -> None:
        if self.proc and self.proc.poll() is None:
            self.proc.terminate(); self.status_var.set("Stop requested...")

    def open_output(self) -> None:
        path = Path(self.output_dir) if self.output_dir else None
        if not path or not path.exists(): return messagebox.showinfo("No output yet", "Run the chain first or choose its output folder.")
        if sys.platform.startswith("win"): os.startfile(path)  # type: ignore[attr-defined]
        else: subprocess.Popen(["xdg-open", str(path)])


def main() -> None:
    parser = argparse.ArgumentParser(description="PRAYCG Control Center v1.0.0-alpha.4 chain GUI")
    parser.add_argument("--analysis-folder", default="")
    parser.add_argument("--out-dir", default="")
    parser.add_argument("--run-label", default="")
    parser.add_argument("--profile", default="human_translation", choices=("human_translation", "biological_translation"))
    args = parser.parse_args()
    ChainLauncher(args.analysis_folder, args.out_dir, args.run_label, args.profile).mainloop()


if __name__ == "__main__":
    main()
