#!/usr/bin/env python3
"""
PRAYCG Control Center v1.0.0-alpha.9.0.0 - Reproducible Study and Hardware Orchestration

A public-facing orchestration GUI for PRAYCG tools.
It launches existing tools as separate processes, manages stimulus/run folders,
checks LSL streams, and provides acquisition helper panels.

This is intentionally an orchestrator, not a monolithic replacement for MediaPrep,
PsychoPy, LabRecorder, BrainFlow, or the Master Comprehensive Suite.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import re
import secrets
import shutil
import shlex
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from praycg_active_context_v1_0 import (
    CONTEXT_SCHEMA,
    empty_context,
    readiness,
    resolution,
    resolve_analysis_outputs,
    resolve_raw_run,
    summarize_context,
)
from praycg_protocol_library_v2_0 import (
    FAMILY_ATLAS,
    FAMILY_NATIVE,
    atlas_asset_snapshot,
    atlas_runtime_plan,
    discover_protocol_modules,
    normalize_atlas_bindings,
    validate_protocol_lock,
    write_protocol_lock,
)
from praycg_protocol_stimulus_flow_v1_0 import (
    MASTER_MEDIA_TAG,
    ProtocolStimulusWorkflowModel,
    migrate_legacy_master_registry,
)

STUDY_WORKSPACE_DIR = Path(__file__).resolve().parents[2] / "tools" / "Study_Workspace_v0_1"
ANALYSIS_ORCHESTRATOR_DIR = Path(__file__).resolve().parents[2] / "tools" / "Analysis_Orchestrator_v0_1"
RESULTS_BUNDLE_DIR = Path(__file__).resolve().parents[2] / "tools" / "Results_Bundle_Builder_v0_1"
for _module_dir in (STUDY_WORKSPACE_DIR, ANALYSIS_ORCHESTRATOR_DIR, RESULTS_BUNDLE_DIR):
    if str(_module_dir) not in sys.path:
        sys.path.insert(0, str(_module_dir))

from praycg_study_workspace_v0_1 import (  # type: ignore
    WORKFLOW_LABELS,
    WORKFLOW_STAGES,
    add_post_hoc_supplement,
    bind_component as bind_workspace_component,
    create_workspace,
    load_workspace,
    next_action as workspace_next_action,
    read_active_pointer,
    record_analysis_outputs as workspace_record_analysis_outputs,
    record_run as workspace_record_run,
    save_workspace,
    set_workflow_stage,
    start_new_session,
    validate_workspace,
    workflow_summary,
    write_active_pointer,
)
from praycg_analysis_orchestrator_v0_1 import (  # type: ignore
    MODULE_CATEGORIES,
    build_analysis_plan,
    build_post_hoc_supplement,
    completion_record,
    execution_graph,
    lock_analysis_plan,
    preflight_registry,
    validate_plan_lock,
    validate_registry as validate_analysis_orchestration_registry,
)
from praycg_results_bundle_builder_v0_1 import (  # type: ignore
    build_results_bundle,
    record_local_review,
)

PLATFORM_CORE_DIR = Path(__file__).resolve().parents[2] / "platform_core"
if str(PLATFORM_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(PLATFORM_CORE_DIR))

STIMULUS_FORGE_DIR = Path(__file__).resolve().parents[2] / "tools" / "Stimulus_Forge_Library_v1_0"
if str(STIMULUS_FORGE_DIR) not in sys.path:
    sys.path.insert(0, str(STIMULUS_FORGE_DIR))

STIMULUS_CONTRACT_IMPORT_ERROR = ""
try:
    from praycg_stimulus_common_v1_0 import (  # type: ignore
        install_pack as install_stimulus_pack,
        validate_pack as validate_stimulus_pack,
        write_registry as write_stimulus_pack_registry,
    )
except Exception as exc:  # pragma: no cover - selection is conservatively blocked below
    STIMULUS_CONTRACT_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"
    install_stimulus_pack = None  # type: ignore[assignment]
    validate_stimulus_pack = None  # type: ignore[assignment]
    write_stimulus_pack_registry = None  # type: ignore[assignment]

HARDWARE_WORKFLOW_DIR = Path(__file__).resolve().parents[2] / "tools" / "Hardware_Workflow_v0_1"
if str(HARDWARE_WORKFLOW_DIR) not in sys.path:
    sys.path.insert(0, str(HARDWARE_WORKFLOW_DIR))

HARDWARE_WORKFLOW_IMPORT_ERROR = ""
try:
    from praycg_hardware_workflow_v0_1 import (  # type: ignore
        HardwareWorkflowModel,
        derive_launch_actions,
        lock_hardware_profile,
        review_hardware_profile_draft,
        validate_hardware_profile_lock,
    )
except Exception as exc:  # pragma: no cover - displayed in the Hardware tab
    HARDWARE_WORKFLOW_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"
    HardwareWorkflowModel = None  # type: ignore[assignment]
    derive_launch_actions = None  # type: ignore[assignment]
    lock_hardware_profile = None  # type: ignore[assignment]
    review_hardware_profile_draft = None  # type: ignore[assignment]
    validate_hardware_profile_lock = None  # type: ignore[assignment]

PLATFORM_CORE_IMPORT_ERROR = ""
try:
    from praycg_platform_core_v1_0_alpha_4 import (  # type: ignore
        active_acquisition_owner_activity,
        active_acquisition_owner_path,
        advance_session_gate,
        bind_active_acquisition_owner_lease,
        bind_authorized_runner_lease_process,
        build_hardware_profile,
        build_session_draft,
        build_session_lock,
        compile_protocol,
        finish_authorized_runner_lease,
        finish_active_acquisition_owner,
        claim_active_acquisition_owner,
        issue_authorized_runner_lease,
        load_json as load_platform_json,
        normalized_path_identity,
        paths_equivalent,
        process_start_identity,
        protocol_timeline,
        recover_superseded_terminal_owner,
        runtime_lock_reuse_reasons,
        runtime_runner_lease_activity,
        sha256_json as platform_sha256_json,
        validate_hardware_module,
        validate_hardware_profile_identity,
        validate_protocol,
        validate_session_lock_identity,
        write_json as write_platform_json,
    )
except Exception as exc:  # pragma: no cover - displayed as an operator-visible alpha limitation
    PLATFORM_CORE_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"
    active_acquisition_owner_activity = None  # type: ignore[assignment]
    active_acquisition_owner_path = None  # type: ignore[assignment]
    advance_session_gate = None  # type: ignore[assignment]
    bind_active_acquisition_owner_lease = None  # type: ignore[assignment]
    bind_authorized_runner_lease_process = None  # type: ignore[assignment]
    build_hardware_profile = None  # type: ignore[assignment]
    build_session_draft = None  # type: ignore[assignment]
    build_session_lock = None  # type: ignore[assignment]
    compile_protocol = None  # type: ignore[assignment]
    finish_authorized_runner_lease = None  # type: ignore[assignment]
    finish_active_acquisition_owner = None  # type: ignore[assignment]
    claim_active_acquisition_owner = None  # type: ignore[assignment]
    issue_authorized_runner_lease = None  # type: ignore[assignment]
    load_platform_json = None  # type: ignore[assignment]
    normalized_path_identity = None  # type: ignore[assignment]
    paths_equivalent = None  # type: ignore[assignment]
    process_start_identity = None  # type: ignore[assignment]
    protocol_timeline = None  # type: ignore[assignment]
    recover_superseded_terminal_owner = None  # type: ignore[assignment]
    runtime_lock_reuse_reasons = None  # type: ignore[assignment]
    runtime_runner_lease_activity = None  # type: ignore[assignment]
    platform_sha256_json = None  # type: ignore[assignment]
    validate_hardware_module = None  # type: ignore[assignment]
    validate_hardware_profile_identity = None  # type: ignore[assignment]
    validate_protocol = None  # type: ignore[assignment]
    validate_session_lock_identity = None  # type: ignore[assignment]
    write_platform_json = None  # type: ignore[assignment]

APP_NAME = "PRAYCG Control Center"
APP_VERSION = "1.0.0-alpha.9.0.0"
CONFIG_SCHEMA = "PRAYCG_ControlCenter_Config_v1_0_alpha_9"

# Tk text buffers and repeated widget creation can retain substantial native
# memory during a long lab session. Keep operator-visible history useful while
# placing hard bounds on UI-owned state.
MAX_CONTROL_CENTER_LOG_LINES = 2000
MAX_CONTROL_CENTER_LOG_CHARS = 250000
MAX_EXITED_PROCESS_ROWS = 40

BENCH_EEG_QUALITY_FAIL_REASONS = frozenset({
    "more than 25% of EEG channels have flat/noise/saturation/missingness flags",
})


def bench_eeg_quality_waiver(payload: Dict[str, Any]) -> Tuple[bool, str]:
    """Allow only cap-off/contact-quality failures while transport remains healthy."""
    if payload.get("schema") != "PRAYCG_Acquisition_Preflight_v1_0":
        return False, "detailed report schema is not eligible for a bench waiver"
    if payload.get("binding_status") != "BOUND":
        return False, "detailed report is not bound to the current equipment session"
    if str(payload.get("status") or "").upper() != "FAIL":
        return False, "detailed report is not a failed EEG-quality report"
    raw_reasons = payload.get("fail_reasons")
    if not isinstance(raw_reasons, list):
        return False, "detailed report failure reasons are unreadable"
    reasons = {
        str(reason).strip()
        for reason in raw_reasons
        if str(reason).strip()
    }
    if not reasons or not reasons.issubset(BENCH_EEG_QUALITY_FAIL_REASONS):
        return False, "failure includes something other than cap-off/contact quality"

    eeg = payload.get("eeg", {})
    if not isinstance(eeg, dict):
        return False, "EEG evidence is missing"
    stream = eeg.get("stream", {})
    timing = eeg.get("timing", {})
    if not isinstance(stream, dict) or not isinstance(timing, dict):
        return False, "EEG stream or timing evidence is missing"
    required_stream_fields = {"source_id", "resolved_candidate_count", "error"}
    required_timing_fields = {
        "sample_count",
        "effective_rate_hz",
        "monotonic_violations",
        "duplicate_timestamps",
        "large_gap_count",
    }
    if not required_stream_fields.issubset(stream):
        return False, "EEG stream evidence is incomplete"
    if not required_timing_fields.issubset(timing) or "expected_rate_hz" not in eeg or "rate_error_fraction" not in eeg:
        return False, "EEG timing/rate evidence is incomplete"
    if str(stream.get("error") or "").strip():
        return False, "EEG stream reported an acquisition error"
    if not isinstance(stream.get("source_id"), str) or not stream["source_id"].strip():
        return False, "EEG stream identity is missing"
    integer_values = {
        "resolved_candidate_count": stream.get("resolved_candidate_count"),
        "sample_count": timing.get("sample_count"),
        "monotonic_violations": timing.get("monotonic_violations"),
        "duplicate_timestamps": timing.get("duplicate_timestamps"),
        "large_gap_count": timing.get("large_gap_count"),
    }
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in integer_values.values()):
        return False, "EEG transport evidence is unreadable"
    candidate_count = integer_values["resolved_candidate_count"]
    sample_count = integer_values["sample_count"]
    monotonic_violations = integer_values["monotonic_violations"]
    duplicate_timestamps = integer_values["duplicate_timestamps"]
    large_gap_count = integer_values["large_gap_count"]
    if candidate_count != 1:
        return False, "EEG stream identity is ambiguous"
    if monotonic_violations != 0:
        return False, "EEG timestamps are not monotonic"
    if duplicate_timestamps != 0:
        return False, "EEG timestamps contain duplicates"
    if large_gap_count != 0:
        return False, "EEG stream contains large delivery gaps"
    raw_expected_rate = eeg.get("expected_rate_hz")
    raw_effective_rate = timing.get("effective_rate_hz")
    raw_rate_error = eeg.get("rate_error_fraction")
    if any(
        isinstance(value, bool) or not isinstance(value, (int, float))
        for value in (raw_expected_rate, raw_effective_rate, raw_rate_error)
    ):
        return False, "EEG effective-rate evidence is unreadable"
    expected_rate = float(raw_expected_rate)
    effective_rate = float(raw_effective_rate)
    rate_error = float(raw_rate_error)
    if (
        not all(math.isfinite(value) for value in (expected_rate, effective_rate, rate_error))
        or expected_rate <= 0.0
        or effective_rate <= 0.0
        or rate_error < 0.0
    ):
        return False, "EEG effective-rate evidence is unreadable"
    calculated_rate_error = abs(effective_rate - expected_rate) / expected_rate
    if not math.isclose(rate_error, calculated_rate_error, rel_tol=1e-6, abs_tol=1e-9):
        return False, "EEG effective-rate evidence is internally inconsistent"
    if rate_error > 0.05:
        return False, "EEG effective sample rate is outside the bench tolerance"
    if sample_count < max(10, int(expected_rate * 5.0)):
        return False, "EEG stream did not deliver the minimum five-second evidence window"
    return True, "only cap-off/contact-quality flags failed; EEG transport and identity passed"


def locked_session_classification_status(session: Any) -> Tuple[bool, str]:
    """Validate the bidirectional participant/bench classification contract."""
    if not isinstance(session, dict):
        return False, "locked session metadata is malformed"
    bench_mode = session.get("bench_test_mode")
    participant_eligible = session.get("participant_data_eligible")
    purpose = str(session.get("session_purpose") or "")
    participant = str(session.get("participant_pseudonym") or "").strip()
    reason = str(session.get("bench_test_reason") or "").strip()
    waiver_active = session.get("bench_eeg_quality_waiver_active")
    readiness_bypass_active = session.get("bench_readiness_bypass_active", False)
    if not isinstance(bench_mode, bool) or not isinstance(participant_eligible, bool):
        return False, "locked session purpose flags are malformed"
    if not isinstance(waiver_active, bool):
        return False, "locked bench-waiver flag is malformed"
    if not isinstance(readiness_bypass_active, bool):
        return False, "locked bench-readiness-bypass flag is malformed"
    if not participant:
        return False, "locked session pseudonym is missing"
    if bench_mode:
        if purpose != "BENCH_TEST" or participant_eligible is not False:
            return False, "bench session purpose or participant-data eligibility is inconsistent"
        if not reason or not participant.upper().startswith("BENCH-") or readiness_bypass_active is not True:
            return False, "bench session lacks its required reason, BENCH- pseudonym, or explicit readiness-bypass label"
    else:
        if purpose != "PARTICIPANT_ACQUISITION" or participant_eligible is not True:
            return False, "participant session purpose or eligibility is inconsistent"
        if reason or waiver_active or readiness_bypass_active or participant.upper().startswith("BENCH-"):
            return False, "participant session contains a reserved bench label"
    return True, "session purpose and participant-data eligibility labels are consistent"


def bench_may_bypass_stimulus_reason(reason: str) -> bool:
    """Allow a scientific-use boundary in bench mode, never a broken file contract."""
    normalized = str(reason or "").upper()
    return "DEMO_ONLY" in normalized and "FAILS ITS FROZEN FILE/HASH CONTRACT" not in normalized


def build_bench_readiness_bypass_preflight(
    hardware_profile: Dict[str, Any],
    run_uuid: str,
    *,
    operator: str,
    source_preflight: Optional[Dict[str, Any]] = None,
    source_preflight_path: str = "",
    source_preflight_file_sha256: str = "",
) -> Dict[str, Any]:
    """Build truthful CAUTION evidence that unlocks only a non-participant bench run."""
    if not isinstance(hardware_profile, dict) or not str(hardware_profile.get("canonical_sha256") or ""):
        raise ValueError("A hash-valid reviewed hardware profile is required for a bench session lock.")
    if not str(run_uuid or "").strip():
        raise ValueError("A runtime session UUID is required for a bench session lock.")
    if not str(operator or "").strip():
        raise ValueError("A recorded operator is required for a bench session lock.")

    module_evidence: List[Dict[str, Any]] = []
    for selected in hardware_profile.get("modules", []):
        if not isinstance(selected, dict) or not str(selected.get("module_id") or "").strip():
            raise ValueError("The reviewed hardware profile contains malformed module selection evidence.")
        module_id = str(selected["module_id"])
        child_report = {
            "schema": "PRAYCG_BenchReadinessBypassModuleEvidence_v1_0",
            "module_id": module_id,
            "status": "BYPASSED_FOR_BENCH_TEST",
            "run_uuid": str(run_uuid),
            "participant_data_eligible": False,
            "reason": "Live hardware and signal-readiness qualifiers were bypassed for a non-participant bench run.",
        }
        module_evidence.append({
            "module_id": module_id,
            "module_file_sha256": selected.get("module_file_sha256") or selected.get("sha256"),
            "module_canonical_sha256": selected.get("module_canonical_sha256"),
            "status": "CAUTION",
            "report": child_report,
            "report_sha256": platform_sha256_json(child_report),  # type: ignore[misc]
        })

    source = source_preflight if isinstance(source_preflight, dict) else {}
    source_binding = {
        "available": bool(source),
        "path": str(source_preflight_path or ""),
        "file_sha256": str(source_preflight_file_sha256 or ""),
        "declared_status": str(source.get("status") or "NOT_RUN"),
        "canonical_sha256": str(source.get("canonical_sha256") or ""),
        "errors": list(source.get("errors") or []),
        "cautions": list(source.get("cautions") or []),
    }
    report: Dict[str, Any] = {
        "schema": "PRAYCG_HardwareProfilePreflight_v1_0_alpha_2",
        "artifact_type": "BENCH_TEST_READINESS_BYPASS_PREFLIGHT",
        "control_center_version": APP_VERSION,
        "created_local": datetime.now().astimezone().isoformat(timespec="seconds"),
        "status": "CAUTION",
        "run_uuid": str(run_uuid),
        "hardware_profile_canonical_sha256": hardware_profile.get("canonical_sha256"),
        "module_evidence": module_evidence,
        "errors": [],
        "cautions": [
            "BENCH TEST ONLY: live hardware, stream, timing, signal-quality, and placement qualifiers were bypassed.",
            "This artifact and every session derived from it are permanently ineligible as participant data.",
        ],
        "bench_test_mode": True,
        "bench_readiness_bypass_active": True,
        "participant_data_eligible": False,
        "operator": str(operator).strip(),
        "source_full_profile_preflight": source_binding,
        "bypassed_qualifiers": [
            "full_profile_preflight",
            "detailed_eeg_als_preflight",
            "als_barcode_placement",
            "live_stream_presence_and_identity",
            "signal_quality_and_timing",
            "demo_only_scientific_collection_boundary",
        ],
    }
    report["canonical_sha256"] = platform_sha256_json(report)  # type: ignore[misc]
    return report

OPERATOR_WORKFLOW_LABELS = {
    "protocol": "Choose protocol",
    "stimuli": "Prepare materials",
    "hardware": "Connect equipment",
    "arm": "Confirm setup",
    "run": "Run session",
    "qc": "Check data quality",
    "analyze": "Analyze",
    "review": "Review results",
    "export": "Export files",
}

PROTOCOL_ASSET_LABELS = {
    "meaning_video": "Meaning video",
    "meaning_anchor_schedule": "Timing / anchor schedule",
    "meaning_stimulus_manifest": "Stimulus review manifest",
    "phase_scrambled_video": "Phase-scrambled control video",
    "shot_order_video": "Shot-order control video",
    "semantic_zero_video": "Semantic-zero control video",
    "target_override_video": "Shared target / override video",
    "reviewed_media_manifest": "Media review / rights manifest",
    "locked_anchor_schedule": "Locked anchor schedule",
    "stimulus_fingerprint_manifest": "Stimulus fingerprint manifest",
    "scale_definition_manifest": "Scale-definition manifest",
    "metabolic_calibration_manifest": "Metabolic calibration manifest",
    "emd_protocol_assets_folder": "EEG Moments protocol files folder",
    "reviewed_import_manifest": "Reviewed import / rights manifest",
    "story_audio": "Story audio",
    "repeated_video": "Repeated naturalistic video",
    "event_video_123": "Everyday-event video 1.2.3",
    "event_video_639": "Everyday-event video 6.3.9",
    "event_video_313": "Everyday-event video 3.1.3",
    "event_video_241": "Everyday-event video 2.4.1",
    "svna_protocol_assets_folder": "SVNA protocol files folder",
    "svna_public_safe_demo_strips": "SVNA public-safe demo strips folder",
}

ATLAS_UNBOUND_RUNTIME_ENV_KEYS = frozenset({
    "PRAYCG_ATLAS_ASSET_BINDINGS_JSON",
    "PRAYCG_ATLAS_RUN_INDEX",
    "PRAYCG_ATLAS_SESSION_INDEX",
    "PRAYCG_RESUME_CHECKPOINT_JSON",
})

# Runtime authority is granted to exactly one validated direct runner launch.
# A stale parent-shell variable must never leak into a debug window or another
# child tool merely because it existed when the Control Center was started.
RUNTIME_AUTHORITY_ENV_KEYS = frozenset({
    "PRAYCG_SESSION_LOCK_JSON",
    "PRAYCG_RUN_UUID",
    "PRAYCG_PARTICIPANT_PSEUDONYM",
    "PRAYCG_SESSION_OPERATOR",
    "PRAYCG_PROTOCOL_MANIFEST",
    "PRAYCG_PROTOCOL_PREFILL_JSON",
    "PRAYCG_SESSION_LOG_DIR",
    "PRAYCG_HARDWARE_PROFILE",
    "PRAYCG_ACQUISITION_STATE",
    "PRAYCG_SESSION_PURPOSE",
    "PRAYCG_BENCH_TEST_MODE",
    "PRAYCG_BENCH_READINESS_BYPASS",
    "PRAYCG_RUNNER_LEASE_JSON",
    "PRAYCG_RUNNER_CLAIM_TOKEN",
}) | ATLAS_UNBOUND_RUNTIME_ENV_KEYS

HARDWARE_LAUNCH_HANDLER_METHODS: Dict[str, str] = {
    "launch_brainflow_eeg_only": "launch_brainflow_eeg_only",
    "launch_brainflow_eeg_als": "launch_brainflow_eeg_als",
    "launch_polar": "launch_polar",
    "launch_vernier": "launch_vernier",
    "launch_generic_eda_ppg": "launch_generic_eda_ppg",
}

# These are the only external processes the cross-version recovery control may
# inspect or stop. Keeping an exact allowlist prevents the equipment recovery
# path from ever becoming a generic Python-process killer.
OPENBCI_BRIDGE_SCRIPT_NAMES = frozenset({
    "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py",
    "praycg_openbci_brainflow_eeg_to_lsl_v1_1.py",
})
OPENBCI_ALS_BRIDGE_SCRIPT_NAME = "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py"
OPENBCI_BRIDGE_HANDLER_KEYS = frozenset({
    "launch_brainflow_eeg_only",
    "launch_brainflow_eeg_als",
})

HARDWARE_PRESETS: Dict[str, List[str]] = {
    "EEG only": ["OpenBCI_CytonDaisy_EEG_v0_1.json"],
    "EEG + ALS": ["OpenBCI_CytonDaisy_EEG_ALS_v0_1.json"],
    "EEG + ALS + Polar H10": [
        "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json",
        "Polar_H10_RR_v0_1.json",
    ],
    "Full supported acquisition stack": [
        "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json",
        "Polar_H10_RR_v0_1.json",
        "Vernier_Respiration_v0_1.json",
    ],
    "Custom selection": [],
}


def slugify(text: str, default: str = "item") -> str:
    text = str(text or "").strip().lower()
    text = re.sub(r"[^a-z0-9._-]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("._-")
    return text or default


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def sha256_bound_path(path: Path) -> str:
    """Hash a file or a directory tree using the Atlas canonical path rule."""
    path = Path(path).expanduser().resolve(strict=True)
    if path.is_file():
        return sha256_file(path)
    if not path.is_dir():
        raise ValueError(f"Unsupported locked input path: {path}")
    digest = hashlib.sha256()
    children = sorted(
        (child for child in path.rglob("*") if child.is_file()),
        key=lambda child: child.relative_to(path).as_posix().casefold(),
    )
    for child in children:
        relative = child.relative_to(path).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(sha256_file(child)))
        digest.update(b"\0")
    return digest.hexdigest()


def now_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def open_path(path: Path) -> None:
    path = Path(path)
    if not path.exists():
        messagebox.showwarning("Path not found", f"Path does not exist:\n{path}")
        return
    if sys.platform.startswith("win"):
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


def command_prefix_from_setting(value: str) -> List[str]:
    """Return a subprocess-safe command prefix from a GUI setting.

    v0.6 used shlex.split() on the Python executable setting. On Windows,
    shlex with POSIX behavior can corrupt backslash paths such as
    user-profile Python paths into invalid paths, causing WinError 2.

    This helper preserves real executable paths exactly. It still allows
    short launcher commands such as: py -3.11
    """
    raw = str(value or "").strip()
    if not raw:
        return []
    whole = raw.strip().strip('"')
    try:
        if Path(whole).is_file():
            return [whole]
    except Exception:
        pass
    try:
        parts = shlex.split(raw, posix=False)
        parts = [str(x).strip().strip('"') for x in parts if str(x).strip()]
        return parts
    except Exception:
        return raw.split()


def child_process_environment(
    env_overrides: Optional[Dict[str, str]] = None,
    *,
    allow_runtime_authority: bool = False,
) -> Dict[str, str]:
    """Build a child environment with runtime authority denied by default."""
    child_env = os.environ.copy()
    for key in RUNTIME_AUTHORITY_ENV_KEYS:
        child_env.pop(key, None)
    clean_overrides = {str(key): str(value) for key, value in (env_overrides or {}).items()}
    # These values have no governed runtime session-lock contract. They are removed
    # even for the one authorized runner child; accepting them would let a
    # parent shell alter the compiled Atlas plan or resume position.
    for key in ATLAS_UNBOUND_RUNTIME_ENV_KEYS:
        clean_overrides.pop(key, None)
    if not allow_runtime_authority:
        for key in RUNTIME_AUTHORITY_ENV_KEYS:
            clean_overrides.pop(key, None)
    child_env.update(clean_overrides)
    return child_env


def windows_bat_command(path: Path, args: Optional[List[str]] = None) -> List[str]:
    if sys.platform.startswith("win") and path.suffix.lower() in {".bat", ".cmd"}:
        return ["cmd.exe", "/c", str(path)] + (args or [])
    return [str(path)] + (args or [])


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def packaged_protocol_atlas_root() -> Path:
    """Return the sole runnable Atlas root trusted by this release."""
    return (package_root().parent / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0").resolve(strict=False)


def packaged_protocol_library_root(module_family: str) -> Path:
    """Return the package-owned runnable root for one supported protocol family."""
    if module_family == FAMILY_ATLAS:
        return packaged_protocol_atlas_root()
    if module_family == FAMILY_NATIVE:
        return (package_root().parent / "tools" / "ProtocolRunner_ModuleLibrary_v1_0").resolve(strict=False)
    raise ValueError(f"Unsupported protocol module family: {module_family!r}")


def normalized_path(value: str) -> Path:
    """Normalize a user-entered path without requiring it to exist."""
    raw = os.path.expandvars(str(value or "").strip().strip('"'))
    return Path(raw).expanduser() if raw else Path()


def command_is_available(cmd: List[str]) -> bool:
    """Return whether the first command token resolves to a launchable file."""
    if not cmd:
        return False
    executable = str(cmd[0]).strip().strip('"')
    if not executable:
        return False
    path = Path(executable).expanduser()
    if path.is_file():
        return True
    return shutil.which(executable) is not None


def command_argument(command_line: str, flag: str) -> str:
    """Read one quoted or unquoted argument from a Windows command line."""
    match = re.search(
        rf"(?i)(?:^|\s){re.escape(flag)}(?:\s+|=)(?:\"([^\"]*)\"|'([^']*)'|(\S+))",
        str(command_line or ""),
    )
    if not match:
        return ""
    return next((str(value) for value in match.groups() if value is not None), "").strip()


def python_script_token(command_line: str) -> str:
    """Return the basename of the direct script argument to Python."""
    match = re.match(
        r'^\s*(?:"[^"]*"|\S+)\s+(?:"([^"]+)"|(\S+))',
        str(command_line or ""),
    )
    if not match:
        return ""
    token = next((str(value) for value in match.groups() if value is not None), "")
    return re.split(r"[\\/]", token)[-1]


def discover_external_openbci_bridges() -> List[Dict[str, Any]]:
    """Find still-running packaged OpenBCI bridges from any Control Center version.

    A Control Center window can be upgraded or closed while a bridge keeps
    streaming. The new window therefore cannot rely only on its in-memory
    ``Popen`` rows. On Windows, query Python command lines and then apply the
    exact script allowlist in Python.
    """
    if not sys.platform.startswith("win"):
        return []
    powershell = shutil.which("powershell.exe") or shutil.which("powershell")
    if not powershell:
        return []
    query = (
        "$ErrorActionPreference='Stop'; "
        "$rows=@(Get-CimInstance Win32_Process | "
        "Where-Object { $_.Name -match '^python(w)?(\\.exe)?$' } | "
        "Select-Object ProcessId,ParentProcessId,CreationDate,Name,CommandLine); "
        "ConvertTo-Json -InputObject $rows -Compress"
    )
    try:
        completed = subprocess.run(
            [powershell, "-NoProfile", "-NonInteractive", "-Command", query],
            capture_output=True,
            text=True,
            timeout=12,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if completed.returncode != 0 or not completed.stdout.strip():
            return []
        payload = json.loads(completed.stdout.lstrip("\ufeff"))
    except Exception:
        return []
    records = payload if isinstance(payload, list) else [payload]
    found: List[Dict[str, Any]] = []
    for record in records:
        if not isinstance(record, dict):
            continue
        command_line = str(record.get("CommandLine") or "")
        direct_script = python_script_token(command_line)
        script_name = next(
            (name for name in OPENBCI_BRIDGE_SCRIPT_NAMES if name.casefold() == direct_script.casefold()),
            "",
        )
        try:
            pid = int(record.get("ProcessId"))
        except (TypeError, ValueError):
            continue
        if not script_name or pid <= 0 or pid == os.getpid():
            continue
        found.append({
            "pid": pid,
            "parent_pid": record.get("ParentProcessId"),
            "created": str(record.get("CreationDate") or ""),
            "name": str(record.get("Name") or ""),
            "command_line": command_line,
            "script_name": script_name,
            "run_uuid": command_argument(command_line, "--run-uuid"),
            "serial_port": command_argument(command_line, "--serial-port").upper(),
        })
    return sorted(found, key=lambda row: int(row["pid"]))


def stop_external_openbci_bridge(candidate: Dict[str, Any]) -> Tuple[bool, str]:
    """Stop one freshly revalidated, allowlisted PRAYCG OpenBCI bridge tree."""
    try:
        pid = int(candidate.get("pid"))
    except (TypeError, ValueError):
        return False, "the saved process ID is invalid"
    script_name = str(candidate.get("script_name") or "")
    command_line = str(candidate.get("command_line") or "")
    if pid <= 0 or script_name not in OPENBCI_BRIDGE_SCRIPT_NAMES or not command_line:
        return False, "the process no longer satisfies the guarded bridge identity"
    fresh = next((row for row in discover_external_openbci_bridges() if int(row["pid"]) == pid), None)
    if fresh is None:
        return True, "the prior bridge had already stopped"
    if fresh.get("script_name") != script_name or fresh.get("command_line") != command_line:
        return False, "the process identity changed before shutdown; no process was stopped"
    try:
        completed = subprocess.run(
            # Bridge processes are long-running console applications. Windows
            # reports that they can only be terminated forcefully; /F is safe
            # here because the PID, allowlisted script, and full command line
            # were all revalidated immediately above.
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            capture_output=True,
            text=True,
            timeout=15,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception as exc:
        return False, str(exc)
    detail = (completed.stdout or completed.stderr or "").strip()
    if completed.returncode != 0:
        return False, detail or f"taskkill returned {completed.returncode}"
    if any(int(row["pid"]) == pid for row in discover_external_openbci_bridges()):
        return False, "Windows accepted the stop request, but the old bridge is still running"
    return True, detail or "old bridge stopped"


def plan_als_barcode_bridge(rows: List[Dict[str, Any]], run_uuid: str) -> Dict[str, Any]:
    """Classify exact PRAYCG bridges before the ALS barcode workflow mutates anything."""
    active = str(run_uuid or "").strip()
    bridges = [row for row in rows if isinstance(row, dict)]
    current_als = [
        row for row in bridges
        if str(row.get("script_name") or "") == OPENBCI_ALS_BRIDGE_SCRIPT_NAME
        and str(row.get("run_uuid") or "") == active
    ]
    if len(bridges) == 1 and len(current_als) == 1:
        return {"action": "REUSE_CURRENT_ALS", "port": str(current_als[0].get("serial_port") or "").upper(), "rows": bridges}
    if not bridges:
        return {"action": "START_ALS", "port": "", "rows": []}
    ports = {
        str(row.get("serial_port") or "").strip().upper()
        for row in bridges
        if str(row.get("serial_port") or "").strip()
    }
    if len(ports) != 1 or any(not str(row.get("serial_port") or "").strip() for row in bridges):
        return {"action": "BLOCK_AMBIGUOUS", "port": "", "rows": bridges}
    if current_als:
        # A current ALS bridge plus any second packaged bridge is not safe to
        # repair automatically because the current publisher must be preserved.
        return {"action": "BLOCK_DUPLICATE", "port": next(iter(ports)), "rows": bridges}
    return {"action": "REPLACE_WITH_ALS", "port": next(iter(ports)), "rows": bridges}


def path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def bundled_tool_paths(root: Optional[Path] = None) -> Dict[str, str]:
    """Return package-relative tools, with alpha modules sourced from the registry."""
    root = root or package_root()
    bundled = root.parent / "tools"
    paths = {
        "mediaprep_gui": str(root / "scripts" / "praycg_launch_mediaprep_gui_v0_92.py"),
        "master_suite_gui": str(root / "scripts" / "praycg_launch_master_suite_gui_v0_92.py"),
        "master_chain_gui": str(root / "scripts" / "praycg_launch_master_chain_gui_v0_92.py"),
        "visualizer_gui": str(bundled / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_master_sync_visualizer_v1_4_0.py"),
        "offline_interpreter_gui": str(bundled / "Offline_Master_Interpreter_v1_6_0" / "scripts" / "praycg_offline_interpretive_report_gui_v1_6_0.py"),
        "confound_expanded_gui": str(bundled / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_confound_expanded_modules_v1_5_7.py"),
        "brainflow_eeg_only": str(bundled / "Acquisition" / "BrainFlow_EEGOnly_Home_Bridge_v1_1" / "scripts" / "praycg_openbci_brainflow_eeg_to_lsl_v1_1.py"),
        "brainflow_eeg_als": str(bundled / "Acquisition" / "BrainFlow_ALS_PT19_Bridge_v1_5" / "scripts" / "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py"),
        "polar_h10": str(bundled / "Acquisition" / "Polar_H10_to_LSL" / "polar_to_lsl.py"),
        "vernier_resp": str(bundled / "Acquisition" / "Vernier_Respiration_to_LSL" / "vernier_respiration_belt_to_lsl.py"),
        "generic_eda_ppg_bridge": str(bundled / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1" / "scripts" / "praycg_generic_eda_ppg_to_lsl_v0_1.py"),
        "generic_eda_ppg_simulator": str(bundled / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1" / "scripts" / "praycg_generic_eda_ppg_simulator_v0_1.py"),
        "generic_eda_ppg_profile_wizard": str(bundled / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1" / "scripts" / "praycg_generic_eda_ppg_profile_wizard_v0_1.py"),
        "lsl_stream_checker": str(root / "scripts" / "praycg_lsl_stream_checker_v0_1.py"),
        "live_stream_monitor": str(root / "scripts" / "praycg_live_stream_monitor_v1_0.py"),
        "signal_quality_index": str(root / "scripts" / "praycg_signal_quality_index_v0_1.py"),
        "acquisition_preflight": str(root / "scripts" / "praycg_acquisition_preflight_v1_0.py"),
        "als_pulse_test": str(root / "scripts" / "praycg_als_barcode_live_test_v0_7.py"),
        "als_barcode_detector": str(root / "scripts" / "praycg_launch_als_barcode_detector_gui_v0_92.py"),
        "mediaprep_barcode_backup": str(root / "scripts" / "praycg_launch_embedded_barcode_backup_v0_92.py"),
        "shot_order_scramble": str(bundled / "MediaPrep_StimulusFingerprint_v1_9_SHOTORDER" / "scripts" / "praycg_shot_order_scramble_control_v1_9.py"),
        "als_holder_calibration": str(root / "scripts" / "praycg_als_holder_calibration_v0_8.py"),
        "hocr_shotorder": str(root / "scripts" / "praycg_launch_hocr_shotorder_gui_v0_92.py"),
        "cai_sid_exploratory_gui": str(bundled / "CAI_SID_Exploratory_v0_2" / "scripts" / "praycg_cai_sid_exploratory_gui_v0_2.py"),
        "cai_readiness_preflight": str(bundled / "CAI_SID_Exploratory_v0_2" / "scripts" / "praycg_cai_readiness_preflight_v0_2.py"),
        "continuous_autonomic_gui": str(bundled / "Continuous_Autonomic_RespDualPath_v1_0" / "scripts" / "praycg_continuous_autonomic_v1_0.py"),
        "prospective_study_console": str(bundled / "Prospective_Study_Package_v0_1" / "scripts" / "praycg_prospective_study_console_v0_1.py"),
        "micro_handoff_gui": str(bundled / "Micro_Handoff_v0_1" / "scripts" / "praycg_micro_handoff_gui_v0_1.py"),
        "protocol_forge": str(bundled / "Protocol_Forge_v0_1" / "praycg_protocol_forge_v0_1.py"),
        "protocol_ai_doc_builder": str(bundled / "Protocol_AI_Doc_Builder_v0_1" / "praycg_protocol_ai_doc_builder_v0_1.py"),
        "stimulus_library": str(bundled / "Stimulus_Forge_Library_v1_0" / "praycg_stimulus_library_v1_0.py"),
        "stimulus_forge": str(bundled / "Stimulus_Forge_Library_v1_0" / "praycg_stimulus_forge_v1_0.py"),
        "hardware_registry": str(bundled / "Hardware_Registry_v0_1" / "praycg_hardware_registry_v0_1.py"),
        "hardware_forge": str(bundled / "Hardware_Forge_v1_0" / "praycg_hardware_forge_v1_0.py"),
        "generic_lsl_intake": str(bundled / "Hardware_Forge_v1_0" / "praycg_generic_lsl_intake_v1_0.py"),
        "stream_contract_validator": str(bundled / "Hardware_Forge_v1_0" / "praycg_stream_contract_v1_0.py"),
        "analysis_module_catalog": str(bundled / "Analysis_Module_Catalog_v0_1" / "praycg_analysis_module_catalog_v0_1.py"),
        "acquisition_supervisor": str(bundled / "Acquisition_Supervisor_v0_1" / "praycg_acquisition_supervisor_v0_1.py"),
        "contract_acquisition_supervisor": str(bundled / "Acquisition_Supervisor_v1_0" / "praycg_acquisition_supervisor_v1_0.py"),
        "bids_exporter": str(bundled / "BIDS_Exporter_v0_1" / "praycg_bids_exporter_v0_1.py"),
        "release_validator": str(bundled / "Release_Validation_v0_1" / "praycg_release_validator_v0_1.py"),
        "cue_locked_gamma_forensics": str(root / "scripts" / "praycg_launch_clgf_gui_v0_1.py"),
        "study_workspace": str(bundled / "Study_Workspace_v0_1" / "praycg_study_workspace_v0_1.py"),
        "analysis_orchestrator": str(bundled / "Analysis_Orchestrator_v0_1" / "praycg_analysis_orchestrator_v0_1.py"),
        "analysis_integrity_qc": str(bundled / "Analysis_Orchestrator_v0_1" / "praycg_run_integrity_qc_v0_1.py"),
        "results_bundle_builder": str(bundled / "Results_Bundle_Builder_v0_1" / "praycg_results_bundle_builder_v0_1.py"),
    }
    registry_path = root.parent / "config" / "module_registry_v1_0_alpha_9.json"
    try:
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
        if registry.get("schema") == "PRAYCG_ModuleRegistry_v1_0_alpha_9":
            for record in registry.get("modules", []):
                key = str(record.get("id", ""))
                if key == "platform_workbench":
                    continue
                entry = Path(str(record.get("entry", "")))
                candidate = (root.parent / entry).resolve()
                if key and not entry.is_absolute() and ".." not in entry.parts and path_is_within(candidate, root.parent):
                    paths[key] = str(candidate)
    except Exception:
        pass
    return paths


def detect_serial_ports() -> List[str]:
    """Find Windows COM ports without requiring pyserial."""
    found: List[str] = []
    try:
        from serial.tools import list_ports  # type: ignore
        found.extend(str(port.device) for port in list_ports.comports() if port.device)
    except Exception:
        pass
    if sys.platform.startswith("win"):
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM")
            try:
                idx = 0
                while True:
                    try:
                        _name, value, _kind = winreg.EnumValue(key, idx)
                    except OSError:
                        break
                    if value:
                        found.append(str(value))
                    idx += 1
            finally:
                winreg.CloseKey(key)
        except Exception:
            pass
    return sorted(set(found), key=lambda value: (len(value), value.lower()))


def user_config_dir() -> Path:
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or str(Path.home())
        return Path(base) / "PRAYCG_ControlCenter"
    return Path.home() / ".praycg_control_center"


def default_config() -> Dict[str, Any]:
    root = package_root()
    home = Path("C:/PRAYCG") if sys.platform.startswith("win") else Path.home() / "PRAYCG"
    py = sys.executable
    return {
        "schema": CONFIG_SCHEMA,
        "version": APP_VERSION,
        "praycg_home": str(home),
        "python_executable": py,
        "stimulus_root": str(home / "stimuli"),
        "stimulus_pack_install_root": str(home / "stimuli" / "bundled_samples"),
        "run_root": str(home / "runs"),
        "analysis_root": str(home / "analysis"),
        "log_root": str(home / "logs"),
        "study_workspace_root": str(home / "study_workspaces"),
        "hardware_adapter_catalog": str(root.parent / "config" / "hardware_adapter_catalog_v1_0.json"),
        "stream_contract_root": str(home / "config" / "stream_contracts"),
        "analysis_orchestration_registry": str(root.parent / "config" / "analysis_orchestration_registry_v0_1.json"),
        "lsl": {
            "expected_streams": ["obci_eeg1", "OpenBCIAnalogAux", "ALS_PT19_Timing", "OpenBCIStatusMarkers", "PolarHRV"],
            "eeg_stream_name": "obci_eeg1",
            "eeg_expected_rate_hz": 125.0,
            "als_stream_name": "ALS_PT19_Timing",
            "als_channel_index_1based": 1
        },
        "acquisition": {
            "openbci_serial_port": "",
            "generic_eda_ppg_driver_profile_path": "",
            "generic_eda_ppg_draft_root": str(home / "config" / "hardware_profile_drafts" / "generic_eda_ppg"),
            "generic_lsl_draft_root": str(home / "config" / "hardware_profile_drafts" / "generic_lsl"),
            "latest_lsl_discovery_snapshot": "",
            "hardware_profile_path": str(home / "config" / "hardware_profiles" / "active_hardware_profile.json"),
            "hardware_profile_draft_path": str(home / "config" / "hardware_profiles" / "hardware_profile_draft.json"),
            "hardware_ui_lock_path": str(home / "config" / "hardware_profiles" / "active_hardware_ui_lock.json"),
            "hardware_preset": "EEG + ALS + Polar H10",
            "preflight_started_epoch": time.time(),
            "control_center_process_id": str(uuid.uuid4()),
            "profile_preflight_report_path": str(home / "logs" / "hardware_profile_preflight" / "active_profile_preflight.json"),
            "detailed_preflight_dir": str(home / "logs" / "acquisition_preflight"),
            "als_test_dir": str(home / "logs" / "als_pulse_tests"),
            "supervisor_output_dir": str(home / "logs" / "acquisition_supervisor" / "active_profile"),
            "session_lock_path": str(home / "config" / "active_session_lock_v1_0_alpha_9.json"),
            "session_draft_path": str(home / "config" / "active_session_draft_v1_0_alpha_9.json"),
            "session_artifact_root": "",
            "approved_protocol_snapshot_path": "",
            "study_id": "PRAYCG_ALPHA",
            "participant_pseudonym": "",
            "operator_name": "",
            "session_lock_status": "NOT_LOCKED",
            "readiness_status": "INELIGIBLE",
            "readiness_message": "Select and review a hardware profile before arming.",
            "armed": False,
            "arm_override_reason": "",
            "bench_test_mode": False,
            "bench_test_reason": "",
            "bench_eeg_quality_waiver_active": False,
            "bench_readiness_bypass_active": False,
            "bench_bypass_preflight_path": "",
            "disarmed_lock_identity": "",
            "state_path": str(home / "config" / "active_acquisition_state_v1_0_alpha_9.json")
        },
        "tools": {
            **bundled_tool_paths(root),
            "psychopy_app": "",
            "psychopy_coder": "",
            "psychopy_python": "",
            "labrecorder": ""
        },
        "runner_launch_mode": "psychopy_python",
        "stimulus_registry": str(home / "config" / "stimulus_registry.json"),
        "run_registry": str(home / "config" / "run_registry.json"),
        "protocol_library_root": str(packaged_protocol_atlas_root()),
        "protocol_asset_root": str(home / "protocol_assets"),
        "protocol_asset_folders": {},
        "protocol_asset_bindings": {},
        "custom_protocol_draft_root": str(home / "protocol_design_drafts"),
        "selected_protocol_id": "PRAYCG3",
    }


def merge_defaults(cfg: Dict[str, Any], defaults: Dict[str, Any]) -> Dict[str, Any]:
    out = defaults.copy()
    for k, v in cfg.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            d = out[k].copy(); d.update(v); out[k] = d
        else:
            out[k] = v
    return out


def migrate_saved_config(cfg: Dict[str, Any], defaults: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """Move bundled paths to this extraction while preserving external app choices."""
    out = merge_defaults(cfg, defaults)
    notes: List[str] = []
    current_root = package_root().parent
    saved_tools = cfg.get("tools", {}) if isinstance(cfg.get("tools"), dict) else {}
    current_bundled = bundled_tool_paths()
    out.setdefault("tools", {})
    for key, current_value in current_bundled.items():
        saved_value = str(saved_tools.get(key, "") or "").strip()
        saved_path = normalized_path(saved_value)
        references_other_bundle = bool(
            saved_value
            and re.search(r"PRAYCG_ControlCenter_v\d", saved_value, flags=re.IGNORECASE)
            and not path_is_within(saved_path, current_root)
        )
        if not saved_value or not saved_path.is_file() or references_other_bundle:
            if saved_value != current_value:
                notes.append(f"Rebased bundled tool path: {key}")
            out["tools"][key] = current_value
    if "protocol_runner_praycg2" in out.get("tools", {}):
        out["tools"].pop("protocol_runner_praycg2", None)
        notes.append("Removed superseded single-runner path; v1 alpha uses the protocol library")
    if "platform_workbench" in out.get("tools", {}):
        out["tools"].pop("platform_workbench", None)
        notes.append("Removed the superseded Platform Workbench path; its controls are consolidated by workflow")
    current_library = str(packaged_protocol_atlas_root())
    saved_library_value = str(cfg.get("protocol_library_root", "") or "").strip()
    saved_library = normalized_path(saved_library_value)
    library_references_other_bundle = bool(
        saved_library_value
        and re.search(r"PRAYCG_ControlCenter_v\d", saved_library_value, flags=re.IGNORECASE)
        and not path_is_within(saved_library, current_root)
    )
    saved_library_is_packaged = bool(
        saved_library_value
        and saved_library.resolve(strict=False) == packaged_protocol_atlas_root()
    )
    if not saved_library_is_packaged or library_references_other_bundle:
        if saved_library_value != current_library:
            notes.append("Rebased bundled protocol-library path")
        out["protocol_library_root"] = current_library
    out["schema"] = CONFIG_SCHEMA
    out["version"] = APP_VERSION
    python_cmd = command_prefix_from_setting(str(out.get("python_executable", "")))
    if not command_is_available(python_cmd):
        out["python_executable"] = sys.executable
        notes.append("Replaced unavailable Python executable with the current interpreter")
    if cfg.get("schema") != CONFIG_SCHEMA or str(cfg.get("version", "")) != APP_VERSION:
        notes.append(f"Updated saved settings to {CONFIG_SCHEMA}")
    # Live evidence and arming are never carried across a fresh application
    # process.  An old report or an already-ARM lock cannot silently re-arm.
    acquisition = out.setdefault("acquisition", {})
    acquisition["armed"] = False
    acquisition["arm_override_reason"] = ""
    acquisition["bench_test_mode"] = False
    acquisition["bench_test_reason"] = ""
    acquisition["bench_eeg_quality_waiver_active"] = False
    acquisition["bench_readiness_bypass_active"] = False
    acquisition["bench_bypass_preflight_path"] = ""
    acquisition["preflight_started_epoch"] = time.time()
    acquisition["control_center_process_id"] = str(uuid.uuid4())
    acquisition["session_lock_status"] = "STALE_NEW_CONTROL_CENTER_PROCESS"
    return out, notes


@dataclass
class RunningProcess:
    label: str
    process: subprocess.Popen
    log_path: Path
    started: float
    cmd: List[str]
    cwd: Optional[Path] = None
    env_overrides: Optional[Dict[str, str]] = None
    runtime_authority: bool = False
    restartable: bool = True
    shutdown_requested: bool = False
    completion_handled: bool = False
    completion_reconcile_attempts: int = 0
    runtime_lease_path: Optional[Path] = None
    runtime_owner_path: Optional[Path] = None
    process_start_identity: str = ""


class ScrollText(ttk.Frame):
    def __init__(
        self,
        parent,
        max_lines: int = MAX_CONTROL_CENTER_LOG_LINES,
        max_chars: int = MAX_CONTROL_CENTER_LOG_CHARS,
    ):
        super().__init__(parent)
        self.max_lines = max(100, int(max_lines))
        self.max_chars = max(10000, int(max_chars))
        self.text = tk.Text(self, wrap="word", height=6)
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scroll.set)
        self.text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def write(self, msg: str) -> None:
        self.text.insert("end", msg)
        line_count = int(self.text.index("end-1c").split(".", 1)[0])
        if line_count > self.max_lines:
            self.text.delete("1.0", f"{line_count - self.max_lines + 1}.0")
        char_count = int(self.text.count("1.0", "end-1c", "chars")[0])
        if char_count > self.max_chars:
            self.text.delete("1.0", f"1.0 + {char_count - self.max_chars} chars")
        self.text.see("end")

    def clear(self) -> None:
        self.text.delete("1.0", "end")


class PRAYCGControlCenter(tk.Tk):
    def __init__(self):
        super().__init__()
        self._closing = False
        self._periodic_after_id: Optional[str] = None
        self._initial_refresh_after_id: Optional[str] = None
        self._process_tree_signature: Optional[Tuple[Any, ...]] = None
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("1180x820")
        self.minsize(1000, 700)
        self.pkg = package_root()
        self.config_path = user_config_dir() / "config.json"
        self.config_migration_notes: List[str] = []
        self.cfg = self.load_config()
        self.study_workspace_pointer_path = user_config_dir() / "active_study_workspace_v0_1.json"
        self.active_workspace_path: Optional[Path] = read_active_pointer(self.study_workspace_pointer_path)
        self.active_workspace: Optional[Dict[str, Any]] = None
        self.workspace_load_error = ""
        if self.active_workspace_path:
            try:
                self.active_workspace = load_workspace(self.active_workspace_path)
            except Exception as exc:
                self.workspace_load_error = f"{type(exc).__name__}: {exc}"
                self.active_workspace_path = None
        self._workspace_sync_in_progress = False
        self.analysis_registry_path = Path(str(self.cfg.get("analysis_orchestration_registry") or "")).expanduser().resolve(strict=False)
        self.analysis_registry_report: Dict[str, Any] = {}
        self.analysis_eligibility: Dict[str, Dict[str, Any]] = {}
        self.analysis_plan_selected_ids: set[str] = set()
        self.analysis_orchestration_rows: Dict[str, Dict[str, Any]] = {}
        self.active_analysis_plan: Dict[str, Any] = dict((self.active_workspace or {}).get("analysis", {}).get("plan", {}) or {})
        self.latest_results_bundle_path: Optional[Path] = None
        self.context_path = user_config_dir() / "active_context_v1_0.json"
        self.active_context = self.load_active_context()
        self.protocol_library_root = packaged_protocol_atlas_root()
        self.cfg["protocol_library_root"] = str(self.protocol_library_root)
        self.analysis_registry_path = Path(str(self.cfg.get("analysis_orchestration_registry") or "")).expanduser().resolve(strict=False)
        self.legacy_protocol_library_root = self.pkg.parent / "tools" / "ProtocolRunner_ModuleLibrary_v1_0"
        self.protocol_lock_path = user_config_dir() / "protocol_lock_v1_0.json"
        self.protocol_records: List[Dict[str, Any]] = []
        self.protocol_library_errors: List[str] = []
        self.locked_protocol: Optional[Dict[str, Any]] = None
        self.protocol_stimulus_model = ProtocolStimulusWorkflowModel(self.pkg.parent)
        self.protocol_stimulus_workflow: Dict[str, Any] = {}
        self.stimulus_tree_candidates: Dict[str, Dict[str, Any]] = {}
        self.selected_stimulus_candidate_id: Optional[str] = None
        self.hardware_registry_root = self.pkg.parent / "config" / "hardware"
        self.hardware_module_paths: List[Path] = []
        self.active_hardware_profile: Optional[Dict[str, Any]] = None
        self.hardware_workflow_model = None
        if HardwareWorkflowModel is not None:
            try:
                self.hardware_workflow_model = HardwareWorkflowModel(intended_use="HUMAN_CONNECTED")
            except Exception:
                traceback.print_exc()
        self.hardware_tree_rows_by_id: Dict[str, Dict[str, Any]] = {}
        self.hardware_profile_draft_path: Optional[Path] = None
        self.hardware_ui_lock: Optional[Dict[str, Any]] = None
        self.rendered_hardware_launch_actions: Dict[str, Dict[str, Any]] = {}
        self.processes: Dict[str, RunningProcess] = {}
        self.last_context_scan = 0.0
        self.last_acquisition_scan = 0.0
        self.last_owner_reconcile = 0.0
        self.active_run_uuid: Optional[str] = None
        self.selected_stimulus_id: Optional[str] = str(self.active_context.get("stimulus", {}).get("id") or "") or None
        saved_run_folder = str(self.active_context.get("run", {}).get("folder") or "")
        self.selected_run_folder: Optional[Path] = Path(saved_run_folder) if saved_run_folder else None
        self.create_dirs()
        self.build_ui()
        if self.workspace_load_error:
            self.log(f"Study Workspace pointer was not loaded: {self.workspace_load_error}\n")
        for note in self.config_migration_notes:
            self.log(f"Settings migration: {note}\n")
        self.refresh_dashboard()
        self.refresh_active_context_ui()
        self.protocol("WM_DELETE_WINDOW", self.close_app)
        self._initial_refresh_after_id = self.after(250, self.refresh_all_context)
        self._periodic_after_id = self.after(1500, self.periodic_update)

    def close_app(self) -> None:
        """Cancel recurring UI callbacks before releasing the Tcl interpreter."""
        if self._closing:
            return
        self._closing = True
        for callback_id in (self._initial_refresh_after_id, self._periodic_after_id):
            if callback_id:
                try:
                    self.after_cancel(callback_id)
                except tk.TclError:
                    pass
        self._initial_refresh_after_id = None
        self._periodic_after_id = None
        self.destroy()

    def load_config(self) -> Dict[str, Any]:
        defaults = default_config()
        if self.config_path.exists():
            try:
                cfg = json.loads(self.config_path.read_text(encoding="utf-8"))
                migrated, notes = migrate_saved_config(cfg, defaults)
                self.config_migration_notes = notes
                if notes:
                    user_config_dir().mkdir(parents=True, exist_ok=True)
                    self.config_path.write_text(json.dumps(migrated, indent=2), encoding="utf-8")
                return migrated
            except Exception:
                traceback.print_exc()
        user_config_dir().mkdir(parents=True, exist_ok=True)
        self.config_path.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
        return defaults

    def save_config(self) -> None:
        user_config_dir().mkdir(parents=True, exist_ok=True)
        self.config_path.write_text(json.dumps(self.cfg, indent=2), encoding="utf-8")
        self.log(f"Saved config: {self.config_path}\n")

    def load_active_context(self) -> Dict[str, Any]:
        try:
            payload = json.loads(self.context_path.read_text(encoding="utf-8"))
            if isinstance(payload, dict) and payload.get("schema") == CONTEXT_SCHEMA:
                return payload
        except Exception:
            pass
        return empty_context()

    def save_active_context(self) -> None:
        self.active_context["schema"] = CONTEXT_SCHEMA
        self.active_context["version"] = "1.0"
        self.active_context["updated_local"] = datetime.now().isoformat(timespec="seconds")
        self.active_context["readiness"] = readiness(self.active_context)
        self.context_path.parent.mkdir(parents=True, exist_ok=True)
        self.context_path.write_text(json.dumps(self.active_context, indent=2), encoding="utf-8")
        self.refresh_active_context_ui()

    def create_dirs(self) -> None:
        for key in ["praycg_home", "stimulus_root", "stimulus_pack_install_root", "protocol_asset_root", "custom_protocol_draft_root", "run_root", "analysis_root", "log_root", "study_workspace_root"]:
            Path(self.cfg[key]).mkdir(parents=True, exist_ok=True)
        acquisition = self.cfg.setdefault("acquisition", {})
        for key in ("hardware_profile_path", "hardware_profile_draft_path", "hardware_ui_lock_path", "session_lock_path", "state_path"):
            value = str(acquisition.get(key) or "").strip()
            if value:
                Path(value).expanduser().parent.mkdir(parents=True, exist_ok=True)
        for key in ("detailed_preflight_dir", "supervisor_output_dir"):
            value = str(acquisition.get(key) or "").strip()
            if value:
                Path(value).expanduser().mkdir(parents=True, exist_ok=True)
        Path(self.cfg["stimulus_registry"]).parent.mkdir(parents=True, exist_ok=True)
        if not Path(self.cfg["stimulus_registry"]).exists():
            Path(self.cfg["stimulus_registry"]).write_text(json.dumps({"schema":"PRAYCG_StimulusRegistry_v0_1", "stimuli": []}, indent=2), encoding="utf-8")
        if not Path(self.cfg["run_registry"]).exists():
            Path(self.cfg["run_registry"]).write_text(json.dumps({"schema":"PRAYCG_RunRegistry_v0_2", "runs": []}, indent=2), encoding="utf-8")

    def build_ui(self) -> None:
        top = ttk.Frame(self)
        top.pack(side="top", fill="x", padx=8, pady=6)
        ttk.Label(top, text="PRAYCG Control Center", font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Label(top, text="  Choose a protocol, prepare its materials, check equipment, run, and review", foreground="#555").pack(side="left")
        ttk.Button(top, text="Open PRAYCG Home", command=lambda: open_path(Path(self.cfg["praycg_home"]))).pack(side="right", padx=4)
        ttk.Button(top, text="Save Settings", command=self.save_settings_from_ui).pack(side="right", padx=4)

        self.build_active_context_bar()

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=8, pady=4)
        self.dashboard_tab = ttk.Frame(self.nb); self.nb.add(self.dashboard_tab, text="Home")
        self.protocol_tab = ttk.Frame(self.nb); self.nb.add(self.protocol_tab, text="Choose Protocol")
        self.stim_tab = ttk.Frame(self.nb); self.nb.add(self.stim_tab, text="Prepare Materials")
        self.acq_tab = ttk.Frame(self.nb); self.nb.add(self.acq_tab, text="Connect & Check Equipment")
        self.runner_tab = ttk.Frame(self.nb); self.nb.add(self.runner_tab, text="Run Session")
        self.analysis_tab = ttk.Frame(self.nb); self.nb.add(self.analysis_tab, text="Review Results")
        self.settings_tab = ttk.Frame(self.nb); self.nb.add(self.settings_tab, text="Settings")

        self.build_dashboard_tab()
        self.build_protocol_atlas_tab()
        self.build_stimulus_tab()
        self.build_acquisition_tab()
        self.build_runner_tab()
        self.build_analysis_tab()
        self.build_settings_tab()

        bottom = ttk.LabelFrame(self, text="Control Center Log")
        bottom.pack(fill="both", expand=False, padx=8, pady=4)
        self.logbox = ScrollText(bottom)
        self.logbox.pack(fill="both", expand=True)
        self.log(f"{APP_NAME} v{APP_VERSION} started. Config: {self.config_path}\n")

    def build_active_context_bar(self) -> None:
        bar = ttk.LabelFrame(self, text="Current Study")
        bar.pack(side="top", fill="x", padx=8, pady=(0, 4))
        self.context_workspace_var = tk.StringVar(value="Workspace: none")
        self.context_workflow_var = tk.StringVar(value="Choose protocol  →  Prepare materials  →  Connect equipment  →  Run session")
        ttk.Label(bar, textvariable=self.context_workspace_var, width=34).pack(side="left", padx=6, pady=4)
        ttk.Label(bar, textvariable=self.context_workflow_var, foreground="#1f4e79").pack(side="left", fill="x", expand=True, padx=6, pady=4)
        ttk.Button(bar, text="Refresh", command=self.refresh_all_context).pack(side="right", padx=3, pady=3)
        ttk.Button(bar, text="Open Workspace", command=self.open_study_workspace_ui).pack(side="right", padx=3, pady=3)
        ttk.Button(bar, text="New Workspace", command=self.create_study_workspace_ui).pack(side="right", padx=3, pady=3)

    def refresh_active_context_ui(self) -> None:
        if not hasattr(self, "context_workspace_var"):
            return
        self.sync_workspace_from_current_state()
        if self.active_workspace:
            session = self.active_workspace.get("current_session", {})
            self.context_workspace_var.set(
                f"{self.active_workspace.get('display_name', 'Study')} | Session {session.get('session_index', '?')}"
            )
            self.context_workflow_var.set(workflow_summary(self.active_workspace))
        else:
            self.context_workspace_var.set("Workspace: none — create or open one")
            self.context_workflow_var.set("Choose protocol → Prepare materials → Connect equipment → Confirm setup → Run → Review")
        self.update_analysis_button_states()
        self.refresh_workspace_ui()

    def save_active_workspace(self) -> None:
        if not self.active_workspace or not self.active_workspace_path:
            return
        self.active_workspace = save_workspace(self.active_workspace_path, self.active_workspace)
        self.active_analysis_plan = dict(self.active_workspace.get("analysis", {}).get("plan", {}) or {})

    def create_study_workspace_ui(self) -> None:
        name = (simpledialog.askstring("New Study Workspace", "Study display name:", parent=self) or "").strip()
        if not name:
            return
        try:
            path, workspace = create_workspace(Path(self.cfg["study_workspace_root"]), name)
            self.active_workspace_path, self.active_workspace = path, workspace
            self.active_analysis_plan = {}
            self.analysis_plan_selected_ids.clear()
            write_active_pointer(self.study_workspace_pointer_path, path)
            self.sync_workspace_from_current_state(force=True)
            self.refresh_workspace_ui()
            self.log(f"Created local Study Workspace: {path}\n")
        except Exception as exc:
            messagebox.showerror("Workspace creation failed", str(exc))

    def open_study_workspace_ui(self) -> None:
        value = filedialog.askopenfilename(
            title="Open PRAYCG Study Workspace",
            initialdir=str(self.cfg.get("study_workspace_root") or self.cfg["praycg_home"]),
            filetypes=(("Study workspace", "study_workspace.json"), ("JSON", "*.json")),
        )
        if not value:
            return
        try:
            path = Path(value).resolve()
            workspace = load_workspace(path)
            self.active_workspace_path, self.active_workspace = path, workspace
            self.active_analysis_plan = dict(workspace.get("analysis", {}).get("plan", {}) or {})
            self.analysis_plan_selected_ids = {
                str(row.get("module_id")) for row in self.active_analysis_plan.get("modules", []) if isinstance(row, dict)
            }
            write_active_pointer(self.study_workspace_pointer_path, path)
            self.refresh_workspace_ui()
            self.refresh_analysis_orchestration_ui()
            self.log(f"Opened Study Workspace: {path}\n")
        except Exception as exc:
            messagebox.showerror("Workspace rejected", str(exc))

    def close_study_workspace_ui(self) -> None:
        self.active_workspace_path = None
        self.active_workspace = None
        self.active_analysis_plan = {}
        self.analysis_plan_selected_ids.clear()
        write_active_pointer(self.study_workspace_pointer_path, None)
        self.refresh_workspace_ui()

    def start_new_workspace_session_ui(self) -> None:
        if not self.active_workspace:
            messagebox.showwarning("Workspace required", "Create or open a Study Workspace first.")
            return
        if not messagebox.askyesno(
            "Start a new session?",
            "This preserves all earlier session evidence, then clears session-bound arm, run, analysis-plan, review, and export state.",
        ):
            return
        self.active_workspace = start_new_session(self.active_workspace, reason="Operator started a new session in Control Center alpha.8.4.2.")
        self.active_analysis_plan = {}
        self.analysis_plan_selected_ids.clear()
        self.save_active_workspace()
        self.refresh_workspace_ui()

    def open_active_workspace_folder(self) -> None:
        if self.active_workspace_path:
            open_path(self.active_workspace_path.parent)
        else:
            messagebox.showinfo("No workspace", "Create or open a Study Workspace first.")

    @staticmethod
    def _workspace_file_record(path_value: str, kind: str) -> Dict[str, Any]:
        value = str(path_value or "").strip()
        if not value:
            return {}
        path = Path(value).expanduser().resolve(strict=False)
        record: Dict[str, Any] = {"kind": kind, "path": str(path), "exists": path.exists()}
        if path.is_file() and not path.is_symlink():
            record["sha256"] = sha256_file(path)
            record["byte_count"] = path.stat().st_size
        return record

    def sync_workspace_from_current_state(self, *, force: bool = False) -> None:
        """Persist current governed selections without granting authority or deleting evidence."""
        if not self.active_workspace or not self.active_workspace_path or self._workspace_sync_in_progress:
            return
        self._workspace_sync_in_progress = True
        changed_any = False
        try:
            protocol: Dict[str, Any] = {}
            if self.locked_protocol:
                protocol = {
                    "protocol_id": self.locked_protocol.get("protocol_id"),
                    "protocol_version": self.locked_protocol.get("protocol_version") or self.locked_protocol.get("version"),
                    "display_name": self.locked_protocol.get("display_name"),
                    "module_family": self.locked_protocol.get("module_family"),
                    "engine_family": self.locked_protocol.get("engine_family"),
                    "lock_artifact": self._workspace_file_record(str(self.protocol_lock_path), "PROTOCOL_LOCK"),
                    "module_sha256": self.locked_protocol.get("module_sha256") or self.locked_protocol.get("canonical_sha256"),
                }
            if protocol:
                self.active_workspace, changed = bind_workspace_component(
                    self.active_workspace, "protocol", protocol, reason="Control Center synchronized the validated protocol lock."
                )
                changed_any |= changed

            stimulus_source = self.active_context.get("stimulus", {})
            stimulus = dict(stimulus_source) if stimulus_source.get("folder") else {}
            if stimulus:
                self.active_workspace, changed = bind_workspace_component(
                    self.active_workspace, "stimulus", stimulus, reason="Control Center synchronized the selected stimulus package and provenance."
                )
                changed_any |= changed

            hardware: Dict[str, Any] = {}
            if self.hardware_ui_lock or self.active_hardware_profile:
                acquisition = self.cfg.get("acquisition", {})
                hardware = {
                    "profile_id": (self.active_hardware_profile or {}).get("profile_id"),
                    "profile_canonical_sha256": (self.active_hardware_profile or {}).get("canonical_sha256"),
                    "profile_path": self._workspace_file_record(str(acquisition.get("hardware_profile_path") or ""), "HARDWARE_PROFILE"),
                    "ui_lock_path": self._workspace_file_record(str(acquisition.get("hardware_ui_lock_path") or ""), "HARDWARE_UI_LOCK"),
                    "readiness_status": acquisition.get("readiness_status"),
                    "validation_evidence": self._workspace_file_record(str(acquisition.get("profile_preflight_report_path") or ""), "PREFLIGHT_REPORT"),
                }
            if hardware:
                self.active_workspace, changed = bind_workspace_component(
                    self.active_workspace, "hardware", hardware, reason="Control Center synchronized the reviewed hardware profile."
                )
                changed_any |= changed

            acquisition = self.cfg.get("acquisition", {})
            runner: Dict[str, Any] = {}
            session_lock = str(acquisition.get("session_lock_path") or "")
            if acquisition.get("armed") or acquisition.get("session_lock_status") not in {None, "", "NOT_LOCKED"}:
                runner = {
                    "armed": bool(acquisition.get("armed")),
                    "session_lock_status": acquisition.get("session_lock_status"),
                    "readiness_status": acquisition.get("readiness_status"),
                    "session_lock": self._workspace_file_record(session_lock, "SESSION_LOCK"),
                    "runner_launch_mode": self.cfg.get("runner_launch_mode"),
                }
            if runner:
                self.active_workspace, changed = bind_workspace_component(
                    self.active_workspace, "runner", runner, reason="Control Center synchronized the independent runner/arm state."
                )
                changed_any |= changed

            run = self.active_context.get("run", {})
            if run.get("folder"):
                self.active_workspace, changed = workspace_record_run(
                    self.active_workspace, run, reason="Control Center recorded the selected completed-run folder."
                )
                changed_any |= changed
            outputs = []
            for kind in ("core", "chain"):
                row = self.active_context.get("analysis", {}).get(kind, {})
                if row.get("status") == "RESOLVED" and row.get("path"):
                    outputs.append({"kind": kind.upper(), "path": row.get("path"), "source": row.get("source")})
            if outputs:
                preserved = [dict(row) for row in self.active_workspace.get("analysis", {}).get("outputs", []) if isinstance(row, dict)]
                seen_paths = {str(row.get("path") or "").casefold() for row in preserved}
                preserved.extend(row for row in outputs if str(row.get("path") or "").casefold() not in seen_paths)
                self.active_workspace, changed = workspace_record_analysis_outputs(
                    self.active_workspace, preserved, reason="Control Center recorded resolved analysis outputs without deleting earlier evidence."
                )
                changed_any |= changed
            if changed_any or force:
                self.save_active_workspace()
        except Exception as exc:
            self.log(f"Study Workspace synchronization caution: {type(exc).__name__}: {exc}\n")
        finally:
            self._workspace_sync_in_progress = False

    def clear_workspace_component(self, component: str, reason: str) -> None:
        if not self.active_workspace:
            return
        try:
            self.active_workspace, changed = bind_workspace_component(
                self.active_workspace, component, {}, reason=reason
            )
            if changed:
                self.save_active_workspace()
        except Exception as exc:
            self.log(f"Workspace component-clear caution: {type(exc).__name__}: {exc}\n")

    def refresh_workspace_ui(self) -> None:
        if not hasattr(self, "workspace_summary_var"):
            return
        if not self.active_workspace:
            self.workspace_summary_var.set("No active Study Workspace. Create or open one before binding a study lifecycle.")
            for stage, variable in self.workspace_stage_vars.items():
                variable.set(f"{OPERATOR_WORKFLOW_LABELS.get(stage, WORKFLOW_LABELS[stage])}\n{'READY' if stage == 'protocol' else 'NOT STARTED'}")
            self.workspace_next_var.set("Next: create or open a local Study Workspace.")
            return
        session = self.active_workspace.get("current_session", {})
        self.workspace_summary_var.set(
            f"{self.active_workspace.get('display_name')} | Study {str(self.active_workspace.get('study_id'))[:8]}… | "
            f"Session {session.get('session_index')} ({str(session.get('session_id'))[:8]}…) | local-only provenance record"
        )
        for stage, variable in self.workspace_stage_vars.items():
            status = self.active_workspace.get("workflow", {}).get(stage, {}).get("status", "NOT_STARTED")
            variable.set(f"{OPERATOR_WORKFLOW_LABELS.get(stage, WORKFLOW_LABELS[stage])}\n{status.replace('_', ' ')}")
        stage, reason = workspace_next_action(self.active_workspace)
        self.workspace_next_var.set(f"Next: {OPERATOR_WORKFLOW_LABELS.get(stage, WORKFLOW_LABELS.get(stage, stage))} — {reason}")

    def tool_is_ready(self, name: str) -> bool:
        return self.active_context.get("readiness", {}).get(name, {}).get("status") == "READY"

    def require_tool_ready(self, name: str, title: str) -> bool:
        record = self.active_context.get("readiness", {}).get(name, {})
        if record.get("status") == "READY":
            return True
        messagebox.showwarning(title, record.get("message") or "The active research context is not ready for this tool.")
        return False

    def log(self, msg: str) -> None:
        if hasattr(self, "logbox"):
            self.logbox.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
        else:
            print(msg, end="")

    def build_dashboard_tab(self) -> None:
        f = self.dashboard_tab
        procs = ttk.LabelFrame(f, text="Running Tools - each row controls only that launched tool")
        procs.pack(side="bottom", fill="x", padx=8, pady=8)
        workspace = ttk.LabelFrame(f, text="Guided Session Workflow")
        workspace.pack(side="top", fill="x", padx=8, pady=(8, 3))
        self.workspace_summary_var = tk.StringVar(value="No active Study Workspace.")
        ttk.Label(workspace, textvariable=self.workspace_summary_var, foreground="#1f4e79").pack(side="top", fill="x", padx=6, pady=(5, 2))
        workspace_actions = ttk.Frame(workspace); workspace_actions.pack(fill="x", padx=3, pady=2)
        ttk.Button(workspace_actions, text="New", command=self.create_study_workspace_ui).pack(side="left", padx=3)
        ttk.Button(workspace_actions, text="Open", command=self.open_study_workspace_ui).pack(side="left", padx=3)
        ttk.Button(workspace_actions, text="New Session", command=self.start_new_workspace_session_ui).pack(side="left", padx=3)
        ttk.Button(workspace_actions, text="Open Folder", command=self.open_active_workspace_folder).pack(side="left", padx=3)
        ttk.Button(workspace_actions, text="Close Workspace", command=self.close_study_workspace_ui).pack(side="left", padx=3)
        ttk.Label(
            workspace_actions,
            text="Follow the steps from left to right. Technical records remain available in the detailed views.",
            foreground="#704000",
        ).pack(side="right", padx=4)
        stage_frame = ttk.Frame(workspace); stage_frame.pack(fill="x", padx=4, pady=(2, 3))
        self.workspace_stage_vars: Dict[str, tk.StringVar] = {}
        stage_commands = {
            "protocol": lambda: self.nb.select(self.protocol_tab),
            "stimuli": lambda: self.nb.select(self.stim_tab),
            "hardware": lambda: self.nb.select(self.acq_tab),
            "arm": lambda: (self.nb.select(self.acq_tab), self.acq_nb.select(4)),
            "run": lambda: self.nb.select(self.runner_tab),
            "qc": lambda: (self.nb.select(self.analysis_tab), self.analysis_nb.select(0)),
            "analyze": lambda: (self.nb.select(self.analysis_tab), self.analysis_nb.select(0)),
            "review": lambda: (self.nb.select(self.analysis_tab), self.analysis_nb.select(2)),
            "export": lambda: (self.nb.select(self.analysis_tab), self.analysis_nb.select(2)),
        }
        for column, stage in enumerate(WORKFLOW_STAGES):
            stage_frame.columnconfigure(column, weight=1)
            variable = tk.StringVar(value=f"{OPERATOR_WORKFLOW_LABELS.get(stage, WORKFLOW_LABELS[stage])}\nNOT STARTED")
            self.workspace_stage_vars[stage] = variable
            ttk.Button(stage_frame, textvariable=variable, command=stage_commands[stage]).grid(
                row=0, column=column, sticky="ew", padx=2, pady=2
            )
        self.workspace_next_var = tk.StringVar(value="Next: create or open a local Study Workspace.")
        ttk.Label(workspace, textvariable=self.workspace_next_var, wraplength=1100, foreground="#333333").pack(fill="x", padx=6, pady=(0, 5))
        overview = ttk.Panedwindow(f, orient="horizontal")
        overview.pack(side="top", fill="both", expand=True, padx=8, pady=3)
        left = ttk.Frame(overview); right = ttk.Frame(overview)
        overview.add(left, weight=1); overview.add(right, weight=1)
        ttk.Label(left, text="Workflow Shortcuts", font=("Segoe UI", 14, "bold")).pack(anchor="w")
        buttons = [
            ("1. Choose Protocol", lambda: self.nb.select(self.protocol_tab)),
            ("2. Prepare Protocol Materials", lambda: self.nb.select(self.stim_tab)),
            ("3. Connect & Check Equipment", lambda: self.nb.select(self.acq_tab)),
            ("4. Run Session", lambda: self.nb.select(self.runner_tab)),
            ("5. Review Results", lambda: (self.nb.select(self.analysis_tab), self.analysis_nb.select(2))),
            ("Advanced Analysis Plan", lambda: (self.nb.select(self.analysis_tab), self.analysis_nb.select(0))),
            ("Advanced Direct Tools", lambda: (self.nb.select(self.analysis_tab), self.analysis_nb.select(1))),
        ]
        for txt, cmd in buttons:
            ttk.Button(left, text=txt, command=cmd).pack(fill="x", pady=4)

        ttk.Label(right, text="Readiness Details", font=("Segoe UI", 14, "bold")).pack(anchor="w")
        self.status_text = tk.Text(right, height=20, wrap="word")
        self.status_text.pack(fill="both", expand=True)
        ttk.Button(right, text="Refresh Status", command=self.refresh_dashboard).pack(fill="x", pady=4)

        header = ttk.Frame(procs)
        header.pack(fill="x", padx=4, pady=(4, 0))
        for col, text, weight in [(0, "Tool", 4), (1, "PID", 1), (2, "Status", 1), (3, "Runtime", 1), (4, "Log", 1), (5, "Close", 1), (6, "More", 1)]:
            header.columnconfigure(col, weight=weight)
            ttk.Label(header, text=text, font=("Segoe UI", 9, "bold")).grid(row=0, column=col, sticky="w", padx=3)
        body = ttk.Frame(procs)
        body.pack(fill="both", expand=True, padx=4, pady=3)
        self.proc_canvas = tk.Canvas(body, height=165, highlightthickness=0)
        proc_scroll = ttk.Scrollbar(body, orient="vertical", command=self.proc_canvas.yview)
        self.proc_canvas.configure(yscrollcommand=proc_scroll.set)
        self.proc_canvas.pack(side="left", fill="both", expand=True)
        proc_scroll.pack(side="right", fill="y")
        self.proc_rows_frame = ttk.Frame(self.proc_canvas)
        self.proc_rows_window = self.proc_canvas.create_window((0, 0), window=self.proc_rows_frame, anchor="nw")
        self.proc_rows_frame.bind("<Configure>", lambda _event: self.proc_canvas.configure(scrollregion=self.proc_canvas.bbox("all")))
        self.proc_canvas.bind("<Configure>", lambda event: self.proc_canvas.itemconfigure(self.proc_rows_window, width=event.width))
        self.selected_proc_key_var = tk.StringVar(value="")
        self.selected_tool_var = tk.StringVar(value="No tool selected")
        footer = ttk.Frame(procs); footer.pack(fill="x", padx=4, pady=(0, 4))
        ttk.Label(footer, textvariable=self.selected_tool_var).pack(side="left", fill="x", expand=True)
        ttk.Button(footer, text="Clear Exited", command=self.clear_exited_processes).pack(side="right", padx=3)
        ttk.Button(footer, text="Refresh Tools", command=lambda: self.update_process_tree(force=True)).pack(side="right", padx=3)
        self.update_process_tree()

    def build_stimulus_tab(self) -> None:
        f = self.stim_tab
        self.stimulus_workflow_var = tk.StringVar(value="Choose a protocol first. This page will then show only the materials it can use.")
        ttk.Label(
            f,
            textvariable=self.stimulus_workflow_var,
            foreground="#1f4e79",
            wraplength=1080,
        ).pack(fill="x", padx=10, pady=(8, 2))

        atlas_assets = ttk.LabelFrame(f, text="Required Protocol Files")
        atlas_assets.pack(fill="x", padx=8, pady=(4, 2))
        self.protocol_asset_summary_var = tk.StringVar(value="Choose a protocol to see what files are needed.")
        ttk.Label(
            atlas_assets,
            textvariable=self.protocol_asset_summary_var,
            wraplength=1040,
            foreground="#1f4e79",
        ).pack(fill="x", padx=6, pady=(5, 2))
        asset_body = ttk.Frame(atlas_assets)
        asset_body.pack(fill="x", padx=5, pady=(0, 3))
        self.protocol_asset_canvas = tk.Canvas(asset_body, height=145, highlightthickness=0)
        asset_scroll = ttk.Scrollbar(asset_body, orient="vertical", command=self.protocol_asset_canvas.yview)
        self.protocol_asset_canvas.configure(yscrollcommand=asset_scroll.set)
        self.protocol_asset_canvas.pack(side="left", fill="x", expand=True)
        asset_scroll.pack(side="right", fill="y")
        self.protocol_asset_rows_frame = ttk.Frame(self.protocol_asset_canvas)
        self.protocol_asset_rows_window = self.protocol_asset_canvas.create_window(
            (0, 0), window=self.protocol_asset_rows_frame, anchor="nw"
        )
        self.protocol_asset_rows_frame.bind(
            "<Configure>",
            lambda _event: self.protocol_asset_canvas.configure(scrollregion=self.protocol_asset_canvas.bbox("all")),
        )
        self.protocol_asset_canvas.bind(
            "<Configure>",
            lambda event: self.protocol_asset_canvas.itemconfigure(self.protocol_asset_rows_window, width=event.width),
        )
        self.protocol_asset_binding_vars: Dict[str, tk.StringVar] = {}
        self.continue_to_equipment_button = ttk.Button(
            atlas_assets,
            text="Continue to Connect & Check Equipment →",
            command=lambda: self.nb.select(self.acq_tab),
        )
        self.continue_to_equipment_button.pack(fill="x", padx=5, pady=(1, 5))

        top = ttk.Frame(f); top.pack(fill="x", padx=8, pady=(4, 2))
        ttk.Button(top, text="Refresh Compatible Assets", command=self.refresh_protocol_stimulus_ui).pack(side="left", padx=4)
        ttk.Button(top, text="Add Master PRAYCG Stimulus (.mp4)", command=self.add_master_stimulus).pack(side="left", padx=4)
        ttk.Button(top, text="Revalidate & Tag Existing Masters", command=self.migrate_legacy_master_stimuli).pack(side="left", padx=4)
        self.stimulus_use_button = ttk.Button(top, text="Use / Install Selected", command=self.use_selected_compatible_stimulus)
        self.stimulus_use_button.pack(side="left", padx=4)
        ttk.Button(top, text="Open Selected Folder", command=self.open_selected_stimulus_candidate).pack(side="left", padx=4)
        ttk.Button(top, text="Open Stimulus Root", command=lambda: open_path(Path(self.cfg["stimulus_root"]))).pack(side="left", padx=4)

        mid = ttk.Panedwindow(f, orient="horizontal"); mid.pack(fill="both", expand=True, padx=8, pady=4)
        lframe = ttk.LabelFrame(mid, text="Compatible Prepared Materials")
        rframe = ttk.LabelFrame(mid, text="Optional Preparation Tools")
        mid.add(lframe, weight=3); mid.add(rframe, weight=4)
        self.stim_tree = ttk.Treeview(
            lframe,
            columns=("source", "status", "use"),
            show="tree headings",
            selectmode="browse",
        )
        self.stim_tree.heading("#0", text="Folder / Stimulus")
        self.stim_tree.column("#0", width=300, stretch=True)
        for col, title, width in [("source", "Source", 135), ("status", "Validation", 120), ("use", "Research use", 115)]:
            self.stim_tree.heading(col, text=title); self.stim_tree.column(col, width=width)
        self.stim_tree.pack(side="left", fill="both", expand=True, padx=(5, 0), pady=5)
        stim_scroll = ttk.Scrollbar(lframe, orient="vertical", command=self.stim_tree.yview)
        self.stim_tree.configure(yscrollcommand=stim_scroll.set)
        stim_scroll.pack(side="right", fill="y", padx=(0, 5), pady=5)
        self.stim_tree.bind("<<TreeviewSelect>>", self.on_stim_select)
        self.stim_detail = tk.Text(rframe, wrap="word", height=12)
        self.stim_detail.pack(fill="both", expand=True, padx=5, pady=5)
        self.stimulus_prep_summary_var = tk.StringVar(value="Protocol-specific Forge choices appear after a protocol is locked.")
        ttk.Label(rframe, textvariable=self.stimulus_prep_summary_var, wraplength=610, foreground="#555555").pack(fill="x", padx=6, pady=(0, 3))
        self.stimulus_prep_buttons_frame = ttk.Frame(rframe)
        self.stimulus_prep_buttons_frame.pack(fill="x", padx=5, pady=(0, 5))

        # Kept for config/backward compatibility. Alpha.7's operator surface
        # uses one named binding per declared protocol input instead.
        self.protocol_asset_folder_var = tk.StringVar(value="")

        ttk.Label(
            f,
            text=(
                "Bundled samples are displayed directly and remain DEMO_ONLY. Installing creates a working copy; it does not promote scientific status. "
                "Only exact, live-validated compatibility rows are shown after protocol lock."
            ),
            foreground="#7a1e1e",
            wraplength=1060,
        ).pack(fill="x", padx=10, pady=(0, 7))
        self.refresh_protocol_stimulus_ui()

    def build_acquisition_tab(self) -> None:
        f = self.acq_tab
        ttk.Label(
            f,
            text=(
                "All hardware work happens here in one order: select and validate devices, create and lock a profile, "
                "launch only that profile's streams, inspect live signals, then record and arm."
            ),
            foreground="#1f4e79",
            wraplength=1080,
        ).pack(fill="x", padx=10, pady=(8, 2))
        self.acq_nb = ttk.Notebook(f)
        self.acq_nb.pack(fill="both", expand=True, padx=8, pady=4)
        catalog_tab = ttk.Frame(self.acq_nb); self.acq_nb.add(catalog_tab, text="1. Hardware Selection")
        profile_tab = ttk.Frame(self.acq_nb); self.acq_nb.add(profile_tab, text="2. Hardware Profile")
        launch_tab = ttk.Frame(self.acq_nb); self.acq_nb.add(launch_tab, text="3. Connect & Launch")
        checks_tab = ttk.Frame(self.acq_nb); self.acq_nb.add(checks_tab, text="4. Live Checks")
        monitor_tab = ttk.Frame(self.acq_nb); self.acq_nb.add(monitor_tab, text="5. Monitor, Record & Arm")

        catalog_actions = ttk.Frame(catalog_tab); catalog_actions.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Button(catalog_actions, text="Open Hardware Forge", command=self.launch_hardware_forge).pack(side="left", padx=4)
        ttk.Button(catalog_actions, text="Discover Existing LSL", command=self.launch_generic_lsl_intake).pack(side="left", padx=4)
        ttk.Button(catalog_actions, text="EDA/PPG Profile Wizard", command=self.launch_generic_eda_ppg_profile_wizard).pack(side="left", padx=4)
        ttk.Button(catalog_actions, text="EDA/PPG Simulator", command=self.launch_generic_eda_ppg_simulator).pack(side="left", padx=4)
        ttk.Button(catalog_actions, text="Refresh Hardware Library", command=self.refresh_hardware_selection_ui).pack(side="left", padx=4)
        ttk.Button(catalog_actions, text="Open Reviewed Module Definitions", command=lambda: open_path(self.hardware_registry_root)).pack(side="left", padx=4)
        ttk.Label(
            catalog_tab,
            text=(
                "Expand EEG, Heart rate / ECG, Respiration, EDA / PPG, EMG, EOG, ALS / markers, or Auxiliary. "
                "Validate one exact choice for each needed role. Catalog entries remain visible, but only profile-eligible definitions enter the validated tray."
            ),
            foreground="#7a1e1e",
            wraplength=1040,
        ).pack(fill="x", padx=12, pady=4)
        hardware_panes = ttk.Panedwindow(catalog_tab, orient="horizontal")
        hardware_panes.pack(fill="both", expand=True, padx=8, pady=(2, 4))
        hardware_library = ttk.LabelFrame(hardware_panes, text="Hardware Library")
        hardware_detail = ttk.LabelFrame(hardware_panes, text="Selected Hardware and Validation")
        hardware_panes.add(hardware_library, weight=3)
        hardware_panes.add(hardware_detail, weight=2)
        self.hardware_selection_tree = ttk.Treeview(
            hardware_library,
            columns=("admission", "physical", "source"),
            show="tree headings",
            selectmode="browse",
            height=11,
        )
        self.hardware_selection_tree.heading("#0", text="Role / Device / Route")
        self.hardware_selection_tree.column("#0", width=330, stretch=True)
        for column, title, width in (
            ("admission", "Admission", 155),
            ("physical", "Physical test", 125),
            ("source", "Source", 125),
        ):
            self.hardware_selection_tree.heading(column, text=title)
            self.hardware_selection_tree.column(column, width=width)
        self.hardware_selection_tree.pack(side="left", fill="both", expand=True, padx=(5, 0), pady=5)
        hardware_scroll = ttk.Scrollbar(hardware_library, orient="vertical", command=self.hardware_selection_tree.yview)
        self.hardware_selection_tree.configure(yscrollcommand=hardware_scroll.set)
        hardware_scroll.pack(side="right", fill="y", padx=(0, 5), pady=5)
        self.hardware_selection_tree.bind("<<TreeviewSelect>>", self.on_hardware_tree_selected)
        self.hardware_selection_detail = tk.Text(hardware_detail, wrap="word", height=10)
        self.hardware_selection_detail.pack(fill="both", expand=True, padx=5, pady=5)
        ttk.Button(hardware_detail, text="Validate and Add Selected Device", command=self.validate_selected_hardware).pack(fill="x", padx=5, pady=2)
        ttk.Button(hardware_detail, text="Remove Selected Role from Tray", command=self.remove_selected_hardware_role).pack(fill="x", padx=5, pady=2)
        ttk.Button(hardware_detail, text="Clear Validated Tray", command=self.clear_validated_hardware_tray).pack(fill="x", padx=5, pady=(2, 5))

        tray = ttk.LabelFrame(catalog_tab, text="Validated Hardware Selections — one row per device")
        tray.pack(fill="x", padx=8, pady=(2, 8))
        self.hardware_validated_tree = ttk.Treeview(tray, columns=("roles", "provides", "status"), show="tree headings", height=4)
        self.hardware_validated_tree.heading("#0", text="Validated module")
        self.hardware_validated_tree.column("#0", width=300)
        for column, title, width in (("roles", "Selected for", 220), ("provides", "Provides", 360), ("status", "Definition check", 120)):
            self.hardware_validated_tree.heading(column, text=title)
            self.hardware_validated_tree.column(column, width=width)
        self.hardware_validated_tree.pack(side="left", fill="x", expand=True, padx=5, pady=5)
        ttk.Button(tray, text="Create Hardware Profile →", command=self.create_hardware_profile_draft).pack(side="right", fill="y", padx=5, pady=5)

        profile_intro = ttk.LabelFrame(profile_tab, text="Build and Lock a Hardware Profile")
        profile_intro.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Label(
            profile_intro,
            text=(
                "A profile is created only from selections that passed the definition/admission check on Step 1. "
                "Reviewing records responsibility; locking freezes the exact profile for the Connect & Launch buttons. "
                "Live-device preflight and ARM remain separate later gates."
            ),
            wraplength=1020,
        ).pack(fill="x", padx=6, pady=5)
        draft = ttk.LabelFrame(profile_tab, text="Profile draft from validated selections")
        draft.pack(fill="x", padx=8, pady=4)
        self.hardware_profile_draft_path_var = tk.StringVar(value=str(self.cfg.get("acquisition", {}).get("hardware_profile_draft_path") or ""))
        ttk.Entry(draft, textvariable=self.hardware_profile_draft_path_var).pack(fill="x", padx=6, pady=(5, 2))
        draft_actions = ttk.Frame(draft); draft_actions.pack(fill="x", padx=6, pady=(2, 5))
        ttk.Button(draft_actions, text="Create / Refresh Draft from Validated Tray", command=self.create_hardware_profile_draft).pack(side="left", padx=(0, 4))
        ttk.Button(draft_actions, text="Review, Approve, and Lock Draft", command=self.review_and_lock_hardware_profile_draft).pack(side="left", padx=4)
        self.hardware_profile_draft_status_var = tk.StringVar(value="No new draft created in this session.")
        ttk.Label(draft, textvariable=self.hardware_profile_draft_status_var, wraplength=1020, foreground="#555555").pack(anchor="w", padx=6, pady=(0, 5))

        active = ttk.LabelFrame(profile_tab, text="Active reviewed and UI-locked profile")
        active.pack(fill="both", expand=True, padx=8, pady=(4, 8))
        self.hardware_profile_path_var = tk.StringVar(value=str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or ""))
        ttk.Entry(active, textvariable=self.hardware_profile_path_var).pack(fill="x", padx=6, pady=(5, 2))
        active_actions = ttk.Frame(active); active_actions.pack(fill="x", padx=6, pady=2)
        ttk.Button(active_actions, text="Load Existing Reviewed Profile", command=self.choose_active_hardware_profile).pack(side="left", padx=(0, 4))
        ttk.Button(active_actions, text="Lock Active Profile for Connect & Launch", command=self.lock_active_hardware_profile_for_launch).pack(side="left", padx=4)
        ttk.Button(active_actions, text="Open Profile Folder", command=self.open_active_hardware_profile_folder).pack(side="left", padx=4)
        self.hardware_profile_status_var = tk.StringVar(value="No active reviewed hardware profile loaded.")
        ttk.Label(active, textvariable=self.hardware_profile_status_var, wraplength=1020, foreground="#7a1e1e").pack(anchor="w", padx=6, pady=2)
        self.hardware_profile_text = tk.Text(active, height=7, wrap="word")
        self.hardware_profile_text.pack(fill="both", expand=True, padx=6, pady=(2, 6))

        self.acquisition_session_button = ttk.Button(
            launch_tab,
            text="Start New Equipment Session",
            command=self.begin_acquisition_session,
        )
        self.acquisition_session_button.pack(fill="x", padx=8, pady=(8, 3))
        self.acquisition_session_var = tk.StringVar(
            value="NO ACTIVE SESSION — start here before launching equipment streams."
        )
        ttk.Label(
            launch_tab,
            textvariable=self.acquisition_session_var,
            foreground="#7a1e1e",
            font=("Segoe UI", 10, "bold"),
            wraplength=1040,
        ).pack(fill="x", padx=12, pady=(0, 2))
        ttk.Label(
            launch_tab,
            text=(
                "This creates a new run ID and evidence folder. Streams launched from this page are tagged with that ID, "
                "so an older or separately launched bridge cannot accidentally satisfy this session's checks."
            ),
            foreground="#555555",
            wraplength=1040,
        ).pack(fill="x", padx=12, pady=(0, 4))
        launch = ttk.LabelFrame(launch_tab, text="Streams in the locked hardware profile")
        launch.pack(fill="both", expand=True, padx=8, pady=4)
        self.hardware_launch_status_var = tk.StringVar(value="Lock an active reviewed profile on Step 2 to generate exact launch controls.")
        ttk.Label(launch, textvariable=self.hardware_launch_status_var, wraplength=1000, foreground="#555555").pack(fill="x", padx=6, pady=6)
        self.hardware_launch_frame = ttk.Frame(launch)
        self.hardware_launch_frame.pack(fill="x", padx=6, pady=4)
        self.hardware_launch_buttons: Dict[str, Any] = {}
        ttk.Label(
            launch_tab,
            text=(
                "One button represents one bridge process, even when that bridge publishes several streams. "
                "Modules without an exact reviewed launcher are reported, never guessed. Start streams before live checks; only one program may own an OpenBCI serial port at a time."
            ),
            foreground="#7a1e1e",
            wraplength=1040,
        ).pack(anchor="w", padx=12, pady=6)

        controls = ttk.LabelFrame(checks_tab, text="Live checks")
        controls.pack(fill="x", padx=8, pady=(8, 4))
        self.hardware_check_buttons: Dict[str, ttk.Button] = {}
        check_defs = [
            ("always", "Refresh Visible LSL Streams", self.populate_lsl_tree),
            ("always", "Open Live Stream Monitor", self.open_live_stream_monitor),
            ("eeg", "EEG Signal Quality / Contact 0–100", self.run_signal_quality),
            ("als", "ALS Barcode Placement Test", self.run_als_test),
            ("als", "ALS Holder Calibration", self.run_als_holder_calibration),
        ]
        for index, (role, label, command) in enumerate(check_defs):
            button = ttk.Button(controls, text=label, command=command)
            button.grid(row=index // 3, column=index % 3, sticky="ew", padx=4, pady=4)
            self.hardware_check_buttons[f"{role}:{index}"] = button
            controls.columnconfigure(index % 3, weight=1)

        right = ttk.LabelFrame(checks_tab, text="Expected and visible LSL streams")
        right.pack(fill="both", expand=True, padx=8, pady=(4, 8))
        self.lsl_tree = ttk.Treeview(right, columns=("name","type","ch","srate","session","source"), show="headings", height=8)
        for col, width in [("name",200),("type",105),("ch",50),("srate",85),("session",250),("source",310)]:
            self.lsl_tree.heading(col, text=col); self.lsl_tree.column(col, width=width)
        self.lsl_tree.pack(fill="both", expand=True)
        self.expected_streams_var = tk.StringVar(value="Expected by active profile: none")
        ttk.Label(right, textvariable=self.expected_streams_var, wraplength=1020, foreground="#555555").pack(anchor="w", padx=5, pady=4)
        ttk.Label(
            right,
            text=(
                "The live monitor shows current values and recent delivery rate: EEG rate and rolling channel quality; "
                "Polar RR/BPM/RMSSD; Vernier belt force in newtons; and raw/relative ALS light load."
            ),
            wraplength=1020,
            foreground="#1f4e79",
        ).pack(anchor="w", padx=5, pady=(0, 5))

        readiness_box = ttk.LabelFrame(monitor_tab, text="Readiness and staged session gate")
        readiness_box.pack(fill="x", padx=8, pady=(8, 4))
        self.acq_readiness_var = tk.StringVar(value="READINESS: checking…")
        ttk.Label(readiness_box, textvariable=self.acq_readiness_var, font=("Segoe UI", 11, "bold"), wraplength=1020).pack(anchor="w", padx=6, pady=4)
        self.acq_gate_var = tk.StringVar(value="PROFILE — | PREFLIGHT — | PROTOCOL — | SESSION LOCK — | ARM —")
        ttk.Label(readiness_box, textvariable=self.acq_gate_var, foreground="#1f4e79", wraplength=1020).pack(anchor="w", padx=6, pady=(0, 4))
        arm_row = ttk.Frame(readiness_box); arm_row.pack(fill="x", padx=6, pady=(0, 6))
        self.acq_session_lock_button = ttk.Button(arm_row, text="Confirm Session Setup", command=self.create_acquisition_session_lock)
        self.acq_session_lock_button.pack(side="left", padx=(0, 4))
        self.acq_arm_button = ttk.Button(arm_row, text="Mark Ready to Run", command=self.arm_acquisition_session)
        self.acq_arm_button.pack(side="left", padx=4)
        ttk.Button(arm_row, text="Disarm", command=self.disarm_acquisition_session).pack(side="left", padx=4)
        ttk.Button(arm_row, text="Refresh Readiness", command=self.refresh_acquisition_readiness).pack(side="left", padx=4)
        self.bench_test_mode_var = tk.BooleanVar(value=bool(self.cfg.get("acquisition", {}).get("bench_test_mode")))
        ttk.Checkbutton(
            arm_row,
            text="Bench Test Mode (no participant)",
            variable=self.bench_test_mode_var,
            command=self.toggle_bench_test_mode,
        ).pack(side="right", padx=(12, 0))
        self.bench_test_status_var = tk.StringVar(value="Participant safeguards active")
        ttk.Label(
            readiness_box,
            textvariable=self.bench_test_status_var,
            foreground="#7a1e1e",
            wraplength=1020,
        ).pack(anchor="w", padx=6, pady=(0, 4))

        monitor_controls = ttk.LabelFrame(monitor_tab, text="Preflight, observation, and recording")
        monitor_controls.pack(fill="x", padx=8, pady=4)
        monitor_defs = [
            ("Run Required 30-Second Equipment Check", self.run_profile_preflight),
            ("Observe Stream Stability for 30 Seconds", self.run_acquisition_supervisor),
            ("Contract-Bound Drift / Sync Observation", self.run_contract_acquisition_supervisor),
            ("Open LabRecorder", self.launch_labrecorder),
            ("Open Latest Reports", self.open_acquisition_reports),
            ("Open Confirmed Session Setup", self.open_active_session_lock),
            ("View / Stop Running Tools", lambda: self.nb.select(self.dashboard_tab)),
        ]
        for index, (label, command) in enumerate(monitor_defs):
            ttk.Button(monitor_controls, text=label, command=command).grid(row=index // 3, column=index % 3, sticky="ew", padx=4, pady=4)
            monitor_controls.columnconfigure(index % 3, weight=1)
        ttk.Label(
            monitor_tab,
            text=(
                "The required 30-second check samples every stream in the locked profile and produces the readiness evidence. "
                "The Alpha 9 contract-bound observer additionally verifies exact outlet identity, ordered channel metadata, drift, jitter, LSL clock corrections, and UID continuity for a selected duration. "
                "Both observers are optional and read-only: they never repair, lock, or arm anything. "
                "Confirmed Session Setup opens the frozen JSON record created for the run. Participant acquisition still requires every live readiness check. "
                "Bench Test Mode bypasses live hardware, stream, timing, signal-quality, placement, and demo-only scientific-use qualifiers so software can be exercised without connected equipment. "
                "The selected protocol, materials, reviewed hardware definition, file identities, and session lock remain required, and every bench output is permanently labeled non-participant data."
            ),
            foreground="#7a1e1e",
            wraplength=1040,
        ).pack(anchor="w", padx=12, pady=6)

        self.refresh_hardware_selection_ui()
        self.load_active_hardware_profile(silent=True)
        self.load_hardware_ui_lock(silent=True)
        self.after(200, self.refresh_acquisition_readiness)

    def platform_core_available(self) -> bool:
        if not PLATFORM_CORE_IMPORT_ERROR and all(
            tool is not None
            for tool in (
                active_acquisition_owner_activity,
                active_acquisition_owner_path,
                advance_session_gate,
                bind_active_acquisition_owner_lease,
                bind_authorized_runner_lease_process,
                build_hardware_profile,
                build_session_draft,
                build_session_lock,
                finish_authorized_runner_lease,
                finish_active_acquisition_owner,
                claim_active_acquisition_owner,
                issue_authorized_runner_lease,
                load_platform_json,
                runtime_runner_lease_activity,
                platform_sha256_json,
                validate_hardware_module,
                validate_hardware_profile_identity,
                validate_protocol,
                validate_session_lock_identity,
            )
        ):
            return True
        messagebox.showerror(
            "Platform component unavailable",
            "The shared validation component could not be loaded. Reinstall or re-extract this alpha package.\n\n"
            f"Detail: {PLATFORM_CORE_IMPORT_ERROR or 'unknown import failure'}",
        )
        return False

    @staticmethod
    def hardware_profile_approved(profile: Optional[Dict[str, Any]]) -> bool:
        """Accept the canonical alpha.2 status and the read-only alpha.1 compatibility status."""
        if not profile:
            return False
        return bool(
            profile.get("status") in {"APPROVED", "LOCKABLE"}
            or profile.get("legacy_status") == "LOCKABLE"
        )

    def refresh_hardware_adapter_catalog_ui(self) -> None:
        """Render the package-owned adapter inventory without granting launch authority."""
        tree = getattr(self, "hardware_adapter_tree", None)
        if tree is None:
            return
        for item in tree.get_children():
            tree.delete(item)
        catalog_candidates = (
            self.pkg.parent / "config" / "hardware_adapter_catalog_v0_1.json",
            self.pkg.parent / "tools" / "Hardware_Forge_v0_1" / "config" / "hardware_adapter_catalog_v0_1.json",
        )
        catalog_path = next((path for path in catalog_candidates if path.is_file()), None)
        if catalog_path is None:
            self.hardware_adapter_detail_var.set("Adapter catalog is missing. Re-extract or validate the alpha.8 package.")
            return
        try:
            payload = json.loads(catalog_path.read_text(encoding="utf-8"))
            records = payload.get("adapters", payload.get("modules", []))
            if not isinstance(records, list):
                raise ValueError("catalog adapters must be an array")
            for record in records:
                if not isinstance(record, dict):
                    continue
                adapter_id = str(record.get("adapter_id") or record.get("id") or "")
                if not adapter_id:
                    continue
                routes = record.get("routes", []) if isinstance(record.get("routes"), list) else []
                route_label = ", ".join(
                    str(route.get("route_id") or "") for route in routes if isinstance(route, dict) and route.get("route_id")
                ) or str(record.get("route") or record.get("transport") or "unspecified")
                tree.insert(
                    "",
                    "end",
                    iid=adapter_id,
                    values=(
                        record.get("display_name") or adapter_id,
                        route_label,
                        record.get("classification") or record.get("category") or "CATALOG",
                        record.get("admission_level") or record.get("admission_state") or "CATALOG_ONLY",
                        "YES" if record.get("human_connected_launch_eligible") is True else "NO",
                    ),
                )
            self.hardware_adapter_detail_var.set(
                f"{len(tree.get_children())} adapter route(s) cataloged. Catalog: {catalog_path.name}. "
                "Use Hardware Forge for dependency checks, simulation, discovery, and draft generation."
            )
        except Exception as exc:
            self.hardware_adapter_detail_var.set(f"Adapter catalog could not be read: {exc}")

    def refresh_hardware_selection_ui(self) -> None:
        tree = getattr(self, "hardware_selection_tree", None)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        self.hardware_tree_rows_by_id = {}
        if self.hardware_workflow_model is None:
            detail = HARDWARE_WORKFLOW_IMPORT_ERROR or "The hardware workflow model could not be initialized."
            self.hardware_selection_detail.delete("1.0", "end")
            self.hardware_selection_detail.insert("end", detail)
            return
        try:
            self.hardware_workflow_model.refresh()
            rows = self.hardware_workflow_model.tree_rows()
        except Exception as exc:
            self.hardware_selection_detail.delete("1.0", "end")
            self.hardware_selection_detail.insert("end", f"Hardware library could not be loaded:\n{exc}")
            return
        inserted: set[str] = set()
        for row in rows:
            row_id = str(row.get("row_id") or "")
            if not row_id:
                continue
            parent = str(row.get("parent_id") or "")
            if parent and parent not in inserted:
                parent = ""
            source = {
                "ROLE_GROUP": "Category",
                "REVIEWED_MODULE": "Reviewed module",
                "ADAPTER": "Adapter catalog",
                "ADAPTER_ROUTE": "Draft route",
            }.get(str(row.get("row_kind")), str(row.get("row_kind") or ""))
            tree.insert(
                parent,
                "end",
                iid=row_id,
                text=row.get("label") or row_id,
                values=(row.get("admission_state") or "", row.get("physical_validation") or "", source),
                open=row.get("row_kind") == "ROLE_GROUP",
            )
            inserted.add(row_id)
            self.hardware_tree_rows_by_id[row_id] = dict(row)
        self.render_validated_hardware_tray()
        inventory = self.hardware_workflow_model.inventory
        self.hardware_selection_detail.delete("1.0", "end")
        self.hardware_selection_detail.insert(
            "end",
            f"Hardware library: {inventory.get('status')}\n"
            f"{len(inventory.get('choices', []))} exact module or route choice(s).\n\n"
            "Choose a row under the role you need, then select Validate and Add. Definition validation does not test a connected device.",
        )

    def on_hardware_tree_selected(self, _event: Any = None) -> None:
        selection = self.hardware_selection_tree.selection() if hasattr(self, "hardware_selection_tree") else ()
        if not selection:
            return
        row = self.hardware_tree_rows_by_id.get(selection[0], {})
        choice_id = str(row.get("choice_id") or "")
        detail: Dict[str, Any] = dict(row)
        if choice_id and self.hardware_workflow_model is not None:
            choice = next(
                (item for item in self.hardware_workflow_model.inventory.get("choices", []) if item.get("choice_id") == choice_id),
                None,
            )
            if isinstance(choice, dict):
                detail = choice
        self.hardware_selection_detail.delete("1.0", "end")
        self.hardware_selection_detail.insert("end", json.dumps(detail, indent=2))

    @staticmethod
    def hardware_role_group_from_row(row: Dict[str, Any]) -> str:
        row_id = str(row.get("row_id") or "")
        parts = row_id.split(":")
        return parts[1] if len(parts) >= 2 and parts[0] == "group" else ""

    def render_validated_hardware_tray(self) -> None:
        tree = getattr(self, "hardware_validated_tree", None)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        if self.hardware_workflow_model is None:
            return
        for index, row in enumerate(self.hardware_workflow_model.tray_rows()):
            tree.insert(
                "",
                "end",
                iid=f"validated::{index}",
                text=row.get("module_id") or row.get("choice_id"),
                values=(
                    ", ".join(map(str, row.get("selected_for_groups", []))),
                    ", ".join(map(str, row.get("provided_roles", []))),
                    row.get("validation_status") or "UNKNOWN",
                ),
            )

    def remove_selected_hardware_role(self) -> None:
        if self.hardware_workflow_model is None:
            return
        selection = self.hardware_selection_tree.selection() if hasattr(self, "hardware_selection_tree") else ()
        row = self.hardware_tree_rows_by_id.get(selection[0], {}) if selection else {}
        group = self.hardware_role_group_from_row(row)
        if not group:
            messagebox.showinfo("Select a hardware role", "Select a device or route beneath the role you want to remove.")
            return
        self.hardware_workflow_model.remove_selection(group)
        self.render_validated_hardware_tray()

    def clear_validated_hardware_tray(self) -> None:
        if self.hardware_workflow_model is not None:
            self.hardware_workflow_model.clear_selections()
        self.render_validated_hardware_tray()

    def create_hardware_profile_draft(self) -> None:
        if self.hardware_workflow_model is None:
            messagebox.showerror("Hardware workflow unavailable", HARDWARE_WORKFLOW_IMPORT_ERROR or "Hardware workflow unavailable.")
            return
        raw = self.hardware_profile_draft_path_var.get().strip() if hasattr(self, "hardware_profile_draft_path_var") else ""
        try:
            path = self.canonical_hardware_profile_draft_path(raw, self.cfg["praycg_home"])
            path.parent.mkdir(parents=True, exist_ok=True)
            profile = self.hardware_workflow_model.create_profile_draft(path, profile_id=path.stem)
        except Exception as exc:
            messagebox.showerror(
                "Profile draft stopped",
                "The validated selections could not be written to the profile draft.\n\n"
                f"Target: {locals().get('path', raw or 'default draft location')}\n\n{exc}",
            )
            return
        self.hardware_profile_draft_path = path
        self.hardware_profile_draft_path_var.set(str(path))
        acquisition = self.cfg.setdefault("acquisition", {})
        acquisition["hardware_profile_draft_path"] = str(path)
        acquisition["armed"] = False
        self.save_config()
        self.hardware_profile_draft_status_var.set(
            f"DRAFT_NOT_APPROVED | {len(profile.get('modules', []))} module(s) | {path.name}. Review and lock on this tab."
        )
        self.acq_nb.select(1)

    @staticmethod
    def canonical_hardware_profile_draft_path(raw: str, praycg_home: Any) -> Path:
        """Return one stable mutable draft path, including recovery from the alpha.8.3 filename-growth bug."""
        default_path = Path(praycg_home).expanduser() / "config" / "hardware_profiles" / "hardware_profile_draft.json"
        path = Path(str(raw).strip()).expanduser() if str(raw).strip() else default_path
        suffix = path.suffix or ".json"
        # Alpha.8.3 preserved every refresh by appending a timestamp to the
        # *current* draft name. Repeated clicks could exceed Windows path limits.
        # A draft is intentionally mutable; reviewed profiles retain history.
        if re.fullmatch(r"hardware_profile_draft(?:_\d{8}_\d{6})+", path.stem, flags=re.IGNORECASE):
            path = path.with_name(f"hardware_profile_draft{suffix}")
        if not path.suffix:
            path = path.with_suffix(".json")
        return path.resolve()

    @staticmethod
    def canonical_reviewed_hardware_profile_path(
        configured: str,
        draft_path: Path,
        *,
        stamp: Optional[str] = None,
    ) -> Path:
        """Choose a bounded approved-profile path without touching a legacy overlong path."""
        default_base = Path(draft_path).parent / "active_hardware_profile.json"
        raw = str(configured or "").strip()
        candidate = Path(raw).expanduser() if raw else default_base
        suffix = candidate.suffix or ".json"
        # Old draft and approved paths could be fed back into the next
        # approval. Strip prior generated timestamps before any exists() call,
        # and never approve into a file still named as a mutable draft.
        bounded_stem = re.sub(r"(?:_\d{8}_\d{6})+$", "", candidate.stem, flags=re.IGNORECASE)
        if bounded_stem.lower().startswith("hardware_profile_draft"):
            base = default_base
        else:
            base = candidate.with_name(f"{bounded_stem or 'active_hardware_profile'}{suffix}")
        # Keep compatibility with Windows applications that still enforce
        # MAX_PATH, and reject illegal filename characters before filesystem IO.
        if len(str(base)) > 230 or re.search(r'[<>:"/\\|?*]', base.name):
            base = default_base
        try:
            base = base.resolve()
        except OSError:
            base = default_base.resolve()
        if not base.exists():
            return base
        version_stamp = stamp or now_stamp()
        versioned = base.with_name(f"{base.stem}_{version_stamp}{base.suffix or '.json'}")
        counter = 2
        while versioned.exists():
            versioned = base.with_name(f"{base.stem}_{version_stamp}_{counter}{base.suffix or '.json'}")
            counter += 1
        return versioned

    def review_and_lock_hardware_profile_draft(self) -> None:
        if review_hardware_profile_draft is None:
            messagebox.showerror("Hardware workflow unavailable", HARDWARE_WORKFLOW_IMPORT_ERROR or "Review helper unavailable.")
            return
        raw = self.hardware_profile_draft_path_var.get().strip()
        try:
            draft_path = self.canonical_hardware_profile_draft_path(raw, self.cfg["praycg_home"]) if raw else Path()
            draft_exists = bool(raw and draft_path.is_file())
        except (OSError, ValueError) as exc:
            messagebox.showerror("Profile draft path is invalid", f"Choose Create / Refresh Draft again.\n\n{exc}")
            return
        if not draft_exists:
            messagebox.showinfo("Profile draft required", "Create a profile draft from the validated tray first.")
            return
        reviewer = simpledialog.askstring(
            "Human profile review",
            "Enter the name of the person who reviewed these exact hardware definitions.\n\n"
            "This records definition review only. It is not a connected-device, electrical-safety, or live-signal approval.",
            initialvalue=str(self.cfg.setdefault("acquisition", {}).get("operator_name") or ""),
            parent=self,
        )
        if not reviewer or not reviewer.strip():
            return
        configured = str(self.cfg.setdefault("acquisition", {}).get("hardware_profile_path") or "").strip()
        try:
            out = self.canonical_reviewed_hardware_profile_path(configured, draft_path)
            out.parent.mkdir(parents=True, exist_ok=True)
            profile = review_hardware_profile_draft(draft_path, out, reviewed_by=reviewer.strip())
            if not self.hardware_profile_approved(profile):
                raise ValueError("The reviewed profile is not lockable: " + "; ".join(map(str, profile.get("errors", []))))
            self.set_active_hardware_profile(out, profile)
            self.lock_active_hardware_profile_for_launch(show_message=False)
        except Exception as exc:
            messagebox.showerror(
                "Profile review stopped",
                f"Draft: {draft_path}\nApproved profile target: {locals().get('out', 'not resolved')}\n\n{exc}",
            )
            return
        self.cfg.setdefault("acquisition", {})["operator_name"] = reviewer.strip()
        self.save_config()
        messagebox.showinfo(
            "Hardware profile locked",
            "The exact reviewed profile now determines the Connect & Launch buttons. Live checks, the session lock, and ARM are still required before acquisition.",
        )

    def lock_active_hardware_profile_for_launch(self, show_message: bool = True) -> None:
        if lock_hardware_profile is None:
            messagebox.showerror("Hardware workflow unavailable", HARDWARE_WORKFLOW_IMPORT_ERROR or "Profile-lock helper unavailable.")
            return
        raw_profile = str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "").strip()
        profile_path = Path(raw_profile).expanduser().resolve() if raw_profile else Path()
        if not raw_profile or not profile_path.is_file():
            messagebox.showinfo("Reviewed profile required", "Build or load an active reviewed profile first.")
            return
        raw_lock = str(self.cfg.get("acquisition", {}).get("hardware_ui_lock_path") or "").strip()
        lock_path = Path(raw_lock).expanduser().resolve() if raw_lock else profile_path.with_name("active_hardware_ui_lock.json")
        try:
            self.hardware_ui_lock = lock_hardware_profile(profile_path, output_path=lock_path)
        except Exception as exc:
            self.hardware_ui_lock = None
            self.render_hardware_launch_actions()
            messagebox.showerror("Profile lock stopped", str(exc))
            return
        self.cfg.setdefault("acquisition", {})["hardware_ui_lock_path"] = str(lock_path)
        self.save_config()
        self.render_active_hardware_profile()
        self.render_hardware_launch_actions()
        self.refresh_active_context_ui()
        if show_message:
            messagebox.showinfo(
                "Profile locked for connection",
                "Connect & Launch now shows one control per exact bridge process in this profile. This UI lock does not arm a session.",
            )

    def load_hardware_ui_lock(self, silent: bool = False) -> None:
        self.hardware_ui_lock = None
        raw = str(self.cfg.get("acquisition", {}).get("hardware_ui_lock_path") or "").strip()
        path = Path(raw).expanduser() if raw else Path()
        if raw and path.is_file() and validate_hardware_profile_lock is not None:
            try:
                lock = json.loads(path.read_text(encoding="utf-8"))
                profile_raw = str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "").strip()
                profile_path = Path(profile_raw).expanduser() if profile_raw else None
                report = validate_hardware_profile_lock(lock, profile_path=profile_path)
                if report.get("status") == "INELIGIBLE":
                    raise ValueError("; ".join(map(str, report.get("errors", []))))
                self.hardware_ui_lock = lock
            except Exception as exc:
                if not silent:
                    messagebox.showerror("Hardware profile lock unavailable", str(exc))
        self.render_active_hardware_profile()
        self.render_hardware_launch_actions()
        self.refresh_active_context_ui()

    def render_hardware_launch_actions(self) -> None:
        frame = getattr(self, "hardware_launch_frame", None)
        if frame is None:
            return
        for child in frame.winfo_children():
            child.destroy()
        self.hardware_launch_buttons = {}
        self.rendered_hardware_launch_actions = {}
        profile_raw = str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "").strip()
        profile_path = Path(profile_raw).expanduser() if profile_raw else Path()
        if not self.hardware_ui_lock or not profile_raw or not profile_path.is_file() or derive_launch_actions is None:
            self.hardware_launch_status_var.set("No valid hardware UI lock. Return to Hardware Profile and lock the active reviewed profile.")
            ttk.Button(frame, text="Go to Hardware Profile", command=lambda: self.acq_nb.select(1)).pack(fill="x", pady=3)
            return
        plan = derive_launch_actions(profile_path, self.hardware_ui_lock)
        if plan.get("status") == "INELIGIBLE":
            self.hardware_launch_status_var.set("Profile lock is invalid or stale: " + "; ".join(map(str, plan.get("errors", []))))
            return
        actions = list(plan.get("actions") or [])
        self.hardware_launch_status_var.set(
            f"{plan.get('status')} | {len(actions)} exact launch process(es) for profile {plan.get('profile_id')}. "
            "Starting a bridge does not satisfy live preflight or ARM."
        )
        lock_raw = str(self.cfg.get("acquisition", {}).get("hardware_ui_lock_path") or "").strip()
        lock_path = Path(lock_raw).expanduser().resolve() if lock_raw else None
        action_id_counts: Dict[str, int] = {}
        for action in actions:
            action_id = str(action.get("action_id") or "")
            action_id_counts[action_id] = action_id_counts.get(action_id, 0) + 1
        for index, action in enumerate(actions):
            action_id = str(action.get("action_id") or "")
            handler_key = str(action.get("handler_key") or "")
            if (
                not action_id
                or action_id_counts.get(action_id) != 1
                or handler_key not in HARDWARE_LAUNCH_HANDLER_METHODS
            ):
                continue
            try:
                action_identity = json.dumps(action, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                lock_identity = json.dumps(
                    self.hardware_ui_lock,
                    sort_keys=True,
                    separators=(",", ":"),
                    ensure_ascii=False,
                )
            except (TypeError, ValueError):
                continue
            self.rendered_hardware_launch_actions[action_id] = {
                "profile_path": str(profile_path.resolve()),
                "hardware_ui_lock_path": str(lock_path) if lock_path is not None else "",
                "profile_lock_sha256": str(plan.get("profile_lock_sha256") or ""),
                "profile_id": str(plan.get("profile_id") or ""),
                "profile_lock_identity": lock_identity,
                "action_identity": action_identity,
            }
            roles = ", ".join(map(str, action.get("canonical_roles", [])))
            label = f"{action.get('label')}  [{roles}]" if roles else str(action.get("label"))
            if action.get("ui_kind") == "MENU_BUTTON":
                widget = ttk.Menubutton(frame, text=label)
                menu = tk.Menu(widget, tearoff=False)
                for variant in action.get("variants", []):
                    variant_id = str(variant.get("variant_id") or "")
                    if not variant_id:
                        continue
                    menu.add_command(
                        label=variant.get("label") or variant_id,
                        command=lambda selected_action=action_id, selected_variant=variant_id: self.launch_locked_hardware_action(
                            selected_action, selected_variant
                        ),
                    )
                widget.configure(menu=menu)
            else:
                widget = ttk.Button(
                    frame,
                    text=label,
                    command=lambda selected_action=action_id: self.launch_locked_hardware_action(selected_action),
                )
            widget.grid(row=index // 2, column=index % 2, sticky="ew", padx=4, pady=4)
            frame.columnconfigure(index % 2, weight=1)
            self.hardware_launch_buttons[action_id] = widget
        unavailable_start = (len(actions) + 1) // 2
        for offset, unavailable in enumerate(plan.get("unavailable_modules", [])):
            ttk.Label(
                frame,
                text=f"No packaged launcher for {unavailable.get('module_id')}: {unavailable.get('reason')}",
                foreground="#7a1e1e",
                wraplength=960,
            ).grid(row=unavailable_start + offset, column=0, columnspan=2, sticky="w", padx=4, pady=3)

    def launch_locked_hardware_action(self, action_id: str, variant: Optional[str] = None) -> bool:
        """Revalidate one rendered profile-lock action immediately before dispatch.

        This is only a Connect & Launch UI-selection gate.  It neither checks nor
        grants session-lock, ARM, owner-lease, or acquisition authority.
        """
        requested_action = str(action_id or "")
        requested_variant = None if variant is None else str(variant)

        def blocked(reason: str) -> bool:
            message = (
                f"{reason}\n\nReturn to Hardware Profile, verify the reviewed profile, and lock it again "
                "before starting a stream bridge. This UI lock does not grant ARM or acquisition authority."
            )
            status_var = getattr(self, "hardware_launch_status_var", None)
            if status_var is not None:
                status_var.set(f"Launch blocked: {reason}")
            messagebox.showerror("Hardware launch blocked", message)
            return False

        rendered = getattr(self, "rendered_hardware_launch_actions", {}).get(requested_action)
        if not requested_action or not isinstance(rendered, dict):
            return blocked("The requested action was not present in the last validated hardware launch plan.")
        acquisition = self.cfg.get("acquisition", {})
        if not isinstance(acquisition, dict):
            return blocked("The current acquisition configuration is unavailable.")
        profile_raw = str(acquisition.get("hardware_profile_path") or "").strip()
        lock_raw = str(acquisition.get("hardware_ui_lock_path") or "").strip()
        if not profile_raw or not lock_raw or derive_launch_actions is None:
            return blocked("The current reviewed profile or hardware UI lock is unavailable.")
        profile_path = Path(profile_raw).expanduser().resolve()
        lock_path = Path(lock_raw).expanduser().resolve()
        if str(profile_path) != rendered.get("profile_path") or str(lock_path) != rendered.get("hardware_ui_lock_path"):
            return blocked("The reviewed hardware profile or UI-lock selection changed after these controls were rendered.")
        if not profile_path.is_file() or not lock_path.is_file():
            return blocked("The current reviewed hardware profile or saved UI lock is missing.")
        try:
            saved_lock = json.loads(lock_path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            return blocked(f"The saved hardware UI lock cannot be read: {exc}")
        current_lock = getattr(self, "hardware_ui_lock", None)
        if not isinstance(saved_lock, dict) or not isinstance(current_lock, dict):
            return blocked("The current hardware UI lock is malformed or has not been loaded.")
        try:
            saved_lock_identity = json.dumps(saved_lock, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            current_lock_identity = json.dumps(current_lock, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            return blocked(f"The current hardware UI lock cannot be identity-checked: {exc}")
        if saved_lock_identity != current_lock_identity:
            return blocked("The loaded hardware UI lock differs from its saved record.")
        if current_lock_identity != rendered.get("profile_lock_identity"):
            return blocked("The hardware UI lock changed after these controls were rendered.")
        for field in ("runtime_authority", "session_lock_authority", "arm_authority", "acquisition_authority"):
            if current_lock.get(field) is not False:
                return blocked(f"The hardware UI lock does not preserve {field}=false.")
        try:
            plan = derive_launch_actions(profile_path, current_lock)
        except Exception as exc:
            return blocked(f"The current hardware launch plan could not be revalidated: {exc}")
        if not isinstance(plan, dict) or plan.get("status") not in {"PASS", "CAUTION"}:
            errors = plan.get("errors", []) if isinstance(plan, dict) else []
            detail = "; ".join(map(str, errors)) or "the current profile/UI-lock pair is ineligible"
            return blocked(f"The current hardware launch plan is invalid or stale: {detail}")
        current_lock_sha256 = str(current_lock.get("lock_sha256") or "")
        if (
            not current_lock_sha256
            or str(plan.get("profile_lock_sha256") or "") != current_lock_sha256
            or current_lock_sha256 != rendered.get("profile_lock_sha256")
            or str(plan.get("profile_id") or "") != rendered.get("profile_id")
        ):
            return blocked("The revalidated launch-plan identity differs from the rendered plan.")
        matches = [
            action
            for action in plan.get("actions", [])
            if isinstance(action, dict) and str(action.get("action_id") or "") == requested_action
        ]
        if len(matches) != 1:
            return blocked("The requested action is missing or ambiguous in the revalidated launch plan.")
        action = matches[0]
        try:
            action_identity = json.dumps(action, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            return blocked(f"The requested action cannot be identity-checked: {exc}")
        if action_identity != rendered.get("action_identity"):
            return blocked("The requested action identity changed after these controls were rendered.")
        if (
            action.get("enabled") is not True
            or action.get("requires_valid_profile_lock") is not True
            or action.get("starts_stream_only") is not True
            or any(action.get(field) is not False for field in ("session_lock_authority", "arm_authority", "acquisition_authority"))
        ):
            return blocked("The requested action does not preserve the stream-only, non-authorizing launch boundary.")
        handler_key = str(action.get("handler_key") or "")
        already_running = [
            item
            for item in getattr(self, "processes", {}).values()
            if item.process.poll() is None and str(item.label) == str(action.get("label") or "")
        ]
        # OpenBCI bridges can outlive the Control Center version that launched
        # them. Their handlers perform a guarded cross-version scan and can
        # offer to retire a bridge bound to an earlier equipment session.
        if already_running and handler_key not in OPENBCI_BRIDGE_HANDLER_KEYS:
            running = already_running[0]
            status_var = getattr(self, "hardware_launch_status_var", None)
            if status_var is not None:
                status_var.set(
                    f"Already running: {running.label} (PID {running.process.pid}). "
                    "Use Home → View / Stop Running Tools before restarting it."
                )
            messagebox.showinfo(
                "Equipment bridge already running",
                f"{running.label} is already running as PID {running.process.pid}.\n\n"
                "A second copy was not started. Use Home → View / Stop Running Tools to open or stop the existing bridge.",
            )
            return False
        handler_name = HARDWARE_LAUNCH_HANDLER_METHODS.get(handler_key)
        handler = getattr(self, handler_name, None) if handler_name else None
        if not callable(handler):
            return blocked("The requested action has no exact packaged Control Center handler.")
        variants = action.get("variants", [])
        if not isinstance(variants, list):
            return blocked("The requested action has a malformed variant ledger.")
        if variants:
            if action.get("ui_kind") != "MENU_BUTTON" or requested_variant is None:
                return blocked("This launch action requires one exact transport variant.")
            selected = [
                row
                for row in variants
                if isinstance(row, dict) and str(row.get("variant_id") or "") == requested_variant
            ]
            if len(selected) != 1:
                return blocked("The chosen transport variant is missing or ambiguous in the revalidated action.")
            argument = str(selected[0].get("handler_argument") or "")
            if not argument:
                return blocked("The chosen transport variant has no exact packaged handler argument.")
            launch_result = handler(argument)
        else:
            if action.get("ui_kind") != "BUTTON" or requested_variant is not None:
                return blocked("The chosen variant does not match this exact launch action.")
            launch_result = handler()
        if launch_result is False:
            return False
        return True

    def refresh_hardware_registry_ui(self) -> None:
        if not hasattr(self, "hardware_listbox"):
            return
        self.hardware_listbox.delete(0, "end")
        self.hardware_module_paths = sorted(self.hardware_registry_root.glob("*.json"))
        for path in self.hardware_module_paths:
            label = path.stem
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
                label = f"{payload.get('display_name') or path.stem}  [{payload.get('trust_level') or 'unrated'}]"
            except Exception:
                label = f"{path.stem}  [unreadable]"
            self.hardware_listbox.insert("end", label)
        self.apply_hardware_preset(save=False)

    def apply_hardware_preset(self, save: bool = True) -> None:
        if not hasattr(self, "hardware_listbox"):
            return
        preset = self.hardware_preset_var.get() if hasattr(self, "hardware_preset_var") else "Custom selection"
        filenames = set(HARDWARE_PRESETS.get(preset, []))
        if preset != "Custom selection":
            self.hardware_listbox.selection_clear(0, "end")
            for index, path in enumerate(self.hardware_module_paths):
                if path.name in filenames:
                    self.hardware_listbox.selection_set(index)
        if save:
            self.cfg.setdefault("acquisition", {})["hardware_preset"] = preset
            self.cfg["acquisition"]["armed"] = False
            self.save_config()
        if hasattr(self, "hardware_profile_text"):
            selected = [path.name for path in self.selected_hardware_module_paths()]
            self.hardware_profile_text.configure(state="normal")
            self.hardware_profile_text.delete("1.0", "end")
            self.hardware_profile_text.insert(
                "end",
                "Selected definitions:\n" + ("\n".join(f"• {name}" for name in selected) if selected else "• none")
                + "\n\nValidate, then build a human-reviewed profile. Applying a preset does not activate or connect hardware.",
            )
            self.hardware_profile_text.configure(state="disabled")

    def selected_hardware_module_paths(self) -> List[Path]:
        if self.hardware_workflow_model is None:
            return []
        choice_index = {
            str(row.get("choice_id")): row
            for row in self.hardware_workflow_model.inventory.get("choices", [])
            if isinstance(row, dict)
        }
        result: List[Path] = []
        for row in self.hardware_workflow_model.tray_rows():
            choice = choice_index.get(str(row.get("choice_id")), {})
            raw = str(choice.get("module_path") or "")
            if raw:
                result.append(Path(raw).expanduser())
        return result

    def validate_selected_hardware(self) -> None:
        if self.hardware_workflow_model is None:
            messagebox.showerror("Hardware workflow unavailable", HARDWARE_WORKFLOW_IMPORT_ERROR or "Hardware workflow unavailable.")
            return
        selection = self.hardware_selection_tree.selection() if hasattr(self, "hardware_selection_tree") else ()
        row = self.hardware_tree_rows_by_id.get(selection[0], {}) if selection else {}
        choice_id = str(row.get("choice_id") or "")
        group = self.hardware_role_group_from_row(row)
        if not choice_id or not group:
            messagebox.showinfo("Select hardware", "Choose an exact device or route beneath one hardware role.")
            return
        try:
            report = self.hardware_workflow_model.validate_and_select(group, choice_id)
        except Exception as exc:
            messagebox.showerror("Hardware validation failed", str(exc))
            return
        self.hardware_selection_detail.delete("1.0", "end")
        self.hardware_selection_detail.insert("end", json.dumps(report, indent=2))
        self.render_validated_hardware_tray()
        if report.get("profile_eligible"):
            messagebox.showinfo(
                "Added to validated tray",
                f"{row.get('label')} can enter profile construction for {report.get('selected_role_group_label')}.\n\n"
                "This did not test a connected device and did not grant acquisition authority.",
            )
        else:
            messagebox.showerror(
                "Not eligible for a human profile",
                "\n".join(map(str, report.get("errors") or ["This catalog or draft route has not reached the required admission state."])),
            )
        self.log(f"Hardware selection validation: {report.get('status')} ({choice_id} for {group}).\n")

    def build_reviewed_hardware_profile(self) -> None:
        """Compatibility entry point: the alpha.8 UI separates draft creation from review."""
        self.create_hardware_profile_draft()

    def choose_active_hardware_profile(self) -> None:
        value = filedialog.askopenfilename(
            title="Select a reviewed hardware profile",
            filetypes=(("JSON", "*.json"), ("All", "*.*")),
        )
        if value:
            self.set_active_hardware_profile(Path(value).expanduser().resolve())

    def set_active_hardware_profile(self, path: Path, profile: Optional[Dict[str, Any]] = None) -> None:
        try:
            profile = profile or json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            self.active_hardware_profile = None
            messagebox.showerror("Profile unavailable", f"Could not read the selected hardware profile.\n\n{exc}")
            self.refresh_acquisition_readiness()
            return
        self.active_hardware_profile = profile
        self.hardware_ui_lock = None
        acquisition = self.cfg.setdefault("acquisition", {})
        acquisition["hardware_profile_path"] = str(path)
        acquisition["armed"] = False
        acquisition["arm_override_reason"] = ""
        acquisition["bench_eeg_quality_waiver_active"] = False
        acquisition["bench_readiness_bypass_active"] = False
        acquisition["bench_bypass_preflight_path"] = ""
        acquisition["disarmed_lock_identity"] = ""
        acquisition["session_stage"] = "SELECT"
        acquisition["preflight_started_epoch"] = 0.0
        acquisition["session_lock_status"] = "STALE_PROFILE_CHANGED"
        if hasattr(self, "hardware_profile_path_var"):
            self.hardware_profile_path_var.set(str(path))
        expected: List[str] = []
        for module in profile.get("modules", []):
            for stream in module.get("streams", []):
                name = str(stream.get("lsl_name") or "").strip()
                if name and name not in expected:
                    expected.append(name)
        if expected:
            self.cfg.setdefault("lsl", {})["expected_streams"] = expected
        self.save_config()
        self.render_active_hardware_profile()
        self.update_hardware_launch_states()
        self.refresh_acquisition_readiness()

    def load_active_hardware_profile(self, silent: bool = False) -> None:
        value = str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "").strip()
        path = Path(value).expanduser() if value else Path()
        if value and path.is_file():
            try:
                self.active_hardware_profile = json.loads(path.read_text(encoding="utf-8"))
            except Exception as exc:
                self.active_hardware_profile = None
                if not silent:
                    messagebox.showerror("Profile unavailable", str(exc))
        else:
            self.active_hardware_profile = None
        self.render_active_hardware_profile()
        self.update_hardware_launch_states()

    def render_active_hardware_profile(self) -> None:
        if not hasattr(self, "hardware_profile_status_var"):
            return
        profile = self.active_hardware_profile
        if not profile:
            self.hardware_profile_status_var.set("No active reviewed hardware profile. Build or load one before live preflight.")
            self.expected_streams_var.set("Expected by active profile: none")
            return
        modules = profile.get("modules", [])
        module_names = [str(module.get("module_id") or "unknown") for module in modules]
        streams = []
        trust = []
        for module in modules:
            trust.append(str(module.get("trust_level") or "unrated"))
            streams.extend(str(stream.get("lsl_name") or "") for stream in module.get("streams", []) if stream.get("lsl_name"))
        status = str(profile.get("status") or "UNKNOWN")
        ui_lock_status = "UI LOCKED" if self.hardware_ui_lock else "NOT YET UI LOCKED"
        self.hardware_profile_status_var.set(
            f"{status} | {ui_lock_status} | reviewed by {profile.get('reviewed_by') or 'UNRECORDED'} | "
            f"{len(modules)} module(s) | profile hash {str(profile.get('canonical_sha256') or '')[:12]}…"
        )
        self.expected_streams_var.set("Expected by active profile: " + (", ".join(streams) if streams else "none declared"))
        if hasattr(self, "hardware_profile_text"):
            self.hardware_profile_text.configure(state="normal")
            self.hardware_profile_text.delete("1.0", "end")
            self.hardware_profile_text.insert(
                "end",
                "Modules: " + (", ".join(module_names) if module_names else "none")
                + "\nTrust levels: " + (", ".join(sorted(set(trust))) if trust else "unrated")
                + "\nExpected streams: " + (", ".join(streams) if streams else "none")
                + ("\nErrors: " + "; ".join(map(str, profile.get("errors", []))) if profile.get("errors") else ""),
            )
            self.hardware_profile_text.configure(state="disabled")

    def active_hardware_module_ids(self) -> set[str]:
        if not self.active_hardware_profile:
            return set()
        return {str(module.get("module_id") or "") for module in self.active_hardware_profile.get("modules", [])}

    def active_hardware_roles(self) -> set[str]:
        if not self.active_hardware_profile:
            return set()
        roles = set(str(role) for role in self.active_hardware_profile.get("resolved_roles", {}))
        for module in self.active_hardware_profile.get("modules", []):
            for stream in module.get("streams", []):
                roles.add(str(stream.get("canonical_role") or ""))
                roles.update(str(role) for role in stream.get("embedded_roles", []))
        return {role for role in roles if role}

    def update_hardware_launch_states(self) -> None:
        self.render_hardware_launch_actions()
        roles = self.active_hardware_roles()
        for key, button in getattr(self, "hardware_check_buttons", {}).items():
            required_role = key.split(":", 1)[0]
            button.configure(state="normal" if required_role == "always" or required_role in roles else "disabled")

    def open_active_hardware_profile_folder(self) -> None:
        value = str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "").strip()
        path = Path(value).expanduser() if value else Path()
        if not value:
            messagebox.showinfo("No profile", "Build or load a hardware profile first.")
            return
        open_path(path.parent if path.parent.exists() else path)

    @staticmethod
    def newest_json(folder: Path, pattern: str) -> Optional[Path]:
        try:
            return max(
                (path for path in folder.glob(pattern) if path.is_file()),
                key=lambda path: path.stat().st_mtime,
                default=None,
            )
        except OSError:
            return None

    def acquisition_report_status(self, path: Optional[Path], not_before: float = 0.0) -> Tuple[str, str]:
        if path is None or not path.is_file():
            return "NOT_RUN", "no report"
        try:
            if not_before and path.stat().st_mtime + 2.0 < not_before:
                return "STALE", f"older than the active profile preflight ({path.name})"
            payload = json.loads(path.read_text(encoding="utf-8"))
            return str(payload.get("status") or "UNKNOWN").upper(), path.name
        except Exception as exc:
            return "UNREADABLE", f"{path.name}: {exc}"

    def profile_preflight_status(self, path: Path, not_before: float = 0.0) -> Tuple[str, str]:
        """Validate the one canonical, full-profile preflight artifact used by session locking."""
        generic_status, detail = self.acquisition_report_status(path, not_before)
        if generic_status in {"NOT_RUN", "STALE", "UNREADABLE"}:
            return generic_status, detail
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if payload.get("schema") != "PRAYCG_HardwareProfilePreflight_v1_0_alpha_2":
                return "UNREADABLE", f"wrong schema ({path.name})"
            profile_hash = (self.active_hardware_profile or {}).get("canonical_sha256")
            if payload.get("hardware_profile_canonical_sha256") != profile_hash:
                return "STALE", f"belongs to another hardware profile ({path.name})"
            if not self.active_run_uuid or payload.get("run_uuid") != self.active_run_uuid:
                return "STALE", f"belongs to another or unbound run UUID ({path.name})"
            stored = str(payload.get("canonical_sha256") or "")
            canonical = {key: value for key, value in payload.items() if key != "canonical_sha256"}
            if not stored or stored != platform_sha256_json(canonical):  # type: ignore[misc]
                return "UNREADABLE", f"canonical hash mismatch ({path.name})"
            status = str(payload.get("status") or "INELIGIBLE").upper()
            if status not in {"PASS", "CAUTION", "INELIGIBLE"}:
                return "UNREADABLE", f"unknown status ({path.name})"
            return status, path.name
        except Exception as exc:
            return "UNREADABLE", f"{path.name}: {exc}"

    def detailed_preflight_report_status(self, path: Optional[Path], not_before: float = 0.0) -> Tuple[str, str]:
        status, detail = self.acquisition_report_status(path, not_before)
        if status in {"NOT_RUN", "STALE", "UNREADABLE"} or path is None:
            return status, detail
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if payload.get("schema") != "PRAYCG_Acquisition_Preflight_v1_0":
                return "UNREADABLE", f"wrong schema ({path.name})"
            profile_hash = str((self.active_hardware_profile or {}).get("canonical_sha256") or "")
            if payload.get("hardware_profile_sha256") != profile_hash:
                return "STALE", f"belongs to another hardware profile ({path.name})"
            if not self.active_run_uuid or payload.get("run_uuid") != self.active_run_uuid:
                return "STALE", f"belongs to another or unbound run UUID ({path.name})"
            if payload.get("binding_status") != "BOUND":
                return "UNREADABLE", f"report is not run/profile bound ({path.name})"
            return str(payload.get("status") or "UNKNOWN").upper(), path.name
        except Exception as exc:
            return "UNREADABLE", f"{path.name}: {exc}"

    def als_barcode_report_status(self, path: Optional[Path], not_before: float = 0.0) -> Tuple[str, str]:
        status, detail = self.acquisition_report_status(path, not_before)
        if status in {"NOT_RUN", "STALE", "UNREADABLE"} or path is None:
            return status, detail
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            if payload.get("schema") != "PRAYCG_ALS_Barcode_Live_Test_v0_7":
                return "UNREADABLE", f"wrong schema ({path.name})"
            profile_hash = str((self.active_hardware_profile or {}).get("canonical_sha256") or "")
            if profile_hash and payload.get("hardware_profile_sha256") != profile_hash:
                return "STALE", f"belongs to another hardware profile ({path.name})"
            if self.active_run_uuid and payload.get("run_uuid") != self.active_run_uuid:
                return "STALE", f"belongs to another run UUID ({path.name})"
            return str(payload.get("status") or "UNKNOWN").upper(), path.name
        except Exception as exc:
            return "UNREADABLE", f"{path.name}: {exc}"

    def bench_eeg_quality_waiver_status(self, path: Optional[Path]) -> Tuple[bool, str]:
        acquisition = self.cfg.setdefault("acquisition", {})
        if not bool(acquisition.get("bench_test_mode")):
            return False, "bench test mode is off"
        if path is None or not path.is_file():
            return False, "no current detailed EEG report"
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            return False, f"detailed EEG report is unreadable: {exc}"
        profile_hash = str((self.active_hardware_profile or {}).get("canonical_sha256") or "")
        if not profile_hash or payload.get("hardware_profile_sha256") != profile_hash:
            return False, "detailed EEG report belongs to another hardware profile"
        if not self.active_run_uuid or payload.get("run_uuid") != self.active_run_uuid:
            return False, "detailed EEG report belongs to another equipment session"
        run_fragment = self.active_run_uuid.replace("-", "")[:12]
        source_id = str(payload.get("eeg", {}).get("stream", {}).get("source_id") or "")
        if not run_fragment or run_fragment not in source_id.replace("-", ""):
            return False, "detailed EEG source identity is not bound to the current equipment session"
        return bench_eeg_quality_waiver(payload)

    def toggle_bench_test_mode(self) -> None:
        acquisition = self.cfg.setdefault("acquisition", {})
        requested = bool(self.bench_test_mode_var.get())
        current = bool(acquisition.get("bench_test_mode"))
        if requested != current and str(acquisition.get("session_stage") or "") == "ACQUIRE":
            self.bench_test_mode_var.set(bool(acquisition.get("bench_test_mode")))
            messagebox.showerror("Runner active", "Bench Test Mode cannot change while an acquisition runner is active.")
            return
        reason = ""
        if requested:
            accepted = messagebox.askyesno(
                "Enable Bench Test Mode?",
                "Use this only for hardware/software testing with no participant.\n\n"
                "It bypasses live hardware, missing-stream, timing, signal-quality, ALS placement, and demo-only scientific-use qualifiers for confirming and arming the session. It does not bypass the selected protocol/materials, reviewed hardware definition, file-integrity checks, or runtime session lock.\n\n"
                "All resulting session records are permanently labeled BENCH_TEST and ineligible as participant data. Continue?",
                parent=self,
            )
            if not accepted:
                self.bench_test_mode_var.set(False)
                return
            reason = simpledialog.askstring(
                "Bench test reason",
                "Record why no participant-quality EEG is expected:",
                initialvalue="EEG cap intentionally not worn; hardware/software bench test only.",
                parent=self,
            ) or ""
            if not reason.strip():
                self.bench_test_mode_var.set(False)
                return
        if requested != current:
            lock_value = str(acquisition.get("session_lock_path") or "").strip()
            lock_path = Path(lock_value).expanduser() if lock_value else Path()
            if lock_value and lock_path.is_file():
                try:
                    existing_lock = load_platform_json(lock_path)  # type: ignore[misc]
                    lock_identity = str(existing_lock.get("lock_identity_sha256") or "")
                    if lock_identity:
                        acquisition["disarmed_lock_identity"] = lock_identity
                except Exception:
                    # An unreadable lock cannot validate now; retain the stale
                    # status below and never infer authority from it.
                    pass
            acquisition["participant_pseudonym"] = ""
        acquisition["bench_test_mode"] = requested
        acquisition["bench_test_reason"] = reason.strip()
        acquisition["bench_eeg_quality_waiver_active"] = False
        acquisition["bench_readiness_bypass_active"] = requested
        acquisition["bench_bypass_preflight_path"] = ""
        acquisition["armed"] = False
        acquisition["arm_override_reason"] = ""
        acquisition["session_lock_status"] = "STALE_BENCH_MODE_CHANGED"
        acquisition["session_stage"] = "SELECT"
        acquisition["preflight_started_epoch"] = time.time()
        self.save_config()
        self.write_acquisition_state()
        self.refresh_acquisition_readiness()
        if requested:
            messagebox.showinfo(
                "Bench Test Mode enabled",
                "Bench Test Mode is ON for this Control Center window. Live equipment checks are now optional for "
                "Confirm Session Setup and Mark Ready to Run. You may still run them for diagnostics; failures and "
                "missing hardware will be recorded but will not block a bench lock.\n\n"
                "The selected protocol, materials, reviewed hardware definition, and file-integrity checks remain "
                "required. The lock and every output are permanently labeled BENCH_TEST / not participant eligible. "
                "Bench mode resets OFF when the app restarts.",
                parent=self,
            )

    def refresh_acquisition_readiness(self) -> str:
        acquisition = self.cfg.setdefault("acquisition", {})
        profile = self.active_hardware_profile
        started = float(acquisition.get("preflight_started_epoch") or 0.0)
        profile_preflight_report = Path(str(acquisition.get("profile_preflight_report_path") or "")).expanduser()
        detailed_dir = Path(str(acquisition.get("detailed_preflight_dir") or "")).expanduser()
        detailed_report = self.newest_json(detailed_dir, "PRAYCG_acquisition_preflight_v1_0_*.json")
        als_test_dir = Path(
            str(acquisition.get("als_test_dir") or Path(self.cfg["log_root"]) / "als_pulse_tests")
        ).expanduser()
        als_test_report = self.newest_json(als_test_dir, "als_barcode_live_test_*.json")
        profile_preflight_status, profile_preflight_detail = self.profile_preflight_status(profile_preflight_report, started)
        detailed_status, detailed_detail = self.detailed_preflight_report_status(detailed_report, started)
        als_test_status, als_test_detail = self.als_barcode_report_status(als_test_report, started)
        bench_mode = bool(acquisition.get("bench_test_mode"))
        bench_waiver_allowed, bench_waiver_detail = self.bench_eeg_quality_waiver_status(detailed_report)
        acquisition["bench_eeg_quality_waiver_active"] = False
        acquisition["bench_readiness_bypass_active"] = bench_mode
        roles = self.active_hardware_roles()
        raw_profile_status = str(profile.get("status") or "UNKNOWN").upper() if profile else "MISSING"
        profile_status = "APPROVED" if self.hardware_profile_approved(profile) else raw_profile_status
        reasons: List[str] = []
        status = "PASS"

        demo_reason = self.demo_only_stimulus_reason()
        if demo_reason:
            reasons.append(demo_reason)

        if profile and self.platform_core_available():
            try:
                profile_path = Path(str(acquisition.get("hardware_profile_path") or "")).expanduser()
                identity_report = validate_hardware_profile_identity(profile, profile_path=profile_path)  # type: ignore[misc]
                if identity_report.status == "INELIGIBLE":
                    profile_status = "INELIGIBLE"
                    reasons.extend(identity_report.errors)
            except Exception as exc:
                profile_status = "INELIGIBLE"
                reasons.append(f"hardware profile identity could not be verified: {exc}")

        structural_ineligible = (
            not profile
            or profile_status != "APPROVED"
            or bool(demo_reason and not bench_may_bypass_stimulus_reason(demo_reason))
        )
        if not profile:
            status = "INELIGIBLE"
            reasons.append("no active reviewed hardware profile")
        elif profile_status != "APPROVED":
            status = "INELIGIBLE"
            reasons.append(f"hardware profile is {profile_status}")
        if profile and profile_status == "APPROVED":
            if profile_preflight_status in {"INELIGIBLE", "FAIL", "UNREADABLE"}:
                status = "INELIGIBLE"
                reasons.append(f"full-profile preflight {profile_preflight_status.lower()}")
            elif profile_preflight_status == "CAUTION":
                status = "CAUTION"
                reasons.append("full-profile preflight contains cautions")
            elif profile_preflight_status != "PASS":
                status = "CAUTION"
                reasons.append("full-profile preflight has not run for this profile selection")
            if "eeg" in roles:
                if detailed_status == "FAIL":
                    if bench_mode and bench_waiver_allowed and status != "INELIGIBLE":
                        status = "CAUTION"
                        acquisition["bench_eeg_quality_waiver_active"] = True
                        reasons.append("BENCH TEST MODE: cap-off EEG contact quality waived; non-participant data only")
                    else:
                        status = "INELIGIBLE"
                        reasons.append("detailed EEG/ALS validation failed")
                        if bench_mode:
                            reasons.append(f"bench waiver refused: {bench_waiver_detail}")
                elif detailed_status in {"WARN", "CAUTION"} and status != "INELIGIBLE":
                    status = "CAUTION"
                    reasons.append("detailed EEG/ALS validation contains warnings")
                elif detailed_status != "PASS" and status != "INELIGIBLE":
                    status = "CAUTION"
                    reasons.append("detailed EEG/ALS validation has not passed for this profile selection")
            if "als" in roles:
                placement = Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json"
                if not placement.is_file():
                    status = "INELIGIBLE"
                    reasons.append("ALS holder calibration/placement profile is not present")
                if als_test_status == "PASS":
                    pass
                elif als_test_status == "WEAK" and status != "INELIGIBLE":
                    status = "CAUTION"
                    reasons.append("ALS barcode placement response is weak")
                else:
                    status = "INELIGIBLE"
                    reasons.append(f"ALS barcode placement test is {als_test_status.lower()}")

        if bench_mode and not structural_ineligible:
            bypassed_findings = list(reasons)
            status = "CAUTION"
            acquisition["bench_eeg_quality_waiver_active"] = False
            reasons = [
                "BENCH TEST READINESS BYPASS ACTIVE: live equipment and scientific-use qualifiers do not block confirmation or ARM; outputs are never participant data"
            ]
            if bypassed_findings:
                reasons.append("recorded bypassed findings: " + "; ".join(bypassed_findings))

        # A demo-only pack remains a hard participant boundary. Bench Test
        # Mode may exercise it because the resulting lock is permanently
        # classified as non-participant data.
        if demo_reason and (not bench_mode or not bench_may_bypass_stimulus_reason(demo_reason)):
            status = "INELIGIBLE"

        try:
            self.refresh_protocol_lock_status(update_acquisition=False)
        except TypeError:
            self.refresh_protocol_lock_status()
        protocol_status = "PASS" if self.locked_protocol else "NOT LOCKED"
        session_lock_status, session_lock_detail = self.validate_active_session_lock()
        acquisition["session_lock_status"] = session_lock_status
        armed = bool(acquisition.get("armed"))
        session_stage = str(acquisition.get("session_stage") or "")
        if armed and (
            status == "INELIGIBLE"
            or not self.locked_protocol
            or session_lock_status != "VALID"
            or session_stage not in {"ARM", "ACQUIRE"}
        ):
            acquisition["armed"] = False
            armed = False
        acquisition["readiness_status"] = status
        acquisition["readiness_message"] = "; ".join(reasons) if reasons else "reviewed profile and required current live checks passed"
        acquisition["latest_profile_preflight_report"] = str(profile_preflight_report) if profile_preflight_report.is_file() else ""
        acquisition["latest_detailed_preflight_report"] = str(detailed_report) if detailed_report else ""
        acquisition["latest_als_barcode_test_report"] = str(als_test_report) if als_test_report else ""

        if hasattr(self, "acq_readiness_var"):
            self.acq_readiness_var.set(f"READINESS: {status} — {acquisition['readiness_message']}")
            self.acq_gate_var.set(
                f"PROFILE {profile_status} | FULL PREFLIGHT {profile_preflight_status} ({profile_preflight_detail}) | "
                f"EEG/ALS {detailed_status if 'eeg' in roles else 'NOT REQUIRED'} ({detailed_detail}) | "
                f"ALS PLACEMENT {als_test_status if 'als' in roles else 'NOT REQUIRED'} ({als_test_detail}) | "
                f"PROTOCOL {protocol_status} | SESSION LOCK {session_lock_status} ({session_lock_detail}) | "
                f"ARM {'ARMED' if armed else 'NOT ARMED'}"
            )
            preflight_eligible = bench_mode or profile_preflight_status in {"PASS", "CAUTION"}
            can_lock = bool(profile and profile_status == "APPROVED" and preflight_eligible and status != "INELIGIBLE" and self.locked_protocol)
            self.acq_session_lock_button.configure(state="normal" if can_lock else "disabled")
            can_arm = bool(can_lock and session_lock_status == "VALID" and session_stage in {"SESSION_LOCK", "ARM"})
            self.acq_arm_button.configure(state="normal" if can_arm else "disabled")
        if hasattr(self, "bench_test_status_var"):
            if bench_mode:
                self.bench_test_status_var.set(
                    f"BENCH TEST MODE ON — readiness {status}; live hardware/readiness qualifiers are bypassed. "
                    "Checks remain available for diagnostics, and outputs are never participant data."
                )
            else:
                self.bench_test_status_var.set(
                    "Bench Test Mode OFF — participant safeguards active. Bench mode always resets OFF when this app starts."
                )
        if hasattr(self, "runner_hardware_var"):
            profile_id = str(profile.get("profile_id") or "none") if profile else "none"
            self.runner_hardware_var.set(
                f"ACQUISITION SESSION: {'ARMED' if armed else 'NOT ARMED'} | profile {profile_id} | "
                f"readiness {status} | session lock {session_lock_status}"
            )
        if hasattr(self, "runner_input_tree"):
            self.refresh_runner_lock_summary()
        if hasattr(self, "post_run_gate_var"):
            self.post_run_gate_var.set(
                f"Session gate: {session_stage or 'none'} | {session_lock_status} — advance only after reviewing the named evidence artifact"
            )
        self.write_acquisition_state()
        return status

    def write_acquisition_state(self) -> None:
        acquisition = self.cfg.setdefault("acquisition", {})
        raw_path = str(acquisition.get("state_path") or "").strip()
        if not raw_path:
            return
        path = Path(raw_path).expanduser()
        path.parent.mkdir(parents=True, exist_ok=True)
        profile = self.active_hardware_profile or {}
        payload = {
            "schema": "PRAYCG_ActiveAcquisitionState_v1_0_alpha_2",
            "updated_local": datetime.now().isoformat(timespec="seconds"),
            "hardware_profile_path": str(acquisition.get("hardware_profile_path") or ""),
            "hardware_profile_id": profile.get("profile_id"),
            "hardware_profile_sha256": profile.get("canonical_sha256"),
            "readiness_status": acquisition.get("readiness_status"),
            "readiness_message": acquisition.get("readiness_message"),
            "latest_profile_preflight_report": acquisition.get("latest_profile_preflight_report"),
            "latest_detailed_preflight_report": acquisition.get("latest_detailed_preflight_report"),
            "latest_als_barcode_test_report": acquisition.get("latest_als_barcode_test_report"),
            "protocol_lock_path": str(self.protocol_lock_path),
            "approved_protocol_snapshot_path": acquisition.get("approved_protocol_snapshot_path"),
            "protocol_id": self.locked_protocol.get("protocol_id") if self.locked_protocol else None,
            "session_lock_path": acquisition.get("session_lock_path"),
            "session_lock_status": acquisition.get("session_lock_status"),
            "session_stage": acquisition.get("session_stage"),
            "session_artifact_root": acquisition.get("session_artifact_root"),
            "armed": bool(acquisition.get("armed")),
            "arm_override_reason": acquisition.get("arm_override_reason") or "",
            "session_purpose": "BENCH_TEST" if acquisition.get("bench_test_mode") else "PARTICIPANT_ACQUISITION",
            "participant_data_eligible": not bool(acquisition.get("bench_test_mode")),
            "bench_test_mode": bool(acquisition.get("bench_test_mode")),
            "bench_test_reason": acquisition.get("bench_test_reason") or "",
            "bench_eeg_quality_waiver_active": bool(acquisition.get("bench_eeg_quality_waiver_active")),
            "bench_readiness_bypass_active": bool(acquisition.get("bench_readiness_bypass_active")),
            "bench_bypass_preflight_path": acquisition.get("bench_bypass_preflight_path") or "",
            "run_uuid": self.active_run_uuid,
            "boundary": "Readiness is an acquisition-health gate, not evidence of cortical origin, construct validity, or a scientific effect.",
        }
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temporary.replace(path)

    @staticmethod
    def stimulus_context_identity(context: Dict[str, Any]) -> str:
        """Hash the operator-visible stimulus identity without volatile context time."""
        stimulus = context.get("stimulus", {}) if isinstance(context, dict) else {}
        if not isinstance(stimulus, dict) or not stimulus:
            return ""
        canonical = json.dumps(stimulus, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def demo_only_stimulus_reason(self) -> str:
        """Return a hard acquisition boundary for bundled/demo-only packs."""
        stimulus = self.active_context.get("stimulus", {}) if isinstance(self.active_context, dict) else {}
        if not isinstance(stimulus, dict):
            return ""
        scientific_status = str(stimulus.get("scientific_status") or "").upper()
        boundary = str(stimulus.get("collection_boundary") or "").upper()
        if scientific_status == "DEMO_ONLY" or "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION" in boundary:
            return "selected stimulus pack is DEMO_ONLY and cannot be armed for participant acquisition"
        candidate_folders: List[Path] = []
        try:
            selected_folder = self.selected_stimulus_folder()
            if selected_folder is not None:
                candidate_folders.append(selected_folder)
        except Exception:
            pass
        try:
            # A design-time protocol lock, when present, is the authority for
            # the session being prepared.  The protocol tree remains browsable
            # after approval, so using its highlighted record here could make
            # this gate inspect another protocol's asset folder while the
            # locked protocol's assets proceed to the runtime lock.
            locked = getattr(self, "locked_protocol", None)
            if isinstance(locked, dict):
                nested_record = locked.get("record")
                record = nested_record if isinstance(nested_record, dict) else locked
            else:
                record = self.selected_protocol_record()
            if record and record.get("module_family") == FAMILY_ATLAS:
                raw = str(self.cfg.get("protocol_asset_folders", {}).get(record.get("protocol_id"), "") or "")
                if raw:
                    candidate_folders.append(Path(raw).expanduser())
        except Exception:
            pass
        seen: set[str] = set()
        for folder in candidate_folders:
            detail = self.stimulus_pack_status_for_path(folder)
            root = str(detail.get("pack_root") or "")
            if root in seen:
                continue
            seen.add(root)
            if detail.get("validation_status") == "FAIL":
                return "selected stimulus pack fails its frozen file/hash contract and cannot be armed"
            status = str(detail.get("scientific_status") or "").upper()
            declared_boundary = str(detail.get("status_boundary") or "").upper()
            if status == "DEMO_ONLY" or "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION" in declared_boundary:
                return "selected stimulus pack is DEMO_ONLY and cannot be armed for participant acquisition"
        return ""

    def stimulus_pack_status_for_path(self, path: Path) -> Dict[str, Any]:
        """Find and revalidate a pack manifest at the selected folder or a nearby parent."""
        try:
            start = Path(path).expanduser().resolve(strict=False)
        except Exception:
            return {}
        if start.is_file():
            start = start.parent
        candidates = [start, *list(start.parents)[:8]]
        for root in candidates:
            manifest_path = root / "stimulus_pack_manifest.json"
            if not manifest_path.is_file():
                continue
            detail: Dict[str, Any] = {"pack_root": str(root), "validation_status": "FAIL"}
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                detail.update({
                    "pack_id": manifest.get("pack_id"),
                    "scientific_status": manifest.get("scientific_status"),
                    "status_boundary": manifest.get("status_boundary"),
                    "manifest_content_sha256": manifest.get("manifest_content_sha256"),
                })
                if validate_stimulus_pack is None:
                    detail["validation_error"] = STIMULUS_CONTRACT_IMPORT_ERROR or "pack validator unavailable"
                    return detail
                report = validate_stimulus_pack(root, media_probe=False)
                detail["validation_status"] = report.status
                detail["validation_errors"] = list(report.errors)
                return detail
            except Exception as exc:
                detail["validation_error"] = f"{type(exc).__name__}: {exc}"
                return detail
        return {}

    def mark_session_stale_for_stimulus_change(self, reason: str) -> None:
        """Immediately revoke pre-ACQUIRE arm authority after stimulus mutation."""
        acquisition = self.cfg.setdefault("acquisition", {})
        value = str(acquisition.get("session_lock_path") or "").strip()
        stage = str(acquisition.get("session_stage") or "")
        lock_identity = ""
        if value:
            try:
                lock = load_platform_json(Path(value).expanduser().resolve())  # type: ignore[misc]
                stage = str(lock.get("current_stage") or stage)
                lock_identity = str(lock.get("lock_identity_sha256") or "")
            except Exception:
                pass
        acquisition["armed"] = False
        acquisition["session_lock_status"] = "STALE_STIMULUS_CONTEXT_CHANGED"
        acquisition["stimulus_stale_reason"] = str(reason)
        # Revocation applies to a lock that has not yet granted ACQUIRE.  An
        # already-running child remains governed by its immutable lock/lease;
        # mutable UI context cannot invalidate that child's ability to record
        # a truthful terminal state.
        if stage in {"SESSION_LOCK", "ARM"} and lock_identity:
            acquisition["disarmed_lock_identity"] = lock_identity
        self.save_config()
        self.log(f"Session disarmed/stale because active stimulus context changed: {reason}\n")

    def validate_current_stimulus_against_lock(
        self,
        runtime_lock: Dict[str, Any],
        validated_protocol: Dict[str, Any],
    ) -> List[str]:
        """Compare mutable operator selection with the exact locked stimulus snapshot."""
        errors: List[str] = []
        session = runtime_lock.get("session", {})
        if not isinstance(session, dict):
            return ["runtime session stimulus metadata is malformed"]
        demo_reason = self.demo_only_stimulus_reason()
        if demo_reason and (
            not bool(session.get("bench_test_mode"))
            or not bench_may_bypass_stimulus_reason(demo_reason)
        ):
            errors.append(demo_reason)
        record = validated_protocol.get("record", {})
        if isinstance(record, dict) and record.get("module_family") == FAMILY_ATLAS:
            current_snapshot, current_errors = self.resolve_atlas_asset_snapshot(record)
            errors.extend(current_errors)
            locked_folder = str(session.get("stimulus_folder") or "")
            current_folder = str(current_snapshot.get("stimulus_folder") or "")
            if not locked_folder or not current_folder or not paths_equivalent(  # type: ignore[misc]
                current_folder, locked_folder, require_existing=True
            ):
                errors.append("selected Atlas asset folder differs from the locked folder")
            locked_assets = session.get("atlas_asset_snapshot", {})
            current_assets = current_snapshot.get("atlas_asset_snapshot", {})
            if not isinstance(locked_assets, dict) or not isinstance(current_assets, dict):
                errors.append("locked or current Atlas asset selection is malformed")
                return errors
            if set(locked_assets) != set(current_assets):
                errors.append("current Atlas asset key set differs from the lock")
            for key in sorted(set(locked_assets) & set(current_assets)):
                locked_record = locked_assets.get(key)
                current_record = current_assets.get(key)
                if not isinstance(locked_record, dict) or not isinstance(current_record, dict):
                    errors.append(f"Atlas asset binding {key} is malformed")
                    continue
                if not paths_equivalent(  # type: ignore[misc]
                    str(locked_record.get("path") or ""),
                    str(current_record.get("path") or ""),
                    require_existing=True,
                ):
                    errors.append(f"Atlas asset path changed: {key}")
                if str(locked_record.get("sha256") or "") != str(current_record.get("sha256") or ""):
                    errors.append(f"Atlas asset content changed: {key}")
            return errors
        locked_id = str(session.get("stimulus_id") or "")
        current_id = str(self.selected_stimulus_id or "")
        if current_id != locked_id:
            errors.append(f"selected stimulus id changed ({locked_id!r} -> {current_id!r})")
        locked_folder = str(session.get("stimulus_folder") or "")
        current_folder = self.selected_stimulus_folder()
        if not locked_folder or current_folder is None or not paths_equivalent(  # type: ignore[misc]
            current_folder, locked_folder, require_existing=True
        ):
            errors.append("selected stimulus folder differs from the locked folder")
        current_snapshot, current_errors = self.resolve_protocol_media_snapshot(validated_protocol)
        errors.extend(current_errors)
        locked_media = session.get("media_selection_snapshot", {})
        current_media = current_snapshot.get("selections", {})
        if not isinstance(locked_media, dict) or not isinstance(current_media, dict):
            errors.append("locked or current media selection is malformed")
            return errors
        if set(locked_media) != set(current_media):
            errors.append("current media/evidence key set differs from the lock")
        for key in sorted(set(locked_media) & set(current_media)):
            locked_record = locked_media.get(key)
            current_record = current_media.get(key)
            if not isinstance(locked_record, dict) or not isinstance(current_record, dict):
                errors.append(f"media binding {key} is malformed")
                continue
            if not paths_equivalent(  # type: ignore[misc]
                str(locked_record.get("path") or ""),
                str(current_record.get("path") or ""),
                require_existing=True,
            ):
                errors.append(f"media binding path changed: {key}")
            if str(locked_record.get("sha256") or "") != str(current_record.get("sha256") or ""):
                errors.append(f"media binding content changed: {key}")
        return errors

    def validate_active_session_lock(self) -> Tuple[str, str]:
        acquisition = self.cfg.setdefault("acquisition", {})
        value = str(acquisition.get("session_lock_path") or "").strip()
        path = Path(value).expanduser() if value else Path()
        if not value or not path.is_file():
            return "NOT_LOCKED", "create after protocol and preflight"
        try:
            payload = load_platform_json(path)  # type: ignore[misc]
        except Exception as exc:
            return "STALE", f"unreadable: {exc}"
        if payload.get("schema") != "PRAYCG_RuntimeSessionLock_v0_2":
            return "STALE", "not the canonical runtime session lock"
        report = validate_session_lock_identity(payload)  # type: ignore[misc]
        if report.status == "INELIGIBLE":
            return "STALE", "; ".join(report.errors)
        lock_identity = str(payload.get("lock_identity_sha256") or "")
        if lock_identity and acquisition.get("disarmed_lock_identity") == lock_identity:
            return "DISARMED", "create a new runtime session lock"
        session = payload.get("session", {})
        if not isinstance(session, dict):
            return "STALE", "locked session metadata is malformed"
        classification_valid, classification_detail = locked_session_classification_status(session)
        if not classification_valid:
            return "STALE", classification_detail
        locked_bench_mode = bool(session.get("bench_test_mode"))
        if locked_bench_mode != bool(acquisition.get("bench_test_mode")):
            return "STALE", "Bench Test Mode changed after the session setup was confirmed"
        session_artifact_root = Path(
            str(session.get("private_output_locations", {}).get("session_log_dir") or "")
        ).expanduser().resolve()
        if not str(session.get("private_output_locations", {}).get("session_log_dir") or ""):
            return "STALE", "locked session has no immutable artifact root"
        if path.parent.resolve() != session_artifact_root:
            return "STALE", "runtime lock is outside its bound session artifact root"
        if session_artifact_root.name != str(session.get("session_id") or ""):
            return "STALE", "session artifact root is not named for the locked run UUID"
        configured_artifact_root = str(acquisition.get("session_artifact_root") or "").strip()
        if configured_artifact_root and Path(configured_artifact_root).expanduser().resolve() != session_artifact_root:
            return "STALE", "active session artifact root changed"
        profile = self.active_hardware_profile or {}
        lock_core = payload.get("lock_core", {})
        if lock_core.get("hardware_profile_canonical_sha256") != profile.get("canonical_sha256"):
            return "STALE", "hardware profile changed"
        locked_profile_path = Path(str(session.get("hardware_profile") or "")).expanduser()
        try:
            locked_profile = load_platform_json(locked_profile_path)  # type: ignore[misc]
            locked_profile_report = validate_hardware_profile_identity(  # type: ignore[misc]
                locked_profile,
                profile_path=locked_profile_path,
            )
        except Exception as exc:
            return "STALE", f"archived hardware profile unavailable: {exc}"
        if locked_profile_report.status == "INELIGIBLE":
            return "STALE", "archived hardware profile invalid: " + "; ".join(locked_profile_report.errors)
        if locked_profile.get("canonical_sha256") != lock_core.get("hardware_profile_canonical_sha256"):
            return "STALE", "archived hardware profile changed"
        if not self.locked_protocol:
            return "STALE", "approved protocol snapshot is not selected"
        try:
            locked_snapshot_path = Path(str(session.get("approved_protocol_snapshot_path") or "")).expanduser()
            _snapshot_path, snapshot = self.load_current_protocol_snapshot(
                self.locked_protocol,
                snapshot_path_override=locked_snapshot_path,
            )
        except Exception as exc:
            return "STALE", f"approved protocol snapshot invalid: {exc}"
        if lock_core.get("protocol_snapshot_sha256") != snapshot.get("approval_envelope_sha256"):
            return "STALE", "approved protocol snapshot changed"
        if not self.active_run_uuid:
            return "STALE", "no run UUID was created in this Control Center process; start a new live preflight"
        if self.active_run_uuid and session.get("session_id") != self.active_run_uuid:
            return "STALE", "run UUID changed"
        media_bindings = session.get("media_selection_snapshot")
        if not isinstance(media_bindings, dict) or not media_bindings:
            return "STALE", "runtime media selection is not bound"
        for binding_name, record in media_bindings.items():
            if not isinstance(record, dict):
                return "STALE", f"media binding {binding_name} is malformed"
            bound_path = Path(str(record.get("path") or "")).expanduser()
            bound_hash = str(record.get("sha256") or "")
            if not bound_path.exists() or not (bound_path.is_file() or bound_path.is_dir()):
                return "STALE", f"bound media/evidence path is missing: {binding_name}"
            if not bound_hash or sha256_bound_path(bound_path) != bound_hash:
                return "STALE", f"bound media/evidence file changed: {binding_name}"
        stage = str(payload.get("current_stage") or "UNKNOWN")
        if stage in {"SESSION_LOCK", "ARM"}:
            stimulus_errors = self.validate_current_stimulus_against_lock(payload, self.locked_protocol)
            if stimulus_errors:
                return "STALE", "; ".join(stimulus_errors)
        supplemental = session.get("supplemental_preflight_evidence", [])
        if not isinstance(supplemental, list):
            return "STALE", "supplemental preflight evidence is malformed"
        for index, record in enumerate(supplemental):
            if not isinstance(record, dict):
                return "STALE", f"supplemental preflight evidence {index + 1} is malformed"
            evidence_path = Path(str(record.get("path") or "")).expanduser()
            evidence_hash = str(record.get("sha256") or "")
            if not evidence_path.is_file():
                return "STALE", f"supplemental preflight evidence is missing: {record.get('kind') or index + 1}"
            if not evidence_hash or sha256_file(evidence_path) != evidence_hash:
                return "STALE", f"supplemental preflight evidence changed: {record.get('kind') or index + 1}"
        preflight_path = Path(str(session.get("profile_preflight_report_path") or "")).expanduser()
        try:
            preflight = load_platform_json(preflight_path)  # type: ignore[misc]
        except Exception as exc:
            return "STALE", f"full-profile preflight unavailable: {exc}"
        calculated_preflight_hash = platform_sha256_json(  # type: ignore[misc]
            {key: value for key, value in preflight.items() if key != "canonical_sha256"}
        )
        if preflight.get("canonical_sha256") != calculated_preflight_hash:
            return "STALE", "full-profile preflight content changed"
        is_bench_bypass_preflight = (
            preflight.get("artifact_type") == "BENCH_TEST_READINESS_BYPASS_PREFLIGHT"
            and preflight.get("bench_test_mode") is True
            and preflight.get("bench_readiness_bypass_active") is True
            and preflight.get("participant_data_eligible") is False
            and str(preflight.get("status") or "").upper() == "CAUTION"
        )
        if locked_bench_mode and not is_bench_bypass_preflight:
            return "STALE", "bench session is not bound to its explicit non-participant readiness-bypass evidence"
        if not locked_bench_mode and is_bench_bypass_preflight:
            return "STALE", "participant session cannot use bench readiness-bypass evidence"
        if lock_core.get("preflight_report_sha256") != preflight.get("canonical_sha256"):
            return "STALE", "full-profile preflight changed"
        acquisition["session_stage"] = stage
        return "VALID", f"{path.name}; stage {stage}"

    def create_acquisition_session_lock(self) -> None:
        status = self.refresh_acquisition_readiness()
        if status == "INELIGIBLE" or not self.active_hardware_profile:
            messagebox.showerror("Cannot confirm session setup", "Resolve the INELIGIBLE equipment state first.")
            return
        if not self.locked_protocol:
            messagebox.showerror("Protocol not locked", "Select and lock a protocol in Protocol Atlas first.")
            return
        if not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        acquisition = self.cfg.setdefault("acquisition", {})
        bench_mode = bool(acquisition.get("bench_test_mode"))
        candidate_lock_path = Path(str(acquisition.get("session_lock_path") or "")).expanduser().resolve()
        reuse_reasons = runtime_lock_reuse_reasons(candidate_lock_path)  # type: ignore[misc]
        if reuse_reasons:
            messagebox.showerror(
                "Start a new equipment session",
                "This acquisition UUID has already been used and its runtime lock cannot be replaced. "
                "Choose Start Another Equipment Session, then confirm and arm the new session.\n\n- "
                + "\n- ".join(reuse_reasons),
            )
            return
        source_profile_path = Path(str(acquisition.get("hardware_profile_path") or "")).expanduser().resolve()
        preflight_path = Path(str(acquisition.get("profile_preflight_report_path") or "")).expanduser().resolve()
        detailed_path = Path(str(acquisition.get("latest_detailed_preflight_report") or "")).expanduser()
        media_snapshot, media_errors = self.resolve_protocol_media_snapshot(self.locked_protocol)
        if media_errors:
            messagebox.showerror(
                "Protocol materials are not ready",
                ("Choose each required protocol file in Prepare Materials" if self.locked_protocol.get("module_family") == FAMILY_ATLAS else "Select one compatible prepared stimulus in Prepare Materials")
                + " before confirming the session setup:\n\n- "
                + "\n- ".join(media_errors),
            )
            return
        if not bench_mode and not preflight_path.is_file():
            messagebox.showerror("30-second check required", "Run the 30-second equipment check before confirming the session setup.")
            return
        operator = simpledialog.askstring(
            "Session operator",
            "Enter the operator name recorded for this runtime session lock:",
            initialvalue=str(acquisition.get("operator_name") or ""),
            parent=self,
        )
        if not operator or not operator.strip():
            return
        if bench_mode:
            participant = f"BENCH-{str(self.active_run_uuid or '')[:8].upper()}"
        else:
            participant = simpledialog.askstring(
                "Participant pseudonym",
                "Enter a non-identifying participant code (for example P001). Do not enter a participant name:",
                initialvalue=str(acquisition.get("participant_pseudonym") or ""),
                parent=self,
            )
            if not participant or not participant.strip():
                return
            if participant.strip().upper().startswith("BENCH-"):
                messagebox.showerror(
                    "Reserved participant code",
                    "Codes beginning with BENCH- are reserved for non-participant Bench Test Mode. Enter a different pseudonym.",
                )
                return
        atlas_record = self.locked_protocol.get("record", {}) if isinstance(self.locked_protocol, dict) else {}
        is_atlas = isinstance(atlas_record, dict) and atlas_record.get("module_family") == FAMILY_ATLAS
        session_index = 1
        if is_atlas:
            session_index_value = simpledialog.askinteger(
                "Atlas session index",
                "Enter this participant's positive session number. Session 1 is correct for a first visit; later visits must use their planned index:",
                initialvalue=int(acquisition.get("session_index") or 1),
                minvalue=1,
                parent=self,
            )
            if session_index_value is None:
                return
            session_index = int(session_index_value)
        override_reason = ""
        if status == "CAUTION":
            if bench_mode:
                override_reason = str(acquisition.get("bench_test_reason") or "").strip()
            else:
                override_reason = simpledialog.askstring(
                    "Document CAUTION decision",
                    "This session is CAUTION, not PASS. Enter the specific reason the operator accepts the caution for alpha testing, or Cancel:",
                    parent=self,
                ) or ""
            if not override_reason.strip():
                return
        try:
            source_snapshot_path, snapshot = self.load_current_protocol_snapshot(self.locked_protocol)
            session_artifact_root = Path(
                str(acquisition.get("session_artifact_root") or preflight_path.parent or Path(self.cfg["log_root"]))
            ).expanduser().resolve()
            session_artifact_root.mkdir(parents=True, exist_ok=True)
            source_preflight_path = preflight_path
            source_preflight: Dict[str, Any] = {}
            source_preflight_file_sha256 = ""
            if source_preflight_path.is_file():
                source_preflight_file_sha256 = sha256_file(source_preflight_path)
                try:
                    loaded_source_preflight = load_platform_json(source_preflight_path)  # type: ignore[misc]
                    if isinstance(loaded_source_preflight, dict):
                        source_preflight = loaded_source_preflight
                except Exception:
                    source_preflight = {}
            if bench_mode:
                preflight_path = session_artifact_root / "bench_readiness_bypass_preflight.json"
                preflight = build_bench_readiness_bypass_preflight(
                    self.active_hardware_profile,
                    str(self.active_run_uuid or ""),
                    operator=operator.strip(),
                    source_preflight=source_preflight,
                    source_preflight_path=str(source_preflight_path) if source_preflight_path.is_file() else "",
                    source_preflight_file_sha256=source_preflight_file_sha256,
                )
                write_platform_json(preflight_path, preflight)  # type: ignore[misc]
                acquisition["bench_bypass_preflight_path"] = str(preflight_path)
            else:
                preflight = load_platform_json(preflight_path)  # type: ignore[misc]
                acquisition["bench_bypass_preflight_path"] = ""
            profile_path = session_artifact_root / "hardware_profile_snapshot.json"
            snapshot_path = session_artifact_root / "approved_protocol_snapshot.json"
            write_platform_json(profile_path, self.active_hardware_profile)  # type: ignore[misc]
            write_platform_json(snapshot_path, snapshot)  # type: ignore[misc]
            assigned_sequence = list(self.locked_protocol.get("branch_order") or [])
            stimulus_id = self.selected_stimulus_id or ""
            stimulus_folder = str(media_snapshot.get("stimulus_folder") or "")
            media_selection_snapshot = dict(media_snapshot.get("selections") or {})
            atlas_asset_records: Dict[str, Any] = {}
            atlas_compiled: Optional[Dict[str, Any]] = None
            if is_atlas:
                atlas_compiled = atlas_runtime_plan(
                    atlas_record,
                    participant_id=participant.strip(),
                    session_index=session_index,
                    asset_bindings=dict(media_snapshot.get("asset_bindings") or {}),
                )
                compiled_path = session_artifact_root / "atlas_compiled_timeline_v2_0.json"
                write_platform_json(compiled_path, atlas_compiled)  # type: ignore[misc]
                media_selection_snapshot["atlas_compiled_timeline"] = {
                    "path": str(compiled_path),
                    "path_kind": "file",
                    "sha256": sha256_file(compiled_path),
                }
                atlas_asset_records = dict(media_snapshot.get("atlas_asset_snapshot") or {})
                assigned_sequence = [
                    str(node.get("compiled_instance_id") or "")
                    for node in atlas_compiled.get("timeline", [])
                    if isinstance(node, dict) and str(node.get("compiled_instance_id") or "")
                ]
                stimulus_id = f"ATLAS:{atlas_record.get('protocol_id')}"
                if not stimulus_folder:
                    stimulus_folder = str(Path(str(atlas_record.get("manifest_path") or "")).resolve().parent)
            supplemental: List[Dict[str, str]] = []
            if bench_mode and source_preflight_path.is_file() and source_preflight_path != preflight_path:
                supplemental.append({
                    "kind": "SOURCE_FULL_PROFILE_PREFLIGHT",
                    "path": str(source_preflight_path),
                    "sha256": source_preflight_file_sha256,
                })
            if detailed_path.is_file():
                supplemental.append({"kind": "DETAILED_EEG_ALS_PREFLIGHT", "path": str(detailed_path), "sha256": sha256_file(detailed_path)})
            als_test_path = Path(str(acquisition.get("latest_als_barcode_test_report") or "")).expanduser()
            if als_test_path.is_file():
                supplemental.append({"kind": "ALS_BARCODE_PLACEMENT_TEST", "path": str(als_test_path), "sha256": sha256_file(als_test_path)})
            template = {
                "schema": "PRAYCG_StudySession_v0_2",
                "study_id": str(acquisition.get("study_id") or "PRAYCG_ALPHA"),
                "session_id": self.active_run_uuid,
                "participant_pseudonym": participant.strip(),
                "protocol_module": str(self.locked_protocol.get("manifest_path") or ""),
                "hardware_profile": str(profile_path),
                "hardware_profile_source_path": str(source_profile_path),
                "approved_protocol_snapshot_path": str(snapshot_path),
                "approved_protocol_snapshot_source_path": str(source_snapshot_path),
                "profile_preflight_report_path": str(preflight_path),
                "assigned_sequence": assigned_sequence,
                "stimulus_id": stimulus_id,
                "stimulus_folder": stimulus_folder,
                "stimulus_scientific_status": self.active_context.get("stimulus", {}).get("scientific_status"),
                "stimulus_collection_boundary": self.active_context.get("stimulus", {}).get("collection_boundary"),
                "media_selection_snapshot": media_selection_snapshot,
                "module_family": FAMILY_ATLAS if is_atlas else FAMILY_NATIVE,
                "session_index": session_index,
                "atlas_asset_snapshot": atlas_asset_records if is_atlas else None,
                "atlas_compiled_timeline": atlas_compiled,
                "compiled_timeline_sha256": atlas_compiled.get("canonical_sha256") if atlas_compiled else None,
                "control_center_readiness": status,
                "control_center_readiness_message": acquisition.get("readiness_message"),
                "control_center_process_id": acquisition.get("control_center_process_id"),
                "preflight_started_epoch": acquisition.get("preflight_started_epoch"),
                "session_purpose": "BENCH_TEST" if bench_mode else "PARTICIPANT_ACQUISITION",
                "participant_data_eligible": not bench_mode,
                "bench_test_mode": bench_mode,
                "bench_test_reason": str(acquisition.get("bench_test_reason") or "") if bench_mode else "",
                "bench_eeg_quality_waiver_active": bool(acquisition.get("bench_eeg_quality_waiver_active")),
                "bench_readiness_bypass_active": bench_mode,
                "bench_bypass_preflight_path": str(preflight_path) if bench_mode else "",
                "supplemental_preflight_evidence": supplemental,
                "private_output_locations": {
                    "run_root": str(self.cfg.get("run_root") or ""),
                    "analysis_root": str(self.cfg.get("analysis_root") or ""),
                    "log_root": str(self.cfg.get("log_root") or ""),
                    "session_log_dir": str(session_artifact_root),
                },
                "operator_caution_decision": {
                    "accepted": bool(override_reason.strip()),
                    "reason": override_reason.strip(),
                    "operator": operator.strip(),
                } if status == "CAUTION" else None,
            }
            draft_path = Path(str(acquisition.get("session_draft_path") or "")).expanduser().resolve()
            out = Path(str(acquisition.get("session_lock_path") or "")).expanduser().resolve()
            draft = build_session_draft(  # type: ignore[misc]
                template,
                snapshot,
                self.active_hardware_profile,
                draft_path,
                protocol_snapshot_path=snapshot_path,
                hardware_profile_path=profile_path,
            )
            if draft.get("status") != "READY_TO_CONNECT":
                raise ValueError("Session selection is not eligible: " + "; ".join(draft.get("validation", {}).get("errors", [])))
            lock = build_session_lock(  # type: ignore[misc]
                draft,
                preflight,
                out,
                operator=operator.strip(),
                allow_caution_override=bool(override_reason.strip()),
                override_reason=override_reason.strip(),
            )
            if lock.get("status") != "LOCKED_READY_TO_ARM":
                raise ValueError("Session could not be locked: " + "; ".join(lock.get("validation", {}).get("errors", [])))
        except Exception as exc:
            messagebox.showerror("Session lock failed", str(exc))
            return
        acquisition["operator_name"] = operator.strip()
        acquisition["participant_pseudonym"] = participant.strip()
        acquisition["session_index"] = session_index
        acquisition["armed"] = False
        acquisition["arm_override_reason"] = override_reason.strip()
        acquisition["disarmed_lock_identity"] = ""
        acquisition["session_lock_status"] = "VALID"
        acquisition["session_stage"] = "SESSION_LOCK"
        self.save_config()
        self.refresh_acquisition_readiness()
        messagebox.showinfo(
            "Bench session setup confirmed" if bench_mode else "Session setup confirmed",
            f"The exact protocol, materials, equipment profile, and check results are now frozen and hash-locked.\n\n{out}\n\n"
            + (
                "This lock is permanently labeled BENCH_TEST and is not eligible as participant data. Live hardware/readiness findings were preserved but bypassed.\n\n"
                if bench_mode else ""
            )
            + "Review the readiness line, then choose Mark Ready to Run.",
        )

    def open_active_session_lock(self) -> None:
        value = str(self.cfg.get("acquisition", {}).get("session_lock_path") or "").strip()
        path = Path(value).expanduser() if value else Path()
        if not value or not path.is_file():
            messagebox.showinfo(
                "No confirmed session setup",
                "Confirm Session Setup becomes available after participant checks pass, or immediately in Bench Test Mode once the reviewed setup and protocol are selected. "
                "That action creates the frozen JSON record this button opens.",
            )
            return
        open_path(path)

    def arm_acquisition_session(self) -> None:
        status = self.refresh_acquisition_readiness()
        if not self.locked_protocol:
            messagebox.showerror("Protocol not locked", "Select and lock a protocol in Protocol Atlas before arming this session.")
            return
        if status == "INELIGIBLE":
            messagebox.showerror(
                "Cannot arm",
                "The acquisition state is INELIGIBLE. Correct the reviewed setup or protocol selection. Live equipment failures are bypassed only while Bench Test Mode is on.",
            )
            return
        lock_status, detail = self.validate_active_session_lock()
        if lock_status != "VALID":
            messagebox.showerror("Session lock required", f"Create a current session lock before arming.\n\nStatus: {lock_status} — {detail}")
            return
        if not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        acquisition = self.cfg.setdefault("acquisition", {})
        path = Path(str(acquisition.get("session_lock_path") or "")).expanduser().resolve()
        try:
            lock = load_platform_json(path)  # type: ignore[misc]
            stage = str(lock.get("current_stage") or "")
            if stage == "SESSION_LOCK":
                lock = advance_session_gate(  # type: ignore[misc]
                    lock,
                    "ARM",
                    path,
                    operator=str(acquisition.get("operator_name") or lock.get("lock_core", {}).get("operator") or "UNRECORDED"),
                    evidence={
                        "control_center_readiness": status,
                        "session_purpose": "BENCH_TEST" if acquisition.get("bench_test_mode") else "PARTICIPANT_ACQUISITION",
                        "participant_data_eligible": not bool(acquisition.get("bench_test_mode")),
                        "bench_eeg_quality_waiver_active": bool(acquisition.get("bench_eeg_quality_waiver_active")),
                        "bench_readiness_bypass_active": bool(acquisition.get("bench_readiness_bypass_active")),
                    },
                )
            elif stage != "ARM":
                raise ValueError(f"Session is already at {stage or 'an unknown stage'}; create a new lock to arm another acquisition.")
        except Exception as exc:
            messagebox.showerror("Arm failed", str(exc))
            return
        acquisition["armed"] = True
        acquisition["armed_local"] = datetime.now().isoformat(timespec="seconds")
        acquisition["session_stage"] = "ARM"
        self.save_config()
        self.refresh_acquisition_readiness()
        bench_arm_notice = ""
        if acquisition.get("bench_test_mode"):
            if acquisition.get("bench_eeg_quality_waiver_active"):
                bench_arm_notice = (
                    "BENCH TEST ONLY — live readiness qualifiers, including EEG contact quality, were bypassed and these outputs are not participant data.\n\n"
                )
            else:
                bench_arm_notice = "BENCH TEST ONLY — live readiness qualifiers were bypassed and these outputs are not participant data.\n\n"
        messagebox.showinfo(
            "Bench session armed" if acquisition.get("bench_test_mode") else "Acquisition session armed",
            f"Run UUID: {self.active_run_uuid}\n\n"
            + bench_arm_notice
            + "The locked protocol runner may now launch. Any profile change or non-waivable failed check disarms the session.",
        )

    def disarm_acquisition_session(self) -> None:
        acquisition = self.cfg.setdefault("acquisition", {})
        path = Path(str(acquisition.get("session_lock_path") or "")).expanduser()
        try:
            payload = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
            acquisition["disarmed_lock_identity"] = str(payload.get("lock_identity_sha256") or "")
        except Exception:
            acquisition["disarmed_lock_identity"] = ""
        acquisition["armed"] = False
        acquisition["session_lock_status"] = "DISARMED"
        self.save_config()
        self.refresh_acquisition_readiness()
        self.log("Acquisition session disarmed; create a new runtime lock before re-arming.\n")

    def run_profile_preflight(self) -> None:
        profile_path = Path(str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "")).expanduser()
        if not self.active_hardware_profile or not profile_path.is_file() or not self.hardware_profile_approved(self.active_hardware_profile):
            messagebox.showerror("Reviewed profile required", "Build or load a lockable reviewed hardware profile before preflight.")
            return
        if not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        acquisition = self.cfg.setdefault("acquisition", {})
        acquisition["armed"] = False
        acquisition["arm_override_reason"] = ""
        acquisition["session_lock_status"] = "STALE_PREFLIGHT_RESTARTED"
        # Freshness begins with the run UUID, not this individual command.  A
        # same-run ALS placement report must not become stale merely because
        # the full-profile and detailed checks are launched afterward.
        acquisition["profile_preflight_invocation_epoch"] = time.time()
        acquisition["preflight_profile_sha256"] = self.active_hardware_profile.get("canonical_sha256")
        self.save_config()
        profile_report = Path(str(acquisition.get("profile_preflight_report_path") or "")).expanduser()
        profile_report.parent.mkdir(parents=True, exist_ok=True)
        self.launch_python_tool(
            "30-Second Full-Profile Preflight",
            "hardware_registry",
            [
                "preflight", "--profile", str(profile_path), "--duration", "30",
                "--run-uuid", str(self.active_run_uuid), "--out", str(profile_report),
            ],
        )
        roles = self.active_hardware_roles()
        if "eeg" in roles:
            lsl = self.cfg.get("lsl", {})
            detailed_dir = Path(str(acquisition["detailed_preflight_dir"])).expanduser()
            args = [
                "--eeg-stream", str(lsl.get("eeg_stream_name", "obci_eeg1")),
                "--als-stream", "ALS_PT19_Timing",
                "--duration", "30",
                "--expected-rate", str(lsl.get("eeg_expected_rate_hz", 125.0)),
                "--out-dir", str(detailed_dir),
                "--placement-profile", str(Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json"),
                "--run-uuid", str(self.active_run_uuid),
                "--hardware-profile-sha256", str(self.active_hardware_profile.get("canonical_sha256") or ""),
            ]
            if "als" in roles:
                args.extend(["--require-als", "--stream-health-only"])
            self.launch_python_tool("30-Second Detailed EEG/ALS Validation", "acquisition_preflight", args)
        self.show_profile_preflight_progress_window(duration_seconds=30)
        self.refresh_acquisition_readiness()
        self.after(33000, self.refresh_acquisition_readiness)

    def show_profile_preflight_progress_window(self, duration_seconds: int = 30) -> None:
        """Show the operator what the required background preflight is doing."""
        existing = getattr(self, "preflight_progress_window", None)
        try:
            if existing is not None and existing.winfo_exists():
                existing.lift()
                existing.focus_force()
                return
        except Exception:
            pass

        window = tk.Toplevel(self)
        self.preflight_progress_window = window
        window.title("PRAYCG Required 30-Second Equipment Check")
        window.geometry("760x430")
        window.minsize(680, 380)
        main = ttk.Frame(window, padding=14)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text="Required 30-Second Equipment Check", font=("Segoe UI", 15, "bold")).pack(anchor="w")
        ttk.Label(
            main,
            text=(
                "Two checks run together: the full locked hardware profile is sampled for stream presence, identity, "
                "delivery rate, timestamp order, gaps, and declared device checks; EEG/ALS also receives a detailed "
                "channel-health check. This window reports progress but does not arm the session."
            ),
            wraplength=720,
        ).pack(anchor="w", pady=(4, 10))
        countdown_var = tk.StringVar(value=f"Starting… {duration_seconds} seconds remaining")
        ttk.Label(main, textvariable=countdown_var, foreground="#1f4e79", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        progress = ttk.Progressbar(main, mode="determinate", maximum=max(1, duration_seconds), value=0)
        progress.pack(fill="x", pady=(4, 10))
        status_var = tk.StringVar(value="Full profile: starting  |  Detailed EEG/ALS: starting")
        ttk.Label(main, textvariable=status_var, wraplength=720).pack(anchor="w", pady=(0, 8))
        detail = tk.Text(main, height=8, wrap="word")
        detail.pack(fill="both", expand=True)
        detail.insert(
            "1.0",
            "What this checks\n"
            "• Every expected stream is visible and unambiguous.\n"
            "• Run-bound streams belong to the active equipment session.\n"
            "• Samples arrive at a plausible effective rate without timestamp reversals or large gaps.\n"
            "• EEG channels are checked for flatness, noise scale, saturation, and missing values.\n"
            "• ALS stream availability is checked here; the separate barcode test proves the controlled black/white response.\n",
        )
        detail.configure(state="disabled")
        actions = ttk.Frame(main)
        actions.pack(fill="x", pady=(8, 0))
        ttk.Button(actions, text="Open Live Stream Monitor", command=self.open_live_stream_monitor).pack(side="left")
        ttk.Button(actions, text="Open Reports Folder", command=self.open_acquisition_reports).pack(side="left", padx=5)
        ttk.Button(actions, text="Close", command=window.destroy).pack(side="right")

        started_monotonic = time.monotonic()
        acquisition = self.cfg.setdefault("acquisition", {})
        freshness = float(acquisition.get("profile_preflight_invocation_epoch") or 0.0)
        roles = self.active_hardware_roles()

        def tick() -> None:
            try:
                if not window.winfo_exists():
                    return
            except Exception:
                return
            elapsed = time.monotonic() - started_monotonic
            progress.configure(value=min(float(duration_seconds), elapsed))
            remaining = max(0, int(math.ceil(duration_seconds - elapsed)))
            countdown_var.set(
                f"Sampling… {remaining} seconds remaining"
                if remaining else "Sampling interval complete — finishing and checking reports…"
            )
            profile_report = Path(str(acquisition.get("profile_preflight_report_path") or "")).expanduser()
            profile_status, profile_detail = self.profile_preflight_status(profile_report, freshness)
            detailed_dir = Path(str(acquisition.get("detailed_preflight_dir") or "")).expanduser()
            detailed_report = self.newest_json(detailed_dir, "PRAYCG_acquisition_preflight_v1_0_*.json")
            detailed_status, detailed_detail = self.detailed_preflight_report_status(detailed_report, freshness)
            if "eeg" not in roles:
                detailed_status, detailed_detail = "NOT REQUIRED", "profile has no EEG role"
            status_var.set(
                f"Full profile: {profile_status} ({profile_detail})\n"
                f"Detailed EEG/ALS: {detailed_status} ({detailed_detail})"
            )
            finished = profile_status in {"PASS", "CAUTION", "INELIGIBLE"} and detailed_status in {
                "PASS", "WARN", "CAUTION", "FAIL", "NOT REQUIRED"
            }
            if finished:
                self.refresh_acquisition_readiness()
                countdown_var.set("Equipment check finished — review the result below and in the readiness gate.")
                return
            if elapsed >= duration_seconds + 25:
                self.refresh_acquisition_readiness()
                countdown_var.set("The check did not finish on time. Open the live monitor and reports for the specific missing stream or error.")
                return
            window.after(500, tick)

        window.after(100, tick)

        def clear_reference(_event: Any = None) -> None:
            if (_event is None or getattr(_event, "widget", None) is window) and getattr(self, "preflight_progress_window", None) is window:
                self.preflight_progress_window = None

        window.bind("<Destroy>", clear_reference)

    def run_acquisition_supervisor(self) -> None:
        profile_path = Path(str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "")).expanduser()
        if not self.active_hardware_profile or not profile_path.is_file():
            messagebox.showerror("Profile required", "Build or load an active hardware profile first.")
            return
        acquisition = self.cfg.setdefault("acquisition", {})
        out = Path(
            str(acquisition.get("supervisor_output_dir") or Path(self.cfg["log_root"]) / "acquisition_supervisor")
        ) / f"observer_{now_stamp()}"
        self.launch_python_tool(
            "Acquisition Supervisor — Observer Only",
            "acquisition_supervisor",
            ["--profile", str(profile_path), "--duration", "30", "--out", str(out)],
        )
        messagebox.showinfo(
            "Stream stability observation started",
            "For 30 seconds this optional observer watches the selected streams for stalls, gaps, timestamp reversals, "
            "and implausible delivery rate. It cannot restart equipment, create a session lock, or arm the runner.\n\n"
            f"Its report will be saved in:\n{out}",
        )

    def run_contract_acquisition_supervisor(self) -> None:
        """Run the Alpha 9 observer against explicitly selected stream contracts."""
        selected = filedialog.askopenfilenames(
            title="Select one or more Alpha 9 stream contracts",
            initialdir=str(Path(self.cfg.get("stream_contract_root") or self.pkg.parent / "tools" / "Hardware_Forge_v1_0" / "contracts").expanduser()),
            filetypes=(("PRAYCG stream contracts", "*.json"), ("All files", "*.*")),
        )
        if not selected:
            return
        duration = simpledialog.askinteger(
            "Observation duration",
            "How many seconds should identity, synchronization, drift, gaps, and clock corrections be observed?",
            initialvalue=30,
            minvalue=1,
            maxvalue=86400,
            parent=self,
        )
        if duration is None:
            return
        acquisition = self.cfg.setdefault("acquisition", {})
        out = Path(
            str(acquisition.get("supervisor_output_dir") or Path(self.cfg["log_root"]) / "acquisition_supervisor")
        ) / f"contract_observer_{now_stamp()}"
        args: List[str] = []
        for value in selected:
            path = Path(value).expanduser()
            if not path.is_file():
                messagebox.showerror("Contract missing", f"The selected stream contract is unavailable:\n{path}")
                return
            args.extend(["--contract", str(path.resolve())])
        args.extend(["--duration", str(duration), "--out", str(out)])
        if self.active_run_uuid:
            args.extend(["--run-uuid", self.active_run_uuid])
        self.launch_python_tool(
            "Alpha 9 Contract-Bound Acquisition Supervisor",
            "contract_acquisition_supervisor",
            args,
        )
        messagebox.showinfo(
            "Contract-bound observation started",
            "This read-only observer requires one unambiguous outlet per selected contract and records ordered metadata, "
            "effective rate, drift, jitter, gaps, timestamp order, clock corrections, and LSL UID continuity. "
            "It cannot restart equipment, confirm a session, or arm the runner.\n\n"
            f"Report folder:\n{out}",
        )

    def open_acquisition_reports(self) -> None:
        report = Path(str(self.cfg.get("acquisition", {}).get("profile_preflight_report_path") or "")).expanduser()
        if report.parent.is_dir():
            open_path(report.parent)
            return
        fallback = Path(self.cfg["log_root"]) / "acquisition_preflight"
        open_path(fallback)

    def build_protocol_atlas_tab(self) -> None:
        f = self.protocol_tab
        ttk.Label(
            f,
            text=(
                "Start here. Select a protocol, review its summary, and confirm that this is the protocol you intend to use. "
                "The next page will show its exact file requirements. Equipment is connected later."
            ),
            foreground="#1f4e79",
            wraplength=1080,
        ).pack(fill="x", padx=10, pady=(8, 3))

        actions = ttk.Frame(f)
        actions.pack(fill="x", padx=8, pady=(2, 4))
        selection_actions = ttk.Frame(actions)
        selection_actions.pack(side="left")
        ttk.Button(selection_actions, text="Use This Protocol", command=self.lock_selected_protocol).pack(side="left", padx=4)
        ttk.Button(selection_actions, text="Change Protocol", command=self.unlock_protocol).pack(side="left", padx=4)
        ttk.Button(selection_actions, text="Create New Protocol with AI Docs…", command=self.launch_protocol_ai_doc_builder).pack(side="left", padx=4)
        ttk.Button(selection_actions, text="Refresh Protocol List", command=self.refresh_protocol_library).pack(side="left", padx=4)
        ttk.Button(selection_actions, text="Open Protocol Library Folder", command=self.open_protocol_library).pack(side="left", padx=4)
        module_actions = ttk.Frame(actions)
        module_actions.pack(side="right")
        ttk.Button(module_actions, text="Validate / Compile Existing Module…", command=self.open_advanced_protocol_builder).pack(side="left", padx=4)
        ttk.Button(module_actions, text="Prospective Assignment Tools…", command=self.launch_prospective_study_console).pack(side="left", padx=4)

        panes = ttk.Panedwindow(f, orient="horizontal")
        panes.pack(fill="both", expand=True, padx=8, pady=4)
        browser = ttk.LabelFrame(panes, text="Protocol Atlas")
        details = ttk.LabelFrame(panes, text="Selected Protocol")
        panes.add(browser, weight=2)
        panes.add(details, weight=3)

        self.protocol_select_var = tk.StringVar(value="")
        self.protocol_tree = ttk.Treeview(
            browser,
            columns=("version", "family", "stimulus"),
            show="tree headings",
            selectmode="browse",
        )
        self.protocol_tree.heading("#0", text="Library / Protocol")
        self.protocol_tree.column("#0", width=325, stretch=True)
        for column, label, width in (
            ("version", "Version", 80),
            ("family", "Family", 125),
            ("stimulus", "Stimulus", 135),
        ):
            self.protocol_tree.heading(column, text=label)
            self.protocol_tree.column(column, width=width, stretch=column == "stimulus")
        self.protocol_tree.pack(side="left", fill="both", expand=True, padx=(5, 0), pady=5)
        protocol_scroll = ttk.Scrollbar(browser, orient="vertical", command=self.protocol_tree.yview)
        self.protocol_tree.configure(yscrollcommand=protocol_scroll.set)
        protocol_scroll.pack(side="right", fill="y", padx=(0, 5), pady=5)
        self.protocol_tree.bind("<<TreeviewSelect>>", self.on_protocol_tree_selected)
        self.protocol_tree_record_ids: Dict[str, str] = {}

        self.protocol_preview = tk.Text(details, wrap="word", height=20)
        self.protocol_preview.pack(fill="both", expand=True, padx=6, pady=6)
        self.protocol_lock_var = tk.StringVar(value="CONFIRMED PROTOCOL: none")
        ttk.Label(
            details,
            textvariable=self.protocol_lock_var,
            foreground="#7a1f1f",
            font=("Segoe UI", 10, "bold"),
            wraplength=620,
        ).pack(anchor="w", fill="x", padx=6, pady=(0, 4))
        ttk.Button(
            details,
            text="Continue to Prepare Materials →",
            command=lambda: self.nb.select(self.stim_tab),
        ).pack(fill="x", padx=6, pady=(0, 6))
        ttk.Label(
            f,
            text=(
                "Library inclusion and a successful software lock establish reproducibility of the declared runner, "
                "not scientific validity, hardware approval, or authority to acquire participant data."
            ),
            foreground="#7a1e1e",
            wraplength=1060,
        ).pack(fill="x", padx=10, pady=(1, 7))
        self.refresh_protocol_library()

    def build_runner_tab(self) -> None:
        f = self.runner_tab
        ttk.Label(
            f,
            text=(
                "The Runner is the final execution surface. It does not choose protocols, stimuli, or hardware; "
                "it shows the exact locked inputs and launches only after the governed acquisition gates pass."
            ),
            foreground="#1f4e79",
            wraplength=1080,
        ).pack(fill="x", padx=10, pady=(8, 3))

        state = ttk.LabelFrame(f, text="Locked Session Inputs — what must pass before arming")
        state.pack(fill="x", padx=8, pady=4)
        self.runner_hardware_var = tk.StringVar(value="ACQUISITION SESSION: not armed")
        self.runner_input_overview_var = tk.StringVar(
            value="Arming is blocked until the required rows below pass. CAUTION items require the existing documented review path."
        )
        ttk.Label(
            state,
            textvariable=self.runner_input_overview_var,
            foreground="#1f4e79",
            wraplength=1030,
        ).pack(anchor="w", fill="x", padx=6, pady=(5, 3))
        self.runner_input_tree = ttk.Treeview(
            state,
            columns=("status", "explanation"),
            show="tree headings",
            height=6,
            selectmode="none",
        )
        self.runner_input_tree.heading("#0", text="Required input / gate")
        self.runner_input_tree.heading("status", text="Result")
        self.runner_input_tree.heading("explanation", text="What passed or what is still needed")
        self.runner_input_tree.column("#0", width=205, stretch=False)
        self.runner_input_tree.column("status", width=120, stretch=False, anchor="center")
        self.runner_input_tree.column("explanation", width=760, stretch=True)
        self.runner_input_tree.tag_configure("PASS", foreground="#1d6b35")
        self.runner_input_tree.tag_configure("ARMED", foreground="#1d6b35")
        self.runner_input_tree.tag_configure("READY_TO_ARM", foreground="#1f4e79")
        self.runner_input_tree.tag_configure("CAUTION", foreground="#8a5a00")
        self.runner_input_tree.tag_configure("NOT_PASSED", foreground="#7a1f1f")
        self.runner_input_tree.tag_configure("WAITING", foreground="#555555")
        self.runner_input_tree.pack(fill="x", padx=6, pady=3)
        nav = ttk.Frame(state); nav.pack(fill="x", padx=6, pady=(2, 6))
        ttk.Button(nav, text="Review Protocol Lock", command=lambda: self.nb.select(self.protocol_tab)).pack(side="left", padx=(0, 4))
        ttk.Button(nav, text="Review Materials", command=lambda: self.nb.select(self.stim_tab)).pack(side="left", padx=4)
        ttk.Button(nav, text="Review Equipment and ARM", command=lambda: self.nb.select(self.acq_tab)).pack(side="left", padx=4)

        top = ttk.LabelFrame(f, text="PsychoPy-safe Approved Protocol Launch")
        top.pack(fill="x", padx=8, pady=4)
        ttk.Label(
            top,
            text=(
                "The canonical mode executes the locked runner with PsychoPy's Python interpreter so the exact "
                "session-lock environment is inherited. Coder modes are retained only for supervised debugging."
            ),
            wraplength=1000,
        ).pack(anchor="w", padx=6, pady=4)
        self.runner_mode_var = tk.StringVar(value=self.cfg.get("runner_launch_mode", "psychopy_python"))
        modes = [
            ("PsychoPy Python interpreter — canonical acquisition path", "psychopy_python"),
            ("Open locked runner in PsychoPy Coder — debugging only", "open_psychopy_coder_then_open_runner_file"),
            ("PsychoPy application with file argument — experimental", "psychopy_app_file_arg"),
            ("Regular Python — noncanonical", "regular_python"),
        ]
        for text, value in modes:
            ttk.Radiobutton(top, text=text, value=value, variable=self.runner_mode_var).pack(anchor="w", padx=6)
        self.launch_protocol_button = ttk.Button(top, text="Launch Locked Protocol Runner", command=self.launch_praycg_runner)
        self.launch_protocol_button.pack(fill="x", padx=6, pady=6)
        utilities = ttk.Frame(top); utilities.pack(fill="x", padx=6, pady=(0, 6))
        ttk.Button(utilities, text="Open Locked Runner Location", command=self.open_runner_location).pack(side="left", padx=(0, 4))
        ttk.Button(utilities, text="Open PsychoPy Coder Only", command=self.launch_psychopy_coder_only).pack(side="left", padx=4)
        ttk.Button(utilities, text="Auto-find PsychoPy / LabRecorder", command=self.autofind_common_tools).pack(side="left", padx=4)

        media = ttk.LabelFrame(f, text="Resolved Inputs and Timeline Readiness")
        media.pack(fill="both", expand=True, padx=8, pady=(4, 8))
        self.runner_detect_text = tk.Text(media, wrap="word")
        self.runner_detect_text.pack(fill="both", expand=True, padx=5, pady=5)
        ttk.Button(media, text="Refresh Locked Input Readiness", command=self.refresh_runner_detect_text).pack(fill="x", padx=5, pady=(0, 5))
        self.refresh_protocol_lock_status()
        self.refresh_runner_detect_text()

    @staticmethod
    def protocol_record_label(record: Dict[str, Any]) -> str:
        family = "Atlas adaptation" if record.get("module_family") == FAMILY_ATLAS else "Native PRAYCG"
        return f"{record['display_name']} [{record['protocol_id']} v{record['protocol_version']}; {family}]"

    def selected_protocol_record(self) -> Optional[Dict[str, Any]]:
        selected = ""
        if hasattr(self, "protocol_tree"):
            tree_selection = self.protocol_tree.selection()
            if tree_selection:
                selected = str(self.protocol_tree_record_ids.get(tree_selection[0]) or "")
        if not selected and hasattr(self, "protocol_select_var"):
            selected = self.protocol_select_var.get().strip()
        for record in self.protocol_records:
            if self.protocol_record_label(record) == selected:
                return record
        return None

    def locked_protocol_record(self) -> Optional[Dict[str, Any]]:
        """Resolve the live immutable lock back to one discovered record."""
        if not self.locked_protocol:
            return None
        matches = [
            record for record in self.protocol_records
            if str(record.get("protocol_id")) == str(self.locked_protocol.get("protocol_id"))
            and str(record.get("protocol_version")) == str(self.locked_protocol.get("protocol_version"))
            and str(record.get("module_family")) == str(self.locked_protocol.get("module_family"))
        ]
        return matches[0] if len(matches) == 1 else None

    def on_protocol_tree_selected(self, _event: Any = None) -> None:
        selection = self.protocol_tree.selection() if hasattr(self, "protocol_tree") else ()
        if not selection:
            return
        label = str(self.protocol_tree_record_ids.get(selection[0]) or "")
        if not label:
            return
        self.protocol_select_var.set(label)
        self.on_protocol_selected()

    def on_protocol_selected(self, _event: Any = None) -> None:
        """Preview a selection without changing its protocol-file bindings."""
        record = self.selected_protocol_record()
        value = ""
        asset_record = self.locked_protocol_record() or record
        if asset_record and asset_record.get("module_family") == FAMILY_ATLAS:
            mappings = self.cfg.setdefault("protocol_asset_folders", {})
            value = str(mappings.get(asset_record.get("protocol_id"), "") or "")
        if hasattr(self, "protocol_asset_folder_var"):
            self.protocol_asset_folder_var.set(value)
        self.refresh_protocol_preview()
        if hasattr(self, "protocol_asset_rows_frame"):
            self.render_protocol_asset_bindings()
        self.refresh_runner_detect_text()

    @staticmethod
    def protocol_asset_contracts(record: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Return only inputs that the operator must explicitly provide."""
        if not isinstance(record, dict):
            return []
        module = record.get("module", {})
        if not isinstance(module, dict):
            return []
        return [
            dict(item)
            for item in module.get("assets", [])
            if isinstance(item, dict) and item.get("source") == "operator_selection"
        ]

    @staticmethod
    def protocol_asset_display_label(contract: Dict[str, Any]) -> str:
        key = str(contract.get("key") or "").strip()
        if key in PROTOCOL_ASSET_LABELS:
            return PROTOCOL_ASSET_LABELS[key]
        role = str(contract.get("role") or "").strip()
        value = role or key or "Protocol file"
        return value.replace("_", " ").replace("-", " ").title()

    def protocol_asset_bindings_for_record(self, record: Dict[str, Any]) -> Dict[str, str]:
        all_bindings = self.cfg.setdefault("protocol_asset_bindings", {})
        protocol_id = str(record.get("protocol_id") or "")
        current = all_bindings.get(protocol_id)
        if not isinstance(current, dict):
            current = {}
            all_bindings[protocol_id] = current
        return current

    @staticmethod
    def protocol_asset_path_status(contract: Dict[str, Any], raw: str) -> Tuple[str, str]:
        """Return a short operator status and optional correction detail."""
        required = contract.get("required") is True
        if not raw.strip():
            return ("Missing", "Choose this file or folder.") if required else ("Optional", "May be left blank.")
        path = Path(raw).expanduser().resolve(strict=False)
        if not path.exists():
            return "Fix", "The selected path no longer exists."
        if contract.get("kind") == "directory" and not path.is_dir():
            return "Fix", "A folder is required."
        if contract.get("kind") != "directory" and not path.is_file():
            return "Fix", "A file is required."
        extensions = {str(item).casefold() for item in contract.get("allowed_extensions", [])}
        if path.is_file() and extensions and path.suffix.casefold() not in extensions:
            return "Fix", "Choose one of: " + ", ".join(sorted(extensions))
        return "Ready", ""

    def render_protocol_asset_bindings(self) -> None:
        """Render an explicit, named picker for every declared Atlas input."""
        frame = getattr(self, "protocol_asset_rows_frame", None)
        if frame is None:
            return
        for child in frame.winfo_children():
            child.destroy()
        self.protocol_asset_binding_vars = {}
        continue_button = getattr(self, "continue_to_equipment_button", None)
        record = self.locked_protocol_record()
        if not record:
            self.protocol_asset_summary_var.set(
                "Step 1: go to Choose Protocol and select Use This Protocol. File requirements will appear here."
            )
            ttk.Label(frame, text="No protocol has been confirmed yet.", foreground="#7a1e1e").grid(
                row=0, column=0, sticky="w", padx=5, pady=8
            )
            if continue_button is not None:
                continue_button.configure(state="disabled")
            return
        if record.get("module_family") != FAMILY_ATLAS:
            self.protocol_asset_summary_var.set(
                "This protocol uses a compatible prepared stimulus. Choose or prepare it in the section below; there are no separate Atlas files."
            )
            ttk.Label(frame, text="Use the compatible prepared-materials list below.").grid(
                row=0, column=0, sticky="w", padx=5, pady=8
            )
            if continue_button is not None:
                continue_button.configure(state="normal")
            return
        contracts = self.protocol_asset_contracts(record)
        if not contracts:
            self.protocol_asset_summary_var.set(
                "No external files are needed for this protocol. Its stimuli are generated by the runner, so you may continue."
            )
            ttk.Label(frame, text="Ready — this file-selection step is skipped.", foreground="#1d6b35").grid(
                row=0, column=0, sticky="w", padx=5, pady=8
            )
            if continue_button is not None:
                continue_button.configure(state="normal")
            return

        bindings = self.protocol_asset_bindings_for_record(record)
        frame.columnconfigure(1, weight=1)
        ttk.Label(frame, text="Needed item", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w", padx=4, pady=2)
        ttk.Label(frame, text="Selected file or folder", font=("Segoe UI", 9, "bold")).grid(row=0, column=1, sticky="w", padx=4, pady=2)
        ttk.Label(frame, text="Status", font=("Segoe UI", 9, "bold")).grid(row=0, column=2, sticky="w", padx=4, pady=2)
        ready_required = 0
        required_count = sum(1 for contract in contracts if contract.get("required") is True)
        for row_index, contract in enumerate(contracts, start=1):
            key = str(contract.get("key") or "")
            raw = str(bindings.get(key) or "")
            variable = tk.StringVar(value=raw)
            self.protocol_asset_binding_vars[key] = variable
            required_label = "required" if contract.get("required") is True else "optional"
            ttk.Label(
                frame,
                text=f"{self.protocol_asset_display_label(contract)} ({required_label})",
                wraplength=260,
            ).grid(row=row_index, column=0, sticky="w", padx=4, pady=2)
            ttk.Entry(frame, textvariable=variable, state="readonly").grid(
                row=row_index, column=1, sticky="ew", padx=4, pady=2
            )
            status, detail = self.protocol_asset_path_status(contract, raw)
            if status == "Ready" and contract.get("required") is True:
                ready_required += 1
            ttk.Label(
                frame,
                text=status,
                foreground="#1d6b35" if status == "Ready" else "#7a1e1e" if status in {"Missing", "Fix"} else "#555555",
            ).grid(row=row_index, column=2, sticky="w", padx=4, pady=2)
            ttk.Button(
                frame,
                text="Choose Folder" if contract.get("kind") == "directory" else "Choose File",
                command=lambda value=key: self.choose_protocol_asset_binding(value),
            ).grid(row=row_index, column=3, sticky="ew", padx=3, pady=2)
            ttk.Button(
                frame,
                text="Clear",
                command=lambda value=key: self.clear_protocol_asset_binding(value),
            ).grid(row=row_index, column=4, sticky="ew", padx=3, pady=2)
            if detail:
                variable.set(raw)

        _snapshot, errors = self.resolve_atlas_asset_snapshot(record)
        if errors:
            first = str(errors[0])
            self.protocol_asset_summary_var.set(
                f"{ready_required} of {required_count} required items selected. Next: {first}"
            )
            if continue_button is not None:
                continue_button.configure(state="disabled")
        else:
            self.protocol_asset_summary_var.set(
                f"Ready — all {required_count} required items are valid. Their paths and SHA-256 hashes will be frozen when you confirm the session setup."
            )
            if continue_button is not None:
                continue_button.configure(state="normal")

    def choose_protocol_asset_binding(self, asset_key: str) -> None:
        record = self.locked_protocol_record()
        if not record or record.get("module_family") != FAMILY_ATLAS:
            messagebox.showinfo("Choose protocol first", "Confirm an Atlas protocol before choosing its files.")
            return
        contract = next(
            (item for item in self.protocol_asset_contracts(record) if str(item.get("key") or "") == asset_key),
            None,
        )
        if contract is None:
            messagebox.showerror("Unknown protocol item", "This file requirement is not declared by the confirmed protocol.")
            return
        bindings = self.protocol_asset_bindings_for_record(record)
        previous = str(bindings.get(asset_key) or "")
        initial_value = previous or str(
            self.cfg.setdefault("protocol_asset_folders", {}).get(record.get("protocol_id"), "")
            or self.cfg.get("protocol_asset_root")
            or ""
        )
        initial_path = Path(initial_value).expanduser() if initial_value else None
        if initial_path is not None and initial_path.is_file():
            initial_path = initial_path.parent
        initial_dir = str(initial_path) if initial_path is not None and initial_path.is_dir() else None
        title = f"Choose {self.protocol_asset_display_label(contract)}"
        if contract.get("kind") == "directory":
            selected = filedialog.askdirectory(title=title, initialdir=initial_dir)
        else:
            extensions = [str(item) for item in contract.get("allowed_extensions", []) if str(item).startswith(".")]
            filetypes = [(f"{extension.upper()} files", f"*{extension}") for extension in extensions]
            filetypes.append(("All files", "*.*"))
            selected = filedialog.askopenfilename(title=title, initialdir=initial_dir, filetypes=filetypes)
        if not selected:
            return
        resolved = str(Path(selected).expanduser().resolve())
        status, detail = self.protocol_asset_path_status(contract, resolved)
        if status != "Ready":
            messagebox.showerror("File cannot be used", detail or "The selected path does not satisfy this protocol requirement.")
            return
        bindings[asset_key] = resolved
        selected_path = Path(resolved)
        compatibility_folder = selected_path if selected_path.is_dir() else selected_path.parent
        self.cfg.setdefault("protocol_asset_folders", {})[str(record.get("protocol_id"))] = str(compatibility_folder)
        self.save_config()
        if previous != resolved:
            self.mark_session_stale_for_stimulus_change(
                f"{self.protocol_asset_display_label(contract)} changed for {record.get('protocol_id')}"
            )
        self.render_protocol_asset_bindings()
        self.refresh_runner_detect_text()
        if hasattr(self, "acq_readiness_var"):
            self.refresh_acquisition_readiness()

    def clear_protocol_asset_binding(self, asset_key: str) -> None:
        record = self.locked_protocol_record()
        if not record:
            return
        bindings = self.protocol_asset_bindings_for_record(record)
        previous = str(bindings.pop(asset_key, "") or "")
        self.save_config()
        if previous:
            contract = next(
                (item for item in self.protocol_asset_contracts(record) if str(item.get("key") or "") == asset_key),
                {"key": asset_key},
            )
            self.mark_session_stale_for_stimulus_change(
                f"{self.protocol_asset_display_label(contract)} was cleared for {record.get('protocol_id')}"
            )
        self.render_protocol_asset_bindings()
        self.refresh_runner_detect_text()
        if hasattr(self, "acq_readiness_var"):
            self.refresh_acquisition_readiness()

    def choose_protocol_asset_folder(self) -> None:
        record = self.locked_protocol_record()
        if not record or record.get("module_family") != FAMILY_ATLAS:
            messagebox.showinfo("Atlas assets", "Lock a Protocol Atlas entry first. Native PRAYCG modules use the filtered Stimulus Library and MediaPrep.")
            return
        initial = str(self.protocol_asset_folder_var.get() or self.cfg.get("protocol_asset_root") or "")
        selected = filedialog.askdirectory(title=f"Select reviewed assets for {record['display_name']}", initialdir=initial or None)
        if not selected:
            return
        resolved = str(Path(selected).expanduser().resolve())
        previous = str(self.cfg.setdefault("protocol_asset_folders", {}).get(record["protocol_id"], "") or "")
        self.protocol_asset_folder_var.set(resolved)
        self.cfg["protocol_asset_folders"][record["protocol_id"]] = resolved
        self.save_config()
        if previous and Path(previous).resolve(strict=False) != Path(resolved).resolve(strict=False):
            self.mark_session_stale_for_stimulus_change(f"Atlas asset folder changed for {record['protocol_id']}")
        self.refresh_runner_detect_text()

    def use_suggested_protocol_asset_folder(self) -> None:
        record = self.locked_protocol_record()
        if not record or record.get("module_family") != FAMILY_ATLAS:
            messagebox.showinfo("Atlas assets", "Lock a Protocol Atlas entry first. Native PRAYCG modules use the filtered Stimulus Library and MediaPrep.")
            return
        root = Path(str(self.cfg.get("protocol_asset_root") or (Path(self.cfg["praycg_home"]) / "protocol_assets"))).expanduser().resolve()
        folder = root / slugify(str(record.get("protocol_id") or "protocol"))
        folder.mkdir(parents=True, exist_ok=True)
        previous = str(self.cfg.setdefault("protocol_asset_folders", {}).get(record["protocol_id"], "") or "")
        self.protocol_asset_folder_var.set(str(folder))
        self.cfg["protocol_asset_folders"][record["protocol_id"]] = str(folder)
        self.save_config()
        if previous and Path(previous).resolve(strict=False) != folder:
            self.mark_session_stale_for_stimulus_change(f"Atlas asset folder changed for {record['protocol_id']}")
        self.refresh_runner_detect_text()

    def refresh_protocol_library(self) -> None:
        self.protocol_library_root = packaged_protocol_atlas_root()
        self.cfg["protocol_library_root"] = str(self.protocol_library_root)
        self.protocol_records, self.protocol_library_errors = discover_protocol_modules(self.protocol_library_root)
        labels = [self.protocol_record_label(record) for record in self.protocol_records]
        preferred = str(self.cfg.get("selected_protocol_id", "PRAYCG3"))
        chosen = next((self.protocol_record_label(record) for record in self.protocol_records if record["protocol_id"] == preferred), labels[0] if labels else "")
        if hasattr(self, "protocol_select_var"):
            self.protocol_select_var.set(chosen)
        if hasattr(self, "protocol_tree"):
            self.protocol_tree.delete(*self.protocol_tree.get_children())
            self.protocol_tree_record_ids.clear()
            navigation = self.protocol_stimulus_model.protocol_navigation()
            inserted: set[str] = set()
            for node in navigation.get("nodes", []):
                if node.get("node_type") != "folder":
                    continue
                node_id = str(node.get("node_id"))
                self.protocol_tree.insert("", "end", iid=node_id, text=node.get("display_name"), open=True)
                inserted.add(node_id)
            selected_iid = ""
            record_by_identity = {
                (str(record.get("protocol_id")), str(record.get("protocol_version"))): record
                for record in self.protocol_records
            }
            for node in navigation.get("nodes", []):
                if node.get("node_type") != "protocol":
                    continue
                identity = (str(node.get("protocol_id")), str(node.get("protocol_version")))
                record = record_by_identity.get(identity)
                if not record:
                    continue
                node_id = str(node.get("node_id"))
                parent_id = str(node.get("parent_id") or "")
                if parent_id not in inserted:
                    parent_id = ""
                required = list(record.get("required_asset_keys") or [])
                stimulus_label = (
                    "Prepared media"
                    if record.get("module_family") == FAMILY_NATIVE
                    else "Runner-generated"
                    if not required
                    else "Reviewed assets"
                )
                label = self.protocol_record_label(record)
                self.protocol_tree.insert(
                    parent_id,
                    "end",
                    iid=node_id,
                    text=record.get("display_name"),
                    values=(record.get("protocol_version"), "Native" if record.get("module_family") == FAMILY_NATIVE else "Atlas", stimulus_label),
                )
                self.protocol_tree_record_ids[node_id] = label
                if label == chosen:
                    selected_iid = node_id
            if selected_iid:
                self.protocol_tree.selection_set(selected_iid)
                self.protocol_tree.focus(selected_iid)
                self.protocol_tree.see(selected_iid)
            if navigation.get("errors"):
                self.protocol_library_errors.extend(str(item) for item in navigation.get("errors", []))
        self.on_protocol_selected()
        self.refresh_protocol_lock_status()

    def load_current_protocol_snapshot(
        self,
        validated_lock: Dict[str, Any],
        snapshot_path_override: Optional[Path] = None,
    ) -> Tuple[Path, Dict[str, Any]]:
        """Load the design-time approved snapshot paired with the simple runner-selection lock."""
        value = str(
            snapshot_path_override
            or self.cfg.setdefault("acquisition", {}).get("approved_protocol_snapshot_path")
            or ""
        ).strip()
        if not value:
            raise FileNotFoundError("No approved protocol snapshot is paired with this selection.")
        path = Path(value).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"Approved protocol snapshot not found: {path}")
        payload = load_platform_json(path)  # type: ignore[misc]
        if payload.get("schema") != "PRAYCG_ApprovedProtocolSnapshot_v0_2" or payload.get("status") != "APPROVED":
            raise ValueError("The paired protocol artifact is not an approved design-time snapshot.")
        core = payload.get("snapshot_core", {})
        if not isinstance(core, dict) or payload.get("snapshot_sha256") != platform_sha256_json(core):  # type: ignore[misc]
            raise ValueError("The approved protocol snapshot identity is invalid.")
        envelope = {key: value for key, value in payload.items() if key != "approval_envelope_sha256"}
        if (
            not str(payload.get("approval_envelope_sha256") or "")
            or payload.get("approval_envelope_sha256") != platform_sha256_json(envelope)  # type: ignore[misc]
            or payload.get("validation_status") != "PASS"
            or not str(payload.get("human_reviewed_by") or "").strip()
            or str(payload.get("human_reviewed_by") or "").strip().upper() in {"UNRECORDED", "EDIT_ME", "UNKNOWN"}
        ):
            raise ValueError("The protocol approval envelope is missing, unreviewed, or has changed.")
        snapshot_library_root = Path(str(payload.get("library_root") or self.protocol_library_root)).expanduser().resolve()
        expected_snapshot_root = packaged_protocol_library_root(str(validated_lock.get("module_family") or ""))
        if snapshot_library_root != expected_snapshot_root:
            raise ValueError(
                "The approved protocol snapshot references a non-packaged runnable library root. "
                "External protocol folders are staging/review inputs only."
            )
        engine_path = (snapshot_library_root / str(core.get("engine_entry") or "")).resolve()
        checks = {
            "protocol_id": str(core.get("protocol_id")) == str(validated_lock.get("protocol_id")),
            "protocol_version": str(core.get("protocol_version")) == str(validated_lock.get("protocol_version")),
            "protocol module": str(core.get("protocol_module_sha256")) == str(validated_lock.get("manifest_sha256")),
            "runner": str(core.get("runner_sha256")) == str(validated_lock.get("runner_sha256")),
            "shared protocol engine": bool(engine_path.is_file()) and sha256_file(engine_path) == str(core.get("engine_sha256") or ""),
        }
        failed = [name for name, passed in checks.items() if not passed]
        if failed:
            raise ValueError("Approved protocol snapshot does not match the selected protocol: " + ", ".join(failed))
        return path, payload

    @staticmethod
    def protocol_lock_ui_identity(lock: Optional[Dict[str, Any]]) -> Optional[Tuple[str, ...]]:
        """Return the lock fields that can change protocol-filtered user choices."""
        if not lock:
            return None
        return tuple(
            str(lock.get(key) or "")
            for key in (
                "protocol_id",
                "protocol_version",
                "module_family",
                "manifest_sha256",
                "runner_sha256",
                "approval_envelope_sha256",
            )
        )

    def refresh_protocol_lock_status(self, update_acquisition: bool = True) -> None:
        previous_lock_identity = self.protocol_lock_ui_identity(self.locked_protocol)
        self.locked_protocol = None
        text = "APPROVED PROTOCOL SNAPSHOT: none - review, approve, and select a protocol before launch."
        color = "#7a1f1f"
        try:
            validated = validate_protocol_lock(self.protocol_lock_path, self.protocol_library_root)
            snapshot_path, snapshot = self.load_current_protocol_snapshot(validated)
            self.locked_protocol = {
                **validated,
                "approved_snapshot_path": str(snapshot_path),
                "approved_snapshot_sha256": snapshot.get("snapshot_sha256"),
                "approval_envelope_sha256": snapshot.get("approval_envelope_sha256"),
                "engine_sha256": snapshot.get("snapshot_core", {}).get("engine_sha256"),
            }
            text = (
                f"APPROVED PROTOCOL SNAPSHOT: {validated['display_name']} "
                f"[{validated['protocol_id']} v{validated['protocol_version']}] | "
                f"module {str(validated['manifest_sha256'])[:12]}... | "
                f"runner {str(validated['runner_sha256'])[:12]}... | validation PASS"
            )
            color = "#1d6b35"
        except FileNotFoundError:
            pass
        except Exception as exc:
            text = f"APPROVED PROTOCOL SNAPSHOT: INVALID/STALE - {exc}"
        if hasattr(self, "protocol_lock_var"):
            self.protocol_lock_var.set(text)
        if hasattr(self, "launch_protocol_button"):
            self.launch_protocol_button.configure(state="normal" if self.locked_protocol else "disabled")
        # ttk foreground is theme-dependent; a direct label option is not retained here.
        self.cfg["protocol_lock_status"] = "PASS" if self.locked_protocol else "UNLOCKED_OR_INVALID"
        current_lock_identity = self.protocol_lock_ui_identity(self.locked_protocol)
        if hasattr(self, "stim_tree") and current_lock_identity != previous_lock_identity:
            self.refresh_protocol_stimulus_ui()
        if hasattr(self, "context_workflow_var"):
            self.refresh_active_context_ui()
        if update_acquisition and hasattr(self, "acq_readiness_var"):
            self.refresh_acquisition_readiness()

    def refresh_protocol_preview(self) -> None:
        if not hasattr(self, "protocol_preview"):
            return
        self.protocol_preview.configure(state="normal")
        self.protocol_preview.delete("1.0", "end")
        record = self.selected_protocol_record()
        if record:
            atlas = record.get("module_family") == FAMILY_ATLAS
            order_label = "Declared timeline" if atlas else "Fixed branch order"
            family_label = "Protocol Atlas v2.0 adaptation" if atlas else "Native PRAYCG protocol"
            adaptation = record.get("module", {}).get("adaptation_status", {}) if atlas else {}
            adaptation_text = str(adaptation.get("classification") or "") if isinstance(adaptation, dict) else ""
            required_assets = list(record.get("required_asset_keys") or [])
            preview_text = (
                f"{record['display_name']}\n"
                f"Protocol ID/version: {record['protocol_id']} v{record['protocol_version']}\n"
                f"Family: {family_label}\n"
                f"Engine family: {record.get('engine_family', 'praycg_fixed_branch')}\n"
                f"{order_label} ({record['branch_count']}): {' -> '.join(record['branch_order'])}\n"
                f"Required external assets: {', '.join(required_assets) if required_assets else 'none'}\n"
            )
            if adaptation_text:
                preview_text += f"Adaptation status: {adaptation_text}\n"
            preview_text += (
                f"Manifest SHA-256: {record['manifest_sha256']}\n"
                f"Runner SHA-256: {record['runner_sha256']}\n"
                f"Hardware stack effect: {record.get('hardware_stack_effect', 'INDEPENDENT_PROFILE_ONLY')}\n"
                f"Purpose: {record['short_description']}\n"
                f"Boundary: {record['scientific_boundary']}\n"
            )
            self.protocol_preview.insert(
                "end",
                preview_text,
            )
        else:
            self.protocol_preview.insert("end", "No valid protocol modules were found.\n")
        if self.protocol_library_errors:
            self.protocol_preview.insert("end", "\nLibrary errors:\n- " + "\n- ".join(self.protocol_library_errors))
        self.protocol_preview.configure(state="disabled")

    def lock_selected_protocol(self) -> None:
        record = self.selected_protocol_record()
        if record is None:
            messagebox.showwarning("No protocol selected", "Select a valid protocol module first.")
            return
        reviewer = simpledialog.askstring(
            "Approve protocol snapshot",
            "Enter the name of the person who reviewed this fixed protocol definition and runner:\n\n"
            "This approves the design-time snapshot only; it does not approve hardware or arm a session.",
            initialvalue=str(self.cfg.setdefault("acquisition", {}).get("operator_name") or ""),
            parent=self,
        )
        if not reviewer or not reviewer.strip():
            return
        try:
            build_root = user_config_dir() / "approved_protocol_snapshots"
            record_library_root = Path(str(record.get("library_root") or self.protocol_library_root)).expanduser().resolve()
            out, snapshot = compile_protocol(  # type: ignore[misc]
                Path(str(record["manifest_path"])),
                record_library_root,
                build_root,
                human_reviewed_by=reviewer.strip(),
            )
            if snapshot.get("status") != "APPROVED":
                raise ValueError("Protocol validation did not produce an approved snapshot.")
            snapshot_path = out / f"approved_protocol_snapshot_{str(snapshot['approval_envelope_sha256'])[:12]}.json"
            write_protocol_lock(record, self.protocol_lock_path)
            self.cfg["selected_protocol_id"] = record["protocol_id"]
            self.cfg["protocol_library_root"] = str(self.protocol_library_root)
            acquisition = self.cfg.setdefault("acquisition", {})
            acquisition["approved_protocol_snapshot_path"] = str(snapshot_path)
            acquisition["operator_name"] = reviewer.strip()
            acquisition["armed"] = False
            acquisition["disarmed_lock_identity"] = ""
            acquisition["session_lock_status"] = "STALE_PROTOCOL_CHANGED"
            self.save_config()
            self.refresh_protocol_lock_status()
            messagebox.showinfo(
                "Protocol snapshot approved",
                f"Approved and selected {record['display_name']}.\n\n"
                f"{'Timeline' if record.get('module_family') == FAMILY_ATLAS else 'Branch order'}: {' -> '.join(record['branch_order'])}\n\n"
                "The module, runner, and engine hashes are frozen. The protocol does not select hardware; a separate runtime session lock is still required after live hardware preflight.",
            )
        except Exception as exc:
            messagebox.showerror("Protocol lock failed", str(exc))

    def unlock_protocol(self) -> None:
        try:
            if self.protocol_lock_path.is_file():
                self.protocol_lock_path.unlink()
            acquisition = self.cfg.setdefault("acquisition", {})
            acquisition["approved_protocol_snapshot_path"] = ""
            acquisition["armed"] = False
            acquisition["disarmed_lock_identity"] = ""
            acquisition["session_lock_status"] = "STALE_PROTOCOL_CHANGED"
            self.save_config()
            self.refresh_protocol_lock_status()
            self.clear_workspace_component("protocol", "Operator cleared the active protocol lock.")
            messagebox.showinfo("Protocol selection cleared", "No approved protocol snapshot is selected. Approve and select a module before the next launch.")
        except Exception as exc:
            messagebox.showerror("Unlock failed", str(exc))

    def open_protocol_library(self) -> None:
        open_path(self.protocol_library_root)

    def open_advanced_protocol_builder(self) -> None:
        """Open the declarative protocol builder without exposing the retired all-purpose Workbench."""
        if not self.platform_core_available():
            return
        existing = getattr(self, "advanced_builder_window", None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            existing.focus_force()
            return
        win = tk.Toplevel(self)
        self.advanced_builder_window = win
        win.title("Advanced Protocol Builder — declarative modules only")
        win.geometry("920x680")
        win.transient(self)
        ttk.Label(
            win,
            text=(
                "Use this only to validate a new or modified protocol module. Standard PRAYCG3, PRAYCG4, and SMG "
                "remain selectable in Protocol Atlas and do not need this validator. For a new idea, use Create New Protocol with AI Docs first. No arbitrary code is executed here."
            ),
            foreground="#7a1e1e",
            wraplength=860,
        ).pack(fill="x", padx=10, pady=8)
        record = self.selected_protocol_record()
        initial_module = str(record.get("manifest_path")) if record else ""
        module_var = tk.StringVar(value=initial_module)
        out_var = tk.StringVar(value=str(Path(self.cfg["praycg_home"]) / "protocol_builds"))

        def path_row(label: str, variable: tk.StringVar, folder: bool = False) -> None:
            row = ttk.Frame(win); row.pack(fill="x", padx=10, pady=3)
            ttk.Label(row, text=label, width=22).pack(side="left")
            ttk.Entry(row, textvariable=variable).pack(side="left", fill="x", expand=True, padx=4)
            def browse() -> None:
                value = filedialog.askdirectory(title=f"Select {label}") if folder else filedialog.askopenfilename(
                    title=f"Select {label}", filetypes=(("Protocol JSON", "*.json"), ("All", "*.*"))
                )
                if value:
                    variable.set(value)
            ttk.Button(row, text="Browse", command=browse).pack(side="left")

        path_row("Protocol module", module_var)
        path_row("Build output folder", out_var, folder=True)
        output = tk.Text(win, height=27, wrap="word")
        output.pack(fill="both", expand=True, padx=10, pady=6)

        def show(payload: Any) -> None:
            output.configure(state="normal")
            output.delete("1.0", "end")
            output.insert("end", json.dumps(payload, indent=2, default=str))
            output.configure(state="disabled")

        def selected() -> Tuple[Path, Dict[str, Any]]:
            path = Path(module_var.get()).expanduser().resolve()
            if not path.is_file():
                raise FileNotFoundError(f"Protocol module not found: {path}")
            return path, load_platform_json(path)  # type: ignore[misc]

        def validate_action() -> None:
            try:
                path, module = selected()
                report = validate_protocol(module, library_root=self.protocol_library_root)  # type: ignore[misc]
                show({**report.as_dict(), "module": str(path), "timeline": protocol_timeline(module)})  # type: ignore[misc]
            except Exception as exc:
                messagebox.showerror("Protocol validation failed", str(exc), parent=win)

        def dry_run_action() -> None:
            try:
                _path, module = selected()
                report = validate_protocol(module, library_root=self.protocol_library_root)  # type: ignore[misc]
                out = Path(out_var.get()).expanduser().resolve()
                target = out / f"{slugify(module.get('protocol_id'), 'protocol')}_dry_run.json"
                write_platform_json(target, {**report.as_dict(), "execution": "NOT_STARTED", "timeline": protocol_timeline(module)})  # type: ignore[misc]
                show({"status": report.status, "execution": "NOT_STARTED", "dry_run_schedule": str(target)})
            except Exception as exc:
                messagebox.showerror("Dry run failed", str(exc), parent=win)

        def compile_action() -> None:
            reviewer = simpledialog.askstring(
                "Human review required",
                "Enter the name of the person who reviewed this protocol definition:",
                parent=win,
            )
            if not reviewer or not reviewer.strip():
                return
            try:
                path, _module = selected()
                out, lock = compile_protocol(  # type: ignore[misc]
                    path,
                    self.protocol_library_root,
                    Path(out_var.get()).expanduser().resolve(),
                    human_reviewed_by=reviewer.strip(),
                )
                show({"compiled_output": str(out), "lock": lock})
                messagebox.showinfo(
                    "Advanced build complete",
                    "The reviewed candidate was compiled and hash-locked. It is not silently installed or selected. "
                    "Review the output, then place an approved manifest in the protocol library before rescanning.",
                    parent=win,
                )
            except Exception as exc:
                messagebox.showerror("Compile failed", str(exc), parent=win)

        buttons = ttk.Frame(win); buttons.pack(fill="x", padx=10, pady=(0, 8))
        ttk.Button(buttons, text="Validate Three Layers", command=validate_action).pack(side="left", padx=3)
        ttk.Button(buttons, text="Write Dry-Run Timeline", command=dry_run_action).pack(side="left", padx=3)
        ttk.Button(buttons, text="Human Review + Compile Snapshot", command=compile_action).pack(side="left", padx=3)
        ttk.Button(buttons, text="Open Build Folder", command=lambda: open_path(Path(out_var.get()).expanduser())).pack(side="right", padx=3)

    def build_analysis_tab(self) -> None:
        self.analysis_nb = ttk.Notebook(self.analysis_tab)
        self.analysis_nb.pack(fill="both", expand=True, padx=6, pady=6)
        self.analysis_plan_page = ttk.Frame(self.analysis_nb)
        self.analysis_tools_page = ttk.Frame(self.analysis_nb)
        self.analysis_review_page = ttk.Frame(self.analysis_nb)
        self.analysis_nb.add(self.analysis_plan_page, text="Plan + Dependency Graph")
        self.analysis_nb.add(self.analysis_tools_page, text="Direct Tools")
        self.analysis_nb.add(self.analysis_review_page, text="Review + Results Bundle")
        self.build_analysis_orchestration_page(self.analysis_plan_page)
        self.build_legacy_analysis_tab(self.analysis_tools_page)
        self.build_results_review_page(self.analysis_review_page)
        self.refresh_analysis_orchestration_ui()
        self.refresh_results_bundle_ui()

    def build_legacy_analysis_tab(self, f: ttk.Frame) -> None:
        module_catalog = ttk.LabelFrame(f, text="Analysis Module Catalog — alpha foundation")
        module_catalog.pack(fill="x", padx=8, pady=(8, 4))
        ttk.Button(module_catalog, text="Open Analysis Module Catalog", command=self.launch_analysis_module_catalog).pack(side="left", padx=5, pady=5)
        ttk.Button(module_catalog, text="Refresh Catalog", command=self.refresh_analysis_module_catalog_ui).pack(side="left", padx=5, pady=5)
        self.analysis_catalog_var = tk.StringVar(value="Catalog loading…")
        ttk.Label(
            module_catalog,
            textvariable=self.analysis_catalog_var,
            foreground="#555555",
            wraplength=790,
        ).pack(side="left", fill="x", expand=True, padx=6, pady=5)
        selection = ttk.LabelFrame(f, text="Selected Run and Analysis Outputs")
        selection.pack(fill="x", padx=8, pady=4)
        self.analysis_run_var = tk.StringVar(value="Run: none")
        self.analysis_core_var = tk.StringVar(value="Core: none")
        self.analysis_chain_var = tk.StringVar(value="Chain: none")
        rows = [
            (self.analysis_run_var, "Select Run Folder", self.select_run_folder),
            (self.analysis_core_var, "Select Core Output", self.select_core_analysis_folder),
            (self.analysis_chain_var, "Select Chain Output", self.select_chain_analysis_folder),
        ]
        for row_index, (variable, text, command) in enumerate(rows):
            ttk.Label(selection, textvariable=variable).grid(row=row_index, column=0, sticky="ew", padx=6, pady=2)
            ttk.Button(selection, text=text, command=command).grid(row=row_index, column=1, sticky="ew", padx=3, pady=2)
        resolve_row = ttk.Frame(selection); resolve_row.grid(row=3, column=0, columnspan=2, sticky="ew", padx=6, pady=2)
        ttk.Label(resolve_row, text="Resolve ambiguous raw inputs:").pack(side="left")
        ttk.Button(resolve_row, text="Choose XDF", command=lambda: self.select_run_artifact("xdf", "Select XDF", (("XDF", "*.xdf"), ("All", "*.*")))).pack(side="left", padx=3)
        ttk.Button(resolve_row, text="Choose Event Log", command=lambda: self.select_run_artifact("events", "Select event JSON/CSV", (("Events", "*.json *.csv"), ("All", "*.*")))).pack(side="left", padx=3)
        ttk.Button(resolve_row, text="Choose Channel Map", command=lambda: self.select_run_artifact("channel_map", "Select channel map", (("CSV", "*.csv"), ("All", "*.*")))).pack(side="left", padx=3)
        catalog = ttk.Frame(selection); catalog.grid(row=4, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        ttk.Label(catalog, text="Recent / pinned runs:").pack(side="left")
        self.run_catalog_var = tk.StringVar()
        self.run_catalog_combo = ttk.Combobox(catalog, textvariable=self.run_catalog_var, state="readonly")
        self.run_catalog_combo.pack(side="left", fill="x", expand=True, padx=4)
        ttk.Button(catalog, text="Use Run", command=self.use_run_catalog_selection).pack(side="left", padx=2)
        ttk.Button(catalog, text="Pin / Unpin", command=self.toggle_pin_catalog_run).pack(side="left", padx=2)
        selection.columnconfigure(0, weight=1)
        actions = ttk.LabelFrame(f, text="Context-Aware Workflow")
        actions.pack(fill="x", padx=8, pady=4)
        self.analysis_buttons: Dict[str, ttk.Button] = {}
        definitions = [
            ("master_suite", "1. Open Master Suite", self.launch_master_suite),
            ("chain", "2. Run Full Chain", self.launch_master_chain),
            ("hocr", "HOC-R", self.launch_hocr_shotorder),
            ("confounds", "Confound Expansion", self.launch_confound_expanded),
            ("als_barcode", "ALS Barcode", self.launch_als_barcode_detector),
            ("visualizer", "Visualizer", self.launch_visualizer),
            ("interpreter", "Interpreter", self.launch_offline_interpreter),
        ]
        for index, (key, text, command) in enumerate(definitions):
            button = ttk.Button(actions, text=text, command=command)
            button.grid(row=index // 4, column=index % 4, sticky="ew", padx=4, pady=4)
            actions.columnconfigure(index % 4, weight=1)
            self.analysis_buttons[key] = button
        exploratory = ttk.LabelFrame(f, text="Exploratory Analysis — isolated from primary conclusions")
        exploratory.pack(fill="x", padx=8, pady=4)
        ttk.Label(
            exploratory,
            text="CAI/SID, Micro Handoff, and Cue-Locked Gamma Forensics are exploratory. They do not alter Master Suite eligibility or primary conclusions and are not validated consciousness measures.",
            foreground="#8a1c1c",
            wraplength=1050,
        ).grid(row=0, column=0, columnspan=4, sticky="w", padx=6, pady=(4, 2))
        self.exploratory_buttons: Dict[str, ttk.Button] = {}
        exploratory_definitions = [
            ("cai_readiness", "1. CAI Readiness Preflight", self.run_cai_readiness_preflight),
            ("cai_sid", "2. CAI/SID v0.2", self.launch_cai_sid_exploratory),
            ("autonomic", "Continuous Autonomic / RespDualPath", self.launch_continuous_autonomic),
            ("micro_handoff", "Micro Handoff v0.1", self.launch_micro_handoff),
            ("clgf", "Cue-Locked Gamma Forensics v0.1", self.launch_cue_locked_gamma_forensics),
        ]
        for index, (key, text, command) in enumerate(exploratory_definitions):
            button = ttk.Button(exploratory, text=text, command=command)
            button.grid(row=1 + index // 3, column=index % 3, sticky="ew", padx=4, pady=4)
            exploratory.columnconfigure(index % 3, weight=1)
            self.exploratory_buttons[key] = button
        post_run = ttk.LabelFrame(f, text="Canonical Post-Run Gate Record — operator-reviewed evidence")
        post_run.pack(fill="x", padx=8, pady=4)
        self.post_run_gate_var = tk.StringVar(value="Session gate: load a finalized runtime lock")
        ttk.Label(
            post_run,
            textvariable=self.post_run_gate_var,
            foreground="#704000",
            wraplength=1040,
        ).grid(row=0, column=0, columnspan=4, sticky="w", padx=6, pady=(4, 2))
        ttk.Button(
            post_run,
            text="Finalize Interrupted Run",
            command=self.finalize_interrupted_run,
        ).grid(row=1, column=0, columnspan=4, sticky="ew", padx=4, pady=4)
        for index, (stage, label) in enumerate((
            ("QC", "Record QC Evidence"),
            ("ANALYZE", "Record Analysis Evidence"),
            ("EXPORT", "Record Export Evidence"),
            ("VERIFY", "Record Verification Evidence"),
        )):
            ttk.Button(post_run, text=label, command=lambda value=stage: self.record_post_run_gate(value)).grid(
                row=2, column=index, sticky="ew", padx=4, pady=4
            )
            post_run.columnconfigure(index, weight=1)
        standards = ttk.LabelFrame(f, text="Standards Export / Verification")
        standards.pack(fill="x", padx=8, pady=4)
        ttk.Button(standards, text="Prepare BIDS Export / Verify…", command=self.open_bids_export_dialog).pack(side="left", padx=5, pady=5)
        ttk.Button(standards, text="Open Latest BIDS Export", command=self.open_latest_bids_export).pack(side="left", padx=5, pady=5)
        ttk.Label(
            standards,
            text="XDF remains the provenance source. RR intervals remain irregular; regular physiology is written only after timestamp checks.",
            foreground="#7a1e1e",
            wraplength=760,
        ).pack(side="left", fill="x", expand=True, padx=6, pady=5)
        utility = ttk.Frame(f); utility.pack(fill="x", padx=8, pady=(0, 4))
        ttk.Button(utility, text="Refresh Resolution", command=self.scan_selected_run_folder).pack(side="left", padx=4)
        ttk.Button(utility, text="Open Source Run", command=lambda: open_path(self.selected_run_folder) if self.selected_run_folder else messagebox.showinfo("No run", "Select a run folder first.")).pack(side="left", padx=4)
        ttk.Button(utility, text="Open Analysis Root", command=lambda: open_path(Path(self.cfg["analysis_root"]))).pack(side="left", padx=4)
        ttk.Button(utility, text="Open Preferred Review Folder", command=self.open_preferred_review_folder).pack(side="left", padx=4)
        ttk.Label(utility, text="Prefills only; no analysis starts until you click Run inside the launched tool.", foreground="#555555").pack(side="right", padx=4)
        preview = ttk.LabelFrame(f, text="Resolved Inputs, Provenance, and Readiness")
        preview.pack(fill="both", expand=True, padx=8, pady=4)
        self.analysis_text = tk.Text(preview, wrap="word")
        self.analysis_text.pack(fill="both", expand=True, padx=8, pady=4)
        self.refresh_run_catalog()
        self.refresh_analysis_module_catalog_ui()
        self.refresh_active_context_ui()

    def build_analysis_orchestration_page(self, f: ttk.Frame) -> None:
        boundary = ttk.LabelFrame(f, text="Governed Analysis Plan")
        boundary.pack(fill="x", padx=8, pady=(8, 4))
        self.analysis_plan_status_var = tk.StringVar(value="Create/open a Study Workspace and select a run folder.")
        ttk.Label(
            boundary,
            textvariable=self.analysis_plan_status_var,
            wraplength=1060,
            foreground="#704000",
        ).pack(fill="x", padx=6, pady=4)
        ttk.Label(
            boundary,
            text="Lock intended analyses before reviewing condition outcomes. Registry inclusion or software PASS never grants scientific validity or primary authority.",
            wraplength=1060,
        ).pack(fill="x", padx=6, pady=(0, 4))
        controls = ttk.Frame(boundary); controls.pack(fill="x", padx=4, pady=(0, 4))
        ttk.Button(controls, text="Refresh Eligibility", command=self.refresh_analysis_orchestration_ui).pack(side="left", padx=3)
        ttk.Button(controls, text="Add Selected to Plan", command=self.add_selected_analysis_module).pack(side="left", padx=3)
        ttk.Button(controls, text="Remove Selected", command=self.remove_selected_analysis_module).pack(side="left", padx=3)
        ttk.Button(controls, text="Lock Analysis Plan", command=self.lock_analysis_plan_ui).pack(side="left", padx=3)
        ttk.Button(controls, text="Launch Next Ready", command=self.launch_next_analysis_module).pack(side="left", padx=3)
        ttk.Button(controls, text="Launch Selected", command=self.launch_selected_analysis_module).pack(side="left", padx=3)
        ttk.Button(controls, text="Record Selected Output", command=self.record_selected_analysis_output).pack(side="left", padx=3)
        self.analysis_show_ineligible_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            controls,
            text="Show ineligible",
            variable=self.analysis_show_ineligible_var,
            command=self.refresh_analysis_orchestration_ui,
        ).pack(side="right", padx=3)

        body = ttk.Panedwindow(f, orient="horizontal"); body.pack(fill="both", expand=True, padx=8, pady=4)
        catalog = ttk.LabelFrame(body, text="Eligible Registry Modules (grouped by governed role)")
        detail = ttk.LabelFrame(body, text="Selected Module Contract / Dependency State")
        body.add(catalog, weight=3); body.add(detail, weight=2)
        self.analysis_orchestration_tree = ttk.Treeview(
            catalog,
            columns=("eligibility", "plan", "role", "dependencies"),
            show="tree headings",
            selectmode="browse",
        )
        self.analysis_orchestration_tree.heading("#0", text="Category / Module")
        self.analysis_orchestration_tree.column("#0", width=335, stretch=True)
        for key, title, width in (
            ("eligibility", "Eligibility", 120), ("plan", "Plan", 105),
            ("role", "Effective role", 160), ("dependencies", "Dependencies", 160),
        ):
            self.analysis_orchestration_tree.heading(key, text=title)
            self.analysis_orchestration_tree.column(key, width=width, stretch=True)
        scroll = ttk.Scrollbar(catalog, orient="vertical", command=self.analysis_orchestration_tree.yview)
        self.analysis_orchestration_tree.configure(yscrollcommand=scroll.set)
        self.analysis_orchestration_tree.pack(side="left", fill="both", expand=True, padx=(5, 0), pady=5)
        scroll.pack(side="right", fill="y", padx=(0, 5), pady=5)
        self.analysis_orchestration_tree.bind("<<TreeviewSelect>>", self.on_analysis_orchestration_select)
        self.analysis_orchestration_detail = tk.Text(detail, wrap="word", height=16)
        self.analysis_orchestration_detail.pack(fill="both", expand=True, padx=6, pady=6)

        graph = ttk.LabelFrame(f, text="Dependency Graph — one governed node at a time")
        graph.pack(fill="x", padx=8, pady=(2, 8))
        self.analysis_graph_var = tk.StringVar(value="Raw run → integrity/timing → preprocessing → canonical frame → analysis branches → review → results bundle")
        ttk.Label(graph, textvariable=self.analysis_graph_var, wraplength=1080, foreground="#1f4e79").pack(fill="x", padx=6, pady=5)

    def build_results_review_page(self, f: ttk.Frame) -> None:
        frame = ttk.LabelFrame(f, text="Review and Local Results Bundle")
        frame.pack(fill="x", padx=8, pady=8)
        self.results_bundle_status_var = tk.StringVar(value="No local results bundle recorded.")
        ttk.Label(frame, textvariable=self.results_bundle_status_var, wraplength=1060, foreground="#704000").pack(fill="x", padx=6, pady=5)
        buttons = ttk.Frame(frame); buttons.pack(fill="x", padx=4, pady=4)
        ttk.Button(buttons, text="Mark Outcome Review Complete", command=self.mark_workspace_outcomes_reviewed).pack(side="left", padx=3)
        ttk.Button(buttons, text="Build Local Results Bundle", command=self.build_local_results_bundle_ui).pack(side="left", padx=3)
        ttk.Button(buttons, text="Review Latest Local Bundle", command=self.review_latest_results_bundle_ui).pack(side="left", padx=3)
        ttk.Button(buttons, text="Open Latest Bundle", command=self.open_latest_results_bundle).pack(side="left", padx=3)
        ttk.Label(
            f,
            text=(
                "The alpha.8 builder has no upload or publication capability. It excludes raw XDF/EDF/BDF/FIF/EEG-class files, "
                "creates a review inventory, and requires separate privacy, licensing, and claim-boundary confirmations. "
                "Local review still leaves publication approval NOT APPROVED."
            ),
            wraplength=1060,
            foreground="#8a1c1c",
        ).pack(fill="x", padx=12, pady=4)
        self.results_bundle_text = tk.Text(f, wrap="word", height=20)
        self.results_bundle_text.pack(fill="both", expand=True, padx=8, pady=8)

    def _workspace_protocol_id(self) -> str:
        if self.active_workspace:
            value = str(self.active_workspace.get("components", {}).get("protocol", {}).get("protocol_id") or "")
            if value:
                return value
        return str((self.locked_protocol or {}).get("protocol_id") or "")

    def _workspace_modalities(self) -> List[str]:
        values: set[str] = set()
        profile = self.active_hardware_profile or {}
        for module in profile.get("modules", []) if isinstance(profile.get("modules"), list) else []:
            text = json.dumps(module).upper()
            for token in ("EEG", "ALS", "CARDIAC", "RESPIRATION", "EDA", "PPG", "EMG", "EOG"):
                if token in text:
                    values.add(token)
        if self.selected_run_folder and any(self.selected_run_folder.glob("**/*.xdf")):
            values.add("LSL_RECORDING")
        return sorted(values)

    def refresh_analysis_orchestration_ui(self) -> None:
        if not hasattr(self, "analysis_orchestration_tree"):
            return
        tree = self.analysis_orchestration_tree
        tree.delete(*tree.get_children())
        self.analysis_orchestration_rows = {}
        try:
            self.analysis_registry_report = validate_analysis_orchestration_registry(
                self.analysis_registry_path, self.pkg.parent
            )
            if self.analysis_registry_report.get("status") != "PASS":
                raise RuntimeError("; ".join(self.analysis_registry_report.get("errors", [])))
            if not self.active_workspace:
                self.analysis_plan_status_var.set("No Study Workspace: registry is valid, but no analysis plan can be bound.")
                return
            if not self.selected_run_folder or not self.selected_run_folder.is_dir():
                self.analysis_plan_status_var.set("Select a completed run folder to compute module eligibility.")
                return
            protocol_id = self._workspace_protocol_id()
            timing = str(self.active_workspace.get("qc", {}).get("status") or "")
            timing_grade = "PASS" if timing == "COMPLETE" else "CAUTION" if timing == "CAUTION" else None
            rates = {"EEG": float(self.cfg.get("lsl", {}).get("eeg_expected_rate_hz") or 0)}
            self.analysis_eligibility = preflight_registry(
                self.analysis_registry_report,
                run_folder=self.selected_run_folder,
                analysis_root=Path(self.cfg["analysis_root"]),
                protocol_id=protocol_id,
                available_modalities=self._workspace_modalities(),
                observed_sample_rates=rates,
                timing_grade=timing_grade,
            )
            locked_ids = {
                str(row.get("module_id")) for row in self.active_analysis_plan.get("modules", []) if isinstance(row, dict)
            }
            posthoc_ids = {
                str(row.get("module_id")) for row in self.active_workspace.get("analysis", {}).get("post_hoc_supplements", []) if isinstance(row, dict)
            }
            category_nodes: Dict[str, str] = {}
            for category in MODULE_CATEGORIES:
                category_nodes[category] = tree.insert("", "end", iid=f"category::{category}", text=category.replace("_", " ").title(), open=True)
            for module_id in self.analysis_registry_report.get("topological_order", []):
                module = self.analysis_registry_report["module_map"][module_id]
                eligibility = self.analysis_eligibility[module_id]
                if eligibility["status"] == "INELIGIBLE" and not self.analysis_show_ineligible_var.get():
                    continue
                if module_id in locked_ids:
                    plan_state = "LOCKED"
                    effective_role = next(
                        (str(row.get("effective_role")) for row in self.active_analysis_plan.get("modules", []) if row.get("module_id") == module_id),
                        str(module.get("analysis_role")),
                    )
                elif module_id in posthoc_ids:
                    plan_state, effective_role = "POST-HOC", "POST_HOC_EXPLORATORY"
                elif module_id in self.analysis_plan_selected_ids:
                    plan_state, effective_role = "SELECTED", str(module.get("analysis_role"))
                else:
                    plan_state, effective_role = "—", str(module.get("analysis_role"))
                tree.insert(
                    category_nodes[module["category"]], "end", iid=module_id, text=module["display_name"],
                    values=(eligibility["status"], plan_state, effective_role, ", ".join(module.get("depends_on", [])) or "none"),
                )
                self.analysis_orchestration_rows[module_id] = {"module": module, "eligibility": eligibility}
            locked_state = validate_plan_lock(self.active_analysis_plan)["status"] if self.active_analysis_plan else "NOT LOCKED"
            self.analysis_plan_status_var.set(
                f"Registry PASS ({len(self.analysis_registry_report.get('module_map', {}))} modules, exact code/config hashes) | "
                f"Protocol {protocol_id or 'unknown'} | Plan {locked_state} | INELIGIBLE modules hidden by default."
            )
            if self.active_analysis_plan:
                graph = execution_graph(self.active_analysis_plan, self.active_workspace.get("analysis", {}).get("executions", []))
                self.analysis_graph_var.set("  →  ".join(f"{row['display_name']} [{row['status']}]" for row in graph["nodes"]))
            else:
                self.analysis_graph_var.set("Raw run → integrity/timing → modality preprocessing → canonical frame → primary/secondary/exploratory branches → review → results bundle")
        except Exception as exc:
            self.analysis_plan_status_var.set(f"Analysis orchestration INELIGIBLE: {type(exc).__name__}: {exc}")
            self.analysis_registry_report = {}
            self.analysis_eligibility = {}

    def selected_analysis_module_id(self) -> str:
        if not hasattr(self, "analysis_orchestration_tree"):
            return ""
        selection = self.analysis_orchestration_tree.selection()
        return selection[0] if selection and not selection[0].startswith("category::") else ""

    def on_analysis_orchestration_select(self, _event=None) -> None:
        module_id = self.selected_analysis_module_id()
        if not module_id or module_id not in self.analysis_orchestration_rows:
            return
        row = self.analysis_orchestration_rows[module_id]
        module, eligibility = row["module"], row["eligibility"]
        lines = [
            f"{module.get('display_name')} ({module_id})",
            f"Version: {module.get('module_version')}",
            f"Category / role: {module.get('category')} / {module.get('analysis_role')}",
            f"Eligibility: {eligibility.get('status')}",
            f"Accepted protocols: {', '.join(module.get('accepted_protocols', []))}",
            f"Required modalities: {', '.join(module.get('required_modalities', [])) or 'none'}",
            f"Required events: {', '.join(module.get('required_events', [])) or 'none'}",
            f"Required conditions: {', '.join(module.get('required_conditions', [])) or 'none'}",
            f"Dependencies: {', '.join(module.get('depends_on', [])) or 'none'}",
            f"Multiplicity family: {module.get('multiplicity_family')}",
            f"Missing-data policy: {module.get('missing_data_policy')}",
            f"Synthetic status: {module.get('synthetic_test_status')}",
            f"Human validation: {module.get('human_validation_status')}",
            f"Primary conclusion authority: {module.get('primary_conclusion_authority')}",
            "",
            "Preflight cautions:", *(f"- {item}" for item in eligibility.get("cautions", [])),
            "Preflight errors:", *(f"- {item}" for item in eligibility.get("errors", [])),
            "Dependency blockers:", *(f"- {item}" for item in eligibility.get("dependency_blockers", [])),
            "", f"Claim boundary: {module.get('claims_boundary')}",
        ]
        self.analysis_orchestration_detail.delete("1.0", "end")
        self.analysis_orchestration_detail.insert("end", "\n".join(lines))

    def add_selected_analysis_module(self) -> None:
        module_id = self.selected_analysis_module_id()
        if not module_id:
            return
        eligibility = self.analysis_eligibility.get(module_id, {})
        if eligibility.get("status") == "INELIGIBLE":
            messagebox.showerror("Module ineligible", "This module cannot be selected for the current run. Review its stated reasons.")
            return
        if self.active_analysis_plan:
            existing = {str(row.get("module_id")) for row in self.active_analysis_plan.get("modules", [])}
            if module_id in existing:
                return
            module = self.analysis_registry_report.get("module_map", {}).get(module_id)
            try:
                supplement = build_post_hoc_supplement(self.active_analysis_plan, module, eligibility)
                self.active_workspace = add_post_hoc_supplement(self.active_workspace, supplement)  # type: ignore[arg-type]
                self.save_active_workspace()
                messagebox.showinfo(
                    "Recorded as post-hoc exploratory",
                    "The locked plan was not changed. This module was recorded as POST_HOC_EXPLORATORY with no primary-conclusion authority.",
                )
            except Exception as exc:
                messagebox.showerror("Post-hoc record failed", str(exc))
        else:
            self.analysis_plan_selected_ids.add(module_id)
        self.refresh_analysis_orchestration_ui()

    def remove_selected_analysis_module(self) -> None:
        module_id = self.selected_analysis_module_id()
        if not module_id:
            return
        if self.active_analysis_plan and any(row.get("module_id") == module_id for row in self.active_analysis_plan.get("modules", [])):
            messagebox.showwarning("Plan is immutable", "A locked analysis plan cannot be edited. Start a new session to create a new preregistered plan.")
            return
        self.analysis_plan_selected_ids.discard(module_id)
        self.refresh_analysis_orchestration_ui()

    def lock_analysis_plan_ui(self) -> None:
        if not self.active_workspace or not self.active_workspace_path:
            messagebox.showwarning("Workspace required", "Create or open a Study Workspace first.")
            return
        if self.active_analysis_plan:
            messagebox.showinfo("Plan already locked", "This session already has an immutable analysis-plan lock.")
            return
        if not self.selected_run_folder or not self.selected_run_folder.is_dir():
            messagebox.showwarning("Run required", "Select the completed run folder before locking an analysis plan.")
            return
        self.refresh_analysis_orchestration_ui()
        selected = set(self.analysis_plan_selected_ids)
        selected.update(
            module_id for module_id, module in self.analysis_registry_report.get("module_map", {}).items()
            if module.get("category") == "REQUIRED_QC"
        )
        if not selected:
            messagebox.showwarning("Select analyses", "Select at least one module. Required QC is added automatically.")
            return
        operator = str(self.cfg.get("acquisition", {}).get("operator_name") or "").strip()
        if not operator:
            operator = (simpledialog.askstring("Operator", "Operator locking the analysis plan:", parent=self) or "").strip()
        if not operator:
            return
        caution_ack = ""
        if any(self.analysis_eligibility.get(item, {}).get("status") in {"CAUTION", "BLOCKED_BY_DEPENDENCY"} for item in selected):
            caution_ack = (simpledialog.askstring(
                "Record caution acknowledgement",
                "Some modules have cautions or deferred dependency inputs. State why the prospective plan may be locked before those downstream inputs exist:",
                parent=self,
            ) or "").strip()
            if not caution_ack:
                return
        try:
            session = self.active_workspace["current_session"]
            draft = build_analysis_plan(
                self.analysis_registry_report,
                self.analysis_eligibility,
                selected,
                study_id=self.active_workspace["study_id"],
                session_id=session["session_id"],
                protocol_id=self._workspace_protocol_id(),
                run_folder=self.selected_run_folder,
                workspace_sha256=self.active_workspace["workspace_content_sha256"],
                outcomes_reviewed=False,
            )
            lock_path = self.active_workspace_path.parent / "locks" / f"analysis_plan_session_{session['session_index']}_{draft['plan_id'][:8]}.json"
            locked = lock_analysis_plan(draft, lock_path, operator=operator, caution_acknowledgement=caution_ack)
            self.active_workspace, _ = bind_workspace_component(
                self.active_workspace, "analysis_plan", locked, reason="Operator locked the preregistered analysis plan before outcome review."
            )
            self.active_workspace["analysis"]["plan_lock_artifact"] = self._workspace_file_record(str(lock_path), "ANALYSIS_PLAN_LOCK")
            self.active_analysis_plan = locked
            self.save_active_workspace()
            self.refresh_analysis_orchestration_ui()
            self.refresh_workspace_ui()
            messagebox.showinfo("Analysis plan locked", f"Immutable plan saved:\n{lock_path}")
        except Exception as exc:
            messagebox.showerror("Plan lock failed", str(exc))

    def _launch_orchestrated_module(self, module_id: str) -> None:
        if not self.active_workspace or not self.active_analysis_plan:
            messagebox.showwarning("Locked plan required", "Lock an analysis plan before governed execution.")
            return
        validation = validate_plan_lock(self.active_analysis_plan)
        if validation["status"] != "PASS":
            messagebox.showerror("Plan invalid", "; ".join(validation["errors"]))
            return
        self.refresh_analysis_orchestration_ui()
        fresh = self.analysis_eligibility.get(module_id, {})
        if fresh.get("status") == "INELIGIBLE":
            messagebox.showerror("Click-time preflight failed", "The module is now INELIGIBLE; no launch occurred.")
            return
        graph = execution_graph(self.active_analysis_plan, self.active_workspace.get("analysis", {}).get("executions", []))
        node = next((row for row in graph["nodes"] if row["module_id"] == module_id), None)
        if not node or node["status"] not in {"READY"}:
            messagebox.showwarning("Module not ready", node["reason"] if node else "The selected module is not in the locked plan.")
            return
        execution = node.get("execution", {})
        if execution.get("mode") == "MANAGED_CLI":
            out = self.active_workspace_path.parent / "analysis" / self.active_workspace["current_session"]["session_id"] / "run_integrity_timing_qc_v0_1.json"
            self.launch_python_tool(
                node["display_name"], "analysis_integrity_qc",
                ["--run-folder", str(self.selected_run_folder), "--out", str(out)],
            )
        elif execution.get("mode") == "CONTROL_CENTER_ACTION":
            action = str(execution.get("control_center_action") or "")
            allowed = set(self.analysis_registry_report.get("module_map", {}).get(module_id, {}).get("execution", {}).get("control_center_action") for _ in [0])
            if action not in allowed or not hasattr(self, action):
                messagebox.showerror("Execution blocked", "The registry action is not allowlisted by the validated module descriptor.")
                return
            getattr(self, action)()
        else:
            messagebox.showerror("Execution blocked", "Unsupported analysis execution mode.")

    def launch_selected_analysis_module(self) -> None:
        module_id = self.selected_analysis_module_id()
        if module_id:
            self._launch_orchestrated_module(module_id)

    def launch_next_analysis_module(self) -> None:
        if not self.active_workspace or not self.active_analysis_plan:
            messagebox.showwarning("Locked plan required", "Lock an analysis plan before governed execution.")
            return
        graph = execution_graph(self.active_analysis_plan, self.active_workspace.get("analysis", {}).get("executions", []))
        module_id = str(graph.get("next_ready_module_id") or "")
        if not module_id:
            messagebox.showinfo("No ready node", "No dependency-eligible analysis node is waiting to launch.")
            return
        self._launch_orchestrated_module(module_id)

    def record_selected_analysis_output(self) -> None:
        module_id = self.selected_analysis_module_id()
        if not module_id or not self.active_workspace or not self.active_analysis_plan:
            messagebox.showwarning("Selection required", "Select a module from the locked plan.")
            return
        if not any(row.get("module_id") == module_id for row in self.active_analysis_plan.get("modules", [])):
            messagebox.showwarning("Not in locked plan", "This alpha records completion only for modules in the locked dependency graph.")
            return
        output = filedialog.askdirectory(title="Select the reviewed output folder for this module")
        if not output:
            output = filedialog.askopenfilename(title="Or select one reviewed output file", filetypes=(("All files", "*.*"),))
        if not output:
            return
        operator = str(self.cfg.get("acquisition", {}).get("operator_name") or "").strip()
        if not operator:
            operator = (simpledialog.askstring("Operator", "Operator reviewing this completion:", parent=self) or "").strip()
        if not operator:
            return
        try:
            record = completion_record(module_id, output, operator=operator, notes="Operator selected and reviewed this output path in alpha.8.")
            executions = [row for row in self.active_workspace["analysis"].get("executions", []) if row.get("module_id") != module_id]
            executions.append(record)
            self.active_workspace["analysis"]["executions"] = executions
            recorded_outputs = [
                {"kind": str(row.get("module_id")), "module_id": row.get("module_id"), "path": row.get("output_inventory", {}).get("root")}
                for row in executions if row.get("output_inventory", {}).get("root")
            ]
            outputs = [dict(row) for row in self.active_workspace["analysis"].get("outputs", []) if isinstance(row, dict)]
            paths = {str(row.get("path") or "").casefold() for row in outputs}
            outputs.extend(row for row in recorded_outputs if str(row.get("path") or "").casefold() not in paths)
            self.active_workspace, _ = workspace_record_analysis_outputs(
                self.active_workspace, outputs, reason=f"Operator recorded reviewed output for {module_id}."
            )
            if module_id == "run_integrity_timing_qc_v0_1":
                qc_status = "CAUTION"
                try:
                    report_path = Path(output)
                    if report_path.is_dir():
                        report_path = report_path / "run_integrity_timing_qc_v0_1.json"
                    report = json.loads(report_path.read_text(encoding="utf-8-sig"))
                    qc_status = "COMPLETE" if report.get("status") == "PASS" else str(report.get("status") or "CAUTION")
                    if qc_status not in {"COMPLETE", "CAUTION", "INELIGIBLE"}:
                        qc_status = "CAUTION"
                except Exception:
                    pass
                self.active_workspace = set_workflow_stage(
                    self.active_workspace, "qc", qc_status,
                    reason="Operator recorded the required run-integrity/timing QC output.",
                    evidence={"module_id": module_id, "output": record["output_inventory"]},
                )
            self.save_active_workspace()
            self.refresh_analysis_orchestration_ui()
            self.refresh_workspace_ui()
        except Exception as exc:
            messagebox.showerror("Completion record failed", str(exc))

    def mark_workspace_outcomes_reviewed(self) -> None:
        if not self.active_workspace:
            messagebox.showwarning("Workspace required", "Create or open a Study Workspace first.")
            return
        if not self.active_analysis_plan or not self.active_workspace.get("analysis", {}).get("outputs"):
            messagebox.showwarning("Analysis evidence required", "A locked plan and at least one recorded analysis output are required.")
            return
        if not messagebox.askyesno(
            "Complete outcome review?",
            "Confirm that available, missing, null, reversed, secondary, exploratory, and ineligible outcomes have been reviewed. This does not approve publication.",
        ):
            return
        self.active_workspace = set_workflow_stage(
            self.active_workspace, "review", "COMPLETE", reason="Operator completed the local outcome-and-limitations review."
        )
        self.save_active_workspace()
        self.refresh_workspace_ui()
        self.refresh_results_bundle_ui()

    def build_local_results_bundle_ui(self) -> None:
        if not self.active_workspace or not self.active_workspace_path:
            messagebox.showwarning("Workspace required", "Create or open a Study Workspace first.")
            return
        if self.active_workspace.get("workflow", {}).get("review", {}).get("status") != "COMPLETE":
            messagebox.showwarning("Review required", "Complete local outcome review before building the results bundle.")
            return
        try:
            self.save_active_workspace()
            path, manifest = build_results_bundle(
                self.active_workspace_path,
                self.active_workspace_path.parent / "results_bundles",
                software_provenance={
                    "control_center_version": APP_VERSION,
                    "analysis_registry_path": str(self.analysis_registry_path),
                    "analysis_registry_sha256": self.analysis_registry_report.get("registry_sha256"),
                },
            )
            self.latest_results_bundle_path = path
            self.active_workspace["results_package"]["status"] = "LOCAL_REVIEW_REQUIRED"
            self.active_workspace["results_package"]["bundles"].append({
                "bundle_id": manifest.get("bundle_id"), "path": str(path), "status": "LOCAL_REVIEW_REQUIRED",
                "raw_biosignal_file_count": manifest.get("raw_biosignal_file_count"),
            })
            self.active_workspace = set_workflow_stage(
                self.active_workspace, "export", "CAUTION", reason="Local results bundle built; privacy, licensing, and claim review remain required."
            )
            self.save_active_workspace()
            self.refresh_workspace_ui()
            self.refresh_results_bundle_ui()
            messagebox.showinfo("Local bundle built", f"Review required; nothing was uploaded.\n\n{path}")
        except Exception as exc:
            messagebox.showerror("Results bundle failed", str(exc))

    def _latest_workspace_bundle(self) -> Optional[Path]:
        if self.latest_results_bundle_path and self.latest_results_bundle_path.is_dir():
            return self.latest_results_bundle_path
        if not self.active_workspace:
            return None
        for row in reversed(self.active_workspace.get("results_package", {}).get("bundles", [])):
            path = Path(str(row.get("path") or "")).expanduser().resolve(strict=False)
            if path.is_dir():
                return path
        return None

    def review_latest_results_bundle_ui(self) -> None:
        path = self._latest_workspace_bundle()
        if not path or not self.active_workspace:
            messagebox.showwarning("No bundle", "Build a local results bundle first.")
            return
        confirmations = []
        for title, question in (
            ("Privacy review", "Have you reviewed every included file for privacy, pseudonymization, and unintended identifiers?"),
            ("Licensing review", "Have you verified licensing for stimuli, code, figures, and third-party material?"),
            ("Claim-boundary review", "Have you verified that confirmatory, secondary, exploratory, null, reversed, missing, and ineligible results are labeled without overclaiming?"),
        ):
            confirmations.append(messagebox.askyesno(title, question))
        reviewer = (simpledialog.askstring("Local reviewer", "Reviewer name:", parent=self) or "").strip()
        if not reviewer:
            return
        try:
            review = record_local_review(
                path, reviewer=reviewer, privacy_confirmed=confirmations[0],
                licensing_confirmed=confirmations[1], claim_boundaries_confirmed=confirmations[2],
            )
            if review["status"] == "PASS":
                self.active_workspace["results_package"]["status"] = "LOCAL_REVIEW_COMPLETE"
                self.active_workspace = set_workflow_stage(
                    self.active_workspace, "export", "COMPLETE",
                    reason="Local bundle review completed; publication approval remains NOT_APPROVED and no upload occurred."
                )
            else:
                self.active_workspace["results_package"]["status"] = "LOCAL_REVIEW_INCOMPLETE"
            self.save_active_workspace()
            self.refresh_workspace_ui()
            self.refresh_results_bundle_ui()
            messagebox.showinfo(
                "Local review recorded",
                f"Review status: {review['status']}\nPublication approval: NOT APPROVED\nUpload performed: no",
            )
        except Exception as exc:
            messagebox.showerror("Review record failed", str(exc))

    def open_latest_results_bundle(self) -> None:
        path = self._latest_workspace_bundle()
        if path:
            open_path(path)
        else:
            messagebox.showinfo("No bundle", "No local results bundle is recorded in this workspace.")

    def refresh_results_bundle_ui(self) -> None:
        if not hasattr(self, "results_bundle_status_var"):
            return
        if not self.active_workspace:
            self.results_bundle_status_var.set("No active Study Workspace.")
            return
        results = self.active_workspace.get("results_package", {})
        self.results_bundle_status_var.set(
            f"Status: {results.get('status')} | Publication: {results.get('publication_approval')} | "
            f"Upload capability: {results.get('upload_capability')} | Bundles: {len(results.get('bundles', []))}"
        )
        if hasattr(self, "results_bundle_text"):
            self.results_bundle_text.delete("1.0", "end")
            self.results_bundle_text.insert("end", json.dumps(results, indent=2))

    def refresh_analysis_module_catalog_ui(self) -> None:
        """Summarize discoverable analysis modules; discovery never changes conclusions."""
        if not hasattr(self, "analysis_catalog_var"):
            return
        candidates = (
            self.pkg.parent / "config" / "analysis_module_registry_v0_1.json",
            self.pkg.parent / "tools" / "Analysis_Module_Catalog_v0_1" / "config" / "analysis_module_registry_v0_1.json",
        )
        path = next((candidate for candidate in candidates if candidate.is_file()), None)
        if path is None:
            self.analysis_catalog_var.set("No governed analysis-module registry is installed; built-in analysis buttons remain available.")
            return
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            modules = payload.get("modules", [])
            if not isinstance(modules, list):
                raise ValueError("modules must be an array")
            executable = sum(1 for module in modules if isinstance(module, dict) and module.get("execution_eligible") is True)
            self.analysis_catalog_var.set(
                f"{len(modules)} module(s) registered; {executable} execution-eligible. Registration cannot alter Master Suite eligibility, "
                "primary endpoints, or evidence grades without a separately versioned scientific review."
            )
        except Exception as exc:
            self.analysis_catalog_var.set(f"Analysis registry could not be read: {exc}")

    def record_post_run_gate(self, target_stage: str) -> None:
        """Append one reviewed evidence record to the canonical session state."""
        if not self.platform_core_available():
            messagebox.showerror("Platform core unavailable", PLATFORM_CORE_IMPORT_ERROR)
            return
        acquisition = self.cfg.setdefault("acquisition", {})
        value = str(acquisition.get("session_lock_path") or "").strip()
        path = Path(value).expanduser().resolve() if value else Path()
        if not value or not path.is_file():
            messagebox.showerror("Session lock required", "No canonical runtime session lock is available.")
            return
        lock_status, lock_detail = self.validate_active_session_lock()
        if lock_status != "VALID":
            messagebox.showerror(
                "Session evidence changed",
                f"The post-run gate cannot advance until every bound external artifact revalidates.\n\n{lock_status}: {lock_detail}",
            )
            return
        evidence_path_value = filedialog.askopenfilename(
            title=f"Select the reviewed evidence artifact for {target_stage}",
            filetypes=(("Reports and manifests", "*.json *.csv *.tsv *.html *.pdf *.txt"), ("All", "*.*")),
        )
        if not evidence_path_value:
            return
        evidence_path = Path(evidence_path_value).expanduser().resolve()
        operator = str(acquisition.get("operator_name") or "").strip()
        if not operator:
            operator = (simpledialog.askstring("Operator", f"Enter the operator recording the {target_stage} gate:", parent=self) or "").strip()
        if not operator:
            return
        try:
            lock = load_platform_json(path)  # type: ignore[misc]
            evidence = {
                "artifact_path": str(evidence_path),
                "artifact_sha256": sha256_file(evidence_path),
                "artifact_size_bytes": evidence_path.stat().st_size,
                "review_declaration": f"Operator reviewed this artifact before recording {target_stage}.",
            }
            updated = advance_session_gate(lock, target_stage, path, operator=operator, evidence=evidence)  # type: ignore[misc]
        except Exception as exc:
            messagebox.showerror(f"{target_stage} gate not recorded", str(exc))
            return
        acquisition["session_stage"] = str(updated.get("current_stage") or target_stage)
        acquisition["session_lock_status"] = "VALID"
        acquisition["operator_name"] = operator
        acquisition["armed"] = False
        self.save_config()
        self.post_run_gate_var.set(f"Session gate: {target_stage} PASS | evidence {evidence_path.name}")
        messagebox.showinfo(
            f"{target_stage} gate recorded",
            "The selected evidence file and its SHA-256 were appended to the runtime history. "
            "This records workflow completion; it does not independently validate the scientific result.",
        )

    def finalize_interrupted_run(self) -> None:
        """Record a reviewed incomplete FINALIZE when a runner cannot do so."""
        if not self.platform_core_available():
            messagebox.showerror("Platform core unavailable", PLATFORM_CORE_IMPORT_ERROR)
            return
        acquisition = self.cfg.setdefault("acquisition", {})
        value = str(acquisition.get("session_lock_path") or "").strip()
        path = Path(value).expanduser().resolve() if value else Path()
        if not value or not path.is_file():
            messagebox.showerror("Session lock required", "No interrupted runtime session lock is available.")
            return
        active_runners = [
            item for item in self.processes.values()
            if item.process.poll() is None
            and paths_equivalent(  # type: ignore[misc]
                str((item.env_overrides or {}).get("PRAYCG_SESSION_LOCK_JSON") or ""),
                path,
                require_existing=True,
            )
        ]
        if active_runners:
            messagebox.showerror(
                "Runner still active",
                "This session still has an active authorized runner process. Stop or let it exit before using interrupted-run recovery.",
            )
            return
        try:
            initial_lock = load_platform_json(path)  # type: ignore[misc]
        except Exception as exc:
            messagebox.showerror("Interrupted session unreadable", str(exc))
            return
        if str(initial_lock.get("current_stage") or "") != "ACQUIRE":
            messagebox.showerror(
                "Interrupted finalization unavailable",
                f"This recovery action requires an ACQUIRE-stage lock; current stage is {initial_lock.get('current_stage')!r}.",
            )
            return
        session_root_value = str(initial_lock.get("session", {}).get("private_output_locations", {}).get("session_log_dir") or "")
        lease_path = Path(session_root_value).expanduser().resolve() / "authorized_runner_lease.json" if session_root_value else Path()
        if not session_root_value or not lease_path.is_file():
            messagebox.showerror(
                "Runner lease unavailable",
                "Interrupted finalization is blocked because the ACQUIRE-stage session has no readable persistent authorized-runner lease.",
            )
            return
        lease_activity = runtime_runner_lease_activity(lease_path)  # type: ignore[misc]
        if bool(lease_activity.get("active")):
            messagebox.showerror(
                "Runner authority still active or uncertain",
                "Interrupted finalization requires an exited lease or a provably dead process with an expired heartbeat.\n\n"
                f"{lease_activity.get('status')}: {lease_activity.get('reason')}",
            )
            return
        try:
            recovery_lease = load_platform_json(lease_path)  # type: ignore[misc]
        except Exception as exc:
            messagebox.showerror(
                "Runner lease changed",
                "The persistent runner lease could not be reread after its inactivity check. "
                f"Interrupted finalization remains blocked.\n\n{exc}",
            )
            return
        recovery_lease_status = str(recovery_lease.get("status") or "")
        recovery_pid = recovery_lease.get("pid") if recovery_lease_status == "ACTIVE" else None
        recovery_start_identity = (
            str(recovery_lease.get("process_start_identity") or "")
            if recovery_lease_status == "ACTIVE"
            else ""
        )
        identity_report = validate_session_lock_identity(initial_lock)  # type: ignore[misc]
        if identity_report.status == "INELIGIBLE":
            messagebox.showerror(
                "Interrupted session lock invalid",
                "The archived lock identity failed validation:\n\n" + "; ".join(identity_report.errors),
            )
            return
        locked_session = initial_lock.get("session", {})
        classification_valid, classification_detail = locked_session_classification_status(locked_session)
        if not classification_valid:
            messagebox.showerror("Interrupted session lock invalid", classification_detail)
            return
        locked_bench_mode = bool(locked_session.get("bench_test_mode"))
        acquisition["bench_test_reason"] = (
            str(locked_session.get("bench_test_reason") or "").strip() if locked_bench_mode else ""
        )
        # Explicit recovery may adopt the immutable purpose label solely so the
        # archived ACQUIRE lock can be finalized. It never restores ARM.
        acquisition["bench_test_mode"] = locked_bench_mode
        acquisition["bench_eeg_quality_waiver_active"] = bool(
            locked_session.get("bench_eeg_quality_waiver_active")
        ) if locked_bench_mode else False
        acquisition["bench_readiness_bypass_active"] = bool(
            locked_session.get("bench_readiness_bypass_active")
        ) if locked_bench_mode else False
        acquisition["bench_bypass_preflight_path"] = (
            str(locked_session.get("bench_bypass_preflight_path") or "") if locked_bench_mode else ""
        )
        acquisition["participant_pseudonym"] = str(locked_session.get("participant_pseudonym") or "")
        acquisition["armed"] = False
        if hasattr(self, "bench_test_mode_var"):
            self.bench_test_mode_var.set(locked_bench_mode)
        locked_uuid = str(initial_lock.get("session", {}).get("session_id") or "").strip()
        if not self.active_run_uuid and locked_uuid:
            # Explicit operator-selected recovery may adopt the archived UUID
            # for validation, but it never restores ARM authority.
            self.active_run_uuid = locked_uuid
            os.environ["PRAYCG_RUN_UUID"] = locked_uuid
        lock_status, lock_detail = self.validate_active_session_lock()
        if lock_status != "VALID":
            messagebox.showerror(
                "Interrupted session evidence changed",
                f"The run cannot be finalized because its lock or bound artifacts do not revalidate.\n\n{lock_status}: {lock_detail}",
            )
            return
        evidence_path_value = filedialog.askopenfilename(
            title="Select an incomplete-run log, manifest, or failure report",
            filetypes=(("Run evidence", "*.json *.csv *.log *.txt"), ("All", "*.*")),
        )
        if not evidence_path_value:
            return
        reason = (simpledialog.askstring(
            "Reason for interrupted finalization",
            "State why the runner could not finalize normally. This will be preserved in the immutable runtime history:",
            parent=self,
        ) or "").strip()
        if not reason:
            return
        operator = str(acquisition.get("operator_name") or "").strip()
        if not operator:
            operator = (simpledialog.askstring(
                "Operator",
                "Enter the operator recording this interrupted FINALIZE:",
                parent=self,
            ) or "").strip()
        if not operator:
            return
        evidence_path = Path(evidence_path_value).expanduser().resolve()
        try:
            finish_authorized_runner_lease(  # type: ignore[misc]
                lease_path,
                status="EXITED",
                reason="OPERATOR_REVIEWED_INTERRUPTED_RUN_PROCESS_INACTIVE: " + reason,
                exit_code=None,
                pid=recovery_pid,
                start_identity=recovery_start_identity,
                allow_unconsumed=True,
            )
            lock = load_platform_json(path)  # type: ignore[misc]
            updated = advance_session_gate(  # type: ignore[misc]
                lock,
                "FINALIZE",
                path,
                operator=operator,
                evidence={
                    "run_state": "INCOMPLETE_INTERRUPTED_OPERATOR_FINALIZATION",
                    "reason": reason,
                    "artifact_path": str(evidence_path),
                    "artifact_sha256": sha256_file(evidence_path),
                    "artifact_size_bytes": evidence_path.stat().st_size,
                    "review_declaration": "Operator reviewed this incomplete-run artifact before FINALIZE.",
                },
            )
        except Exception as exc:
            messagebox.showerror("Interrupted FINALIZE not recorded", str(exc))
            return
        try:
            recovery_owner_path = active_acquisition_owner_path(self.cfg["log_root"])  # type: ignore[misc]
            if recovery_owner_path.is_file():
                recovery_owner = load_platform_json(recovery_owner_path)  # type: ignore[misc]
                owner_lock_path = str(recovery_owner.get("owner_core", {}).get("session_lock_path") or "")
                if paths_equivalent(owner_lock_path, path, require_existing=True):  # type: ignore[misc]
                    finish_active_acquisition_owner(  # type: ignore[misc]
                        recovery_owner_path,
                        reason="OPERATOR_REVIEWED_INTERRUPTED_RUN_FINALIZED",
                    )
        except Exception as exc:
            # FINALIZE is already durable.  Leave the owner claim in place so
            # the next begin/launch remains fail-closed until it is validated.
            self.log(f"Interrupted run finalized, but its global owner remains unresolved: {exc}\n")
        acquisition["session_stage"] = str(updated.get("current_stage") or "FINALIZE")
        acquisition["session_lock_status"] = "VALID"
        acquisition["operator_name"] = operator
        acquisition["armed"] = False
        self.save_config()
        self.post_run_gate_var.set(f"Session gate: FINALIZE PASS (incomplete) | evidence {evidence_path.name}")
        messagebox.showinfo(
            "Interrupted run finalized",
            "The run was preserved as incomplete and its reviewed evidence was hash-bound. This is recovery bookkeeping, not evidence that acquisition completed successfully.",
        )

    def build_settings_tab(self) -> None:
        f = self.settings_tab
        canvas = tk.Canvas(f)
        scroll = ttk.Scrollbar(f, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        self.setting_vars: Dict[str, tk.StringVar] = {}

        def add_path_row(label: str, key_path: Tuple[str, Optional[str]], folder=False):
            row = ttk.Frame(inner); row.pack(fill="x", padx=8, pady=3)
            ttk.Label(row, text=label, width=32).pack(side="left")
            key, subkey = key_path
            val = self.cfg.get(key, {}).get(subkey, "") if subkey else self.cfg.get(key, "")
            var = tk.StringVar(value=str(val))
            name = key if subkey is None else f"{key}.{subkey}"
            self.setting_vars[name] = var
            ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=4)
            def browse():
                if folder:
                    p = filedialog.askdirectory(title=f"Select {label}")
                else:
                    p = filedialog.askopenfilename(title=f"Select {label}")
                if p: var.set(p)
            ttk.Button(row, text="Browse", command=browse).pack(side="left")

        ttk.Label(inner, text="Core Folders", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=8, pady=6)
        add_path_row("PRAYCG Home", ("praycg_home", None), folder=True)
        add_path_row("Stimulus Root", ("stimulus_root", None), folder=True)
        add_path_row("Installed Sample-Pack Root", ("stimulus_pack_install_root", None), folder=True)
        add_path_row("Run Root", ("run_root", None), folder=True)
        add_path_row("Analysis Root", ("analysis_root", None), folder=True)
        add_path_row("Log Root", ("log_root", None), folder=True)
        add_path_row("Study Workspace Root", ("study_workspace_root", None), folder=True)
        add_path_row("Analysis Orchestration Registry", ("analysis_orchestration_registry", None), folder=False)
        atlas_row = ttk.Frame(inner); atlas_row.pack(fill="x", padx=8, pady=3)
        ttk.Label(atlas_row, text="Runnable Protocol Atlas (package-locked)", width=32).pack(side="left")
        atlas_path_var = tk.StringVar(value=str(packaged_protocol_atlas_root()))
        ttk.Entry(atlas_row, textvariable=atlas_path_var, state="readonly").pack(side="left", fill="x", expand=True, padx=4)
        ttk.Label(atlas_row, text="External folders are staging only.", foreground="#555555").pack(side="left")
        add_path_row("Protocol Asset Root", ("protocol_asset_root", None), folder=True)
        add_path_row("Custom Protocol AI-Doc Draft Root", ("custom_protocol_draft_root", None), folder=True)
        ttk.Label(inner, text="Tool Paths", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=8, pady=8)
        auto_frame = ttk.LabelFrame(inner, text="Bundled/current paths + Auto-find external tools v1.0.0-alpha.9.0.0")
        auto_frame.pack(fill="x", padx=8, pady=6)
        ttk.Label(auto_frame, text="Searches common Windows locations, PRAYCG_HOME, Desktop, Downloads, Program Files, and PATH. Review results before launching.", wraplength=900).pack(anchor="w", padx=6, pady=4)
        btnrow = ttk.Frame(auto_frame); btnrow.pack(fill="x", padx=6, pady=4)
        ttk.Button(btnrow, text="Use Bundled Paths", command=self.use_bundled_paths).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Use Current Python", command=self.use_current_python).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Auto-find ALL", command=self.autofind_common_tools).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Find LabRecorder", command=self.autofind_labrecorder).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Find PsychoPy", command=self.autofind_psychopy).pack(side="left", padx=3)
        developer = ttk.LabelFrame(inner, text="Developer / release tools — ordinary acquisition does not require these")
        developer.pack(fill="x", padx=8, pady=6)
        developer_actions = [
            ("Run Release Validation", self.launch_release_validator),
            ("Open Module Registry JSON", lambda: self.open_package_config_file("module_registry_v1_0_alpha_9.json")),
            ("Open Analysis Orchestration Registry", lambda: open_path(self.analysis_registry_path)),
            ("Open Raw Hardware Definitions", lambda: open_path(self.hardware_registry_root)),
            ("Open Marker / Timing Contract", lambda: self.open_package_config_file("marker_timing_contract_v1_0_alpha_2.json", "marker_timing_contract_v1_0_alpha_1.json")),
            ("Open Session Template", lambda: self.open_package_config_file("study_session_TEMPLATE_v0_1.json")),
            ("Open Active Settings JSON", lambda: open_path(self.config_path)),
        ]
        for index, (label, command) in enumerate(developer_actions):
            ttk.Button(developer, text=label, command=command).grid(row=index // 3, column=index % 3, sticky="ew", padx=4, pady=4)
            developer.columnconfigure(index % 3, weight=1)
        tool_labels = [
            ("Python executable", ("python_executable", None)),
            ("MediaPrep GUI", ("tools", "mediaprep_gui")),
            ("PsychoPy App", ("tools", "psychopy_app")),
            ("PsychoPy Coder", ("tools", "psychopy_coder")),
            ("PsychoPy Python", ("tools", "psychopy_python")),
            ("LabRecorder exe", ("tools", "labrecorder")),
            ("Master Suite GUI", ("tools", "master_suite_gui")),
            ("Full v1.6.1 Chain GUI", ("tools", "master_chain_gui")),
            ("Visualizer GUI", ("tools", "visualizer_gui")),
            ("Offline Interpreter GUI", ("tools", "offline_interpreter_gui")),
            ("Confound Expansion Module", ("tools", "confound_expanded_gui")),
            ("ALS Barcode Detector", ("tools", "als_barcode_detector")),
            ("MediaPrep Embedded Barcode Backup", ("tools", "mediaprep_barcode_backup")),
            ("Shot-Order Scramble Generator", ("tools", "shot_order_scramble")),
            ("ALS Holder Calibration", ("tools", "als_holder_calibration")),
            ("HOC-R ShotOrder Module", ("tools", "hocr_shotorder")),
            ("CAI/SID Exploratory GUI", ("tools", "cai_sid_exploratory_gui")),
            ("CAI Readiness Preflight", ("tools", "cai_readiness_preflight")),
            ("Continuous Autonomic / RespDualPath", ("tools", "continuous_autonomic_gui")),
            ("Prospective Study Console", ("tools", "prospective_study_console")),
            ("Micro Handoff v0.1", ("tools", "micro_handoff_gui")),
            ("Stimulus Library v1.0", ("tools", "stimulus_library")),
            ("Stimulus Forge v1.0", ("tools", "stimulus_forge")),
            ("Protocol Forge v0.1", ("tools", "protocol_forge")),
            ("Protocol AI Docs Builder v0.1", ("tools", "protocol_ai_doc_builder")),
            ("Hardware Registry v0.1", ("tools", "hardware_registry")),
            ("Hardware Forge v1.0", ("tools", "hardware_forge")),
            ("Generic Existing-LSL Intake v1.0", ("tools", "generic_lsl_intake")),
            ("Stream Contract Validator v1.0", ("tools", "stream_contract_validator")),
            ("Analysis Module Catalog v0.1", ("tools", "analysis_module_catalog")),
            ("Acquisition Supervisor v0.1", ("tools", "acquisition_supervisor")),
            ("Contract-Bound Acquisition Supervisor v1.0", ("tools", "contract_acquisition_supervisor")),
            ("BIDS Exporter v0.1", ("tools", "bids_exporter")),
            ("Release Validator v0.1", ("tools", "release_validator")),
            ("Cue-Locked Gamma Forensics v0.1", ("tools", "cue_locked_gamma_forensics")),
            ("Study Workspace v0.1", ("tools", "study_workspace")),
            ("Analysis Orchestrator v0.1", ("tools", "analysis_orchestrator")),
            ("Run Integrity / Timing QC v0.1", ("tools", "analysis_integrity_qc")),
            ("Local Results Bundle Builder v0.1", ("tools", "results_bundle_builder")),
            ("BrainFlow EEG Only", ("tools", "brainflow_eeg_only")),
            ("BrainFlow EEG + ALS", ("tools", "brainflow_eeg_als")),
            ("Live Signal and Stream Monitor", ("tools", "live_stream_monitor")),
            ("30-Second Acquisition Validation", ("tools", "acquisition_preflight")),
            ("Polar H10 script", ("tools", "polar_h10")),
            ("Vernier Resp script", ("tools", "vernier_resp")),
            ("Generic EDA/PPG Bridge", ("tools", "generic_eda_ppg_bridge")),
            ("Generic EDA/PPG Simulator", ("tools", "generic_eda_ppg_simulator")),
            ("Generic EDA/PPG Profile Wizard", ("tools", "generic_eda_ppg_profile_wizard")),
        ]
        for label, kp in tool_labels:
            add_path_row(label, kp, folder=False)
        ttk.Button(inner, text="Save Settings", command=self.save_settings_from_ui).pack(fill="x", padx=8, pady=10)
        ttk.Button(inner, text="Open Config JSON", command=lambda: open_path(self.config_path)).pack(fill="x", padx=8, pady=4)

    # Settings and process handling
    def save_settings_from_ui(self) -> None:
        if not hasattr(self, "setting_vars"):
            return self.save_config()
        for name, var in self.setting_vars.items():
            if "." in name:
                key, sub = name.split(".", 1)
                self.cfg.setdefault(key, {})[sub] = var.get().strip()
            else:
                self.cfg[name] = var.get().strip()
        self.cfg["runner_launch_mode"] = self.runner_mode_var.get() if hasattr(self, "runner_mode_var") else self.cfg.get("runner_launch_mode")
        self.protocol_library_root = packaged_protocol_atlas_root()
        self.cfg["protocol_library_root"] = str(self.protocol_library_root)
        self.analysis_registry_path = Path(str(self.cfg.get("analysis_orchestration_registry") or "")).expanduser().resolve(strict=False)
        self.create_dirs()
        self.save_config()
        if hasattr(self, "protocol_tree"):
            self.refresh_protocol_library()
        self.refresh_dashboard()
        self.refresh_stimulus_registry()

    def launch_process(
        self,
        label: str,
        cmd: List[str],
        cwd: Optional[Path] = None,
        env_overrides: Optional[Dict[str, str]] = None,
        *,
        allow_runtime_authority: bool = False,
        restartable: bool = True,
        runtime_lease_path: Optional[Path] = None,
        runtime_owner_path: Optional[Path] = None,
    ) -> Optional[RunningProcess]:
        cmd = [str(x) for x in cmd if str(x) != ""]
        if not cmd:
            messagebox.showerror("Cannot launch", "Empty command.")
            return None
        if not command_is_available(cmd):
            messagebox.showerror(
                "Cannot launch - executable not found",
                f"Could not find the program needed to launch {label}:\n\n{cmd[0]}\n\n"
                "Review Settings, then use Auto-find or Use Current Python."
            )
            return
        p: Optional[subprocess.Popen] = None
        child_start_identity = ""

        def safe_log(message: str) -> None:
            try:
                self.log(message)
            except Exception:
                pass

        def clean_failed_spawn() -> bool:
            """Stop and reap any child created before this launch path failed."""
            if p is None:
                return True
            try:
                if p.poll() is None:
                    p.terminate()
                    try:
                        p.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        p.kill()
                        p.wait(timeout=3)
            except Exception as cleanup_exc:
                safe_log(f"Could not prove failed child PID {p.pid} exited: {cleanup_exc}\n")
            stopped = p.poll() is not None
            if stopped and allow_runtime_authority and runtime_lease_path is not None and runtime_lease_path.is_file():
                try:
                    finish_authorized_runner_lease(  # type: ignore[misc]
                        runtime_lease_path,
                        status="LAUNCH_FAILED",
                        reason="CONTROL_CENTER_STOPPED_CHILD_AFTER_POST_SPAWN_LAUNCH_FAILURE",
                        exit_code=p.returncode,
                        pid=p.pid,
                        start_identity=child_start_identity,
                        allow_unconsumed=True,
                    )
                except Exception as lease_exc:
                    safe_log(f"Failed child lease remains unresolved: {lease_exc}\n")
            for key, item in list(getattr(self, "processes", {}).items()):
                if item.process is p:
                    self.processes.pop(key, None)
            return stopped

        try:
            log_dir = Path(self.cfg["log_root"]) / "control_center"
            log_dir.mkdir(parents=True, exist_ok=True)
            log_path = log_dir / f"{now_stamp()}_{slugify(label)}.log"
            self.log(f"Launching {label}: {' '.join(cmd)}\n  log: {log_path}\n")
            f = open(log_path, "w", encoding="utf-8", errors="replace")
            f.write(f"{label}\n{' '.join(cmd)}\nStarted {datetime.now().isoformat()}\n\n")
            f.flush()
            creationflags = 0
            if sys.platform.startswith("win"):
                creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            try:
                child_env = child_process_environment(
                    env_overrides,
                    allow_runtime_authority=allow_runtime_authority,
                )
                p = subprocess.Popen(
                    cmd,
                    cwd=str(cwd) if cwd else None,
                    stdout=f,
                    stderr=subprocess.STDOUT,
                    creationflags=creationflags,
                    env=child_env,
                )
                if allow_runtime_authority:
                    if runtime_lease_path is None:
                        raise RuntimeError("Authorized runner launch has no persistent run-local lease.")
                    binding = bind_authorized_runner_lease_process(  # type: ignore[misc]
                        runtime_lease_path,
                        pid=p.pid,
                    )
                    child_start_identity = str(binding.get("process_start_identity") or "")
            finally:
                f.close()
            # Make duplicate launches visible instead of overwriting prior rows.
            proc_key = f"{label} [{p.pid}]"
            recorded_environment = dict(env_overrides or {})
            recorded_environment.pop("PRAYCG_RUNNER_CLAIM_TOKEN", None)
            self.processes[proc_key] = RunningProcess(
                label=label,
                process=p,
                log_path=log_path,
                started=time.time(),
                cmd=cmd,
                cwd=cwd,
                env_overrides=recorded_environment,
                runtime_authority=bool(allow_runtime_authority),
                restartable=bool(restartable),
                runtime_lease_path=Path(runtime_lease_path).resolve() if runtime_lease_path else None,
                runtime_owner_path=Path(runtime_owner_path).resolve() if runtime_owner_path else None,
                process_start_identity=child_start_identity,
            )
            self.update_process_tree()
            self.after(1600, lambda key=proc_key: self.check_quick_exit(key))
            return self.processes[proc_key]
        except FileNotFoundError as exc:
            clean_failed_spawn()
            detail = " ".join(cmd)
            try:
                messagebox.showerror("Launch failed - file not found", f"Could not launch {label}.\n\nWindows could not find the executable in this command:\n{detail}\n\nMost common fix: Settings -> Use Current Python, then try again.\n\nRaw error:\n{exc}")
            except Exception:
                pass
            safe_log(f"FAILED {label}: {exc}\nCommand: {detail}\n")
            return None
        except Exception as exc:
            clean_failed_spawn()
            try:
                messagebox.showerror("Launch failed", f"Could not launch {label}:\n{exc}")
            except Exception:
                pass
            safe_log(f"FAILED {label}: {exc}\n")
            return None

    def reconcile_runtime_lease_process_exit(self, rp: RunningProcess, return_code: int) -> bool:
        """Persist observed child exit if an abrupt stop bypassed its finally block."""
        if not rp.runtime_authority or rp.runtime_lease_path is None or not rp.runtime_lease_path.is_file():
            return True
        try:
            rp.completion_reconcile_attempts += 1
            finish_authorized_runner_lease(  # type: ignore[misc]
                rp.runtime_lease_path,
                status="EXITED",
                reason="CONTROL_CENTER_OBSERVED_CHILD_PROCESS_EXIT",
                exit_code=int(return_code),
                pid=rp.process.pid,
                start_identity=rp.process_start_identity,
                allow_unconsumed=True,
            )
            if rp.runtime_owner_path is not None and rp.runtime_owner_path.is_file():
                finish_active_acquisition_owner(  # type: ignore[misc]
                    rp.runtime_owner_path,
                    reason="CONTROL_CENTER_OBSERVED_TERMINAL_RUNNER_AND_FINALIZED_LOCK",
                )
            return True
        except Exception as exc:
            if rp.completion_reconcile_attempts in {1, 5, 20}:
                self.log(
                    f"Runner lease exit reconciliation warning for PID {rp.process.pid} "
                    f"(attempt {rp.completion_reconcile_attempts}): {exc}\n"
                )
            if rp.completion_reconcile_attempts < 20 and not self._closing:
                delay_ms = min(5000, 500 * (2 ** min(rp.completion_reconcile_attempts - 1, 4)))
                self.after(delay_ms, lambda: self.update_process_tree(force=True))
            return False

    def reconcile_finalized_acquisition_owner(self, *, silent: bool = True) -> bool:
        """Release a terminal global owner after delayed heartbeat expiry or restart."""
        log_root = str(getattr(self, "cfg", {}).get("log_root") or "")
        if not log_root:
            return True
        owner_path = active_acquisition_owner_path(log_root)  # type: ignore[misc]
        if not owner_path.is_file():
            return True
        try:
            owner = load_platform_json(owner_path)  # type: ignore[misc]
            lock_path = Path(str(owner.get("owner_core", {}).get("session_lock_path") or "")).expanduser().resolve()
            lock = load_platform_json(lock_path)  # type: ignore[misc]
            stage = str(lock.get("current_stage") or "")
            if stage not in {"FINALIZE", "QC", "ANALYZE", "EXPORT", "VERIFY"}:
                raise RuntimeError(
                    f"owner lock path currently resolves to stage {stage or '<blank>'}; "
                    "checking the narrow superseded-terminal-owner recovery contract"
                )
            finish_active_acquisition_owner(  # type: ignore[misc]
                owner_path,
                reason="CONTROL_CENTER_RECONCILED_TERMINAL_RUN_AFTER_HEARTBEAT_EXPIRY",
            )
            return True
        except Exception as exc:
            try:
                operator = str(
                    getattr(self, "cfg", {}).get("acquisition", {}).get("operator_name") or ""
                ).strip()
                recovered = recover_superseded_terminal_owner(  # type: ignore[misc]
                    owner_path,
                    operator=operator,
                    reason="ALPHA_8_5_3_RECOVERED_TERMINAL_OWNER_AFTER_RUNTIME_LOCK_WAS_SUPERSEDED",
                )
                self.log(
                    "Recovered the terminal acquisition owner left by a superseded runtime lock "
                    f"({recovered.get('owner_core', {}).get('run_uuid')}). Start a new equipment session UUID before launching again.\n"
                )
                return True
            except Exception as recovery_exc:
                if not silent:
                    self.log(
                        f"Global acquisition owner remains unresolved: {exc}; "
                        f"narrow superseded-lock recovery was not eligible: {recovery_exc}\n"
                    )
                return False

    def check_quick_exit(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if not rp:
            return
        rc = rp.process.poll()
        if rc is not None:
            self.update_process_tree()
            messagebox.showwarning(
                "Tool exited quickly",
                f"{rp.label} exited shortly after launch with code {rc}.\n\n"
                "If no window appeared, the launch did not complete. Use Open in that tool's "
                f"Dashboard row to inspect its log.\n\nLog:\n{rp.log_path}"
            )

    def get_python_cmd(self) -> List[str]:
        py_setting = self.cfg.get("python_executable") or sys.executable
        cmd = command_prefix_from_setting(str(py_setting))
        if not command_is_available(cmd):
            cmd = [sys.executable]
            self.cfg["python_executable"] = sys.executable
            if hasattr(self, "setting_vars") and "python_executable" in self.setting_vars:
                self.setting_vars["python_executable"].set(sys.executable)
            self.save_config()
            self.log(f"Unavailable Python setting repaired to current interpreter: {sys.executable}\n")
        return cmd

    def use_current_python(self) -> None:
        self.cfg["python_executable"] = sys.executable
        if hasattr(self, "setting_vars") and "python_executable" in self.setting_vars:
            self.setting_vars["python_executable"].set(sys.executable)
        self.save_config()
        self.log(f"Python executable reset to current interpreter: {sys.executable}\n")
        messagebox.showinfo("Python path updated", f"Python executable set to:\n{sys.executable}")

    def launch_python_tool(self, label: str, script_key: str, args: Optional[List[str]]=None) -> None:
        script = normalized_path(self.cfg["tools"].get(script_key, ""))
        if not script.is_file():
            messagebox.showerror("Script not found", f"Set the path for {script_key} in Settings.\n\nCurrent path:\n{script}")
            return
        self.launch_process(label, self.get_python_cmd() + [str(script)] + (args or []), cwd=script.parent)

    def _prune_exited_process_history(self) -> None:
        """Bound retained Popen records without discarding unresolved leases."""
        removable = [
            (key, rp)
            for key, rp in self.processes.items()
            if rp.process.poll() is not None and (not rp.runtime_authority or rp.completion_handled)
        ]
        removable.sort(key=lambda item: item[1].started, reverse=True)
        for key, _rp in removable[MAX_EXITED_PROCESS_ROWS:]:
            self.processes.pop(key, None)
            if self.selected_proc_key_var.get() == key:
                self.selected_proc_key_var.set("")

    def update_process_tree(self, *, force: bool = False) -> None:
        if not hasattr(self, "proc_rows_frame"):
            return
        self._prune_exited_process_history()
        signature = tuple(
            (
                key,
                rp.process.poll(),
                rp.shutdown_requested,
                int(max(0.0, time.time() - rp.started) // 60),
            )
            for key, rp in self.processes.items()
        )
        if not force and signature == self._process_tree_signature:
            return
        self._process_tree_signature = signature
        for child in self.proc_rows_frame.winfo_children():
            child.destroy()
        if not self.processes:
            ttk.Label(self.proc_rows_frame, text="No tools launched from this Control Center session.").pack(anchor="w", padx=6, pady=10)
            self.on_process_select()
            return
        refresh_context = False
        for proc_key, rp in self.processes.items():
            rc = rp.process.poll()
            status = "stopping" if rc is None and rp.shutdown_requested else "running" if rc is None else f"exited {rc}"
            runtime = time.strftime("%H:%M:%S", time.gmtime(time.time() - rp.started))
            row = ttk.Frame(self.proc_rows_frame)
            row.pack(fill="x", pady=1)
            for col, weight in [(0, 4), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1)]:
                row.columnconfigure(col, weight=weight)
            selector = tk.Radiobutton(
                row,
                text=rp.label,
                variable=self.selected_proc_key_var,
                value=proc_key,
                indicatoron=False,
                anchor="w",
                command=self.on_process_select,
                selectcolor="#dbeafe",
                relief="flat",
            )
            selector.grid(row=0, column=0, sticky="ew", padx=2)
            ttk.Label(row, text=str(rp.process.pid)).grid(row=0, column=1, sticky="w", padx=3)
            ttk.Label(row, text=status).grid(row=0, column=2, sticky="w", padx=3)
            ttk.Label(row, text=runtime).grid(row=0, column=3, sticky="w", padx=3)
            ttk.Button(row, text="Open", command=lambda key=proc_key: self.open_process_log(key)).grid(row=0, column=4, sticky="ew", padx=2)
            close_btn = tk.Button(
                row,
                text="Close",
                command=lambda key=proc_key: self.shutdown_process(key),
                bg="#9b1c1c",
                fg="white",
                activebackground="#6f1111",
                activeforeground="white",
                padx=7,
                pady=2,
            )
            if rc is not None:
                close_btn.configure(state="disabled", bg="#999999")
            close_btn.grid(row=0, column=5, sticky="ew", padx=2)
            more = ttk.Menubutton(row, text="More")
            menu = tk.Menu(more, tearoff=False)
            menu.add_command(label="Force close", command=lambda key=proc_key: self.force_kill_process(key))
            menu.add_command(label="Open log", command=lambda key=proc_key: self.open_process_log(key))
            menu.add_command(label="Open working folder", command=lambda key=proc_key: self.open_process_working_folder(key))
            menu.add_separator()
            menu.add_command(
                label="Restart" if rp.restartable else "Restart unavailable for locked runner",
                command=lambda key=proc_key: self.restart_process(key),
                state="normal" if rp.restartable else "disabled",
            )
            more.configure(menu=menu)
            more.grid(row=0, column=6, sticky="ew", padx=2)
            if rc is not None and not rp.completion_handled:
                rp.completion_handled = self.reconcile_runtime_lease_process_exit(rp, int(rc))
                refresh_context = True
                if rp.label.startswith("Stimulus Library") or rp.label.startswith("Stimulus Forge"):
                    self.after(100, self.refresh_stimulus_registry)
        self.on_process_select()
        if refresh_context:
            self.after(100, self.refresh_analysis_context)

    def periodic_update(self) -> None:
        if self._closing:
            return
        try:
            self.update_process_tree()
            self.refresh_workspace_ui()
            now = time.time()
            if now - self.last_owner_reconcile >= 5.0:
                self.last_owner_reconcile = now
                self.reconcile_finalized_acquisition_owner(silent=True)
            if now - self.last_acquisition_scan >= 5.0:
                self.last_acquisition_scan = now
                self.refresh_acquisition_readiness()
            if self.selected_run_folder and now - self.last_context_scan >= 12.0:
                self.last_context_scan = now
                self.refresh_analysis_context()
        except Exception as exc:
            if not self._closing:
                self.log(f"Periodic UI refresh recovered from {type(exc).__name__}: {exc}\n")
        finally:
            if not self._closing:
                self._periodic_after_id = self.after(1500, self.periodic_update)

    def on_process_select(self, _event=None) -> None:
        if not hasattr(self, "selected_tool_var"):
            return
        proc_key = self.selected_proc_key_var.get() if hasattr(self, "selected_proc_key_var") else ""
        if not proc_key:
            self.selected_tool_var.set("No tool selected")
            return
        rp = self.processes.get(proc_key)
        if not rp:
            self.selected_tool_var.set("Selected entry is unavailable")
            self.selected_proc_key_var.set("")
            return
        state = "running" if rp.process.poll() is None else f"exited {rp.process.poll()}"
        self.selected_tool_var.set(f"Selected: {rp.label} | PID {rp.process.pid} | {state}")

    def selected_process(self, show_warning: bool = True) -> Optional[Tuple[str, RunningProcess]]:
        proc_key = self.selected_proc_key_var.get() if hasattr(self, "selected_proc_key_var") else ""
        if not proc_key:
            if show_warning:
                messagebox.showwarning("No tool selected", "Select a Running Tools row first.")
            return None
        rp = self.processes.get(proc_key)
        if rp is None and show_warning:
            messagebox.showwarning("Tool unavailable", "The selected tool is no longer available in the process list.")
        return (proc_key, rp) if rp is not None else None

    def terminate_process_tree(self, rp: RunningProcess, force: bool = False) -> Tuple[bool, str]:
        """Terminate a launched tool and its child processes when supported."""
        if rp.process.poll() is not None:
            return True, f"already exited with code {rp.process.poll()}"
        try:
            if sys.platform.startswith("win"):
                cmd = ["taskkill", "/PID", str(rp.process.pid), "/T"]
                if force:
                    cmd.append("/F")
                completed = subprocess.run(cmd, capture_output=True, text=True, timeout=12)
                detail = (completed.stdout or completed.stderr or "").strip()
                if completed.returncode == 0:
                    return True, detail or "taskkill accepted the request"
                if force:
                    rp.process.kill()
                else:
                    rp.process.terminate()
                return True, detail or f"taskkill returned {completed.returncode}; used process fallback"
            if force:
                rp.process.kill()
            else:
                rp.process.terminate()
            return True, "process signal sent"
        except Exception as exc:
            return False, str(exc)

    def shutdown_selected_process(self) -> None:
        selected = self.selected_process()
        if selected is None:
            return
        self.shutdown_process(selected[0])

    def shutdown_process(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            messagebox.showwarning("Tool unavailable", "That tool is no longer available in the process list.")
            return
        self.selected_proc_key_var.set(proc_key)
        self.on_process_select()
        if rp.process.poll() is not None:
            messagebox.showinfo("Tool already stopped", f"{rp.label} has already exited with code {rp.process.poll()}.")
            self.update_process_tree()
            return
        if not messagebox.askyesno(
            "Shut down selected tool?",
            f"Shut down this tool and child processes?\n\n{rp.label}\nPID {rp.process.pid}",
        ):
            return
        rp.shutdown_requested = True
        ok, detail = self.terminate_process_tree(rp, force=False)
        self.log(f"Shutdown requested for {rp.label} PID {rp.process.pid}: {detail}\n")
        if not ok:
            messagebox.showerror("Shutdown failed", f"Could not request shutdown for {rp.label}.\n\n{detail}")
            rp.shutdown_requested = False
        self.update_process_tree()
        if ok:
            self.after(1600, lambda key=proc_key: self.check_shutdown_result(key))

    def check_shutdown_result(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            return
        rc = rp.process.poll()
        if rc is None:
            if messagebox.askyesno(
                "Tool is still running",
                f"{rp.label} did not stop after the normal shutdown request.\n\nForce close it and its child processes?",
            ):
                ok, detail = self.terminate_process_tree(rp, force=True)
                self.log(f"Force-close requested for {rp.label} PID {rp.process.pid}: {detail}\n")
                if not ok:
                    messagebox.showerror("Force close failed", detail)
            else:
                rp.shutdown_requested = False
        else:
            self.log(f"Stopped {rp.label} PID {rp.process.pid}; exit code {rc}.\n")
        self.update_process_tree()

    def stop_selected_process(self) -> None:
        """Backward-compatible alias retained for internal callers."""
        self.shutdown_selected_process()

    def force_kill_selected_process(self) -> None:
        selected = self.selected_process()
        if selected is None:
            return
        self.force_kill_process(selected[0])

    def force_kill_process(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            messagebox.showwarning("Tool unavailable", "That tool is no longer available in the process list.")
            return
        self.selected_proc_key_var.set(proc_key)
        self.on_process_select()
        if rp.process.poll() is not None:
            messagebox.showinfo("Tool already stopped", f"{rp.label} has already exited with code {rp.process.poll()}.")
            return
        if not messagebox.askyesno("Force close selected tool?", f"Force close this tool and child processes?\n\n{rp.label}\nPID {rp.process.pid}"):
            return
        rp.shutdown_requested = True
        ok, detail = self.terminate_process_tree(rp, force=True)
        self.log(f"Force-close requested for {rp.label} PID {rp.process.pid}: {detail}\n")
        if not ok:
            messagebox.showerror("Force close failed", detail)
            rp.shutdown_requested = False
        self.update_process_tree()

    def open_selected_process_log(self) -> None:
        selected = self.selected_process()
        if selected is not None:
            self.open_process_log(selected[0])

    def open_process_log(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp:
            open_path(rp.log_path)

    def open_process_working_folder(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp:
            open_path(rp.cwd or rp.log_path.parent)

    def restart_process(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            return
        if rp.runtime_authority or not rp.restartable or any(
            key in RUNTIME_AUTHORITY_ENV_KEYS for key in (rp.env_overrides or {})
        ):
            messagebox.showwarning(
                "Locked runner cannot be restarted",
                "An authorized protocol runner can consume a session launch claim only once. "
                "If the run did not finalize, use Analysis Modules → Finalize Interrupted Run, then "
                "start a new acquisition UUID, re-establish the selected setup, lock, and arm again. Participant runs must also repeat the required live checks.",
            )
            return
        if rp.process.poll() is None:
            messagebox.showinfo("Tool still running", "Close this tool before restarting it.")
            return
        self.launch_process(rp.label, list(rp.cmd), cwd=rp.cwd, env_overrides=rp.env_overrides)

    def clear_exited_processes(self) -> None:
        removable: List[str] = []
        for key, rp in list(self.processes.items()):
            return_code = rp.process.poll()
            if return_code is None:
                continue
            if rp.runtime_authority and not rp.completion_handled:
                rp.completion_handled = self.reconcile_runtime_lease_process_exit(rp, int(return_code))
                if not rp.completion_handled:
                    # A terminal child can remain authoritative briefly while
                    # its last heartbeat is fresh.  Keep the row as the retry
                    # carrier instead of discarding persistent cleanup work.
                    continue
            removable.append(key)
        for key in removable:
            self.processes.pop(key, None)
        if self.selected_proc_key_var.get() in removable:
            self.selected_proc_key_var.set("")
        self.update_process_tree(force=True)

    # Dashboard/status
    def refresh_dashboard(self) -> None:
        if not hasattr(self, "status_text"): return
        self.status_text.config(state="normal")
        self.status_text.delete("1.0", "end")
        lines = []
        lines.append(f"Version: {APP_VERSION}")
        lines.append(f"PRAYCG_HOME: {self.cfg['praycg_home']}")
        lines.append(f"Stimulus root: {self.cfg['stimulus_root']}")
        lines.append(f"Run root: {self.cfg['run_root']}")
        lines.append(f"Analysis root: {self.cfg['analysis_root']}")
        lines.append(f"Active context: {self.context_path}")
        lines.append(f"Study Workspace: {self.active_workspace_path or 'none'}")
        if self.active_workspace:
            lines.append(f"Study ID: {self.active_workspace.get('study_id')}")
            lines.append(f"Session ID: {self.active_workspace.get('current_session', {}).get('session_id')}")
            lines.append(f"Lifecycle: {workflow_summary(self.active_workspace)}")
            stage, reason = workspace_next_action(self.active_workspace)
            lines.append(f"Next governed stage: {WORKFLOW_LABELS.get(stage, stage)} — {reason}")
        lines.append(f"Selected stimulus: {self.active_context.get('stimulus', {}).get('id') or 'none'}")
        lines.append(f"Selected run: {self.active_context.get('run', {}).get('folder') or 'none'}")
        lines.append(f"Preferred review output: {self.active_context.get('analysis', {}).get('preferred_review_folder') or 'none'}")
        lines.append("")
        lines.append("Governed lifecycle:")
        lines.append("Protocol → Stimuli → Hardware → Arm → Run → QC → Analyze → Review → Export")
        lines.append("Upstream changes mark dependent locks STALE without deleting the earlier evidence.")
        lines.append("Analysis uses an immutable pre-outcome plan and a dependency graph; there is no Run Everything action.")
        lines.append("Anything added after plan lock is POST_HOC_EXPLORATORY and has no primary-conclusion authority.")
        lines.append("Export first builds a local review bundle. Alpha.7 cannot upload or approve publication, and raw biosignals are excluded.")
        lines.append("")
        lines.append("Important boundary: cataloging, generation, or a software PASS does not certify hardware, stimuli, endpoints, or constructs.")
        self.status_text.insert("end", "\n".join(lines))
        self.status_text.config(state="disabled")

    # Stimulus library
    def read_registry(self) -> Dict[str, Any]:
        p = Path(self.cfg["stimulus_registry"])
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {"schema":"PRAYCG_StimulusRegistry_v0_1", "stimuli": []}

    def write_registry(self, reg: Dict[str, Any]) -> None:
        Path(self.cfg["stimulus_registry"]).write_text(json.dumps(reg, indent=2), encoding="utf-8")

    def stimulus_registry_items(self) -> List[Dict[str, Any]]:
        """Normalize legacy masters and installed governed packs for one UI."""
        registry = self.read_registry()
        normalized: List[Dict[str, Any]] = []
        seen: set[str] = set()
        legacy = registry.get("stimuli", [])
        if isinstance(legacy, list):
            for row in legacy:
                if not isinstance(row, dict):
                    continue
                item = dict(row)
                stimulus_id = str(item.get("stimulus_id") or "").strip()
                if not stimulus_id or stimulus_id in seen:
                    continue
                item["registry_kind"] = "legacy_master"
                item["active_for_selection"] = True
                normalized.append(item)
                seen.add(stimulus_id)
        packs = registry.get("packs", [])
        if not isinstance(packs, list):
            return normalized
        for row in packs:
            if not isinstance(row, dict):
                continue
            pack_id = str(row.get("pack_id") or "").strip()
            folder = str(row.get("path") or "").strip()
            if not pack_id or not folder or pack_id in seen:
                continue
            normalized.append({
                "stimulus_id": pack_id,
                "pack_id": pack_id,
                "registry_kind": "stimulus_pack",
                "folder": folder,
                "created_local": row.get("installed_utc") or "",
                "last_selected_local": row.get("last_selected_local") or "",
                "validation_status": row.get("validation_status") or "UNKNOWN",
                "scientific_status": row.get("scientific_status") or "UNKNOWN",
                "manifest_content_sha256": row.get("manifest_content_sha256") or "",
                "active_for_selection": row.get("active_for_selection") is True,
                "registry_errors": list(row.get("errors") or []),
                "pinned": bool(row.get("pinned")),
            })
            seen.add(pack_id)
        return normalized

    def unlocked_bundled_stimulus_nodes(self) -> List[Dict[str, Any]]:
        """Show packaged demonstrations before lock without claiming compatibility."""
        catalog_path = self.pkg.parent / "tools" / "Stimulus_Forge_Library_v1_0" / "config" / "stimulus_pack_catalog_v1_0.json"
        try:
            catalog = json.loads(catalog_path.read_text(encoding="utf-8-sig"))
        except Exception:
            return []
        rows: List[Dict[str, Any]] = [{
            "node_type": "folder",
            "node_id": "stimulus-folder::bundled-unfiltered",
            "parent_id": "",
            "display_name": "Bundled Sample Packs — lock a protocol to filter",
        }]
        for entry in catalog.get("packs", []):
            if not isinstance(entry, dict):
                continue
            pack_id = str(entry.get("pack_id") or "")
            source = (self.pkg.parent / str(entry.get("package_relative_root") or "")).resolve(strict=False)
            report_status = "MISSING"
            if validate_stimulus_pack is not None and source.is_dir():
                try:
                    report_status = str(validate_stimulus_pack(source, media_probe=False).status)
                except Exception:
                    report_status = "UNREADABLE"
            rows.append({
                "node_type": "stimulus",
                "node_id": f"unlocked-bundled::{pack_id}",
                "candidate_id": f"unlocked-bundled::{pack_id}",
                "parent_id": "stimulus-folder::bundled-unfiltered",
                "display_name": entry.get("display_name") or pack_id,
                "pack_id": pack_id,
                "source_kind": "BUNDLED_SAMPLE_PACK",
                "source_path": str(source),
                "status": report_status,
                "validation_status": report_status,
                "scientific_status": entry.get("scientific_status") or "DEMO_ONLY",
                "selection_allowed": False,
                "plain_language_status": "Visible for inspection. Lock a protocol before installation or use so compatibility can be revalidated.",
            })
        return rows

    def reconcile_active_stimulus_with_workflow(self, workflow: Dict[str, Any]) -> Tuple[str, str]:
        """Keep an active stimulus only when it remains compatible with the new lock."""
        stim_id = str(self.selected_stimulus_id or "")
        if not stim_id or not self.locked_protocol or workflow.get("status") not in {"READY", "CAUTION"}:
            return "", ""
        candidates = [
            row
            for row in workflow.get("compatible_stimuli", [])
            if isinstance(row, dict)
            and (
                str(row.get("pack_id") or "") == stim_id
                or (
                    row.get("source_kind") == "MASTER_PRAYCG_MEDIA"
                    and str(row.get("candidate_id") or "").split("::", 1)[-1] == stim_id
                )
            )
        ]
        if candidates:
            active_folder = str(self.active_context.get("stimulus", {}).get("folder") or "")
            if active_folder:
                for row in candidates:
                    source_path = str(row.get("source_path") or "")
                    if not source_path:
                        continue
                    try:
                        if Path(source_path).expanduser().resolve(strict=False) == Path(active_folder).expanduser().resolve(strict=False):
                            return str(row.get("candidate_id") or ""), ""
                    except OSError:
                        continue
            return str(candidates[0].get("candidate_id") or ""), ""

        protocol_id = str(self.locked_protocol.get("protocol_id") or "the locked protocol")
        note = f"Previous stimulus {stim_id} was cleared because it is not compatible with {protocol_id}."
        had_context = bool(self.active_context.get("stimulus"))
        self.selected_stimulus_id = None
        self.active_context["stimulus"] = {}
        if had_context:
            self.mark_session_stale_for_stimulus_change(note)
        self.save_active_context()
        self.refresh_runner_detect_text()
        self.log(note + "\n")
        return "", note

    def refresh_protocol_stimulus_ui(self) -> None:
        if not hasattr(self, "stim_tree"):
            return
        previous_candidate_id = self.selected_stimulus_candidate_id
        self.stim_tree.delete(*self.stim_tree.get_children())
        self.stimulus_tree_candidates = {}
        self.selected_stimulus_candidate_id = None
        if self.locked_protocol:
            workflow = self.protocol_stimulus_model.resolve_locked_workflow(
                self.protocol_lock_path,
                stimulus_registry_path=Path(self.cfg["stimulus_registry"]),
            )
            nodes = list(workflow.get("stimulus_nodes") or [])
        else:
            workflow = {
                "status": "LOCK_REQUIRED",
                "plain_language": "Bundled examples are visible below. Confirm one protocol in Choose Protocol to show only compatible materials and preparation tools.",
                "reasons": [],
                "stimulus_nodes": self.unlocked_bundled_stimulus_nodes(),
                "prep_engines": [],
            }
            nodes = list(workflow["stimulus_nodes"])
        active_candidate_id, reconciliation_note = self.reconcile_active_stimulus_with_workflow(workflow)
        self.protocol_stimulus_workflow = workflow
        self.stimulus_workflow_var.set(
            str(workflow.get("plain_language") or "The locked protocol's stimulus workflow could not be resolved.")
            + ((" Reasons: " + "; ".join(map(str, workflow.get("reasons", [])))) if workflow.get("reasons") else "")
            + ((" " + reconciliation_note) if reconciliation_note else "")
        )
        folders: set[str] = set()
        for node in nodes:
            if node.get("node_type") != "folder":
                continue
            node_id = str(node.get("node_id") or "")
            if not node_id:
                continue
            self.stim_tree.insert("", "end", iid=node_id, text=node.get("display_name"), open=True)
            folders.add(node_id)
        for node in nodes:
            if node.get("node_type") != "stimulus":
                continue
            node_id = str(node.get("node_id") or node.get("candidate_id") or "")
            if not node_id:
                continue
            parent = str(node.get("parent_id") or "")
            if parent not in folders:
                parent = ""
            source = {
                "BUNDLED_SAMPLE_PACK": "Bundled sample",
                "INSTALLED_PACK": "Installed pack",
                "MASTER_PRAYCG_MEDIA": "Master media",
            }.get(str(node.get("source_kind")), str(node.get("source_kind") or "Unknown"))
            scientific = str(node.get("scientific_status") or "")
            research_use = "DEMO ONLY" if scientific == "DEMO_ONLY" else "PREP INPUT" if scientific == "PREPARATION_INPUT_ONLY" else scientific or "REVIEW"
            self.stim_tree.insert(
                parent,
                "end",
                iid=node_id,
                text=node.get("display_name") or node.get("candidate_id"),
                values=(source, node.get("validation_status") or node.get("status") or "UNKNOWN", research_use),
            )
            self.stimulus_tree_candidates[node_id] = dict(node)
        self.render_protocol_prep_actions()
        if hasattr(self, "stimulus_use_button"):
            self.stimulus_use_button.configure(state="disabled")
        locked = self.locked_protocol_record()
        asset_folder = ""
        if locked and locked.get("module_family") == FAMILY_ATLAS:
            asset_folder = str(self.cfg.setdefault("protocol_asset_folders", {}).get(locked.get("protocol_id"), "") or "")
        if hasattr(self, "protocol_asset_folder_var"):
            self.protocol_asset_folder_var.set(asset_folder)
        if hasattr(self, "protocol_asset_rows_frame"):
            self.render_protocol_asset_bindings()
        self.stim_detail.delete("1.0", "end")
        self.stim_detail.insert(
            "end",
            "Select an asset row to inspect it. Bundled packs are package-owned examples; use Install to create a writable working copy.\n\n"
            + str(workflow.get("authority_boundary") or "A visible asset is not acquisition authority."),
        )
        selection_id = (
            previous_candidate_id
            if previous_candidate_id in self.stimulus_tree_candidates
            else active_candidate_id
            if active_candidate_id in self.stimulus_tree_candidates
            else ""
        )
        if selection_id:
            self.stim_tree.selection_set(selection_id)
            self.stim_tree.focus(selection_id)
            self.stim_tree.see(selection_id)
            self.on_stim_select()

    def refresh_stimulus_registry(self) -> None:
        """Compatibility alias used after legacy registry mutations."""
        self.refresh_protocol_stimulus_ui()

    def render_protocol_prep_actions(self) -> None:
        frame = getattr(self, "stimulus_prep_buttons_frame", None)
        if frame is None:
            return
        for child in frame.winfo_children():
            child.destroy()
        workflow = self.protocol_stimulus_workflow or {}
        engines = list(workflow.get("prep_engines") or [])
        if not self.locked_protocol:
            self.stimulus_prep_summary_var.set("Preparation choices are intentionally hidden until a protocol is locked.")
            ttk.Button(frame, text="Go to Choose Protocol", command=lambda: self.nb.select(self.protocol_tab)).pack(fill="x", pady=2)
            return
        protocol = workflow.get("protocol", {}) if isinstance(workflow.get("protocol"), dict) else {}
        direct = [row for row in engines if row.get("direct_launch_allowed") and row.get("id") != "protocol_sample_pack_validator"]
        pipeline = [str(row.get("id")) for row in engines if not row.get("direct_launch_allowed")]
        self.stimulus_prep_summary_var.set(
            f"Available for {protocol.get('protocol_id')} v{protocol.get('protocol_version')}: "
            + (", ".join(str(row.get("id")) for row in direct) if direct else "no standalone Forge generator")
            + (". Included pipeline stages: " + ", ".join(pipeline) if pipeline else "")
        )
        action = workflow.get("recommended_launch_action", {}) if isinstance(workflow.get("recommended_launch_action"), dict) else {}
        if action.get("action_id") == "launch_mediaprep":
            ttk.Button(
                frame,
                text=f"Launch {protocol.get('protocol_id')} MediaPrep",
                command=self.launch_mediaprep,
            ).pack(fill="x", pady=2)
            ttk.Button(frame, text="MP4 ALS Barcode Backup Utility", command=self.launch_mediaprep_barcode_backup).pack(fill="x", pady=2)
            if "shot_order_scramble" in pipeline:
                ttk.Button(frame, text="Shot-Order Scramble Utility", command=self.launch_shot_order_scramble).pack(fill="x", pady=2)
        allowed = [str(row.get("id")) for row in direct if str(row.get("id") or "")]
        for row in direct:
            engine_id = str(row.get("id") or "")
            ttk.Button(
                frame,
                text=f"Open {engine_id.replace('_', ' ').title()} Generator",
                command=lambda value=engine_id, choices=tuple(allowed): self.launch_stimulus_forge_for_engine(value, choices),
            ).pack(fill="x", pady=2)
        ttk.Button(frame, text="Validate / Install Packs (Advanced)", command=self.launch_stimulus_library).pack(fill="x", pady=2)

    def selected_stimulus_candidate(self) -> Optional[Dict[str, Any]]:
        if not self.selected_stimulus_candidate_id:
            return None
        value = self.stimulus_tree_candidates.get(self.selected_stimulus_candidate_id)
        return dict(value) if value else None

    def open_selected_stimulus_candidate(self) -> None:
        candidate = self.selected_stimulus_candidate()
        if not candidate:
            messagebox.showinfo("Select an asset", "Select a stimulus asset row first.")
            return
        source = Path(str(candidate.get("source_path") or "")).expanduser()
        open_path(source)

    def use_selected_compatible_stimulus(self) -> None:
        candidate = self.selected_stimulus_candidate()
        if not candidate:
            messagebox.showinfo("Select an asset", "Select a compatible stimulus or master-media row first.")
            return
        if not self.locked_protocol:
            messagebox.showinfo("Choose protocol first", "Confirm a protocol in Choose Protocol before installing or selecting prepared materials.")
            return
        check = self.protocol_stimulus_model.preflight_candidate_for_locked_protocol(
            self.protocol_lock_path,
            str(candidate.get("candidate_id") or ""),
            stimulus_registry_path=Path(self.cfg["stimulus_registry"]),
        )
        if check.get("status") != "PASS":
            messagebox.showerror("Stimulus selection blocked", "\n".join(map(str, check.get("reasons") or ["Compatibility could not be revalidated."])))
            self.refresh_protocol_stimulus_ui()
            return
        candidate = dict(check["candidate"])
        if candidate.get("source_kind") == "BUNDLED_SAMPLE_PACK":
            if install_stimulus_pack is None or write_stimulus_pack_registry is None:
                messagebox.showerror("Installer unavailable", STIMULUS_CONTRACT_IMPORT_ERROR or "Stimulus pack installer is unavailable.")
                return
            destination_root = Path(self.cfg["stimulus_pack_install_root"]).expanduser()
            try:
                installed, report = install_stimulus_pack(Path(str(candidate["source_path"])), destination_root)
                write_stimulus_pack_registry(destination_root, Path(self.cfg["stimulus_registry"]), media_probe=False)
            except Exception as exc:
                messagebox.showerror("Working-copy installation stopped", str(exc))
                return
            self.refresh_protocol_stimulus_ui()
            installed_candidate = next(
                (
                    row for row in self.stimulus_tree_candidates.values()
                    if row.get("source_kind") == "INSTALLED_PACK" and row.get("pack_id") == candidate.get("pack_id")
                ),
                None,
            )
            if installed_candidate:
                self.selected_stimulus_candidate_id = str(installed_candidate.get("candidate_id"))
                self.activate_compatible_stimulus_candidate(installed_candidate)
            messagebox.showinfo(
                "Working copy installed",
                f"Installed and revalidated at:\n{installed}\n\nStatus: {report.status}. Scientific status was not promoted.",
            )
            return
        self.activate_compatible_stimulus_candidate(candidate)

    def activate_compatible_stimulus_candidate(self, candidate: Dict[str, Any]) -> None:
        source_kind = str(candidate.get("source_kind") or "")
        stim_id = str(candidate.get("pack_id") or "")
        if source_kind == "MASTER_PRAYCG_MEDIA":
            stim_id = str(candidate.get("candidate_id") or "").split("::", 1)[-1]
        if not stim_id:
            messagebox.showerror("Stimulus selection blocked", "The compatible row has no stable stimulus identity.")
            return
        self.selected_stimulus_id = stim_id
        self.record_stimulus_access(stim_id)
        self.update_stimulus_context(stim_id)
        self.display_stimulus_detail(stim_id)
        self.refresh_runner_detect_text()
        self.log(f"Selected protocol-compatible stimulus: {stim_id}\n")

    def add_master_stimulus(self) -> None:
        path_str = filedialog.askopenfilename(title="Select master stimulus MP4", filetypes=[("MP4", "*.mp4"), ("All files", "*.*")])
        if not path_str: return
        src = Path(path_str)
        stim_id = simpledialog.askstring("Stimulus ID", "Enter a short stimulus ID (letters/numbers/underscore):", initialvalue=slugify(src.stem))
        if not stim_id: return
        stim_id = slugify(stim_id)
        stim_dir = Path(self.cfg["stimulus_root"]) / stim_id
        master_dir = stim_dir / "master"
        master_dir.mkdir(parents=True, exist_ok=True)
        dst = master_dir / "stimulus_master.mp4"
        if dst.exists() and not messagebox.askyesno("Overwrite?", f"{dst} already exists. Overwrite?"):
            return
        self.log(f"Copying master stimulus to {dst}\n")
        shutil.copy2(src, dst)
        report = self.validate_mp4(dst)
        report["original_source_path"] = str(src)
        report["stimulus_id"] = stim_id
        report["copied_to"] = str(dst)
        report["created_local"] = datetime.now().isoformat(timespec="seconds")
        report["sha256"] = sha256_file(dst)
        (master_dir / "master_sha256.txt").write_text(report["sha256"] + "\n", encoding="utf-8")
        (master_dir / "master_media_validation_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        reg = self.read_registry()
        reg["stimuli"] = [s for s in reg.get("stimuli", []) if s.get("stimulus_id") != stim_id]
        reg["stimuli"].append({
            "stimulus_id": stim_id,
            "folder": str(stim_dir),
            "master_mp4": str(dst),
            "tags": [MASTER_MEDIA_TAG],
            "stimulus_class": MASTER_MEDIA_TAG,
            "duration_sec": report.get("duration_sec"),
            "created_local": report["created_local"],
            "sha256": report["sha256"],
            "validation_status": report.get("status", "UNKNOWN"),
            "active_for_selection": True,
            "pinned": False,
            "last_selected_local": report["created_local"],
        })
        self.write_registry(reg)
        self.refresh_stimulus_registry()
        candidate_id = f"master::{stim_id}"
        candidate = self.stimulus_tree_candidates.get(candidate_id)
        activation_note = "Registered as a governed master-media preparation input."
        if self.locked_protocol and isinstance(candidate, dict):
            check = self.protocol_stimulus_model.preflight_candidate_for_locked_protocol(
                self.protocol_lock_path,
                candidate_id,
                stimulus_registry_path=Path(self.cfg["stimulus_registry"]),
            )
            if check.get("status") == "PASS":
                self.selected_stimulus_candidate_id = candidate_id
                if self.stim_tree.exists(candidate_id):
                    self.stim_tree.selection_set(candidate_id)
                    self.stim_tree.focus(candidate_id)
                    self.stim_tree.see(candidate_id)
                self.activate_compatible_stimulus_candidate(dict(check["candidate"]))
                activation_note = "It is compatible with the current protocol lock and is now the active MediaPrep input."
            else:
                activation_note = "It was registered but not activated because current-lock compatibility could not be revalidated."
        elif self.locked_protocol:
            activation_note = "It was registered but is not an input accepted by the current protocol lock, so the active context was not changed."
        else:
            activation_note = "Lock PRAYCG3, PRAYCG4, or SMG to revalidate and select it for MediaPrep."
        messagebox.showinfo(
            "Stimulus added",
            f"Added {stim_id}\n\nValidation status: {report.get('status')}\n\n{activation_note}",
        )

    def migrate_legacy_master_stimuli(self) -> None:
        """Explicitly revalidate alpha.4 master rows before applying the current master-media tag."""
        if not messagebox.askyesno(
            "Revalidate existing masters",
            "This checks existing untagged master-video rows against their live MP4, recorded SHA-256, "
            "alpha.4 validation report, hash sidecar, and folder containment. Only rows that pass every check "
            f"receive {MASTER_MEDIA_TAG}.\n\n"
            "A backup of the registry is written before any change. Scientific status and acquisition eligibility are not promoted. Continue?",
            parent=self,
        ):
            return
        try:
            report = migrate_legacy_master_registry(
                Path(self.cfg["stimulus_registry"]),
                Path(self.cfg["stimulus_root"]),
            )
        except Exception as exc:
            messagebox.showerror("Master migration stopped", str(exc))
            return
        self.refresh_protocol_stimulus_ui()
        migrated = list(report.get("migrated_ids") or [])
        skipped = list(report.get("skipped") or [])
        details = [
            f"Status: {report.get('status')}",
            f"Tagged after live revalidation: {len(migrated)}" + ((" — " + ", ".join(migrated)) if migrated else ""),
            f"Already tagged: {len(report.get('already_tagged_ids') or [])}",
            f"Skipped: {len(skipped)}",
        ]
        if report.get("backup_path"):
            details.append(f"Registry backup: {report['backup_path']}")
        if skipped:
            details.append(
                "Skipped reasons:\n- "
                + "\n- ".join(
                    f"{row.get('stimulus_id') or 'unnamed row'}: {'; '.join(map(str, row.get('reasons') or []))}"
                    for row in skipped[:8]
                )
            )
            if len(skipped) > 8:
                details.append(f"{len(skipped) - 8} additional skipped row(s); inspect the registry and validation files.")
        details.append(str(report.get("authority_boundary") or ""))
        self.log(
            f"Legacy master-media migration: {report.get('status')} | tagged {len(migrated)} | skipped {len(skipped)}.\n"
        )
        messagebox.showinfo("Existing-master review complete", "\n\n".join(details), parent=self)

    def validate_mp4(self, path: Path) -> Dict[str, Any]:
        rep: Dict[str, Any] = {"schema":"PRAYCG_MasterStimulus_Validation_v0_1", "file": str(path), "status":"PILOT_UNVALIDATED"}
        rep["size_bytes"] = path.stat().st_size
        rep["extension_ok"] = path.suffix.lower() == ".mp4"
        warnings = []
        # Try ffprobe first
        ffprobe = shutil.which("ffprobe")
        if ffprobe:
            try:
                cmd = [ffprobe, "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", str(path)]
                out = subprocess.check_output(cmd, text=True, errors="replace")
                info = json.loads(out)
                rep["ffprobe"] = info
                fmt = info.get("format", {})
                rep["duration_sec"] = float(fmt.get("duration")) if fmt.get("duration") else None
                video_streams = [s for s in info.get("streams", []) if s.get("codec_type") == "video"]
                audio_streams = [s for s in info.get("streams", []) if s.get("codec_type") == "audio"]
                rep["has_video"] = bool(video_streams); rep["has_audio"] = bool(audio_streams)
                if video_streams:
                    vs = video_streams[0]
                    rep["width"] = vs.get("width"); rep["height"] = vs.get("height")
                    rep["avg_frame_rate"] = vs.get("avg_frame_rate")
                if not audio_streams: warnings.append("No audio stream detected.")
            except Exception as exc:
                rep["ffprobe_error"] = str(exc)
        else:
            warnings.append("ffprobe not found; validation limited. Install FFmpeg for stronger checks.")
        # Try OpenCV if useful
        try:
            import cv2  # type: ignore
            cap = cv2.VideoCapture(str(path))
            if cap.isOpened():
                fps = cap.get(cv2.CAP_PROP_FPS)
                frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
                w = cap.get(cv2.CAP_PROP_FRAME_WIDTH); h = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
                rep.setdefault("fps", fps); rep.setdefault("frame_count", frames)
                rep.setdefault("width", w); rep.setdefault("height", h)
                if not rep.get("duration_sec") and fps and frames:
                    rep["duration_sec"] = float(frames / fps)
                cap.release()
            else:
                warnings.append("OpenCV could not open MP4.")
        except Exception as exc:
            rep["opencv_error"] = str(exc)
        dur = rep.get("duration_sec")
        if dur is not None:
            if dur < 120: warnings.append("Duration < 2 min; acceptable for tests, weak for standard PRAYCG.")
            if dur > 360: warnings.append("Duration > 6 min; may be long for standard PRAYCG.")
        rep["warnings"] = warnings
        rep["status"] = "PASS_WITH_WARNINGS" if warnings else "PASS_BASIC_VALIDATION"
        return rep

    def on_stim_select(self, event=None) -> None:
        sel = self.stim_tree.selection()
        if not sel:
            return
        candidate = self.stimulus_tree_candidates.get(sel[0])
        if not candidate:
            self.selected_stimulus_candidate_id = None
            self.stimulus_use_button.configure(state="disabled")
            return
        self.selected_stimulus_candidate_id = sel[0]
        allowed = bool(candidate.get("selection_allowed")) and bool(self.locked_protocol)
        self.stimulus_use_button.configure(state="normal" if allowed else "disabled")
        self.stim_detail.delete("1.0", "end")
        self.stim_detail.insert("end", json.dumps(candidate, indent=2))
        if candidate.get("source_kind") == "BUNDLED_SAMPLE_PACK":
            self.stimulus_use_button.configure(text="Install and Use Working Copy")
        else:
            self.stimulus_use_button.configure(text="Use Selected Compatible Asset")

    def record_stimulus_access(self, stim_id: str) -> None:
        reg = self.read_registry()
        changed = False
        for collection, id_key in (("stimuli", "stimulus_id"), ("packs", "pack_id")):
            rows = reg.get(collection, [])
            if not isinstance(rows, list):
                continue
            for item in rows:
                if isinstance(item, dict) and item.get(id_key) == stim_id:
                    item["last_selected_local"] = datetime.now().isoformat(timespec="seconds")
                    item.setdefault("pinned", False)
                    changed = True
                    break
            if changed:
                break
        if changed:
            self.write_registry(reg)

    def toggle_pin_selected_stimulus(self) -> None:
        if not self.selected_stimulus_id:
            messagebox.showinfo("No stimulus selected", "Select a stimulus first.")
            return
        reg = self.read_registry()
        for collection, id_key in (("stimuli", "stimulus_id"), ("packs", "pack_id")):
            rows = reg.get(collection, [])
            if not isinstance(rows, list):
                continue
            for item in rows:
                if isinstance(item, dict) and item.get(id_key) == self.selected_stimulus_id:
                    item["pinned"] = not bool(item.get("pinned"))
                    self.write_registry(reg)
                    self.refresh_stimulus_registry()
                    return

    def selected_stimulus_folder(self) -> Optional[Path]:
        if not self.selected_stimulus_id:
            return None
        for item in self.stimulus_registry_items():
            if item.get("stimulus_id") != self.selected_stimulus_id:
                continue
            if item.get("registry_kind") == "stimulus_pack" and not item.get("active_for_selection"):
                return None
            if str(item.get("folder") or "").strip():
                return Path(str(item["folder"])).expanduser()
        return Path(self.cfg["stimulus_root"]) / self.selected_stimulus_id

    def display_stimulus_detail(self, stim_id: str) -> None:
        if not hasattr(self, "stim_detail"): return
        folder = self.selected_stimulus_folder() if stim_id == self.selected_stimulus_id else None
        if folder is None:
            folder = Path(self.cfg["stimulus_root"]) / stim_id
        detections = self.detect_stimulus_files(folder)
        self.stim_detail.delete("1.0", "end")
        self.stim_detail.insert("end", json.dumps(detections, indent=2))
        self.refresh_runner_detect_text()

    def detect_stimulus_files(self, folder: Path) -> Dict[str, Any]:
        patterns = {
            "master_mp4": ["master/stimulus_master.mp4", "**/stimulus_master.mp4"],
            "target_video": ["**/stimulus_target_cued*.mp4"],
            "override_video": ["**/stimulus_override_cued*.mp4"],
            "control_video": ["**/stimulus_control*cued*phase*scrambled*.mp4", "**/stimulus_control*.mp4"],
            "shot_order_video": ["**/*shot*order*.mp4", "**/*shotorder*.mp4"],
            "semantic_zero_video": ["**/*semantic*zero*.mp4", "**/*semantic_zero*.mp4"],
            "cue_schedule_json": ["**/cue_schedule*.json"],
            "cue_schedule_csv": ["**/cue_schedule*.csv"],
            "locked_anchor_json": ["**/*LOCKED*.json"],
            "draft_anchor_json": ["**/*DRAFT*.json", "**/*ESTIMATED*.json"],
            "stimulus_fingerprint_all": ["**/stimulus_exogenous_regressor_frame_all_conditions.csv"],
            "cet_regressors_all": ["**/cet_regressors_all_conditions.csv"],
            "mediaprep_manifest": ["**/*manifest*.json", "**/*MediaPrep*report*.json"],
            "shot_order_manifest": ["**/*shot*order*manifest*.json", "**/*shotorder*manifest*.json"],
            "semantic_density_sidecar": ["**/*semantic*density*.json", "**/*semantic*density*.csv"],
        }
        out = {"folder": str(folder), "exists": folder.exists(), "files": {}}
        for key, pats in patterns.items():
            matches: List[str] = []
            for pat in pats:
                matches += [str(p) for p in folder.glob(pat) if p.is_file()]
            # de-duplicate, shortest newest-ish: preserve sorted
            matches = sorted(set(matches), key=lambda x: (len(x), x))
            out["files"][key] = matches[:10]
        # Alpha.4 data-only sample packs declare exact protocol bindings.  Use
        # those paths ahead of filename heuristics, but never execute pack
        # content or allow a binding to escape the selected pack directory.
        pack_manifest = folder / "stimulus_pack_manifest.json"
        if pack_manifest.is_file():
            try:
                manifest = json.loads(pack_manifest.read_text(encoding="utf-8"))
                if validate_stimulus_pack is None:
                    raise ValueError(
                        "Pack contract validator is unavailable: "
                        + (STIMULUS_CONTRACT_IMPORT_ERROR or "unknown import failure")
                    )
                pack_report = validate_stimulus_pack(folder, media_probe=False)
                out["stimulus_pack_validation"] = pack_report.as_dict()
                if pack_report.status == "FAIL":
                    raise ValueError("pack validation failed: " + "; ".join(pack_report.errors))
                selected = self.locked_protocol_record() or (self.selected_protocol_record() if hasattr(self, "protocol_select_var") else None)
                protocol_id = str((selected or {}).get("protocol_id") or self.cfg.get("selected_protocol_id") or "")
                rows = [
                    row for row in manifest.get("compatibility", [])
                    if isinstance(row, dict) and str(row.get("protocol_id") or "") == protocol_id
                ]
                if len(rows) == 1:
                    binding_aliases = {
                        "cue_schedule": "cue_schedule_json",
                        "predeclared_anchor_file": "locked_anchor_json",
                    }
                    for raw_key, raw_relative in (rows[0].get("bindings") or {}).items():
                        detection_key = binding_aliases.get(str(raw_key), str(raw_key))
                        if detection_key not in out["files"]:
                            continue
                        relative = Path(str(raw_relative))
                        candidate = (folder / relative).resolve(strict=False)
                        if relative.is_absolute() or not path_is_within(candidate, folder) or not candidate.exists():
                            continue
                        value = str(candidate)
                        out["files"][detection_key] = [value] + [item for item in out["files"][detection_key] if item != value]
                    target_values = out["files"].get("target_video", [])
                    if target_values and not out["files"].get("master_mp4"):
                        out["files"]["master_mp4"] = [target_values[0]]
                out["files"]["mediaprep_manifest"] = [str(pack_manifest.resolve())]
                out["stimulus_pack"] = {
                    "pack_id": manifest.get("pack_id"),
                    "scientific_status": manifest.get("scientific_status"),
                    "status_boundary": manifest.get("status_boundary"),
                    "manifest_content_sha256": manifest.get("manifest_content_sha256"),
                }
            except Exception as exc:
                out["stimulus_pack_error"] = str(exc)
        # convenience recommended files
        rec = {}
        for key in ["master_mp4", "target_video", "override_video", "control_video", "shot_order_video", "semantic_zero_video", "cue_schedule_json", "cue_schedule_csv", "locked_anchor_json", "draft_anchor_json", "stimulus_fingerprint_all", "mediaprep_manifest", "shot_order_manifest", "semantic_density_sidecar"]:
            vals = out["files"].get(key, [])
            rec[key] = vals[0] if len(vals) == 1 else None
            rec[f"{key}_status"] = "FOUND" if len(vals) == 1 else "MISSING" if not vals else "AMBIGUOUS"
        out["recommended"] = rec
        status = []
        for key in ["target_video","override_video","control_video","shot_order_video","semantic_zero_video","cue_schedule_json"]:
            status.append(f"{key}: {'FOUND' if rec.get(key) else 'MISSING'}")
        status.append(f"anchor: {'LOCKED' if rec.get('locked_anchor_json') else 'DRAFT/ESTIMATED' if rec.get('draft_anchor_json') else 'MISSING'}")
        status.append(f"stimulus_fingerprint: {'FOUND' if rec.get('stimulus_fingerprint_all') else 'MISSING'}")
        out["status_lines"] = status
        return out

    def update_stimulus_context(self, stim_id: str) -> None:
        previous_identity = self.stimulus_context_identity(self.active_context)
        folder = self.selected_stimulus_folder() if stim_id == self.selected_stimulus_id else None
        if folder is None:
            folder = Path(self.cfg["stimulus_root"]) / stim_id
        detections = self.detect_stimulus_files(folder)
        files = detections.get("files", {})
        registry_entry: Dict[str, Any] = {}
        for item in self.stimulus_registry_items():
            if item.get("stimulus_id") == stim_id:
                registry_entry = item
                break
        if (
            registry_entry.get("registry_kind") == "stimulus_pack"
            and (
                not registry_entry.get("active_for_selection")
                or detections.get("stimulus_pack_error")
                or detections.get("stimulus_pack_validation", {}).get("status") == "FAIL"
            )
        ):
            self.active_context["stimulus"] = {}
            if previous_identity:
                self.mark_session_stale_for_stimulus_change(f"stimulus pack {stim_id} became invalid")
            self.save_active_context()
            return

        def record(key: str, preferred: str = "") -> Dict[str, Any]:
            candidates = [Path(value) for value in files.get(key, [])]
            preferred_paths = [Path(preferred)] if preferred else []
            return resolution(candidates, source="STIMULUS_LIBRARY_SCAN", preferred_paths=preferred_paths)

        master = record("master_mp4", str(registry_entry.get("master_mp4") or ""))
        fingerprint_file = record("stimulus_fingerprint_all")
        manifest = record("mediaprep_manifest")
        stimulus_context = {
            "id": stim_id,
            "folder": str(folder.resolve()),
            "master_sha256": str(registry_entry.get("sha256") or ""),
            "stimulus_pack": detections.get("stimulus_pack", {}),
            "scientific_status": registry_entry.get("scientific_status") or detections.get("stimulus_pack", {}).get("scientific_status"),
            "collection_boundary": detections.get("stimulus_pack", {}).get("status_boundary"),
            "master_mp4": master,
            "mediaprep_output_root": str((folder / "mediaprep").resolve()),
            "target_video": record("target_video"),
            "override_video": record("override_video"),
            "control_video": record("control_video"),
            "cue_schedule_json": record("cue_schedule_json"),
            "cue_schedule_csv": record("cue_schedule_csv"),
            "locked_anchor_json": record("locked_anchor_json"),
            "draft_anchor_json": record("draft_anchor_json"),
            "stimulus_fingerprint_file": fingerprint_file,
            "stimulus_fingerprint_folder": str(Path(fingerprint_file["path"]).parent) if fingerprint_file.get("path") else "",
            "media_manifest_json": manifest,
        }
        selected_protocol = self.locked_protocol_record() or (self.selected_protocol_record() if hasattr(self, "protocol_select_var") else None)
        if selected_protocol and selected_protocol.get("module_family") == FAMILY_ATLAS and detections.get("stimulus_pack"):
            atlas_folder = folder.resolve()
            try:
                payload = json.loads((folder / "stimulus_pack_manifest.json").read_text(encoding="utf-8"))
                rows = [
                    row for row in payload.get("compatibility", [])
                    if isinstance(row, dict) and row.get("protocol_id") == selected_protocol.get("protocol_id")
                ]
                if len(rows) == 1:
                    directory_binding = (rows[0].get("bindings") or {}).get("emd_protocol_assets_folder")
                    if directory_binding:
                        candidate = (folder / str(directory_binding)).resolve(strict=False)
                        if path_is_within(candidate, folder) and candidate.is_dir():
                            atlas_folder = candidate
                    self.cfg.setdefault("protocol_asset_folders", {})[str(selected_protocol["protocol_id"])] = str(atlas_folder)
                    if hasattr(self, "protocol_asset_folder_var"):
                        self.protocol_asset_folder_var.set(str(atlas_folder))
                    self.save_config()
            except Exception:
                pass
        self.active_context["stimulus"] = stimulus_context
        current_identity = self.stimulus_context_identity(self.active_context)
        if previous_identity and previous_identity != current_identity:
            self.mark_session_stale_for_stimulus_change(f"selected or resolved stimulus changed to {stim_id}")
        self.save_active_context()

    def clear_stimulus_context(self) -> None:
        had_stimulus = bool(self.active_context.get("stimulus"))
        self.selected_stimulus_id = None
        self.active_context["stimulus"] = {}
        if had_stimulus:
            self.mark_session_stale_for_stimulus_change("active stimulus was cleared")
        if hasattr(self, "stim_tree"):
            self.stim_tree.selection_remove(*self.stim_tree.selection())
        self.clear_workspace_component("stimulus", "Operator cleared the active stimulus selection.")
        self.save_active_context()
        self.refresh_runner_detect_text()

    def clear_run_context(self) -> None:
        self.selected_run_folder = None
        self.active_context["run"] = {}
        self.active_context["analysis"] = {}
        if self.active_workspace:
            self.active_workspace = set_workflow_stage(
                self.active_workspace, "run", "STALE", reason="Operator cleared the active run selection; earlier run evidence was preserved."
            )
            self.save_active_workspace()
        self.save_active_context()
        if hasattr(self, "analysis_text"):
            self.analysis_text.delete("1.0", "end")
            self.analysis_text.insert("end", "No run folder selected.\n")

    def refresh_all_context(self) -> None:
        if self.selected_stimulus_id and self.selected_stimulus_folder() and self.selected_stimulus_folder().is_dir():
            self.update_stimulus_context(self.selected_stimulus_id)
        if self.selected_run_folder and self.selected_run_folder.is_dir():
            self.scan_selected_run_folder()
        else:
            if self.selected_run_folder:
                self.selected_run_folder = None
                self.active_context["run"] = {}
                self.active_context["analysis"] = {}
            self.save_active_context()

    def runner_locked_input_rows(self) -> List[Dict[str, str]]:
        """Summarize the existing governed gates without creating any new authority."""
        acquisition = self.cfg.setdefault("acquisition", {})
        selected = self.locked_protocol_record()
        rows: List[Dict[str, str]] = []

        if selected:
            protocol_label = f"{selected.get('protocol_id')} v{selected.get('protocol_version')}"
            rows.append({"key": "protocol", "label": "Protocol snapshot", "status": "PASS", "detail": f"Locked and hash-validated: {protocol_label}."})
        else:
            rows.append({"key": "protocol", "label": "Protocol snapshot", "status": "NOT PASSED", "detail": "Choose, review, and lock one protocol before arming."})

        material_status = "WAITING"
        material_detail = "Lock a protocol first; its exact material requirements will then be checked."
        if selected and selected.get("module_family") == FAMILY_ATLAS:
            try:
                snapshot, errors = self.resolve_atlas_asset_snapshot(selected)
                if errors:
                    material_status = "NOT PASSED"
                    material_detail = f"{len(errors)} required Atlas input(s) remain unresolved: {errors[0]}"
                else:
                    material_status = "PASS"
                    count = len(snapshot.get("selections", {}))
                    material_detail = f"All declared Atlas inputs are resolved and hash-bound ({count} external selection(s))."
            except Exception as exc:
                material_status = "NOT PASSED"
                material_detail = f"Atlas inputs could not be verified: {exc}"
        elif selected:
            try:
                folder = self.selected_stimulus_folder()
                if not folder or not folder.is_dir():
                    material_status = "NOT PASSED"
                    material_detail = "Select a compatible prepared stimulus in Prepare Materials."
                else:
                    detected = self.detect_stimulus_files(folder)
                    recommended = detected.get("recommended", {})
                    constraints = selected.get("module", {}).get("integrity_constraints", {})
                    required = list(constraints.get("required_media_keys", []))
                    if constraints.get("cue_schedule_required"):
                        required.append("cue_schedule_json")
                    missing = [key for key in required if recommended.get(f"{key}_status") != "FOUND"]
                    demo_reason = self.demo_only_stimulus_reason()
                    pack_error = str(detected.get("stimulus_pack_error") or "").strip()
                    if (
                        demo_reason
                        and bench_may_bypass_stimulus_reason(demo_reason)
                        and bool(acquisition.get("bench_test_mode"))
                        and not pack_error
                        and not missing
                    ):
                        material_status = "CAUTION"
                        material_detail = demo_reason + "; allowed only by the active non-participant Bench Test Mode classification."
                    elif demo_reason or pack_error or missing:
                        material_status = "NOT PASSED"
                        material_detail = demo_reason or pack_error or ("Missing or ambiguous: " + ", ".join(missing))
                    else:
                        material_status = "PASS"
                        material_detail = f"Compatible prepared materials found for {selected.get('protocol_id')}."
            except Exception as exc:
                material_status = "NOT PASSED"
                material_detail = f"Prepared materials could not be verified: {exc}"
        rows.append({"key": "materials", "label": "Stimulus / materials", "status": material_status, "detail": material_detail})

        profile = self.active_hardware_profile or {}
        if profile and self.hardware_profile_approved(profile):
            profile_id = str(profile.get("profile_id") or "unnamed profile")
            rows.append({"key": "profile", "label": "Hardware profile", "status": "PASS", "detail": f"Reviewed profile is active and identity-checked: {profile_id}."})
        elif profile:
            rows.append({"key": "profile", "label": "Hardware profile", "status": "NOT PASSED", "detail": f"The active profile is {profile.get('status') or 'not approved'}; review and lock an eligible profile."})
        else:
            rows.append({"key": "profile", "label": "Hardware profile", "status": "NOT PASSED", "detail": "Create or load a reviewed hardware profile, then lock it for launch."})

        readiness = str(acquisition.get("readiness_status") or "NOT CHECKED").upper()
        readiness_detail = str(acquisition.get("readiness_message") or "Run the required equipment checks.")
        readiness_ui = readiness if readiness in {"PASS", "CAUTION"} else ("WAITING" if readiness == "NOT CHECKED" else "NOT PASSED")
        rows.append({"key": "preflight", "label": "Live pre-arm checks", "status": readiness_ui, "detail": readiness_detail})

        lock_status = str(acquisition.get("session_lock_status") or "NOT LOCKED").upper()
        lock_ui = "PASS" if lock_status == "VALID" else "WAITING"
        lock_detail = (
            "The confirmed session setup is current and matches the locked inputs."
            if lock_status == "VALID"
            else (
                f"Confirm Session Setup after selecting the reviewed setup; live checks are diagnostic-only in Bench Test Mode (current: {lock_status.replace('_', ' ')})."
                if acquisition.get("bench_test_mode")
                else f"Confirm Session Setup after the required checks pass (current: {lock_status.replace('_', ' ')})."
            )
        )
        rows.append({"key": "session_lock", "label": "Confirmed session setup", "status": lock_ui, "detail": lock_detail})

        armed = bool(acquisition.get("armed"))
        blockers = [row["label"] for row in rows if row["status"] not in {"PASS", "CAUTION"}]
        if armed:
            arm_status = "ARMED"
            arm_detail = "All enforced gates passed and this exact session is armed. Any relevant input change disarms it."
        elif not blockers:
            arm_status = "READY TO ARM"
            arm_detail = "Required inputs and setup are current. Review any CAUTION, then choose Mark Ready to Run."
        else:
            arm_status = "WAITING"
            arm_detail = "Arming remains blocked by: " + ", ".join(blockers) + "."
        rows.append({"key": "arm", "label": "ARM state", "status": arm_status, "detail": arm_detail})
        return rows

    def refresh_runner_lock_summary(self) -> None:
        tree = getattr(self, "runner_input_tree", None)
        if tree is None:
            return
        for item in tree.get_children():
            tree.delete(item)
        rows = self.runner_locked_input_rows()
        for row in rows:
            tag = row["status"].replace(" ", "_")
            tree.insert("", "end", iid=f"runner-input::{row['key']}", text=row["label"], values=(row["status"], row["detail"]), tags=(tag,))
        arm = rows[-1]
        passed = sum(row["status"] in {"PASS", "ARMED", "READY TO ARM"} for row in rows[:-1])
        self.runner_input_overview_var.set(
            f"{passed}/{len(rows) - 1} prerequisite rows passed. {arm['detail']}"
        )

    def refresh_runner_detect_text(self) -> None:
        if not hasattr(self, "runner_detect_text"): return
        self.refresh_runner_lock_summary()
        self.runner_detect_text.delete("1.0", "end")
        selected = self.locked_protocol_record()
        if selected and selected.get("module_family") == FAMILY_ATLAS:
            media_snapshot, errors = self.resolve_atlas_asset_snapshot(selected)
            module = selected.get("module", {})
            compiled_preview: Dict[str, Any] = {}
            try:
                compiled_preview = atlas_runtime_plan(selected, participant_id="PREVIEW", session_index=1)
            except Exception as exc:
                errors.append(f"timeline compilation: {exc}")
            external_contracts = [
                item for item in module.get("assets", [])
                if isinstance(item, dict) and item.get("source") == "operator_selection"
            ]
            lines = [
                f"Atlas module: {selected.get('display_name')}",
                f"Engine family: {selected.get('engine_family')}",
                "Hardware selection: independent; this module cannot change the Acquisition profile",
                f"Asset folder: {media_snapshot.get('stimulus_folder') or 'not selected'}",
            ]
            for contract in external_contracts:
                key = str(contract.get("key") or "")
                resolved = media_snapshot.get("atlas_asset_snapshot", {}).get(key, {})
                state = "READY" if resolved else ("MISSING" if contract.get("required") else "OPTIONAL / NOT BOUND")
                lines.append(f"{key}: {state}")
            timeline = compiled_preview.get("timeline", []) if isinstance(compiled_preview, dict) else []
            if timeline:
                lines.append(f"Compiled preview: {len(timeline)} node instance(s); sequence {compiled_preview.get('sequence_id')}; seed recorded at session lock")
                lines.append("Timeline: " + " -> ".join(str(node.get("id")) for node in timeline if isinstance(node, dict)))
            lines.append("Readiness: " + ("INELIGIBLE" if errors else "PASS FOR DESIGN/ASSET LOCK"))
            if errors:
                lines.append("Reasons:\n- " + "\n- ".join(errors))
            lines.append("\nExternal asset snapshot:\n" + json.dumps(media_snapshot.get("atlas_asset_snapshot", {}), indent=2))
            lines.append("\nBoundary: Atlas dry-run and asset readiness do not validate PsychoPy timing, hardware acquisition, cortical origin, or scientific construct validity.")
            self.runner_detect_text.insert("end", "\n".join(lines) + "\n")
            return
        folder = self.selected_stimulus_folder()
        if not folder:
            self.runner_detect_text.insert("end", "No stimulus selected. Native PRAYCG modules require a compatible prepared entry from Prepare Materials.\n")
            return
        det = self.detect_stimulus_files(folder)
        if selected:
            module = selected.get("module", {})
            required_keys = module.get("integrity_constraints", {}).get("required_media_keys", [])
            status_lines = [
                f"{key}: {det['recommended'].get(f'{key}_status', 'MISSING')}"
                for key in required_keys
            ]
            if module.get("integrity_constraints", {}).get("cue_schedule_required"):
                status_lines.append(f"cue_schedule_json: {det['recommended'].get('cue_schedule_json_status', 'MISSING')}")
            status_lines.append(
                "anchor: "
                + ("LOCKED" if det["recommended"].get("locked_anchor_json") else "DRAFT/ESTIMATED" if det["recommended"].get("draft_anchor_json") else "MISSING")
            )
        else:
            status_lines = det["status_lines"]
        self.runner_detect_text.insert("end", "\n".join(status_lines) + "\n\n")
        self.runner_detect_text.insert("end", json.dumps(det["recommended"], indent=2))
        if selected:
            branch_order = " -> ".join(selected.get("branch_order", []))
            self.runner_detect_text.insert(
                "end",
                f"\n\nSelected module: {selected.get('protocol_id')} v{selected.get('protocol_version')}\n"
                f"Locked branch order: {branch_order}\n"
                "Only inputs declared by the selected module are authoritative. Review unresolved files in the runner preflight; never substitute missing inputs silently.\n",
            )
        else:
            self.runner_detect_text.insert("end", "\n\nSelect and lock a protocol module before launch.\n")

    # Launchers
    @staticmethod
    def context_record_path(section: Dict[str, Any], key: str) -> str:
        record = section.get(key, {})
        return str(record.get("path") or "") if isinstance(record, dict) and record.get("status") == "RESOLVED" else ""

    @staticmethod
    def add_arg(args: List[str], flag: str, value: Any) -> None:
        raw = str(value or "").strip()
        if raw:
            args.extend([flag, raw])

    def launch_mediaprep(self) -> None:
        if not self.require_tool_ready("mediaprep", "MediaPrep is not ready"):
            return
        path = self.cfg["tools"].get("mediaprep_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set MediaPrep GUI path in Settings.")
            return
        stimulus = self.active_context.get("stimulus", {})
        args: List[str] = []
        self.add_arg(args, "--master", self.context_record_path(stimulus, "master_mp4"))
        self.add_arg(args, "--out-root", stimulus.get("mediaprep_output_root"))
        self.add_arg(args, "--project-name", stimulus.get("id"))
        self.launch_python_or_exe("MediaPrep Suite", path, args=args)

    def launch_master_suite(self) -> None:
        if not self.require_tool_ready("master_suite", "Master Suite is not ready"):
            return
        path = self.cfg["tools"].get("master_suite_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Master Suite GUI path in Settings.")
            return
        run = self.active_context.get("run", {})
        stimulus = self.active_context.get("stimulus", {})
        args: List[str] = []
        self.add_arg(args, "--project-name", run.get("label"))
        self.add_arg(args, "--xdf", self.context_record_path(run, "xdf"))
        self.add_arg(args, "--event-log", self.context_record_path(run, "events"))
        self.add_arg(args, "--channel-map", self.context_record_path(run, "channel_map"))
        cue_json = self.context_record_path(run, "cue_schedule_json") or self.context_record_path(stimulus, "cue_schedule_json")
        anchor = self.context_record_path(run, "predeclared_anchor_file") or self.context_record_path(stimulus, "locked_anchor_json")
        self.add_arg(args, "--cue-schedule-json", cue_json)
        self.add_arg(args, "--cue-schedule-csv", self.context_record_path(stimulus, "cue_schedule_csv"))
        self.add_arg(args, "--media-manifest-json", self.context_record_path(stimulus, "media_manifest_json"))
        self.add_arg(args, "--predeclared-anchor-file", anchor)
        self.add_arg(args, "--stimulus-fingerprint-folder", stimulus.get("stimulus_fingerprint_folder"))
        self.add_arg(args, "--out-root", self.cfg.get("analysis_root"))
        self.add_arg(args, "--control-context-file", self.context_path)
        self.launch_python_or_exe("Master Comprehensive Suite", path, args=args)

    def launch_master_chain(self) -> None:
        if not self.require_tool_ready("chain", "Full chained analysis is not ready"):
            return
        path = self.cfg["tools"].get("master_chain_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Full v1.6.1 Chain GUI path in Settings.")
            return
        core = self.active_context.get("analysis", {}).get("core", {}).get("path", "")
        run_label = self.active_context.get("run", {}).get("label", "")
        args: List[str] = []
        self.add_arg(args, "--analysis-folder", core)
        self.add_arg(args, "--run-label", run_label)
        self.launch_python_or_exe("Master Comprehensive Chained Analysis v1.6.1", path, args=args)

    def exploratory_analysis_folder(self) -> str:
        analysis = self.active_context.get("analysis", {})
        for candidate in [
            analysis.get("preferred_review_folder"),
            analysis.get("chain", {}).get("path"),
            analysis.get("core", {}).get("path"),
        ]:
            if candidate and Path(str(candidate)).is_dir():
                return str(Path(str(candidate)).resolve())
        return str(self.selected_run_folder.resolve()) if self.selected_run_folder and self.selected_run_folder.is_dir() else ""

    def exploratory_output_folder(self) -> Path:
        run_label = slugify(self.active_context.get("run", {}).get("label") or "selected_run")
        return Path(self.cfg["analysis_root"]) / run_label / "Exploratory_CAISID_v0_2"

    def run_cai_readiness_preflight(self) -> None:
        if not self.selected_run_folder or not self.selected_run_folder.is_dir():
            messagebox.showwarning("Run folder required", "Select a PRAYCG run folder before the CAI/SID readiness preflight.")
            return
        path = self.cfg["tools"].get("cai_readiness_preflight", "")
        args = ["--run-folder", str(self.selected_run_folder), "--out", str(self.exploratory_output_folder() / "readiness")]
        self.add_arg(args, "--analysis-folder", self.exploratory_analysis_folder())
        self.launch_python_or_exe("CAI/SID v0.2 Readiness Preflight", path, args=args)

    def launch_cai_sid_exploratory(self) -> None:
        if not self.selected_run_folder or not self.selected_run_folder.is_dir():
            messagebox.showwarning("Run folder required", "Select a PRAYCG run folder before launching exploratory CAI/SID.")
            return
        path = self.cfg["tools"].get("cai_sid_exploratory_gui", "")
        args = ["--run-folder", str(self.selected_run_folder)]
        self.add_arg(args, "--analysis-folder", self.exploratory_analysis_folder())
        self.add_arg(args, "--control-context-file", self.context_path)
        self.launch_python_or_exe("Exploratory CAI/SID v0.2", path, args=args)

    def launch_continuous_autonomic(self) -> None:
        if not self.selected_run_folder or not self.selected_run_folder.is_dir():
            messagebox.showwarning("Run folder required", "Select a recorded run folder before launching continuous autonomic analysis.")
            return
        path = self.cfg["tools"].get("continuous_autonomic_gui", "")
        self.launch_python_or_exe("Continuous Autonomic / RespDualPath v1.0", path, args=["--gui", "--run-folder", str(self.selected_run_folder)])

    def launch_prospective_study_console(self) -> None:
        path = self.cfg["tools"].get("prospective_study_console", "")
        args: List[str] = []
        self.add_arg(args, "--control-context-file", self.context_path)
        self.launch_python_or_exe("Prospective Study Console v0.1", path, args=args)

    def launch_protocol_ai_doc_builder(self) -> None:
        """Create a documentation-only custom-protocol package for AI-assisted development."""
        path = self.cfg.get("tools", {}).get("protocol_ai_doc_builder", "")
        output_root = Path(
            str(self.cfg.get("custom_protocol_draft_root") or Path(self.cfg["praycg_home"]) / "protocol_design_drafts")
        ).expanduser()
        self.launch_python_or_exe(
            "Protocol AI Docs Builder v0.1",
            path,
            args=["--output-root", str(output_root)],
        )

    def micro_handoff_output_folder(self) -> Path:
        run_label = slugify(self.active_context.get("run", {}).get("label") or "selected_run")
        return Path(self.cfg["analysis_root"]) / run_label / "Exploratory_MicroHandoff_v0_1"

    def launch_micro_handoff(self) -> None:
        if not self.selected_run_folder or not self.selected_run_folder.is_dir():
            messagebox.showwarning("Run folder required", "Select a recorded PRAYCG run folder before launching Micro Handoff v0.1.")
            return
        path = self.cfg["tools"].get("micro_handoff_gui", "")
        args = [
            "--gui",
            "--run-folder", str(self.selected_run_folder),
            "--out", str(self.micro_handoff_output_folder()),
        ]
        self.add_arg(args, "--analysis-folder", self.exploratory_analysis_folder())
        run = self.active_context.get("run", {})
        self.add_arg(args, "--xdf", self.context_record_path(run, "xdf"))
        self.launch_python_or_exe("Micro Handoff v0.1 — Exploratory", path, args=args)

    def launch_cue_locked_gamma_forensics(self) -> None:
        path = self.cfg["tools"].get("cue_locked_gamma_forensics", "")
        args: List[str] = []
        if self.selected_run_folder and self.selected_run_folder.is_dir():
            self.add_arg(args, "--data-audit", self.selected_run_folder)
        self.add_arg(args, "--out", Path(self.cfg["analysis_root"]) / "Exploratory_CueLockedGammaForensics_v0_1")
        self.launch_python_or_exe("Cue-Locked Gamma Forensics v0.1 — Exploratory Confound Extension", path, args=args)

    def launch_stimulus_library(self) -> None:
        path = self.cfg.get("tools", {}).get("stimulus_library", "")
        selected = self.locked_protocol_record() or {}
        args = [
            "--gui",
            "--install-root", str(Path(self.cfg["stimulus_pack_install_root"]).expanduser()),
            "--stimulus-root", str(Path(self.cfg["stimulus_root"]).expanduser()),
            "--registry", str(Path(self.cfg["stimulus_registry"]).expanduser()),
        ]
        protocol_id = str(selected.get("protocol_id") or "").strip()
        if protocol_id:
            args.extend(["--protocol", protocol_id])
        self.launch_python_or_exe(
            "Stimulus Library v1.0",
            path,
            args=args,
        )

    def launch_stimulus_forge(self) -> None:
        path = self.cfg.get("tools", {}).get("stimulus_forge", "")
        locked = self.locked_protocol_record() or {}
        protocol_id = str(locked.get("protocol_id") or "")
        self.launch_python_or_exe(
            "Stimulus Forge v1.0",
            path,
            args=[
                "--gui",
                "--output-root", str(Path(self.cfg["stimulus_root"]).expanduser() / "forge_outputs"),
            ] + (["--protocol", protocol_id] if protocol_id else []),
        )

    def launch_stimulus_forge_for_engine(self, engine_id: str, allowed_engines: Tuple[str, ...] = ()) -> None:
        """Open the Forge already narrowed to the locked protocol's direct engines."""
        if not self.locked_protocol:
            messagebox.showinfo("Protocol lock required", "Lock a protocol before opening its preparation engine.")
            return
        path = self.cfg.get("tools", {}).get("stimulus_forge", "")
        locked = self.locked_protocol_record() or {}
        args = [
            "--gui",
            "--output-root", str(Path(self.cfg["stimulus_root"]).expanduser() / "forge_outputs"),
            "--protocol", str(locked.get("protocol_id") or ""),
            "--prefill-engine", str(engine_id),
        ]
        if allowed_engines:
            args.extend(["--allowed-engines", ",".join(allowed_engines)])
        self.launch_python_or_exe(f"Stimulus Forge — {engine_id}", path, args=args)

    def launch_hardware_forge(self) -> None:
        path = self.cfg.get("tools", {}).get("hardware_forge", "")
        self.launch_python_or_exe("Hardware Forge v1.0 — Adapter Workbench", path, args=["gui"])

    def launch_generic_lsl_intake(self) -> None:
        path = self.cfg.get("tools", {}).get("generic_lsl_intake", "")
        self.launch_python_or_exe("Generic Existing-LSL Intake v1.0", path, args=["gui"])

    def launch_generic_eda_ppg_profile_wizard(self) -> None:
        """Collect the small set of transport fields needed to write non-approved drafts."""
        path = self.cfg.get("tools", {}).get("generic_eda_ppg_profile_wizard", "")
        use_udp = messagebox.askyesnocancel(
            "Generic EDA/PPG draft",
            "Which typed transport should this draft describe?\n\n"
            "Yes — UDP JSON datagrams\n"
            "No — serial JSON lines\n\n"
            "The result is a non-approved draft. It cannot arm or acquire a participant session.",
            parent=self,
        )
        if use_udp is None:
            return
        transport = "udp" if use_udp else "serial"
        profile_id = simpledialog.askstring(
            "Draft identifier",
            "Enter a short profile identifier (for example, eda_ppg_device_a):",
            parent=self,
        )
        if not profile_id or not profile_id.strip():
            return
        device_identity = simpledialog.askstring(
            "Device identity",
            "Enter the exact device/model identity being mapped. Do not use a participant name:",
            parent=self,
        )
        if not device_identity or not device_identity.strip():
            return
        acquisition = self.cfg.setdefault("acquisition", {})
        draft_root = Path(
            str(acquisition.get("generic_eda_ppg_draft_root") or Path(self.cfg["praycg_home"]) / "config" / "hardware_profile_drafts" / "generic_eda_ppg")
        ).expanduser()
        selected_out = filedialog.askdirectory(
            title="Choose a folder for the non-approved EDA/PPG drafts",
            initialdir=str(draft_root),
            mustexist=False,
        )
        if not selected_out:
            return
        args = [
            "--transport", transport,
            "--profile-id", profile_id.strip(),
            "--device-identity", device_identity.strip(),
            "--out-dir", selected_out,
        ]
        if transport == "serial":
            port = simpledialog.askstring(
                "Serial connection",
                "Enter the exact serial port (for example, COM6):",
                parent=self,
            )
            if not port or not port.strip():
                return
            baud = simpledialog.askinteger(
                "Serial speed",
                "Enter the baud rate:",
                initialvalue=115200,
                minvalue=1200,
                parent=self,
            )
            if baud is None:
                return
            args.extend(["--serial-port", port.strip(), "--baud", str(baud)])
        else:
            udp_port = simpledialog.askinteger(
                "UDP input",
                "Enter the local UDP port:",
                initialvalue=18995,
                minvalue=1024,
                maxvalue=65535,
                parent=self,
            )
            if udp_port is None:
                return
            args.extend(["--bind-host", "127.0.0.1", "--udp-port", str(udp_port)])
        acquisition["generic_eda_ppg_draft_root"] = str(Path(selected_out).expanduser())
        self.save_config()
        self.launch_python_or_exe("Generic EDA/PPG Draft Profile Wizard v0.1", path, args=args)
        messagebox.showinfo(
            "Draft generation started",
            "Two draft files will be written: a driver profile and a hardware-module definition. "
            "They remain non-approved until their packet map, units, rates, physical behavior, and admission evidence are reviewed.",
            parent=self,
        )

    def launch_generic_eda_ppg_simulator(self) -> None:
        """Start a bounded synthetic source and companion LSL bridge for software testing."""
        simulator_path = self.cfg.get("tools", {}).get("generic_eda_ppg_simulator", "")
        bridge_path = self.cfg.get("tools", {}).get("generic_eda_ppg_bridge", "")
        profile_path = (
            self.pkg.parent
            / "tools" / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1"
            / "config" / "generic_eda_ppg_udp_SIMULATOR_v0_1.json"
        ).resolve()
        if not profile_path.is_file():
            messagebox.showerror("Simulator profile missing", f"The packaged simulator profile was not found:\n{profile_path}")
            return
        simulation_uuid = str(uuid.uuid4())
        output_root = Path(self.cfg["log_root"]) / "hardware_simulation" / simulation_uuid
        bridge_args = [
            "bridge", "--profile", str(profile_path), "--transport", "udp",
            "--run-uuid", simulation_uuid, "--duration", "31", "--out-dir", str(output_root / "bridge"),
        ]
        simulator_args = [
            "--profile", str(profile_path), "--run-uuid", simulation_uuid,
            "--duration", "30", "--out-dir", str(output_root / "source"),
        ]
        self.launch_python_or_exe("SYNTHETIC EDA/PPG LSL Bridge v0.1", bridge_path, args=bridge_args)
        self.after(
            500,
            lambda: self.launch_python_or_exe(
                "SYNTHETIC EDA/PPG UDP Source v0.1", simulator_path, args=simulator_args
            ),
        )
        messagebox.showinfo(
            "Synthetic test started",
            f"A 30-second synthetic EDA/PPG transport test is starting.\n\nEvidence folder:\n{output_root}\n\n"
            "SYNTHETIC_ outlets and their output are software fixtures only; they are not participant data or physical-device validation.",
            parent=self,
        )

    def launch_generic_eda_ppg(self) -> None:
        """Launch only an admission-approved physical route bound to its reviewed driver hash."""
        if not self.platform_core_available():
            return
        profile = self.active_hardware_profile or {}
        raw_profile_path = str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "").strip()
        profile_path = Path(raw_profile_path).expanduser() if raw_profile_path else Path()
        if not raw_profile_path or not profile_path.is_file():
            messagebox.showerror(
                "Reviewed hardware profile required",
                "The active Generic EDA/PPG route must come from a saved reviewed hardware profile.",
            )
            return
        try:
            identity_report = validate_hardware_profile_identity(  # type: ignore[misc]
                profile,
                profile_path=profile_path,
            )
        except Exception as exc:
            messagebox.showerror("Hardware profile validation failed", str(exc))
            return
        if not self.hardware_profile_approved(profile) or identity_report.status == "INELIGIBLE":
            details = list(getattr(identity_report, "errors", []) or [])
            messagebox.showerror(
                "Hardware profile is not eligible",
                "Physical EDA/PPG launch was blocked because the saved profile identity or its bound module identity is invalid."
                + (("\n\n- " + "\n- ".join(map(str, details))) if details else ""),
            )
            return
        candidates = [
            module for module in profile.get("modules", [])
            if str(module.get("module_id") or "") in {"generic_eda_ppg_serial", "generic_eda_ppg_udp"}
        ]
        if len(candidates) != 1:
            messagebox.showerror(
                "Approved EDA/PPG route required",
                "The active hardware profile must contain exactly one reviewed generic_eda_ppg_serial or "
                "generic_eda_ppg_udp module.",
            )
            return
        selected_module = candidates[0]
        if (
            selected_module.get("admission_state") != "HUMAN_CONNECTED_APPROVED"
            or selected_module.get("physical_validation") != "HUMAN_CONNECTED"
        ):
            messagebox.showerror(
                "Physical launch withheld",
                "This adapter has not reached HUMAN_CONNECTED_APPROVED. Catalog, simulator, and bench evidence cannot be treated as "
                "approval to collect participant data.",
            )
            return
        expected_hash = str(selected_module.get("driver_profile_sha256") or "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected_hash):
            messagebox.showerror(
                "Driver identity missing",
                "The reviewed hardware module does not bind a lowercase SHA-256 identity for its driver profile. "
                "Promote a corrected module definition before launch.",
            )
            return
        acquisition = self.cfg.setdefault("acquisition", {})
        raw_driver = str(acquisition.get("generic_eda_ppg_driver_profile_path") or "").strip()
        driver_path = Path(raw_driver).expanduser() if raw_driver else Path()
        if not raw_driver or not driver_path.is_file():
            chosen = filedialog.askopenfilename(
                title="Select the reviewed Generic EDA/PPG driver profile",
                filetypes=(("JSON", "*.json"), ("All", "*.*")),
            )
            if not chosen:
                return
            driver_path = Path(chosen).expanduser().resolve()
        try:
            driver = json.loads(driver_path.read_text(encoding="utf-8"))
        except Exception as exc:
            messagebox.showerror("Driver profile unreadable", str(exc))
            return
        module_id = str(selected_module.get("module_id") or "")
        transport = "serial" if module_id.endswith("_serial") else "udp"
        problems: List[str] = []
        if driver.get("schema") != "PRAYCG_GenericEDAPPGDriverProfile_v0_1":
            problems.append("unsupported driver-profile schema")
        if driver.get("status") != "REVIEWED_DRIVER_PROFILE" or driver.get("synthetic") is not False:
            problems.append("profile is not a reviewed, non-synthetic driver profile")
        if str(driver.get("transport", {}).get("kind") or "") != transport:
            problems.append(f"driver transport does not match {module_id}")
        actual_hash = sha256_file(driver_path)
        if actual_hash != expected_hash:
            problems.append("driver-profile SHA-256 does not match the reviewed hardware module")
        if problems:
            messagebox.showerror("Driver profile is not eligible", "Launch was blocked:\n\n- " + "\n- ".join(problems))
            return
        run_uuid = self.active_run_uuid or self.begin_acquisition_session()
        if not run_uuid:
            return
        acquisition["generic_eda_ppg_driver_profile_path"] = str(driver_path)
        self.save_config()
        session_root = Path(str(acquisition.get("session_artifact_root") or self.cfg["log_root"]))
        bridge_path = self.cfg.get("tools", {}).get("generic_eda_ppg_bridge", "")
        self.launch_python_or_exe(
            "Generic EDA/PPG → LSL v0.1",
            bridge_path,
            args=[
                "bridge", "--profile", str(driver_path), "--transport", transport,
                "--run-uuid", run_uuid, "--out-dir", str(session_root / "generic_eda_ppg"),
            ],
        )

    def launch_analysis_module_catalog(self) -> None:
        path = self.cfg.get("tools", {}).get("analysis_module_catalog", "")
        args = ["--gui"]
        if self.selected_run_folder and self.selected_run_folder.is_dir():
            args.extend(["--run-folder", str(self.selected_run_folder.resolve())])
        self.launch_python_or_exe("Analysis Module Catalog v0.1", path, args=args)

    def launch_release_validator(self) -> None:
        path = self.cfg["tools"].get("release_validator", "")
        self.launch_python_or_exe("PRAYCG Release Validator v0.1", path, args=["--package", str(self.pkg.parent)])

    def open_package_config_file(self, *names: str) -> None:
        for name in names:
            candidate = self.pkg.parent / "config" / name
            if candidate.is_file():
                open_path(candidate)
                return
        messagebox.showwarning("Configuration file missing", "None of the requested package configuration files were found:\n\n" + "\n".join(names))

    def open_bids_export_dialog(self) -> None:
        existing = getattr(self, "bids_export_window", None)
        if existing is not None and existing.winfo_exists():
            existing.lift()
            existing.focus_force()
            return None
        win = tk.Toplevel(self)
        self.bids_export_window = win
        win.title("PRAYCG BIDS Export / Verify")
        win.geometry("900x600")
        win.transient(self)
        run = self.active_context.get("run", {})
        run_folder = str(run.get("folder") or (self.selected_run_folder or ""))
        run_label = slugify(run.get("label") or (Path(run_folder).name if run_folder else "selected_run"))
        export_default = Path(self.cfg["analysis_root"]) / run_label / "BIDS_Export"
        run_var = tk.StringVar(value=run_folder)
        out_var = tk.StringVar(value=str(export_default))
        events_value = self.context_record_path(run, "events")
        events_var = tk.StringVar(value=events_value if events_value.lower().endswith(".csv") else "")
        xdf_var = tk.StringVar(value=self.context_record_path(run, "xdf"))
        physio_var = tk.StringVar()
        rr_var = tk.StringVar()
        subject_var = tk.StringVar(value="001")
        session_var = tk.StringVar(value="01")
        task_var = tk.StringVar(value="praycg")
        frame = ttk.Frame(win); frame.pack(fill="both", expand=True, padx=10, pady=8)

        def add_path_row(row: int, label: str, variable: tk.StringVar, folder: bool = False, kinds=None) -> None:
            ttk.Label(frame, text=label, width=23).grid(row=row, column=0, sticky="w", padx=4, pady=3)
            ttk.Entry(frame, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=4, pady=3)
            def browse() -> None:
                value = filedialog.askdirectory(title=f"Select {label}") if folder else filedialog.askopenfilename(
                    title=f"Select {label}", filetypes=kinds or (("All", "*.*"),)
                )
                if value:
                    variable.set(value)
            ttk.Button(frame, text="Browse", command=browse).grid(row=row, column=2, padx=4, pady=3)

        add_path_row(0, "Source run folder", run_var, folder=True)
        add_path_row(1, "Export output folder", out_var, folder=True)
        add_path_row(2, "Events CSV (optional)", events_var, kinds=(("CSV", "*.csv"), ("All", "*.*")))
        add_path_row(3, "Regular physiology CSV", physio_var, kinds=(("CSV", "*.csv"), ("All", "*.*")))
        add_path_row(4, "Irregular RR-event CSV", rr_var, kinds=(("CSV", "*.csv"), ("All", "*.*")))
        add_path_row(5, "Source XDF (optional)", xdf_var, kinds=(("XDF", "*.xdf"), ("All", "*.*")))
        ids = ttk.LabelFrame(frame, text="De-identified BIDS labels")
        ids.grid(row=6, column=0, columnspan=3, sticky="ew", padx=4, pady=6)
        for index, (label, variable) in enumerate((("Subject", subject_var), ("Session", session_var), ("Task", task_var))):
            ttk.Label(ids, text=label).grid(row=0, column=index * 2, padx=(6, 2), pady=5)
            ttk.Entry(ids, textvariable=variable, width=18).grid(row=0, column=index * 2 + 1, padx=(2, 8), pady=5)
        ttk.Label(
            frame,
            text=(
                "Export is a standards-facing derivative, not a replacement for the source XDF. Do not enter names, emails, dates of birth, "
                "or other direct identifiers. RR events are not silently resampled."
            ),
            foreground="#7a1e1e",
            wraplength=820,
        ).grid(row=7, column=0, columnspan=3, sticky="w", padx=4, pady=5)
        output = tk.Text(frame, height=8, wrap="word")
        output.grid(row=8, column=0, columnspan=3, sticky="nsew", padx=4, pady=5)
        frame.columnconfigure(1, weight=1)
        frame.rowconfigure(8, weight=1)

        def launch(dry_run: bool) -> None:
            source = Path(run_var.get()).expanduser()
            target = Path(out_var.get()).expanduser()
            if not source.is_dir():
                messagebox.showerror("Run folder required", "Select an existing source run folder.", parent=win)
                return
            if not str(target):
                messagebox.showerror("Output required", "Select an export output folder.", parent=win)
                return
            subject = slugify(subject_var.get(), "001")
            session = slugify(session_var.get(), "01")
            task = slugify(task_var.get(), "praycg")
            args = ["--run-folder", str(source.resolve()), "--out", str(target.resolve()), "--subject", subject, "--session", session, "--task", task]
            for flag, value in (("--events-csv", events_var.get()), ("--physio-csv", physio_var.get()), ("--rr-csv", rr_var.get()), ("--xdf", xdf_var.get())):
                value = value.strip()
                if value:
                    path = Path(value).expanduser()
                    if not path.is_file():
                        messagebox.showerror("Input missing", f"Optional input was supplied but does not exist:\n{path}", parent=win)
                        return
                    args.extend([flag, str(path.resolve())])
            if dry_run:
                args.append("--dry-run")
            self.cfg.setdefault("export", {})["latest_bids_export"] = str(target.resolve())
            self.save_config()
            self.launch_python_or_exe(
                "BIDS Export Dry Run" if dry_run else "BIDS Export and Verification Report",
                self.cfg["tools"].get("bids_exporter", ""),
                args=args,
            )
            output.configure(state="normal")
            output.delete("1.0", "end")
            output.insert(
                "end",
                ("Dry-run plan launched." if dry_run else "Export launched.")
                + f"\n\nOutput: {target.resolve()}\n"
                + "Use Running Tools on the Dashboard to inspect completion and logs. The exporter writes praycg_export_report.json.",
            )
            output.configure(state="disabled")

        actions = ttk.Frame(frame); actions.grid(row=9, column=0, columnspan=3, sticky="ew", padx=4, pady=5)
        ttk.Button(actions, text="Dry-Run Export Plan", command=lambda: launch(True)).pack(side="left", padx=3)
        ttk.Button(actions, text="Export + Write Verification Report", command=lambda: launch(False)).pack(side="left", padx=3)
        ttk.Button(actions, text="Open Output Folder", command=lambda: open_path(Path(out_var.get()).expanduser())).pack(side="right", padx=3)

    def open_latest_bids_export(self) -> None:
        value = str(self.cfg.get("export", {}).get("latest_bids_export") or "").strip()
        if not value:
            messagebox.showinfo("No export yet", "Prepare a BIDS export first.")
            return
        open_path(Path(value).expanduser())




    def launch_als_barcode_detector(self) -> None:
        if not self.require_tool_ready("als_barcode", "ALS Barcode Detector is not ready"):
            return
        run = self.active_context.get("run", {})
        args: List[str] = []
        self.add_arg(args, "--folder", run.get("folder"))
        self.add_arg(args, "--xdf", self.context_record_path(run, "xdf"))
        events_path = self.context_record_path(run, "events")
        if events_path.lower().endswith(".json"):
            self.add_arg(args, "--events-json", events_path)
        self.launch_python_tool("ALS Barcode Detector v1.5.8", "als_barcode_detector", args)

    def launch_mediaprep_barcode_backup(self) -> None:
        path = self.cfg["tools"].get("mediaprep_barcode_backup", "")
        if not path or not Path(path).expanduser().exists():
            messagebox.showwarning("Path missing", "Set MediaPrep barcode backup script path in Settings or click Use Bundled Paths.")
            return
        self.launch_python_or_exe("MediaPrep ALS Barcode Backup", path)

    def launch_confound_expanded(self) -> None:
        if not self.require_tool_ready("confounds", "Confound modules are not ready"):
            return
        path = self.cfg["tools"].get("confound_expanded_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Confound Expansion Module path in Settings.")
            return
        analysis = self.active_context.get("analysis", {})
        run = self.active_context.get("run", {})
        stimulus = self.active_context.get("stimulus", {})
        args = ["--gui"]
        self.add_arg(args, "--analysis-folder", analysis.get("core", {}).get("path", ""))
        self.add_arg(args, "--run-log-folder", run.get("folder"))
        self.add_arg(args, "--stimulus-fingerprint-folder", stimulus.get("stimulus_fingerprint_folder"))
        self.launch_python_or_exe("Confound Expansion Modules", path, args=args)

    def launch_shot_order_scramble(self) -> None:
        path = self.cfg["tools"].get("shot_order_scramble", "")
        if not path or not Path(path).expanduser().exists():
            messagebox.showwarning("Path missing", "Set Shot-Order Scramble script path in Settings or click Use Bundled Paths.")
            return
        self.launch_python_or_exe("Shot-Order Scramble Generator v1.9", path)

    def run_als_holder_calibration(self) -> None:
        args = ["--stream-name", self.cfg.get("lsl", {}).get("als_stream_name", "ALS_PT19_Timing"),
                "--channel-index", str(self.cfg.get("lsl", {}).get("als_channel_index_1based", 1)),
                "--out", str(Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json")]
        self.launch_python_tool("ALS Holder Calibration v0.8", "als_holder_calibration", args)

    def launch_hocr_shotorder(self) -> None:
        if not self.require_tool_ready("hocr", "HOC-R is not ready"):
            return
        core = self.active_context.get("analysis", {}).get("core", {}).get("path", "")
        self.launch_python_tool("HOC-R ShotOrder Module v1.6.0", "hocr_shotorder", ["--analysis-folder", core])

    def launch_visualizer(self) -> None:
        if not self.require_tool_ready("visualizer", "Visualizer is not ready"):
            return
        path = self.cfg["tools"].get("visualizer_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Visualizer GUI/script path in Settings.")
            return
        analysis = self.active_context.get("analysis", {})
        run = self.active_context.get("run", {})
        stimulus = self.active_context.get("stimulus", {})
        args = ["--gui"]
        self.add_arg(args, "--analysis-out", analysis.get("preferred_review_folder"))
        self.add_arg(args, "--xdf", self.context_record_path(run, "xdf"))
        self.add_arg(args, "--events", self.context_record_path(run, "events"))
        video = self.context_record_path(run, "target_video") or self.context_record_path(stimulus, "target_video")
        self.add_arg(args, "--video", video)
        export_name = f"{slugify(run.get('label') or 'PRAYCG_Run')}_MasterSync_v1_4_0.mp4"
        self.add_arg(args, "--out", Path(self.cfg["analysis_root"]) / "visualizer_exports" / export_name)
        self.launch_python_or_exe("Master Sync Visualizer", path, args=args)

    def launch_offline_interpreter(self) -> None:
        if not self.require_tool_ready("interpreter", "Interpreter is not ready"):
            return
        path = self.cfg["tools"].get("offline_interpreter_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Offline Interpreter GUI path in Settings.")
            return
        analysis = self.active_context.get("analysis", {})
        args: List[str] = []
        self.add_arg(args, "--analysis-folder", analysis.get("preferred_review_folder"))
        self.add_arg(args, "--run-label", self.active_context.get("run", {}).get("label"))
        self.launch_python_or_exe("Offline Interpreter", path, args=args)

    def launch_python_or_exe(self, label: str, path: str, args: Optional[List[str]]=None) -> Optional[RunningProcess]:
        p = normalized_path(path)
        if not p.is_file():
            messagebox.showerror("Path not found", f"Path not found for {label}:\n{p}")
            return None
        if p.suffix.lower() in {".py", ".pyw"}:
            return self.launch_process(label, self.get_python_cmd() + [str(p)] + (args or []), cwd=p.parent)
        return self.launch_process(label, windows_bat_command(p, args), cwd=p.parent)

    def launch_polar(self) -> None:
        run_uuid = self.active_run_uuid or self.begin_acquisition_session()
        if not run_uuid:
            return
        self.launch_python_tool("Polar H10 RR -> LSL", "polar_h10", ["--run-uuid", run_uuid])

    def launch_vernier(self, connection: str) -> None:
        self.launch_python_tool(f"Vernier Respiration {connection.upper()} -> LSL", "vernier_resp", ["--connection", connection])

    def prepare_openbci_bridge_launch(self, label: str, port: str, run_uuid: str) -> bool:
        """Recover a COM port held by an older packaged PRAYCG bridge."""
        selected_port = str(port or "").strip().upper()
        rows = [
            row for row in discover_external_openbci_bridges()
            if str(row.get("serial_port") or "").upper() == selected_port
        ]
        if not rows:
            return True
        current = [row for row in rows if str(row.get("run_uuid") or "") == str(run_uuid or "")]
        needs_als = "ALS" in str(label or "").upper()
        compatible = [
            row for row in current
            if not needs_als or str(row.get("script_name") or "") == OPENBCI_ALS_BRIDGE_SCRIPT_NAME
        ]
        if compatible:
            row = compatible[0]
            messagebox.showinfo(
                "Equipment bridge already running",
                f"A PRAYCG OpenBCI bridge is already streaming from {selected_port} for this equipment session "
                f"(PID {row['pid']}).\n\nA second copy was not started. You can proceed to Live Checks.",
            )
            return False
        details = "\n".join(
            f"- PID {row['pid']} | session {row.get('run_uuid') or 'not declared'} | {row.get('script_name')}"
            for row in rows
        )
        if not messagebox.askyesno(
            "Restart the incompatible equipment bridge?",
            f"{selected_port} is still owned by a packaged PRAYCG OpenBCI bridge that is either from an earlier "
            "equipment session or does not publish the ALS outlet required by this action. That is why the ALS barcode "
            "check can report a session mismatch/missing stream or a replacement bridge can say the board is in use.\n\n"
            f"Running bridge(s):\n{details}\n\n"
            f"Stop the old bridge and restart {label} for the current equipment session?",
        ):
            self.hardware_launch_status_var.set(
                f"Launch cancelled: {selected_port} remains attached to an earlier equipment session."
            )
            return False
        failures: List[str] = []
        for row in rows:
            ok, detail = stop_external_openbci_bridge(row)
            self.log(f"Cross-version bridge recovery for PID {row['pid']}: {detail}\n")
            if not ok:
                failures.append(f"PID {row['pid']}: {detail}")
        if failures:
            messagebox.showerror(
                "Old bridge could not be stopped",
                "The new bridge was not started, so no second process can contend for the board.\n\n"
                + "\n".join(failures),
            )
            return False
        self.hardware_launch_status_var.set(
            f"Recovered {selected_port} from the earlier session; starting {label} for {run_uuid}."
        )
        return True

    def launch_brainflow_eeg_only(self) -> bool:
        path = self.cfg["tools"].get("brainflow_eeg_only", "")
        if not path:
            messagebox.showwarning("Path missing", "Set BrainFlow EEG-only script path in Settings.")
            return False
        port = self.prompt_openbci_serial_port("BrainFlow EEG Only")
        if not port:
            return False
        run_uuid = self.active_run_uuid or self.begin_acquisition_session()
        if not run_uuid:
            return False
        session_root = Path(str(self.cfg.setdefault("acquisition", {}).get("session_artifact_root") or self.cfg["log_root"]))
        if not self.prepare_openbci_bridge_launch("BrainFlow EEG Only", port, run_uuid):
            return False
        return self.launch_python_or_exe("BrainFlow EEG Only", path, ["--serial-port", port, "--run-uuid", run_uuid, "--log-dir", str(session_root / "brainflow_eeg_only")]) is not None

    def launch_brainflow_eeg_als(self) -> bool:
        path = self.cfg["tools"].get("brainflow_eeg_als", "")
        if not path:
            messagebox.showwarning("Path missing", "Set BrainFlow EEG+ALS script path in Settings.")
            return False
        port = self.prompt_openbci_serial_port("BrainFlow EEG + ALS")
        if not port:
            return False
        run_uuid = self.active_run_uuid or self.begin_acquisition_session()
        if not run_uuid:
            return False
        session_root = Path(str(self.cfg.setdefault("acquisition", {}).get("session_artifact_root") or self.cfg["log_root"]))
        if not self.prepare_openbci_bridge_launch("BrainFlow EEG + ALS", port, run_uuid):
            return False
        return self.launch_brainflow_eeg_als_on_port(port, run_uuid, session_root=session_root)

    def launch_brainflow_eeg_als_on_port(
        self,
        port: str,
        run_uuid: str,
        *,
        session_root: Optional[Path] = None,
    ) -> bool:
        """Launch the configured EEG+ALS bridge after ownership was resolved."""
        path = self.cfg["tools"].get("brainflow_eeg_als", "")
        bridge_path = normalized_path(path)
        if not path or not bridge_path.is_file():
            messagebox.showerror(
                "BrainFlow EEG+ALS bridge missing",
                "The configured bridge script is unavailable. Repair its path in Settings before running the ALS barcode test.\n\n"
                f"Current path:\n{bridge_path}",
            )
            return False
        selected_port = str(port or "").strip().upper()
        if not re.fullmatch(r"COM\d+", selected_port, flags=re.IGNORECASE):
            messagebox.showerror("Invalid serial port", f"The recovered bridge port is invalid: {selected_port or '<blank>'}")
            return False
        detected_ports = {str(value).strip().upper() for value in detect_serial_ports() if str(value).strip()}
        if selected_port not in detected_ports:
            visible = ", ".join(sorted(detected_ports)) if detected_ports else "none"
            messagebox.showerror(
                "OpenBCI serial device is not present",
                f"{selected_port} is not currently visible to Windows (detected ports: {visible}). No bridge was started.\n\n"
                "Reconnect or power-cycle the OpenBCI USB dongle, wait for its COM port to appear, then press the launch or barcode button again.",
            )
            return False
        active = str(run_uuid or "").strip()
        if not active:
            messagebox.showerror("Equipment session required", "Start an equipment session before launching the EEG+ALS bridge.")
            return False
        root = session_root or Path(
            str(self.cfg.setdefault("acquisition", {}).get("session_artifact_root") or self.cfg["log_root"])
        )
        self.cfg.setdefault("acquisition", {})["openbci_serial_port"] = selected_port
        self.save_config()
        return self.launch_python_or_exe(
            "BrainFlow EEG + ALS",
            str(bridge_path),
            ["--serial-port", selected_port, "--enable-analog-aux", "--publish-als-stream", "--run-uuid", active, "--log-dir", str(root / "brainflow_eeg_als"), "--calibration-profile", str(Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json")],
        ) is not None

    def prepare_als_barcode_bridge(self) -> bool:
        """Make the barcode button a guarded, self-contained ALS workflow."""
        run_uuid = str(self.active_run_uuid or "").strip()
        if not run_uuid:
            return False
        plan = plan_als_barcode_bridge(discover_external_openbci_bridges(), run_uuid)
        action = str(plan.get("action") or "")
        rows = list(plan.get("rows") or [])
        port = str(plan.get("port") or "").strip().upper()
        if action == "REUSE_CURRENT_ALS":
            row = rows[0]
            self.hardware_launch_status_var.set(
                f"ALS barcode check is reusing the current-session EEG+ALS bridge on {port} (PID {row['pid']})."
            )
            return True
        if action in {"BLOCK_AMBIGUOUS", "BLOCK_DUPLICATE"}:
            details = "\n".join(
                f"- PID {row.get('pid')} | {row.get('serial_port') or 'port unknown'} | "
                f"session {row.get('run_uuid') or 'not declared'} | {row.get('script_name') or 'unknown'}"
                for row in rows
            )
            messagebox.showerror(
                "ALS bridge ownership is ambiguous",
                "More than one packaged OpenBCI bridge or more than one serial port is involved. Alpha 9.0.0 did not stop any process. "
                "Close the listed bridge windows, then press ALS Barcode Placement Test again.\n\n"
                + details,
            )
            self.hardware_launch_status_var.set("ALS barcode test blocked safely: bridge ownership is ambiguous.")
            return False
        if action == "START_ALS":
            if not messagebox.askyesno(
                "Start the ALS equipment bridge?",
                "No packaged PRAYCG EEG+ALS bridge is running for this equipment session.\n\n"
                "Start it now, wait for the current-session ALS outlet, and then run the barcode test?",
                parent=self,
            ):
                self.hardware_launch_status_var.set("ALS barcode test cancelled before starting the equipment bridge.")
                return False
            selected = self.prompt_openbci_serial_port("ALS Barcode Placement Test")
            if not selected:
                return False
            port = selected
        elif action == "REPLACE_WITH_ALS":
            details = "\n".join(
                f"- PID {row.get('pid')} | session {row.get('run_uuid') or 'not declared'} | {row.get('script_name')}"
                for row in rows
            )
            if not messagebox.askyesno(
                "Recover the ALS bridge and continue?",
                f"{port} is owned by a packaged PRAYCG bridge that cannot provide a unique current-session ALS outlet.\n\n"
                f"Bridge(s) to stop:\n{details}\n\n"
                "Alpha 9.0.0 will revalidate each exact process, stop only those listed bridge processes, start EEG+ALS for the current session, wait for its outlet, and run the barcode. Continue?",
                parent=self,
            ):
                self.hardware_launch_status_var.set(f"ALS barcode test cancelled; {port} ownership was not changed.")
                return False
            failures: List[str] = []
            for row in rows:
                ok, detail = stop_external_openbci_bridge(row)
                self.log(f"ALS barcode bridge recovery for PID {row.get('pid')}: {detail}\n")
                if not ok:
                    failures.append(f"PID {row.get('pid')}: {detail}")
            if failures:
                messagebox.showerror(
                    "ALS bridge recovery stopped safely",
                    "At least one bridge could not be revalidated and stopped. No replacement bridge or barcode window was started.\n\n"
                    + "\n".join(failures),
                )
                self.hardware_launch_status_var.set("ALS barcode recovery failed closed; no replacement was started.")
                return False
        else:
            messagebox.showerror("ALS bridge recovery error", f"Unrecognized recovery decision: {action or '<blank>'}")
            return False

        session_root = Path(
            str(self.cfg.setdefault("acquisition", {}).get("session_artifact_root") or self.cfg["log_root"])
        )
        self.hardware_launch_status_var.set(
            f"Starting the EEG+ALS bridge on {port} for {run_uuid}; the barcode test will wait for its outlet."
        )
        return self.launch_brainflow_eeg_als_on_port(port, run_uuid, session_root=session_root)

    def begin_acquisition_session(self) -> str:
        """Create the UUID inherited by a subsequently launched PsychoPy runner."""
        conflicts = PRAYCGControlCenter.runtime_authority_conflicts(self)
        if conflicts:
            messagebox.showerror(
                "Active or unresolved runner authority",
                "A new acquisition UUID cannot be created while an authorized runner is active or an ACQUIRE-stage run remains unresolved.\n\n"
                + "\n".join(f"- {item}" for item in conflicts)
                + "\n\nStop the runner or use Analysis Modules → Finalize Interrupted Run before starting another session.",
            )
            return ""
        protocol_runs_root = Path(self.cfg["log_root"]) / "protocol_runs"
        new_uuid = ""
        for _attempt in range(16):
            candidate = str(uuid.uuid4())
            if not (protocol_runs_root / candidate).exists():
                new_uuid = candidate
                break
        if not new_uuid:
            messagebox.showerror("UUID collision", "Could not allocate a fresh run UUID without colliding with existing artifacts.")
            return ""
        self.active_run_uuid = new_uuid
        os.environ["PRAYCG_RUN_UUID"] = self.active_run_uuid
        acquisition = self.cfg.setdefault("acquisition", {})
        run_artifact_dir = Path(self.cfg["log_root"]) / "protocol_runs" / self.active_run_uuid
        run_artifact_dir.mkdir(parents=True, exist_ok=True)
        acquisition["session_artifact_root"] = str(run_artifact_dir)
        acquisition["profile_preflight_report_path"] = str(run_artifact_dir / "hardware_profile_preflight.json")
        acquisition["detailed_preflight_dir"] = str(run_artifact_dir / "detailed_eeg_als_preflight")
        acquisition["als_test_dir"] = str(run_artifact_dir / "als_barcode_placement_test")
        acquisition["supervisor_output_dir"] = str(run_artifact_dir / "acquisition_supervisor")
        acquisition["session_draft_path"] = str(run_artifact_dir / "runtime_session_draft.json")
        acquisition["session_lock_path"] = str(run_artifact_dir / "runtime_session_lock.json")
        acquisition["latest_profile_preflight_report"] = ""
        acquisition["latest_detailed_preflight_report"] = ""
        acquisition["latest_als_barcode_test_report"] = ""
        acquisition["armed"] = False
        acquisition["arm_override_reason"] = ""
        acquisition["bench_readiness_bypass_active"] = bool(acquisition.get("bench_test_mode"))
        acquisition["bench_bypass_preflight_path"] = ""
        acquisition["disarmed_lock_identity"] = ""
        acquisition["session_stage"] = "SELECT"
        acquisition["preflight_started_epoch"] = time.time()
        acquisition["session_lock_status"] = "STALE_RUN_UUID_CHANGED"
        self.save_config()
        self.write_acquisition_state()
        if hasattr(self, "acquisition_session_var"):
            self.acquisition_session_var.set(
                f"ACTIVE SESSION — {self.active_run_uuid}  |  evidence: {run_artifact_dir}"
            )
        if hasattr(self, "acquisition_session_button"):
            self.acquisition_session_button.configure(text="Start Another Equipment Session")
        if hasattr(self, "acq_readiness_var"):
            self.refresh_acquisition_readiness()
        self.log(f"New acquisition/run UUID: {self.active_run_uuid}\n")
        return self.active_run_uuid

    def runtime_authority_conflicts(self) -> List[str]:
        """Find in-memory or persistent authority that forbids a new run UUID."""
        conflicts: List[str] = []
        for item in getattr(self, "processes", {}).values():
            if bool(getattr(item, "runtime_authority", False)) and item.process.poll() is None:
                conflicts.append(f"authorized runner PID {item.process.pid} is still active")
        lease_paths: List[Path] = []
        log_root = str(getattr(self, "cfg", {}).get("log_root") or "")
        if log_root:
            PRAYCGControlCenter.reconcile_finalized_acquisition_owner(self, silent=True)
            owner_path = active_acquisition_owner_path(log_root)  # type: ignore[misc]
            owner_activity = active_acquisition_owner_activity(owner_path)  # type: ignore[misc]
            if bool(owner_activity.get("active")):
                conflicts.append(
                    "log-root acquisition owner: "
                    f"{owner_activity.get('status')} — {owner_activity.get('reason')}"
                )
            lease_paths.extend((Path(log_root) / "protocol_runs").glob("*/authorized_runner_lease.json"))
        acquisition = getattr(self, "cfg", {}).get("acquisition", {})
        current_root = str(acquisition.get("session_artifact_root") or "") if isinstance(acquisition, dict) else ""
        if current_root:
            lease_paths.append(Path(current_root) / "authorized_runner_lease.json")
        seen: set[str] = set()
        for lease_path in lease_paths:
            identity = normalized_path_identity(lease_path)  # type: ignore[misc]
            if identity in seen or not lease_path.is_file():
                continue
            seen.add(identity)
            activity = runtime_runner_lease_activity(lease_path)  # type: ignore[misc]
            if bool(activity.get("active")):
                conflicts.append(f"{lease_path.parent.name}: {activity.get('status')} — {activity.get('reason')}")
                continue
            # A dead/expired child does not remain live authority, but an
            # ACQUIRE-stage gate still requires explicit interrupted FINALIZE
            # before another session is allocated.
            try:
                lease = load_platform_json(lease_path)  # type: ignore[misc]
                lock_path = Path(str(lease.get("lease_core", {}).get("session_lock_path") or "")).expanduser().resolve()
                lock = load_platform_json(lock_path)  # type: ignore[misc]
                if str(lock.get("current_stage") or "") == "ACQUIRE":
                    conflicts.append(f"{lease_path.parent.name}: expired/dead runner remains at ACQUIRE and needs interrupted FINALIZE")
            except Exception as exc:
                conflicts.append(f"{lease_path.parent.name}: persistent runner authority cannot be resolved safely ({exc})")
        if log_root:
            for lock_path in (Path(log_root) / "protocol_runs").glob("*/runtime_session_lock.json"):
                try:
                    lock = load_platform_json(lock_path)  # type: ignore[misc]
                    report = validate_session_lock_identity(lock)  # type: ignore[misc]
                    if report.status == "INELIGIBLE":
                        conflicts.append(f"{lock_path.parent.name}: runtime lock identity is invalid and cannot be classified safely")
                        continue
                    if str(lock.get("current_stage") or "") != "ACQUIRE":
                        continue
                    lease_path = lock_path.parent / "authorized_runner_lease.json"
                    if not lease_path.is_file():
                        conflicts.append(f"{lock_path.parent.name}: ACQUIRE-stage lock has no persistent runner lease")
                except Exception as exc:
                    conflicts.append(f"{lock_path.parent.name}: runtime lock cannot be resolved safely ({exc})")
        return conflicts

    def prompt_openbci_serial_port(self, label: str) -> Optional[str]:
        ports = detect_serial_ports()
        saved = str(self.cfg.get("acquisition", {}).get("openbci_serial_port", "") or "").strip()
        initial = saved or (ports[0] if len(ports) == 1 else "")
        detected = ", ".join(ports) if ports else "none detected automatically"
        port = simpledialog.askstring(
            f"{label} - serial port",
            "Enter the OpenBCI serial port (for example COM3).\n\n"
            f"Detected ports: {detected}\n\n"
            "Close the OpenBCI GUI first; only one program can use the port.",
            initialvalue=initial,
            parent=self,
        )
        if port is None:
            self.log(f"{label} launch canceled before serial-port selection.\n")
            return None
        port = port.strip().upper()
        if not re.fullmatch(r"COM\d+", port, flags=re.IGNORECASE):
            messagebox.showerror("Invalid serial port", f"Enter a Windows COM port such as COM3.\n\nReceived: {port or '<blank>'}")
            return None
        self.cfg.setdefault("acquisition", {})["openbci_serial_port"] = port
        self.save_config()
        return port

    def launch_labrecorder(self) -> None:
        path = self.cfg["tools"].get("labrecorder", "")
        if not path:
            messagebox.showwarning("Path missing", "Set LabRecorder executable path in Settings.")
            return
        self.launch_python_or_exe("LabRecorder", path)

    def check_lsl_streams(self) -> None:
        if not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        session_root = Path(str(self.cfg.setdefault("acquisition", {}).get("session_artifact_root") or self.cfg["log_root"]))
        args = ["--duration", "5", "--out-dir", str(session_root / "lsl_stream_checks")]
        expected = self.cfg.get("lsl", {}).get("expected_streams", [])
        if expected:
            args += ["--required"] + expected
        self.launch_python_tool("LSL Stream Checker", "lsl_stream_checker", args)
        self.after(1000, self.populate_lsl_tree)

    def run_signal_quality(self) -> None:
        self.open_live_stream_monitor(focus_role="eeg")

    def open_live_stream_monitor(self, focus_role: str = "") -> None:
        """Open a read-only live window for every stream in the locked profile."""
        profile_path = Path(str(self.cfg.get("acquisition", {}).get("hardware_profile_path") or "")).expanduser()
        if not self.active_hardware_profile or not profile_path.is_file():
            messagebox.showerror("Hardware profile required", "Build or load an active reviewed hardware profile before opening live readouts.")
            return
        if not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        args = ["--profile", str(profile_path), "--run-uuid", str(self.active_run_uuid)]
        if focus_role:
            args.extend(["--focus-role", focus_role])
        self.launch_python_tool("Live Signal Quality and Stream Monitor", "live_stream_monitor", args)

    def run_acquisition_preflight(self) -> None:
        """Launch the detailed EEG/ALS report used beside the canonical full-profile gate."""
        if not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        lsl = self.cfg.get("lsl", {})
        args = [
            "--gui",
            "--eeg-stream", str(lsl.get("eeg_stream_name", "obci_eeg1")),
            "--als-stream", "ALS_PT19_Timing",
            "--expected-rate", str(lsl.get("eeg_expected_rate_hz", 125.0)),
            "--out-dir", str(Path(self.cfg.setdefault("acquisition", {}).get("detailed_preflight_dir") or Path(self.cfg["log_root"]) / "acquisition_preflight")),
            "--placement-profile", str(Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json"),
            "--run-uuid", str(self.active_run_uuid),
            "--hardware-profile-sha256", str((self.active_hardware_profile or {}).get("canonical_sha256") or ""),
            "--require-als",
        ]
        self.launch_python_tool("Optional 30-Second Acquisition Validation", "acquisition_preflight", args)

    def run_als_test(self) -> None:
        if not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        acquisition = self.cfg.setdefault("acquisition", {})
        bench_mode = bool(acquisition.get("bench_test_mode"))
        packaged_bridges = discover_external_openbci_bridges()
        detected_ports = detect_serial_ports()
        display_only = bool(bench_mode and not packaged_bridges and not detected_ports)
        if bench_mode and not packaged_bridges and detected_ports:
            physical = messagebox.askyesnocancel(
                "Bench barcode mode",
                "Bench Test Mode is ON and no packaged OpenBCI bridge is running, but Windows reports serial port(s): "
                + ", ".join(detected_ports)
                + ".\n\nChoose Yes to start hardware and perform a physical ALS placement check. "
                "Choose No to run the display/UI sequence only. Choose Cancel to stop.",
                parent=self,
            )
            if physical is None:
                return
            display_only = not physical
        if display_only:
            messagebox.showinfo(
                "Bench barcode display test",
                "Bench Test Mode is ON and Windows detects no serial device or packaged OpenBCI bridge. "
                "The barcode will therefore run in display-only mode without trying to claim COM3.\n\n"
                "This exercises the barcode window and timing sequence only. It records BENCH_DISPLAY_ONLY, contains "
                "no ALS samples, does not validate sensor placement, and cannot satisfy the ALS readiness gate.",
                parent=self,
            )
            self.hardware_launch_status_var.set(
                "BENCH DISPLAY ONLY: running the barcode UI without ALS hardware; readiness will remain ineligible."
            )
        elif not self.prepare_als_barcode_bridge():
            return
        lsl = self.cfg.get("lsl", {})
        args = [
            "--stream-name", str(lsl.get("als_stream_name", "ALS_PT19_Timing")),
            "--channel-index", str(lsl.get("als_channel_index_1based", 1)),
            "--run-uuid", str(self.active_run_uuid),
            "--hardware-profile-sha256", str((self.active_hardware_profile or {}).get("canonical_sha256") or ""),
            "--out-dir", str(Path(self.cfg.setdefault("acquisition", {}).get("als_test_dir") or Path(self.cfg["log_root"]) / "als_pulse_tests")),
            "--fullscreen",
            "--pulse-position", "lower_right",
            "--size-px", "180",
            "--margin-px", "40",
            "--resolve-timeout-sec", "20"
        ]
        if display_only:
            args.append("--display-only")
        self.launch_python_tool(
            "ALS Barcode Display-Only Bench Test" if display_only else "ALS Screen Pulse Barcode Test",
            "als_pulse_test",
            args,
        )

    def populate_lsl_tree(self) -> None:
        if not hasattr(self, "lsl_tree"): return
        self.lsl_tree.delete(*self.lsl_tree.get_children())
        try:
            from pylsl import resolve_streams
            streams = resolve_streams(wait_time=1.0)
            for idx, s in enumerate(streams):
                try:
                    stream_run_uuid = str(s.desc().child_value("run_uuid") or "")
                except Exception:
                    stream_run_uuid = ""
                session_label = (
                    "CURRENT — " + stream_run_uuid
                    if stream_run_uuid and stream_run_uuid == self.active_run_uuid
                    else "OTHER — " + stream_run_uuid
                    if stream_run_uuid
                    else "UNBOUND / NOT DECLARED"
                )
                self.lsl_tree.insert("", "end", iid=str(idx), values=(s.name(), s.type(), s.channel_count(), s.nominal_srate(), session_label, s.source_id()))
            self.log(f"LSL monitor found {len(streams)} stream(s).\n")
        except Exception as exc:
            self.log(f"LSL monitor unavailable/error: {exc}\n")
            messagebox.showwarning("LSL monitor", f"Could not resolve LSL streams. Install pylsl or check network.\n\n{exc}")

    # Runner launch modes
    def psychopy_coder_command(self, runner: Optional[Path] = None) -> List[str]:
        """Build a PsychoPy Coder command that bypasses broken console launchers."""
        psychopy_python = normalized_path(self.cfg["tools"].get("psychopy_python", ""))
        if psychopy_python.is_file():
            cmd = [str(psychopy_python), "-m", "psychopy.app.psychopyApp", "--coder"]
            if runner is not None:
                cmd.append(str(runner))
            return cmd
        coder = normalized_path(
            self.cfg["tools"].get("psychopy_coder", "")
            or self.cfg["tools"].get("psychopy_app", "")
        )
        if coder.is_file():
            cmd = windows_bat_command(coder, ["--coder"] + ([str(runner)] if runner is not None else []))
            return cmd
        return []

    def resolve_protocol_media_snapshot(self, validated_lock: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
        """Resolve the exact prepared files that the runtime session lock will bind."""
        record = validated_lock.get("record", {})
        if isinstance(record, dict) and record.get("module_family") == FAMILY_ATLAS:
            return self.resolve_atlas_asset_snapshot(record)
        folder = self.selected_stimulus_folder()
        if not folder or not folder.is_dir():
            return {"stimulus_folder": "", "selections": {}}, ["no prepared stimulus folder is selected"]
        module = record.get("module", {}) if isinstance(record, dict) else {}
        recommended = self.detect_stimulus_files(folder).get("recommended", {})
        selections: Dict[str, Dict[str, str]] = {}
        errors: List[str] = []

        def bind(target_key: str, detection_key: str, *, required: bool) -> None:
            status = str(recommended.get(f"{detection_key}_status") or "MISSING")
            value = str(recommended.get(detection_key) or "").strip()
            if status != "FOUND" or not value:
                if required:
                    errors.append(f"{target_key}: {status.lower()}; exactly one file is required")
                return
            path = Path(value).expanduser().resolve()
            if not path.is_file():
                if required:
                    errors.append(f"{target_key}: selected file no longer exists")
                return
            selections[target_key] = {"path": str(path), "sha256": sha256_file(path)}

        constraints = module.get("integrity_constraints", {}) if isinstance(module, dict) else {}
        for key in constraints.get("required_media_keys", []):
            bind(str(key), str(key), required=True)
        for target_key, detection_key in {
            "cue_schedule_json": "cue_schedule_json",
            "predeclared_anchor_file": "locked_anchor_json",
            "shot_order_manifest": "shot_order_manifest",
            "semantic_density_sidecar": "semantic_density_sidecar",
        }.items():
            required = target_key == "cue_schedule_json" and bool(constraints.get("cue_schedule_required", False))
            bind(target_key, detection_key, required=required)
        if "als" in self.active_hardware_roles():
            placement = Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json"
            if placement.is_file():
                selections["als_placement_profile"] = {"path": str(placement.resolve()), "sha256": sha256_file(placement)}
            else:
                errors.append("als_placement_profile: holder calibration/placement file is required for the selected ALS profile")
        return {"stimulus_folder": str(folder.resolve()), "selections": selections}, errors

    def resolve_atlas_asset_snapshot(self, record: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
        """Resolve explicitly named Atlas inputs; never guess across multiple roles."""
        contracts = self.protocol_asset_contracts(record)
        manifest_folder = str(Path(str(record.get("manifest_path"))).resolve().parent)
        if not contracts:
            return {
                "stimulus_folder": manifest_folder,
                "selections": {},
                "atlas_asset_snapshot": {},
                "asset_bindings": {},
            }, []

        protocol_id = str(record.get("protocol_id") or "")
        saved = self.cfg.setdefault("protocol_asset_bindings", {}).get(protocol_id, {})
        if not isinstance(saved, dict):
            saved = {}
        declared_keys = {str(contract.get("key") or "") for contract in contracts}
        bindings: Dict[str, str] = {
            str(key): str(value)
            for key, value in saved.items()
            if str(key) in declared_keys and str(value).strip()
        }

        # Compatibility for alpha.6.1 users: a previously saved folder may be
        # adopted automatically only when the protocol has exactly one input.
        # More than one role always requires explicit per-role choices.
        configured = str(self.cfg.setdefault("protocol_asset_folders", {}).get(protocol_id, "") or "")
        if len(contracts) == 1 and not bindings and configured:
            contract = contracts[0]
            candidate_root = Path(configured).expanduser().resolve(strict=False)
            key = str(contract.get("key") or "")
            if contract.get("kind") == "directory" and candidate_root.is_dir():
                bindings[key] = str(candidate_root)
            elif candidate_root.is_file():
                bindings[key] = str(candidate_root)
            elif candidate_root.is_dir():
                allowed = {str(value).casefold() for value in contract.get("allowed_extensions", [])}
                matches = sorted(
                    (
                        item for item in candidate_root.rglob("*")
                        if item.is_file() and (not allowed or item.suffix.casefold() in allowed)
                    ),
                    key=lambda item: item.relative_to(candidate_root).as_posix().casefold(),
                )
                if len(matches) == 1:
                    bindings[key] = str(matches[0].resolve())

        errors: List[str] = []
        for contract in contracts:
            key = str(contract.get("key") or "")
            label = self.protocol_asset_display_label(contract)
            raw = str(bindings.get(key) or "")
            status, detail = self.protocol_asset_path_status(contract, raw)
            if status in {"Missing", "Fix"}:
                if status == "Missing" and contract.get("required") is not True:
                    continue
                errors.append(f"{label}: {detail}")
        folder = configured
        if not folder and bindings:
            first = Path(next(iter(bindings.values()))).expanduser().resolve(strict=False)
            folder = str(first if first.is_dir() else first.parent)
        if errors:
            return {
                "stimulus_folder": folder,
                "selections": {},
                "atlas_asset_snapshot": {},
                "asset_bindings": bindings,
            }, errors
        try:
            normalized = normalize_atlas_bindings(record, bindings)
            snapshot = atlas_asset_snapshot(record, normalized)
        except Exception as exc:
            readable = str(exc)
            for contract in contracts:
                key = str(contract.get("key") or "")
                readable = readable.replace(key, self.protocol_asset_display_label(contract))
            return {
                "stimulus_folder": folder or manifest_folder,
                "selections": {},
                "atlas_asset_snapshot": {},
                "asset_bindings": bindings,
            }, [readable]
        return {
            "stimulus_folder": folder or manifest_folder,
            "selections": dict(snapshot),
            "atlas_asset_snapshot": dict(snapshot),
            "asset_bindings": dict(normalized),
        }, []

    def write_protocol_prefill(
        self,
        validated_lock: Dict[str, Any],
        runtime_lock: Dict[str, Any],
    ) -> Path:
        """Write file hints exclusively from the immutable runtime lock snapshot."""
        session = runtime_lock.get("session", {})
        media_snapshot = session.get("media_selection_snapshot", {}) if isinstance(session, dict) else {}
        if not isinstance(media_snapshot, dict) or not media_snapshot:
            raise ValueError("Runtime session lock has no immutable media selection snapshot.")
        selections = {
            str(key): str(record.get("path"))
            for key, record in media_snapshot.items()
            if isinstance(record, dict) and record.get("path")
        }
        for key, record in media_snapshot.items():
            if not isinstance(record, dict):
                raise ValueError(f"Locked media record {key} is malformed.")
            selected_path = Path(str(record.get("path") or "")).expanduser().resolve()
            if not selected_path.exists() or not (selected_path.is_file() or selected_path.is_dir()):
                raise ValueError(f"Locked media record {key} is missing or changed.")
            if sha256_bound_path(selected_path) != str(record.get("sha256") or ""):
                raise ValueError(f"Locked media record {key} is missing or changed.")

        payload = {
            "schema": "PRAYCG_ProtocolPrefill_v1_0",
            "created_local": datetime.now().isoformat(timespec="seconds"),
            "protocol_id": validated_lock.get("protocol_id"),
            "protocol_version": validated_lock.get("protocol_version"),
            "manifest_sha256": validated_lock.get("manifest_sha256"),
            "module_family": validated_lock.get("module_family"),
            "stimulus_id": str(session.get("stimulus_id") or ""),
            "stimulus_folder": str(session.get("stimulus_folder") or ""),
            "selections": selections,
            "selection_records": media_snapshot,
            "atlas_asset_snapshot": session.get("atlas_asset_snapshot"),
            "compiled_timeline_sha256": session.get("compiled_timeline_sha256"),
            "runtime_lock_identity_sha256": runtime_lock.get("lock_identity_sha256"),
            "rule": "Convenience hints only; the runner independently revalidates all files and protocol hashes.",
        }
        artifact_root = Path(str(session.get("private_output_locations", {}).get("session_log_dir") or "")).expanduser().resolve()
        if not artifact_root.is_dir():
            raise ValueError("Locked run-local artifact directory is unavailable.")
        path = artifact_root / "protocol_prefill_v1_0.json"
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        temporary.replace(path)
        self.log(
            f"Prepared {validated_lock.get('protocol_id')} runner prefill with "
            f"{len(selections)} resolved file(s): {path}\n"
        )
        return path

    def launch_praycg_runner(self) -> None:
        self.refresh_protocol_lock_status()
        if not self.locked_protocol:
            messagebox.showwarning("Protocol not approved", "Select a protocol from the library and click Approve & Select Protocol before launch.")
            return
        mode = self.runner_mode_var.get()
        authorized_direct_launch = mode in {"psychopy_python", "regular_python"}
        acquisition = self.cfg.setdefault("acquisition", {})
        if authorized_direct_launch:
            self.refresh_acquisition_readiness()
            session_lock_status, lock_detail = self.validate_active_session_lock()
            if (
                not bool(acquisition.get("armed"))
                or session_lock_status != "VALID"
                or str(acquisition.get("session_stage") or "") != "ARM"
            ):
                self.nb.select(self.acq_tab)
                self.acq_nb.select(4)
                messagebox.showwarning(
                    "Acquisition session not armed",
                    "The runner cannot start until Acquisition has a current session lock and an armed state.\n\n"
                    f"Readiness: {acquisition.get('readiness_status')}\n"
                    f"Session lock: {session_lock_status} — {lock_detail}\n\n"
                    "In Connect & Check Equipment → Monitor, Record & Arm: run the 30-second check, confirm the session setup, then mark it ready to run.",
                )
                return
        try:
            validated = validate_protocol_lock(self.protocol_lock_path, self.protocol_library_root)
        except Exception as exc:
            self.refresh_protocol_lock_status()
            messagebox.showerror("Protocol lock invalid", f"The locked protocol cannot be launched:\n\n{exc}\n\nRescan and lock it again.")
            return
        if authorized_direct_launch and not self.active_run_uuid:
            if not self.begin_acquisition_session():
                return
        self.cfg["runner_launch_mode"] = mode
        rp = Path(str(validated["runner_path"])).expanduser().resolve()
        protocol_label = f"{validated['protocol_id']} v{validated['protocol_version']}"
        if not rp.is_file():
            messagebox.showerror("Runner not found", f"Locked runner script not found:\n\n{rp}\n\nRescan the library and lock the protocol again.")
            return
        prefill_path: Optional[Path] = None
        current_runtime_lock: Optional[Dict[str, Any]] = None
        session_lock_path = Path(str(acquisition.get("session_lock_path") or "")).expanduser().resolve()
        if authorized_direct_launch:
            reuse_reasons = runtime_lock_reuse_reasons(session_lock_path)  # type: ignore[misc]
            if reuse_reasons:
                messagebox.showerror(
                    "This acquisition UUID was already used",
                    "A locked runner may be launched only once from an acquisition UUID. "
                    "Choose Start Another Equipment Session, confirm the setup, and arm the new UUID before launching.\n\n- "
                    + "\n- ".join(reuse_reasons),
                )
                return
            try:
                current_runtime_lock = load_platform_json(session_lock_path)  # type: ignore[misc]
                stimulus_errors = self.validate_current_stimulus_against_lock(current_runtime_lock, validated)
                if stimulus_errors:
                    self.mark_session_stale_for_stimulus_change("; ".join(stimulus_errors))
                    raise ValueError("; ".join(stimulus_errors))
                prefill_path = self.write_protocol_prefill(validated, current_runtime_lock)
            except Exception as exc:
                messagebox.showerror("Locked inputs changed", f"The prepared runner inputs no longer match the runtime session lock:\n\n{exc}\n\nCreate a new session lock.")
                return
        runner_env = {
            "PRAYCG_PROTOCOL_PREFILL_JSON": str(prefill_path or ""),
            "PRAYCG_PROTOCOL_MANIFEST": str(validated.get("manifest_path", "")),
            "PRAYCG_RUN_UUID": str(self.active_run_uuid or ""),
            "PRAYCG_PARTICIPANT_PSEUDONYM": str(acquisition.get("participant_pseudonym") or ""),
            "PRAYCG_SESSION_OPERATOR": str(acquisition.get("operator_name") or ""),
            "PRAYCG_HARDWARE_PROFILE": str(acquisition.get("hardware_profile_path") or ""),
            "PRAYCG_ACQUISITION_STATE": str(acquisition.get("state_path") or ""),
            "PRAYCG_SESSION_LOCK_JSON": str(acquisition.get("session_lock_path") or ""),
            "PRAYCG_SESSION_LOG_DIR": str(acquisition.get("session_artifact_root") or ""),
            "PRAYCG_SESSION_PURPOSE": "BENCH_TEST" if acquisition.get("bench_test_mode") else "PARTICIPANT_ACQUISITION",
            "PRAYCG_BENCH_TEST_MODE": "1" if acquisition.get("bench_test_mode") else "0",
            "PRAYCG_BENCH_READINESS_BYPASS": "1" if acquisition.get("bench_readiness_bypass_active") else "0",
        }
        command: List[str]
        launch_label: str
        launch_environment: Optional[Dict[str, str]] = None
        if mode == "psychopy_python":
            py = self.cfg["tools"].get("psychopy_python", "")
            if not py:
                messagebox.showwarning("PsychoPy Python missing", "Set PsychoPy Python interpreter path in Settings.")
                return
            command = [py, str(rp)]
            launch_label = f"{protocol_label} Runner via PsychoPy Python"
            launch_environment = runner_env
        elif mode == "open_psychopy_coder_then_open_runner_file":
            command = self.psychopy_coder_command(rp)
            if not command:
                messagebox.showwarning("PsychoPy path missing", "Set PsychoPy Python, Coder, or app path in Settings, then run Auto-find PsychoPy.")
                return
            launch_label = f"{protocol_label} Runner in PsychoPy Coder — debug only"
        elif mode == "psychopy_app_file_arg":
            app = self.cfg["tools"].get("psychopy_app", "")
            if not app:
                messagebox.showwarning("PsychoPy app missing", "Set PsychoPy app path in Settings.")
                return
            command = [app, "--coder", str(rp)]
            launch_label = f"{protocol_label} Runner via PsychoPy app — debug only"
        else:
            command = self.get_python_cmd() + [str(rp)]
            launch_label = f"{protocol_label} Runner via regular Python"
            launch_environment = runner_env

        if not command_is_available(command):
            messagebox.showerror(
                "Cannot launch - executable not found",
                f"Could not find the program needed to launch {launch_label}:\n\n{command[0]}",
            )
            return

        claimed_lock: Optional[Dict[str, Any]] = None
        runtime_owner_path: Optional[Path] = None
        runtime_owner: Optional[Dict[str, Any]] = None
        runtime_lease_path: Optional[Path] = None
        runtime_claim_token = ""
        runtime_lease: Optional[Dict[str, Any]] = None
        if authorized_direct_launch:
            try:
                current_lock = load_platform_json(session_lock_path)  # type: ignore[misc]
                stimulus_errors = self.validate_current_stimulus_against_lock(current_lock, validated)
                if stimulus_errors:
                    self.mark_session_stale_for_stimulus_change("; ".join(stimulus_errors))
                    raise ValueError("Current stimulus no longer matches the lock: " + "; ".join(stimulus_errors))
                conflicts = PRAYCGControlCenter.runtime_authority_conflicts(self)
                if conflicts:
                    raise RuntimeError(
                        "Another acquisition authority is active or unresolved:\n- "
                        + "\n- ".join(conflicts)
                    )
                runtime_owner_path, runtime_owner = claim_active_acquisition_owner(  # type: ignore[misc]
                    self.cfg["log_root"],
                    current_lock,
                    session_lock_path,
                    controller_instance_id=str(acquisition.get("control_center_process_id") or ""),
                    controller_pid=os.getpid(),
                )
                runtime_claim_token = secrets.token_urlsafe(48)
                runtime_lease_path, runtime_lease = issue_authorized_runner_lease(  # type: ignore[misc]
                    current_lock,
                    session_lock_path,
                    runtime_claim_token,
                    launch_mode=mode,
                    launch_command=command,
                    controller_instance_id=str(acquisition.get("control_center_process_id") or ""),
                    controller_pid=os.getpid(),
                )
                runtime_owner = bind_active_acquisition_owner_lease(  # type: ignore[misc]
                    runtime_owner_path,
                    runtime_lease_path,
                    controller_instance_id=str(acquisition.get("control_center_process_id") or ""),
                    controller_pid=os.getpid(),
                )
                lease_core = runtime_lease.get("lease_core", {})
                owner_core = runtime_owner.get("owner_core", {})
                runner_env["PRAYCG_RUNNER_LEASE_JSON"] = str(runtime_lease_path)
                runner_env["PRAYCG_RUNNER_CLAIM_TOKEN"] = runtime_claim_token
                launch_environment = runner_env
                claimed_lock = advance_session_gate(  # type: ignore[misc]
                    current_lock,
                    "ACQUIRE",
                    session_lock_path,
                    operator=str(acquisition.get("operator_name") or current_lock.get("lock_core", {}).get("operator") or "UNRECORDED"),
                    evidence={
                        "event": "AUTHORIZED_RUNNER_PROCESS_CLAIMED_BEFORE_SPAWN",
                        "run_uuid": self.active_run_uuid,
                        "launch_mode": mode,
                        "protocol_id": validated.get("protocol_id"),
                        "protocol_version": validated.get("protocol_version"),
                        "runner_sha256": validated.get("runner_sha256"),
                        "lease_path": str(runtime_lease_path),
                        "lease_id": lease_core.get("lease_id"),
                        "lease_core_sha256": runtime_lease.get("lease_core_sha256"),
                        "lease_claim_token_sha256": lease_core.get("claim_token_sha256"),
                        "armed_state_sha256": lease_core.get("armed_state_sha256"),
                        "active_owner_path": str(runtime_owner_path),
                        "active_owner_id": owner_core.get("owner_id"),
                        "active_owner_core_sha256": runtime_owner.get("owner_core_sha256"),
                    },
                )
            except Exception as exc:
                if runtime_lease_path is not None and runtime_lease_path.is_file() and claimed_lock is None:
                    try:
                        finish_authorized_runner_lease(  # type: ignore[misc]
                            runtime_lease_path,
                            status="CANCELLED",
                            reason="ACQUIRE_GATE_CLAIM_FAILED",
                            allow_unconsumed=True,
                        )
                    except Exception as lease_exc:
                        self.log(f"Failed to close rejected runner lease: {lease_exc}\n")
                if runtime_owner_path is not None and runtime_owner_path.is_file() and claimed_lock is None:
                    try:
                        finish_active_acquisition_owner(  # type: ignore[misc]
                            runtime_owner_path,
                            reason="CONTROL_CENTER_CANCELLED_OWNER_BEFORE_ACQUIRE",
                            allow_preacquire_cancel=True,
                            controller_instance_id=str(acquisition.get("control_center_process_id") or ""),
                            controller_pid=os.getpid(),
                        )
                    except Exception as owner_exc:
                        self.log(f"Failed owner claim remains unresolved: {owner_exc}\n")
                messagebox.showerror("Runner launch claim failed", f"The ACQUIRE gate could not be claimed exactly once:\n\n{exc}")
                return
            acquisition["session_stage"] = "ACQUIRE"
            self.save_config()
            self.refresh_acquisition_readiness()

        started = self.launch_process(
            launch_label,
            command,
            cwd=rp.parent,
            env_overrides=launch_environment,
            allow_runtime_authority=authorized_direct_launch,
            restartable=not authorized_direct_launch,
            runtime_lease_path=runtime_lease_path,
            runtime_owner_path=runtime_owner_path,
        )
        if started is None and authorized_direct_launch and claimed_lock is not None:
            try:
                if runtime_lease_path is not None and runtime_lease_path.is_file():
                    finish_authorized_runner_lease(  # type: ignore[misc]
                        runtime_lease_path,
                        status="LAUNCH_FAILED",
                        reason="CHILD_PROCESS_DID_NOT_START_OR_BIND",
                        allow_unconsumed=True,
                    )
                failed_lock = load_platform_json(session_lock_path)  # type: ignore[misc]
                failed_finalized_lock = advance_session_gate(  # type: ignore[misc]
                    failed_lock,
                    "FINALIZE",
                    session_lock_path,
                    operator=str(acquisition.get("operator_name") or failed_lock.get("lock_core", {}).get("operator") or "UNRECORDED"),
                    evidence={
                        "run_state": "LAUNCH_FAILED_BEFORE_CHILD_PROCESS_STARTED",
                        "launch_mode": mode,
                        "executable": command[0],
                    },
                )
                if runtime_owner_path is not None and runtime_owner_path.is_file():
                    finish_active_acquisition_owner(  # type: ignore[misc]
                        runtime_owner_path,
                        reason="CONTROL_CENTER_FINALIZED_FAILED_RUNNER_LAUNCH",
                    )
                acquisition["session_stage"] = "FINALIZE"
                acquisition["armed"] = False
                self.save_config()
                self.refresh_acquisition_readiness()
            except Exception as exc:
                self.log(f"Failed to finalize an unsuccessful runner launch: {exc}\n")
            return
        if mode == "open_psychopy_coder_then_open_runner_file":
            self.log(f"Opening {protocol_label} in Coder without acquisition authority: {rp}\n")
            messagebox.showinfo("Debug-only Coder mode", "Coder was opened without the runtime session-lock environment. It is useful for inspection, but pressing Run there will be rejected by the engine. Use the recommended PsychoPy Python mode for an authorized acquisition.")
        elif mode == "psychopy_app_file_arg":
            messagebox.showinfo("Experimental debug mode", "The PsychoPy application was opened without acquisition authority. Use the recommended PsychoPy Python mode to execute the locked session.")

    def launch_psychopy_coder_only(self, show_warning=True) -> None:
        cmd = self.psychopy_coder_command()
        if not cmd:
            if show_warning:
                messagebox.showwarning("PsychoPy path missing", "Set PsychoPy Python, Coder, or app path in Settings, then run Auto-find PsychoPy.")
            return
        self.launch_process("PsychoPy Coder", cmd)

    def open_runner_location(self) -> None:
        self.refresh_protocol_lock_status()
        if not self.locked_protocol:
            messagebox.showwarning("Protocol not approved", "Approve and select a protocol before opening its runner location.")
            return
        p = Path(str(self.locked_protocol["runner_path"])).expanduser().resolve()
        open_path(p.parent if p.parent.exists() else p)




    def use_bundled_paths(self) -> None:
        """Reset tool paths to the software bundled inside this alpha package."""
        root = package_root()
        # Also reset Python to the interpreter running this Control Center.
        # This clears stale v0.5 configs where a Windows path may have been corrupted by shlex.
        self.cfg["python_executable"] = sys.executable
        self.cfg.setdefault("tools", {})
        self.cfg["tools"].update(bundled_tool_paths(root))
        self.cfg["protocol_library_root"] = str(root.parent / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0")
        self.cfg["analysis_orchestration_registry"] = str(root.parent / "config" / "analysis_orchestration_registry_v0_1.json")
        self.cfg.setdefault("protocol_asset_root", str(Path(self.cfg.get("praycg_home") or "C:/PRAYCG") / "protocol_assets"))
        self.cfg["schema"] = CONFIG_SCHEMA
        self.cfg["version"] = APP_VERSION
        self.protocol_library_root = Path(self.cfg["protocol_library_root"]).resolve()
        self.save_config()
        if hasattr(self, "setting_vars"):
            for name, var in self.setting_vars.items():
                try:
                    if "." in name:
                        key, sub = name.split(".", 1)
                        var.set(str(self.cfg.get(key, {}).get(sub, "")))
                    else:
                        var.set(str(self.cfg.get(name, "")))
                except Exception:
                    pass
        if hasattr(self, "protocol_tree"):
            self.refresh_protocol_library()
        self.analysis_registry_path = Path(self.cfg["analysis_orchestration_registry"]).resolve()
        self.log("Bundled v1.0.0-alpha.9.0.0 stimulus, hardware, protocol, acquisition, workspace, and analysis paths loaded. Python executable reset to the current interpreter. LabRecorder and PsychoPy remain external and can be auto-found or set manually.\n")
        messagebox.showinfo("Bundled paths loaded", "Control Center paths now point to the bundled v1.0.0-alpha.9.0.0 platform package. Python was reset to the current interpreter. LabRecorder and PsychoPy are external apps and still need auto-find or manual selection.")

    # Auto-find helpers v0.4
    def _autofind_roots(self) -> List[Path]:
        roots: List[Path] = []
        def add(x):
            if not x: return
            try:
                p = Path(x).expanduser()
                if p.exists() and p.is_dir() and p not in roots:
                    roots.append(p)
            except Exception:
                pass
        add(self.cfg.get("praycg_home"))
        add(self.cfg.get("stimulus_root"))
        add(self.cfg.get("run_root"))
        add(self.pkg)
        add(Path.home() / "Desktop")
        add(Path.home() / "Downloads")
        add(Path.home() / "Documents")
        for env in ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA", "APPDATA"]:
            add(os.environ.get(env))
        for x in ["C:/PRAYCG", "C:/Program Files/PsychoPy", "C:/Program Files/LabRecorder", "C:/LabRecorder", "C:/PsychoPy"]:
            add(x)
        return roots

    def _bounded_find(self, patterns: List[str], roots: Optional[List[Path]]=None, max_depth: int=7, max_hits: int=40, time_budget_sec: float=9.0) -> List[Path]:
        """Fast bounded recursive finder for public Windows users. Avoids full drive sweeps."""
        start = time.time()
        roots = roots or self._autofind_roots()
        hits: List[Path] = []
        seen = set()
        lower_patterns = [p.lower() for p in patterns]
        for root in roots:
            if time.time() - start > time_budget_sec or len(hits) >= max_hits:
                break
            try:
                root = root.resolve()
            except Exception:
                continue
            if not root.exists():
                continue
            stack = [(root, 0)]
            while stack and time.time() - start <= time_budget_sec and len(hits) < max_hits:
                cur, depth = stack.pop()
                try:
                    entries = list(cur.iterdir())
                except Exception:
                    continue
                for e in entries:
                    if len(hits) >= max_hits or time.time() - start > time_budget_sec:
                        break
                    name = e.name.lower()
                    if e.is_file():
                        for pat in lower_patterns:
                            if self._wild_match(name, pat) or self._wild_match(str(e).lower(), pat):
                                try:
                                    r = e.resolve()
                                except Exception:
                                    r = e
                                if str(r).lower() not in seen:
                                    hits.append(r); seen.add(str(r).lower())
                                break
                    elif e.is_dir() and depth < max_depth:
                        # Skip noisy folders.
                        if name in {".git", "__pycache__", "node_modules", "windows", "winsxs", "appdata"} and depth > 0:
                            continue
                        stack.append((e, depth + 1))
        return hits

    def _wild_match(self, text: str, pattern: str) -> bool:
        # small wildcard matcher for names/paths; pattern is lowercase.
        if "*" not in pattern:
            return pattern in text
        rx = re.escape(pattern).replace(r"\*", ".*")
        return re.search(rx, text) is not None

    def _score_candidate(self, path: Path, kind: str) -> int:
        txt = str(path).lower()
        score = 0
        if kind == "runner":
            for token, pts in [("praycg2_0", 50), ("2_0", 30), ("consolidated", 30), ("selfreport", 25), ("runner", 10), ("scripts", 5), ("current", 10)]:
                if token in txt: score += pts
            if path.name == "run_PRAYCG2_0_ConsolidatedSelfReport.py": score += 80
        elif kind == "labrecorder":
            if path.name.lower() == "labrecorder.exe": score += 80
            if "program files" in txt: score += 10
        elif kind == "psychopy":
            if path.name.lower() in {"psychopy.exe", "psychopyapp.exe"}: score += 80
            if "program files" in txt: score += 10
        elif kind == "psychopy_python":
            if path.name.lower() in {"python.exe", "pythonw.exe"}: score += 30
            if "psychopy" in txt: score += 50
        # prefer shorter paths after scoring.
        score -= min(len(txt) // 80, 5)
        return score

    def _choose_best(self, candidates: List[Path], kind: str) -> Optional[Path]:
        if not candidates:
            return None
        return sorted(candidates, key=lambda p: (self._score_candidate(p, kind), -len(str(p))), reverse=True)[0]

    def _set_tool_path(self, key: str, path: Optional[Path]) -> None:
        if not path:
            return
        self.cfg.setdefault("tools", {})[key] = str(path)
        if hasattr(self, "setting_vars"):
            var = self.setting_vars.get(f"tools.{key}")
            if var is not None:
                var.set(str(path))

    def _set_core_path(self, key: str, path: Optional[Path]) -> None:
        if not path:
            return
        self.cfg[key] = str(path)
        if hasattr(self, "setting_vars"):
            var = self.setting_vars.get(key)
            if var is not None:
                var.set(str(path))

    def autofind_labrecorder(self, save: bool=True) -> Dict[str, Any]:
        report: Dict[str, Any] = {"tool": "labrecorder", "found": False, "candidates": []}
        which = shutil.which("LabRecorder") or shutil.which("LabRecorder.exe")
        cands = [Path(which)] if which else []
        cands += self._bounded_find(["labrecorder.exe", "*LabRecorder*.exe"], max_depth=6, time_budget_sec=7.0)
        best = self._choose_best(cands, "labrecorder")
        report["candidates"] = [str(p) for p in cands[:20]]
        if best:
            report.update({"found": True, "selected": str(best)})
            self._set_tool_path("labrecorder", best)
            self.log(f"Auto-find LabRecorder: {best}\n")
        else:
            self.log("Auto-find LabRecorder: not found. Set manually in Settings.\n")
        if save: self.save_config()
        return report

    def autofind_psychopy(self, save: bool=True) -> Dict[str, Any]:
        report: Dict[str, Any] = {"tool": "psychopy", "found": False, "candidates": []}
        cands: List[Path] = []
        for name in ["psychopy", "psychopy.exe"]:
            w = shutil.which(name)
            if w: cands.append(Path(w))
        cands += self._bounded_find(["psychopy.exe", "*PsychoPy*.exe"], max_depth=7, time_budget_sec=9.0)
        best = self._choose_best(cands, "psychopy")
        report["candidates"] = [str(p) for p in cands[:20]]
        if best:
            report.update({"found": True, "selected_app": str(best), "selected_coder": str(best)})
            self._set_tool_path("psychopy_app", best)
            self._set_tool_path("psychopy_coder", best)
            # Look for PsychoPy-bundled Python near the app.
            py_cands = []
            for parent in [best.parent, best.parent.parent if best.parent.parent else best.parent]:
                for nm in ["python.exe", "pythonw.exe"]:
                    p = parent / nm
                    if p.exists(): py_cands.append(p)
                for sub in ["python", "Python", "resources", "Scripts"]:
                    d = parent / sub
                    if d.exists():
                        py_cands += [p for p in d.rglob("python*.exe") if p.is_file()][:10]
            py_best = self._choose_best(py_cands, "psychopy_python")
            if py_best:
                self._set_tool_path("psychopy_python", py_best)
                report["selected_python"] = str(py_best)
            self.log(f"Auto-find PsychoPy: {best}\n")
        else:
            self.log("Auto-find PsychoPy: not found. Set manually in Settings.\n")
        if save: self.save_config()
        return report

    def autofind_common_tools(self) -> None:
        self.refresh_protocol_library()
        report = {
            "schema": "PRAYCG_ControlCenter_AutoFind_Report_v0_95",
            "created_local": datetime.now().isoformat(timespec="seconds"),
            "labrecorder": self.autofind_labrecorder(save=False),
            "psychopy": self.autofind_psychopy(save=False),
            "protocol_library": {
                "root": str(self.protocol_library_root),
                "valid_module_count": len(self.protocol_records),
                "errors": list(self.protocol_library_errors),
                "protocol_ids": [record.get("protocol_id") for record in self.protocol_records],
            },
        }
        # Save after all updates so the Settings GUI gets all values.
        self.save_config()
        out_dir = Path(self.cfg["log_root"]) / "control_center" / "autofind"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"autofind_report_{now_stamp()}.json"
        out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        self.log(f"Auto-find report written: {out_path}\n")
        if hasattr(self, "runner_detect_text"):
            self.refresh_runner_detect_text()
        messagebox.showinfo("Auto-find complete", "Auto-find finished. Review Settings paths before launching tools.\n\nReport:\n" + str(out_path))

    # Analysis tab
    def read_run_registry(self) -> Dict[str, Any]:
        try:
            payload = json.loads(Path(self.cfg["run_registry"]).read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else {"schema": "PRAYCG_RunRegistry_v0_2", "runs": []}
        except Exception:
            return {"schema": "PRAYCG_RunRegistry_v0_2", "runs": []}

    def write_run_registry(self, registry: Dict[str, Any]) -> None:
        registry["schema"] = "PRAYCG_RunRegistry_v0_2"
        Path(self.cfg["run_registry"]).write_text(json.dumps(registry, indent=2), encoding="utf-8")

    def record_selected_run(self) -> None:
        run = self.active_context.get("run", {})
        folder = str(run.get("folder") or "")
        if not folder:
            return
        registry = self.read_run_registry()
        previous = next((item for item in registry.get("runs", []) if str(item.get("folder", "")).casefold() == folder.casefold()), {})
        entry = {
            "folder": folder,
            "label": run.get("label") or Path(folder).name,
            "run_uuid": run.get("run_uuid") or "",
            "protocol_schema": run.get("protocol_schema") or "",
            "stimulus_id": self.active_context.get("stimulus", {}).get("id") or "",
            "xdf": self.context_record_path(run, "xdf"),
            "events": self.context_record_path(run, "events"),
            "last_selected_local": datetime.now().isoformat(timespec="seconds"),
            "pinned": bool(previous.get("pinned", False)),
        }
        runs = [item for item in registry.get("runs", []) if str(item.get("folder", "")).casefold() != folder.casefold()]
        runs.append(entry)
        registry["runs"] = runs
        self.write_run_registry(registry)
        self.refresh_run_catalog()

    def refresh_run_catalog(self) -> None:
        if not hasattr(self, "run_catalog_combo"):
            return
        runs = self.read_run_registry().get("runs", [])
        runs = [item for item in runs if str(item.get("folder") or "")]
        runs.sort(key=lambda item: str(item.get("last_selected_local") or ""), reverse=True)
        runs.sort(key=lambda item: bool(item.get("pinned")), reverse=True)
        self.run_catalog_paths: Dict[str, str] = {}
        values = []
        for item in runs:
            prefix = "PIN | " if item.get("pinned") else ""
            label = f"{prefix}{item.get('label') or Path(item['folder']).name} | {item.get('run_uuid') or 'no UUID'} | {item['folder']}"
            values.append(label)
            self.run_catalog_paths[label] = str(item["folder"])
        self.run_catalog_combo["values"] = values
        if values and self.run_catalog_var.get() not in values:
            self.run_catalog_var.set(values[0])

    def use_run_catalog_selection(self) -> None:
        folder = self.run_catalog_paths.get(self.run_catalog_var.get(), "") if hasattr(self, "run_catalog_paths") else ""
        if not folder or not Path(folder).is_dir():
            messagebox.showwarning("Run unavailable", "The selected catalog entry no longer points to an existing folder.")
            return
        self.selected_run_folder = Path(folder)
        self.active_context["analysis"] = {}
        self.scan_selected_run_folder()

    def toggle_pin_catalog_run(self) -> None:
        folder = self.run_catalog_paths.get(self.run_catalog_var.get(), "") if hasattr(self, "run_catalog_paths") else ""
        if not folder:
            return
        registry = self.read_run_registry()
        for item in registry.get("runs", []):
            if str(item.get("folder", "")).casefold() == folder.casefold():
                item["pinned"] = not bool(item.get("pinned"))
                break
        self.write_run_registry(registry)
        self.refresh_run_catalog()

    def select_run_folder(self) -> None:
        d = filedialog.askdirectory(title="Select PRAYCG run folder")
        if d:
            self.selected_run_folder = Path(d)
            self.active_context["analysis"] = {}
            self.scan_selected_run_folder()

    def scan_selected_run_folder(self) -> None:
        folder = self.selected_run_folder
        if not folder:
            if hasattr(self, "analysis_text"):
                self.analysis_text.delete("1.0", "end")
                self.analysis_text.insert("end", "No run folder selected.\n")
            return
        if not folder.is_dir():
            messagebox.showwarning("Run folder missing", f"The selected run folder no longer exists:\n{folder}")
            return
        self.active_context["run"] = resolve_raw_run(folder)
        # Analysis selection must never become acquisition authority.  Live
        # acquisition UUIDs are created only by begin_acquisition_session().
        self.link_stimulus_from_run_context()
        self.record_selected_run()
        self.refresh_analysis_context()

    def link_stimulus_from_run_context(self) -> None:
        """Use recorded media paths to link a run to exactly one registered stimulus."""
        run = self.active_context.get("run", {})
        recorded_paths = []
        for key in ("target_video", "override_video", "control_video", "cue_schedule_json"):
            value = self.context_record_path(run, key)
            if value:
                recorded_paths.append(Path(value))
        if not recorded_paths:
            return
        matches = []
        for item in self.read_registry().get("stimuli", []):
            folder_value = str(item.get("folder") or "")
            if not folder_value:
                continue
            stimulus_folder = Path(folder_value)
            if any(path_is_within(path, stimulus_folder) for path in recorded_paths):
                matches.append(str(item.get("stimulus_id") or ""))
        matches = sorted(set(value for value in matches if value))
        if len(matches) == 1 and matches[0] != self.selected_stimulus_id:
            self.selected_stimulus_id = matches[0]
            self.update_stimulus_context(matches[0])
            if hasattr(self, "stim_tree") and self.stim_tree.exists(matches[0]):
                self.stim_tree.selection_set(matches[0])
                self.stim_tree.focus(matches[0])
            self.log(f"Linked selected run to registered stimulus {matches[0]} using recorded media paths.\n")

    def refresh_analysis_context(self) -> None:
        run = self.active_context.get("run", {})
        run_folder_value = str(run.get("folder") or "")
        if not run_folder_value:
            self.active_context["analysis"] = {}
            self.save_active_context()
            return
        run_folder = Path(run_folder_value)
        existing = self.active_context.get("analysis", {})
        core_override = None
        chain_override = None
        if existing.get("core", {}).get("source") == "MANUAL_SELECTION" and existing.get("core", {}).get("path"):
            core_override = Path(existing["core"]["path"])
        if existing.get("chain", {}).get("source") == "MANUAL_SELECTION" and existing.get("chain", {}).get("path"):
            chain_override = Path(existing["chain"]["path"])
        self.active_context["analysis"] = resolve_analysis_outputs(
            Path(self.cfg["analysis_root"]),
            run,
            run_folder=run_folder,
            core_override=core_override,
            chain_override=chain_override,
        )
        self.save_active_context()
        self.render_analysis_context()

    def select_core_analysis_folder(self) -> None:
        d = filedialog.askdirectory(title="Select completed Master Suite v1.6.0 core output")
        if not d:
            return
        folder = Path(d).resolve()
        canonical = folder / "tables" / "praycg_analysis_frame_v1_6_0.csv"
        if not canonical.is_file():
            messagebox.showerror("Not a canonical core output", f"Missing:\n{canonical}")
            return
        self.active_context.setdefault("analysis", {})["core"] = {
            "status": "RESOLVED",
            "path": str(folder),
            "source": "MANUAL_SELECTION",
            "message": "Manually selected canonical core output",
            "candidates": [str(folder)],
        }
        self.active_context["analysis"]["chain"] = {}
        self.refresh_analysis_context()

    def select_run_artifact(self, key: str, title: str, filetypes) -> None:
        value = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if not value:
            return
        path = Path(value).resolve()
        self.active_context.setdefault("run", {})[key] = {
            "status": "RESOLVED",
            "path": str(path),
            "source": "MANUAL_SELECTION",
            "message": "Manually selected raw-run artifact",
            "candidates": [str(path)],
        }
        self.active_context["analysis"] = {}
        self.record_selected_run()
        self.refresh_analysis_context()

    def select_chain_analysis_folder(self) -> None:
        d = filedialog.askdirectory(title="Select completed v1.6.1 chained-analysis output")
        if not d:
            return
        folder = Path(d).resolve()
        if not (folder / "chain_manifest.json").is_file():
            messagebox.showerror("Not a chained output", f"Missing chain_manifest.json in:\n{folder}")
            return
        self.active_context.setdefault("analysis", {})["chain"] = {
            "status": "RESOLVED",
            "path": str(folder),
            "source": "MANUAL_SELECTION",
            "message": "Manually selected chained-analysis output",
            "candidates": [str(folder)],
        }
        self.refresh_analysis_context()

    def render_analysis_context(self) -> None:
        if not hasattr(self, "analysis_text"):
            return
        run = self.active_context.get("run", {})
        analysis = self.active_context.get("analysis", {})
        self.analysis_run_var.set(f"Run: {run.get('folder') or 'none'}")
        self.analysis_core_var.set(f"Core: {analysis.get('core', {}).get('status', 'MISSING')} | {analysis.get('core', {}).get('path', '')}")
        self.analysis_chain_var.set(f"Chain: {analysis.get('chain', {}).get('status', 'MISSING')} | {analysis.get('chain', {}).get('path', '')}")
        self.analysis_text.delete("1.0", "end")
        self.analysis_text.insert("end", summarize_context(self.active_context))
        self.analysis_text.insert(
            "end",
            "\n\nEXPLORATORY BOUNDARY\nCAI/SID, continuous autonomic, Micro Handoff v0.1, and Cue-Locked Gamma Forensics v0.1 outputs remain separate from Master Suite eligibility and primary conclusions. Readiness or synthetic PASS statuses concern computation only, not construct validity. Micro Handoff estimates an EEG temporal gamma/theta coordination proxy; it is not a direct measure, probability, diagnosis, or validated gauge of consciousness. Cue-Locked Gamma Forensics evaluates artifact-compatible timing, spectrum, topography, and autonomic patterns; it does not deliver a brain-versus-muscle verdict.\n",
        )

    def update_analysis_button_states(self) -> None:
        if not hasattr(self, "analysis_buttons"):
            return
        for key, button in self.analysis_buttons.items():
            button.configure(state="normal" if self.tool_is_ready(key) else "disabled")
        if hasattr(self, "exploratory_buttons"):
            has_run = bool(self.selected_run_folder and self.selected_run_folder.is_dir())
            for key, button in self.exploratory_buttons.items():
                configured = str(self.cfg.get("tools", {}).get({
                    "cai_readiness": "cai_readiness_preflight",
                    "cai_sid": "cai_sid_exploratory_gui",
                    "autonomic": "continuous_autonomic_gui",
                    "prospective": "prospective_study_console",
                    "micro_handoff": "micro_handoff_gui",
                    "clgf": "cue_locked_gamma_forensics",
                }[key], ""))
                allowed = Path(configured).is_file() and (has_run or key in {"prospective", "clgf"})
                button.configure(state="normal" if allowed else "disabled")
        self.render_analysis_context()

    def open_preferred_review_folder(self) -> None:
        preferred = str(self.active_context.get("analysis", {}).get("preferred_review_folder") or "")
        if not preferred:
            messagebox.showinfo("No review folder", "Complete or select a matching core/chained analysis output first.")
            return
        open_path(Path(preferred))


def main() -> int:
    app = PRAYCGControlCenter()
    app.mainloop()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
