#!/usr/bin/env python3
"""Live, read-only LSL stream monitor for a reviewed PRAYCG hardware profile.

This window makes transport state visible to the operator.  It does not write
preflight evidence, approve a hardware profile, create a session lock, or arm a
runner.  Values remain in the units declared by each outlet; ALS values are raw
or relative photonic load, not calibrated lux.
"""
from __future__ import annotations

import argparse
import json
import math
import queue
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any, Iterable, Optional


def _safe_stream_value(info: Any, method: str, default: Any = "") -> Any:
    try:
        return getattr(info, method)()
    except Exception:
        return default


def _description_value(info: Any, key: str) -> str:
    try:
        return str(info.desc().child_value(key) or "")
    except Exception:
        return ""


def _stream_identity(info: Any) -> dict[str, str]:
    return {
        "name": str(_safe_stream_value(info, "name", "") or ""),
        "source_id": str(_safe_stream_value(info, "source_id", "") or ""),
        "run_uuid": _description_value(info, "run_uuid"),
    }


def choose_stream_candidate(
    candidates: Iterable[Any],
    expected: dict[str, Any],
    active_run_uuid: str,
) -> tuple[Optional[Any], str, list[dict[str, str]]]:
    """Select one outlet without silently crossing the active-session boundary."""
    options = list(candidates)
    identities = [_stream_identity(info) for info in options]
    policy = str(expected.get("source_id_policy") or "").strip().lower()
    active = str(active_run_uuid or "").strip()
    fragment = active.replace("-", "")[:12]

    if policy == "dynamic_run_bound" and active:
        matching = []
        for info, identity in zip(options, identities):
            source_compact = identity["source_id"].replace("-", "")
            if identity["run_uuid"] == active or (fragment and fragment in source_compact):
                matching.append(info)
        if len(matching) == 1:
            return matching[0], "CURRENT SESSION", identities
        if not matching and options:
            return None, "WRONG SESSION — outlet exists but was not launched for this session", identities
        if len(matching) > 1:
            return None, "AMBIGUOUS — multiple outlets belong to this session", identities
        return None, "NOT FOUND", identities

    declared = str(expected.get("source_id") or "").strip()
    if declared:
        matching = [
            info for info, identity in zip(options, identities)
            if identity["source_id"] == declared
        ]
        if len(matching) == 1:
            return matching[0], "DECLARED SOURCE", identities
        if len(matching) > 1:
            return None, "AMBIGUOUS — duplicate declared source", identities
        if options:
            return None, "SOURCE ID MISMATCH", identities

    if len(options) == 1:
        return options[0], "VISIBLE", identities
    if not options:
        return None, "NOT FOUND", identities
    return None, "AMBIGUOUS — multiple outlets use this name", identities


def _channel_metadata(info: Any, channel_count: int) -> tuple[list[str], list[str]]:
    labels: list[str] = []
    units: list[str] = []
    try:
        node = info.desc().child("channels").child("channel")
        for index in range(channel_count):
            if node.empty():
                break
            labels.append(str(node.child_value("label") or f"Channel {index + 1}"))
            units.append(str(node.child_value("unit") or ""))
            node = node.next_sibling()
    except Exception:
        pass
    while len(labels) < channel_count:
        labels.append(f"Channel {len(labels) + 1}")
    while len(units) < channel_count:
        units.append("")
    return labels, units


def _effective_rate(timestamps: list[float], window_seconds: float = 5.0) -> float:
    if len(timestamps) < 2:
        return 0.0
    cutoff = timestamps[-1] - window_seconds
    recent = [stamp for stamp in timestamps if stamp >= cutoff]
    duration = recent[-1] - recent[0] if len(recent) > 1 else 0.0
    return (len(recent) - 1) / duration if duration > 0 else 0.0


def _rmssd_ms(values: list[float]) -> Optional[float]:
    plausible = [value for value in values if math.isfinite(value) and 250.0 <= value <= 2500.0]
    if len(plausible) < 3:
        return None
    diffs = [right - left for left, right in zip(plausible, plausible[1:])]
    return math.sqrt(sum(value * value for value in diffs) / len(diffs)) if diffs else None


def summarize_stream(
    role: str,
    samples: list[list[Any]],
    timestamps: list[float],
    labels: list[str],
    units: list[str],
    nominal_rate_hz: float,
) -> dict[str, Any]:
    """Build concise operator readouts from a rolling sample window."""
    actual_rate = _effective_rate(timestamps)
    latest = samples[-1] if samples else []
    numeric_rows: list[list[float]] = []
    for sample in samples:
        row: list[float] = []
        for value in sample:
            try:
                number = float(value)
            except (TypeError, ValueError):
                number = float("nan")
            row.append(number)
        numeric_rows.append(row)
    role = str(role or "").lower()
    channel_rows: list[dict[str, Any]] = []

    if role == "eeg":
        quality: Optional[float] = None
        quality_rows: list[dict[str, Any]] = []
        try:
            import numpy as np
            from praycg_signal_quality_index_v0_1 import compute_channel_scores

            array = np.asarray(numeric_rows, dtype=float)
            stamps = np.asarray(timestamps, dtype=float)
            if array.ndim == 2 and array.shape[0] >= 10:
                quality_rows, summary = compute_channel_scores(array, stamps, nominal_rate_hz or actual_rate)
                quality = float(summary.get("overall_quality_0_100") or 0.0)
        except Exception:
            quality_rows = []
        for index, value in enumerate(latest):
            score_row = quality_rows[index] if index < len(quality_rows) else {}
            channel_rows.append({
                "channel": labels[index] if index < len(labels) else f"Channel {index + 1}",
                "current": value,
                "unit": units[index] if index < len(units) else "",
                "quality": score_row.get("quality_0_100"),
                "status": score_row.get("status") or "COLLECTING",
            })
        quality_text = f" | rolling quality {quality:.0f}/100" if quality is not None else " | collecting quality"
        return {
            "primary": f"{actual_rate:.1f} Hz actual ({nominal_rate_hz:g} Hz expected){quality_text}",
            "channel_rows": channel_rows,
            "actual_rate_hz": actual_rate,
            "quality_0_100": quality,
        }

    if role == "rr_intervals" and numeric_rows and numeric_rows[-1]:
        rr_values = [row[0] for row in numeric_rows if row and math.isfinite(row[0])]
        latest_rr = rr_values[-1] if rr_values else float("nan")
        bpm = 60000.0 / latest_rr if latest_rr > 0 else float("nan")
        rmssd = _rmssd_ms(rr_values[-60:])
        hrv = f" | rolling RMSSD {rmssd:.1f} ms" if rmssd is not None else " | HRV collecting"
        primary = f"RR {latest_rr:.1f} ms | {bpm:.1f} BPM{hrv}"
    elif role == "respiration" and numeric_rows and numeric_rows[-1]:
        value = numeric_rows[-1][0]
        primary = f"{value:.3f} newtons (current belt force) | {actual_rate:.1f} Hz"
    elif role == "als" and numeric_rows and numeric_rows[-1]:
        values = [row[0] for row in numeric_rows if row and math.isfinite(row[0])]
        current = values[-1] if values else float("nan")
        low, high = (min(values), max(values)) if values else (float("nan"), float("nan"))
        relative = 100.0 * (current - low) / (high - low) if high > low else 0.0
        primary = f"raw {current:.3f} | relative photonic load {relative:.0f}% | {actual_rate:.1f} Hz"
    elif role == "markers":
        primary = str(latest[0]) if latest else "waiting for next marker"
    elif numeric_rows and numeric_rows[-1]:
        rendered = []
        for index, value in enumerate(numeric_rows[-1][:4]):
            label = labels[index] if index < len(labels) else f"Ch {index + 1}"
            unit = units[index] if index < len(units) else ""
            rendered.append(f"{label} {value:.3f} {unit}".strip())
        primary = " | ".join(rendered) + (f" | {actual_rate:.1f} Hz" if actual_rate else "")
    else:
        primary = "waiting for samples"

    for index, value in enumerate(latest):
        channel_rows.append({
            "channel": labels[index] if index < len(labels) else f"Channel {index + 1}",
            "current": value,
            "unit": units[index] if index < len(units) else "",
            "quality": None,
            "status": "LIVE",
        })
    return {"primary": primary, "channel_rows": channel_rows, "actual_rate_hz": actual_rate}


def expected_streams_from_profile(profile: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for module in profile.get("modules", []):
        for stream in module.get("streams", []):
            row = dict(stream)
            key = (str(row.get("lsl_name") or ""), str(row.get("canonical_role") or ""))
            if not key[0] or key in seen:
                continue
            seen.add(key)
            row["module_id"] = module.get("module_id")
            rows.append(row)
    return rows


class StreamWorker(threading.Thread):
    def __init__(self, expected: dict[str, Any], run_uuid: str, updates: queue.Queue, stop: threading.Event):
        super().__init__(daemon=True)
        self.expected = expected
        self.run_uuid = run_uuid
        self.updates = updates
        self.stop = stop

    def _emit(self, **payload: Any) -> None:
        update = {
            "key": f"{self.expected.get('lsl_name')}|{self.expected.get('canonical_role')}",
            "name": self.expected.get("lsl_name"),
            "role": self.expected.get("canonical_role"),
            **payload,
        }
        try:
            self.updates.put_nowait(update)
        except queue.Full:
            # Only the newest rolling status matters. Drop stale UI work rather
            # than letting a hidden or busy monitor consume unbounded memory.
            try:
                self.updates.get_nowait()
            except queue.Empty:
                pass
            try:
                self.updates.put_nowait(update)
            except queue.Full:
                pass

    def run(self) -> None:
        try:
            from pylsl import StreamInlet, resolve_byprop
        except Exception as exc:
            self._emit(status="PYLSL UNAVAILABLE", readout=str(exc), source_id="", channel_rows=[])
            return
        name = str(self.expected.get("lsl_name") or "")
        nominal = float(self.expected.get("nominal_srate") or 0.0)
        while not self.stop.is_set():
            candidates = resolve_byprop("name", name, timeout=1.0)
            info, selection, identities = choose_stream_candidate(candidates, self.expected, self.run_uuid)
            if info is None:
                detail = "; ".join(
                    f"{row['source_id'] or 'no source id'} / {row['run_uuid'] or 'no session id'}"
                    for row in identities
                )
                self._emit(status=selection, readout=detail or "No visible outlet", source_id="", channel_rows=[])
                self.stop.wait(1.0)
                continue
            source_id = str(_safe_stream_value(info, "source_id", "") or "")
            channel_count = int(_safe_stream_value(info, "channel_count", 0) or 0)
            labels, units = _channel_metadata(info, channel_count)
            inlet = StreamInlet(info, max_buflen=15, recover=True)
            try:
                inlet.open_stream(timeout=3.0)
            except TypeError:
                inlet.open_stream()
            except Exception as exc:
                self._emit(status="CONNECTION ERROR", readout=str(exc), source_id=source_id, channel_rows=[])
                try:
                    inlet.close_stream()
                except Exception:
                    pass
                self.stop.wait(1.0)
                continue
            max_samples = max(180, min(10000, int((nominal or 20.0) * 12)))
            samples: deque[list[Any]] = deque(maxlen=max_samples)
            timestamps: deque[float] = deque(maxlen=max_samples)
            connected_at = time.monotonic()
            last_sample_at = 0.0
            last_emit = 0.0
            try:
                while not self.stop.is_set():
                    chunk, stamps = inlet.pull_chunk(timeout=0.25, max_samples=512)
                    if chunk:
                        samples.extend([list(row) for row in chunk])
                        timestamps.extend(float(stamp) for stamp in stamps)
                        last_sample_at = time.monotonic()
                    now = time.monotonic()
                    if now - last_emit >= 0.5:
                        summary = summarize_stream(
                            str(self.expected.get("canonical_role") or ""),
                            list(samples),
                            list(timestamps),
                            labels,
                            units,
                            nominal,
                        )
                        if last_sample_at:
                            age = now - last_sample_at
                            status = "LIVE" if age < (5.0 if nominal == 0 else 2.0) else "NO RECENT DATA"
                        else:
                            status = "CONNECTING" if now - connected_at < 3.0 else "NO DATA"
                        if len(identities) > 1 and status == "LIVE":
                            status = "LIVE — DUPLICATE NAME"
                            summary["primary"] += f" | stop {len(identities) - 1} other same-name outlet(s) before preflight"
                        self._emit(status=status, readout=summary["primary"], source_id=source_id, **summary)
                        last_emit = now
            except Exception as exc:
                self._emit(status="DISCONNECTED", readout=str(exc), source_id=source_id, channel_rows=[])
            finally:
                try:
                    inlet.close_stream()
                except Exception:
                    pass
            self.stop.wait(0.5)


class LiveStreamMonitor:
    def __init__(self, profile: dict[str, Any], run_uuid: str, focus_role: str = ""):
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.profile = profile
        self.run_uuid = run_uuid
        self.expected = expected_streams_from_profile(profile)
        self.focus_role = focus_role
        self.updates: queue.Queue = queue.Queue(maxsize=max(16, len(self.expected) * 4))
        self.stop = threading.Event()
        self.latest: dict[str, dict[str, Any]] = {}
        self.workers: list[StreamWorker] = []
        self._closing = False
        self._drain_after_id: Any = None

        self.root = tk.Tk()
        self.root.title("PRAYCG Live Signal Quality and Stream Monitor")
        self.root.geometry("1160x720")
        self.root.minsize(900, 560)
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text="Live Signal Quality and Stream Monitor", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        session_text = (
            f"Active equipment session: {run_uuid}"
            if run_uuid else "No active equipment session. Values may be viewed, but run-bound checks cannot pass."
        )
        ttk.Label(main, text=session_text, foreground="#1f4e79", wraplength=1100).pack(anchor="w", pady=(2, 2))
        ttk.Label(
            main,
            text=(
                "Read-only display. EEG quality is a rolling engineering proxy, not impedance. Polar HRV is rolling "
                "RMSSD from received RR intervals. ALS load is relative/raw—not calibrated lux—and does not replace the barcode test."
            ),
            foreground="#7a1e1e",
            wraplength=1100,
        ).pack(anchor="w", pady=(0, 8))
        self.tree = ttk.Treeview(
            main,
            columns=("status", "role", "stream", "readout", "source"),
            show="headings",
            height=11,
        )
        for column, title, width in (
            ("status", "State", 165), ("role", "Role", 100), ("stream", "Stream", 180),
            ("readout", "Current live readout", 500), ("source", "Source ID", 250),
        ):
            self.tree.heading(column, text=title)
            self.tree.column(column, width=width, stretch=column in {"readout", "source"})
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._selected)

        detail = ttk.LabelFrame(main, text="Selected stream channels")
        detail.pack(fill="both", expand=True, pady=(8, 0))
        self.channel_tree = ttk.Treeview(
            detail, columns=("channel", "current", "unit", "quality", "status"), show="headings", height=8,
        )
        for column, title, width in (
            ("channel", "Channel", 220), ("current", "Current", 170), ("unit", "Unit", 150),
            ("quality", "Quality 0–100", 130), ("status", "State", 130),
        ):
            self.channel_tree.heading(column, text=title)
            self.channel_tree.column(column, width=width, stretch=column == "channel")
        self.channel_tree.pack(fill="both", expand=True, padx=4, pady=4)
        ttk.Button(main, text="Close Monitor", command=self.close).pack(anchor="e", pady=(8, 0))
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self._start()

    def _start(self) -> None:
        for expected in self.expected:
            key = f"{expected.get('lsl_name')}|{expected.get('canonical_role')}"
            self.tree.insert("", "end", iid=key, values=("SEARCHING", expected.get("canonical_role"), expected.get("lsl_name"), "Looking for outlet…", ""))
            worker = StreamWorker(expected, self.run_uuid, self.updates, self.stop)
            self.workers.append(worker)
            worker.start()
        self._drain_after_id = self.root.after(100, self._drain)

    def _drain(self) -> None:
        try:
            while True:
                update = self.updates.get_nowait()
                key = str(update["key"])
                self.latest[key] = update
                if self.tree.exists(key):
                    self.tree.item(key, values=(update.get("status"), update.get("role"), update.get("name"), update.get("readout"), update.get("source_id")))
                    if self.focus_role and str(update.get("role")) == self.focus_role and not self.tree.selection():
                        self.tree.selection_set(key)
                        self.tree.focus(key)
                        self._show_channels(key)
                if key in self.tree.selection():
                    self._show_channels(key)
        except queue.Empty:
            pass
        if not self.stop.is_set():
            self._drain_after_id = self.root.after(100, self._drain)

    def _selected(self, _event: Any = None) -> None:
        selected = self.tree.selection()
        if selected:
            self._show_channels(selected[0])

    def _show_channels(self, key: str) -> None:
        rows = self.latest.get(key, {}).get("channel_rows", [])
        desired_ids: set[str] = set()
        for index, row in enumerate(rows):
            item_id = str(index)
            desired_ids.add(item_id)
            quality = row.get("quality")
            current = row.get("current")
            try:
                current_text = f"{float(current):.4f}"
            except (TypeError, ValueError):
                current_text = str(current)
            values = (
                row.get("channel"), current_text, row.get("unit"),
                "—" if quality is None else f"{float(quality):.1f}", row.get("status"),
            )
            if self.channel_tree.exists(item_id):
                self.channel_tree.item(item_id, values=values)
            else:
                self.channel_tree.insert("", "end", iid=item_id, values=values)
        for stale_id in set(self.channel_tree.get_children()) - desired_ids:
            self.channel_tree.delete(stale_id)

    def close(self) -> None:
        if self._closing:
            return
        self._closing = True
        self.stop.set()
        if self._drain_after_id is not None:
            try:
                self.root.after_cancel(self._drain_after_id)
            except self.tk.TclError:
                pass
            self._drain_after_id = None
        self.root.destroy()

    def run(self) -> None:
        self.root.mainloop()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--run-uuid", default="")
    parser.add_argument("--focus-role", default="", choices=("", "eeg", "rr_intervals", "respiration", "als"))
    args = parser.parse_args()
    try:
        profile = json.loads(args.profile.read_text(encoding="utf-8"))
    except Exception as exc:
        raise SystemExit(f"Could not load hardware profile: {exc}")
    LiveStreamMonitor(profile, args.run_uuid, args.focus_role).run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
