from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
CONTROL_SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
CONTROL_CENTER_PATH = CONTROL_SCRIPTS / "praycg_control_center_v1_0_0_alpha_8.py"
FORGE_PATH = PACKAGE_ROOT / "tools" / "Hardware_Forge_v0_1" / "praycg_hardware_forge_v0_1.py"
WORKFLOW_PATH = PACKAGE_ROOT / "tools" / "Hardware_Workflow_v0_1" / "praycg_hardware_workflow_v0_1.py"
CERLOG_SCRIPTS = PACKAGE_ROOT / "tools" / "Acquisition" / "Cerelog_ESP_EEG_BrainFlow_v0_1" / "scripts"

for import_root in (CONTROL_SCRIPTS, FORGE_PATH.parent, WORKFLOW_PATH.parent):
    if str(import_root) not in sys.path:
        sys.path.insert(0, str(import_root))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


control = load_module("praycg_alpha84_control_test", CONTROL_CENTER_PATH)
forge = load_module("praycg_alpha84_forge_test", FORGE_PATH)
workflow = load_module("praycg_alpha84_workflow_test", WORKFLOW_PATH)


class Variable:
    def __init__(self, value=""):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value


class Notebook:
    def select(self, index):
        self.selected = index


class DraftModel:
    def __init__(self):
        self.paths: list[Path] = []

    def create_profile_draft(self, path: Path, profile_id: str):
        self.paths.append(path)
        path.write_text(json.dumps({"profile_id": profile_id}), encoding="utf-8")
        return {"modules": [{"module_id": "fixture"}]}


class Alpha84UIAndCerelogTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.tmp_path = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_repeated_draft_refresh_recovers_legacy_name_and_reuses_one_path(self) -> None:
        runaway = self.tmp_path / "config" / "hardware_profiles" / (
            "hardware_profile_draft_20260915_101010_20260915_101011_20260915_101012.json"
        )
        app = object.__new__(control.PRAYCGControlCenter)
        app.cfg = {"praycg_home": str(self.tmp_path), "acquisition": {}}
        app.hardware_workflow_model = DraftModel()
        app.hardware_profile_draft_path_var = Variable(str(runaway))
        app.hardware_profile_draft_status_var = Variable()
        app.acq_nb = Notebook()
        app.save_config = lambda: None

        app.create_hardware_profile_draft()
        app.create_hardware_profile_draft()

        expected = runaway.with_name("hardware_profile_draft.json").resolve()
        assert app.hardware_workflow_model.paths == [expected, expected]
        assert app.hardware_profile_draft_path_var.get() == str(expected)
        assert expected.is_file()
        assert app.acq_nb.selected == 1


    def test_custom_draft_filename_is_stable_and_not_timestamped(self) -> None:
        custom = self.tmp_path / "my_review_draft.json"
        assert control.PRAYCGControlCenter.canonical_hardware_profile_draft_path(str(custom), self.tmp_path) == custom.resolve()

    def test_review_target_recovers_live_legacy_draft_path_before_filesystem_io(self) -> None:
        profiles = self.tmp_path / "config" / "hardware_profiles"
        profiles.mkdir(parents=True)
        draft = profiles / "hardware_profile_draft.json"
        draft.write_text("{}", encoding="utf-8")
        active = profiles / "active_hardware_profile.json"
        active.write_text("{}", encoding="utf-8")
        legacy_name = "hardware_profile_draft" + "_20260914_130052" * 14 + ".json"
        configured = profiles / legacy_name

        target = control.PRAYCGControlCenter.canonical_reviewed_hardware_profile_path(
            str(configured),
            draft,
            stamp="20260915_160000",
        )

        assert target == profiles / "active_hardware_profile_20260915_160000.json"
        assert len(str(target)) < 230
        assert not target.name.startswith("hardware_profile_draft")

    def test_review_target_history_suffix_never_grows_recursively(self) -> None:
        profiles = self.tmp_path / "hardware_profiles"
        profiles.mkdir()
        draft = profiles / "hardware_profile_draft.json"
        active = profiles / "active_hardware_profile.json"
        active.write_text("{}", encoding="utf-8")
        first_version = profiles / "active_hardware_profile_20260915_160000.json"
        first_version.write_text("{}", encoding="utf-8")

        target = control.PRAYCGControlCenter.canonical_reviewed_hardware_profile_path(
            str(first_version),
            draft,
            stamp="20260915_160000",
        )

        assert target == profiles / "active_hardware_profile_20260915_160000_2.json"


    def test_protocol_actions_are_grouped_in_requested_order(self) -> None:
        source = CONTROL_CENTER_PATH.read_text(encoding="utf-8")
        start = source.index("    def build_protocol_atlas_tab")
        end = source.index("    def build_runner_tab", start)
        block = source[start:end]
        assert block.index('text="Change Protocol"') < block.index('text="Create New Protocol with AI Docs…"')
        assert block.index('text="Validate / Compile Existing Module…"') < block.index('text="Prospective Assignment Tools…"')
        assert 'selection_actions = ttk.Frame(actions)' in block
        assert 'module_actions = ttk.Frame(actions)' in block


    def test_runner_summary_explains_each_pre_arm_gate(self) -> None:
        app = object.__new__(control.PRAYCGControlCenter)
        protocol = {
            "protocol_id": "ATLAS_FIXTURE",
            "protocol_version": "1.0",
            "module_family": control.FAMILY_ATLAS,
        }
        app.cfg = {"acquisition": {"readiness_status": "PASS", "readiness_message": "required live checks passed", "session_lock_status": "VALID", "armed": False}}
        app.active_hardware_profile = {"profile_id": "fixture_profile", "status": "APPROVED"}
        app.locked_protocol_record = lambda: protocol
        app.resolve_atlas_asset_snapshot = lambda selected: ({"selections": {"fixture": {"sha256": "a" * 64}}}, [])

        rows = app.runner_locked_input_rows()

        assert [row["label"] for row in rows] == [
            "Protocol snapshot",
            "Stimulus / materials",
            "Hardware profile",
            "Live pre-arm checks",
            "Confirmed session setup",
            "ARM state",
        ]
        assert [row["status"] for row in rows[:-1]] == ["PASS"] * 5
        assert rows[-1]["status"] == "READY TO ARM"
        assert all(row["detail"] for row in rows)


    def test_cerelog_brainflow_route_is_visible_but_quarantined(self) -> None:
        catalog_path = PACKAGE_ROOT / "config" / "hardware_adapter_catalog_v0_1.json"
        report = forge.validate_catalog(catalog_path)
        assert report["status"] == "PASS"
        inventory = workflow.load_hardware_inventory(catalog_path=catalog_path)
        choice = next(row for row in inventory["choices"] if row["choice_id"] == "adapter:cerelog_esp_eeg_brainflow:custom_brainflow_x8")
        assert choice["admission_state"] == "QUARANTINED"
        assert choice["launch_state"] == "WITHHELD"
        validation = workflow.validate_role_selection("eeg", choice["choice_id"], inventory=inventory)
        assert validation["profile_eligible"] is False
        assert any("quarantined" in error.lower() for error in validation["errors"])


    def test_cerelog_tools_and_safety_acknowledgement_are_packaged(self) -> None:
        expected = {
            "praycg_cerelog_brainflow_common_v0_1.py",
            "praycg_cerelog_brainflow_to_lsl_v0_1.py",
            "praycg_cerelog_brainflow_record_v0_1.py",
        }
        assert expected.issubset({path.name for path in CERLOG_SCRIPTS.glob("*.py")})
        publisher = (CERLOG_SCRIPTS / "praycg_cerelog_brainflow_to_lsl_v0_1.py").read_text(encoding="utf-8")
        assert "outlet.push_chunk" in publisher
        assert "pushthrough=True" in publisher
        common = load_module("praycg_cerelog_common_safety_test", CERLOG_SCRIPTS / "praycg_cerelog_brainflow_common_v0_1.py")
        args = type("Args", (), {"acknowledge_battery_only": False})()
        try:
            common.require_safety_acknowledgement(args)
        except RuntimeError as exc:
            assert "NON-ISOLATED" in str(exc)
            assert "battery-powered" in str(exc)
        else:
            raise AssertionError("The battery-only safety acknowledgement was not enforced")
