from __future__ import annotations

import importlib.util
from pathlib import Path
import unittest


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
DIAGNOSTICS_PATH = PACKAGE_ROOT / "tools" / "Acquisition" / "praycg_acquisition_diagnostics_v1_0.py"
ALS_BRIDGE_PATH = (
    PACKAGE_ROOT
    / "tools"
    / "Acquisition"
    / "BrainFlow_ALS_PT19_Bridge_v1_5"
    / "scripts"
    / "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py"
)
EEG_BRIDGE_PATH = (
    PACKAGE_ROOT
    / "tools"
    / "Acquisition"
    / "BrainFlow_EEGOnly_Home_Bridge_v1_1"
    / "scripts"
    / "praycg_openbci_brainflow_eeg_to_lsl_v1_1.py"
)
CONTROL_CENTER_PATH = PACKAGE_ROOT / "control_center" / "scripts" / "praycg_control_center_v1_0_0_alpha_8.py"


def load_diagnostics():
    spec = importlib.util.spec_from_file_location("praycg_acquisition_diagnostics_alpha82_test", DIAGNOSTICS_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


class BrainFlowTransportAlpha82Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.diagnostics = load_diagnostics()

    def test_cyton_daisy_native_step_has_no_false_packet_loss(self) -> None:
        counts, last_packet, gaps = self.diagnostics.analyze_package_numbers(
            [250, 252, 254, 0, 2],
            None,
            expected_step=2,
        )
        self.assertEqual(counts, {"missing": 0, "duplicates": 0, "out_of_order": 0})
        self.assertEqual(last_packet, 2)
        self.assertEqual(gaps, [1, 1, 1, 1, 1])

    def test_cyton_daisy_real_gap_counts_missing_samples_not_counter_ticks(self) -> None:
        counts, _last_packet, gaps = self.diagnostics.analyze_package_numbers(
            [10, 12, 16],
            None,
            expected_step=2,
        )
        self.assertEqual(counts["missing"], 1)
        self.assertEqual(gaps, [1, 1, 2])

    def test_reconstructed_daisy_timestamps_keep_125_hz_cadence(self) -> None:
        stamps, _last_packet, _last_stamp, counts, max_gap = self.diagnostics.reconstruct_lsl_timestamps(
            4,
            125.0,
            [0, 2, 4, 6],
            None,
            None,
            100.0,
            expected_package_step=2,
        )
        self.assertEqual(counts["missing"], 0)
        self.assertAlmostEqual(max_gap, 1.0 / 125.0)
        self.assertAlmostEqual(stamps[-1], 100.0)
        self.assertTrue(all(abs((b - a) - (1.0 / 125.0)) < 1e-9 for a, b in zip(stamps, stamps[1:])))

    def test_bridges_use_explicit_flushed_chunks(self) -> None:
        als_source = ALS_BRIDGE_PATH.read_text(encoding="utf-8")
        eeg_source = EEG_BRIDGE_PATH.read_text(encoding="utf-8")
        self.assertNotIn("pushthrough=False", als_source)
        self.assertNotIn("pushthrough=False", eeg_source)
        self.assertGreaterEqual(als_source.count("chunk_size=0"), 3)
        self.assertIn("eeg_outlet.push_chunk(eeg.tolist(), timestamp=ts_list, pushthrough=True)", als_source)
        self.assertIn("outlet.push_chunk(eeg.tolist(), timestamp=stamps, pushthrough=True)", eeg_source)

    def test_duplicate_bridge_launch_is_blocked_in_control_center(self) -> None:
        source = CONTROL_CENTER_PATH.read_text(encoding="utf-8")
        self.assertIn("Equipment bridge already running", source)
        self.assertIn("A second copy was not started", source)
        self.assertIn('APP_VERSION = "1.0.0-alpha.8.5.4"', source)

    def test_live_consumers_explicitly_open_their_streams(self) -> None:
        monitor = (PACKAGE_ROOT / "control_center" / "scripts" / "praycg_live_stream_monitor_v1_0.py").read_text(encoding="utf-8")
        preflight = (PACKAGE_ROOT / "tools" / "Hardware_Registry_v0_1" / "praycg_hardware_registry_v0_1.py").read_text(encoding="utf-8")
        self.assertIn("inlet.open_stream(timeout=3.0)", monitor)
        self.assertEqual(monitor.count("inlet.open_stream(timeout="), 1)
        self.assertNotIn("inlet.open_stream(timeout=2.0)", monitor)
        self.assertIn("open_stream(timeout=2.0)", preflight)
        self.assertIn('"reason": "STREAM_CONNECTION_FAILED"', preflight)

    def test_streaming_memory_is_bounded(self) -> None:
        monitor = (PACKAGE_ROOT / "control_center" / "scripts" / "praycg_live_stream_monitor_v1_0.py").read_text(encoding="utf-8")
        als_source = ALS_BRIDGE_PATH.read_text(encoding="utf-8")
        eeg_source = EEG_BRIDGE_PATH.read_text(encoding="utf-8")
        self.assertIn("queue.Queue(maxsize=", monitor)
        self.assertIn("except queue.Full", monitor)
        self.assertNotIn("default=450000", als_source)
        self.assertNotIn("default=450000", eeg_source)
        self.assertIn("default=45000", als_source)
        self.assertIn("default=45000", eeg_source)


if __name__ == "__main__":
    unittest.main()
