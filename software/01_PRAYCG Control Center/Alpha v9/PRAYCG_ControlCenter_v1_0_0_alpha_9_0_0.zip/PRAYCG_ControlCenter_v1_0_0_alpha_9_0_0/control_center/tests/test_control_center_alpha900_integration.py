from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "control_center" / "scripts" / "praycg_control_center_v1_0_0_alpha_9.py"
if str(SCRIPT.parent) not in sys.path:
    sys.path.insert(0, str(SCRIPT.parent))
SPEC = importlib.util.spec_from_file_location("praycg_control_center_alpha9", SCRIPT)
assert SPEC and SPEC.loader
cc = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = cc
SPEC.loader.exec_module(cc)


def test_alpha9_release_identity_and_config_schema() -> None:
    assert cc.APP_VERSION == "1.0.0-alpha.9.0.0"
    assert cc.CONFIG_SCHEMA == "PRAYCG_ControlCenter_Config_v1_0_alpha_9"
    config = cc.default_config()
    assert config["version"] == cc.APP_VERSION
    assert config["schema"] == cc.CONFIG_SCHEMA


def test_alpha9_bundled_adapter_tools_exist() -> None:
    paths = cc.bundled_tool_paths()
    for key in (
        "hardware_forge", "generic_lsl_intake", "stream_contract_validator",
        "contract_acquisition_supervisor",
    ):
        assert Path(paths[key]).is_file(), (key, paths[key])
    assert "Hardware_Forge_v1_0" in paths["hardware_forge"]
    assert "Acquisition_Supervisor_v1_0" in paths["contract_acquisition_supervisor"]


def test_alpha9_control_center_exposes_new_workflows() -> None:
    assert hasattr(cc.PRAYCGControlCenter, "launch_generic_lsl_intake")
    assert hasattr(cc.PRAYCGControlCenter, "run_contract_acquisition_supervisor")
    source = SCRIPT.read_text(encoding="utf-8")
    assert "Discover Existing LSL" in source
    assert "Contract-Bound Drift / Sync Observation" in source


def test_protocol_catalogs_bind_to_alpha9_package() -> None:
    for name in (
        "praycg_mature_endpoint_atlas_catalog_v1_0.json",
        "public_dataset_protocol_catalog_v1_0.json",
    ):
        payload = json.loads((ROOT / "config" / name).read_text(encoding="utf-8"))
        assert payload["base_platform"] == ROOT.name
