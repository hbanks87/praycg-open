from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from types import MethodType, SimpleNamespace


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_ROOT = PACKAGE_ROOT / "control_center" / "scripts"
CONTROL_CENTER_PATH = SCRIPTS_ROOT / "praycg_control_center_v1_0_0_alpha_8.py"
HARDWARE_WORKFLOW_PATH = (
    PACKAGE_ROOT / "tools" / "Hardware_Workflow_v0_1" / "praycg_hardware_workflow_v0_1.py"
)

if str(SCRIPTS_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_ROOT))


def _load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


control_center = _load_module("praycg_control_center_alpha5_click_gate_test", CONTROL_CENTER_PATH)
hardware_workflow = _load_module("praycg_hardware_workflow_alpha5_click_gate_test", HARDWARE_WORKFLOW_PATH)


class _ValueSink:
    def __init__(self) -> None:
        self.value = None

    def set(self, value) -> None:
        self.value = value


class _FrameSink:
    def winfo_children(self):
        return ()

    def columnconfigure(self, *_args, **_kwargs) -> None:
        pass


class _WidgetSink:
    def __init__(self, _parent, **kwargs) -> None:
        self.options = dict(kwargs)
        self.command = kwargs.get("command")

    def configure(self, **kwargs) -> None:
        self.options.update(kwargs)

    def grid(self, **_kwargs) -> None:
        pass

    def pack(self, **_kwargs) -> None:
        pass

    def invoke(self):
        assert self.command is not None
        return self.command()


class _MenuSink:
    def __init__(self, _parent, **_kwargs) -> None:
        self.commands: dict[str, object] = {}

    def add_command(self, *, label, command) -> None:
        self.commands[str(label)] = command


def _reviewed_profile(
    root: Path,
    *,
    stem: str,
    profile_id: str,
    role_group: str,
    choice_id: str,
):
    model = hardware_workflow.HardwareWorkflowModel()
    selection = model.validate_and_select(role_group, choice_id)
    assert selection["profile_eligible"] is True
    draft_path = root / f"{stem}_draft.json"
    profile_path = root / f"{stem}_profile.json"
    lock_path = root / f"{stem}_ui_lock.json"
    model.create_profile_draft(draft_path, profile_id=profile_id)
    profile = hardware_workflow.review_hardware_profile_draft(
        draft_path,
        profile_path,
        reviewed_by="Click Gate Test Reviewer",
    )
    lock = hardware_workflow.lock_hardware_profile(profile_path, output_path=lock_path)
    return profile_path, profile, lock_path, lock


def _app(profile_path: Path, lock_path: Path, lock: dict, **handlers):
    app = SimpleNamespace(
        cfg={
            "acquisition": {
                "hardware_profile_path": str(profile_path),
                "hardware_ui_lock_path": str(lock_path),
            }
        },
        hardware_ui_lock=lock,
        hardware_launch_frame=_FrameSink(),
        hardware_launch_status_var=_ValueSink(),
        **handlers,
    )
    app.launch_locked_hardware_action = MethodType(
        control_center.PRAYCGControlCenter.launch_locked_hardware_action,
        app,
    )
    return app


def _patch_widgets(monkeypatch) -> None:
    monkeypatch.setattr(control_center.ttk, "Button", _WidgetSink)
    monkeypatch.setattr(control_center.ttk, "Menubutton", _WidgetSink)
    monkeypatch.setattr(control_center.tk, "Menu", _MenuSink)


def test_rendered_button_blocks_a_valid_profile_and_ui_lock_switch_before_click(
    tmp_path: Path,
    monkeypatch,
) -> None:
    profile_path, _payload_a, lock_path, lock_a = _reviewed_profile(
        tmp_path,
        stem="rig_a",
        profile_id="rig_a",
        role_group="cardiac",
        choice_id="module:polar_h10_rr",
    )
    launches: list[str] = []
    errors: list[str] = []
    app = _app(profile_path, lock_path, lock_a, launch_polar=lambda: launches.append("polar"))
    _patch_widgets(monkeypatch)
    monkeypatch.setattr(
        control_center.messagebox,
        "showerror",
        lambda _title, message, **_kwargs: errors.append(str(message)),
    )

    control_center.PRAYCGControlCenter.render_hardware_launch_actions(app)
    stale_button = app.hardware_launch_buttons["launch_polar_h10_rr"]
    replacement_model = hardware_workflow.HardwareWorkflowModel()
    replacement = replacement_model.validate_and_select("cardiac", "module:polar_h10_rr")
    assert replacement["profile_eligible"] is True
    replacement_draft = tmp_path / "rig_b_draft.json"
    replacement_model.create_profile_draft(replacement_draft, profile_id="rig_b")
    payload_b = hardware_workflow.review_hardware_profile_draft(
        replacement_draft,
        profile_path,
        reviewed_by="Replacement Click Gate Test Reviewer",
    )
    lock_b = hardware_workflow.lock_hardware_profile(profile_path, output_path=lock_path)
    assert hardware_workflow.derive_launch_actions(profile_path, lock_b)["status"] in {"PASS", "CAUTION"}
    app.active_hardware_profile = payload_b
    app.hardware_ui_lock = lock_b

    assert stale_button.invoke() is False
    assert launches == []
    assert any("hardware UI lock changed after these controls were rendered" in message for message in errors)


def test_rendered_button_rereads_and_blocks_a_tampered_saved_ui_lock(
    tmp_path: Path,
    monkeypatch,
) -> None:
    profile_path, _payload, lock_path, lock = _reviewed_profile(
        tmp_path,
        stem="saved_lock",
        profile_id="saved_lock",
        role_group="cardiac",
        choice_id="module:polar_h10_rr",
    )
    launches: list[str] = []
    errors: list[str] = []
    app = _app(profile_path, lock_path, lock, launch_polar=lambda: launches.append("polar"))
    _patch_widgets(monkeypatch)
    monkeypatch.setattr(
        control_center.messagebox,
        "showerror",
        lambda _title, message, **_kwargs: errors.append(str(message)),
    )

    control_center.PRAYCGControlCenter.render_hardware_launch_actions(app)
    stale_button = app.hardware_launch_buttons["launch_polar_h10_rr"]
    tampered_lock = json.loads(lock_path.read_text(encoding="utf-8"))
    tampered_lock["arm_authority"] = True
    lock_path.write_text(json.dumps(tampered_lock), encoding="utf-8")

    assert stale_button.invoke() is False
    assert launches == []
    assert any("differs from its saved record" in message for message in errors)


def test_click_gate_dispatches_only_the_exact_rendered_menu_variant(
    tmp_path: Path,
    monkeypatch,
) -> None:
    profile_path, _payload, lock_path, lock = _reviewed_profile(
        tmp_path,
        stem="vernier",
        profile_id="vernier",
        role_group="respiration",
        choice_id="module:vernier_respiration",
    )
    launches: list[str] = []
    errors: list[str] = []
    app = _app(
        profile_path,
        lock_path,
        lock,
        launch_vernier=lambda connection: launches.append(connection),
    )
    _patch_widgets(monkeypatch)
    monkeypatch.setattr(
        control_center.messagebox,
        "showerror",
        lambda _title, message, **_kwargs: errors.append(str(message)),
    )

    control_center.PRAYCGControlCenter.render_hardware_launch_actions(app)
    widget = app.hardware_launch_buttons["launch_vernier_respiration"]
    menu = widget.options["menu"]

    assert menu.commands["USB"]() is True
    assert launches == ["usb"]
    assert app.launch_locked_hardware_action("launch_vernier_respiration", "serial") is False
    assert launches == ["usb"]
    assert any("chosen transport variant" in message for message in errors)
    assert lock["session_lock_authority"] is False
    assert lock["arm_authority"] is False
    assert lock["acquisition_authority"] is False
