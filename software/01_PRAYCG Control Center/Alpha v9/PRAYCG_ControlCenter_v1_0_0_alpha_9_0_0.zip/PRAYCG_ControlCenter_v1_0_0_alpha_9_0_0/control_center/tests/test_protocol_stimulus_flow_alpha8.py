from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import pytest


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

from praycg_protocol_stimulus_flow_v1_0 import (  # noqa: E402
    MASTER_MEDIA_TAG,
    ProtocolStimulusWorkflowModel,
    WorkflowSelectionError,
)


@pytest.fixture(scope="module")
def model() -> ProtocolStimulusWorkflowModel:
    return ProtocolStimulusWorkflowModel(PACKAGE_ROOT, media_probe=False)


def _lock(model: ProtocolStimulusWorkflowModel, tmp_path: Path, protocol_id: str, version: str) -> Path:
    path = tmp_path / f"{protocol_id}.lock.json"
    model.lock_protocol(f"protocol::{protocol_id}::{version}", path)
    return path


def _catalog_pack(model: ProtocolStimulusWorkflowModel, pack_id: str) -> tuple[Path, dict]:
    catalog = json.loads(
        (model.stimulus_tool_root / "config" / "stimulus_pack_catalog_v1_0.json").read_text(encoding="utf-8")
    )
    entry = next(row for row in catalog["packs"] if row["pack_id"] == pack_id)
    root = model.package_root / entry["package_relative_root"]
    manifest = json.loads((root / "stimulus_pack_manifest.json").read_text(encoding="utf-8"))
    return root, manifest


def _write_registry(path: Path, *, stimuli=None, packs=None) -> Path:
    path.write_text(
        json.dumps({"schema": "PRAYCG_StimulusRegistry_v1_0", "stimuli": stimuli or [], "packs": packs or []}),
        encoding="utf-8",
    )
    return path


def _master_row(tmp_path: Path, *, tagged: bool = True, good_hash: bool = True) -> dict:
    folder = tmp_path / "MASTER_A"
    master_dir = folder / "master"
    master_dir.mkdir(parents=True, exist_ok=True)
    # Enough of an ISO-BMFF header for the model's dependency-free container
    # check. The legacy registry is also required to carry its earlier media-
    # validation result; this fixture does not claim codec-level validity.
    video = master_dir / "stimulus_master.mp4"
    video.write_bytes(b"\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2")
    digest = hashlib.sha256(video.read_bytes()).hexdigest()
    return {
        "stimulus_id": "MASTER_A",
        "folder": str(folder),
        "master_mp4": str(video),
        "sha256": digest if good_hash else "0" * 64,
        "validation_status": "PASS_BASIC_VALIDATION",
        "tags": [MASTER_MEDIA_TAG] if tagged else ["SOMETHING_ELSE"],
    }


def test_catalog_cross_validation_covers_all_release_protocols(model: ProtocolStimulusWorkflowModel) -> None:
    report = model.catalog_validation()
    assert report["status"] == "PASS", report["errors"]
    assert report["facts"]["protocol_count"] == 43
    assert report["facts"]["workflow_count"] == 43
    assert report["facts"]["frozen_stimulus_catalog_count"] == 14
    assert report["facts"]["public_dataset_catalog_count"] == 12
    assert report["facts"]["mature_endpoint_catalog_count"] == 17
    assert report["facts"]["engine_count"] == 15


def test_protocol_navigation_is_tree_based_not_dropdown_based(model: ProtocolStimulusWorkflowModel) -> None:
    result = model.protocol_navigation()
    protocols = [row for row in result["nodes"] if row["node_type"] == "protocol"]
    folders = [row for row in result["nodes"] if row["node_type"] == "folder"]
    assert result["navigation_mode"] == "TREE_FILE_NAVIGATION"
    assert len(protocols) == 43
    assert folders
    assert all(row["parent_id"].startswith("protocol-folder::") for row in protocols)
    assert all(row["workflow_status"] == "READY_TO_LOCK" for row in protocols)


def test_mature_runner_generated_protocol_needs_no_stimulus_pack(
    model: ProtocolStimulusWorkflowModel, tmp_path: Path
) -> None:
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "ATLAS_PRAYCG_T_TRUST_OFFLOADING", "1.0")
    )
    assert result["status"] == "READY"
    assert result["compatible_stimuli"] == []
    assert result["excluded_stimuli"] == []
    assert result["prep_engines"] == []
    assert result["workflow"]["preparation_mode"] == "MATURE_RUNNER_GENERATED"
    assert result["workflow"]["required_asset_keys"] == []
    assert result["recommended_launch_action"]["action_id"] == "no_external_stimulus_required"
    assert "runner-generated" in result["plain_language"]


def test_mature_media_protocol_uses_hash_locked_atlas_asset_folder(
    model: ProtocolStimulusWorkflowModel, tmp_path: Path
) -> None:
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "ATLAS_PRAYCG_G_MATURE_GRADIENT", "2.0")
    )
    assert result["status"] == "READY"
    assert result["compatible_stimuli"] == []
    assert result["excluded_stimuli"] == []
    assert result["workflow"]["preparation_mode"] == "MATURE_PROTOCOL_ASSET_FOLDER"
    assert set(result["workflow"]["required_asset_keys"]) == {
        "phase_scrambled_video",
        "shot_order_video",
        "semantic_zero_video",
        "target_override_video",
        "reviewed_media_manifest",
        "locked_anchor_schedule",
        "stimulus_fingerprint_manifest",
    }
    assert result["recommended_launch_action"]["action_id"] == "choose_protocol_files"
    assert "paths and hashes" in result["plain_language"]


def test_praycg3_lock_filters_samples_and_prefills_mediaprep(model: ProtocolStimulusWorkflowModel, tmp_path: Path) -> None:
    result = model.resolve_locked_workflow(_lock(model, tmp_path, "PRAYCG3", "3.0"))
    visible = [row for row in result["compatible_stimuli"] if row["source_kind"] == "BUNDLED_SAMPLE_PACK"]
    assert result["status"] == "READY"
    assert [row["pack_id"] for row in visible] == ["PRAYCG_NATIVE_STORY_DEMO_V1"]
    assert result["recommended_launch_action"]["action_id"] == "launch_mediaprep"
    assert result["recommended_launch_action"]["prefill_protocol_id"] == "PRAYCG3"
    assert result["stimulus_navigation_mode"] == "TREE_FILE_NAVIGATION"
    assert any(row.get("candidate_id") == "bundled::PRAYCG_NATIVE_STORY_DEMO_V1" for row in result["stimulus_nodes"])


def test_praycg4_exposes_shot_order_pipeline_only_for_matching_lock(
    model: ProtocolStimulusWorkflowModel, tmp_path: Path
) -> None:
    praycg4 = model.resolve_locked_workflow(_lock(model, tmp_path, "PRAYCG4", "4.0"))
    praycg3 = model.resolve_locked_workflow(_lock(model, tmp_path, "PRAYCG3", "3.0"))
    p4_engines = {row["id"] for row in praycg4["prep_engines"]}
    p3_engines = {row["id"] for row in praycg3["prep_engines"]}
    assert "shot_order_scramble" in p4_engines
    assert "shot_order_scramble" not in p3_engines
    shot = next(row for row in praycg4["prep_engines"] if row["id"] == "shot_order_scramble")
    assert shot["stage_role"] == "PIPELINE_STAGE"
    assert shot["direct_launch_allowed"] is False


def test_storyboard_protocol_gets_storybook_tools_not_unrelated_audio_tools(
    model: ProtocolStimulusWorkflowModel, tmp_path: Path
) -> None:
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "ATLAS_SVNA_GUTTER_RANKING_ADAPTATION", "1.0")
    )
    engine_ids = {row["id"] for row in result["prep_engines"]}
    assert "illustrated_storybook" in engine_ids
    assert "svna_strip_generator" in engine_ids
    assert "audio_story_bundle" not in engine_ids
    assert result["recommended_launch_action"]["prefill_engine_id"] == "illustrated_storybook"


def test_valid_tagged_master_is_visible_to_native_protocol(model: ProtocolStimulusWorkflowModel, tmp_path: Path) -> None:
    registry = _write_registry(tmp_path / "registry.json", stimuli=[_master_row(tmp_path)])
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "PRAYCG3", "3.0"), stimulus_registry_path=registry
    )
    masters = [row for row in result["compatible_stimuli"] if row["source_kind"] == "MASTER_PRAYCG_MEDIA"]
    assert len(masters) == 1
    assert masters[0]["status"] == "AVAILABLE_FOR_PREPARATION"
    assert masters[0]["participant_acquisition_eligible"] is False
    assert MASTER_MEDIA_TAG in masters[0]["why_visible"]


@pytest.mark.parametrize("tagged,good_hash", [(False, True), (True, False)])
def test_untagged_or_hash_changed_master_fails_closed(
    model: ProtocolStimulusWorkflowModel, tmp_path: Path, tagged: bool, good_hash: bool
) -> None:
    registry = _write_registry(
        tmp_path / f"registry-{tagged}-{good_hash}.json",
        stimuli=[_master_row(tmp_path / f"case-{tagged}-{good_hash}", tagged=tagged, good_hash=good_hash)],
    )
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "PRAYCG3", "3.0"), stimulus_registry_path=registry
    )
    assert not [row for row in result["compatible_stimuli"] if row["source_kind"] == "MASTER_PRAYCG_MEDIA"]
    excluded = next(row for row in result["excluded_stimuli"] if row["candidate_id"] == "master::MASTER_A")
    assert excluded["status"] == "BLOCKED"


def test_tagged_master_is_not_visible_to_atlas_protocol(model: ProtocolStimulusWorkflowModel, tmp_path: Path) -> None:
    registry = _write_registry(tmp_path / "registry.json", stimuli=[_master_row(tmp_path)])
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "ATLAS_NATVIEW_REPEATED_VIDEO_ADAPTATION", "1.0"),
        stimulus_registry_path=registry,
    )
    assert not [row for row in result["compatible_stimuli"] if row["source_kind"] == "MASTER_PRAYCG_MEDIA"]
    excluded = next(row for row in result["excluded_stimuli"] if row["candidate_id"] == "master::MASTER_A")
    assert "does not accept" in " ".join(excluded["reasons"])


def test_inactive_installed_pack_fails_closed(model: ProtocolStimulusWorkflowModel, tmp_path: Path) -> None:
    root, manifest = _catalog_pack(model, "PRAYCG_NATIVE_STORY_DEMO_V1")
    registry = _write_registry(
        tmp_path / "registry.json",
        packs=[{
            "pack_id": manifest["pack_id"],
            "pack_version": manifest["pack_version"],
            "path": str(root),
            "manifest_content_sha256": manifest["manifest_content_sha256"],
            "validation_status": "PASS",
            "active_for_selection": False,
        }],
    )
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "PRAYCG3", "3.0"), stimulus_registry_path=registry
    )
    installed = [row for row in result["compatible_stimuli"] if row["source_kind"] == "INSTALLED_PACK"]
    assert installed == []
    assert any("inactive" in " ".join(row["reasons"]) for row in result["excluded_stimuli"])


def test_live_valid_but_incompatible_installed_pack_fails_closed(
    model: ProtocolStimulusWorkflowModel, tmp_path: Path
) -> None:
    root, manifest = _catalog_pack(model, "PRAYCG_NARR_SOUND_STORY_DEMO_V1")
    registry = _write_registry(
        tmp_path / "registry.json",
        packs=[{
            "pack_id": manifest["pack_id"],
            "pack_version": manifest["pack_version"],
            "path": str(root),
            "manifest_content_sha256": manifest["manifest_content_sha256"],
            "validation_status": "PASS",
            "active_for_selection": True,
        }],
    )
    result = model.resolve_locked_workflow(
        _lock(model, tmp_path, "PRAYCG3", "3.0"), stimulus_registry_path=registry
    )
    installed_id = f"installed::{manifest['pack_id']}::"
    blocked = next(row for row in result["excluded_stimuli"] if row["candidate_id"].startswith(installed_id))
    assert blocked["selection_allowed"] is False
    assert "does not declare exactly one compatibility row" in " ".join(blocked["reasons"])


def test_stale_candidate_is_revalidated_before_prefill(model: ProtocolStimulusWorkflowModel, tmp_path: Path) -> None:
    lock_path = _lock(model, tmp_path, "PRAYCG3", "3.0")
    result = model.preflight_candidate_for_locked_protocol(lock_path, "installed::NOT_REAL::000000000000")
    assert result["status"] == "BLOCKED"
    assert "inactive, unvalidated, incompatible, missing, or ambiguous" in result["reasons"][0]


def test_missing_or_tampered_lock_leaves_next_tab_empty(model: ProtocolStimulusWorkflowModel, tmp_path: Path) -> None:
    missing = model.resolve_locked_workflow(tmp_path / "missing.lock.json")
    assert missing["status"] == "BLOCKED"
    assert missing["stimulus_nodes"] == []
    lock_path = _lock(model, tmp_path, "PRAYCG3", "3.0")
    payload = json.loads(lock_path.read_text(encoding="utf-8"))
    payload["manifest_sha256"] = "0" * 64
    lock_path.write_text(json.dumps(payload), encoding="utf-8")
    tampered = model.resolve_locked_workflow(lock_path)
    assert tampered["status"] == "BLOCKED"
    assert tampered["stimulus_nodes"] == []


def test_unknown_engine_in_workflow_catalog_blocks_catalog(tmp_path: Path, model: ProtocolStimulusWorkflowModel) -> None:
    source = json.loads(model.workflow_config_path.read_text(encoding="utf-8"))
    source["protocols"][0]["direct_engines"][0] = "download_and_execute_anything"
    bad = tmp_path / "bad-workflow.json"
    bad.write_text(json.dumps(source), encoding="utf-8")
    report = ProtocolStimulusWorkflowModel(
        PACKAGE_ROOT, workflow_config_path=bad, media_probe=False
    ).catalog_validation()
    assert report["status"] == "FAIL"
    assert any("unregistered engine" in error for error in report["errors"])


def test_unknown_protocol_navigation_id_cannot_be_locked(model: ProtocolStimulusWorkflowModel, tmp_path: Path) -> None:
    with pytest.raises(WorkflowSelectionError, match="did not resolve exactly once"):
        model.lock_protocol("protocol::UNKNOWN::1.0", tmp_path / "bad.lock.json")
