from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch


PACKAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE / "platform_core"))

import praycg_platform_core_v1_0_alpha_2 as alpha2  # noqa: E402
import praycg_platform_core_v1_0_alpha_3 as alpha3  # noqa: E402


class WindowsPidProbeRegressionTests(unittest.TestCase):
    def test_current_process_is_live(self) -> None:
        for module in (alpha2, alpha3):
            with self.subTest(module=module.__name__):
                self.assertTrue(module._pid_exists(os.getpid()))
                self.assertEqual(
                    module._process_identity_state(
                        os.getpid(), module.process_start_identity(os.getpid())
                    ),
                    "LIVE",
                )

    def test_stale_windows_pid_is_dead_without_os_kill(self) -> None:
        stale_pid = 2_147_483_647
        for module in (alpha2, alpha3):
            with self.subTest(module=module.__name__):
                with patch.object(
                    module.os,
                    "kill",
                    side_effect=SystemError("OSError returned a result with an exception set"),
                ) as kill:
                    self.assertFalse(module._pid_exists(stale_pid))
                    self.assertEqual(
                        module._process_identity_state(stale_pid, "windows_filetime:stale"),
                        "DEAD",
                    )
                    if os.name == "nt":
                        kill.assert_not_called()


if __name__ == "__main__":
    unittest.main()
