from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
CONTROL_SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
ATLAS_ROOT = PACKAGE_ROOT / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0"
ATLAS_SCRIPTS = ATLAS_ROOT / "scripts"
for value in (CONTROL_SCRIPTS, ATLAS_SCRIPTS):
    if str(value) not in sys.path:
        sys.path.insert(0, str(value))

import praycg_control_center_v1_0_0_alpha_3 as control
import praycg_protocol_library_v2_0 as library
from praycg_protocol_atlas_engine_v2_0 import (
    _compiled_run_index,
    _load_resume_index,
    _reject_unbound_atlas_runtime_environment,
    _session_index,
)


class ProtocolAtlasRuntimeAuthorityTests(unittest.TestCase):
    def test_runnable_discovery_rejects_external_atlas_root(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            records, errors = library.discover_protocol_modules(Path(temp))
        self.assertEqual([], records)
        self.assertTrue(any("packaged Atlas root" in message for message in errors))

    def test_control_center_sanitizes_unbound_atlas_controls_even_for_authorized_child(self) -> None:
        values = {key: "UNTRUSTED" for key in control.ATLAS_UNBOUND_RUNTIME_ENV_KEYS}
        with patch.dict(os.environ, values, clear=False):
            child = control.child_process_environment(
                values,
                allow_runtime_authority=True,
            )
        self.assertTrue(control.ATLAS_UNBOUND_RUNTIME_ENV_KEYS.isdisjoint(child))

    def test_engine_rejects_unbound_runtime_control_before_real_run(self) -> None:
        with patch.dict(os.environ, {"PRAYCG_ATLAS_RUN_INDEX": "2"}, clear=False):
            with self.assertRaisesRegex(RuntimeError, "Unbound Atlas runtime controls"):
                _reject_unbound_atlas_runtime_environment()

    def test_session_and_run_indices_come_only_from_locked_plan(self) -> None:
        with patch.dict(os.environ, {"PRAYCG_ATLAS_SESSION_INDEX": "99", "PRAYCG_ATLAS_RUN_INDEX": "99"}, clear=False):
            self.assertEqual(3, _session_index({"session": {"session_index": 3}}))
            self.assertEqual(2, _compiled_run_index({"parameters": {"run_index": 2}}))
        with self.assertRaisesRegex(RuntimeError, "positive session_index"):
            _session_index({"session": {}})
        with self.assertRaisesRegex(RuntimeError, "positive run_index"):
            _compiled_run_index({"parameters": {"run_index": 0}})

    def test_resume_is_disabled_and_unbound_checkpoint_fails_closed(self) -> None:
        self.assertEqual(0, _load_resume_index(None, {}))  # type: ignore[arg-type]
        with patch.dict(os.environ, {"PRAYCG_RESUME_CHECKPOINT_JSON": "stale.json"}, clear=False):
            with self.assertRaisesRegex(RuntimeError, "resume is disabled"):
                _load_resume_index(None, {})  # type: ignore[arg-type]

    def test_saved_runnable_root_is_always_rebased_to_packaged_root(self) -> None:
        defaults = control.default_config()
        with tempfile.TemporaryDirectory() as temp:
            migrated, notes = control.migrate_saved_config(
                {
                    "schema": control.CONFIG_SCHEMA,
                    "version": control.APP_VERSION,
                    "protocol_library_root": temp,
                },
                defaults,
            )
        self.assertEqual(str(control.packaged_protocol_atlas_root()), migrated["protocol_library_root"])
        self.assertTrue(any("protocol-library" in note for note in notes))

    def test_packaged_root_is_selected_by_protocol_family(self) -> None:
        self.assertEqual(
            control.packaged_protocol_library_root(library.FAMILY_ATLAS),
            control.packaged_protocol_atlas_root(),
        )
        self.assertEqual(
            control.packaged_protocol_library_root(library.FAMILY_NATIVE),
            (control.package_root().parent / "tools" / "ProtocolRunner_ModuleLibrary_v1_0").resolve(strict=False),
        )
        with self.assertRaisesRegex(ValueError, "Unsupported protocol module family"):
            control.packaged_protocol_library_root("external")

    def test_launch_snapshot_rejects_external_runnable_root(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_root = Path(temp)
            snapshot_path = temp_root / "approved.json"
            core = {"protocol_id": "TEST", "protocol_version": "1.0"}
            payload = {
                "schema": "PRAYCG_ApprovedProtocolSnapshot_v0_2",
                "status": "APPROVED",
                "validation_status": "PASS",
                "human_reviewed_by": "Test Reviewer",
                "library_root": str(temp_root / "external_atlas"),
                "snapshot_core": core,
                "snapshot_sha256": control.platform_sha256_json(core),
            }
            payload["approval_envelope_sha256"] = control.platform_sha256_json(payload)
            snapshot_path.write_text(json.dumps(payload), encoding="utf-8")

            app = object.__new__(control.PRAYCGControlCenter)
            app.cfg = {"acquisition": {"approved_protocol_snapshot_path": str(snapshot_path)}}
            app.protocol_library_root = control.packaged_protocol_atlas_root()
            app.legacy_protocol_library_root = control.packaged_protocol_library_root(library.FAMILY_NATIVE)
            validated_lock = {
                "module_family": library.FAMILY_ATLAS,
                "protocol_id": "TEST",
                "protocol_version": "1.0",
            }
            with self.assertRaisesRegex(ValueError, "non-packaged runnable library root"):
                app.load_current_protocol_snapshot(validated_lock)


if __name__ == "__main__":
    unittest.main()
