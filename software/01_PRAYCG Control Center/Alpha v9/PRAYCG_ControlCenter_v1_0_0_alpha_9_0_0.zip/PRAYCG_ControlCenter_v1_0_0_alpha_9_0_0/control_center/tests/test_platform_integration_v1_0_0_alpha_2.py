from __future__ import annotations

import gzip
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PACKAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE / "platform_core"))
sys.path.insert(0, str(PACKAGE / "control_center" / "scripts"))
from praycg_platform_core_v1_0_alpha_2 import (  # noqa: E402
    build_hardware_profile,
    build_session_manifest,
    compile_protocol,
    load_json,
    resolve_analysis_capabilities,
    scan_public_package,
    validate_hardware_module,
    validate_protocol,
)
from praycg_control_center_v1_0_0_alpha_2 import APP_VERSION, CONFIG_SCHEMA, bundled_tool_paths  # noqa: E402


class PlatformAlpha2IntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.library = PACKAGE / "tools" / "ProtocolRunner_ModuleLibrary_v1_0"
        self.protocol_path = self.library / "protocols" / "PRAYCG4_shotorder_four_branch_v1_0.json"
        self.hardware_path = PACKAGE / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json"

    def test_version_and_registered_entry_points(self) -> None:
        self.assertEqual(APP_VERSION, "1.0.0-alpha.2")
        self.assertEqual(CONFIG_SCHEMA, "PRAYCG_ControlCenter_Config_v1_0_alpha_2")
        paths = bundled_tool_paths()
        self.assertNotIn("platform_workbench", paths)
        for key in ("protocol_forge", "hardware_registry", "acquisition_supervisor", "bids_exporter", "release_validator", "cue_locked_gamma_forensics"):
            self.assertTrue(Path(paths[key]).is_file(), f"{key}: {paths[key]}")

    def test_protocol_three_layer_validation_and_lock(self) -> None:
        module = load_json(self.protocol_path)
        report = validate_protocol(module, library_root=self.library)
        self.assertEqual(report.status, "PASS", report.as_dict())
        with tempfile.TemporaryDirectory() as temp:
            out, lock = compile_protocol(self.protocol_path, self.library, Path(temp), human_reviewed_by="Alpha Tester")
            self.assertEqual(lock["status"], "APPROVED")
            timeline = (out / "compiled_timeline.csv").read_text(encoding="utf-8")
            self.assertIn("BASELINE_1", timeline)
            self.assertIn("BASELINE_2_REFLECTION", timeline)
            self.assertIn("FINAL_REPORT", timeline)

    def test_unreviewed_protocol_cannot_lock(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            _out, lock = compile_protocol(self.protocol_path, self.library, Path(temp))
            self.assertEqual(lock["status"], "DRAFT_NOT_APPROVED")

    def test_hardware_profile_and_capability_resolution(self) -> None:
        module = load_json(self.hardware_path)
        self.assertNotEqual(validate_hardware_module(module).status, "INELIGIBLE")
        with tempfile.TemporaryDirectory() as temp:
            profile_path = Path(temp) / "profile.json"
            profile = build_hardware_profile([self.hardware_path], profile_path, profile_id="alpha", reviewed_by="Alpha Tester")
            self.assertEqual(profile["status"], "APPROVED")
            self.assertIn("als", profile["resolved_roles"])
            capabilities = resolve_analysis_capabilities(load_json(self.protocol_path), profile)
            self.assertEqual(capabilities["capabilities"]["HOC_R_ShotOrder"]["status"], "AVAILABLE")
            self.assertEqual(capabilities["capabilities"]["Cue_Locked_Gamma_Forensics_v0_1"]["classification"], "EXPLORATORY_SECONDARY_CONFOUND_EXTENSION")

    def test_session_manifest_preserves_gates(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            _build_dir, protocol_lock = compile_protocol(self.protocol_path, self.library, temp_path / "protocols", human_reviewed_by="Alpha Tester")
            profile_path = temp_path / "hardware.json"
            profile = build_hardware_profile([self.hardware_path], profile_path, profile_id="alpha", reviewed_by="Alpha Tester")
            template = load_json(PACKAGE / "config" / "study_session_TEMPLATE_v0_1.json")
            template.update({"study_id": "SYNTH", "session_id": "001", "participant_pseudonym": "P001", "protocol_module": str(self.protocol_path), "hardware_profile": str(profile_path)})
            manifest = build_session_manifest(template, protocol_lock, profile, temp_path / "session.json")
            self.assertEqual(manifest["status"], "READY_TO_CONNECT")
            self.assertEqual(manifest["gate_status"]["SELECT"], "PASS")
            self.assertEqual(manifest["gate_status"]["PREFLIGHT"], "PENDING")
            self.assertEqual(manifest["gate_status"]["ARM"], "PENDING")

    def test_bids_export_preserves_irregular_rr(self) -> None:
        script = PACKAGE / "tools" / "BIDS_Exporter_v0_1" / "praycg_bids_exporter_v0_1.py"
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); run = root / "run"; out = root / "bids"; run.mkdir()
            events = run / "events.csv"; rr = run / "rr.csv"; physio = run / "resp.csv"
            events.write_text("onset,duration,trial_type\n0,0,BASELINE_1_START\n1.2,0,TARGET_1_START\n", encoding="utf-8")
            rr.write_text("time,rr_seconds\n0.7,0.71\n1.48,0.78\n2.17,0.69\n", encoding="utf-8")
            physio.write_text("time,respiration\n0.0,1.0\n0.1,1.1\n0.2,1.2\n", encoding="utf-8")
            completed = subprocess.run([sys.executable, str(script), "--run-folder", str(run), "--out", str(out), "--events-csv", str(events), "--rr-csv", str(rr), "--physio-csv", str(physio)], capture_output=True, text=True)
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            rr_out = out / "sub-001" / "ses-01" / "func" / "sub-001_ses-01_task-praycg_physioevents.tsv.gz"
            self.assertTrue(rr_out.is_file())
            with gzip.open(rr_out, "rt", encoding="utf-8") as handle:
                text = handle.read()
            self.assertIn("0.71", text)
            report = load_json(out / "praycg_export_report.json")
            self.assertFalse(report["outputs"]["rr_events"]["resampled"])

    def test_public_scan_rejects_raw_data_and_private_paths(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "bad.xdf").write_bytes(b"xdf")
            windows_path = "C:" + "\\Users" + "\\person\\secret"
            (root / "path.txt").write_text(windows_path, encoding="utf-8")
            self.assertEqual(scan_public_package(root)["status"], "INELIGIBLE")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "authority.py").write_text(
                "token = str(os.environ.pop('RUNNER_TOKEN', ''))\n"
                "synthetic_token = 'synthetic-test-token-' + 'x' * 48\n",
                encoding="utf-8",
            )
            self.assertEqual(scan_public_package(root)["status"], "PASS")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            credential_name = "api_" + "key"
            credential_value = "live-credential-value-" + "1234567890"
            (root / "embedded.py").write_text(
                f"{credential_name} = '{credential_value}'\n",
                encoding="utf-8",
            )
            report = scan_public_package(root)
            self.assertEqual(report["status"], "INELIGIBLE")
            self.assertTrue(any(row["finding"] == "possible credential or private key" for row in report["findings"]))

    def test_resolved_environment_capture_is_privacy_minimized(self) -> None:
        script = PACKAGE / "tools" / "Release_Validation_v0_1" / "praycg_capture_environment_lock_v0_1.py"
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "environment.json"
            completed = subprocess.run(
                [sys.executable, str(script), "--out", str(output)],
                capture_output=True,
                text=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stdout + completed.stderr)
            record = load_json(output)
            self.assertEqual(record["schema"], "PRAYCG_ResolvedEnvironment_v0_1")
            self.assertTrue(record["packages"])
            serialized = output.read_text(encoding="utf-8").casefold()
            for forbidden in ("executable_path", "user_name", "host_name", "environment_variables", "credentials"):
                self.assertNotIn(f'"{forbidden}"', serialized)


if __name__ == "__main__":
    unittest.main()
