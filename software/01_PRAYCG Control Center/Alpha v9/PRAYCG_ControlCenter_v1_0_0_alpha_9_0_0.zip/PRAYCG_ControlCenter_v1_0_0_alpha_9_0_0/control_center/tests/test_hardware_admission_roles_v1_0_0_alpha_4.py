from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "platform_core"))
import praycg_platform_core_v1_0_alpha_3 as alpha3  # noqa: E402
import praycg_platform_core_v1_0_alpha_4 as core  # noqa: E402


def module(module_id: str, lsl_name: str, *, admission: str = "HUMAN_CONNECTED_APPROVED") -> dict:
    return {
        "schema": "PRAYCG_HardwareModule_v0_1",
        "module_id": module_id,
        "module_version": "0.1.0",
        "display_name": module_id,
        "transport": "test fixture",
        "trust_level": "COMMUNITY_UNVERIFIED",
        "admission_state": admission,
        "physical_validation": "HUMAN_CONNECTED" if admission == "HUMAN_CONNECTED_APPROVED" else "NOT_PERFORMED",
        "admission_evidence": [{"sha256": "a" * 64}] if admission == "HUMAN_CONNECTED_APPROVED" else [],
        "streams": [{
            "lsl_name": lsl_name,
            "source_id": "",
            "source_id_policy": "dynamic_run_bound",
            "source_id_prefix": f"{module_id}_",
            "canonical_role": "eeg",
            "nominal_srate": 250.0,
            "channel_count": 2,
            "units": "microvolts",
            "role_assignment_default": "UNASSIGNED",
        }],
        "preflight": {"duration_seconds": 30, "checks": ["effective_sample_rate"]},
        "managed_recovery": {"enabled_by_default": False},
    }


class AdmissionAndRoleTests(unittest.TestCase):
    def test_authority_lease_implementation_is_carried_unchanged(self) -> None:
        self.assertIs(core.claim_active_acquisition_owner, alpha3.claim_active_acquisition_owner)
        self.assertIs(core.advance_session_gate, alpha3.advance_session_gate)
        self.assertEqual(core.PLATFORM_VERSION, "1.0.0-alpha.4")

    def test_two_sources_require_explicit_primary(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            paths = []
            for item in (module("first", "FirstEEG"), module("second", "SecondEEG")):
                path = root / f"{item['module_id']}.json"
                path.write_text(json.dumps(item), encoding="utf-8")
                paths.append(path)
            ambiguous = core.build_hardware_profile(paths, root / "ambiguous.json", profile_id="ambiguous", reviewed_by="Reviewer")
            self.assertEqual(ambiguous["status"], "DRAFT_NOT_APPROVED")
            self.assertTrue(any("exactly one primary" in item for item in ambiguous["errors"]))
            resolved = core.build_hardware_profile(
                paths,
                root / "resolved.json",
                profile_id="resolved",
                reviewed_by="Reviewer",
                role_assignments={"eeg": "first/FirstEEG"},
            )
            self.assertEqual(resolved["status"], "APPROVED", resolved)
            self.assertEqual(resolved["primary_role_sources"]["eeg"]["source_ref"], "first/FirstEEG")
            self.assertEqual(resolved["supplemental_role_sources"]["eeg"][0]["source_ref"], "second/SecondEEG")

    def test_catalog_only_module_cannot_enter_human_profile(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            path = root / "catalog.json"
            path.write_text(json.dumps(module("staged", "StagedEEG", admission="CATALOG_ONLY")), encoding="utf-8")
            profile = core.build_hardware_profile([path], root / "profile.json", profile_id="staged", reviewed_by="Reviewer")
            self.assertEqual(profile["status"], "DRAFT_NOT_APPROVED")
            self.assertTrue(any("cannot enter" in item for item in profile["errors"]))

    def test_legacy_module_remains_compatible_but_visible_as_ungraded(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            path = ROOT / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_v0_1.json"
            profile = core.build_hardware_profile([path], root / "profile.json", profile_id="legacy", reviewed_by="Reviewer")
            self.assertEqual(profile["status"], "APPROVED", profile)
            self.assertEqual(profile["modules"][0]["admission_state"], "LEGACY_CARRIED_UNGRADED")
            self.assertTrue(any("LEGACY_CARRIED_UNGRADED" in item for item in profile["cautions"]))

    def test_spoofed_legacy_id_from_external_path_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            value = module("openbci_cyton_daisy_eeg", "SpoofedEEG")
            for field in ("admission_state", "physical_validation", "admission_evidence"):
                value.pop(field, None)
            path = root / "OpenBCI_CytonDaisy_EEG_v0_1.json"
            path.write_text(json.dumps(value), encoding="utf-8")
            profile = core.build_hardware_profile([path], root / "profile.json", profile_id="spoof", reviewed_by="Reviewer")
            self.assertEqual(profile["status"], "DRAFT_NOT_APPROVED")
            self.assertTrue(any("exact packaged config/hardware file" in item for item in profile["errors"]))

    def test_unknown_module_cannot_claim_legacy_compatibility(self) -> None:
        value = module("new_ungraded_adapter", "NewEEG")
        for field in ("admission_state", "physical_validation", "admission_evidence"):
            value.pop(field, None)
        report = core.validate_hardware_module(value)
        self.assertTrue(any("not on the exact carried-module allowlist" in item for item in report.errors))

    def test_tampered_assignment_ledger_is_ineligible(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            path = root / "one.json"
            path.write_text(json.dumps(module("one", "OneEEG")), encoding="utf-8")
            profile_path = root / "profile.json"
            profile = core.build_hardware_profile([path], profile_path, profile_id="one", reviewed_by="Reviewer")
            profile["primary_role_sources"]["eeg"]["source_ref"] = "other/OtherEEG"
            profile["canonical_sha256"] = alpha3._canonical_stored_hash(profile)
            report = core.validate_hardware_profile_identity(profile)
            self.assertTrue(any("ledger does not match" in item for item in report.errors))

    def test_generic_physio_driver_profile_is_path_and_hash_bound(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            driver = root / "driver.json"
            driver.write_text('{"profile":"reviewed fixture"}\n', encoding="utf-8")
            value = module("generic_eda_ppg_udp", "PhysioEEGPlaceholder")
            value["streams"] = [
                {"lsl_name": "PRAYCG_EDA", "source_id": "", "source_id_policy": "dynamic_run_bound", "source_id_prefix": "praycg_physio_eda_", "canonical_role": "eda", "nominal_srate": 10.0, "channel_count": 1, "units": "native"},
                {"lsl_name": "PRAYCG_PPG", "source_id": "", "source_id_policy": "dynamic_run_bound", "source_id_prefix": "praycg_physio_ppg_", "canonical_role": "ppg", "nominal_srate": 100.0, "channel_count": 1, "units": "native"},
            ]
            value["driver_profile_relative_path"] = driver.name
            value["driver_profile_sha256"] = core.sha256_file(driver)
            path = root / "physio.json"
            path.write_text(json.dumps(value), encoding="utf-8")
            profile = core.build_hardware_profile([path], root / "profile.json", profile_id="physio", reviewed_by="Reviewer")
            self.assertEqual(profile["status"], "APPROVED", profile)
            self.assertEqual(profile["modules"][0]["driver_profile_sha256"], core.sha256_file(driver))
            driver.write_text('{"profile":"changed"}\n', encoding="utf-8")
            report = core.validate_hardware_profile_identity(profile)
            self.assertTrue(any("driver profile SHA-256" in item for item in report.errors))

    def test_generic_physio_rejects_unbound_or_uppercase_driver_hash(self) -> None:
        value = module("generic_eda_ppg_serial", "SerialEEGPlaceholder")
        value["driver_profile_relative_path"] = "../escape.json"
        value["driver_profile_sha256"] = "A" * 64
        report = core.validate_hardware_module(value)
        self.assertTrue(any("contained driver_profile_relative_path" in item for item in report.errors))
        self.assertTrue(any("lowercase 64-hex" in item for item in report.errors))


if __name__ == "__main__":
    unittest.main()
