from __future__ import annotations

import ast
import importlib.util
import inspect
import json
import os
import sys
import tempfile
import types
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

import numpy as np


PACKAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE / "platform_core"))
sys.path.insert(0, str(PACKAGE / "control_center" / "scripts"))

import praycg_control_center_v1_0_0_alpha_2 as control_center  # noqa: E402


def load_detailed_preflight_module():
    path = PACKAGE / "control_center" / "scripts" / "praycg_acquisition_preflight_v1_0.py"
    spec = importlib.util.spec_from_file_location("alpha2_command_path_preflight_test", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def load_engine_with_dependency_stubs():
    pylsl = types.ModuleType("pylsl")
    for name in ("StreamInfo", "StreamOutlet", "StreamInlet"):
        setattr(pylsl, name, type(name, (), {}))
    pylsl.local_clock = lambda: 0.0
    pylsl.resolve_byprop = lambda *_args, **_kwargs: []
    psychopy = types.ModuleType("psychopy")
    for name in ("core", "event", "gui", "logging", "visual"):
        setattr(psychopy, name, types.SimpleNamespace())
    constants = types.ModuleType("psychopy.constants")
    constants.FINISHED = "FINISHED"
    engine_path = PACKAGE / "tools" / "ProtocolRunner_ModuleLibrary_v1_0" / "scripts" / "praycg_protocol_engine_v3_0.py"
    spec = importlib.util.spec_from_file_location("praycg_protocol_engine_command_path_test", engine_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {
        "pylsl": pylsl,
        "psychopy": psychopy,
        "psychopy.constants": constants,
        str(spec.name): module,
    }):
        spec.loader.exec_module(module)
    return module


def stage_calls(function, callee: str) -> list[str]:
    tree = ast.parse(inspect.getsource(function))
    stages: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = node.func.attr if isinstance(node.func, ast.Attribute) else node.func.id if isinstance(node.func, ast.Name) else ""
        if name != callee or not node.args:
            continue
        value = node.args[0]
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            stages.append(value.value.upper())
    return stages


class CommandPathIntegrationHardeningTests(unittest.TestCase):
    def test_child_environment_denies_inherited_runtime_authority_by_default(self) -> None:
        stale = {key: f"stale-{index}" for index, key in enumerate(control_center.RUNTIME_AUTHORITY_ENV_KEYS)}
        with patch.dict(os.environ, stale, clear=False):
            debug_environment = control_center.child_process_environment()
            for key in control_center.RUNTIME_AUTHORITY_ENV_KEYS:
                self.assertNotIn(key, debug_environment)

            authorized_environment = control_center.child_process_environment(
                {
                    "PRAYCG_SESSION_LOCK_JSON": "fresh-lock.json",
                    "PRAYCG_RUN_UUID": "fresh-run",
                    "NON_AUTHORITY_SETTING": "retained",
                },
                allow_runtime_authority=True,
            )
        self.assertEqual(authorized_environment["PRAYCG_SESSION_LOCK_JSON"], "fresh-lock.json")
        self.assertEqual(authorized_environment["PRAYCG_RUN_UUID"], "fresh-run")
        self.assertEqual(authorized_environment["NON_AUTHORITY_SETTING"], "retained")
        for key in control_center.RUNTIME_AUTHORITY_ENV_KEYS - {"PRAYCG_SESSION_LOCK_JSON", "PRAYCG_RUN_UUID"}:
            self.assertNotIn(key, authorized_environment)

    def test_authorized_runner_process_cannot_use_generic_restart(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            process = types.SimpleNamespace(poll=lambda: 1, pid=12345)
            running = control_center.RunningProcess(
                label="Locked PRAYCG runner",
                process=process,
                log_path=Path(temp) / "runner.log",
                started=0.0,
                cmd=[sys.executable, "runner.py"],
                env_overrides={"PRAYCG_SESSION_LOCK_JSON": "lock.json"},
                runtime_authority=True,
                restartable=False,
            )
            launch_calls = []
            harness = types.SimpleNamespace(
                processes={"locked": running},
                launch_process=lambda *args, **kwargs: launch_calls.append((args, kwargs)),
            )
            with patch.object(control_center.messagebox, "showwarning") as warning:
                control_center.PRAYCGControlCenter.restart_process(harness, "locked")
            self.assertFalse(launch_calls)
            warning.assert_called_once()

    def test_integrated_preflight_is_stream_health_only_and_placement_remains_dedicated(self) -> None:
        launch_source = inspect.getsource(control_center.PRAYCGControlCenter.run_profile_preflight)
        self.assertIn('"--stream-health-only"', launch_source)
        placement_source = inspect.getsource(control_center.PRAYCGControlCenter.run_als_test)
        self.assertIn('"als_pulse_test"', placement_source)
        self.assertIn('"--run-uuid"', placement_source)
        self.assertIn('"--hardware-profile-sha256"', placement_source)

        detailed = load_detailed_preflight_module()
        parsed = detailed.build_parser().parse_args(["--stream-health-only", "--require-als"])
        self.assertTrue(parsed.stream_health_only)
        stamps = np.arange(750, dtype=float) / 125.0
        rng = np.random.default_rng(7)
        run_uuid = "12345678-1234-1234-1234-123456789abc"
        fragment = run_uuid.replace("-", "")[:12]
        eeg = detailed.Capture(
            "obci_eeg1",
            125.0,
            16,
            rng.normal(0, 10, size=(750, 16)).tolist(),
            stamps.tolist(),
            source_id=f"praycg_eeg_{fragment}",
            resolved_candidate_count=1,
        )
        # A present, run-bound but flat ALS stream is deliberately not pulse
        # evidence. Stream-health mode may establish availability, but must
        # neither calculate nor present pulse evidence; the dedicated placement
        # test owns that decision.
        als = detailed.Capture(
            "ALS_PT19_Timing",
            125.0,
            1,
            [[1.0]] * 750,
            stamps.tolist(),
            source_id=f"praycg_als_{fragment}",
            resolved_candidate_count=1,
        )
        report = detailed.analyze(
            eeg,
            als,
            125.0,
            True,
            run_uuid=run_uuid,
            hardware_profile_sha256="a" * 64,
            stream_health_only=True,
        )
        self.assertFalse(any("pulse" in reason.casefold() for reason in report["fail_reasons"]))
        self.assertEqual(report.get("als_evidence_mode"), "STREAM_HEALTH_ONLY")
        for forbidden in ("pulse_visible", "transition_count", "contrast_to_noise", "robust_span"):
            self.assertNotIn(forbidden, report["als"])
        with tempfile.TemporaryDirectory() as temp:
            outputs = detailed.write_report(report, Path(temp))
            markdown = Path(outputs["markdown"]).read_text(encoding="utf-8")
        self.assertNotIn("ALS pulse visible", markdown)
        self.assertIn("no pulse inference", markdown)

    def test_profile_preflight_does_not_stale_same_run_als_evidence(self) -> None:
        launch_source = inspect.getsource(control_center.PRAYCGControlCenter.run_profile_preflight)
        self.assertNotIn('acquisition["preflight_started_epoch"] = time.time()', launch_source)
        self.assertIn('acquisition["profile_preflight_invocation_epoch"] = time.time()', launch_source)

    def test_new_uuid_derives_disjoint_immutable_run_artifact_paths(self) -> None:
        first = uuid.UUID("11111111-1111-4111-8111-111111111111")
        second = uuid.UUID("22222222-2222-4222-8222-222222222222")
        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            harness = types.SimpleNamespace(
                active_run_uuid=None,
                cfg={"log_root": str(log_root), "acquisition": {}},
                save_config=lambda: None,
                write_acquisition_state=lambda: None,
                log=lambda _message: None,
            )
            with patch.object(control_center.uuid, "uuid4", side_effect=[first, second]):
                first_run = control_center.PRAYCGControlCenter.begin_acquisition_session(harness)
                first_paths = dict(harness.cfg["acquisition"])
                second_run = control_center.PRAYCGControlCenter.begin_acquisition_session(harness)
                second_paths = dict(harness.cfg["acquisition"])

            self.assertEqual(first_run, str(first))
            self.assertEqual(second_run, str(second))
            required = (
                "profile_preflight_report_path",
                "detailed_preflight_dir",
                "session_draft_path",
                "session_lock_path",
                "als_test_dir",
            )
            first_root = (log_root / "protocol_runs" / str(first)).resolve()
            second_root = (log_root / "protocol_runs" / str(second)).resolve()
            for key in required:
                first_path = Path(first_paths[key]).resolve()
                second_path = Path(second_paths[key]).resolve()
                first_path.relative_to(first_root)
                second_path.relative_to(second_root)
                self.assertNotEqual(first_path, second_path, key)
            self.assertEqual(Path(first_paths["session_artifact_root"]).resolve(), first_root)
            self.assertEqual(Path(second_paths["session_artifact_root"]).resolve(), second_root)

    def test_locked_snapshot_prefill_ignores_mutable_stimulus_context(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            locked_file = root / "locked_target.mp4"
            mutable_file = root / "mutable_target.mp4"
            locked_file.write_bytes(b"locked")
            mutable_file.write_bytes(b"mutable")
            runtime_lock = {
                "lock_identity_sha256": "a" * 64,
                "session": {
                    "stimulus_id": "LOCKED_A",
                    "stimulus_folder": str(root / "locked_folder"),
                    "media_selection_snapshot": {
                        "target_video": {
                            "path": str(locked_file),
                            "sha256": control_center.sha256_file(locked_file),
                        },
                    },
                    "private_output_locations": {"session_log_dir": str(root)},
                },
            }
            harness = types.SimpleNamespace(
                selected_stimulus_id="MUTABLE_B",
                log=lambda _message: None,
            )
            path = control_center.PRAYCGControlCenter.write_protocol_prefill(
                harness,
                {"protocol_id": "P", "protocol_version": "1", "manifest_sha256": "b" * 64},
                runtime_lock,
            )
            payload = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(payload["stimulus_id"], "LOCKED_A")
            self.assertEqual(payload["stimulus_folder"], str(root / "locked_folder"))
            self.assertEqual(payload["selections"], {"target_video": str(locked_file)})
            self.assertNotIn(str(mutable_file), json.dumps(payload))

    def test_changed_stimulus_identity_or_alias_folder_fails_preclaim(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            locked_folder = root / "stimulus_a"
            mutable_folder = root / "stimulus_b"
            locked_folder.mkdir()
            mutable_folder.mkdir()
            locked_file = locked_folder / "same_name.mp4"
            mutable_file = mutable_folder / "same_name.mp4"
            locked_file.write_bytes(b"byte-identical")
            mutable_file.write_bytes(b"byte-identical")
            digest = control_center.sha256_file(locked_file)
            runtime_lock = {
                "session": {
                    "stimulus_id": "A",
                    "stimulus_folder": str(locked_folder),
                    "media_selection_snapshot": {"target_video": {"path": str(locked_file), "sha256": digest}},
                },
            }
            harness = types.SimpleNamespace(
                selected_stimulus_id="B",
                selected_stimulus_folder=lambda: mutable_folder,
                resolve_protocol_media_snapshot=lambda _lock: (
                    {"stimulus_folder": str(mutable_folder), "selections": {"target_video": {"path": str(mutable_file), "sha256": digest}}},
                    [],
                ),
            )
            errors = control_center.PRAYCGControlCenter.validate_current_stimulus_against_lock(
                harness, runtime_lock, {}
            )
            self.assertTrue(any("stimulus id" in item for item in errors))
            self.assertTrue(any("stimulus folder" in item for item in errors))
            self.assertTrue(any("binding path" in item for item in errors))

    def test_stimulus_change_revokes_arm_immediately(self) -> None:
        harness = types.SimpleNamespace(
            cfg={"acquisition": {"armed": True, "session_stage": "ARM", "session_lock_path": ""}},
            save_config=lambda: None,
            log=lambda _message: None,
        )
        control_center.PRAYCGControlCenter.mark_session_stale_for_stimulus_change(harness, "selected B")
        acquisition = harness.cfg["acquisition"]
        self.assertFalse(acquisition["armed"])
        self.assertEqual(acquisition["session_lock_status"], "STALE_STIMULUS_CONTEXT_CHANGED")

    def test_new_uuid_blocks_missing_lease_for_acquire_lock_and_active_process(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            run_root = log_root / "protocol_runs" / "existing-run"
            run_root.mkdir(parents=True)
            lock_path = run_root / "runtime_session_lock.json"
            lock_path.write_text("{}", encoding="utf-8")
            harness = types.SimpleNamespace(
                active_run_uuid=None,
                cfg={"log_root": str(log_root), "acquisition": {}},
                processes={},
                save_config=lambda: None,
                write_acquisition_state=lambda: None,
                log=lambda _message: None,
            )
            valid = types.SimpleNamespace(status="PASS")
            with patch.object(control_center, "load_platform_json", return_value={"current_stage": "ACQUIRE"}), patch.object(
                control_center, "validate_session_lock_identity", return_value=valid
            ):
                conflicts = control_center.PRAYCGControlCenter.runtime_authority_conflicts(harness)
            self.assertTrue(any("no persistent runner lease" in item for item in conflicts))
            original_cfg = json.loads(json.dumps(harness.cfg))
            process = types.SimpleNamespace(poll=lambda: None, pid=43210)
            harness.processes = {"runner": types.SimpleNamespace(runtime_authority=True, process=process)}
            with patch.object(control_center.messagebox, "showerror"):
                result = control_center.PRAYCGControlCenter.begin_acquisition_session(harness)
            self.assertEqual(result, "")
            self.assertEqual(harness.cfg, original_cfg)

    def test_post_spawn_ui_failure_stops_child_before_closing_active_lease(self) -> None:
        class FakeProcess:
            def __init__(self) -> None:
                self.pid = 24680
                self.returncode = None
                self.terminate_calls = 0
                self.kill_calls = 0
                self.wait_calls = 0

            def poll(self):
                return self.returncode

            def terminate(self) -> None:
                self.terminate_calls += 1
                self.returncode = -15

            def kill(self) -> None:
                self.kill_calls += 1
                self.returncode = -9

            def wait(self, timeout=None):
                self.wait_calls += 1
                if self.returncode is None:
                    raise control_center.subprocess.TimeoutExpired("runner", timeout)
                return self.returncode

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            lease_path = root / "authorized_runner_lease.json"
            lease_path.write_text("{}", encoding="utf-8")
            process = FakeProcess()
            finish_calls = []
            harness = types.SimpleNamespace(
                cfg={"log_root": str(root)},
                processes={},
                log=lambda _message: None,
                update_process_tree=lambda: (_ for _ in ()).throw(RuntimeError("dashboard closed")),
                after=lambda *_args, **_kwargs: None,
            )

            def record_finish(path, **kwargs):
                finish_calls.append((path, kwargs))
                return {"status": kwargs["status"]}

            with patch.object(control_center, "command_is_available", return_value=True), patch.object(
                control_center.subprocess, "Popen", return_value=process
            ), patch.object(
                control_center,
                "bind_authorized_runner_lease_process",
                return_value={"process_start_identity": "start-24680"},
            ), patch.object(
                control_center,
                "finish_authorized_runner_lease",
                side_effect=record_finish,
            ), patch.object(control_center.messagebox, "showerror"):
                launched = control_center.PRAYCGControlCenter.launch_process(
                    harness,
                    "Authorized runner",
                    [sys.executable, "runner.py"],
                    allow_runtime_authority=True,
                    restartable=False,
                    runtime_lease_path=lease_path,
                )

            self.assertIsNone(launched)
            self.assertEqual(process.terminate_calls, 1)
            self.assertGreaterEqual(process.wait_calls, 1)
            self.assertIsNotNone(process.poll())
            self.assertFalse(harness.processes)
            self.assertEqual(len(finish_calls), 1)
            self.assertEqual(finish_calls[0][1]["pid"], process.pid)
            self.assertEqual(finish_calls[0][1]["start_identity"], "start-24680")
            self.assertEqual(finish_calls[0][1]["status"], "LAUNCH_FAILED")

    def test_post_claim_log_setup_failure_returns_controlled_launch_failure(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            lease_path = root / "authorized_runner_lease.json"
            lease_path.write_text("{}", encoding="utf-8")
            harness = types.SimpleNamespace(
                cfg={"log_root": str(root)},
                processes={},
                log=lambda _message: (_ for _ in ()).throw(OSError("synthetic log sink failure")),
                update_process_tree=lambda: None,
                after=lambda *_args, **_kwargs: None,
            )
            with patch.object(control_center, "command_is_available", return_value=True), patch.object(
                control_center.subprocess, "Popen"
            ) as popen, patch.object(control_center.messagebox, "showerror"):
                launched = control_center.PRAYCGControlCenter.launch_process(
                    harness,
                    "Authorized runner",
                    [sys.executable, "runner.py"],
                    allow_runtime_authority=True,
                    restartable=False,
                    runtime_lease_path=lease_path,
                )
            self.assertIsNone(launched)
            popen.assert_not_called()
            self.assertFalse(harness.processes)

    def test_clear_exited_keeps_authority_row_until_delayed_reconcile_succeeds(self) -> None:
        process = types.SimpleNamespace(poll=lambda: 0, pid=13579)
        running = control_center.RunningProcess(
            label="Authorized runner",
            process=process,
            log_path=Path("runner.log"),
            started=0.0,
            cmd=[sys.executable, "runner.py"],
            runtime_authority=True,
            completion_handled=False,
        )
        selected = {"value": "runner"}
        outcomes = iter((False, True))
        update_calls = []
        harness = types.SimpleNamespace(
            processes={"runner": running},
            selected_proc_key_var=types.SimpleNamespace(
                get=lambda: selected["value"],
                set=lambda value: selected.__setitem__("value", value),
            ),
            reconcile_runtime_lease_process_exit=lambda _rp, _rc: next(outcomes),
            update_process_tree=lambda: update_calls.append(True),
        )
        control_center.PRAYCGControlCenter.clear_exited_processes(harness)
        self.assertIn("runner", harness.processes)
        self.assertFalse(running.completion_handled)
        control_center.PRAYCGControlCenter.clear_exited_processes(harness)
        self.assertNotIn("runner", harness.processes)
        self.assertEqual(selected["value"], "")
        self.assertEqual(len(update_calls), 2)

    def test_control_center_claims_acquire_before_spawn_and_engine_does_not_reclaim(self) -> None:
        launch_source = inspect.getsource(control_center.PRAYCGControlCenter.launch_praycg_runner)
        claim_position = launch_source.find('"ACQUIRE"')
        spawn_position = launch_source.find("self.launch_process")
        self.assertGreaterEqual(claim_position, 0, "authorized launch must explicitly claim ACQUIRE")
        self.assertGreater(spawn_position, claim_position, "ACQUIRE must be persisted before process spawn")
        self.assertIn("advance_session_gate", launch_source)
        self.assertIn("allow_runtime_authority=authorized_direct_launch", launch_source)
        self.assertIn("restartable=not authorized_direct_launch", launch_source)

        engine = load_engine_with_dependency_stubs()
        run_source = inspect.getsource(engine.run_full_experiment)
        required_position = run_source.find('required_stage="ACQUIRE"')
        logger_position = run_source.find("EventLogger(")
        self.assertGreaterEqual(required_position, 0)
        self.assertGreater(logger_position, required_position)
        self.assertNotIn("ACQUIRE", stage_calls(engine.run_full_experiment, "advance_runtime_session_gate"))

    def test_runner_closes_logs_before_hashed_finalize_evidence(self) -> None:
        engine = load_engine_with_dependency_stubs()
        source = inspect.getsource(engine.run_full_experiment)
        # Earlier fail-fast branches may close a partial log.  The final close
        # is the one whose completed artifacts must precede FINALIZE.
        close_position = source.rfind("logger.close()")
        finalize_position = source.find('"FINALIZE"', close_position)
        self.assertGreaterEqual(close_position, 0)
        self.assertGreater(finalize_position, close_position, "event logs must close before FINALIZE is persisted")
        evidence_region = source[close_position:finalize_position + 1200]
        self.assertIn("is_file", evidence_region)
        self.assertIn("stat().st_size", evidence_region)
        self.assertIn("file_sha256", evidence_region)
        self.assertIn("event_log_json", evidence_region)
        self.assertIn("event_log_csv", evidence_region)

    def test_manual_postrun_revalidates_bindings_and_interrupted_run_can_finalize(self) -> None:
        gate_source = inspect.getsource(control_center.PRAYCGControlCenter.record_post_run_gate)
        validate_position = gate_source.find("validate_active_session_lock")
        advance_position = gate_source.find("advance_session_gate")
        self.assertGreaterEqual(validate_position, 0)
        self.assertGreater(advance_position, validate_position)

        analysis_source = inspect.getsource(control_center.PRAYCGControlCenter.build_analysis_tab)
        self.assertIn("Finalize Interrupted Run", analysis_source)
        self.assertTrue(hasattr(control_center.PRAYCGControlCenter, "finalize_interrupted_run"))
        recovery_source = inspect.getsource(control_center.PRAYCGControlCenter.finalize_interrupted_run)
        for required in (
            "validate_active_session_lock",
            '"ACQUIRE"',
            '"FINALIZE"',
            "askopenfilename",
            "askstring",
            "advance_session_gate",
        ):
            self.assertIn(required, recovery_source)


if __name__ == "__main__":
    unittest.main()
