from __future__ import annotations

from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[2]
FORGE_ROOT = ROOT / "tools" / "Hardware_Forge_v1_0"
SUPERVISOR_ROOT = ROOT / "tools" / "Acquisition_Supervisor_v1_0"
for folder in (FORGE_ROOT, SUPERVISOR_ROOT):
    if str(folder) not in sys.path:
        sys.path.insert(0, str(folder))

from praycg_hardware_forge_v1_0 import build_launch_plan, validate_catalog  # noqa: E402
from praycg_generic_lsl_intake_v1_0 import _xml_observation  # noqa: E402
from praycg_stream_contract_v1_0 import (  # noqa: E402
    compare_contract,
    create_contract_draft,
    read_json,
    select_unambiguous_stream,
    validate_contract,
)
from praycg_acquisition_supervisor_v1_0 import analyze_timestamps  # noqa: E402


POLAR_CONTRACT = FORGE_ROOT / "contracts" / "polar_h10_rr_v1_0.json"


def polar_observation() -> dict:
    return {
        "name": "PolarHRV",
        "type": "RRIntervals",
        "channel_count": 1,
        "nominal_srate": 0.0,
        "channel_format": "float32",
        "source_id": "praycg_polar_h10_rr_v0_2_0123456789ab",
        "uid": "uid-1",
        "hostname": "bench-host",
        "session_id": "default",
        "channels": [
            {"index": 1, "label": "RR_interval", "type": "RRIntervals", "unit": "milliseconds"}
        ],
        "desc": {"manufacturer": "Polar", "model": "H10", "run_uuid": "run-1"},
    }


def test_alpha9_adapter_catalog_is_structurally_eligible() -> None:
    report = validate_catalog()
    assert report["status"] == "CAUTION", report
    assert not report["errors"]
    assert report["adapter_count"] >= 11
    assert report["route_count"] >= 14


def test_polar_contract_requires_physical_promotion_but_matches_metadata() -> None:
    contract = read_json(POLAR_CONTRACT)
    validation = validate_contract(contract)
    assert validation["status"] == "CAUTION"
    assert validation["admission_ready"] is False
    comparison = compare_contract(
        contract, polar_observation(), expected_run_uuid="run-1", require_admission_ready=False
    )
    assert comparison["status"] == "CAUTION"
    assert not comparison["errors"]


def test_complete_ordered_channel_metadata_is_fail_closed() -> None:
    contract = read_json(POLAR_CONTRACT)
    observed = polar_observation()
    observed["channels"][0]["unit"] = "seconds"
    report = compare_contract(contract, observed, require_admission_ready=False)
    assert report["status"] == "INELIGIBLE"
    assert any("channel 1 unit mismatch" in error for error in report["errors"])


def test_duplicate_matching_outlets_are_ambiguous() -> None:
    contract = read_json(POLAR_CONTRACT)
    one = polar_observation()
    two = deepcopy(one)
    two["uid"] = "uid-2"
    report = select_unambiguous_stream(contract, [one, two], require_admission_ready=False)
    assert report["status"] == "INELIGIBLE"
    assert "More than one" in report["errors"][0]


def test_generic_lsl_draft_never_has_runtime_authority() -> None:
    draft = create_contract_draft(
        polar_observation(), contract_id="observed_polar", canonical_role="rr_intervals"
    )
    assert draft["contract_state"] == "DRAFT_UNVERIFIED"
    assert draft["draft_provenance"]["runtime_authority"] is False
    assert validate_contract(draft)["admission_ready"] is False


def test_lsl_xml_parser_preserves_ordered_channel_metadata() -> None:
    xml = """
    <info><desc><manufacturer>Example</manufacturer><channels>
      <channel><label>C3</label><type>EEG</type><unit>microvolts</unit></channel>
      <channel><label>C4</label><type>EEG</type><unit>microvolts</unit></channel>
    </channels></desc></info>
    """
    channels, desc = _xml_observation(xml)
    assert [row["label"] for row in channels] == ["C3", "C4"]
    assert [row["index"] for row in channels] == [1, 2]
    assert desc["manufacturer"] == "Example"


def test_long_duration_metrics_detect_drift_gaps_and_regressions() -> None:
    stable = analyze_timestamps(
        [index / 100.0 for index in range(1001)], nominal_srate=100.0,
        clock_offsets=[0.001, 0.0012, 0.0011],
    )
    assert stable["rate_within_tolerance"] is True
    assert abs(stable["drift_ppm"]) < 1e-6
    assert stable["clock_correction_measurement_count"] == 3

    broken = analyze_timestamps(
        [0.0, 0.01, 0.02, 0.50, 0.49, 0.51], nominal_srate=100.0,
    )
    assert broken["gap_count"] == 1
    assert broken["timestamp_regression_count"] == 1


def test_launch_plan_has_no_runtime_authority() -> None:
    plan = build_launch_plan("polar_h10", "rr_intervals_ble", run_uuid="run-1")
    assert plan["runtime_authority"] is False
    assert "ARM" in plan["forbidden_effects"]
    assert plan["handler_key"] == "launch_polar"
