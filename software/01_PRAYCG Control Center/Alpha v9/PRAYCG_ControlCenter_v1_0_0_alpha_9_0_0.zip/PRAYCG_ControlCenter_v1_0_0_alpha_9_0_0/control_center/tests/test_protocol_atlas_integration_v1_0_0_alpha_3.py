from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
CONTROL_SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
PLATFORM_CORE = PACKAGE_ROOT / "platform_core"
ATLAS_ROOT = PACKAGE_ROOT / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0"
ATLAS_SCRIPTS = ATLAS_ROOT / "scripts"
for value in (CONTROL_SCRIPTS, PLATFORM_CORE, ATLAS_SCRIPTS):
    if str(value) not in sys.path:
        sys.path.insert(0, str(value))

import praycg_platform_core_v1_0_alpha_3 as platform
import praycg_protocol_library_v2_0 as library
from praycg_protocol_atlas_core_v2_0 import canonical_sha256


class ProtocolAtlasIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.records, cls.errors = library.discover_protocol_modules(ATLAS_ROOT)

    def test_federated_library_preserves_native_and_adds_substantial_atlas(self) -> None:
        self.assertEqual([], self.errors)
        native_ids = {
            row["protocol_id"] for row in self.records
            if row["module_family"] == library.FAMILY_NATIVE
        }
        atlas = [row for row in self.records if row["module_family"] == library.FAMILY_ATLAS]
        self.assertEqual({"PRAYCG3", "PRAYCG4", "SMG"}, native_ids)
        self.assertGreaterEqual(len(atlas), 11)
        self.assertTrue(all(row["hardware_stack_effect"] == "NONE" for row in atlas))
        self.assertTrue(all(row["module"].get("hardware_profile_id") is None for row in atlas))

    def test_each_atlas_entry_compiles_deterministically(self) -> None:
        for record in (row for row in self.records if row["module_family"] == library.FAMILY_ATLAS):
            first = library.atlas_runtime_plan(record, participant_id="P001", session_index=1)
            second = library.atlas_runtime_plan(record, participant_id="P001", session_index=1)
            self.assertEqual(first, second, record["protocol_id"])
            self.assertEqual(first["canonical_sha256"], canonical_sha256({key: value for key, value in first.items() if key != "canonical_sha256"}))
            self.assertTrue(first["timeline"], record["protocol_id"])
            self.assertTrue(all(node.get("compiled_instance_id") for node in first["timeline"]))

    def test_design_time_compiler_approves_every_packaged_record(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output_root = Path(temp)
            for record in self.records:
                _out, snapshot = platform.compile_protocol(
                    Path(record["manifest_path"]),
                    Path(record["library_root"]),
                    output_root,
                    human_reviewed_by="Atlas Test Reviewer",
                )
                self.assertEqual("APPROVED", snapshot["status"], record["protocol_id"])
                self.assertEqual("PASS", snapshot["validation_status"], record["protocol_id"])
                core = snapshot["snapshot_core"]
                self.assertTrue(core.get("runner_sha256"))
                self.assertTrue(core.get("engine_sha256"))

    def test_federated_selection_lock_detects_runner_change(self) -> None:
        record = next(row for row in self.records if row["module_family"] == library.FAMILY_ATLAS)
        with tempfile.TemporaryDirectory() as temp:
            lock_path = Path(temp) / "protocol_lock.json"
            lock = library.write_protocol_lock(record, lock_path)
            validated = library.validate_protocol_lock(lock_path, ATLAS_ROOT)
            self.assertEqual("PASS", validated["validation"])
            self.assertEqual(record["engine_sha256"], lock["engine_sha256"])

    def test_wrappers_are_thin_and_use_the_shared_engine(self) -> None:
        for record in (row for row in self.records if row["module_family"] == library.FAMILY_ATLAS):
            source = Path(record["runner_path"]).read_text(encoding="utf-8")
            self.assertIn("run_protocol_manifest", source, record["protocol_id"])
            self.assertNotIn("subprocess", source, record["protocol_id"])
            self.assertLess(len(source.splitlines()), 80, record["protocol_id"])


if __name__ == "__main__":
    unittest.main()
