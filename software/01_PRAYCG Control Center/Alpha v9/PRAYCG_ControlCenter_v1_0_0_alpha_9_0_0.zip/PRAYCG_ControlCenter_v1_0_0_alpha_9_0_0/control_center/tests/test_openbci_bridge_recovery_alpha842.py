from __future__ import annotations

import importlib.util
import json
import os
import sys
import unittest
from pathlib import Path
from types import MethodType, SimpleNamespace
from unittest import mock


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
SCRIPT = SCRIPTS / "praycg_control_center_v1_0_0_alpha_8.py"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def _load_module():
    name = "praycg_control_center_alpha842_bridge_recovery_test"
    spec = importlib.util.spec_from_file_location(name, SCRIPT)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


control = _load_module()


class _ValueSink:
    def __init__(self) -> None:
        self.value = ""

    def set(self, value) -> None:
        self.value = str(value)


class OpenBCIBridgeRecoveryAlpha842Tests(unittest.TestCase):
    def test_command_argument_handles_windows_paths_and_quotes(self) -> None:
        command = (
            'python.exe "C:\\PRAYCG Bundle\\praycg_openbci_brainflow_als_pt19_bridge_v1_5.py" '
            '--serial-port COM3 --run-uuid "11111111-1111-4111-8111-111111111111"'
        )
        self.assertEqual(control.command_argument(command, "--serial-port"), "COM3")
        self.assertEqual(
            control.command_argument(command, "--run-uuid"),
            "11111111-1111-4111-8111-111111111111",
        )

    def test_discovery_returns_only_exact_allowlisted_bridge(self) -> None:
        rows = [
            {
                "ProcessId": 42420,
                "ParentProcessId": 12,
                "CreationDate": "today",
                "Name": "python.exe",
                "CommandLine": (
                    "python.exe C:\\old\\praycg_openbci_brainflow_als_pt19_bridge_v1_5.py "
                    "--serial-port COM3 --run-uuid 22222222-2222-4222-8222-222222222222"
                ),
            },
            {
                "ProcessId": 42421,
                "ParentProcessId": 12,
                "CreationDate": "today",
                "Name": "python.exe",
                "CommandLine": (
                    "python.exe unrelated_analysis.py --serial-port COM3 "
                    "--note praycg_openbci_brainflow_als_pt19_bridge_v1_5.py"
                ),
            },
        ]
        completed = SimpleNamespace(returncode=0, stdout=json.dumps(rows), stderr="")
        with (
            mock.patch.object(control.sys, "platform", "win32"),
            mock.patch.object(control.shutil, "which", return_value="powershell.exe"),
            mock.patch.object(control.subprocess, "run", return_value=completed),
        ):
            found = control.discover_external_openbci_bridges()
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0]["pid"], 42420)
        self.assertEqual(found[0]["serial_port"], "COM3")
        self.assertTrue(found[0]["run_uuid"].startswith("22222222-"))

    def test_shutdown_revalidates_pid_and_command_identity(self) -> None:
        candidate = {
            "pid": 42420,
            "script_name": "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py",
            "command_line": "python.exe C:\\old\\praycg_openbci_brainflow_als_pt19_bridge_v1_5.py",
        }
        changed = dict(candidate, command_line="python.exe C:\\different\\unrelated.py")
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[changed]),
            mock.patch.object(control.subprocess, "run") as run,
        ):
            ok, reason = control.stop_external_openbci_bridge(candidate)
        self.assertFalse(ok)
        self.assertIn("identity changed", reason)
        run.assert_not_called()

    def test_shutdown_uses_windows_force_flag_only_after_exact_revalidation(self) -> None:
        candidate = {
            "pid": 42420,
            "script_name": "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py",
            "command_line": "python.exe C:\\old\\praycg_openbci_brainflow_als_pt19_bridge_v1_5.py --serial-port COM3",
        }
        completed = SimpleNamespace(returncode=0, stdout="SUCCESS", stderr="")
        discoveries = [[candidate], []]
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", side_effect=discoveries),
            mock.patch.object(control.subprocess, "run", return_value=completed) as run,
        ):
            ok, _reason = control.stop_external_openbci_bridge(candidate)
        self.assertTrue(ok)
        command = run.call_args.args[0]
        self.assertEqual(command[:3], ["taskkill", "/PID", "42420"])
        self.assertIn("/T", command)
        self.assertIn("/F", command)

    def test_launch_recovery_requires_consent_and_stops_only_stale_same_port(self) -> None:
        old = {
            "pid": 24244,
            "script_name": "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py",
            "serial_port": "COM3",
            "run_uuid": "22222222-2222-4222-8222-222222222222",
            "command_line": "allowlisted",
        }
        stopped = []

        def stop(row):
            stopped.append(row["pid"])
            return True, "stopped"

        app = SimpleNamespace(hardware_launch_status_var=_ValueSink(), log=lambda _message: None)
        method = MethodType(control.PRAYCGControlCenter.prepare_openbci_bridge_launch, app)
        current = "11111111-1111-4111-8111-111111111111"
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[old]),
            mock.patch.object(control, "stop_external_openbci_bridge", side_effect=stop),
            mock.patch.object(control.messagebox, "askyesno", return_value=True),
        ):
            self.assertTrue(method("BrainFlow EEG + ALS", "COM3", current))
        self.assertEqual(stopped, [24244])
        self.assertIn("Recovered COM3", app.hardware_launch_status_var.value)

    def test_current_session_bridge_is_reused_without_second_launch(self) -> None:
        current = "11111111-1111-4111-8111-111111111111"
        running = {
            "pid": os.getpid() + 1000,
            "script_name": "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py",
            "serial_port": "COM3",
            "run_uuid": current,
            "command_line": "allowlisted",
        }
        shown = []
        app = SimpleNamespace(hardware_launch_status_var=_ValueSink(), log=lambda _message: None)
        method = MethodType(control.PRAYCGControlCenter.prepare_openbci_bridge_launch, app)
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[running]),
            mock.patch.object(
                control.messagebox,
                "showinfo",
                side_effect=lambda title, message, **_kwargs: shown.append((title, message)),
            ),
        ):
            self.assertFalse(method("BrainFlow EEG + ALS", "COM3", current))
        self.assertTrue(shown)
        self.assertIn("already streaming", shown[0][1])


if __name__ == "__main__":
    unittest.main()
