from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from types import SimpleNamespace


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_ROOT = PACKAGE_ROOT / "control_center" / "scripts"
CONTROL_CENTER_PATH = SCRIPTS_ROOT / "praycg_control_center_v1_0_0_alpha_8.py"
HARDWARE_WORKFLOW_PATH = (
    PACKAGE_ROOT / "tools" / "Hardware_Workflow_v0_1" / "praycg_hardware_workflow_v0_1.py"
)

if str(SCRIPTS_ROOT) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_ROOT))


def _load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


control_center = _load_module("praycg_control_center_alpha8_layout_test", CONTROL_CENTER_PATH)
hardware_workflow = _load_module("praycg_hardware_workflow_alpha8_layout_test", HARDWARE_WORKFLOW_PATH)
from praycg_protocol_stimulus_flow_v1_0 import (  # noqa: E402
    MASTER_MEDIA_TAG,
    migrate_legacy_master_registry,
)


def _class_node() -> ast.ClassDef:
    tree = ast.parse(CONTROL_CENTER_PATH.read_text(encoding="utf-8"))
    return next(
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "PRAYCGControlCenter"
    )


def _method_node(name: str) -> ast.FunctionDef:
    return next(
        node
        for node in _class_node().body
        if isinstance(node, ast.FunctionDef) and node.name == name
    )


def test_top_level_notebook_uses_the_exact_seven_stage_layout() -> None:
    method = _method_node("build_ui")
    labels: list[str] = []
    for node in ast.walk(method):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute) or node.func.attr != "add":
            continue
        if not isinstance(node.func.value, ast.Attribute) or node.func.value.attr != "nb":
            continue
        for keyword in node.keywords:
            if keyword.arg == "text" and isinstance(keyword.value, ast.Constant):
                labels.append(str(keyword.value.value))
    assert labels == [
        "Home",
        "Choose Protocol",
        "Prepare Materials",
        "Connect & Check Equipment",
        "Run Session",
        "Review Results",
        "Settings",
    ]


def test_protocol_atlas_is_tree_navigation_not_a_combobox() -> None:
    method = _method_node("build_protocol_atlas_tab")
    constructor_names = {
        node.func.attr
        for node in ast.walk(method)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
    }
    assert "Treeview" in constructor_names
    assert "Combobox" not in constructor_names


def test_new_flow_builders_and_callbacks_exist_without_opening_tk() -> None:
    required = {
        "build_protocol_atlas_tab",
        "build_stimulus_tab",
        "build_acquisition_tab",
        "build_runner_tab",
        "on_protocol_tree_selected",
        "refresh_protocol_stimulus_ui",
        "render_protocol_asset_bindings",
        "choose_protocol_asset_binding",
        "clear_protocol_asset_binding",
        "launch_protocol_ai_doc_builder",
        "validate_selected_hardware",
        "create_hardware_profile_draft",
        "review_and_lock_hardware_profile_draft",
        "lock_active_hardware_profile_for_launch",
        "render_hardware_launch_actions",
    }
    assert required.issubset(set(dir(control_center.PRAYCGControlCenter)))


def test_alpha8_bundled_paths_resolve_for_the_new_builder_and_existing_tools() -> None:
    paths = control_center.bundled_tool_paths(PACKAGE_ROOT / "control_center")
    assert "protocol_ai_doc_builder" in paths
    missing = {name: value for name, value in paths.items() if not Path(value).is_file()}
    assert missing == {}


def _atlas_record(protocol_id: str) -> dict:
    records, errors = control_center.discover_protocol_modules(
        control_center.packaged_protocol_atlas_root()
    )
    assert errors == []
    return next(record for record in records if record["protocol_id"] == protocol_id)


def test_alpha8_default_config_has_named_protocol_file_bindings() -> None:
    assert control_center.default_config()["protocol_asset_bindings"] == {}


def test_three_named_unified_presence_inputs_resolve_and_hash_independently(tmp_path: Path) -> None:
    video = tmp_path / "meaning.mp4"
    anchors = tmp_path / "anchors.csv"
    manifest = tmp_path / "manifest.json"
    video.write_bytes(b"synthetic-video-fixture")
    anchors.write_text("time_s,label\n0,start\n", encoding="utf-8")
    manifest.write_text('{"reviewed": true}', encoding="utf-8")
    record = _atlas_record("ATLAS_UNIFIED_PRESENCE_AVAILABILITY")
    app = object.__new__(control_center.PRAYCGControlCenter)
    app.cfg = {
        "protocol_asset_bindings": {
            record["protocol_id"]: {
                "meaning_video": str(video),
                "meaning_anchor_schedule": str(anchors),
                "meaning_stimulus_manifest": str(manifest),
            }
        },
        "protocol_asset_folders": {},
    }

    snapshot, errors = app.resolve_atlas_asset_snapshot(record)

    assert errors == []
    assert set(snapshot["selections"]) == {
        "meaning_video",
        "meaning_anchor_schedule",
        "meaning_stimulus_manifest",
    }
    assert all(row["sha256"] for row in snapshot["selections"].values())
    assert len({row["path"] for row in snapshot["selections"].values()}) == 3


def test_multi_input_protocol_never_guesses_files_from_an_old_folder(tmp_path: Path) -> None:
    (tmp_path / "meaning.mp4").write_bytes(b"synthetic-video-fixture")
    (tmp_path / "one.json").write_text("{}", encoding="utf-8")
    (tmp_path / "two.json").write_text("{}", encoding="utf-8")
    record = _atlas_record("ATLAS_UNIFIED_PRESENCE_AVAILABILITY")
    app = object.__new__(control_center.PRAYCGControlCenter)
    app.cfg = {
        "protocol_asset_bindings": {},
        "protocol_asset_folders": {record["protocol_id"]: str(tmp_path)},
    }

    snapshot, errors = app.resolve_atlas_asset_snapshot(record)

    assert snapshot["selections"] == {}
    assert any("Meaning video" in error and "Choose" in error for error in errors)
    assert any("Timing / anchor schedule" in error for error in errors)
    assert any("Stimulus review manifest" in error for error in errors)


def test_runner_generated_autonomic_protocol_skips_external_file_selection() -> None:
    record = _atlas_record("ATLAS_RHYTHMIC_AUTONOMIC_STABILIZATION")
    app = object.__new__(control_center.PRAYCGControlCenter)
    app.cfg = {"protocol_asset_bindings": {}, "protocol_asset_folders": {}}

    snapshot, errors = app.resolve_atlas_asset_snapshot(record)

    assert errors == []
    assert snapshot["selections"] == {}
    assert snapshot["asset_bindings"] == {}


def test_every_dynamic_hardware_action_targets_a_control_center_handler() -> None:
    handlers = {
        str(binding["handler_key"])
        for bindings in hardware_workflow.LAUNCH_BINDINGS.values()
        for binding in bindings
    }
    missing = sorted(
        name for name in handlers if not hasattr(control_center.PRAYCGControlCenter, name)
    )
    assert missing == []


def test_hardware_ui_actions_cannot_claim_session_or_acquisition_authority() -> None:
    model = hardware_workflow.HardwareWorkflowModel()
    selection = model.validate_and_select("cardiac", "module:polar_h10_rr")
    assert selection["profile_eligible"] is True
    assert selection["runtime_authority"] is False
    assert selection["arm_authority"] is False
    assert selection["acquisition_authority"] is False


def _rendered_polar_launch_state(tmp_path: Path) -> tuple[SimpleNamespace, Path, str, list[str]]:
    model = hardware_workflow.HardwareWorkflowModel()
    selection = model.validate_and_select("cardiac", "module:polar_h10_rr")
    assert selection["profile_eligible"] is True
    module_path = next(
        Path(str(row["module_path"]))
        for row in model.inventory["choices"]
        if row.get("choice_id") == "module:polar_h10_rr"
    )
    profile_path = tmp_path / "reviewed-profile.json"
    hardware_workflow.platform_core.build_hardware_profile(
        [module_path],
        profile_path,
        profile_id="alpha5-click-gate",
        reviewed_by="Integration Tester",
    )
    lock_path = tmp_path / "hardware-ui-lock.json"
    lock = hardware_workflow.lock_hardware_profile(profile_path, output_path=lock_path)
    plan = hardware_workflow.derive_launch_actions(profile_path, lock)
    assert plan["status"] in {"PASS", "CAUTION"}
    action = next(row for row in plan["actions"] if row["action_id"] == "launch_polar_h10_rr")
    action_id = str(action["action_id"])
    dispatched: list[str] = []
    app = SimpleNamespace(
        cfg={
            "acquisition": {
                "hardware_profile_path": str(profile_path),
                "hardware_ui_lock_path": str(lock_path),
            }
        },
        hardware_ui_lock=lock,
        hardware_launch_status_var=_ValueSink(),
        rendered_hardware_launch_actions={
            action_id: {
                "profile_path": str(profile_path.resolve()),
                "hardware_ui_lock_path": str(lock_path.resolve()),
                "profile_lock_sha256": str(plan["profile_lock_sha256"]),
                "profile_id": str(plan["profile_id"]),
                "profile_lock_identity": json.dumps(
                    lock, sort_keys=True, separators=(",", ":"), ensure_ascii=False
                ),
                "action_identity": json.dumps(
                    action, sort_keys=True, separators=(",", ":"), ensure_ascii=False
                ),
            }
        },
        launch_polar=lambda: dispatched.append("polar"),
    )
    return app, profile_path, action_id, dispatched


def test_click_time_hardware_gate_blocks_profile_tamper_after_button_render(
    tmp_path: Path, monkeypatch
) -> None:
    app, profile_path, action_id, dispatched = _rendered_polar_launch_state(tmp_path)
    errors: list[tuple[str, str]] = []
    monkeypatch.setattr(control_center.messagebox, "showerror", lambda title, text: errors.append((title, text)))
    profile_path.write_text(profile_path.read_text(encoding="utf-8") + "\n", encoding="utf-8")

    launched = control_center.PRAYCGControlCenter.launch_locked_hardware_action(app, action_id)

    assert launched is False
    assert dispatched == []
    assert errors and errors[0][0] == "Hardware launch blocked"
    assert "invalid or stale" in errors[0][1]


class _ValueSink:
    def __init__(self) -> None:
        self.value = None

    def set(self, value) -> None:
        self.value = value


class _ButtonSink:
    def __init__(self) -> None:
        self.options = {}

    def configure(self, **kwargs) -> None:
        self.options.update(kwargs)


class _TextSink:
    def delete(self, *_args) -> None:
        pass

    def insert(self, *_args) -> None:
        pass


class _TreeSink:
    def __init__(self) -> None:
        self.items: dict[str, dict] = {}
        self.selected: tuple[str, ...] = ()

    def get_children(self):
        return tuple(self.items)

    def delete(self, *items) -> None:
        for item in items:
            self.items.pop(item, None)
        self.selected = ()

    def insert(self, parent, _where, *, iid, **kwargs) -> None:
        self.items[iid] = {"parent": parent, **kwargs}

    def selection_set(self, item) -> None:
        self.selected = (item,)

    def focus(self, _item) -> None:
        pass

    def see(self, _item) -> None:
        pass

    def selection(self):
        return self.selected


def test_periodic_protocol_revalidation_does_not_rebuild_an_unchanged_stimulus_tree(monkeypatch) -> None:
    app = SimpleNamespace()
    app.locked_protocol = None
    app.protocol_lock_path = Path("protocol-lock.json")
    app.protocol_library_root = Path("atlas")
    app.cfg = {}
    app.stim_tree = object()
    app.protocol_lock_var = _ValueSink()
    app.protocol_lock_ui_identity = control_center.PRAYCGControlCenter.protocol_lock_ui_identity
    refreshes: list[str] = []
    app.refresh_protocol_stimulus_ui = lambda: refreshes.append("refresh")
    app.load_current_protocol_snapshot = lambda _validated: (
        Path("approved.json"),
        {
            "snapshot_sha256": "snapshot",
            "approval_envelope_sha256": "approval",
            "snapshot_core": {"engine_sha256": "engine"},
        },
    )
    validated = {
        "protocol_id": "PRAYCG3",
        "protocol_version": "3.0",
        "module_family": "PRAYCG_NATIVE",
        "manifest_sha256": "manifest",
        "runner_sha256": "runner",
        "display_name": "PRAYCG3",
    }
    monkeypatch.setattr(control_center, "validate_protocol_lock", lambda *_args: dict(validated))

    control_center.PRAYCGControlCenter.refresh_protocol_lock_status(app, update_acquisition=False)
    control_center.PRAYCGControlCenter.refresh_protocol_lock_status(app, update_acquisition=False)

    assert refreshes == ["refresh"]


def test_explicit_stimulus_rebuild_reselects_a_still_compatible_candidate() -> None:
    app = SimpleNamespace()
    candidate_id = "bundled::DEMO"
    app.stim_tree = _TreeSink()
    app.selected_stimulus_id = None
    app.selected_stimulus_candidate_id = candidate_id
    app.stimulus_tree_candidates = {}
    app.active_context = {"stimulus": {}}
    app.locked_protocol = {"protocol_id": "PRAYCG3"}
    app.protocol_lock_path = Path("protocol-lock.json")
    app.cfg = {"stimulus_registry": "registry.json", "protocol_asset_folders": {}}
    app.protocol_stimulus_model = type(
        "Model",
        (),
        {
            "resolve_locked_workflow": staticmethod(
                lambda *_args, **_kwargs: {
                    "status": "READY",
                    "plain_language": "ready",
                    "reasons": [],
                    "stimulus_nodes": [
                        {
                            "node_type": "folder",
                            "node_id": "stimulus-folder::bundled",
                            "display_name": "Bundled",
                        },
                        {
                            "node_type": "stimulus",
                            "node_id": candidate_id,
                            "candidate_id": candidate_id,
                            "parent_id": "stimulus-folder::bundled",
                            "display_name": "Demo",
                            "source_kind": "BUNDLED_SAMPLE_PACK",
                            "scientific_status": "DEMO_ONLY",
                            "validation_status": "PASS",
                            "selection_allowed": True,
                        },
                    ],
                    "prep_engines": [],
                }
            )
        },
    )()
    app.stimulus_workflow_var = _ValueSink()
    app.stimulus_use_button = _ButtonSink()
    app.stim_detail = _TextSink()
    app.render_protocol_prep_actions = lambda: None
    app.locked_protocol_record = lambda: None
    app.reconcile_active_stimulus_with_workflow = lambda workflow: (
        control_center.PRAYCGControlCenter.reconcile_active_stimulus_with_workflow(app, workflow)
    )
    selected_callbacks: list[str] = []
    def _select() -> None:
        app.selected_stimulus_candidate_id = app.stim_tree.selection()[0]
        selected_callbacks.append("selected")
    app.on_stim_select = _select

    control_center.PRAYCGControlCenter.refresh_protocol_stimulus_ui(app)

    assert app.selected_stimulus_candidate_id == candidate_id
    assert app.stim_tree.selection() == (candidate_id,)
    assert selected_callbacks == ["selected"]


def test_active_native_stimulus_is_preserved_when_new_native_lock_still_accepts_it(tmp_path: Path) -> None:
    active_folder = tmp_path / "installed-native-pack"
    active_folder.mkdir()
    candidate_id = "installed::PRAYCG_NATIVE_STORY_DEMO_V1::abc123"
    app = SimpleNamespace(
        selected_stimulus_id="PRAYCG_NATIVE_STORY_DEMO_V1",
        locked_protocol={"protocol_id": "PRAYCG4"},
        active_context={"stimulus": {"folder": str(active_folder)}},
    )
    workflow = {
        "status": "READY",
        "compatible_stimuli": [
            {
                "candidate_id": candidate_id,
                "pack_id": "PRAYCG_NATIVE_STORY_DEMO_V1",
                "source_kind": "INSTALLED_PACK",
                "source_path": str(active_folder),
            }
        ],
    }

    selected, note = control_center.PRAYCGControlCenter.reconcile_active_stimulus_with_workflow(
        app, workflow
    )

    assert selected == candidate_id
    assert note == ""
    assert app.selected_stimulus_id == "PRAYCG_NATIVE_STORY_DEMO_V1"
    assert app.active_context["stimulus"]["folder"] == str(active_folder)


def test_active_native_stimulus_is_cleared_when_atlas_lock_does_not_accept_it() -> None:
    calls: list[tuple[str, str]] = []
    app = SimpleNamespace(
        selected_stimulus_id="PRAYCG_NATIVE_STORY_DEMO_V1",
        locked_protocol={"protocol_id": "ATLAS_ERP_CORE_P3B_ADAPTATION"},
        active_context={"stimulus": {"folder": "C:/native-pack", "scientific_status": "DEMO_ONLY"}},
        mark_session_stale_for_stimulus_change=lambda reason: calls.append(("stale", reason)),
        save_active_context=lambda: calls.append(("save", "")),
        refresh_runner_detect_text=lambda: calls.append(("runner", "")),
        log=lambda message: calls.append(("log", message)),
    )
    workflow = {
        "status": "READY",
        "compatible_stimuli": [
            {
                "candidate_id": "bundled::PRAYCG_ATLAS_ERP_DEMO_V1",
                "pack_id": "PRAYCG_ATLAS_ERP_DEMO_V1",
                "source_kind": "BUNDLED_SAMPLE_PACK",
                "source_path": "C:/atlas-pack",
            }
        ],
    }

    selected, note = control_center.PRAYCGControlCenter.reconcile_active_stimulus_with_workflow(
        app, workflow
    )

    assert selected == ""
    assert "was cleared because it is not compatible" in note
    assert app.selected_stimulus_id is None
    assert app.active_context["stimulus"] == {}
    assert [kind for kind, _message in calls] == ["stale", "save", "runner", "log"]


def test_adding_master_under_atlas_lock_registers_without_replacing_active_context(
    tmp_path: Path, monkeypatch
) -> None:
    source = tmp_path / "new-master.mp4"
    source.write_bytes(b"\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2")
    registered: list[dict] = []
    notices: list[tuple[str, str]] = []
    prior_context = {
        "stimulus": {
            "id": "PRAYCG_ATLAS_ERP_DEMO_V1",
            "folder": str(tmp_path / "atlas-pack"),
            "scientific_status": "DEMO_ONLY",
        }
    }
    app = SimpleNamespace(
        cfg={
            "stimulus_root": str(tmp_path / "stimuli"),
            "stimulus_registry": str(tmp_path / "stimulus-registry.json"),
        },
        locked_protocol={"protocol_id": "ATLAS_ERP_CORE_P3B_ADAPTATION"},
        selected_stimulus_id="PRAYCG_ATLAS_ERP_DEMO_V1",
        selected_stimulus_candidate_id="bundled::PRAYCG_ATLAS_ERP_DEMO_V1",
        stimulus_tree_candidates={},
        active_context=json.loads(json.dumps(prior_context)),
        log=lambda _message: None,
        validate_mp4=lambda _path: {"status": "PASS_BASIC_VALIDATION", "duration_sec": 180.0},
        read_registry=lambda: {"schema": "PRAYCG_StimulusRegistry_v0_1", "stimuli": []},
        write_registry=lambda payload: registered.append(json.loads(json.dumps(payload))),
    )

    def _refresh() -> None:
        # Atlas does not accept generic MASTER_PRAYCG_MEDIA, so the filtered tree
        # intentionally contains no candidate for the newly registered master.
        app.stimulus_tree_candidates = {}

    app.refresh_stimulus_registry = _refresh
    monkeypatch.setattr(control_center.filedialog, "askopenfilename", lambda **_kwargs: str(source))
    monkeypatch.setattr(control_center.simpledialog, "askstring", lambda *_args, **_kwargs: "NEW_MASTER")
    monkeypatch.setattr(
        control_center.messagebox,
        "showinfo",
        lambda title, message, **_kwargs: notices.append((str(title), str(message))),
    )

    control_center.PRAYCGControlCenter.add_master_stimulus(app)

    assert registered[0]["stimuli"][0]["stimulus_id"] == "new_master"
    assert registered[0]["stimuli"][0]["tags"] == [MASTER_MEDIA_TAG]
    assert app.selected_stimulus_id == "PRAYCG_ATLAS_ERP_DEMO_V1"
    assert app.selected_stimulus_candidate_id == "bundled::PRAYCG_ATLAS_ERP_DEMO_V1"
    assert app.active_context == prior_context
    assert "not an input accepted by the current protocol lock" in notices[0][1]


def _alpha4_master_registry(tmp_path: Path) -> tuple[Path, Path, Path, str]:
    stimulus_root = tmp_path / "stimuli"
    master_dir = stimulus_root / "legacy_story" / "master"
    master_dir.mkdir(parents=True)
    master = master_dir / "stimulus_master.mp4"
    master.write_bytes(b"\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2")
    digest = hashlib.sha256(master.read_bytes()).hexdigest()
    status = "PASS_BASIC_VALIDATION"
    (master_dir / "master_sha256.txt").write_text(digest + "\n", encoding="utf-8")
    (master_dir / "master_media_validation_report.json").write_text(
        json.dumps(
            {
                "schema": "PRAYCG_MasterStimulus_Validation_v0_1",
                "status": status,
                "stimulus_id": "legacy_story",
                "copied_to": str(master.resolve()),
                "sha256": digest,
            }
        ),
        encoding="utf-8",
    )
    registry = tmp_path / "stimulus_registry.json"
    registry.write_text(
        json.dumps(
            {
                "schema": "PRAYCG_StimulusRegistry_v0_1",
                "stimuli": [
                    {
                        "stimulus_id": "legacy_story",
                        "folder": str((stimulus_root / "legacy_story").resolve()),
                        "master_mp4": str(master.resolve()),
                        "sha256": digest,
                        "validation_status": status,
                        "pinned": False,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    return registry, stimulus_root, master, digest


def test_genuine_alpha4_master_can_be_conservatively_tagged_with_backup(tmp_path: Path) -> None:
    registry, stimulus_root, _master, _digest = _alpha4_master_registry(tmp_path)

    result = migrate_legacy_master_registry(registry, stimulus_root)

    assert result["status"] == "PASS"
    assert result["migrated_ids"] == ["legacy_story"]
    assert result["scientific_status_promoted"] is False
    backup = Path(result["backup_path"])
    assert backup.is_file()
    old_row = json.loads(backup.read_text(encoding="utf-8"))["stimuli"][0]
    assert "tags" not in old_row
    new_row = json.loads(registry.read_text(encoding="utf-8"))["stimuli"][0]
    assert new_row["tags"] == [MASTER_MEDIA_TAG]
    assert new_row["stimulus_class"] == MASTER_MEDIA_TAG
    assert new_row["active_for_selection"] is True
    assert "scientific_status" not in new_row
    assert new_row["compatibility_migration"]["scientific_status_promoted"] is False


def test_alpha4_master_migration_is_idempotent(tmp_path: Path) -> None:
    registry, stimulus_root, _master, _digest = _alpha4_master_registry(tmp_path)
    first = migrate_legacy_master_registry(registry, stimulus_root)
    after_first = registry.read_bytes()

    second = migrate_legacy_master_registry(registry, stimulus_root)

    assert first["status"] == "PASS"
    assert second["status"] == "NO_CHANGES"
    assert second["migrated_ids"] == []
    assert second["already_tagged_ids"] == ["legacy_story"]
    assert second["backup_path"] == ""
    assert registry.read_bytes() == after_first


def test_tampered_alpha4_master_is_skipped_without_writing_registry_or_backup(tmp_path: Path) -> None:
    registry, stimulus_root, master, _digest = _alpha4_master_registry(tmp_path)
    original_registry = registry.read_bytes()
    master.write_bytes(master.read_bytes() + b"tampered")

    result = migrate_legacy_master_registry(registry, stimulus_root)

    assert result["status"] == "NO_CHANGES"
    assert result["migrated_ids"] == []
    assert result["backup_path"] == ""
    assert registry.read_bytes() == original_registry
    reasons = " ".join(result["skipped"][0]["reasons"])
    assert "live master MP4 hash does not match the registry" in reasons


def test_migration_does_not_reactivate_an_explicitly_inactive_legacy_master(tmp_path: Path) -> None:
    registry, stimulus_root, _master, _digest = _alpha4_master_registry(tmp_path)
    payload = json.loads(registry.read_text(encoding="utf-8"))
    payload["stimuli"][0]["active_for_selection"] = False
    registry.write_text(json.dumps(payload), encoding="utf-8")
    original_registry = registry.read_bytes()

    result = migrate_legacy_master_registry(registry, stimulus_root)

    assert result["status"] == "NO_CHANGES"
    assert result["migrated_ids"] == []
    assert result["backup_path"] == ""
    assert registry.read_bytes() == original_registry
    assert "explicitly inactive" in " ".join(result["skipped"][0]["reasons"])
