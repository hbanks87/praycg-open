"""Replay the mature compatibility regressions against the active alpha.3 modules.

Alpha.3 deliberately retains several alpha.2 schema identifiers.  The original
regressions remain useful for that compatibility surface, but importing the old
implementation alone would not test the public alpha.3 entry points.  This
harness loads the same test classes with their legacy module imports bound to
the active alpha.3 Control Center and platform core, then corrects only the
three release-identity assertions that are expected to differ.
"""
from __future__ import annotations

import importlib.util
import json
import re
import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType


PACKAGE = Path(__file__).resolve().parents[2]
TESTS = Path(__file__).resolve().parent
sys.path.insert(0, str(PACKAGE / "platform_core"))
sys.path.insert(0, str(PACKAGE / "control_center" / "scripts"))

import praycg_platform_core_v1_0_alpha_3 as active_platform_core  # noqa: E402
import praycg_control_center_v1_0_0_alpha_3 as active_control_center  # noqa: E402


_ABSENT = object()


def _load_suite(filename: str, module_name: str) -> ModuleType:
    """Load an existing suite with legacy imports redirected only during import."""
    aliases = {
        "praycg_platform_core_v1_0_alpha_2": active_platform_core,
        "praycg_control_center_v1_0_0_alpha_2": active_control_center,
    }
    # Hardware Registry imports the platform core at module import time.  Load a
    # private instance for each ported suite, then restore the canonical module
    # cache so the separately retained alpha.2 tests remain independent.
    managed_names = [*aliases, "praycg_hardware_registry_v0_1"]
    saved = {name: sys.modules.get(name, _ABSENT) for name in managed_names}
    try:
        sys.modules.update(aliases)
        sys.modules.pop("praycg_hardware_registry_v0_1", None)
        path = TESTS / filename
        spec = importlib.util.spec_from_file_location(module_name, path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f"Could not load regression source: {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        return module
    finally:
        for name, value in saved.items():
            if value is _ABSENT:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = value


command_path = _load_suite(
    "test_command_path_integration_hardening_v1_0_0_alpha_2.py",
    "_praycg_alpha3_port_command_path",
)
hardware_preflight = _load_suite(
    "test_hardware_preflight_hardening_v1_0_0_alpha_2.py",
    "_praycg_alpha3_port_hardware_preflight",
)
platform_gates = _load_suite(
    "test_platform_gates_v1_0_0_alpha_2.py",
    "_praycg_alpha3_port_platform_gates",
)
platform_integration = _load_suite(
    "test_platform_integration_v1_0_0_alpha_2.py",
    "_praycg_alpha3_port_platform_integration",
)
runner_binding = _load_suite(
    "test_runner_runtime_binding_v1_0_0_alpha_2.py",
    "_praycg_alpha3_port_runner_binding",
)
micro_handoff = _load_suite(
    "test_micro_handoff_integration_v0_95a.py",
    "_praycg_alpha3_port_micro_handoff",
)


class ActiveAlpha3CommandPathTests(command_path.CommandPathIntegrationHardeningTests):
    pass


class ActiveAlpha3HardwarePreflightTests(hardware_preflight.HardwarePreflightHardeningTests):
    pass


class ActiveAlpha3PlatformGateTests(platform_gates.PlatformAlpha2GateTests):
    def test_design_snapshot_and_runtime_draft_are_not_session_locks(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            snapshot, _sp, _profile, _hp, _template, draft = self._selection(Path(temp))
            self.assertEqual(active_platform_core.PLATFORM_VERSION, "1.0.0-alpha.3")
            self.assertEqual(snapshot["schema"], active_platform_core.PROTOCOL_SNAPSHOT_SCHEMA)
            self.assertEqual(snapshot["artifact_type"], "DESIGN_TIME_APPROVED_PROTOCOL_SNAPSHOT")
            self.assertEqual(snapshot["status"], "APPROVED")
            self.assertEqual(draft["schema"], active_platform_core.SESSION_DRAFT_SCHEMA)
            self.assertEqual(draft["status"], "READY_TO_CONNECT")
            self.assertEqual(draft["gate_status"]["SELECT"], "PASS")
            self.assertEqual(draft["gate_status"]["CONNECT"], "PENDING")
            self.assertNotEqual(draft["schema"], active_platform_core.SESSION_LOCK_SCHEMA)


class ActiveAlpha3PlatformIntegrationTests(platform_integration.PlatformAlpha2IntegrationTests):
    def test_version_and_registered_entry_points(self) -> None:
        self.assertEqual(active_control_center.APP_VERSION, "1.0.0-alpha.3")
        self.assertEqual(
            active_control_center.CONFIG_SCHEMA,
            "PRAYCG_ControlCenter_Config_v1_0_alpha_3",
        )
        paths = active_control_center.bundled_tool_paths()
        self.assertNotIn("platform_workbench", paths)
        for key in (
            "protocol_atlas",
            "protocol_forge",
            "hardware_registry",
            "acquisition_supervisor",
            "bids_exporter",
            "release_validator",
            "cue_locked_gamma_forensics",
        ):
            self.assertTrue(Path(paths[key]).is_file(), f"{key}: {paths[key]}")


class ActiveAlpha3RunnerRuntimeBindingTests(runner_binding.RunnerRuntimeBindingTests):
    pass


class ActiveAlpha3MicroHandoffIntegrationTests(micro_handoff.MicroHandoffIntegrationTests):
    def test_control_center_version_and_schema(self) -> None:
        self.assertEqual(active_control_center.APP_VERSION, "1.0.0-alpha.3")
        self.assertEqual(
            active_control_center.CONFIG_SCHEMA,
            "PRAYCG_ControlCenter_Config_v1_0_alpha_3",
        )


class ActiveAlpha3HarnessIdentityTests(unittest.TestCase):
    def test_every_replayed_suite_is_bound_to_active_modules(self) -> None:
        self.assertIs(command_path.control_center, active_control_center)
        self.assertIs(platform_gates.alpha2, active_platform_core)
        self.assertEqual(platform_gates.PLATFORM_VERSION, "1.0.0-alpha.3")
        self.assertIs(runner_binding.platform_core, active_platform_core)
        self.assertIs(runner_binding.control_center, active_control_center)
        self.assertEqual(platform_integration.APP_VERSION, "1.0.0-alpha.3")
        self.assertEqual(micro_handoff.APP_VERSION, "1.0.0-alpha.3")


class ActiveAlpha3ConsolidationTests(unittest.TestCase):
    """Pin the alpha.3 operator consolidation and release-owned registry."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.source_path = (
            PACKAGE / "control_center" / "scripts" / "praycg_control_center_v1_0_0_alpha_3.py"
        )
        cls.source = cls.source_path.read_text(encoding="utf-8")
        cls.registry = json.loads(
            (PACKAGE / "config" / "module_registry_v1_0_alpha_3.json").read_text(
                encoding="utf-8"
            )
        )

    def test_six_operator_workspaces_and_no_platform_workbench_tab(self) -> None:
        tab_labels = re.findall(r'self\.nb\.add\([^\n]+text="([^"]+)"', self.source)
        self.assertEqual(
            tab_labels,
            [
                "Dashboard",
                "Stimulus Library",
                "Acquisition",
                "Protocol Atlas / Runner",
                "Analysis",
                "Settings",
            ],
        )
        self.assertNotIn('text="Platform Workbench"', self.source)

    def test_acquisition_owns_all_four_hardware_workspaces(self) -> None:
        acquisition_tabs = re.findall(
            r'self\.acq_nb\.add\([^\n]+text="([^"]+)"', self.source
        )
        self.assertEqual(
            acquisition_tabs,
            [
                "1. Hardware Profile",
                "2. Connect & Launch",
                "3. Live Checks",
                "4. Monitor, Record & Arm",
            ],
        )
        for action in (
            "Start New Acquisition Session / UUID",
            "Run 30-Second Profile Preflight",
            "Arm Acquisition Session",
            "ALS Barcode Placement Test",
        ):
            self.assertIn(action, self.source)

    def test_alpha3_registry_federates_native_and_atlas_without_hardware_authority(self) -> None:
        self.assertEqual(self.registry["schema"], "PRAYCG_ModuleRegistry_v1_0_alpha_3")
        self.assertEqual(self.registry["version"], "1.0.0-alpha.3")
        modules = {item["id"]: item for item in self.registry["modules"]}
        self.assertNotIn("platform_workbench", modules)
        self.assertEqual(modules["hardware_registry"]["workspace"], "Acquisition")
        self.assertEqual(modules["protocol_atlas"]["workspace"], "Runner / PsychoPy")
        self.assertEqual(modules["protocol_atlas"]["hardware_stack_effect"], "NONE")
        federation = self.registry["protocol_federation"]
        self.assertEqual(federation["native_entries"], ["PRAYCG3", "PRAYCG4", "SMG"])
        self.assertEqual(federation["atlas_entry_count"], 11)
        self.assertFalse(federation["arbitrary_downloaded_code_allowed"])

    def test_active_import_and_default_runtime_artifacts_are_alpha3(self) -> None:
        self.assertIn("from praycg_platform_core_v1_0_alpha_3 import", self.source)
        config = active_control_center.default_config()
        acquisition = config["acquisition"]
        self.assertTrue(acquisition["session_lock_path"].endswith("active_session_lock_v1_0_alpha_3.json"))
        self.assertTrue(acquisition["session_draft_path"].endswith("active_session_draft_v1_0_alpha_3.json"))
        self.assertTrue(acquisition["state_path"].endswith("active_acquisition_state_v1_0_alpha_3.json"))


if __name__ == "__main__":
    unittest.main()
