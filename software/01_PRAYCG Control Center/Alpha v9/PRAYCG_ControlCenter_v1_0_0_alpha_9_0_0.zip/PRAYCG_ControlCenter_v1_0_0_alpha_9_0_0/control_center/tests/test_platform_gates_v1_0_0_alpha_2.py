from __future__ import annotations

import tempfile
import unittest
from copy import deepcopy
from pathlib import Path
import os
import shutil
import subprocess
import threading
from unittest.mock import patch


PACKAGE = Path(__file__).resolve().parents[2]
import sys

sys.path.insert(0, str(PACKAGE / "platform_core"))
sys.path.insert(0, str(PACKAGE / "tools" / "Hardware_Registry_v0_1"))

import praycg_platform_core_v1_0_alpha_1 as alpha1  # noqa: E402
import praycg_platform_core_v1_0_alpha_2 as alpha2  # noqa: E402
import praycg_platform_core_v1_0_alpha_3 as alpha3  # noqa: E402
import praycg_platform_core_v1_0_alpha_4 as alpha4  # noqa: E402
import praycg_hardware_registry_v0_1 as hardware_registry  # noqa: E402
from praycg_platform_core_v1_0_alpha_2 import (  # noqa: E402
    PLATFORM_VERSION,
    PROTOCOL_SNAPSHOT_SCHEMA,
    SESSION_DRAFT_SCHEMA,
    SESSION_LOCK_SCHEMA,
    advance_session_gate,
    active_acquisition_owner_activity,
    active_acquisition_owner_path,
    aggregate_hardware_preflight,
    build_hardware_profile,
    build_session_draft,
    build_session_lock,
    bind_active_acquisition_owner_lease,
    claim_active_acquisition_owner,
    compile_protocol,
    issue_authorized_runner_lease,
    finish_active_acquisition_owner,
    finish_authorized_runner_lease,
    load_json,
    sha256_json,
    validate_session_lock_identity,
    write_json,
)


class PlatformAlpha2GateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.library = PACKAGE / "tools" / "ProtocolRunner_ModuleLibrary_v1_0"
        self.protocol_path = self.library / "protocols" / "PRAYCG4_shotorder_four_branch_v1_0.json"
        self.hardware_path = PACKAGE / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json"
        self.polar_path = PACKAGE / "config" / "hardware" / "Polar_H10_RR_v0_1.json"

    def _selection(
        self,
        root: Path,
        hardware_paths: list[Path] | None = None,
        *,
        session_id: str = "001",
        controller_instance_id: str = "synthetic-control-center",
    ):
        build_dir, snapshot = compile_protocol(
            self.protocol_path,
            self.library,
            root / "protocol_build",
            human_reviewed_by="Alpha Tester",
        )
        snapshot_path = build_dir / "approved_protocol_snapshot.json"
        profile_path = root / "hardware_profile.json"
        profile = build_hardware_profile(
            hardware_paths or [self.hardware_path],
            profile_path,
            profile_id="alpha2_test",
            reviewed_by="Alpha Tester",
        )
        template = load_json(PACKAGE / "config" / "study_session_TEMPLATE_v0_1.json")
        template.update({
            "study_id": "SYNTH",
            "session_id": session_id,
            "participant_pseudonym": "P001",
            "protocol_module": str(self.protocol_path),
            "hardware_profile": str(profile_path),
            "stimulus_id": "SYNTH_STIMULUS",
            "stimulus_folder": str(root),
            "media_selection_snapshot": {
                "synthetic_media": {"path": str(self.protocol_path), "sha256": alpha1.sha256_file(self.protocol_path)},
            },
            "private_output_locations": {"session_log_dir": str(root)},
            "control_center_process_id": controller_instance_id,
        })
        draft = build_session_draft(
            template,
            snapshot,
            profile,
            root / "session_draft.json",
            protocol_snapshot_path=snapshot_path,
            hardware_profile_path=profile_path,
        )
        return snapshot, snapshot_path, profile, profile_path, template, draft

    @staticmethod
    def _module_report(selected: dict, status: str = "PASS", *, expected_run_uuid: str = "001") -> dict:
        stream_rows = []
        for stream in selected["streams"]:
            source_id = str(stream.get("source_id") or "")
            if not source_id:
                prefix = str(stream.get("source_id_prefix") or "")
                suffix = str(stream.get("source_id_suffix") or "")
                examples = list(stream.get("source_id_examples") or [])
                run_fragment = expected_run_uuid.replace("-", "")[:12]
                source_id = str(examples[0]) if examples else f"{prefix or 'synthetic_source_'}{run_fragment}{suffix}"
            stream_rows.append({
                "lsl_name": stream["lsl_name"],
                "status": status,
                "resolved_candidate_count": 1,
                "observed_source_id": source_id,
            })
        return {
            "schema": "PRAYCG_HardwareModulePreflight_v1_0_alpha_2",
            "expected_run_uuid": expected_run_uuid,
            "module_id": selected["module_id"],
            "module_file_sha256": selected.get("module_file_sha256") or selected.get("sha256"),
            "module_canonical_sha256": selected.get("module_canonical_sha256"),
            "status": status,
            "streams": stream_rows,
        }

    def _armed_owner_session(
        self,
        log_root: Path,
        run_uuid: str,
        *,
        controller_instance_id: str = "synthetic-control-center",
    ):
        run_root = log_root / "protocol_runs" / run_uuid
        run_root.mkdir(parents=True, exist_ok=True)
        _s, _sp, profile, _hp, _t, draft = self._selection(
            run_root,
            session_id=run_uuid,
            controller_instance_id=controller_instance_id,
        )
        preflight = aggregate_hardware_preflight(
            profile,
            [
                self._module_report(module, expected_run_uuid=run_uuid)
                for module in profile["modules"]
            ],
            expected_run_uuid=run_uuid,
        )
        lock_path = run_root / "runtime_session_lock.json"
        locked = build_session_lock(draft, preflight, lock_path, operator="Operator")
        armed = advance_session_gate(locked, "ARM", lock_path, operator="Operator")
        return lock_path, armed

    @staticmethod
    def _acquire_claim(lock: dict, **changes) -> dict:
        protocol = lock["lock_core"]["selection_identity"]["protocol"]
        root = Path(lock["session"]["private_output_locations"]["session_log_dir"])
        log_root = root.parent.parent
        owner_path = active_acquisition_owner_path(log_root)
        if owner_path.is_file():
            owner = load_json(owner_path)
        else:
            owner_path, owner = claim_active_acquisition_owner(
                log_root,
                lock,
                root / "runtime_session_lock.json",
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
        lease_path = root / "authorized_runner_lease.json"
        if lease_path.is_file():
            lease = load_json(lease_path)
        else:
            lease_path, lease = issue_authorized_runner_lease(
                lock,
                root / "runtime_session_lock.json",
                "synthetic-test-claim-token-" + "x" * 48,
                launch_mode="psychopy_python",
                launch_command=[sys.executable, "runner.py"],
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
        if str(owner.get("status") or "") == "CLAIMED":
            owner = bind_active_acquisition_owner_lease(
                owner_path,
                lease_path,
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
        lease_core = lease["lease_core"]
        owner_core = owner["owner_core"]
        evidence = {
            "event": "AUTHORIZED_RUNNER_PROCESS_CLAIMED_BEFORE_SPAWN",
            "run_uuid": lock["session"]["session_id"],
            "launch_mode": "psychopy_python",
            "protocol_id": protocol["protocol_id"],
            "protocol_version": protocol["protocol_version"],
            "runner_sha256": protocol["runner_file_sha256"],
            "lease_path": str(lease_path),
            "lease_id": lease_core["lease_id"],
            "lease_core_sha256": lease["lease_core_sha256"],
            "lease_claim_token_sha256": lease_core["claim_token_sha256"],
            "armed_state_sha256": lease_core["armed_state_sha256"],
            "active_owner_path": str(owner_path),
            "active_owner_id": owner_core["owner_id"],
            "active_owner_core_sha256": owner["owner_core_sha256"],
        }
        evidence.update(changes)
        return evidence

    def test_design_snapshot_and_runtime_draft_are_not_session_locks(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            snapshot, _sp, _profile, _hp, _template, draft = self._selection(Path(temp))
            self.assertEqual(PLATFORM_VERSION, "1.0.0-alpha.2")
            self.assertEqual(snapshot["schema"], PROTOCOL_SNAPSHOT_SCHEMA)
            self.assertEqual(snapshot["artifact_type"], "DESIGN_TIME_APPROVED_PROTOCOL_SNAPSHOT")
            self.assertEqual(snapshot["status"], "APPROVED")
            self.assertEqual(draft["schema"], SESSION_DRAFT_SCHEMA)
            self.assertEqual(draft["status"], "READY_TO_CONNECT")
            self.assertEqual(draft["gate_status"]["SELECT"], "PASS")
            self.assertEqual(draft["gate_status"]["CONNECT"], "PENDING")
            self.assertNotEqual(draft["schema"], SESSION_LOCK_SCHEMA)

    def test_public_session_builder_exposes_prepare_and_lock_only(self) -> None:
        builder = (
            PACKAGE
            / "tools"
            / "Study_Session_Builder_v0_1"
            / "praycg_study_session_builder_v0_1.py"
        )
        help_run = subprocess.run(
            [sys.executable, str(builder), "--help"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(help_run.returncode, 0, help_run.stderr)
        self.assertIn("{prepare,lock}", help_run.stdout)
        rejected = subprocess.run(
            [sys.executable, str(builder), "acquire", "--out", "unused.json"],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertNotEqual(rejected.returncode, 0)
        self.assertIn("invalid choice", rejected.stderr)

    def test_protocol_file_hash_mismatch_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _build, snapshot = compile_protocol(
                self.protocol_path, self.library, root / "build", human_reviewed_by="Reviewer"
            )
            altered = root / "altered_protocol.json"
            module = load_json(self.protocol_path)
            module["display_name"] = "Altered after approval"
            write_json(altered, module)
            profile_path = root / "profile.json"
            profile = build_hardware_profile(
                [self.hardware_path], profile_path, profile_id="test", reviewed_by="Reviewer"
            )
            template = load_json(PACKAGE / "config" / "study_session_TEMPLATE_v0_1.json")
            template.update({
                "study_id": "S", "session_id": "1", "participant_pseudonym": "P1",
                "protocol_module": str(altered), "hardware_profile": str(profile_path),
            })
            draft = build_session_draft(template, snapshot, profile, root / "draft.json")
            self.assertEqual(draft["status"], "INVALID_SELECTION")
            self.assertTrue(any("protocol" in item.lower() for item in draft["validation"]["errors"]))

    def test_runner_hash_mismatch_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            library = root / "library"
            shutil.copytree(self.library, library)
            protocol_path = library / "protocols" / self.protocol_path.name
            _build, snapshot = compile_protocol(
                protocol_path, library, root / "build", human_reviewed_by="Reviewer"
            )
            runner_path = library / snapshot["snapshot_core"]["runner_entry"]
            runner_path.write_text(runner_path.read_text(encoding="utf-8") + "\n# altered\n", encoding="utf-8")
            profile_path = root / "profile.json"
            profile = build_hardware_profile(
                [self.hardware_path], profile_path, profile_id="test", reviewed_by="Reviewer"
            )
            template = load_json(PACKAGE / "config" / "study_session_TEMPLATE_v0_1.json")
            template.update({
                "study_id": "S", "session_id": "1", "participant_pseudonym": "P1",
                "protocol_module": str(protocol_path), "hardware_profile": str(profile_path),
            })
            draft = build_session_draft(template, snapshot, profile, root / "draft.json")
            self.assertEqual(draft["status"], "INVALID_SELECTION")
            self.assertIn("runner", " ".join(draft["validation"]["errors"]).lower())

    def test_shared_engine_hash_mismatch_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            library = root / "library"
            shutil.copytree(self.library, library)
            protocol_path = library / "protocols" / self.protocol_path.name
            _build, snapshot = compile_protocol(
                protocol_path, library, root / "build", human_reviewed_by="Reviewer"
            )
            engine_path = library / "scripts" / "praycg_protocol_engine_v3_0.py"
            engine_path.write_text(engine_path.read_text(encoding="utf-8") + "\n# altered\n", encoding="utf-8")
            profile_path = root / "profile.json"
            profile = build_hardware_profile(
                [self.hardware_path], profile_path, profile_id="test", reviewed_by="Reviewer"
            )
            template = load_json(PACKAGE / "config" / "study_session_TEMPLATE_v0_1.json")
            template.update({
                "study_id": "S", "session_id": "1", "participant_pseudonym": "P1",
                "protocol_module": str(protocol_path), "hardware_profile": str(profile_path),
            })
            draft = build_session_draft(template, snapshot, profile, root / "draft.json")
            self.assertEqual(draft["status"], "INVALID_SELECTION")
            self.assertIn("engine", " ".join(draft["validation"]["errors"]).lower())

    def test_hardware_profile_path_or_content_mismatch_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            snapshot, _sp, profile, profile_path, template, _draft = self._selection(root)
            other_path = root / "other_profile.json"
            other = deepcopy(profile)
            other["profile_id"] = "other"
            other["canonical_sha256"] = sha256_json({k: v for k, v in other.items() if k != "canonical_sha256"})
            write_json(other_path, other)
            template["hardware_profile"] = str(other_path)
            draft = build_session_draft(
                template,
                snapshot,
                profile,
                root / "mismatch.json",
                hardware_profile_path=profile_path,
            )
            self.assertEqual(draft["status"], "INVALID_SELECTION")
            joined = " ".join(draft["validation"]["errors"]).lower()
            self.assertIn("hardware profile", joined)

    def test_changed_hardware_module_definition_blocks_selection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            local_hardware = root / "hardware.json"
            shutil.copy2(self.hardware_path, local_hardware)
            _build, snapshot = compile_protocol(
                self.protocol_path, self.library, root / "build", human_reviewed_by="Reviewer"
            )
            profile_path = root / "profile.json"
            profile = build_hardware_profile(
                [local_hardware], profile_path, profile_id="test", reviewed_by="Reviewer"
            )
            changed = load_json(local_hardware)
            changed["display_name"] = "Changed after approval"
            write_json(local_hardware, changed)
            template = load_json(PACKAGE / "config" / "study_session_TEMPLATE_v0_1.json")
            template.update({
                "study_id": "S", "session_id": "1", "participant_pseudonym": "P1",
                "protocol_module": str(self.protocol_path), "hardware_profile": str(profile_path),
            })
            draft = build_session_draft(template, snapshot, profile, root / "draft.json")
            self.assertEqual(draft["status"], "INVALID_SELECTION")
            self.assertIn("hardware module", " ".join(draft["validation"]["errors"]).lower())

    def test_full_profile_preflight_requires_every_module_and_stream(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, _d = self._selection(
                root, [self.hardware_path, self.polar_path]
            )
            only_first = aggregate_hardware_preflight(
                profile, [self._module_report(profile["modules"][0])]
            )
            self.assertEqual(only_first["status"], "INELIGIBLE")
            both = aggregate_hardware_preflight(
                profile, [self._module_report(module) for module in profile["modules"]]
            )
            self.assertEqual(both["status"], "PASS", both)
            incomplete = self._module_report(profile["modules"][0])
            incomplete["streams"] = incomplete["streams"][:-1]
            missing_stream = aggregate_hardware_preflight(
                profile, [incomplete, self._module_report(profile["modules"][1])]
            )
            self.assertEqual(missing_stream["status"], "INELIGIBLE")

    def test_profile_preflight_invokes_every_selected_module(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, _d = self._selection(
                root, [self.hardware_path, self.polar_path]
            )

            def synthetic_live(module, _duration, *, module_file_sha256=None, expected_run_uuid=""):
                selected = next(item for item in profile["modules"] if item["module_id"] == module["module_id"])
                result = self._module_report(selected)
                result["module_file_sha256"] = module_file_sha256
                result["expected_run_uuid"] = expected_run_uuid
                return result

            with patch.object(hardware_registry, "live_preflight", side_effect=synthetic_live) as mocked:
                result = hardware_registry.profile_preflight(profile, 0.01)
            self.assertEqual(mocked.call_count, len(profile["modules"]))
            self.assertEqual(result["status"], "PASS", result)

    def test_preflight_hash_mismatch_is_ineligible(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            _s, _sp, profile, _hp, _t, _d = self._selection(Path(temp))
            report = self._module_report(profile["modules"][0])
            report["module_file_sha256"] = "0" * 64
            aggregate = aggregate_hardware_preflight(profile, [report])
            self.assertEqual(aggregate["status"], "INELIGIBLE")

    def test_pass_preflight_binds_lock_and_gate_order(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "logs" / "protocol_runs" / "001"
            root.mkdir(parents=True)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(
                profile, [self._module_report(module) for module in profile["modules"]]
            )
            state_path = root / "runtime_session_lock.json"
            lock = build_session_lock(draft, preflight, state_path, operator="Operator")
            self.assertEqual(lock["schema"], SESSION_LOCK_SCHEMA)
            self.assertEqual(lock["status"], "LOCKED_READY_TO_ARM")
            self.assertEqual(lock["lock_core"]["preflight_report_sha256"], preflight["canonical_sha256"])
            with self.assertRaisesRegex(ValueError, "ARM"):
                advance_session_gate(lock, "ACQUIRE", state_path, operator="Operator")
            armed = advance_session_gate(lock, "ARM", state_path, operator="Operator")
            acquiring = advance_session_gate(
                armed,
                "ACQUIRE",
                state_path,
                operator="Operator",
                evidence=self._acquire_claim(armed),
            )
            self.assertEqual(acquiring["status"], "ACQUIRING")
            self.assertEqual(acquiring["lock_identity_sha256"], lock["lock_identity_sha256"])

    def test_unrecorded_operator_cannot_lock_or_arm(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(profile, [self._module_report(profile["modules"][0])])
            rejected = build_session_lock(draft, preflight, root / "rejected.json", operator="UNRECORDED")
            self.assertEqual(rejected["status"], "NOT_LOCKABLE")
            lock = build_session_lock(draft, preflight, root / "lock.json", operator="Operator")
            with self.assertRaisesRegex(ValueError, "recorded operator"):
                advance_session_gate(lock, "ARM", root / "armed.json", operator="EDIT_ME")

    def test_caution_requires_documented_override_and_ineligible_never_overrides(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            caution = aggregate_hardware_preflight(
                profile, [self._module_report(profile["modules"][0], "CAUTION")]
            )
            blocked = build_session_lock(draft, caution, root / "blocked.json", operator="Operator")
            self.assertEqual(blocked["status"], "NOT_LOCKABLE")
            accepted = build_session_lock(
                draft,
                caution,
                root / "accepted.json",
                operator="Operator",
                allow_caution_override=True,
                override_reason="Reviewed a small rate deviation; acquisition may proceed as an alpha test.",
            )
            self.assertEqual(accepted["status"], "LOCKED_READY_TO_ARM")
            self.assertEqual(accepted["gate_status"]["PREFLIGHT"], "CAUTION_ACCEPTED")
            ineligible = deepcopy(caution)
            ineligible["status"] = "INELIGIBLE"
            ineligible["canonical_sha256"] = sha256_json({k: v for k, v in ineligible.items() if k != "canonical_sha256"})
            rejected = build_session_lock(
                draft,
                ineligible,
                root / "rejected.json",
                operator="Operator",
                allow_caution_override=True,
                override_reason="Attempted override",
            )
            self.assertEqual(rejected["status"], "NOT_LOCKABLE")

    def test_control_center_supplemental_caution_requires_the_same_override(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            snapshot, snapshot_path, profile, profile_path, template, _draft = self._selection(root)
            template["control_center_readiness"] = "CAUTION"
            template["control_center_readiness_message"] = "ALS placement response was weak."
            draft = build_session_draft(
                template,
                snapshot,
                profile,
                root / "caution_draft.json",
                protocol_snapshot_path=snapshot_path,
                hardware_profile_path=profile_path,
            )
            preflight = aggregate_hardware_preflight(
                profile, [self._module_report(module) for module in profile["modules"]]
            )
            blocked = build_session_lock(draft, preflight, root / "blocked.json", operator="Operator")
            self.assertEqual(blocked["status"], "NOT_LOCKABLE")
            accepted = build_session_lock(
                draft,
                preflight,
                root / "accepted.json",
                operator="Operator",
                allow_caution_override=True,
                override_reason="Reviewed the weak ALS response and accepted it for this alpha session.",
            )
            self.assertEqual(accepted["status"], "LOCKED_READY_TO_ARM")
            self.assertEqual(accepted["lock_core"]["preflight_status"], "CAUTION")
            self.assertEqual(accepted["gate_status"]["PREFLIGHT"], "CAUTION_ACCEPTED")

    def test_tampered_lock_identity_blocks_arm(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(profile, [self._module_report(profile["modules"][0])])
            lock = build_session_lock(draft, preflight, root / "lock.json", operator="Operator")
            lock["lock_core"]["operator"] = "Changed after locking"
            with self.assertRaisesRegex(ValueError, "identity"):
                advance_session_gate(lock, "ARM", root / "armed.json", operator="Operator")

    def test_tampered_session_metadata_invalidates_lock(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(profile, [self._module_report(profile["modules"][0])])
            lock = build_session_lock(draft, preflight, root / "lock.json", operator="Operator")
            lock["session"]["participant_pseudonym"] = "CHANGED_AFTER_LOCK"
            report = validate_session_lock_identity(lock)
            self.assertEqual(report.status, "INELIGIBLE")
            self.assertIn("metadata changed", " ".join(report.errors).lower())

    def test_approval_envelope_metadata_is_hash_bound(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            snapshot, _sp, profile, profile_path, template, _draft = self._selection(root)
            snapshot["human_reviewed_by"] = "Changed After Approval"
            draft = build_session_draft(
                template,
                snapshot,
                profile,
                root / "tampered_approval_draft.json",
                hardware_profile_path=profile_path,
            )
            self.assertEqual(draft["status"], "INVALID_SELECTION")
            self.assertIn("approved", " ".join(draft["validation"]["errors"]).lower())

    def test_runtime_state_hash_and_history_chain_detect_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(
                profile, [self._module_report(profile["modules"][0])]
            )
            lock = build_session_lock(draft, preflight, root / "lock.json", operator="Operator")
            altered_state = deepcopy(lock)
            altered_state["status"] = "ARMED"
            self.assertEqual(validate_session_lock_identity(altered_state).status, "INELIGIBLE")
            altered_history = deepcopy(lock)
            altered_history["runtime_history"][0]["operator"] = "Changed"
            self.assertEqual(validate_session_lock_identity(altered_history).status, "INELIGIBLE")
            altered_gate = deepcopy(lock)
            altered_gate["gate_status"]["ARM"] = "PASS"
            self.assertEqual(validate_session_lock_identity(altered_gate).status, "INELIGIBLE")

    def test_runtime_lock_freezes_research_critical_runner_configuration(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(
                profile, [self._module_report(profile["modules"][0])]
            )
            lock = build_session_lock(draft, preflight, root / "lock.json", operator="Operator")
            policy = lock["session"]["runner_configuration_policy"]
            self.assertEqual(policy["baseline_seconds"], 120.0)
            self.assertEqual(policy["washout_seconds"], 120.0)
            self.assertTrue(policy["enable_final_reflection_baseline"])
            self.assertTrue(policy["enable_per_phase_confound_reports"])
            self.assertTrue(policy["enable_eeg_watchdog"])
            self.assertTrue(policy["enable_runner_als_barcode"])

    def test_post_run_gates_cannot_be_skipped(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "logs" / "protocol_runs" / "001"
            root.mkdir(parents=True)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(profile, [self._module_report(profile["modules"][0])])
            state_path = root / "runtime_session_lock.json"
            record = build_session_lock(draft, preflight, state_path, operator="Operator")
            record = advance_session_gate(record, "ARM", state_path, operator="Operator")
            record = advance_session_gate(
                record,
                "ACQUIRE",
                state_path,
                operator="Operator",
                evidence=self._acquire_claim(record),
            )
            record = advance_session_gate(record, "FINALIZE", state_path, operator="Operator")
            with self.assertRaisesRegex(ValueError, "QC"):
                advance_session_gate(record, "ANALYZE", state_path, operator="Operator")
            for stage in ("QC", "ANALYZE", "EXPORT", "VERIFY"):
                record = advance_session_gate(record, stage, state_path, operator="Operator")
            self.assertEqual(record["status"], "VERIFIED_COMPLETE")

    def test_same_runtime_transition_cannot_be_claimed_twice(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "logs" / "protocol_runs" / "001"
            root.mkdir(parents=True)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(
                profile, [self._module_report(profile["modules"][0])]
            )
            state_path = root / "runtime_session_lock.json"
            locked = build_session_lock(draft, preflight, state_path, operator="Operator")
            armed = advance_session_gate(locked, "ARM", state_path, operator="Operator")
            stale_armed = deepcopy(armed)
            advance_session_gate(
                armed,
                "ACQUIRE",
                state_path,
                operator="Operator",
                evidence=self._acquire_claim(armed),
            )
            with self.assertRaisesRegex(ValueError, "changed|already claimed"):
                advance_session_gate(
                    stale_armed,
                    "ACQUIRE",
                    state_path,
                    operator="Operator",
                    evidence=self._acquire_claim(stale_armed),
                )
            claims = list(root.glob("*.acquire.transition_claim.json"))
            self.assertEqual(len(claims), 1)

    def test_acquire_requires_exact_bound_process_claim(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "logs" / "protocol_runs" / "001"
            root.mkdir(parents=True)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(
                profile, [self._module_report(profile["modules"][0])]
            )
            state_path = root / "runtime_session_lock.json"
            locked = build_session_lock(draft, preflight, state_path, operator="Operator")
            armed = advance_session_gate(locked, "ARM", state_path, operator="Operator")
            invalid_claims = (
                None,
                self._acquire_claim(armed, event="RUN_REQUESTED"),
                self._acquire_claim(armed, run_uuid="wrong-run"),
                self._acquire_claim(armed, launch_mode="open_psychopy_coder_then_open_runner_file"),
                self._acquire_claim(armed, protocol_id="wrong-protocol"),
                self._acquire_claim(armed, protocol_version="wrong-version"),
                self._acquire_claim(armed, runner_sha256="0" * 64),
            )
            for evidence in invalid_claims:
                with self.subTest(evidence=evidence):
                    with self.assertRaisesRegex(ValueError, "ACQUIRE runner-process claim"):
                        advance_session_gate(
                            armed,
                            "ACQUIRE",
                            state_path,
                            operator="Operator",
                            evidence=evidence,
                        )

    def test_acquire_or_later_lock_revalidates_claim_semantics(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp) / "logs" / "protocol_runs" / "001"
            root.mkdir(parents=True)
            _s, _sp, profile, _hp, _t, draft = self._selection(root)
            preflight = aggregate_hardware_preflight(
                profile, [self._module_report(profile["modules"][0])]
            )
            state_path = root / "runtime_session_lock.json"
            locked = build_session_lock(draft, preflight, state_path, operator="Operator")
            armed = advance_session_gate(locked, "ARM", state_path, operator="Operator")
            acquiring = advance_session_gate(
                armed,
                "ACQUIRE",
                state_path,
                operator="Operator",
                evidence=self._acquire_claim(armed),
            )
            altered = deepcopy(acquiring)
            event = altered["runtime_history"][-1]
            event["evidence"]["launch_mode"] = "open_psychopy_coder_then_open_runner_file"
            event["evidence_sha256"] = sha256_json(event["evidence"])
            event["event_sha256"] = sha256_json({
                key: value for key, value in event.items() if key != "event_sha256"
            })
            altered["state_sha256"] = sha256_json({
                "lock_identity_sha256": altered["lock_identity_sha256"],
                "status": altered["status"],
                "current_stage": altered["current_stage"],
                "gate_status": altered["gate_status"],
                "runtime_history": altered["runtime_history"],
                "validation": altered["validation"],
            })
            report = validate_session_lock_identity(altered)
            self.assertEqual(report.status, "INELIGIBLE")
            self.assertIn("supported direct mode", " ".join(report.errors))

    def test_log_root_owner_claim_serializes_two_control_centers(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            lock_a, armed_a = self._armed_owner_session(log_root, "run-a", controller_instance_id="control-center-a")
            lock_b, armed_b = self._armed_owner_session(log_root, "run-b", controller_instance_id="control-center-b")
            barrier = threading.Barrier(2)
            winners = []
            failures = []

            def contend(lock_path, armed, instance_id):
                barrier.wait()
                try:
                    result = claim_active_acquisition_owner(
                        log_root,
                        armed,
                        lock_path,
                        controller_instance_id=instance_id,
                        controller_pid=os.getpid(),
                    )
                    winners.append(result)
                except Exception as exc:
                    failures.append(str(exc))

            threads = (
                threading.Thread(target=contend, args=(lock_a, armed_a, "control-center-a")),
                threading.Thread(target=contend, args=(lock_b, armed_b, "control-center-b")),
            )
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join(timeout=10.0)
            self.assertTrue(all(not thread.is_alive() for thread in threads))
            self.assertEqual(len(winners), 1)
            self.assertEqual(len(failures), 1)
            self.assertIn("active or unresolved", failures[0])
            current = load_json(active_acquisition_owner_path(log_root))
            self.assertEqual(current["owner_core"]["owner_id"], winners[0][1]["owner_core"]["owner_id"])

    def test_dead_finalized_owner_reclaims_but_unresolved_acquire_does_not(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            lock_a, armed_a = self._armed_owner_session(log_root, "run-a")
            evidence_a = self._acquire_claim(armed_a)
            acquiring_a = advance_session_gate(
                armed_a,
                "ACQUIRE",
                lock_a,
                operator="Operator",
                evidence=evidence_a,
            )
            lease_a = Path(evidence_a["lease_path"])
            finish_authorized_runner_lease(
                lease_a,
                status="CANCELLED",
                reason="SYNTHETIC_CHILD_NEVER_STARTED",
                allow_unconsumed=True,
            )
            finalized_a = advance_session_gate(acquiring_a, "FINALIZE", lock_a, operator="Operator")
            lock_b, armed_b = self._armed_owner_session(log_root, "run-b", controller_instance_id="control-center-b")
            old_owner_id = evidence_a["active_owner_id"]
            with patch.object(alpha2, "_process_identity_state", return_value="DEAD"):
                _owner_path, owner_b = claim_active_acquisition_owner(
                    log_root,
                    armed_b,
                    lock_b,
                    controller_instance_id="control-center-b",
                    controller_pid=os.getpid(),
                )
            self.assertNotEqual(owner_b["owner_core"]["owner_id"], old_owner_id)
            history = list((log_root / "protocol_runs" / "active_acquisition_owner_history").glob("*.json"))
            self.assertEqual(len(history), 1)
            self.assertEqual(validate_session_lock_identity(finalized_a).status, "PASS")
            duplicate = history[0].with_name("duplicate_owner_identity.json")
            duplicate.write_bytes(history[0].read_bytes())
            duplicated_report = validate_session_lock_identity(finalized_a)
            self.assertEqual(duplicated_report.status, "INELIGIBLE")
            self.assertIn("resolve uniquely", " ".join(duplicated_report.errors))

        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            lock_a, armed_a = self._armed_owner_session(log_root, "run-a")
            evidence_a = self._acquire_claim(armed_a)
            advance_session_gate(
                armed_a,
                "ACQUIRE",
                lock_a,
                operator="Operator",
                evidence=evidence_a,
            )
            finish_authorized_runner_lease(
                evidence_a["lease_path"],
                status="CANCELLED",
                reason="SYNTHETIC_INTERRUPTED_ACQUIRE",
                allow_unconsumed=True,
            )
            lock_b, armed_b = self._armed_owner_session(log_root, "run-b", controller_instance_id="control-center-b")
            with patch.object(alpha2, "_process_identity_state", return_value="DEAD"):
                activity = active_acquisition_owner_activity(active_acquisition_owner_path(log_root))
                self.assertTrue(activity["active"])
                self.assertEqual(activity["status"], "UNRESOLVED_ACQUIRE")
                with self.assertRaisesRegex(RuntimeError, "active or unresolved"):
                    claim_active_acquisition_owner(
                        log_root,
                        armed_b,
                        lock_b,
                        controller_instance_id="control-center-b",
                        controller_pid=os.getpid(),
                    )

    def test_acquire_owner_evidence_omission_or_cross_owner_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            lock_path, armed = self._armed_owner_session(log_root, "run-a")
            valid = self._acquire_claim(armed)
            invalid = []
            for field in ("active_owner_path", "active_owner_id", "active_owner_core_sha256"):
                changed = dict(valid)
                changed.pop(field)
                invalid.append(changed)
            changed = dict(valid)
            changed["active_owner_id"] = "another-owner"
            invalid.append(changed)
            changed = dict(valid)
            changed["active_owner_core_sha256"] = "0" * 64
            invalid.append(changed)
            for evidence in invalid:
                with self.subTest(evidence=evidence):
                    with self.assertRaisesRegex(ValueError, "ACQUIRE runner-process claim"):
                        advance_session_gate(
                            armed,
                            "ACQUIRE",
                            lock_path,
                            operator="Operator",
                            evidence=evidence,
                        )

    def test_alpha853_recovers_only_terminal_owner_after_same_uuid_lock_was_superseded(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            lock_path, armed = self._armed_owner_session(log_root, "run-a")
            evidence = self._acquire_claim(armed)
            acquiring = advance_session_gate(
                armed,
                "ACQUIRE",
                lock_path,
                operator="Operator",
                evidence=evidence,
            )
            finish_authorized_runner_lease(
                evidence["lease_path"],
                status="EXITED",
                reason="SYNTHETIC_TERMINAL_RUNNER",
                allow_unconsumed=True,
            )
            advance_session_gate(acquiring, "FINALIZE", lock_path, operator="Operator")
            old_identity = armed["lock_identity_sha256"]

            _replacement_path, replacement = self._armed_owner_session(
                log_root,
                "run-a",
                controller_instance_id="replacement-control-center",
            )
            self.assertNotEqual(replacement["lock_identity_sha256"], old_identity)
            self.assertIn(
                "the run UUID already contains a one-use authorized-runner lease",
                alpha4.runtime_lock_reuse_reasons(lock_path),
            )

            owner_path = active_acquisition_owner_path(log_root)
            with patch.object(alpha3, "_process_identity_state", return_value="DEAD"):
                recovered = alpha4.recover_superseded_terminal_owner(
                    owner_path,
                    operator="Operator",
                    reason="ALPHA_8_5_3_SYNTHETIC_RECOVERY",
                )
                activity = alpha3.active_acquisition_owner_activity(owner_path)
            self.assertEqual(recovered["status"], "RELEASED")
            self.assertFalse(activity["active"])
            terminal_path = Path(recovered["owner_core"]["terminal_marker_path"])
            terminal = alpha3.load_json(terminal_path)
            self.assertEqual(terminal["lock_stage"], "FINALIZE")
            self.assertEqual(
                terminal["recovery"]["replacement_lock_identity_sha256"],
                replacement["lock_identity_sha256"],
            )
            self.assertEqual(terminal["recovery"]["old_lock_identity_sha256"], old_identity)

    def test_alpha853_runtime_lock_builder_refuses_a_used_uuid(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            log_root = Path(temp) / "logs"
            lock_path, armed = self._armed_owner_session(log_root, "run-a")
            self._acquire_claim(armed)
            _s, _sp, profile, _hp, _t, draft = self._selection(
                lock_path.parent,
                session_id="run-a",
            )
            preflight = alpha4.aggregate_hardware_preflight(
                profile,
                [
                    self._module_report(module, expected_run_uuid="run-a")
                    for module in profile["modules"]
                ],
                expected_run_uuid="run-a",
            )
            with self.assertRaisesRegex(RuntimeError, "already been used"):
                alpha4.build_session_lock(draft, preflight, lock_path, operator="Operator")

    def test_legacy_approved_inputs_remain_accepted_as_selection_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _build, old_protocol_lock = alpha1.compile_protocol(
                self.protocol_path, self.library, root / "old_build", human_reviewed_by="Reviewer"
            )
            profile_path = root / "old_profile.json"
            old_profile = alpha1.build_hardware_profile(
                [self.hardware_path], profile_path, profile_id="legacy", reviewed_by="Reviewer"
            )
            template = load_json(PACKAGE / "config" / "study_session_TEMPLATE_v0_1.json")
            template.update({
                "study_id": "LEGACY", "session_id": "1", "participant_pseudonym": "P1",
                "protocol_module": str(self.protocol_path), "hardware_profile": str(profile_path),
            })
            draft = build_session_draft(template, old_protocol_lock, old_profile, root / "draft.json")
            self.assertEqual(draft["status"], "READY_TO_CONNECT", draft["validation"])


if __name__ == "__main__":
    unittest.main()
