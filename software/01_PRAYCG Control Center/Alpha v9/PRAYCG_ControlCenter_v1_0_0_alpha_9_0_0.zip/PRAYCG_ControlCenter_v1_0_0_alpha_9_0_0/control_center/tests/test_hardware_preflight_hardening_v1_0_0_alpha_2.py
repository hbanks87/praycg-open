from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np


PACKAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE / "platform_core"))
sys.path.insert(0, str(PACKAGE / "tools" / "Hardware_Registry_v0_1"))

import praycg_hardware_registry_v0_1 as registry  # noqa: E402
from praycg_platform_core_v1_0_alpha_2 import (  # noqa: E402
    aggregate_hardware_preflight,
    build_hardware_profile,
    sha256_json,
)


def load_detailed_preflight_module():
    path = PACKAGE / "control_center" / "scripts" / "praycg_acquisition_preflight_v1_0.py"
    spec = importlib.util.spec_from_file_location("alpha2_detailed_preflight_test", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class HardwarePreflightHardeningTests(unittest.TestCase):
    def setUp(self) -> None:
        self.polar_path = PACKAGE / "config" / "hardware" / "Polar_H10_RR_v0_1.json"

    def test_dynamic_source_identity_uses_run_token(self) -> None:
        expected = {
            "source_id_policy": "dynamic_run_bound",
            "source_id_prefix": "praycg_test_",
        }
        run_uuid = "12345678-1234-4321-9999-123456789abc"
        errors, cautions = registry.stream_identity_findings(
            expected,
            "praycg_test_123456781234",
            run_uuid,
        )
        self.assertEqual(errors, [])
        self.assertEqual(cautions, [])
        errors, _ = registry.stream_identity_findings(expected, "praycg_test_wrongrun", run_uuid)
        self.assertTrue(any("run UUID" in item for item in errors))
        errors, cautions = registry.stream_identity_findings(expected, "praycg_test_unbound")
        self.assertEqual(errors, [])
        self.assertTrue(any("run UUID" in item for item in cautions))

    def test_duplicate_named_outlets_are_ineligible(self) -> None:
        class FakeInfo:
            def __init__(self, source_id: str):
                self._source_id = source_id

            def source_id(self):
                return self._source_id

        fake_pylsl = types.SimpleNamespace(
            StreamInlet=lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("duplicate outlet must not open")),
            resolve_byprop=lambda *_args, **_kwargs: [FakeInfo("one"), FakeInfo("two")],
        )
        module = {
            "module_id": "duplicate_test",
            "preflight": {"checks": ["timestamp_monotonicity"]},
            "streams": [{"lsl_name": "duplicate", "source_id": "one", "canonical_role": "markers", "nominal_srate": 0, "channel_count": 1}],
        }
        with patch.dict(sys.modules, {"pylsl": fake_pylsl}), patch.object(registry.time, "monotonic", side_effect=[0.0, 2.0]):
            report = registry.live_preflight(module, 1.0)
        self.assertEqual(report["status"], "INELIGIBLE")
        self.assertEqual(report["streams"][0]["candidate_count"], 2)
        self.assertEqual(report["performed_declared_checks"], [])
        self.assertEqual(report["unperformed_declared_checks"], ["timestamp_monotonicity"])

    def test_live_report_records_gaps_and_unperformed_checks(self) -> None:
        class FakeInfo:
            def source_id(self):
                return "fixed_source"

            def type(self):
                return "EEG"

            def nominal_srate(self):
                return 125.0

        class FakeInlet:
            def __init__(self, *_args, **_kwargs):
                self.rows = iter([([1.0, 2.0], 0.0), ([2.0, 3.0], 0.5)])

            def pull_sample(self, timeout=0.0):
                return next(self.rows, (None, 0.0))

            def close_stream(self):
                return None

        fake_pylsl = types.SimpleNamespace(
            StreamInlet=FakeInlet,
            resolve_byprop=lambda *_args, **_kwargs: [FakeInfo()],
        )
        module = {
            "module_id": "gap_test",
            "preflight": {"checks": ["effective_sample_rate", "timestamp_monotonicity", "gaps", "flat_channels", "saturation"]},
            "streams": [{"lsl_name": "test", "source_id": "fixed_source", "canonical_role": "eeg", "nominal_srate": 125.0, "channel_count": 2}],
        }
        with patch.dict(sys.modules, {"pylsl": fake_pylsl}), patch.object(
            registry.time,
            "monotonic",
            side_effect=[0.0, 0.1, 0.2, 2.0],
        ):
            report = registry.live_preflight(module, 1.0)
        stream = report["streams"][0]
        self.assertEqual(stream["max_gap_seconds"], 0.5)
        self.assertEqual(stream["large_gap_count"], 1)
        self.assertEqual(report["unperformed_declared_checks"], ["saturation"])
        self.assertEqual(report["status"], "CAUTION")

    def test_aggregate_preserves_child_report_and_run_binding(self) -> None:
        run_uuid = "12345678-1234-4321-9999-123456789abc"
        with tempfile.TemporaryDirectory() as temp:
            profile = build_hardware_profile(
                [self.polar_path],
                Path(temp) / "profile.json",
                profile_id="polar_test",
                reviewed_by="Tester",
            )
            selected = profile["modules"][0]
            child = {
                "schema": "PRAYCG_HardwareModulePreflight_v1_0_alpha_2",
                "platform_version": "1.0.0-alpha.2",
                "module_id": selected["module_id"],
                "module_file_sha256": selected["module_file_sha256"],
                "module_canonical_sha256": selected["module_canonical_sha256"],
                "expected_run_uuid": run_uuid,
                "status": "PASS",
                "streams": [{
                    "lsl_name": "PolarHRV",
                    "canonical_role": "rr_intervals",
                    "status": "PASS",
                    "resolved_candidate_count": 1,
                    "observed_source_id": "praycg_polar_h10_rr_v0_2_123456781234",
                }],
            }
            aggregate = aggregate_hardware_preflight(profile, [child], expected_run_uuid=run_uuid)
            self.assertEqual(aggregate["status"], "PASS", aggregate)
            self.assertEqual(aggregate["run_uuid"], run_uuid)
            evidence = aggregate["module_evidence"][0]
            self.assertEqual(evidence["report"], child)
            self.assertEqual(evidence["report_sha256"], sha256_json(child))
            mismatch = aggregate_hardware_preflight(profile, [child], expected_run_uuid="another-run")
            self.assertEqual(mismatch["status"], "INELIGIBLE")

    def test_detailed_report_binds_run_and_hardware_profile(self) -> None:
        detailed = load_detailed_preflight_module()
        stamps = np.arange(750, dtype=float) / 125.0
        rng = np.random.default_rng(2)
        eeg = detailed.Capture(
            "obci_eeg1",
            125.0,
            16,
            rng.normal(0, 10, size=(750, 16)).tolist(),
            stamps.tolist(),
            source_id="praycg_eeg_run123",
            resolved_candidate_count=1,
        )
        als = detailed.Capture("ALS_PT19_Timing", 125.0, 1, [], [], "not required")
        digest = "a" * 64
        report = detailed.analyze(
            eeg,
            als,
            125.0,
            False,
            run_uuid="run-123",
            hardware_profile_sha256=digest,
        )
        self.assertEqual(report["run_uuid"], "run-123")
        self.assertEqual(report["hardware_profile_sha256"], digest)
        self.assertEqual(report["binding_status"], "BOUND")
        self.assertNotIn("not bound", " ".join(report["warning_reasons"]).lower())
        unbound = detailed.analyze(
            eeg,
            als,
            125.0,
            False,
            run_uuid="different-run",
            hardware_profile_sha256=digest,
        )
        self.assertEqual(unbound["binding_status"], "UNBOUND_OR_INVALID")
        self.assertEqual(unbound["status"], "FAIL")

    def test_polar_registry_and_bridge_agree_on_milliseconds(self) -> None:
        module = json.loads(self.polar_path.read_text(encoding="utf-8"))
        stream = module["streams"][0]
        self.assertEqual(stream["units"], "milliseconds")
        self.assertEqual(stream["source_id_policy"], "dynamic_run_bound")
        script = (PACKAGE / "tools" / "Acquisition" / "Polar_H10_to_LSL" / "polar_to_lsl.py").read_text(encoding="utf-8")
        self.assertIn('"RRIntervals"', script)
        self.assertIn('"milliseconds"', script)
        self.assertIn('"--run-uuid"', script)


if __name__ == "__main__":
    unittest.main()
