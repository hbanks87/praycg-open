from __future__ import annotations

import json
from pathlib import Path
import unittest


PACKAGE = Path(__file__).resolve().parents[2]
CONTROL_CENTER = PACKAGE / "control_center" / "scripts" / "praycg_control_center_v1_0_0_alpha_2.py"


class Alpha2ConsolidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = CONTROL_CENTER.read_text(encoding="utf-8")

    def _method_block(self, start: str, end: str) -> str:
        return self.source.split(f"    def {start}", 1)[1].split(f"    def {end}", 1)[0]

    def test_one_operator_console_and_six_workspaces(self) -> None:
        self.assertNotIn('text="Platform Alpha"', self.source)
        self.assertNotIn("def launch_platform_workbench", self.source)
        self.assertNotIn('"platform_workbench": str(', self.source)
        for label in ("Dashboard", "Stimulus Library", "Acquisition", "Runner / PsychoPy", "Analysis", "Settings"):
            self.assertIn(label, self.source)

    def test_acquisition_has_exact_four_named_sections(self) -> None:
        block = self._method_block("build_acquisition_tab", "platform_core_available")
        expected = (
            "1. Hardware Profile",
            "2. Connect & Launch",
            "3. Live Checks",
            "4. Monitor, Record & Arm",
        )
        positions = [block.index(label) for label in expected]
        self.assertEqual(positions, sorted(positions))
        self.assertEqual(block.count("self.acq_nb.add("), 4)
        for action in ("Start BrainFlow EEG + ALS", "ALS Barcode Placement Test", "Run 30-Second Profile Preflight", "Open LabRecorder"):
            self.assertIn(action, block)

    def test_tools_are_located_by_workflow(self) -> None:
        runner = self._method_block("build_runner_tab", "protocol_record_label")
        analysis = self._method_block("build_analysis_tab", "build_settings_tab")
        settings = self._method_block("build_settings_tab", "save_settings_from_ui")
        self.assertIn("Advanced Protocol Builder", runner)
        self.assertIn("Prospective Assignment Tools", runner)
        self.assertNotIn("Prospective Study Console", analysis)
        self.assertIn("BIDS Export / Verify", analysis)
        for label in ("Record QC Evidence", "Record Analysis Evidence", "Record Export Evidence", "Record Verification Evidence"):
            self.assertIn(label, analysis)
        self.assertIn("Run Release Validation", settings)

    def test_registry_has_no_parallel_workbench(self) -> None:
        registry = json.loads((PACKAGE / "config" / "module_registry_v1_0_alpha_2.json").read_text(encoding="utf-8"))
        self.assertEqual(registry["schema"], "PRAYCG_ModuleRegistry_v1_0_alpha_2")
        ids = {row["id"] for row in registry["modules"]}
        self.assertNotIn("platform_workbench", ids)
        by_id = {row["id"]: row for row in registry["modules"]}
        self.assertEqual(by_id["hardware_registry"]["workspace"], "Acquisition")
        self.assertEqual(by_id["bids_exporter"]["workspace"], "Analysis")
        self.assertEqual(by_id["release_validator"]["workspace"], "Settings")

    def test_current_marker_contract_is_run_bound_and_explicitly_bounded(self) -> None:
        contract = json.loads(
            (PACKAGE / "config" / "marker_timing_contract_v1_0_alpha_2.json").read_text(encoding="utf-8")
        )
        self.assertEqual(contract["schema"], "PRAYCG_MarkerTimingContract_v1_0_alpha_2")
        self.assertIn("run_uuid", contract["required_event_fields"])
        self.assertIn("runtime session lock", contract["launch_authority_rule"])
        self.assertIn("does not by itself establish", contract["scientific_boundary"])

    def test_eeg_als_profile_matches_bridge_outlets(self) -> None:
        module = json.loads((PACKAGE / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json").read_text(encoding="utf-8"))
        streams = [(row["lsl_name"], row["canonical_role"], row["channel_count"], row["nominal_srate"]) for row in module["streams"]]
        self.assertEqual(streams, [
            ("obci_eeg1", "eeg", 16, 125.0),
            ("OpenBCIAnalogAux", "analog_aux", 3, 125.0),
            ("ALS_PT19_Timing", "als", 1, 125.0),
            ("OpenBCIStatusMarkers", "markers", 1, 0),
        ])
        self.assertEqual({row.get("source_id_policy") for row in module["streams"]}, {"dynamic_run_bound"})

    def test_als_live_tools_default_to_the_dedicated_timing_outlet(self) -> None:
        template = json.loads((PACKAGE / "control_center" / "config" / "praycg_control_center_config_TEMPLATE_v1_0_0_alpha_2.json").read_text(encoding="utf-8"))
        self.assertEqual(template["lsl"]["als_stream_name"], "ALS_PT19_Timing")
        self.assertEqual(template["lsl"]["als_channel_index_1based"], 1)
        calibration = (PACKAGE / "control_center" / "scripts" / "praycg_als_holder_calibration_v0_8.py").read_text(encoding="utf-8")
        self.assertIn("default='ALS_PT19_Timing'", calibration)
        self.assertIn("default=1", calibration)
        calibration_launch = self._method_block("run_als_holder_calibration", "launch_hocr_shotorder")
        self.assertIn('get("als_stream_name", "ALS_PT19_Timing")', calibration_launch)

    def test_control_center_and_runner_use_canonical_runtime_gate(self) -> None:
        self.assertIn("from praycg_platform_core_v1_0_alpha_2 import", self.source)
        self.assertIn("build_session_draft", self.source)
        self.assertIn("build_session_lock", self.source)
        self.assertIn("advance_session_gate", self.source)
        engine = (PACKAGE / "tools" / "ProtocolRunner_ModuleLibrary_v1_0" / "scripts" / "praycg_protocol_engine_v3_0.py").read_text(encoding="utf-8")
        self.assertIn("runtime session lock is mandatory", engine)
        self.assertLess(
            engine.index('load_and_validate_runtime_session(cfg, required_stage="ACQUIRE")'),
            engine.index("logger = EventLogger("),
        )
        self.assertIn("runner_configuration_policy", engine)
        self.assertIn("protocol_engine_file_sha256", engine)
        self.assertIn('advance_session_gate(  # type: ignore[misc]\n                    current_lock,\n                    "ACQUIRE"', self.source)
        self.assertIn('advance_runtime_session_gate(\n                    "FINALIZE"', engine)

    def test_only_direct_interpreter_modes_receive_acquisition_authority(self) -> None:
        launch = self._method_block("launch_praycg_runner", "launch_psychopy_coder_only")
        self.assertIn('"runner_launch_mode": "psychopy_python"', self.source)
        self.assertIn("debug only", launch)
        self.assertIn("without acquisition authority", launch)
        self.assertNotIn("env_overrides=runner_env)\n            self.log(f\"Opening", launch)

    def test_prospective_console_cannot_open_a_runner_directly(self) -> None:
        console = (PACKAGE / "tools" / "Prospective_Study_Package_v0_1" / "scripts" / "praycg_prospective_study_console_v0_1.py").read_text(encoding="utf-8")
        self.assertNotIn("self.reveal(runner)", console)
        self.assertIn("shared engine rejects an unbound direct launch", console)


if __name__ == "__main__":
    unittest.main()
