"""Alpha.4 regression coverage for the stimulus, hardware, and analysis forges."""
from __future__ import annotations

import copy
import io
import json
import math
import shutil
import sys
import tempfile
import types
import unittest
import uuid
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock


PACKAGE = Path(__file__).resolve().parents[2]
STIMULUS_ROOT = PACKAGE / "tools" / "Stimulus_Forge_Library_v1_0"
HARDWARE_FORGE_ROOT = PACKAGE / "tools" / "Hardware_Forge_v0_1"
BRIDGE_ROOT = PACKAGE / "tools" / "Acquisition" / "Generic_EDA_PPG_Stream_Bridge_v0_1"
ANALYSIS_ROOT = PACKAGE / "tools" / "Analysis_Module_Catalog_v0_1"
for import_root in (
    STIMULUS_ROOT,
    HARDWARE_FORGE_ROOT,
    BRIDGE_ROOT / "scripts",
    ANALYSIS_ROOT,
):
    sys.path.insert(0, str(import_root))

import praycg_analysis_module_catalog_v0_1 as analysis_catalog  # noqa: E402
import praycg_generic_eda_ppg_core_v0_1 as eda_ppg_core  # noqa: E402
import praycg_generic_eda_ppg_to_lsl_v0_1 as eda_ppg_bridge  # noqa: E402
import praycg_hardware_forge_v0_1 as hardware_forge  # noqa: E402
import praycg_stimulus_common_v1_0 as stimulus_common  # noqa: E402
import praycg_stimulus_forge_v1_0 as stimulus_forge  # noqa: E402


def _json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise AssertionError(f"Expected a JSON object: {path}")
    return value


def _write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def _minimal_stimulus_pack(root: Path, pack_id: str = "SYNTHETIC_ALPHA4_PACK") -> dict:
    root.mkdir(parents=True)
    payload = root / "assets" / "stimulus.txt"
    payload.parent.mkdir()
    payload.write_text("package-owned synthetic fixture\n", encoding="utf-8")
    manifest = {
        "schema": "PRAYCG_StimulusPack_v1_0",
        "pack_id": pack_id,
        "pack_version": "1.0.0-alpha.4",
        "display_name": "Synthetic alpha.4 contract fixture",
        "scientific_status": "DEMO_ONLY",
        "status_boundary": "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION",
        "distribution": {
            "bundled": False,
            "license_id": "CC0-1.0",
            "source_material_bundled": False,
            "redistribution_reviewed": False,
        },
        "generator": {
            "engine_id": "test_fixture",
            "engine_version": "0.1",
            "seed": 7,
            "deterministic_claim": True,
        },
        "compatibility": [
            {
                "protocol_id": "SYNTHETIC_PROTOCOL",
                "protocol_version": "1.0",
                "bindings": {"stimulus": "assets/stimulus.txt"},
            }
        ],
        "asset_roles": [
            {
                "asset_id": "stimulus",
                "role": "software_test_fixture",
                "path": "assets/stimulus.txt",
            }
        ],
        "file_ledger": [],
        "claims_boundary": [
            "This synthetic file tests software contracts only and is not a scientific stimulus."
        ],
        "manifest_content_sha256": "0" * 64,
    }
    return stimulus_common.finalize_manifest(manifest, root)


class Alpha4StimulusForgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.catalog = stimulus_common.load_catalog(STIMULUS_ROOT)

    def test_packaged_catalog_and_all_packs_pass_static_integrity(self) -> None:
        self.assertEqual(self.catalog["schema"], "PRAYCG_StimulusPackCatalog_v1_0")
        self.assertEqual(len(self.catalog["protocols"]), 14)
        self.assertEqual(len(self.catalog["packs"]), 4)
        reports = list(stimulus_common.iter_catalog_pack_reports(STIMULUS_ROOT, media_probe=False))
        self.assertEqual(len(reports), 4)
        for entry, report in reports:
            with self.subTest(pack_id=entry["pack_id"]):
                self.assertEqual(report.status, "PASS", report.errors)
                self.assertEqual(report.facts["scientific_status"], "DEMO_ONLY")
                self.assertEqual(
                    report.facts["collection_eligibility"],
                    "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION",
                )

    def test_every_protocol_has_one_default_pack_with_exact_binding_keys(self) -> None:
        for row in self.catalog["protocols"]:
            with self.subTest(protocol_id=row["protocol_id"]):
                defaults = [option for option in row["sample_options"] if option.get("default") is True]
                self.assertEqual(len(defaults), 1)
                pack_entry = stimulus_common.catalog_pack_by_id(self.catalog, defaults[0]["pack_id"])
                pack_root = stimulus_common.catalog_pack_root(pack_entry, STIMULUS_ROOT)
                manifest = stimulus_common.read_json(pack_root / "stimulus_pack_manifest.json")
                compatibility = [
                    item
                    for item in manifest["compatibility"]
                    if item.get("protocol_id") == row["protocol_id"]
                ]
                self.assertEqual(len(compatibility), 1)
                self.assertEqual(
                    set(compatibility[0]["bindings"]),
                    set(row["expected_asset_keys"]),
                )
                resolved = stimulus_common.resolve_bindings(pack_root, row["protocol_id"])
                self.assertEqual(set(resolved), set(row["expected_asset_keys"]))
                self.assertTrue(all(Path(value).exists() for value in resolved.values()))

    def test_relative_path_contract_rejects_traversal_and_absolute_paths(self) -> None:
        unsafe = ("../escape.mp4", "assets/../../escape.mp4", "/absolute/file.mp4", "C:/absolute/file.mp4")
        for value in unsafe:
            with self.subTest(value=value):
                with self.assertRaises(stimulus_common.StimulusContractError):
                    stimulus_common.normalize_relative_path(value)

    def test_synthetic_pack_round_trip_and_payload_tampering_failures(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            baseline = Path(temp) / "baseline"
            _minimal_stimulus_pack(baseline)
            report = stimulus_common.validate_pack(baseline, media_probe=False)
            self.assertEqual(report.status, "PASS", report.errors)

            missing = Path(temp) / "missing"
            shutil.copytree(baseline, missing)
            (missing / "assets" / "stimulus.txt").unlink()
            self.assertEqual(stimulus_common.validate_pack(missing, media_probe=False).status, "FAIL")

            modified = Path(temp) / "modified"
            shutil.copytree(baseline, modified)
            with (modified / "assets" / "stimulus.txt").open("ab") as stream:
                stream.write(b"changed")
            self.assertEqual(stimulus_common.validate_pack(modified, media_probe=False).status, "FAIL")

            extra = Path(temp) / "extra"
            shutil.copytree(baseline, extra)
            (extra / "untracked.bin").write_bytes(b"unexpected")
            self.assertEqual(stimulus_common.validate_pack(extra, media_probe=False).status, "FAIL")

    def test_manifest_hash_and_study_lock_requirements_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            pack = Path(temp) / "pack"
            _minimal_stimulus_pack(pack)
            manifest_path = pack / "stimulus_pack_manifest.json"
            manifest = stimulus_common.read_json(manifest_path)
            manifest["display_name"] = "Changed without rehash"
            stimulus_common.write_json(manifest_path, manifest)
            mismatch = stimulus_common.validate_pack(pack, media_probe=False)
            self.assertEqual(mismatch.status, "FAIL")
            self.assertTrue(any("content hash" in error.lower() for error in mismatch.errors))

            manifest["scientific_status"] = "STUDY_LOCKED"
            manifest.pop("review", None)
            manifest.pop("study_lock", None)
            manifest["manifest_content_sha256"] = stimulus_common.manifest_content_sha256(manifest)
            stimulus_common.write_json(manifest_path, manifest)
            locked = stimulus_common.validate_pack(pack, media_probe=False)
            self.assertEqual(locked.status, "FAIL")
            self.assertTrue(any("study_locked" in error.lower() for error in locked.errors))

    def test_install_is_copy_on_use_and_refuses_existing_destination(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source"
            destination_root = Path(temp) / "installed"
            manifest = _minimal_stimulus_pack(source, "COPY_ON_USE_PACK")
            existing = destination_root / manifest["pack_id"]
            existing.mkdir(parents=True)
            with self.assertRaises(stimulus_common.StimulusContractError):
                stimulus_common.install_pack(source, destination_root)
            self.assertTrue((source / "assets" / "stimulus.txt").is_file())

    def test_duplicate_installed_pack_ids_are_disabled_as_ambiguous(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _minimal_stimulus_pack(root / "copy_a", "DUPLICATE_PACK")
            _minimal_stimulus_pack(root / "copy_b", "DUPLICATE_PACK")
            registry = stimulus_common.scan_installed_packs(root, media_probe=False)
            self.assertEqual(registry["duplicate_pack_ids"], ["DUPLICATE_PACK"])
            self.assertEqual(len(registry["packs"]), 2)
            self.assertTrue(all(row["active_for_selection"] is False for row in registry["packs"]))

    def test_forge_uses_a_static_offline_engine_allowlist(self) -> None:
        engine_registry = _json(STIMULUS_ROOT / "engine_registry_v1_0.json")
        self.assertEqual(len(engine_registry["engines"]), 15)
        self.assertTrue(all(engine["network_allowed"] is False for engine in engine_registry["engines"]))
        with tempfile.TemporaryDirectory() as temp:
            request = stimulus_forge.ForgeRequest(
                engine_id="downloaded.module:run",
                output=Path(temp) / "must_not_exist",
            )
            with self.assertRaises(stimulus_common.StimulusContractError):
                stimulus_forge.run_engine(request)
            self.assertFalse(request.output.exists())

    def test_library_never_imports_or_executes_code_named_by_a_pack(self) -> None:
        source = (STIMULUS_ROOT / "praycg_stimulus_common_v1_0.py").read_text(encoding="utf-8")
        source += (STIMULUS_ROOT / "praycg_stimulus_library_v1_0.py").read_text(encoding="utf-8")
        for forbidden in ("importlib", "runpy", "eval(", "exec(", "os.system", "subprocess"):
            self.assertNotIn(forbidden, source)


class Alpha4HardwareForgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.catalog_path = PACKAGE / "config" / "hardware_adapter_catalog_v0_1.json"
        cls.catalog, cls.drafts = hardware_forge.load_catalog(cls.catalog_path)
        cls.draft_ids = {row["draft_module_id"] for row in cls.drafts["drafts"]}

    def test_packaged_hardware_catalog_passes_and_has_no_runtime_authority(self) -> None:
        report = hardware_forge.validate_catalog(self.catalog_path)
        self.assertEqual(report["status"], "PASS", report["errors"])
        self.assertGreaterEqual(report["adapter_count"], 8)
        self.assertEqual(report["route_count"], report["draft_count"])
        self.assertFalse(self.drafts["runtime_authority"])
        for adapter in self.catalog["adapters"]:
            self.assertFalse(adapter["runtime_authority"])
            for route in adapter["routes"]:
                if adapter["admission_state"] in {"CATALOG_ONLY", "QUARANTINED"}:
                    self.assertNotEqual(route["launch_state"], "AVAILABLE_ALPHA")
                if adapter["admission_state"] == "QUARANTINED":
                    self.assertEqual(route["launch_state"], "WITHHELD")

    def test_adapter_validation_rejects_unsafe_archive_and_authority_claims(self) -> None:
        descriptor = copy.deepcopy(self.catalog["adapters"][0])
        descriptor["runtime_authority"] = True
        descriptor["source_archive"]["filename"] = str(PACKAGE / "outside.zip")
        descriptor["source_archive"]["sha256"] = "A" * 64
        descriptor["routes"][0]["launch_state"] = "AVAILABLE_ALPHA"
        errors = hardware_forge.validate_adapter_descriptor(descriptor, self.draft_ids)
        combined = "\n".join(errors).lower()
        self.assertIn("runtime_authority", combined)
        self.assertIn("filename", combined)
        self.assertIn("lowercase", combined)
        self.assertIn("cannot expose", combined)

    def test_simulator_and_quarantine_cannot_imply_physical_validation(self) -> None:
        simulator = next(
            copy.deepcopy(row)
            for row in self.catalog["adapters"]
            if row["admission_state"] == "SIMULATOR_VERIFIED"
        )
        simulator["physical_validation"] = "BENCH_ONLY"
        self.assertTrue(
            any("cannot claim physical" in error for error in hardware_forge.validate_adapter_descriptor(simulator, self.draft_ids))
        )
        quarantined = next(
            copy.deepcopy(row)
            for row in self.catalog["adapters"]
            if row["admission_state"] == "QUARANTINED"
        )
        quarantined["routes"][0]["launch_state"] = "DIAGNOSTIC_ONLY"
        self.assertTrue(
            any("quarantined routes must be withheld" in error for error in hardware_forge.validate_adapter_descriptor(quarantined, self.draft_ids))
        )

    def test_duplicate_route_adapter_and_draft_ids_fail(self) -> None:
        descriptor = copy.deepcopy(self.catalog["adapters"][0])
        descriptor["routes"].append(copy.deepcopy(descriptor["routes"][0]))
        direct_errors = hardware_forge.validate_adapter_descriptor(descriptor, self.draft_ids)
        self.assertTrue(any("duplicate route_id" in error for error in direct_errors))

        with tempfile.TemporaryDirectory() as temp:
            synthetic_root = Path(temp)
            forge_root = synthetic_root / "tools" / "Hardware_Forge_v0_1"
            config_root = synthetic_root / "config"
            (forge_root / "schemas").mkdir(parents=True)
            (forge_root / "catalog").mkdir(parents=True)
            config_root.mkdir()
            (forge_root / "schemas" / "hardware_adapter_descriptor_v0_1.schema.json").write_text("{}", encoding="utf-8")
            catalog = copy.deepcopy(self.catalog)
            drafts = copy.deepcopy(self.drafts)
            catalog["adapters"].append(copy.deepcopy(catalog["adapters"][0]))
            drafts["drafts"].append(copy.deepcopy(drafts["drafts"][0]))
            _write_json(config_root / "hardware_adapter_catalog_v0_1.json", catalog)
            _write_json(forge_root / "catalog" / "hardware_module_drafts_v0_1.json", drafts)
            with mock.patch.object(hardware_forge, "PACKAGE_ROOT", synthetic_root), mock.patch.object(
                hardware_forge, "FORGE_ROOT", forge_root
            ):
                report = hardware_forge.validate_catalog(config_root / "hardware_adapter_catalog_v0_1.json")
            combined = "\n".join(report["errors"])
            self.assertIn("Duplicate adapter_id", combined)
            self.assertIn("Duplicate draft_module_id", combined)

    def test_role_collisions_require_explicit_primary_selection(self) -> None:
        selections = (
            "generic_eda_ppg:serial_json_lines",
            "generic_eda_ppg:udp_json_datagrams",
        )
        ambiguous = hardware_forge.create_draft_profile(
            selections,
            profile_id="ambiguous_physio",
            catalog_path=self.catalog_path,
        )
        self.assertEqual(ambiguous["status"], "DRAFT_NOT_APPROVED")
        self.assertFalse(ambiguous["runtime_authority"])
        self.assertTrue(any("multiple primary sources" in error for error in ambiguous["errors_requiring_resolution"]))

        prefix = "generic_eda_ppg/serial_json_lines"
        resolved = hardware_forge.create_draft_profile(
            selections,
            profile_id="resolved_physio",
            primary_overrides={
                "eda": f"{prefix}/PRAYCG_EDA",
                "ppg": f"{prefix}/PRAYCG_PPG",
            },
            catalog_path=self.catalog_path,
        )
        self.assertEqual(resolved["status"], "DRAFT_NOT_APPROVED")
        self.assertEqual(resolved["errors_requiring_resolution"], [])
        self.assertTrue(resolved["role_assignments"]["eda"]["primary"].startswith(prefix))
        self.assertTrue(resolved["role_assignments"]["ppg"]["primary"].startswith(prefix))

    def test_all_draft_stream_roles_and_assignments_are_typed(self) -> None:
        canonical_roles = set(self.drafts["canonical_roles"])
        assignments = {"PRIMARY", "SUPPLEMENTAL", "UNASSIGNED"}
        for draft in self.drafts["drafts"]:
            with self.subTest(draft=draft["draft_module_id"]):
                self.assertEqual(
                    hardware_forge.validate_draft(draft, canonical_roles),
                    [],
                )
                self.assertFalse(draft["runtime_authority"])
                for stream in draft["proposed_module"]["streams"]:
                    self.assertIn(stream["canonical_role"], canonical_roles)
                    self.assertIn(stream["role_assignment_default"], assignments)


class Alpha4GenericEDAPPGBridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.profile_path = BRIDGE_ROOT / "config" / "generic_eda_ppg_udp_SIMULATOR_v0_1.json"
        cls.profile = eda_ppg_core.load_json(cls.profile_path)

    def test_synthetic_profile_is_typed_and_never_physical_authority(self) -> None:
        report = eda_ppg_core.validate_driver_profile(self.profile, for_live=True)
        self.assertEqual(report["status"], "PASS", report["errors"])
        self.assertFalse(report["runtime_authority"])
        self.assertTrue(self.profile["synthetic"])
        self.assertEqual(self.profile["status"], "SIMULATOR_ONLY")
        self.assertTrue(all(row["lsl_name"].startswith("SYNTHETIC_") for row in self.profile["streams"]))

    def test_malformed_packets_are_rejected_before_publication(self) -> None:
        invalid_packets: tuple[bytes | str, ...] = (
            b"\xff",
            "not json",
            "[]",
            json.dumps({"stream": "unknown", "values": [1.0]}),
            json.dumps({"stream": "eda"}),
            json.dumps({"stream": "eda", "values": True}),
            json.dumps({"stream": "eda", "values": [1.0, 2.0]}),
            '{"stream":"eda","values":[NaN]}',
            '{"stream":"eda","values":[1.0],"device_timestamp_seconds":Infinity}',
            json.dumps({"stream": "eda", "values": [1.0], "sequence": -1}),
        )
        for packet in invalid_packets:
            with self.subTest(packet=repr(packet)):
                with self.assertRaises((UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError)):
                    eda_ppg_core.parse_packet(packet, self.profile, host_timestamp_seconds=1.0)

    def test_valid_packets_retain_typed_identity_and_timestamps(self) -> None:
        observation = eda_ppg_core.parse_packet(
            json.dumps(
                {
                    "stream": "ppg",
                    "values": [0.75],
                    "device_timestamp_seconds": 12.25,
                    "sequence": 9,
                }
            ),
            self.profile,
            host_timestamp_seconds=100.5,
        )
        self.assertEqual(observation.stream_id, "ppg")
        self.assertEqual(observation.values, (0.75,))
        self.assertEqual(observation.device_timestamp_seconds, 12.25)
        self.assertEqual(observation.host_timestamp_seconds, 100.5)
        self.assertEqual(observation.sequence, 9)

    def test_synthetic_signal_preflight_exercises_rate_range_and_pulse_checks(self) -> None:
        observations: list[eda_ppg_core.Observation] = []
        for index in range(41):
            timestamp = index / 10.0
            value = 2.0 + 0.2 * math.sin(2.0 * math.pi * 0.2 * timestamp)
            observations.append(eda_ppg_core.Observation("eda", (value,), 100.0 + timestamp, timestamp, index))
        for index in range(401):
            timestamp = index / 100.0
            value = 0.8 * math.sin(2.0 * math.pi * 1.2 * timestamp) + 0.1 * math.sin(2.0 * math.pi * 2.4 * timestamp)
            observations.append(eda_ppg_core.Observation("ppg", (value,), 100.0 + timestamp, timestamp, index))
        report = eda_ppg_core.summarize_preflight(
            observations,
            self.profile,
            requested_duration_seconds=4.0,
        )
        self.assertEqual(report["status"], "PASS", report["cautions"])
        self.assertTrue(report["synthetic"])
        self.assertEqual(report["physical_validation"], "NOT_ESTABLISHED")
        ppg = next(row for row in report["streams"] if row["canonical_role"] == "ppg")
        self.assertTrue(ppg["ppg_pulse_visibility"]["visible"])

    def test_packet_collection_counts_rejections_without_accepting_them(self) -> None:
        class Source:
            def __init__(self) -> None:
                self.values: list[bytes] = [
                    b'{"stream":"eda","values":[1.0],"sequence":0}',
                    b"malformed",
                    b'{"stream":"ppg","values":[0.5],"sequence":0}',
                ]

            def read(self) -> bytes | None:
                if self.values:
                    return self.values.pop(0)
                eda_ppg_bridge.STOP = True
                return None

        eda_ppg_bridge.STOP = False
        try:
            observations, rejected = eda_ppg_bridge.collect_observations(
                Source(),
                self.profile,
                duration_seconds=1.0,
            )
        finally:
            eda_ppg_bridge.STOP = False
        self.assertEqual(len(observations), 2)
        self.assertEqual(rejected, 1)

    def test_full_uuid_is_required_and_lsl_identities_are_run_bound(self) -> None:
        run_uuid = "12345678-1234-5678-9234-567812345678"
        self.assertEqual(eda_ppg_bridge._validated_run_uuid(run_uuid), run_uuid)
        self.assertEqual(eda_ppg_bridge.run_fragment(run_uuid), "123456781234")
        for invalid in ("", "12345678", "not-a-uuid"):
            with self.subTest(invalid=invalid):
                with self.assertRaises(ValueError):
                    eda_ppg_bridge._validated_run_uuid(invalid)

        class Descriptor:
            def __init__(self) -> None:
                self.values: dict[str, str] = {}

            def append_child_value(self, key: str, value: str) -> "Descriptor":
                self.values[key] = value
                return self

        class Info:
            def __init__(self, **kwargs: object) -> None:
                self.kwargs = kwargs
                self.descriptor = Descriptor()

            def desc(self) -> Descriptor:
                return self.descriptor

        class Outlet:
            def __init__(self, info: Info, **_kwargs: object) -> None:
                self.info = info

        fake_pylsl = types.SimpleNamespace(
            StreamInfo=Info,
            StreamOutlet=Outlet,
            cf_float32="float32",
            cf_string="string",
            local_clock=lambda: 0.0,
        )
        with mock.patch.dict(sys.modules, {"pylsl": fake_pylsl}):
            outlets, status_outlet, _clock = eda_ppg_bridge._lsl_outlets(self.profile, run_uuid)
        self.assertEqual(set(outlets), {"eda", "ppg"})
        for outlet in [*outlets.values(), status_outlet]:
            self.assertIn("123456781234", str(outlet.info.kwargs["source_id"]))
            self.assertEqual(outlet.info.descriptor.values["run_uuid"], run_uuid)
            self.assertEqual(outlet.info.descriptor.values["synthetic"], "true")


class Alpha4AnalysisModuleCatalogTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.registry_path = PACKAGE / "config" / "analysis_module_registry_v0_1.json"
        cls.registry = _json(cls.registry_path)

    def test_packaged_registry_passes_with_explicit_no_authority_boundary(self) -> None:
        report = analysis_catalog.validate_registry(self.registry_path)
        self.assertEqual(report["status"], "PASS", report["errors"])
        self.assertEqual(report["module_count"], 10)
        self.assertEqual(report["valid_module_count"], 10)
        for field in analysis_catalog.AUTHORITY_FIELDS:
            self.assertEqual(self.registry[field], "NONE")
            self.assertEqual(report["authority_boundary"][field], "NONE")
            for module in self.registry["modules"]:
                self.assertEqual(module[field], "NONE")

    def test_broader_analysis_components_are_reference_only_until_normalized(self) -> None:
        modules = {module["module_id"]: module for module in self.registry["modules"]}
        reference_ids = {
            "master_comprehensive_suite_v1_6_0",
            "full_chained_analysis_v1_6_1",
            "hocr_shotorder_v1_6_0",
            "confound_expansion_v1_5_7",
            "master_sync_visualizer_v1_4_0",
            "offline_master_interpreter_v1_6_0",
            "cue_locked_gamma_forensics_v0_1",
        }
        self.assertTrue(reference_ids.issubset(modules))
        for module_id in reference_ids:
            descriptor = modules[module_id]
            self.assertFalse(descriptor["execution_eligible"])
            self.assertEqual(
                descriptor["launch"]["contract_status"],
                analysis_catalog.REFERENCE_ONLY_CONTRACT,
            )
            self.assertTrue(
                all(descriptor[field] == "NONE" for field in analysis_catalog.AUTHORITY_FIELDS)
            )

    def test_registry_rejects_authority_grants_duplicates_and_path_traversal(self) -> None:
        mutated = copy.deepcopy(self.registry)
        mutated["primary_endpoint_authority"] = "PRIMARY"
        mutated["modules"][0]["master_suite_eligibility_effect"] = "ELIGIBLE"
        mutated["modules"][0]["entry_point"] = "../outside.py"
        mutated["modules"].append(copy.deepcopy(mutated["modules"][1]))
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "registry.json"
            _write_json(path, mutated)
            report = analysis_catalog.validate_registry(path)
        combined = "\n".join(report["errors"])
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("primary_endpoint_authority must be NONE", combined)
        self.assertIn("master_suite_eligibility_effect must be NONE", combined)
        self.assertIn("traversal", combined)
        self.assertIn("repeats module IDs", combined)

    def test_default_entry_is_gui_and_accepts_gui_and_run_folder(self) -> None:
        fake_run = Path("example-run")
        with mock.patch.object(analysis_catalog, "launch_gui", return_value=0) as launch:
            self.assertEqual(analysis_catalog.main([]), 0)
            launch.assert_called_once_with(
                analysis_catalog.DEFAULT_REGISTRY,
                None,
                module_id=None,
            )
        with mock.patch.object(analysis_catalog, "launch_gui", return_value=0) as launch:
            self.assertEqual(
                analysis_catalog.main(["--gui", "--run-folder", str(fake_run)]),
                0,
            )
            launch.assert_called_once_with(
                analysis_catalog.DEFAULT_REGISTRY,
                fake_run,
                module_id=None,
            )

    def test_synthetic_run_preflight_can_reach_operator_review_without_promotion(self) -> None:
        run_uuid = "2b6ef9fa-32a7-4804-866f-e73f54638bc7"
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / "run"
            (run / "derived").mkdir(parents=True)
            _write_json(run / "run_identity.json", {"run_uuid": run_uuid})
            (run / "derived" / "cardiac_beats.csv").write_text("time,ibi\n0,0.8\n", encoding="utf-8")
            (run / "derived" / "respiration.csv").write_text("time,value\n0,1\n", encoding="utf-8")
            report = analysis_catalog.preflight_catalog(
                self.registry_path,
                run,
                module_id="continuous_autonomic_resp_dual_path_v1_0",
            )
        self.assertEqual(report["status"], "READY_FOR_OPERATOR_REVIEW", report["errors"])
        self.assertEqual(report["run_identity"]["run_uuid"], run_uuid)
        module = report["modules"][0]
        self.assertEqual(module["status"], "READY_FOR_OPERATOR_REVIEW")
        self.assertTrue(all(row["status"] == "RESOLVED" for row in module["required_artifact_groups"]))
        self.assertTrue(all(value == "NONE" for value in module["authority_boundary"].values()))

    def test_run_identity_ambiguity_and_malformed_identity_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            ambiguous = Path(temp) / "ambiguous"
            ambiguous.mkdir()
            _write_json(
                ambiguous / "run_state.json",
                {
                    "run_uuid": "85ea9a0e-a8c6-447e-b97f-c6d56857a047",
                    "nested": {"session_id": "21dd8544-f523-4485-9d24-19c7222bcb2a"},
                },
            )
            identity = analysis_catalog.resolve_run_identity(ambiguous)
            self.assertEqual(identity["status"], "AMBIGUOUS")
            report = analysis_catalog.preflight_catalog(
                self.registry_path,
                ambiguous,
                module_id="micro_handoff_v0_1",
            )
            self.assertEqual(report["status"], "INELIGIBLE")

            malformed = Path(temp) / "malformed"
            malformed.mkdir()
            (malformed / "run_manifest.json").write_text("{broken", encoding="utf-8")
            identity = analysis_catalog.resolve_run_identity(malformed)
            self.assertEqual(identity["status"], "MALFORMED")
            self.assertTrue(identity["unreadable_identity_files"])

    def test_exactly_one_artifact_policy_refuses_ambiguous_inputs(self) -> None:
        run_uuid = str(uuid.uuid4())
        with tempfile.TemporaryDirectory() as temp:
            run = Path(temp) / run_uuid
            run.mkdir()
            (run / "one.xdf").write_bytes(b"xdf-one")
            (run / "two.xdf").write_bytes(b"xdf-two")
            (run / "task_events.json").write_text("{}", encoding="utf-8")
            report = analysis_catalog.preflight_catalog(
                self.registry_path,
                run,
                module_id="cai_sid_exploratory_v0_2",
            )
        self.assertEqual(report["status"], "INELIGIBLE")
        xdf = next(row for row in report["modules"][0]["required_artifact_groups"] if row["group_id"] == "xdf_recording")
        self.assertEqual(xdf["status"], "AMBIGUOUS")
        self.assertEqual(xdf["match_count"], 2)

    def test_catalog_source_has_no_module_execution_mechanism(self) -> None:
        source = (ANALYSIS_ROOT / "praycg_analysis_module_catalog_v0_1.py").read_text(encoding="utf-8")
        for forbidden in ("importlib", "runpy", "subprocess", "os.system", "eval(", "exec("):
            self.assertNotIn(forbidden, source)
        self.assertNotIn("Launch Selected", source)

    def test_json_mode_reports_catalog_without_starting_gui(self) -> None:
        output = io.StringIO()
        with mock.patch.object(analysis_catalog, "launch_gui") as launch, redirect_stdout(output):
            code = analysis_catalog.main(["--json"])
        self.assertEqual(code, 0)
        launch.assert_not_called()
        payload = json.loads(output.getvalue())
        self.assertEqual(payload["status"], "PASS")


class Alpha4ForgePackageSurfaceTests(unittest.TestCase):
    def test_expected_public_code_config_schema_and_demo_assets_exist(self) -> None:
        expected = (
            "config/analysis_module_registry_v0_1.json",
            "config/hardware_adapter_catalog_v0_1.json",
            "tools/Analysis_Module_Catalog_v0_1/praycg_analysis_module_catalog_v0_1.py",
            "tools/Analysis_Module_Catalog_v0_1/analysis_module_descriptor_v0_1.schema.json",
            "tools/Hardware_Forge_v0_1/praycg_hardware_forge_v0_1.py",
            "tools/Hardware_Forge_v0_1/schemas/hardware_adapter_descriptor_v0_1.schema.json",
            "tools/Hardware_Forge_v0_1/schemas/hardware_profile_draft_v0_2.schema.json",
            "tools/Hardware_Forge_v0_1/catalog/hardware_module_drafts_v0_1.json",
            "tools/Acquisition/Generic_EDA_PPG_Stream_Bridge_v0_1/scripts/praycg_generic_eda_ppg_core_v0_1.py",
            "tools/Acquisition/Generic_EDA_PPG_Stream_Bridge_v0_1/scripts/praycg_generic_eda_ppg_to_lsl_v0_1.py",
            "tools/Acquisition/Generic_EDA_PPG_Stream_Bridge_v0_1/scripts/praycg_generic_eda_ppg_simulator_v0_1.py",
            "tools/Stimulus_Forge_Library_v1_0/praycg_stimulus_common_v1_0.py",
            "tools/Stimulus_Forge_Library_v1_0/praycg_stimulus_forge_v1_0.py",
            "tools/Stimulus_Forge_Library_v1_0/praycg_stimulus_library_v1_0.py",
            "tools/Stimulus_Forge_Library_v1_0/config/stimulus_pack_catalog_v1_0.json",
            "tools/Stimulus_Forge_Library_v1_0/config/stimulus_pack_schema_v1_0.json",
            "examples/no_copyright_media_demo/stimulus_library/packs/PRAYCG_NATIVE_STORY_DEMO_V1/stimulus_pack_manifest.json",
            "examples/no_copyright_media_demo/stimulus_library/packs/PRAYCG_NARR_SOUND_STORY_DEMO_V1/stimulus_pack_manifest.json",
            "examples/no_copyright_media_demo/stimulus_library/packs/PRAYCG_ATLAS_EVENT_VIDEO_DEMO_V1/stimulus_pack_manifest.json",
            "examples/no_copyright_media_demo/stimulus_library/packs/PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1/stimulus_pack_manifest.json",
        )
        missing = [relative for relative in expected if not (PACKAGE / relative).is_file()]
        self.assertEqual(missing, [])

    def test_alpha4_module_registry_entries_resolve_to_the_governed_tools(self) -> None:
        registry = _json(PACKAGE / "config" / "module_registry_v1_0_alpha_4.json")
        modules = {row["id"]: row for row in registry["modules"]}
        expected = {
            "stimulus_library": "tools/Stimulus_Forge_Library_v1_0/praycg_stimulus_library_v1_0.py",
            "stimulus_forge": "tools/Stimulus_Forge_Library_v1_0/praycg_stimulus_forge_v1_0.py",
            "hardware_forge": "tools/Hardware_Forge_v0_1/praycg_hardware_forge_v0_1.py",
            "analysis_module_catalog": "tools/Analysis_Module_Catalog_v0_1/praycg_analysis_module_catalog_v0_1.py",
        }
        for module_id, entry in expected.items():
            with self.subTest(module_id=module_id):
                self.assertEqual(modules[module_id]["entry"], entry)
                self.assertTrue((PACKAGE / entry).is_file())
        self.assertEqual(modules["analysis_module_catalog"]["primary_endpoint_authority"], "NONE")
        self.assertEqual(modules["analysis_module_catalog"]["master_suite_eligibility_effect"], "NONE")
        self.assertEqual(modules["hardware_forge"]["runner_authority"], "NONE")
        self.assertFalse(modules["stimulus_library"]["scientific_collection_default"])

    def test_package_json_files_are_parseable_and_schema_ids_are_distinct(self) -> None:
        paths = (
            PACKAGE / "config" / "analysis_module_registry_v0_1.json",
            PACKAGE / "config" / "hardware_adapter_catalog_v0_1.json",
            ANALYSIS_ROOT / "analysis_module_descriptor_v0_1.schema.json",
            HARDWARE_FORGE_ROOT / "schemas" / "hardware_adapter_descriptor_v0_1.schema.json",
            HARDWARE_FORGE_ROOT / "schemas" / "hardware_profile_draft_v0_2.schema.json",
            STIMULUS_ROOT / "config" / "stimulus_pack_catalog_v1_0.json",
            STIMULUS_ROOT / "config" / "stimulus_pack_schema_v1_0.json",
        )
        values = [_json(path) for path in paths]
        identities = [value.get("schema") or value.get("$id") for value in values]
        self.assertTrue(all(identities))
        self.assertEqual(len(identities), len(set(identities)))


if __name__ == "__main__":
    unittest.main()
