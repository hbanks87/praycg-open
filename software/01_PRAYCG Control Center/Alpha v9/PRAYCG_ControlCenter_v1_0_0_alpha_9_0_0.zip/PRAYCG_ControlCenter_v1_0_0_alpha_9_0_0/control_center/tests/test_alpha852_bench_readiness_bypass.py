from __future__ import annotations

import copy
import importlib.util
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest


PACKAGE = Path(__file__).resolve().parents[2]
SCRIPT_DIR = PACKAGE / "control_center" / "scripts"
PLATFORM_DIR = PACKAGE / "platform_core"
for entry in (SCRIPT_DIR, PLATFORM_DIR):
    if str(entry) not in sys.path:
        sys.path.insert(0, str(entry))

spec = importlib.util.spec_from_file_location(
    "praycg_alpha852_bench_bypass",
    SCRIPT_DIR / "praycg_control_center_v1_0_0_alpha_8.py",
)
assert spec and spec.loader
control = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = control
spec.loader.exec_module(control)

import praycg_platform_core_v1_0_alpha_4 as platform  # noqa: E402


class ValueVar:
    def __init__(self) -> None:
        self.value = ""

    def set(self, value) -> None:
        self.value = value


class Button:
    def __init__(self) -> None:
        self.state = "unknown"

    def configure(self, **kwargs) -> None:
        self.state = kwargs.get("state", self.state)


class Alpha852BenchReadinessBypassTests(unittest.TestCase):
    def _selection(self, root: Path, *, bench: bool = True):
        library = PACKAGE / "tools" / "ProtocolRunner_ModuleLibrary_v1_0"
        protocol_path = library / "protocols" / "PRAYCG3_original_three_prong_v1_0.json"
        hardware_path = PACKAGE / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json"
        run_uuid = "85200000-1234-1234-1234-123456789abc"
        artifact_root = root / "logs" / "protocol_runs" / run_uuid
        artifact_root.mkdir(parents=True)
        build_dir, snapshot = platform.compile_protocol(
            protocol_path,
            library,
            root / "protocol_build",
            human_reviewed_by="Alpha 8.5.3 Test",
        )
        profile_path = artifact_root / "hardware_profile_snapshot.json"
        profile = platform.build_hardware_profile(
            [hardware_path],
            profile_path,
            profile_id="alpha852_bench_bypass",
            reviewed_by="Alpha 8.5.3 Test",
        )
        bypass_path = artifact_root / "bench_readiness_bypass_preflight.json"
        bypass = control.build_bench_readiness_bypass_preflight(
            profile,
            run_uuid,
            operator="Bench Operator",
            source_preflight={
                "status": "INELIGIBLE",
                "errors": ["LSL stream not found", "ALS stream unavailable"],
                "cautions": [],
            },
        )
        platform.write_json(bypass_path, bypass)
        template = {
            "schema": "PRAYCG_StudySession_v0_2",
            "study_id": "SYNTHETIC",
            "session_id": run_uuid,
            "participant_pseudonym": f"BENCH-{run_uuid[:8].upper()}" if bench else "P001",
            "session_purpose": "BENCH_TEST" if bench else "PARTICIPANT_ACQUISITION",
            "participant_data_eligible": not bench,
            "bench_test_mode": bench,
            "bench_test_reason": "no hardware connected" if bench else "",
            "bench_eeg_quality_waiver_active": False,
            "bench_readiness_bypass_active": bench,
            "bench_bypass_preflight_path": str(bypass_path) if bench else "",
            "protocol_module": str(protocol_path),
            "hardware_profile": str(profile_path),
            "assigned_sequence": [],
            "stimulus_id": "SYNTHETIC_STIMULUS",
            "stimulus_folder": str(root),
            "media_selection_snapshot": {
                "protocol": {
                    "path": str(protocol_path),
                    "sha256": platform.sha256_file(protocol_path),
                }
            },
            "control_center_readiness": "CAUTION" if bench else "PASS",
            "private_output_locations": {"session_log_dir": str(artifact_root)},
            "control_center_process_id": "alpha852-test-control-center",
        }
        draft = platform.build_session_draft(
            template,
            snapshot,
            profile,
            artifact_root / ("bench_draft.json" if bench else "participant_draft.json"),
            protocol_snapshot_path=build_dir / "approved_protocol_snapshot.json",
            hardware_profile_path=profile_path,
        )
        return run_uuid, profile, bypass, bypass_path, draft

    def _readiness_app(self, *, bench: bool, approved: bool = True):
        acquisition = {
            "bench_test_mode": bench,
            "preflight_started_epoch": 0.0,
            "profile_preflight_report_path": "missing-profile-report.json",
            "detailed_preflight_dir": ".",
            "als_test_dir": ".",
            "armed": False,
            "session_stage": "SELECT",
        }
        profile = {"status": "APPROVED", "canonical_sha256": "profile-a"} if approved else None
        app = SimpleNamespace(
            cfg={"acquisition": acquisition, "log_root": ".", "praycg_home": "."},
            active_hardware_profile=profile,
            active_run_uuid="run-a",
            locked_protocol={"protocol_id": "TEST"},
            acq_readiness_var=ValueVar(),
            acq_gate_var=ValueVar(),
            bench_test_status_var=ValueVar(),
            runner_hardware_var=ValueVar(),
            post_run_gate_var=ValueVar(),
            acq_session_lock_button=Button(),
            acq_arm_button=Button(),
        )
        app.newest_json = lambda _folder, _pattern: Path("missing-detail.json")
        app.profile_preflight_status = lambda _path, _started: ("INELIGIBLE", "missing hardware")
        app.detailed_preflight_report_status = lambda _path, _started: ("FAIL", "missing EEG/ALS")
        app.als_barcode_report_status = lambda _path, _started: ("BENCH_DISPLAY_ONLY", "no ALS")
        app.bench_eeg_quality_waiver_status = lambda _path: (False, "missing streams")
        app.active_hardware_roles = lambda: {"eeg", "als"}
        app.hardware_profile_approved = lambda _profile: approved
        app.platform_core_available = lambda: False
        app.demo_only_stimulus_reason = lambda: "selected stimulus pack is DEMO_ONLY"
        app.refresh_protocol_lock_status = lambda **_kwargs: None
        app.validate_active_session_lock = lambda: ("NOT_LOCKED", "test")
        app.write_acquisition_state = lambda: None
        return app

    def test_failed_missing_and_display_only_hardware_are_nonblocking_in_bench_mode(self) -> None:
        app = self._readiness_app(bench=True)
        status = control.PRAYCGControlCenter.refresh_acquisition_readiness(app)
        self.assertEqual(status, "CAUTION")
        self.assertEqual(app.acq_session_lock_button.state, "normal")
        self.assertTrue(app.cfg["acquisition"]["bench_readiness_bypass_active"])
        self.assertIn("ALS barcode placement test is bench_display_only", app.cfg["acquisition"]["readiness_message"])

    def test_same_failures_remain_blocking_for_participant_acquisition(self) -> None:
        app = self._readiness_app(bench=False)
        status = control.PRAYCGControlCenter.refresh_acquisition_readiness(app)
        self.assertEqual(status, "INELIGIBLE")
        self.assertEqual(app.acq_session_lock_button.state, "disabled")
        self.assertFalse(app.cfg["acquisition"]["bench_readiness_bypass_active"])

    def test_bench_bypass_does_not_replace_required_reviewed_profile(self) -> None:
        app = self._readiness_app(bench=True, approved=False)
        status = control.PRAYCGControlCenter.refresh_acquisition_readiness(app)
        self.assertEqual(status, "INELIGIBLE")
        self.assertEqual(app.acq_session_lock_button.state, "disabled")

    def test_bench_bypass_does_not_override_broken_stimulus_file_contract(self) -> None:
        app = self._readiness_app(bench=True)
        app.demo_only_stimulus_reason = lambda: "selected stimulus pack fails its frozen file/hash contract and cannot be armed"
        status = control.PRAYCGControlCenter.refresh_acquisition_readiness(app)
        self.assertEqual(status, "INELIGIBLE")
        self.assertEqual(app.acq_session_lock_button.state, "disabled")

    def test_bypass_preflight_is_hash_valid_auditable_and_armable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            _run_uuid, profile, bypass, _bypass_path, draft = self._selection(root, bench=True)
            self.assertEqual(bypass["canonical_sha256"], platform.sha256_json({
                key: value for key, value in bypass.items() if key != "canonical_sha256"
            }))
            self.assertEqual(
                {row["module_id"] for row in bypass["module_evidence"]},
                {row["module_id"] for row in profile["modules"]},
            )
            lock_path = root / "logs" / "protocol_runs" / _run_uuid / "runtime_session_lock.json"
            lock = platform.build_session_lock(
                draft,
                bypass,
                lock_path,
                operator="Bench Operator",
                allow_caution_override=True,
                override_reason="no hardware connected",
            )
            self.assertEqual(lock["status"], "LOCKED_READY_TO_ARM")
            self.assertEqual(lock["lock_core"]["preflight_status"], "CAUTION")
            self.assertTrue(control.locked_session_classification_status(lock["session"])[0])
            armed = platform.advance_session_gate(lock, "ARM", lock_path, operator="Bench Operator")
            self.assertEqual(armed["current_stage"], "ARM")
            self.assertEqual(platform.validate_session_lock_identity(armed).status, "PASS")

    def test_platform_core_rejects_bypass_artifact_for_participant_session(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            run_uuid, _profile, bypass, _bypass_path, participant_draft = self._selection(root, bench=False)
            lock = platform.build_session_lock(
                participant_draft,
                bypass,
                root / "logs" / "protocol_runs" / run_uuid / "participant_lock.json",
                operator="Bench Operator",
                allow_caution_override=True,
                override_reason="must not authorize participant data",
            )
            self.assertEqual(lock["status"], "NOT_LOCKABLE")
            self.assertIn(
                "Participant sessions cannot use bench readiness-bypass preflight evidence.",
                lock["validation"]["errors"],
            )

    def test_repeated_bypass_artifacts_never_claim_participant_eligibility(self) -> None:
        profile = {
            "canonical_sha256": "profile-a",
            "modules": [{
                "module_id": "synthetic",
                "module_file_sha256": "file-a",
                "module_canonical_sha256": "module-a",
            }],
        }
        for index in range(250):
            report = control.build_bench_readiness_bypass_preflight(
                copy.deepcopy(profile),
                f"run-{index}",
                operator="Stress Operator",
                source_preflight={"status": "INELIGIBLE", "errors": [f"failure-{index}"]},
            )
            self.assertIs(report["participant_data_eligible"], False)
            self.assertIs(report["bench_readiness_bypass_active"], True)
            self.assertEqual(report["status"], "CAUTION")
            self.assertEqual(report["errors"], [])
            self.assertEqual(report["canonical_sha256"], platform.sha256_json({
                key: value for key, value in report.items() if key != "canonical_sha256"
            }))


if __name__ == "__main__":
    unittest.main()
