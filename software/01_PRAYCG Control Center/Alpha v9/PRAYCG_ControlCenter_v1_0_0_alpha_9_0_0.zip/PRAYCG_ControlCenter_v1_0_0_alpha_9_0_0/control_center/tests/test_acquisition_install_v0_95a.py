from contextlib import redirect_stdout
import io
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools" / "Acquisition"))
import praycg_check_acquisition_install_v1_0 as check


class AcquisitionInstallTests(unittest.TestCase):
    def setUp(self):
        self.board = SimpleNamespace(
            disable_board_logger=Mock(),
            get_sampling_rate=Mock(return_value=125),
            get_eeg_channels=Mock(side_effect=lambda b: list(range(8 if b == 0 else 16))),
            get_analog_channels=Mock(return_value=[27, 28, 29]),
        )
        # Only metadata APIs are provided. Hardware access would fail the test.
        self.modules = {
            "numpy": SimpleNamespace(), "serial": SimpleNamespace(),
            "pylsl": SimpleNamespace(local_clock=Mock(return_value=123.0)),
            "brainflow.board_shim": SimpleNamespace(BoardShim=self.board, BoardIds=SimpleNamespace(
                CYTON_BOARD=SimpleNamespace(value=0), CYTON_DAISY_BOARD=SimpleNamespace(value=2))),
        }

    def run_check(self, missing=None):
        def load(name):
            if name == missing:
                raise ModuleNotFoundError(name)
            return self.modules[name]
        with patch.object(check.importlib, "import_module", side_effect=load), \
             patch.object(check.metadata, "version", return_value="test"), \
             redirect_stdout(io.StringIO()) as output:
            code = check.main()
        return code, output.getvalue()

    def test_native_success_no_hardware(self):
        code, output = self.run_check()
        self.assertEqual(code, 0)
        self.board.disable_board_logger.assert_called_once()
        self.assertEqual(self.board.get_sampling_rate.call_count, 2)
        self.assertIn("NOT tested", output)

    def test_native_failure_despite_successful_import(self):
        self.board.disable_board_logger.side_effect = ModuleNotFoundError("No module named 'pkg_resources'")
        code, output = self.run_check()
        self.assertEqual(code, 1)
        self.assertIn("setuptools>=80.9,<82", output)
        self.assertNotIn("PASS:", output)

    def test_missing_pyserial_fails(self):
        self.assertEqual(self.run_check(missing="serial")[0], 1)

    def test_missing_brainflow_fails(self):
        self.assertEqual(self.run_check(missing="brainflow.board_shim")[0], 1)

    def test_lsl_native_failure_fails(self):
        self.modules["pylsl"].local_clock.side_effect = OSError("DLL missing")
        self.assertEqual(self.run_check()[0], 1)

    def test_invalid_board_metadata_fails(self):
        self.board.get_analog_channels.return_value = []
        self.assertEqual(self.run_check()[0], 1)

    def test_all_installer_branches_pin_and_probe(self):
        bat = (ROOT / "INSTALL_PRAYCG_v1_0_0_alpha_9_0_0.bat").read_text()
        self.assertEqual(bat.count('install --upgrade pip "setuptools>=80.9,<82" wheel'), 3)
        self.assertEqual(bat.count('"%PRAYCG_ACQUISITION_CHECK%"'), 3)
        self.assertIn("endlocal & exit /b 0", bat)
        self.assertIn("endlocal & exit /b 1", bat)
        for req in [ROOT / "requirements_PRAYCG_v1_0_0_alpha_9_0_0.txt", *(
            ROOT / "tools" / "Acquisition").glob("*/requirements*.txt")]:
            with self.subTest(requirements=req.name):
                content = req.read_text()
                self.assertIn("setuptools>=80.9,<82", content)
                self.assertIn("pyserial>=3.5,<4", content)


if __name__ == "__main__":
    unittest.main()
