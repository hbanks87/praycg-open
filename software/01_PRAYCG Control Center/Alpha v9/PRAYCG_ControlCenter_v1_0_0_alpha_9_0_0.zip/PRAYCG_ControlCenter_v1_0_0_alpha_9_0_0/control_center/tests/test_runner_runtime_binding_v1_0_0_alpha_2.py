from __future__ import annotations

import importlib.util
import os
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path
from unittest.mock import patch


PACKAGE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PACKAGE / "platform_core"))
sys.path.insert(0, str(PACKAGE / "control_center" / "scripts"))

import praycg_platform_core_v1_0_alpha_2 as platform_core  # noqa: E402
import praycg_platform_core_v1_0_alpha_3 as platform_core_alpha3  # noqa: E402
import praycg_control_center_v1_0_0_alpha_2 as control_center  # noqa: E402
from praycg_platform_core_v1_0_alpha_2 import (  # noqa: E402
    active_acquisition_owner_path,
    advance_session_gate,
    aggregate_hardware_preflight,
    bind_authorized_runner_lease_process,
    build_hardware_profile,
    build_session_draft,
    build_session_lock,
    bind_active_acquisition_owner_lease,
    claim_active_acquisition_owner,
    compile_protocol,
    issue_authorized_runner_lease,
    consume_authorized_runner_lease,
    finish_authorized_runner_lease,
    load_json,
    sha256_file,
    sha256_json,
    runtime_runner_lease_activity,
    write_json,
)


def load_engine_with_dependency_stubs():
    pylsl = types.ModuleType("pylsl")
    for name in ("StreamInfo", "StreamOutlet", "StreamInlet"):
        setattr(pylsl, name, type(name, (), {}))
    pylsl.local_clock = lambda: 0.0
    pylsl.resolve_byprop = lambda *_args, **_kwargs: []
    psychopy = types.ModuleType("psychopy")
    for name in ("core", "event", "gui", "logging", "visual"):
        setattr(psychopy, name, types.SimpleNamespace())
    constants = types.ModuleType("psychopy.constants")
    constants.FINISHED = "FINISHED"
    engine_path = PACKAGE / "tools" / "ProtocolRunner_ModuleLibrary_v1_0" / "scripts" / "praycg_protocol_engine_v3_0.py"
    spec = importlib.util.spec_from_file_location("praycg_protocol_engine_alpha2_test", engine_path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {
        "pylsl": pylsl,
        "psychopy": psychopy,
        "psychopy.constants": constants,
        str(spec.name): module,
    }):
        spec.loader.exec_module(module)
    return module


class RunnerRuntimeBindingTests(unittest.TestCase):
    def _armed_session(self, root: Path, *, session_overrides=None):
        library = PACKAGE / "tools" / "ProtocolRunner_ModuleLibrary_v1_0"
        protocol_path = library / "protocols" / "PRAYCG3_original_three_prong_v1_0.json"
        hardware_path = PACKAGE / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json"
        build_dir, snapshot = compile_protocol(
            protocol_path, library, root / "protocol_build", human_reviewed_by="Alpha Tester"
        )
        profile_path = root / "profile.json"
        profile = build_hardware_profile(
            [hardware_path], profile_path, profile_id="runner_binding", reviewed_by="Alpha Tester"
        )
        run_uuid = "12345678-1234-1234-1234-123456789abc"
        artifact_root = root / "logs" / "protocol_runs" / run_uuid
        artifact_root.mkdir(parents=True, exist_ok=True)
        media_snapshot = {}
        for key in ("control_video", "target_video", "override_video", "cue_schedule_json", "als_placement_profile"):
            path = root / f"{key}.dat"
            path.write_bytes((key + " synthetic fixture").encode("utf-8"))
            media_snapshot[key] = {"path": str(path.resolve()), "sha256": sha256_file(path)}
        module = load_json(protocol_path)
        template = {
            "schema": "PRAYCG_StudySession_v0_2",
            "study_id": "SYNTHETIC",
            "session_id": run_uuid,
            "participant_pseudonym": "P001",
            "session_purpose": "PARTICIPANT_ACQUISITION",
            "participant_data_eligible": True,
            "bench_test_mode": False,
            "bench_test_reason": "",
            "protocol_module": str(protocol_path),
            "hardware_profile": str(profile_path),
            "assigned_sequence": [row["phase"] for row in module["branches"]],
            "stimulus_id": "SYNTH_STIMULUS",
            "stimulus_folder": str(root),
            "media_selection_snapshot": media_snapshot,
            "private_output_locations": {"session_log_dir": str(artifact_root.resolve())},
            "control_center_process_id": "synthetic-control-center",
        }
        template.update(dict(session_overrides or {}))
        draft = build_session_draft(
            template,
            snapshot,
            profile,
            root / "draft.json",
            protocol_snapshot_path=build_dir / "approved_protocol_snapshot.json",
            hardware_profile_path=profile_path,
        )
        module_reports = []
        run_fragment = run_uuid.replace("-", "")[:12]
        for selected in profile["modules"]:
            stream_rows = []
            for stream in selected["streams"]:
                source = f"{stream.get('source_id_prefix') or 'synthetic_'}{run_fragment}{stream.get('source_id_suffix') or ''}"
                stream_rows.append({
                    "lsl_name": stream["lsl_name"],
                    "status": "PASS",
                    "resolved_candidate_count": 1,
                    "observed_source_id": source,
                })
            module_reports.append({
                "schema": "PRAYCG_HardwareModulePreflight_v1_0_alpha_2",
                "module_id": selected["module_id"],
                "expected_run_uuid": run_uuid,
                "module_file_sha256": selected["module_file_sha256"],
                "module_canonical_sha256": selected["module_canonical_sha256"],
                "status": "PASS",
                "streams": stream_rows,
            })
        preflight = aggregate_hardware_preflight(profile, module_reports, expected_run_uuid=run_uuid)
        lock_path = artifact_root / "runtime_session_lock.json"
        lock = build_session_lock(draft, preflight, lock_path, operator="Operator")
        lock = advance_session_gate(lock, "ARM", lock_path, operator="Operator")
        return protocol_path, lock_path, lock, run_uuid, media_snapshot

    @staticmethod
    def _acquire_claim(lock: dict) -> dict:
        protocol = lock["lock_core"]["selection_identity"]["protocol"]
        root = Path(lock["session"]["private_output_locations"]["session_log_dir"])
        log_root = root.parent.parent
        owner_path = active_acquisition_owner_path(log_root)
        if owner_path.is_file():
            owner = load_json(owner_path)
        else:
            owner_path, owner = claim_active_acquisition_owner(
                log_root,
                lock,
                root / "runtime_session_lock.json",
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
        lease_path = root / "authorized_runner_lease.json"
        if lease_path.is_file():
            lease = load_json(lease_path)
        else:
            lease_path, lease = issue_authorized_runner_lease(
                lock,
                root / "runtime_session_lock.json",
                "synthetic-test-claim-token-" + "x" * 48,
                launch_mode="psychopy_python",
                launch_command=[sys.executable, "runner.py"],
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
        if str(owner.get("status") or "") == "CLAIMED":
            owner = bind_active_acquisition_owner_lease(
                owner_path,
                lease_path,
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
        lease_core = lease["lease_core"]
        owner_core = owner["owner_core"]
        return {
            "event": "AUTHORIZED_RUNNER_PROCESS_CLAIMED_BEFORE_SPAWN",
            "run_uuid": lock["session"]["session_id"],
            "launch_mode": "psychopy_python",
            "protocol_id": protocol["protocol_id"],
            "protocol_version": protocol["protocol_version"],
            "runner_sha256": protocol["runner_file_sha256"],
            "lease_path": str(lease_path),
            "lease_id": lease_core["lease_id"],
            "lease_core_sha256": lease["lease_core_sha256"],
            "lease_claim_token_sha256": lease_core["claim_token_sha256"],
            "armed_state_sha256": lease_core["armed_state_sha256"],
            "active_owner_path": str(owner_path),
            "active_owner_id": owner_core["owner_id"],
            "active_owner_core_sha256": owner["owner_core_sha256"],
        }

    def _runner_cfg(self, engine, protocol_path: Path, lock: dict, media_snapshot: dict) -> dict:
        cfg = engine.attach_protocol_identity({}, engine.load_protocol_module(protocol_path))
        policy = dict(lock["session"]["runner_configuration_policy"])
        policy.pop("policy_version")
        policy["log_dir"] = policy.pop("session_log_dir")
        cfg.update(policy)
        cfg.update({key: record["path"] for key, record in media_snapshot.items()})
        cfg["participant_id"] = lock["session"]["participant_pseudonym"]
        cfg["session_id"] = lock["session"]["session_id"]
        return cfg

    @staticmethod
    def _purpose_environment(lock: dict) -> dict:
        session = lock["session"]
        return {
            "PRAYCG_SESSION_PURPOSE": session["session_purpose"],
            "PRAYCG_BENCH_TEST_MODE": "1" if session["bench_test_mode"] else "0",
        }

    @staticmethod
    def _rewrite_active_lease_identity(
        lease_path: Path,
        *,
        pid: int,
        start_identity: str,
        heartbeat_epoch: float,
    ) -> dict:
        binding_path = lease_path.with_name("authorized_runner_lease.process_binding.json")
        marker_path = lease_path.with_name("authorized_runner_lease.claim_consumed.json")
        binding = load_json(binding_path)
        binding["pid"] = pid
        binding["process_start_identity"] = start_identity
        binding["canonical_sha256"] = sha256_json(
            {key: value for key, value in binding.items() if key != "canonical_sha256"}
        )
        write_json(binding_path, binding)
        marker = load_json(marker_path)
        marker["process_binding_sha256"] = binding["canonical_sha256"]
        marker["pid"] = pid
        marker["process_start_identity"] = start_identity
        marker["canonical_sha256"] = sha256_json(
            {key: value for key, value in marker.items() if key != "canonical_sha256"}
        )
        write_json(marker_path, marker)
        lease = load_json(lease_path)
        lease["pid"] = pid
        lease["process_start_identity"] = start_identity
        lease["heartbeat_epoch"] = heartbeat_epoch
        lease["heartbeat_utc"] = "synthetic"
        lease["lease_state_sha256"] = sha256_json(
            {key: value for key, value in lease.items() if key != "lease_state_sha256"}
        )
        write_json(lease_path, lease)
        return lease

    def test_valid_armed_lock_passes_and_changed_timing_fails(self) -> None:
        engine = load_engine_with_dependency_stubs()
        with tempfile.TemporaryDirectory() as temp:
            protocol_path, lock_path, lock, run_uuid, media = self._armed_session(Path(temp))
            cfg = self._runner_cfg(engine, protocol_path, lock, media)
            environment = {
                "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                "PRAYCG_RUN_UUID": run_uuid,
                "PRAYCG_PARTICIPANT_PSEUDONYM": "P001",
                **self._purpose_environment(lock),
            }
            with patch.dict(os.environ, environment, clear=False):
                path, loaded = engine.load_and_validate_runtime_session(cfg, required_stage="ARM")
                self.assertEqual(path, lock_path.resolve())
                self.assertEqual(loaded["current_stage"], "ARM")
                changed = dict(cfg)
                changed["baseline_seconds"] = 119.0
                with self.assertRaisesRegex(RuntimeError, "baseline_seconds"):
                    engine.load_and_validate_runtime_session(changed, required_stage="ARM")

    def test_purpose_binding_persists_participant_and_bench_run_state(self) -> None:
        engine = load_engine_with_dependency_stubs()
        cases = (
            ({}, "P001", "PARTICIPANT_ACQUISITION", True, False, ""),
            ({
                "participant_pseudonym": "BENCH-12345678",
                "session_purpose": "BENCH_TEST",
                "participant_data_eligible": False,
                "bench_test_mode": True,
                "bench_test_reason": "cap-off signal-path validation",
            }, "BENCH-12345678", "BENCH_TEST", False, True, "cap-off signal-path validation"),
        )
        with tempfile.TemporaryDirectory() as temp:
            for index, (overrides, pseudonym, purpose, eligible, bench_mode, reason) in enumerate(cases):
                with self.subTest(purpose=purpose):
                    root = Path(temp) / str(index)
                    protocol_path, lock_path, lock, _run_uuid, media = self._armed_session(
                        root,
                        session_overrides=overrides,
                    )
                    cfg = self._runner_cfg(engine, protocol_path, lock, media)
                    environment = {
                        "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                        "PRAYCG_RUN_UUID": lock["session"]["session_id"],
                        "PRAYCG_PARTICIPANT_PSEUDONYM": pseudonym,
                        **self._purpose_environment(lock),
                    }
                    with patch.dict(os.environ, environment, clear=False):
                        engine.load_and_validate_runtime_session(cfg, required_stage="ARM")
                    fake_logger = types.SimpleNamespace(
                        log_dir=root,
                        csv_path=root / "events.csv",
                        json_path=root / "events.json",
                        run_uuid=lock["session"]["session_id"],
                    )
                    state = engine.RunStateManifest(fake_logger, cfg)
                    persisted = load_json(state.path)
                    self.assertEqual(persisted["session_purpose"], purpose)
                    self.assertIs(persisted["participant_data_eligible"], eligible)
                    self.assertIs(persisted["bench_test_mode"], bench_mode)
                    self.assertEqual(persisted["bench_test_reason"], reason)

    def test_purpose_environment_must_match_lock_in_both_directions(self) -> None:
        engine = load_engine_with_dependency_stubs()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            protocol_path, lock_path, lock, run_uuid, media = self._armed_session(root / "participant")
            cfg = self._runner_cfg(engine, protocol_path, lock, media)
            base = {
                "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                "PRAYCG_RUN_UUID": run_uuid,
                "PRAYCG_PARTICIPANT_PSEUDONYM": "P001",
            }
            for purpose, bench_flag, message in (
                ("BENCH_TEST", "0", "PRAYCG_SESSION_PURPOSE"),
                ("PARTICIPANT_ACQUISITION", "1", "PRAYCG_BENCH_TEST_MODE"),
            ):
                with self.subTest(purpose=purpose, bench_flag=bench_flag):
                    with patch.dict(os.environ, {**base, "PRAYCG_SESSION_PURPOSE": purpose, "PRAYCG_BENCH_TEST_MODE": bench_flag}, clear=False):
                        with self.assertRaisesRegex(RuntimeError, message):
                            engine.load_and_validate_runtime_session(dict(cfg), required_stage="ARM")

            bench_overrides = {
                "participant_pseudonym": "BENCH-12345678",
                "session_purpose": "BENCH_TEST",
                "participant_data_eligible": False,
                "bench_test_mode": True,
                "bench_test_reason": "cap-off validation",
            }
            protocol_path, lock_path, lock, run_uuid, media = self._armed_session(root / "bench", session_overrides=bench_overrides)
            cfg = self._runner_cfg(engine, protocol_path, lock, media)
            base = {
                "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                "PRAYCG_RUN_UUID": run_uuid,
                "PRAYCG_PARTICIPANT_PSEUDONYM": "BENCH-12345678",
            }
            for purpose, bench_flag, message in (
                ("PARTICIPANT_ACQUISITION", "1", "PRAYCG_SESSION_PURPOSE"),
                ("BENCH_TEST", "0", "PRAYCG_BENCH_TEST_MODE"),
            ):
                with self.subTest(purpose=purpose, bench_flag=bench_flag):
                    with patch.dict(os.environ, {**base, "PRAYCG_SESSION_PURPOSE": purpose, "PRAYCG_BENCH_TEST_MODE": bench_flag}, clear=False):
                        with self.assertRaisesRegex(RuntimeError, message):
                            engine.load_and_validate_runtime_session(dict(cfg), required_stage="ARM")

    def test_hash_valid_lock_purpose_invariants_fail_closed(self) -> None:
        engine = load_engine_with_dependency_stubs()
        cases = (
            ({"bench_test_mode": True, "session_purpose": "BENCH_TEST", "participant_data_eligible": False, "bench_test_reason": "", "participant_pseudonym": "BENCH-12345678"}, "bench_test_reason"),
            ({"bench_test_mode": True, "session_purpose": "BENCH_TEST", "participant_data_eligible": True, "bench_test_reason": "test", "participant_pseudonym": "BENCH-12345678"}, "participant_data_eligible"),
            ({"bench_test_mode": True, "session_purpose": "BENCH_TEST", "participant_data_eligible": False, "bench_test_reason": "test", "participant_pseudonym": "P001"}, "BENCH-"),
            ({"bench_test_mode": False, "session_purpose": "PARTICIPANT_ACQUISITION", "participant_data_eligible": True, "bench_test_reason": "", "participant_pseudonym": "BENCH-NOT-A-PARTICIPANT"}, "must not begin"),
        )
        with tempfile.TemporaryDirectory() as temp:
            for index, (overrides, message) in enumerate(cases):
                with self.subTest(message=message):
                    _protocol_path, lock_path, lock, _run_uuid, _media = self._armed_session(
                        Path(temp) / str(index),
                        session_overrides=overrides,
                    )
                    self.assertEqual(platform_core.validate_session_lock_identity(lock).status, "PASS")
                    environment = {
                        "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                        **self._purpose_environment(lock),
                    }
                    with patch.dict(os.environ, environment, clear=False):
                        with self.assertRaisesRegex(RuntimeError, message):
                            engine.load_runtime_session_authority(required_stage="ARM")

    def test_missing_runtime_lock_is_rejected(self) -> None:
        engine = load_engine_with_dependency_stubs()
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "mandatory"):
                engine.load_and_validate_runtime_session({}, required_stage="ARM")
            with self.assertRaisesRegex(RuntimeError, "claimed only by the Control Center"):
                engine.advance_runtime_session_gate("ACQUIRE", {}, {})

    def test_engine_requires_valid_acquire_process_claim(self) -> None:
        engine = load_engine_with_dependency_stubs()
        with tempfile.TemporaryDirectory() as temp:
            protocol_path, lock_path, armed, run_uuid, media = self._armed_session(Path(temp))
            claim = self._acquire_claim(armed)
            acquiring = advance_session_gate(
                armed,
                "ACQUIRE",
                lock_path,
                operator="Operator",
                evidence=claim,
            )
            cfg = self._runner_cfg(engine, protocol_path, acquiring, media)
            environment = {
                "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                "PRAYCG_RUN_UUID": run_uuid,
                "PRAYCG_PARTICIPANT_PSEUDONYM": "P001",
                "PRAYCG_RUNNER_LEASE_JSON": claim["lease_path"],
                **self._purpose_environment(acquiring),
            }
            with patch.dict(os.environ, environment, clear=False):
                _path, loaded = engine.load_runtime_session_authority(required_stage="ACQUIRE")
                self.assertEqual(loaded["current_stage"], "ACQUIRE")
                _path, loaded = engine.load_and_validate_runtime_session(cfg, required_stage="ACQUIRE")
                self.assertEqual(loaded["current_stage"], "ACQUIRE")

    def test_runner_lease_token_is_pid_bound_and_exactly_once(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            _protocol_path, lock_path, armed, run_uuid, _media = self._armed_session(Path(temp))
            token = "one-use-authorized-runner-token-" + "x" * 48
            lease_path, _lease = issue_authorized_runner_lease(
                armed,
                lock_path,
                token,
                launch_mode="psychopy_python",
                launch_command=[sys.executable, "runner.py"],
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
            bind_authorized_runner_lease_process(lease_path, pid=os.getpid())
            with self.assertRaisesRegex(RuntimeError, "claim token"):
                consume_authorized_runner_lease(
                    lease_path,
                    "wrong-token-" + "z" * 48,
                    expected_lock_path=lock_path,
                    expected_run_uuid=run_uuid,
                )
            active = consume_authorized_runner_lease(
                lease_path,
                token,
                expected_lock_path=lock_path,
                expected_run_uuid=run_uuid,
            )
            self.assertEqual(active["status"], "ACTIVE")
            self.assertEqual(active["pid"], os.getpid())
            self.assertTrue(runtime_runner_lease_activity(lease_path)["active"])
            with self.assertRaisesRegex(RuntimeError, "exact exiting process PID"):
                finish_authorized_runner_lease(
                    lease_path,
                    status="LAUNCH_FAILED",
                    reason="MISSING_EXIT_IDENTITY_MUST_NOT_CLOSE_ACTIVE",
                    allow_unconsumed=True,
                )
            if str(active.get("process_start_identity") or ""):
                with self.assertRaisesRegex(RuntimeError, "nonblank process-start identity"):
                    finish_authorized_runner_lease(
                        lease_path,
                        status="LAUNCH_FAILED",
                        reason="MISSING_START_IDENTITY_MUST_NOT_CLOSE_ACTIVE",
                        pid=os.getpid(),
                        allow_unconsumed=True,
                    )
            with self.assertRaisesRegex(RuntimeError, "already been consumed|already consumed"):
                consume_authorized_runner_lease(
                    lease_path,
                    token,
                    expected_lock_path=lock_path,
                    expected_run_uuid=run_uuid,
                )
            ended = finish_authorized_runner_lease(
                lease_path,
                status="EXITED",
                reason="SYNTHETIC_TEST_COMPLETE",
                exit_code=0,
                pid=os.getpid(),
                start_identity=str(active.get("process_start_identity") or ""),
            )
            self.assertEqual(ended["status"], "EXITED")
            self.assertTrue(runtime_runner_lease_activity(lease_path)["active"])
            with patch.object(platform_core_alpha3, "_process_identity_state", return_value="DEAD"):
                alpha853_terminal = platform_core_alpha3.runtime_runner_lease_activity(
                    lease_path,
                    now_epoch=float(ended.get("heartbeat_epoch") or 0.0) + 0.1,
                )
            self.assertFalse(alpha853_terminal["active"])
            with patch.object(platform_core, "_process_identity_state", return_value="DEAD"):
                terminal = runtime_runner_lease_activity(
                    lease_path,
                    now_epoch=float(ended.get("heartbeat_epoch") or 0.0) + 100.0,
                )
            self.assertFalse(terminal["active"])

            exit_marker = lease_path.with_name("authorized_runner_lease.exit.json")
            exit_marker.unlink()
            missing_exit = runtime_runner_lease_activity(lease_path)
            self.assertTrue(missing_exit["active"])
            self.assertEqual(missing_exit["status"], "INVALID")
            with self.assertRaisesRegex(RuntimeError, "lacks its immutable exit record"):
                finish_authorized_runner_lease(
                    lease_path,
                    status="EXITED",
                    reason="TERMINAL_IDEMPOTENCE_REQUIRES_VALID_EXIT_RECORD",
                    exit_code=0,
                    pid=os.getpid(),
                    start_identity=str(active.get("process_start_identity") or ""),
                )

    def test_live_process_binding_blocks_even_after_unconsumed_claim_expiry(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            _protocol_path, lock_path, armed, _run_uuid, _media = self._armed_session(Path(temp))
            lease_path, lease = issue_authorized_runner_lease(
                armed,
                lock_path,
                "live-bound-expired-claim-token-" + "l" * 48,
                launch_mode="psychopy_python",
                launch_command=[sys.executable, "runner.py"],
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
                claim_ttl_sec=5.0,
            )
            bind_authorized_runner_lease_process(lease_path, pid=os.getpid())
            activity = runtime_runner_lease_activity(
                lease_path,
                now_epoch=float(lease["lease_core"]["claim_expires_epoch"]) + 100.0,
            )
            self.assertTrue(activity["active"])
            self.assertEqual(activity["status"], "CLAIM_ISSUED")
            self.assertIn("PID/process-start identity is alive", activity["reason"])

    def test_malformed_consumption_marker_is_uncertain_not_expired(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            _protocol_path, lock_path, armed, _run_uuid, _media = self._armed_session(Path(temp))
            lease_path, lease = issue_authorized_runner_lease(
                armed,
                lock_path,
                "malformed-consumption-marker-token-" + "m" * 48,
                launch_mode="psychopy_python",
                launch_command=[sys.executable, "runner.py"],
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
                claim_ttl_sec=5.0,
            )
            bind_authorized_runner_lease_process(lease_path, pid=os.getpid())
            write_json(lease_path.with_name("authorized_runner_lease.claim_consumed.json"), {})
            activity = runtime_runner_lease_activity(
                lease_path,
                now_epoch=float(lease["lease_core"]["claim_expires_epoch"]) + 100.0,
            )
            self.assertTrue(activity["active"])
            self.assertEqual(activity["status"], "CLAIM_CONSUMPTION_UNCERTAIN")

    def test_unlocked_optional_media_and_evidence_inputs_are_rejected(self) -> None:
        engine = load_engine_with_dependency_stubs()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            protocol_path, lock_path, armed, run_uuid, media = self._armed_session(root)
            claim = self._acquire_claim(armed)
            acquiring = advance_session_gate(
                armed,
                "ACQUIRE",
                lock_path,
                operator="Operator",
                evidence=claim,
            )
            cfg = self._runner_cfg(engine, protocol_path, acquiring, media)
            environment = {
                "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                "PRAYCG_RUN_UUID": run_uuid,
                "PRAYCG_PARTICIPANT_PSEUDONYM": "P001",
                "PRAYCG_RUNNER_LEASE_JSON": claim["lease_path"],
                **self._purpose_environment(acquiring),
            }
            with patch.dict(os.environ, environment, clear=False):
                for key in (
                    "predeclared_anchor_file",
                    "shot_order_manifest",
                    "semantic_density_sidecar",
                ):
                    with self.subTest(key=key):
                        extra = root / f"unlocked_{key}.json"
                        extra.write_text("{}", encoding="utf-8")
                        changed = dict(cfg)
                        changed[key] = str(extra)
                        with self.assertRaisesRegex(RuntimeError, "unbound selections"):
                            engine.load_and_validate_runtime_session(changed, required_stage="ACQUIRE")

    def test_restarted_control_center_finalizes_only_dead_stale_active_lease(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            _protocol_path, lock_path, armed, run_uuid, _media = self._armed_session(root)
            claim = self._acquire_claim(armed)
            lease_path = Path(claim["lease_path"])
            token = "synthetic-test-claim-token-" + "x" * 48
            advance_session_gate(
                armed,
                "ACQUIRE",
                lock_path,
                operator="Operator",
                evidence=claim,
            )
            bind_authorized_runner_lease_process(lease_path, pid=os.getpid())
            active = consume_authorized_runner_lease(
                lease_path,
                token,
                expected_lock_path=lock_path,
                expected_run_uuid=run_uuid,
            )
            evidence_path = lock_path.parent / "interrupted_run.log"
            evidence_path.write_text("synthetic interrupted-run evidence", encoding="utf-8")
            gate_text = []
            messages = []
            harness = types.SimpleNamespace(
                cfg={
                    "log_root": str(root / "logs"),
                    "acquisition": {
                        "session_lock_path": str(lock_path),
                        "operator_name": "Operator",
                        "session_stage": "ACQUIRE",
                        "armed": False,
                    },
                },
                processes={},
                active_run_uuid=run_uuid,
                platform_core_available=lambda: True,
                validate_active_session_lock=lambda: ("VALID", "synthetic"),
                save_config=lambda: None,
                log=lambda message: messages.append(message),
                post_run_gate_var=types.SimpleNamespace(set=lambda value: gate_text.append(value)),
            )

            with patch.object(control_center.messagebox, "showerror") as blocked, patch.object(
                control_center.filedialog, "askopenfilename", return_value=str(evidence_path)
            ), patch.object(
                control_center.simpledialog, "askstring", return_value="Synthetic reviewed interruption"
            ), patch.object(control_center.messagebox, "showinfo"):
                control_center.PRAYCGControlCenter.finalize_interrupted_run(harness)
            blocked.assert_called_once()
            self.assertEqual(load_json(lock_path)["current_stage"], "ACQUIRE")
            self.assertEqual(load_json(lease_path)["status"], "ACTIVE")

            dead_pid = 2_147_480_000
            self._rewrite_active_lease_identity(
                lease_path,
                pid=dead_pid,
                start_identity="dead-process-start",
                heartbeat_epoch=time.time(),
            )
            with patch.object(control_center.messagebox, "showerror") as blocked, patch.object(
                control_center.filedialog, "askopenfilename", return_value=str(evidence_path)
            ), patch.object(
                control_center.simpledialog, "askstring", return_value="Synthetic reviewed interruption"
            ), patch.object(control_center.messagebox, "showinfo"):
                control_center.PRAYCGControlCenter.finalize_interrupted_run(harness)
            blocked.assert_called_once()
            self.assertEqual(load_json(lock_path)["current_stage"], "ACQUIRE")

            stale = self._rewrite_active_lease_identity(
                lease_path,
                pid=dead_pid,
                start_identity="dead-process-start",
                heartbeat_epoch=1.0,
            )
            exit_marker = {
                "schema": "PRAYCG_AuthorizedRunnerLeaseExit_v1_0_alpha_2",
                "lease_id": stale["lease_core"]["lease_id"],
                "lease_core_sha256": stale["lease_core_sha256"],
                "status": "EXITED",
                "pid": dead_pid,
                "process_start_identity": "dead-process-start",
                "exit_epoch": time.time(),
                "exit_utc": "synthetic",
                "exit_reason": "SYNTHETIC_CRASH_AFTER_EXIT_MARKER",
                "exit_code": None,
            }
            exit_marker["canonical_sha256"] = sha256_json(exit_marker)
            write_json(lease_path.with_name("authorized_runner_lease.exit.json"), exit_marker)
            with patch.object(control_center.messagebox, "showerror") as blocked, patch.object(
                control_center.filedialog, "askopenfilename", return_value=str(evidence_path)
            ), patch.object(
                control_center.simpledialog, "askstring", return_value="Synthetic reviewed interruption"
            ), patch.object(control_center.messagebox, "showinfo"):
                control_center.PRAYCGControlCenter.finalize_interrupted_run(harness)
            blocked.assert_not_called()
            self.assertEqual(load_json(lock_path)["current_stage"], "FINALIZE")
            self.assertEqual(load_json(lease_path)["status"], "EXITED")
            owner_activity = platform_core.active_acquisition_owner_activity(
                active_acquisition_owner_path(root / "logs")
            )
            self.assertFalse(owner_activity["active"])
            self.assertTrue(gate_text)

    def test_engine_guard_consumes_before_body_heartbeats_and_clears_secret(self) -> None:
        engine = load_engine_with_dependency_stubs()
        with tempfile.TemporaryDirectory() as temp:
            _protocol_path, lock_path, armed, run_uuid, _media = self._armed_session(Path(temp))
            token = "engine-guard-authorized-token-" + "y" * 48
            lease_path, _lease = issue_authorized_runner_lease(
                armed,
                lock_path,
                token,
                launch_mode="psychopy_python",
                launch_command=[sys.executable, "runner.py"],
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
            bind_authorized_runner_lease_process(lease_path, pid=os.getpid())
            advance_session_gate(
                armed,
                "ACQUIRE",
                lock_path,
                operator="Operator",
                evidence=self._acquire_claim(armed),
            )
            observations = {}

            @engine.authorized_runner_lease_guard
            def guarded_body():
                first = load_json(lease_path)
                self.assertEqual(first["status"], "ACTIVE")
                self.assertNotIn("PRAYCG_RUNNER_CLAIM_TOKEN", os.environ)
                time.sleep(2.2)
                second = load_json(lease_path)
                observations["first"] = float(first["heartbeat_epoch"])
                observations["second"] = float(second["heartbeat_epoch"])

            environment = {
                "PRAYCG_RUNNER_LEASE_JSON": str(lease_path),
                "PRAYCG_RUNNER_CLAIM_TOKEN": token,
                "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                "PRAYCG_RUN_UUID": run_uuid,
                **self._purpose_environment(armed),
            }
            with patch.dict(os.environ, environment, clear=False):
                guarded_body()
            self.assertGreater(observations["second"], observations["first"])
            self.assertEqual(load_json(lease_path)["status"], "EXITED")

    def test_copied_lease_path_cannot_replace_acquire_bound_canonical_lease(self) -> None:
        engine = load_engine_with_dependency_stubs()
        with tempfile.TemporaryDirectory() as temp:
            _protocol_path, lock_path, armed, run_uuid, _media = self._armed_session(Path(temp))
            claim = self._acquire_claim(armed)
            advance_session_gate(
                armed,
                "ACQUIRE",
                lock_path,
                operator="Operator",
                evidence=claim,
            )
            canonical_lease = Path(claim["lease_path"])
            copied_lease = canonical_lease.with_name("copied_authorized_runner_lease.json")
            copied_lease.write_bytes(canonical_lease.read_bytes())
            environment = {
                "PRAYCG_SESSION_LOCK_JSON": str(lock_path),
                "PRAYCG_RUN_UUID": run_uuid,
                "PRAYCG_RUNNER_LEASE_JSON": str(copied_lease),
                **self._purpose_environment(armed),
            }
            with patch.dict(os.environ, environment, clear=False):
                with self.assertRaisesRegex(RuntimeError, "does not match the canonical lease"):
                    engine.load_runtime_session_authority(required_stage="ACQUIRE")
            token = "synthetic-test-claim-token-" + "x" * 48
            with self.assertRaisesRegex(RuntimeError, "not the canonical run-local lease"):
                consume_authorized_runner_lease(
                    copied_lease,
                    token,
                    expected_lock_path=lock_path,
                    expected_run_uuid=run_uuid,
                )
            self.assertFalse(canonical_lease.with_name("authorized_runner_lease.claim_consumed.json").exists())

    def test_nonterminal_or_tampered_exit_marker_blocks_as_unknown_active(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            _protocol_path, lock_path, armed, _run_uuid, _media = self._armed_session(Path(temp))
            lease_path, lease = issue_authorized_runner_lease(
                armed,
                lock_path,
                "exit-marker-validation-token-" + "q" * 48,
                launch_mode="psychopy_python",
                launch_command=[sys.executable, "runner.py"],
                controller_instance_id="synthetic-control-center",
                controller_pid=os.getpid(),
            )
            marker = {
                "schema": "PRAYCG_AuthorizedRunnerLeaseExit_v1_0_alpha_2",
                "lease_id": lease["lease_core"]["lease_id"],
                "lease_core_sha256": lease["lease_core_sha256"],
                "status": "ACTIVE",
                "pid": os.getpid(),
                "process_start_identity": "",
                "exit_epoch": time.time(),
                "exit_utc": "synthetic",
                "exit_reason": "forged",
                "exit_code": None,
            }
            marker["canonical_sha256"] = sha256_json(marker)
            write_json(lease_path.with_name("authorized_runner_lease.exit.json"), marker)
            activity = runtime_runner_lease_activity(lease_path)
            self.assertTrue(activity["active"])
            self.assertEqual(activity["status"], "INVALID")

            for field, replacement in (
                ("schema", "PRAYCG_AuthorizedRunnerLeaseExit_WRONG"),
                ("lease_id", "different-lease-id"),
            ):
                with self.subTest(field=field):
                    terminal = dict(marker)
                    terminal["status"] = "EXITED"
                    terminal[field] = replacement
                    terminal["canonical_sha256"] = sha256_json(
                        {key: value for key, value in terminal.items() if key != "canonical_sha256"}
                    )
                    write_json(lease_path.with_name("authorized_runner_lease.exit.json"), terminal)
                    activity = runtime_runner_lease_activity(lease_path)
                    self.assertTrue(activity["active"])
                    self.assertEqual(activity["status"], "INVALID")


if __name__ == "__main__":
    unittest.main()
