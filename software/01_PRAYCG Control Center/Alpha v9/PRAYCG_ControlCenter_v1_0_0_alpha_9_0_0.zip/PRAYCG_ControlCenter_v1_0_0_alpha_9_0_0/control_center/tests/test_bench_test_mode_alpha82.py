from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = PACKAGE_ROOT / "control_center" / "scripts"
CONTROL_CENTER_PATH = SCRIPT_DIR / "praycg_control_center_v1_0_0_alpha_8.py"


def load_control_center():
    sys.path.insert(0, str(SCRIPT_DIR))
    module_name = "praycg_control_center_bench_test"
    spec = importlib.util.spec_from_file_location(module_name, CONTROL_CENTER_PATH)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def contact_only_payload() -> dict:
    return {
        "schema": "PRAYCG_Acquisition_Preflight_v1_0",
        "binding_status": "BOUND",
        "status": "FAIL",
        "fail_reasons": [
            "more than 25% of EEG channels have flat/noise/saturation/missingness flags"
        ],
        "eeg": {
            "stream": {
                "source_id": "praycg-eeg-runa",
                "resolved_candidate_count": 1,
                "error": "",
            },
            "timing": {
                "sample_count": 3750,
                "effective_rate_hz": 125.0,
                "monotonic_violations": 0,
                "duplicate_timestamps": 0,
                "large_gap_count": 0,
            },
            "expected_rate_hz": 125.0,
            "rate_error_fraction": 0.0,
        },
    }


class BenchTestModeAlpha82Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.control = load_control_center()
        cls.source = CONTROL_CENTER_PATH.read_text(encoding="utf-8")

    def test_contact_only_failure_can_be_waived(self) -> None:
        allowed, detail = self.control.bench_eeg_quality_waiver(contact_only_payload())
        self.assertTrue(allowed)
        self.assertIn("transport and identity passed", detail)

    def test_transport_or_identity_failures_cannot_be_waived(self) -> None:
        cases = []
        for key, value in (
            ("resolved_candidate_count", 2),
            ("source_id", ""),
        ):
            payload = contact_only_payload()
            payload["eeg"]["stream"][key] = value
            cases.append(payload)
        for key, value in (
            ("sample_count", 0),
            ("monotonic_violations", 1),
            ("duplicate_timestamps", 1),
            ("large_gap_count", 1),
        ):
            payload = contact_only_payload()
            payload["eeg"]["timing"][key] = value
            cases.append(payload)
        for payload in cases:
            self.assertFalse(self.control.bench_eeg_quality_waiver(payload)[0])

    def test_non_quality_failure_cannot_be_waived(self) -> None:
        payload = contact_only_payload()
        payload["fail_reasons"].append("EEG stream missing")
        self.assertFalse(self.control.bench_eeg_quality_waiver(payload)[0])

    def test_malformed_or_out_of_tolerance_evidence_cannot_be_waived(self) -> None:
        mutations = (
            ("fail_reasons", None),
            ("rate_error_fraction", float("nan")),
            ("rate_error_fraction", float("inf")),
            ("rate_error_fraction", -0.01),
            ("rate_error_fraction", 0.051),
        )
        for key, value in mutations:
            payload = contact_only_payload()
            if key == "fail_reasons":
                payload[key] = value
            else:
                payload["eeg"][key] = value
            self.assertFalse(self.control.bench_eeg_quality_waiver(payload)[0], key)

        payload = contact_only_payload()
        payload["eeg"]["timing"]["sample_count"] = "unreadable"
        self.assertFalse(self.control.bench_eeg_quality_waiver(payload)[0])

    def test_missing_inconsistent_or_too_short_transport_evidence_cannot_be_waived(self) -> None:
        omissions = (
            ("stream", "resolved_candidate_count"),
            ("timing", "sample_count"),
            ("timing", "effective_rate_hz"),
            ("timing", "monotonic_violations"),
            ("timing", "duplicate_timestamps"),
            ("timing", "large_gap_count"),
            ("eeg", "expected_rate_hz"),
            ("eeg", "rate_error_fraction"),
        )
        for section, key in omissions:
            payload = contact_only_payload()
            target = payload["eeg"] if section == "eeg" else payload["eeg"][section]
            target.pop(key)
            self.assertFalse(self.control.bench_eeg_quality_waiver(payload)[0], f"{section}.{key}")

        payload = contact_only_payload()
        payload["eeg"]["rate_error_fraction"] = 0.01
        self.assertFalse(self.control.bench_eeg_quality_waiver(payload)[0])

        payload = contact_only_payload()
        payload["eeg"]["timing"]["sample_count"] = 624
        self.assertFalse(self.control.bench_eeg_quality_waiver(payload)[0])

    def test_report_must_match_current_profile_and_run(self) -> None:
        payload = contact_only_payload()
        payload["hardware_profile_sha256"] = "profile-a"
        payload["run_uuid"] = "run-a"
        app = SimpleNamespace(
            cfg={"acquisition": {"bench_test_mode": True}},
            active_hardware_profile={"canonical_sha256": "profile-a"},
            active_run_uuid="run-a",
        )
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "detailed.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            method = self.control.PRAYCGControlCenter.bench_eeg_quality_waiver_status
            self.assertTrue(method(app, path)[0])

            app.active_run_uuid = "run-b"
            self.assertFalse(method(app, path)[0])
            app.active_run_uuid = "run-a"
            app.active_hardware_profile = {"canonical_sha256": "profile-b"}
            self.assertFalse(method(app, path)[0])

            app.active_hardware_profile = {"canonical_sha256": "profile-a"}
            payload["eeg"]["stream"]["source_id"] = "praycg-eeg-other-run"
            path.write_text(json.dumps(payload), encoding="utf-8")
            self.assertFalse(method(app, path)[0])

    def test_stale_als_report_cannot_be_promoted_back_to_pass(self) -> None:
        app = SimpleNamespace(
            active_hardware_profile={"canonical_sha256": "profile-a"},
            active_run_uuid="run-a",
        )
        status_method = self.control.PRAYCGControlCenter.acquisition_report_status
        app.acquisition_report_status = lambda path, not_before=0.0: status_method(app, path, not_before)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "als.json"
            path.write_text(json.dumps({
                "schema": "PRAYCG_ALS_Barcode_Live_Test_v0_7",
                "status": "PASS",
                "hardware_profile_sha256": "profile-a",
                "run_uuid": "run-a",
            }), encoding="utf-8")
            old = time.time() - 60.0
            os.utime(path, (old, old))
            result = self.control.PRAYCGControlCenter.als_barcode_report_status(app, path, time.time())
            self.assertEqual(result[0], "STALE")

    def test_mode_change_disarms_existing_lock_and_clears_reserved_pseudonym(self) -> None:
        class ToggleVar:
            def __init__(self, value: bool):
                self.value = value

            def get(self):
                return self.value

            def set(self, value):
                self.value = bool(value)

        with tempfile.TemporaryDirectory() as directory:
            lock_path = Path(directory) / "runtime_session_lock.json"
            lock_path.write_text(json.dumps({"lock_identity_sha256": "locked-bench-identity"}), encoding="utf-8")
            acquisition = {
                "bench_test_mode": True,
                "bench_test_reason": "cap intentionally off",
                "bench_eeg_quality_waiver_active": True,
                "session_stage": "ARM",
                "session_lock_path": str(lock_path),
                "participant_pseudonym": "BENCH-RUNA",
            }
            app = SimpleNamespace(
                cfg={"acquisition": acquisition},
                bench_test_mode_var=ToggleVar(False),
                save_config=lambda: None,
                write_acquisition_state=lambda: None,
                refresh_acquisition_readiness=lambda: "CAUTION",
            )
            self.control.PRAYCGControlCenter.toggle_bench_test_mode(app)
            self.assertEqual(acquisition["disarmed_lock_identity"], "locked-bench-identity")
            self.assertEqual(acquisition["participant_pseudonym"], "")
            self.assertFalse(acquisition["bench_test_mode"])
            self.assertFalse(acquisition["armed"])
            self.assertEqual(acquisition["session_stage"], "SELECT")

    def test_locked_session_classification_is_validated_in_both_directions(self) -> None:
        participant = {
            "bench_test_mode": False,
            "session_purpose": "PARTICIPANT_ACQUISITION",
            "participant_data_eligible": True,
            "participant_pseudonym": "P001",
            "bench_test_reason": "",
            "bench_eeg_quality_waiver_active": False,
            "bench_readiness_bypass_active": False,
        }
        bench = {
            "bench_test_mode": True,
            "session_purpose": "BENCH_TEST",
            "participant_data_eligible": False,
            "participant_pseudonym": "BENCH-RUNA",
            "bench_test_reason": "cap intentionally not worn",
            "bench_eeg_quality_waiver_active": True,
            "bench_readiness_bypass_active": True,
        }
        self.assertTrue(self.control.locked_session_classification_status(participant)[0])
        self.assertTrue(self.control.locked_session_classification_status(bench)[0])

        for key, value in (
            ("session_purpose", "BENCH_TEST"),
            ("participant_data_eligible", False),
            ("participant_pseudonym", "BENCH-RUNA"),
            ("bench_test_reason", "leftover bench reason"),
            ("bench_eeg_quality_waiver_active", True),
            ("bench_readiness_bypass_active", True),
        ):
            malformed = dict(participant)
            malformed[key] = value
            self.assertFalse(self.control.locked_session_classification_status(malformed)[0], key)

        for key, value in (
            ("session_purpose", "PARTICIPANT_ACQUISITION"),
            ("participant_data_eligible", True),
            ("participant_pseudonym", "P001"),
            ("bench_test_reason", ""),
            ("bench_readiness_bypass_active", False),
        ):
            malformed = dict(bench)
            malformed[key] = value
            self.assertFalse(self.control.locked_session_classification_status(malformed)[0], key)

    def readiness_app(self, *, bench_mode: bool, waiver_allowed: bool, profile_status: str = "PASS"):
        acquisition = {
            "bench_test_mode": bench_mode,
            "preflight_started_epoch": 0.0,
            "profile_preflight_report_path": "profile.json",
            "detailed_preflight_dir": ".",
            "als_test_dir": ".",
            "armed": False,
            "session_stage": "SELECT",
        }
        app = SimpleNamespace(
            cfg={"acquisition": acquisition, "log_root": ".", "praycg_home": "."},
            active_hardware_profile={"status": "APPROVED", "canonical_sha256": "profile-a"},
            active_run_uuid="run-a",
            locked_protocol={"protocol_id": "TEST"},
        )
        app.newest_json = lambda _folder, _pattern: Path("detailed.json")
        app.profile_preflight_status = lambda _path, _started: (profile_status, "profile.json")
        app.detailed_preflight_report_status = lambda _path, _started: ("FAIL", "detailed.json")
        app.als_barcode_report_status = lambda _path, _started: ("NOT_RUN", "no report")
        app.bench_eeg_quality_waiver_status = lambda _path: (waiver_allowed, "test decision")
        app.active_hardware_roles = lambda: {"eeg"}
        app.hardware_profile_approved = lambda _profile: True
        app.platform_core_available = lambda: False
        app.demo_only_stimulus_reason = lambda: ""
        app.refresh_protocol_lock_status = lambda **_kwargs: None
        app.validate_active_session_lock = lambda: ("NOT_LOCKED", "test")
        app.write_acquisition_state = lambda: None
        return app

    def test_normal_participant_failure_remains_ineligible(self) -> None:
        app = self.readiness_app(bench_mode=False, waiver_allowed=True)
        status = self.control.PRAYCGControlCenter.refresh_acquisition_readiness(app)
        self.assertEqual(status, "INELIGIBLE")
        self.assertFalse(app.cfg["acquisition"]["bench_eeg_quality_waiver_active"])

    def test_bench_contact_only_failure_becomes_audited_bypass_caution(self) -> None:
        app = self.readiness_app(bench_mode=True, waiver_allowed=True)
        status = self.control.PRAYCGControlCenter.refresh_acquisition_readiness(app)
        self.assertEqual(status, "CAUTION")
        self.assertFalse(app.cfg["acquisition"]["bench_eeg_quality_waiver_active"])
        self.assertTrue(app.cfg["acquisition"]["bench_readiness_bypass_active"])
        self.assertIn("outputs are never participant data", app.cfg["acquisition"]["readiness_message"])

    def test_bench_mode_bypasses_nonwaivable_and_stale_live_checks(self) -> None:
        app = self.readiness_app(bench_mode=True, waiver_allowed=False)
        self.assertEqual(
            self.control.PRAYCGControlCenter.refresh_acquisition_readiness(app),
            "CAUTION",
        )
        stale = self.readiness_app(bench_mode=True, waiver_allowed=True, profile_status="STALE")
        self.assertEqual(
            self.control.PRAYCGControlCenter.refresh_acquisition_readiness(stale),
            "CAUTION",
        )
        self.assertIn("recorded bypassed findings", stale.cfg["acquisition"]["readiness_message"])

    def test_bench_sessions_are_labeled_non_participant(self) -> None:
        self.assertIn('"session_purpose": "BENCH_TEST" if bench_mode else "PARTICIPANT_ACQUISITION"', self.source)
        self.assertIn('"participant_data_eligible": not bench_mode', self.source)
        self.assertIn('participant = f"BENCH-', self.source)
        self.assertIn('"PRAYCG_BENCH_TEST_MODE"', self.source)


if __name__ == "__main__":
    unittest.main()
