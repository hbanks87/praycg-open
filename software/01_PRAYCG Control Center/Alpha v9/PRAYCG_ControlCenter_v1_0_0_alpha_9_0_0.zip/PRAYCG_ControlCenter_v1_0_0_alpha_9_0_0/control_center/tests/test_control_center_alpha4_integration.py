"""Focused integration checks for the alpha.4 Control Center shell."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


PACKAGE = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE / "control_center" / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import praycg_control_center_v1_0_0_alpha_4 as cc  # noqa: E402


class _Dummy:
    pass


class Alpha4ControlCenterIntegrationTests(unittest.TestCase):
    def test_release_identity_and_new_entry_points(self) -> None:
        self.assertEqual(cc.APP_VERSION, "1.0.0-alpha.4")
        self.assertEqual(cc.CONFIG_SCHEMA, "PRAYCG_ControlCenter_Config_v1_0_alpha_4")
        self.assertEqual(cc.PLATFORM_CORE_IMPORT_ERROR, "")
        self.assertEqual(cc.STIMULUS_CONTRACT_IMPORT_ERROR, "")
        defaults = cc.default_config()
        self.assertIn("stimulus_pack_install_root", defaults)
        self.assertIn("generic_eda_ppg_driver_profile_path", defaults["acquisition"])
        for name in (
            "launch_stimulus_library",
            "launch_stimulus_forge",
            "launch_hardware_forge",
            "launch_generic_eda_ppg_profile_wizard",
            "launch_generic_eda_ppg_simulator",
            "launch_generic_eda_ppg",
            "launch_analysis_module_catalog",
        ):
            self.assertTrue(callable(getattr(cc.PRAYCGControlCenter, name, None)), name)

    def test_mixed_legacy_and_pack_registry_is_preserved_in_ui_model(self) -> None:
        dummy = _Dummy()
        dummy.read_registry = lambda: {
            "schema": "PRAYCG_StimulusRegistry_v1_0",
            "stimuli": [
                {"stimulus_id": "LEGACY_MASTER", "folder": "C:/legacy", "pinned": False},
            ],
            "packs": [
                {
                    "pack_id": "DEMO_PACK",
                    "path": "C:/packs/demo",
                    "scientific_status": "DEMO_ONLY",
                    "validation_status": "PASS",
                    "active_for_selection": True,
                },
            ],
        }
        rows = cc.PRAYCGControlCenter.stimulus_registry_items(dummy)
        self.assertEqual({row["stimulus_id"] for row in rows}, {"LEGACY_MASTER", "DEMO_PACK"})
        indexed = {row["stimulus_id"]: row for row in rows}
        self.assertEqual(indexed["LEGACY_MASTER"]["registry_kind"], "legacy_master")
        self.assertEqual(indexed["DEMO_PACK"]["registry_kind"], "stimulus_pack")
        self.assertTrue(indexed["DEMO_PACK"]["active_for_selection"])

    def test_native_pack_exact_bindings_populate_praycg4(self) -> None:
        pack = (
            PACKAGE / "examples" / "no_copyright_media_demo" / "stimulus_library"
            / "packs" / "PRAYCG_NATIVE_STORY_DEMO_V1"
        )
        dummy = _Dummy()
        dummy.cfg = {"selected_protocol_id": "PRAYCG4"}
        dummy.protocol_select_var = object()
        dummy.selected_protocol_record = lambda: {"protocol_id": "PRAYCG4"}
        report = cc.PRAYCGControlCenter.detect_stimulus_files(dummy, pack)
        self.assertNotIn("stimulus_pack_error", report)
        self.assertEqual(report["stimulus_pack_validation"]["status"], "PASS")
        expected_names = {
            "control_video": "phase_scrambled.mp4",
            "shot_order_video": "shot_order_scramble.mp4",
            "target_video": "target_with_cues.mp4",
            "override_video": "target_with_cues.mp4",
            "cue_schedule_json": "cue_schedule.json",
            "shot_order_manifest": "shot_order_manifest.json",
        }
        for key, expected in expected_names.items():
            self.assertEqual(Path(report["files"][key][0]).name, expected, key)

    def test_pack_binding_fails_closed_after_manifest_tamper(self) -> None:
        source = (
            PACKAGE / "examples" / "no_copyright_media_demo" / "stimulus_library"
            / "packs" / "PRAYCG_ATLAS_GENERATED_VISUALS_DEMO_V1"
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / source.name
            # This small pack is copied using ordinary library operations so the
            # test exercises the same relative-path and ledger checks as selection.
            import shutil
            shutil.copytree(source, root)
            manifest_path = root / "stimulus_pack_manifest.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest["display_name"] = "tampered after registry scan"
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
            dummy = _Dummy()
            dummy.cfg = {"selected_protocol_id": "ATLAS_ERP_CORE_P3B_ADAPTATION"}
            dummy.protocol_select_var = object()
            dummy.selected_protocol_record = lambda: {"protocol_id": "ATLAS_ERP_CORE_P3B_ADAPTATION"}
            report = cc.PRAYCGControlCenter.detect_stimulus_files(dummy, root)
            self.assertIn("stimulus_pack_error", report)
            self.assertEqual(report["stimulus_pack_validation"]["status"], "FAIL")

    def test_unvalidated_legacy_generic_module_is_not_selectable(self) -> None:
        self.assertFalse((PACKAGE / "config" / "hardware" / "Generic_EDA_PPG_v0_1.json").exists())

    def test_inactive_stimulus_pack_cannot_resolve_as_session_input(self) -> None:
        dummy = _Dummy()
        dummy.selected_stimulus_id = "INACTIVE_PACK"
        dummy.cfg = {"stimulus_root": "C:/legacy"}
        dummy.stimulus_registry_items = lambda: [{
            "stimulus_id": "INACTIVE_PACK",
            "registry_kind": "stimulus_pack",
            "folder": "C:/packs/inactive",
            "active_for_selection": False,
        }]

        folder = cc.PRAYCGControlCenter.selected_stimulus_folder(dummy)

        self.assertIsNone(folder)

    def test_demo_only_pack_is_a_hard_participant_acquisition_boundary(self) -> None:
        dummy = _Dummy()
        dummy.active_context = {
            "stimulus": {
                "scientific_status": "DEMO_ONLY",
                "collection_boundary": "DEMO_ONLY_NOT_VALID_FOR_SCIENTIFIC_COLLECTION",
            }
        }
        reason = cc.PRAYCGControlCenter.demo_only_stimulus_reason(dummy)
        self.assertIn("cannot be armed", reason)
        dummy.demo_only_stimulus_reason = lambda: reason
        dummy.selected_stimulus_id = None
        dummy.selected_stimulus_folder = lambda: None
        dummy.resolve_protocol_media_snapshot = lambda _validated: ({"selections": {}}, [])
        errors = cc.PRAYCGControlCenter.validate_current_stimulus_against_lock(
            dummy,
            {"session": {}},
            {"record": {"module_family": "UNRECOGNIZED_TEST_FAMILY"}},
        )
        self.assertIn(reason, errors)

    def test_nested_atlas_asset_folder_inherits_demo_only_boundary(self) -> None:
        pack = (
            PACKAGE / "examples" / "no_copyright_media_demo" / "stimulus_library"
            / "packs" / "PRAYCG_ATLAS_EVENT_VIDEO_DEMO_V1"
        )
        dummy = _Dummy()
        dummy.active_context = {"stimulus": {}}
        dummy.selected_stimulus_folder = lambda: None
        dummy.selected_protocol_record = lambda: {
            "protocol_id": "ATLAS_EEG_MOMENTS_CLIPS_ADAPTATION",
            "module_family": cc.FAMILY_ATLAS,
        }
        dummy.cfg = {
            "protocol_asset_folders": {
                "ATLAS_EEG_MOMENTS_CLIPS_ADAPTATION": str(pack / "emd_assets")
            }
        }
        dummy.stimulus_pack_status_for_path = lambda path: cc.PRAYCGControlCenter.stimulus_pack_status_for_path(dummy, path)
        reason = cc.PRAYCGControlCenter.demo_only_stimulus_reason(dummy)
        self.assertIn("DEMO_ONLY", reason)

    def test_generic_physical_launch_rejects_unvalidated_loaded_profile(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            profile_path = Path(temporary) / "forged_profile.json"
            profile = {
                "schema": "PRAYCG_HardwareProfile_v1_0_alpha_2",
                "status": "APPROVED",
                "reviewed_by": "Reviewer",
                "modules": [{
                    "module_id": "generic_eda_ppg_udp",
                    "admission_state": "HUMAN_CONNECTED_APPROVED",
                    "physical_validation": "HUMAN_CONNECTED",
                    "driver_profile_sha256": "0" * 64,
                    "streams": [],
                }],
            }
            profile_path.write_text(json.dumps(profile), encoding="utf-8")
            dummy = _Dummy()
            dummy.active_hardware_profile = profile
            dummy.cfg = {"acquisition": {"hardware_profile_path": str(profile_path)}}
            dummy.platform_core_available = lambda: True
            dummy.hardware_profile_approved = cc.PRAYCGControlCenter.hardware_profile_approved
            dummy.begin_acquisition_session = mock.Mock(side_effect=AssertionError("invalid profile reached session creation"))
            dummy.launch_python_or_exe = mock.Mock(side_effect=AssertionError("invalid profile reached bridge launch"))
            with mock.patch.object(cc.messagebox, "showerror") as showerror:
                cc.PRAYCGControlCenter.launch_generic_eda_ppg(dummy)
            self.assertTrue(showerror.called)
            dummy.begin_acquisition_session.assert_not_called()
            dummy.launch_python_or_exe.assert_not_called()

    def test_demo_gate_uses_locked_atlas_protocol_after_combo_changes(self) -> None:
        pack = (
            PACKAGE / "examples" / "no_copyright_media_demo" / "stimulus_library"
            / "packs" / "PRAYCG_ATLAS_EVENT_VIDEO_DEMO_V1"
        )
        locked_protocol_id = "ATLAS_EEG_MOMENTS_CLIPS_ADAPTATION"
        highlighted_protocol_id = "ATLAS_MIPDB_EYES_CLOSED_REST_ADAPTATION"
        dummy = _Dummy()
        dummy.active_context = {"stimulus": {}}
        dummy.selected_stimulus_folder = lambda: None
        dummy.locked_protocol = {
            "protocol_id": locked_protocol_id,
            "module_family": cc.FAMILY_ATLAS,
            "record": {
                "protocol_id": locked_protocol_id,
                "module_family": cc.FAMILY_ATLAS,
            },
        }
        dummy.selected_protocol_record = lambda: {
            "protocol_id": highlighted_protocol_id,
            "module_family": cc.FAMILY_ATLAS,
        }
        dummy.cfg = {
            "protocol_asset_folders": {
                locked_protocol_id: str(pack / "emd_assets"),
            }
        }
        dummy.stimulus_pack_status_for_path = (
            lambda path: cc.PRAYCGControlCenter.stimulus_pack_status_for_path(dummy, path)
        )

        reason = cc.PRAYCGControlCenter.demo_only_stimulus_reason(dummy)

        self.assertIn("DEMO_ONLY", reason)


if __name__ == "__main__":
    unittest.main()
