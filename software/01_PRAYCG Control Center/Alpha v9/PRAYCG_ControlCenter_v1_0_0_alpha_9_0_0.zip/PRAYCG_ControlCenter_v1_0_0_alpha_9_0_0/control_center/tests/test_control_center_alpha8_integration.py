import ast
import json
import unittest
from pathlib import Path


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
CONTROL_CENTER = PACKAGE_ROOT / "control_center" / "scripts" / "praycg_control_center_v1_0_0_alpha_8.py"


class ControlCenterAlpha7IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = CONTROL_CENTER.read_text(encoding="utf-8")
        cls.tree = ast.parse(cls.source)

    def test_release_identity_and_exact_tabs(self):
        self.assertIn('APP_VERSION = "1.0.0-alpha.8.5.4"', self.source)
        for label in (
            "Home", "Choose Protocol", "Prepare Materials", "Connect & Check Equipment",
            "Run Session", "Review Results", "Settings",
        ):
            self.assertIn(f'text="{label}"', self.source)

    def test_workspace_lifecycle_and_no_run_everything(self):
        for name in (
            "create_study_workspace_ui", "sync_workspace_from_current_state",
            "refresh_analysis_orchestration_ui", "lock_analysis_plan_ui",
            "build_local_results_bundle_ui", "review_latest_results_bundle_ui",
        ):
            self.assertIn(f"def {name}", self.source)
        self.assertNotIn('text="Run Everything"', self.source)
        registry = json.loads((PACKAGE_ROOT / "config" / "analysis_orchestration_registry_v0_1.json").read_text())
        self.assertEqual(registry["network_execution"], "DISABLED")
        self.assertEqual(registry["primary_authority"], "NONE_BY_REGISTRATION")


if __name__ == "__main__":
    unittest.main()
