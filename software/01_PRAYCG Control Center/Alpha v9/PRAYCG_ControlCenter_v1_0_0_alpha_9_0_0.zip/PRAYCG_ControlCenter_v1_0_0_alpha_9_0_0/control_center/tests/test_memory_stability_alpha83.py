from __future__ import annotations

from pathlib import Path
import unittest


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
CONTROL_CENTER_PATH = PACKAGE_ROOT / "control_center" / "scripts" / "praycg_control_center_v1_0_0_alpha_8.py"
MONITOR_PATH = PACKAGE_ROOT / "control_center" / "scripts" / "praycg_live_stream_monitor_v1_0.py"
VALIDATOR_PATH = PACKAGE_ROOT / "tools" / "Release_Validation_v0_1" / "praycg_release_validator_v0_1.py"


class MemoryStabilityAlpha83Tests(unittest.TestCase):
    def test_control_center_bounds_long_lived_ui_state(self) -> None:
        source = CONTROL_CENTER_PATH.read_text(encoding="utf-8")
        self.assertIn("MAX_CONTROL_CENTER_LOG_LINES = 2000", source)
        self.assertIn("MAX_CONTROL_CENTER_LOG_CHARS = 250000", source)
        self.assertIn("MAX_EXITED_PROCESS_ROWS = 40", source)
        self.assertIn("line_count > self.max_lines", source)
        self.assertIn("char_count > self.max_chars", source)
        self.assertIn("_prune_exited_process_history", source)
        self.assertIn("signature == self._process_tree_signature", source)

    def test_recurring_callbacks_are_cancelled_on_close(self) -> None:
        source = CONTROL_CENTER_PATH.read_text(encoding="utf-8")
        self.assertIn('self.protocol("WM_DELETE_WINDOW", self.close_app)', source)
        self.assertIn("self.after_cancel(callback_id)", source)
        self.assertIn("if self._closing:", source)

    def test_monitor_bounds_queue_and_reuses_channel_rows(self) -> None:
        source = MONITOR_PATH.read_text(encoding="utf-8")
        self.assertIn("queue.Queue(maxsize=", source)
        self.assertIn("self.channel_tree.item(item_id, values=values)", source)
        self.assertIn("self.root.after_cancel(self._drain_after_id)", source)

    def test_release_validation_is_strictly_sequential(self) -> None:
        source = VALIDATOR_PATH.read_text(encoding="utf-8")
        self.assertIn('VALIDATION_EXECUTION_MODE = "sequential"', source)
        self.assertNotIn("ThreadPoolExecutor", source)
        self.assertIn("shard_results = [run_shard(shard_spec) for shard_spec in shard_specs]", source)
        self.assertIn("results = [run_declared_test_suite(suite, package) for suite in suites]", source)
        self.assertIn("workers=1", source)
        self.assertIn("CREATE_NEW_PROCESS_GROUP", source)
        self.assertIn("CREATE_NO_WINDOW", source)


if __name__ == "__main__":
    unittest.main()
