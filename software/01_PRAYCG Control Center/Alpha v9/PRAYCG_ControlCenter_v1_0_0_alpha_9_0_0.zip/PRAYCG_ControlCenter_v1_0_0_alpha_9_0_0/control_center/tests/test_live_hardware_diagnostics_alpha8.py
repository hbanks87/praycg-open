from __future__ import annotations

import importlib.util
import math
import sys
import unittest
from pathlib import Path


PACKAGE = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE / "control_center" / "scripts"
sys.path.insert(0, str(SCRIPTS))


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, SCRIPTS / filename)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


monitor = load_module("alpha8_live_monitor", "praycg_live_stream_monitor_v1_0.py")
barcode = load_module("alpha8_als_barcode", "praycg_als_barcode_live_test_v0_7.py")


class FakeDescription:
    def __init__(self, values):
        self.values = values

    def child_value(self, key):
        return self.values.get(key, "")


class FakeInfo:
    def __init__(self, name: str, source_id: str, run_uuid: str):
        self._name = name
        self._source_id = source_id
        self._description = FakeDescription({"run_uuid": run_uuid})

    def name(self):
        return self._name

    def source_id(self):
        return self._source_id

    def desc(self):
        return self._description


class LiveHardwareDiagnosticsAlpha8Tests(unittest.TestCase):
    def test_dynamic_stream_selection_prefers_exact_active_session(self) -> None:
        active = "11111111-1111-4111-8111-111111111111"
        old = FakeInfo("ALS_PT19_Timing", "praycg_old_als", "22222222-2222-4222-8222-222222222222")
        current = FakeInfo("ALS_PT19_Timing", "praycg_current_als", active)
        selected, status, identities = monitor.choose_stream_candidate(
            [old, current], {"source_id_policy": "dynamic_run_bound"}, active
        )
        self.assertIs(selected, current)
        self.assertEqual(status, "CURRENT SESSION")
        self.assertEqual(len(identities), 2)

    def test_outside_bridge_is_visible_but_cannot_satisfy_session_binding(self) -> None:
        active = "11111111-1111-4111-8111-111111111111"
        outside = FakeInfo("ALS_PT19_Timing", "praycg_outside_als", "22222222-2222-4222-8222-222222222222")
        selected, status, _identities = monitor.choose_stream_candidate(
            [outside], {"source_id_policy": "dynamic_run_bound"}, active
        )
        self.assertIsNone(selected)
        self.assertIn("WRONG SESSION", status)
        selected_barcode, barcode_status, _ = barcode.select_run_bound_stream([outside], active)
        self.assertIsNone(selected_barcode)
        self.assertEqual(barcode_status, "WRONG_SESSION")

    def test_barcode_recovers_current_binding_from_packaged_source_id(self) -> None:
        active = "32d2b59e-978a-4748-b070-d4746b133c8c"
        outlet = FakeInfo(
            "ALS_PT19_Timing",
            "praycg_obci_brainflow_als_v1_5_cyton-daisy_32d2b59e978a_als",
            "",
        )
        selected, status, identities = barcode.select_run_bound_stream([outlet], active)
        self.assertIs(selected, outlet)
        self.assertEqual(status, "CURRENT_SESSION")
        self.assertEqual(identities[0]["run_uuid_fragment"], "32d2b59e978a")

    def test_barcode_accepts_both_sensor_polarities(self) -> None:
        design = {"black_pre": 0.5, "white_a": 2.0, "black_gap": 0.5, "white_b": 0.75, "black_post": 1.0}
        start = 1000.0

        def samples(white_value: float, black_value: float):
            rows = []
            total = sum(design.values())
            for index in range(int(total * 100)):
                elapsed = index / 100.0
                white = 0.5 <= elapsed < 2.5 or 3.0 <= elapsed < 3.75
                rows.append((start + elapsed, white_value if white else black_value))
            return rows

        positive = barcode.classify_samples(samples(10.0, 0.0), design, start)
        negative = barcode.classify_samples(samples(0.0, 10.0), design, start)
        self.assertEqual(positive["status"], "PASS")
        self.assertEqual(positive["observed_polarity"], "higher_on_white")
        self.assertEqual(negative["status"], "PASS")
        self.assertEqual(negative["observed_polarity"], "lower_on_white")

    def test_role_specific_live_readouts_are_operator_friendly(self) -> None:
        rr = monitor.summarize_stream(
            "rr_intervals", [[800.0], [820.0], [790.0], [810.0]], [1.0, 1.8, 2.62, 3.41],
            ["RR_interval"], ["milliseconds"], 0.0,
        )
        self.assertIn("BPM", rr["primary"])
        self.assertIn("RMSSD", rr["primary"])
        force = monitor.summarize_stream(
            "respiration", [[4.1], [4.5]], [1.0, 1.1], ["force_N"], ["newton"], 10.0,
        )
        self.assertIn("newtons", force["primary"])
        light = monitor.summarize_stream(
            "als", [[1.0], [3.0], [2.0]], [1.0, 1.01, 1.02], ["ALS"], ["raw"], 125.0,
        )
        self.assertIn("relative photonic load", light["primary"])
        self.assertIn("raw 2.000", light["primary"])

    def test_eeg_readout_reports_actual_rate_and_channel_quality(self) -> None:
        timestamps = [index / 125.0 for index in range(250)]
        samples = [
            [30.0 * math.sin(index / 7.0), 25.0 * math.cos(index / 9.0)]
            for index in range(250)
        ]
        result = monitor.summarize_stream(
            "eeg", samples, timestamps, ["F3", "F4"], ["microvolts", "microvolts"], 125.0
        )
        self.assertIn("125.0 Hz actual", result["primary"])
        self.assertIn("rolling quality", result["primary"])
        self.assertEqual(len(result["channel_rows"]), 2)
        self.assertTrue(all(row["quality"] is not None for row in result["channel_rows"]))

    def test_control_center_wires_visible_session_and_preflight_feedback(self) -> None:
        source = (SCRIPTS / "praycg_control_center_v1_0_0_alpha_8.py").read_text(encoding="utf-8")
        for required in (
            "Start New Equipment Session",
            "ACTIVE SESSION —",
            "Open Live Stream Monitor",
            "show_profile_preflight_progress_window",
            "Observe Stream Stability for 30 Seconds",
            "Open Confirmed Session Setup",
        ):
            self.assertIn(required, source)
        self.assertIn('lsl.get("als_channel_index_1based", 1)', source)


if __name__ == "__main__":
    unittest.main()
