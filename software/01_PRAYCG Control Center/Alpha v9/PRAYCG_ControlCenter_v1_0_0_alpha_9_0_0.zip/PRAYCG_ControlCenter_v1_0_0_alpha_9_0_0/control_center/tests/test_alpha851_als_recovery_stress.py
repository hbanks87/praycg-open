from __future__ import annotations

import importlib.util
import itertools
import contextlib
import io
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import MethodType, SimpleNamespace
from unittest import mock


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
CONTROL_PATH = SCRIPTS / "praycg_control_center_v1_0_0_alpha_8.py"
BARCODE_PATH = SCRIPTS / "praycg_als_barcode_live_test_v0_7.py"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


control = load_module("praycg_alpha851_recovery_stress_control", CONTROL_PATH)
barcode = load_module("praycg_alpha851_recovery_stress_barcode", BARCODE_PATH)

RUN = "11111111-1111-4111-8111-111111111111"
OLD = "22222222-2222-4222-8222-222222222222"
ALS_SCRIPT = control.OPENBCI_ALS_BRIDGE_SCRIPT_NAME
EEG_SCRIPT = "praycg_openbci_brainflow_eeg_to_lsl_v1_1.py"


def bridge(pid: int, script: str = ALS_SCRIPT, run_uuid: str = OLD, port: str = "COM3") -> dict:
    return {
        "pid": pid,
        "script_name": script,
        "run_uuid": run_uuid,
        "serial_port": port,
        "command_line": f"python.exe {script} --serial-port {port} --run-uuid {run_uuid}",
    }


class Sink:
    def __init__(self) -> None:
        self.value = ""

    def set(self, value) -> None:
        self.value = str(value)


class Alpha851ALSRecoveryStressTests(unittest.TestCase):
    def test_planner_exhaustive_classification_is_order_independent(self) -> None:
        cases = [
            ([], "START_ALS"),
            ([bridge(1, run_uuid=RUN)], "REUSE_CURRENT_ALS"),
            ([bridge(1)], "REPLACE_WITH_ALS"),
            ([bridge(1, script=EEG_SCRIPT, run_uuid=RUN)], "REPLACE_WITH_ALS"),
            ([bridge(1, port="COM3"), bridge(2, port="COM4")], "BLOCK_AMBIGUOUS"),
            ([bridge(1, run_uuid=RUN), bridge(2, script=EEG_SCRIPT, run_uuid=RUN)], "BLOCK_DUPLICATE"),
            ([bridge(1, port="")], "BLOCK_AMBIGUOUS"),
        ]
        for rows, expected in cases:
            permutations = itertools.permutations(rows) if rows else [()]
            for ordered in permutations:
                decision = control.plan_als_barcode_bridge(list(ordered), RUN)
                self.assertEqual(decision["action"], expected)

    def test_stale_bridge_is_stopped_and_restarted_on_same_port(self) -> None:
        stale = bridge(24244)
        stopped = []
        launched = []
        app = SimpleNamespace(
            active_run_uuid=RUN,
            cfg={
                "tools": {"brainflow_eeg_als": str(CONTROL_PATH)},
                "acquisition": {"session_artifact_root": tempfile.gettempdir()},
                "log_root": tempfile.gettempdir(),
                "praycg_home": tempfile.gettempdir(),
            },
            hardware_launch_status_var=Sink(),
            log=lambda _message: None,
            save_config=lambda: None,
        )
        app.launch_brainflow_eeg_als_on_port = lambda port, run_uuid, **_kwargs: launched.append((port, run_uuid)) or True
        method = MethodType(control.PRAYCGControlCenter.prepare_als_barcode_bridge, app)
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[stale]),
            mock.patch.object(control, "stop_external_openbci_bridge", side_effect=lambda row: (stopped.append(row["pid"]) or True, "stopped")),
            mock.patch.object(control.messagebox, "askyesno", return_value=True),
        ):
            self.assertTrue(method())
        self.assertEqual(stopped, [24244])
        self.assertEqual(launched, [("COM3", RUN)])

    def test_stop_failure_fails_closed_without_replacement(self) -> None:
        stale = bridge(24244)
        launched = []
        app = SimpleNamespace(
            active_run_uuid=RUN,
            cfg={"acquisition": {}, "log_root": tempfile.gettempdir()},
            hardware_launch_status_var=Sink(),
            log=lambda _message: None,
        )
        app.launch_brainflow_eeg_als_on_port = lambda *_args, **_kwargs: launched.append(True) or True
        method = MethodType(control.PRAYCGControlCenter.prepare_als_barcode_bridge, app)
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[stale]),
            mock.patch.object(control, "stop_external_openbci_bridge", return_value=(False, "identity changed")),
            mock.patch.object(control.messagebox, "askyesno", return_value=True),
            mock.patch.object(control.messagebox, "showerror"),
        ):
            self.assertFalse(method())
        self.assertFalse(launched)
        self.assertIn("failed closed", app.hardware_launch_status_var.value)

    def test_current_session_als_is_reused_without_mutation(self) -> None:
        current = bridge(os.getpid() + 1000, run_uuid=RUN)
        app = SimpleNamespace(active_run_uuid=RUN, hardware_launch_status_var=Sink())
        method = MethodType(control.PRAYCGControlCenter.prepare_als_barcode_bridge, app)
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[current]),
            mock.patch.object(control, "stop_external_openbci_bridge") as stop,
            mock.patch.object(control.messagebox, "askyesno") as prompt,
        ):
            self.assertTrue(method())
        stop.assert_not_called()
        prompt.assert_not_called()
        self.assertIn("reusing", app.hardware_launch_status_var.value)

    def test_ambiguous_ports_stop_nothing(self) -> None:
        rows = [bridge(10, port="COM3"), bridge(11, port="COM4")]
        app = SimpleNamespace(active_run_uuid=RUN, hardware_launch_status_var=Sink())
        method = MethodType(control.PRAYCGControlCenter.prepare_als_barcode_bridge, app)
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=rows),
            mock.patch.object(control, "stop_external_openbci_bridge") as stop,
            mock.patch.object(control.messagebox, "showerror"),
        ):
            self.assertFalse(method())
        stop.assert_not_called()

    def test_run_barcode_refuses_to_open_if_bridge_preparation_fails(self) -> None:
        launches = []
        app = SimpleNamespace(
            active_run_uuid=RUN,
            cfg={"lsl": {}, "acquisition": {}, "log_root": tempfile.gettempdir()},
            active_hardware_profile={},
            prepare_als_barcode_bridge=lambda: False,
            launch_python_tool=lambda *args: launches.append(args),
        )
        control.PRAYCGControlCenter.run_als_test(app)
        self.assertFalse(launches)

    def test_run_barcode_passes_bounded_bridge_startup_wait(self) -> None:
        launches = []
        app = SimpleNamespace(
            active_run_uuid=RUN,
            cfg={"lsl": {}, "acquisition": {}, "log_root": tempfile.gettempdir()},
            active_hardware_profile={},
            prepare_als_barcode_bridge=lambda: True,
            launch_python_tool=lambda *args: launches.append(args),
        )
        control.PRAYCGControlCenter.run_als_test(app)
        self.assertEqual(len(launches), 1)
        args = launches[0][2]
        self.assertEqual(args[args.index("--resolve-timeout-sec") + 1], "20")

    def test_bench_without_bridge_or_serial_runs_display_only(self) -> None:
        launches = []
        app = SimpleNamespace(
            active_run_uuid=RUN,
            cfg={"lsl": {}, "acquisition": {"bench_test_mode": True}, "log_root": tempfile.gettempdir()},
            active_hardware_profile={},
            hardware_launch_status_var=Sink(),
            prepare_als_barcode_bridge=lambda: self.fail("display-only bench path must not prepare hardware"),
            launch_python_tool=lambda *args: launches.append(args),
        )
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[]),
            mock.patch.object(control, "detect_serial_ports", return_value=[]),
            mock.patch.object(control.messagebox, "showinfo"),
        ):
            control.PRAYCGControlCenter.run_als_test(app)
        self.assertEqual(len(launches), 1)
        self.assertEqual(launches[0][0], "ALS Barcode Display-Only Bench Test")
        self.assertIn("--display-only", launches[0][2])
        self.assertIn("readiness will remain ineligible", app.hardware_launch_status_var.value)

    def test_bench_with_detected_serial_keeps_physical_gate(self) -> None:
        launches = []
        prepared = []
        app = SimpleNamespace(
            active_run_uuid=RUN,
            cfg={"lsl": {}, "acquisition": {"bench_test_mode": True}, "log_root": tempfile.gettempdir()},
            active_hardware_profile={},
            prepare_als_barcode_bridge=lambda: prepared.append(True) or True,
            launch_python_tool=lambda *args: launches.append(args),
        )
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[]),
            mock.patch.object(control, "detect_serial_ports", return_value=["COM3"]),
            mock.patch.object(control.messagebox, "askyesnocancel", return_value=True),
        ):
            control.PRAYCGControlCenter.run_als_test(app)
        self.assertEqual(prepared, [True])
        self.assertNotIn("--display-only", launches[0][2])

    def test_bench_can_choose_display_only_when_other_serial_ports_exist(self) -> None:
        launches = []
        app = SimpleNamespace(
            active_run_uuid=RUN,
            cfg={"lsl": {}, "acquisition": {"bench_test_mode": True}, "log_root": tempfile.gettempdir()},
            active_hardware_profile={},
            hardware_launch_status_var=Sink(),
            prepare_als_barcode_bridge=lambda: self.fail("display-only choice must not prepare hardware"),
            launch_python_tool=lambda *args: launches.append(args),
        )
        with (
            mock.patch.object(control, "discover_external_openbci_bridges", return_value=[]),
            mock.patch.object(control, "detect_serial_ports", return_value=["COM7"]),
            mock.patch.object(control.messagebox, "askyesnocancel", return_value=False),
            mock.patch.object(control.messagebox, "showinfo"),
        ):
            control.PRAYCGControlCenter.run_als_test(app)
        self.assertIn("--display-only", launches[0][2])

    def test_bridge_launch_blocks_ghost_com_port_before_spawning(self) -> None:
        launches = []
        app = SimpleNamespace(
            cfg={
                "tools": {"brainflow_eeg_als": str(CONTROL_PATH)},
                "acquisition": {},
                "log_root": tempfile.gettempdir(),
                "praycg_home": tempfile.gettempdir(),
            },
            save_config=lambda: None,
            launch_python_or_exe=lambda *args, **kwargs: launches.append((args, kwargs)),
        )
        method = MethodType(control.PRAYCGControlCenter.launch_brainflow_eeg_als_on_port, app)
        with (
            mock.patch.object(control, "detect_serial_ports", return_value=[]),
            mock.patch.object(control.messagebox, "showerror") as error,
        ):
            self.assertFalse(method("COM3", RUN))
        self.assertFalse(launches)
        self.assertIn("not present", error.call_args.args[0].lower())

    def test_bridge_launch_uses_detected_port_and_current_session(self) -> None:
        launches = []
        app = SimpleNamespace(
            cfg={
                "tools": {"brainflow_eeg_als": str(CONTROL_PATH)},
                "acquisition": {},
                "log_root": tempfile.gettempdir(),
                "praycg_home": tempfile.gettempdir(),
            },
            save_config=lambda: None,
            launch_python_or_exe=lambda *args, **kwargs: launches.append((args, kwargs)) or object(),
        )
        method = MethodType(control.PRAYCGControlCenter.launch_brainflow_eeg_als_on_port, app)
        with mock.patch.object(control, "detect_serial_ports", return_value=["COM3"]):
            self.assertTrue(method("com3", RUN))
        self.assertEqual(app.cfg["acquisition"]["openbci_serial_port"], "COM3")
        command_args = launches[0][0][2]
        self.assertEqual(command_args[command_args.index("--serial-port") + 1], "COM3")
        self.assertEqual(command_args[command_args.index("--run-uuid") + 1], RUN)


class FakeInfo:
    def __init__(self, run_uuid: str):
        self.run_uuid = run_uuid

    def source_id(self):
        return "praycg_als_" + self.run_uuid.replace("-", "")[:12]

    def desc(self):
        return self

    def child_value(self, key: str):
        return self.run_uuid if key == "run_uuid" else ""


class FakeInlet:
    def __init__(self, info, **_kwargs):
        self.info = info

    def open_stream(self, **_kwargs):
        return None

    def pull_chunk(self, **_kwargs):
        return [], []


class Alpha851BarcodeResolutionTests(unittest.TestCase):
    def test_recorder_waits_through_lingering_old_advertisement(self) -> None:
        observed = [[FakeInfo(OLD)], [FakeInfo(RUN)]]

        def resolve(*_args, **_kwargs):
            return observed.pop(0) if observed else [FakeInfo(RUN)]

        with tempfile.TemporaryDirectory() as directory:
            rec = barcode.LSLRecorder("ALS_PT19_Timing", 1, 1.0, Path(directory), RUN, 2.0)
            with mock.patch.object(barcode, "_import_pylsl", return_value=(FakeInlet, resolve, lambda: 1.0)):
                self.assertTrue(rec.prepare())
        self.assertEqual(rec.selection_status, "CURRENT_SESSION")
        self.assertEqual(rec.source_run_uuid, RUN)

    def test_timeout_is_clamped_to_safe_bounds(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            low = barcode.LSLRecorder("x", 1, 1.0, Path(directory), RUN, -10)
            high = barcode.LSLRecorder("x", 1, 1.0, Path(directory), RUN, 999)
        self.assertEqual(low.resolve_timeout_sec, 0.1)
        self.assertEqual(high.resolve_timeout_sec, 60.0)

    def test_display_only_runs_without_importing_lsl_and_writes_nonpassing_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            argv = [
                str(BARCODE_PATH),
                "--display-only",
                "--run-uuid", RUN,
                "--out-dir", directory,
            ]
            with (
                mock.patch.object(sys, "argv", argv),
                mock.patch.object(barcode, "display_tk_barcode") as display,
                mock.patch.object(barcode, "show_message") as message,
                mock.patch.object(barcode, "_import_pylsl", side_effect=AssertionError("LSL must not be imported")),
            ):
                with contextlib.redirect_stdout(io.StringIO()):
                    self.assertEqual(barcode.main(), 0)
            reports = list(Path(directory).glob("als_barcode_live_test_*.json"))
            self.assertEqual(len(reports), 1)
            payload = __import__("json").loads(reports[0].read_text(encoding="utf-8"))
        display.assert_called_once()
        message.assert_called_once()
        self.assertEqual(payload["status"], "BENCH_DISPLAY_ONLY")
        self.assertTrue(payload["bench_display_only"])
        self.assertFalse(payload["physical_als_evidence"])
        self.assertEqual(payload["stream_selection_status"], "BENCH_DISPLAY_ONLY")


if __name__ == "__main__":
    unittest.main()
