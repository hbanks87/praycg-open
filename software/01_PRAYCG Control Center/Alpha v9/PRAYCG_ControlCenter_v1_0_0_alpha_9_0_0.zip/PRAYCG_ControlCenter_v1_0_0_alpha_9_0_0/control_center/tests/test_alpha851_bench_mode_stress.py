from __future__ import annotations

import copy
import importlib.util
import itertools
import sys
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


PACKAGE_ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = PACKAGE_ROOT / "control_center" / "scripts"
SCRIPT = SCRIPTS / "praycg_control_center_v1_0_0_alpha_8.py"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

spec = importlib.util.spec_from_file_location("praycg_alpha851_bench_stress", SCRIPT)
assert spec and spec.loader
control = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = control
spec.loader.exec_module(control)


def valid_contact_only_payload() -> dict:
    return {
        "schema": "PRAYCG_Acquisition_Preflight_v1_0",
        "binding_status": "BOUND",
        "status": "FAIL",
        "fail_reasons": ["more than 25% of EEG channels have flat/noise/saturation/missingness flags"],
        "eeg": {
            "stream": {"source_id": "praycg_eeg_111111111111", "resolved_candidate_count": 1, "error": ""},
            "timing": {
                "sample_count": 3750,
                "effective_rate_hz": 125.0,
                "monotonic_violations": 0,
                "duplicate_timestamps": 0,
                "large_gap_count": 0,
            },
            "expected_rate_hz": 125.0,
            "rate_error_fraction": 0.0,
        },
    }


class ToggleVar:
    def __init__(self, value: bool):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = bool(value)


class Alpha851BenchModeStressTests(unittest.TestCase):
    def test_waiver_rejects_repeated_transport_and_identity_corruption(self) -> None:
        self.assertTrue(control.bench_eeg_quality_waiver(valid_contact_only_payload())[0])
        mutations = [
            ("eeg.stream.source_id", ""),
            ("eeg.stream.resolved_candidate_count", 0),
            ("eeg.stream.resolved_candidate_count", 2),
            ("eeg.stream.error", "board read failed"),
            ("eeg.timing.sample_count", 624),
            ("eeg.timing.monotonic_violations", 1),
            ("eeg.timing.duplicate_timestamps", 1),
            ("eeg.timing.large_gap_count", 1),
            ("eeg.timing.effective_rate_hz", 100.0),
            ("eeg.rate_error_fraction", 0.2),
            ("binding_status", "UNBOUND"),
            ("status", "PASS"),
            ("fail_reasons", ["EEG stream missing"]),
        ]
        for _cycle in range(40):
            for dotted, value in mutations:
                payload = valid_contact_only_payload()
                target = payload
                parts = dotted.split(".")
                for part in parts[:-1]:
                    target = target[part]
                target[parts[-1]] = value
                allowed, _detail = control.bench_eeg_quality_waiver(payload)
                self.assertFalse(allowed, dotted)

    def test_session_classification_exhaustive_matrix_has_only_two_valid_shapes(self) -> None:
        valid_count = 0
        for bench, eligible, waiver, purpose, pseudonym, reason in itertools.product(
            (False, True),
            (False, True),
            (False, True),
            ("PARTICIPANT_ACQUISITION", "BENCH_TEST", "OTHER"),
            ("P001", "BENCH-111111111111", ""),
            ("", "cap intentionally not worn"),
        ):
            session = {
                "bench_test_mode": bench,
                "participant_data_eligible": eligible,
                "bench_eeg_quality_waiver_active": waiver,
                "bench_readiness_bypass_active": bench,
                "session_purpose": purpose,
                "participant_pseudonym": pseudonym,
                "bench_test_reason": reason,
            }
            actual, _detail = control.locked_session_classification_status(session)
            expected_participant = (
                not bench and eligible and not waiver and purpose == "PARTICIPANT_ACQUISITION"
                and pseudonym == "P001" and reason == ""
            )
            expected_bench = (
                bench and not eligible and purpose == "BENCH_TEST"
                and pseudonym == "BENCH-111111111111" and bool(reason)
            )
            self.assertEqual(actual, expected_participant or expected_bench, session)
            valid_count += int(actual)
        self.assertGreater(valid_count, 0)

    def test_one_hundred_mode_transitions_always_disarm_and_stale_prior_evidence(self) -> None:
        acquisition = {
            "bench_test_mode": False,
            "bench_test_reason": "",
            "bench_eeg_quality_waiver_active": False,
            "session_stage": "SELECT",
            "session_lock_path": "",
            "participant_pseudonym": "P001",
            "armed": True,
        }
        var = ToggleVar(False)
        app = SimpleNamespace(
            cfg={"acquisition": acquisition},
            bench_test_mode_var=var,
            save_config=lambda: None,
            write_acquisition_state=lambda: None,
            refresh_acquisition_readiness=lambda: "CAUTION",
        )
        with (
            mock.patch.object(control.messagebox, "askyesno", return_value=True),
            mock.patch.object(control.messagebox, "showinfo"),
            mock.patch.object(control.simpledialog, "askstring", return_value="cap intentionally not worn"),
        ):
            previous_epoch = 0.0
            for index in range(100):
                requested = index % 2 == 0
                var.set(requested)
                control.PRAYCGControlCenter.toggle_bench_test_mode(app)
                self.assertEqual(acquisition["bench_test_mode"], requested)
                self.assertFalse(acquisition["armed"])
                self.assertFalse(acquisition["bench_eeg_quality_waiver_active"])
                self.assertEqual(acquisition["session_lock_status"], "STALE_BENCH_MODE_CHANGED")
                self.assertEqual(acquisition["session_stage"], "SELECT")
                self.assertEqual(acquisition["participant_pseudonym"], "")
                self.assertGreaterEqual(acquisition["preflight_started_epoch"], previous_epoch)
                previous_epoch = acquisition["preflight_started_epoch"]
                self.assertEqual(bool(acquisition["bench_test_reason"]), requested)

    def test_restart_migration_always_resets_bench_authority(self) -> None:
        saved = control.default_config()
        saved["acquisition"].update({
            "bench_test_mode": True,
            "bench_test_reason": "old reason",
            "bench_eeg_quality_waiver_active": True,
            "armed": True,
            "arm_override_reason": "old override",
        })
        before = time.time()
        migrated, _notes = control.migrate_saved_config(copy.deepcopy(saved), control.default_config())
        after = time.time()
        acquisition = migrated["acquisition"]
        self.assertFalse(acquisition["bench_test_mode"])
        self.assertEqual(acquisition["bench_test_reason"], "")
        self.assertFalse(acquisition["bench_eeg_quality_waiver_active"])
        self.assertFalse(acquisition["armed"])
        self.assertEqual(acquisition["arm_override_reason"], "")
        self.assertEqual(acquisition["session_lock_status"], "STALE_NEW_CONTROL_CENTER_PROCESS")
        self.assertGreaterEqual(acquisition["preflight_started_epoch"], before)
        self.assertLessEqual(acquisition["preflight_started_epoch"], after)

    def test_active_runner_refuses_mode_change_without_mutating_authority(self) -> None:
        acquisition = {
            "bench_test_mode": False,
            "session_stage": "ACQUIRE",
            "armed": True,
            "participant_pseudonym": "P001",
        }
        var = ToggleVar(True)
        app = SimpleNamespace(cfg={"acquisition": acquisition}, bench_test_mode_var=var)
        with mock.patch.object(control.messagebox, "showerror") as error:
            control.PRAYCGControlCenter.toggle_bench_test_mode(app)
        self.assertFalse(var.get())
        self.assertFalse(acquisition["bench_test_mode"])
        self.assertTrue(acquisition["armed"])
        self.assertEqual(acquisition["participant_pseudonym"], "P001")
        error.assert_called_once()


if __name__ == "__main__":
    unittest.main()
