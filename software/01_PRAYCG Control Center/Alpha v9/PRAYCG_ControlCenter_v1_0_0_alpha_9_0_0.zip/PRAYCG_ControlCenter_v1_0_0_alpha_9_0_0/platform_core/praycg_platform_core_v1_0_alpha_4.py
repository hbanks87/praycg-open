#!/usr/bin/env python3
"""PRAYCG alpha.4 platform extensions over the audited alpha.3 authority core.

All session-lease and acquisition-authority behavior remains delegated to the
alpha.3 implementation. Alpha.4 adds conservative hardware-admission metadata
and profile-specific primary/supplemental role selection without changing the
meaning of canonical signal roles.
"""
from __future__ import annotations

from copy import deepcopy
import importlib.util
import os
from pathlib import Path
import sys
import time
from typing import Any, Iterable, Mapping, Sequence
import re

import praycg_platform_core_v1_0_alpha_3 as alpha3
from praycg_platform_core_v1_0_alpha_3 import *  # noqa: F401,F403 - compatibility surface


PLATFORM_VERSION = "1.0.0-alpha.4"
MODULE_REGISTRY_SCHEMA = "PRAYCG_ModuleRegistry_v1_0_alpha_4"
PACKAGE_ROOT = Path(__file__).resolve().parents[1]
ADMISSION_STATES = {
    "CATALOG_ONLY",
    "SIMULATOR_VERIFIED",
    "BENCH_VERIFIED",
    "HUMAN_CONNECTED_APPROVED",
    "QUARANTINED",
}
PHYSICAL_VALIDATION_STATES = {"NOT_PERFORMED", "BENCH_ONLY", "HUMAN_CONNECTED"}
ROLE_ASSIGNMENTS = {"PRIMARY", "SUPPLEMENTAL", "UNASSIGNED"}
GENERIC_EDA_PPG_MODULE_IDS = {"generic_eda_ppg_serial", "generic_eda_ppg_udp"}
LOWER_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
LEGACY_CARRIED_HARDWARE_MODULE_IDS = {
    "generic_eog_emg_sentinels",
    "openbci_cyton_daisy_eeg_als",
    "openbci_cyton_daisy_eeg",
    "polar_h10_rr",
    "vernier_respiration",
}
LEGACY_CARRIED_HARDWARE_PATHS = {
    "generic_eog_emg_sentinels": PACKAGE_ROOT / "config" / "hardware" / "Generic_EOG_EMG_Sentinels_v0_1.json",
    "openbci_cyton_daisy_eeg_als": PACKAGE_ROOT / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_ALS_v0_1.json",
    "openbci_cyton_daisy_eeg": PACKAGE_ROOT / "config" / "hardware" / "OpenBCI_CytonDaisy_EEG_v0_1.json",
    "polar_h10_rr": PACKAGE_ROOT / "config" / "hardware" / "Polar_H10_RR_v0_1.json",
    "vernier_respiration": PACKAGE_ROOT / "config" / "hardware" / "Vernier_Respiration_v0_1.json",
}

PUBLIC_DEMO_PACKS_RELATIVE_ROOT = (
    Path("examples") / "no_copyright_media_demo" / "stimulus_library" / "packs"
)
PUBLIC_DEMO_MEDIA_SUFFIXES = {".avi", ".mkv", ".mov", ".mp4", ".wav"}
PUBLIC_MEDIA_SCAN_FINDING = "raw recording or media file is not permitted in the public software package"
PUBLIC_DEMO_LICENSE_ID = "CC0-1.0"
_STIMULUS_COMMON_MODULE_NAME = "_praycg_alpha4_stimulus_common_for_public_scan"


def _load_stimulus_pack_contract() -> Any:
    """Load the package-local data-pack validator without importing pack content.

    The platform core normally has no import-time dependency on a tool folder.
    Public-package scanning is the one deliberate exception: the scanner must
    use the same frozen manifest and ledger contract as the Stimulus Library.
    Loading is lazy and fails closed at the caller if the contract is absent or
    cannot be imported.
    """
    existing = sys.modules.get(_STIMULUS_COMMON_MODULE_NAME)
    if existing is not None:
        return existing
    source = (
        PACKAGE_ROOT
        / "tools"
        / "Stimulus_Forge_Library_v1_0"
        / "praycg_stimulus_common_v1_0.py"
    )
    if not source.is_file():
        raise FileNotFoundError(f"Stimulus-pack validation contract is missing: {source}")
    spec = importlib.util.spec_from_file_location(_STIMULUS_COMMON_MODULE_NAME, source)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load stimulus-pack validation contract: {source}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_STIMULUS_COMMON_MODULE_NAME] = module
    previous_dont_write_bytecode = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(_STIMULUS_COMMON_MODULE_NAME, None)
        raise
    finally:
        sys.dont_write_bytecode = previous_dont_write_bytecode
    return module


def _verified_public_demo_media(root: Path) -> tuple[set[str], list[dict[str, Any]]]:
    """Return exact root-relative media paths admitted by valid CC0 demo packs.

    Admission is intentionally narrow.  A pack must be an immediate child of
    the designated public demo-pack directory, pass the complete strict pack
    validator (including manifest-content hash, per-file byte/hash ledger, and
    no untracked files), declare ``DEMO_ONLY``, and declare ``CC0-1.0`` for a
    bundled, redistribution-reviewed distribution.  Any import or validation
    failure produces an empty allowlist for the affected pack.
    """
    root = Path(root).resolve()
    packs_root = (root / PUBLIC_DEMO_PACKS_RELATIVE_ROOT).resolve()
    if not packs_root.is_dir():
        return set(), []
    try:
        packs_root.relative_to(root)
    except ValueError:
        return set(), []

    try:
        contract = _load_stimulus_pack_contract()
    except Exception as exc:
        return set(), [{
            "pack": PUBLIC_DEMO_PACKS_RELATIVE_ROOT.as_posix(),
            "status": "REJECTED_FAIL_CLOSED",
            "reason": f"stimulus contract unavailable: {type(exc).__name__}",
            "allowed_media_count": 0,
        }]

    allowed: set[str] = set()
    audits: list[dict[str, Any]] = []
    for pack_root in sorted((path for path in packs_root.iterdir() if path.is_dir()), key=lambda path: path.name.casefold()):
        media_files = sorted(
            (
                path for path in pack_root.rglob("*")
                if path.is_file() and path.suffix.casefold() in PUBLIC_DEMO_MEDIA_SUFFIXES
            ),
            key=lambda path: path.as_posix().casefold(),
        )
        if not media_files:
            continue
        try:
            pack_root.resolve().relative_to(packs_root)
            pack_is_contained = not pack_root.is_symlink()
        except ValueError:
            pack_is_contained = False
        if not pack_is_contained:
            audits.append({
                "pack": pack_root.relative_to(root).as_posix(),
                "status": "REJECTED_FAIL_CLOSED",
                "reasons": ["pack root is a link or resolves outside the designated demo-pack directory"],
                "allowed_media_count": 0,
            })
            continue
        manifest_path = pack_root / "stimulus_pack_manifest.json"
        rejection_reasons: list[str] = []
        manifest: Mapping[str, Any] = {}
        try:
            validation = contract.validate_pack(pack_root, strict_extra_files=True, media_probe=False)
        except Exception as exc:
            validation = None
            rejection_reasons.append(f"strict pack validation raised {type(exc).__name__}")
        if validation is None or validation.status != "PASS":
            if validation is not None:
                rejection_reasons.extend(str(item) for item in validation.errors)
                rejection_reasons.extend(str(item) for item in validation.warnings)
            if not rejection_reasons:
                rejection_reasons.append("strict pack validation did not pass")
        try:
            loaded = contract.read_json(manifest_path)
            if isinstance(loaded, Mapping):
                manifest = loaded
            else:
                rejection_reasons.append("manifest root is not an object")
        except Exception as exc:
            rejection_reasons.append(f"manifest could not be read: {type(exc).__name__}")

        distribution = manifest.get("distribution") if isinstance(manifest, Mapping) else None
        if manifest.get("scientific_status") != "DEMO_ONLY":
            rejection_reasons.append("scientific_status is not DEMO_ONLY")
        if not isinstance(distribution, Mapping) or distribution.get("license_id") != PUBLIC_DEMO_LICENSE_ID:
            rejection_reasons.append(f"distribution.license_id is not {PUBLIC_DEMO_LICENSE_ID}")
        if not isinstance(distribution, Mapping) or distribution.get("bundled") is not True:
            rejection_reasons.append("distribution.bundled is not true")
        if not isinstance(distribution, Mapping) or distribution.get("redistribution_reviewed") is not True:
            rejection_reasons.append("distribution.redistribution_reviewed is not true")

        pack_relative = pack_root.relative_to(root).as_posix()
        if rejection_reasons:
            audits.append({
                "pack": pack_relative,
                "pack_id": manifest.get("pack_id"),
                "status": "REJECTED_FAIL_CLOSED",
                "reasons": list(dict.fromkeys(rejection_reasons)),
                "allowed_media_count": 0,
            })
            continue

        admitted = {path.relative_to(root).as_posix() for path in media_files}
        allowed.update(admitted)
        audits.append({
            "pack": pack_relative,
            "pack_id": manifest.get("pack_id"),
            "status": "VERIFIED_CC0_DEMO_ONLY",
            "scientific_status": "DEMO_ONLY",
            "license_id": PUBLIC_DEMO_LICENSE_ID,
            "manifest_content_sha256": manifest.get("manifest_content_sha256"),
            "allowed_media_count": len(admitted),
        })
    return allowed, audits


def scan_public_package(root: Path, *, allowed_emails: Iterable[str] = ()) -> dict[str, Any]:
    """Run alpha.3 public scanning with a hash-bound CC0 demo-media exception.

    Only the exact audio/video paths returned by
    :func:`_verified_public_demo_media` may have the inherited generic media
    prohibition removed.  Raw biosignals, media anywhere else, and every other
    privacy or credential finding remain untouched.
    """
    root = Path(root).resolve()
    result = alpha3.scan_public_package(root, allowed_emails=allowed_emails)
    verified_media, pack_audits = _verified_public_demo_media(root)
    findings: list[dict[str, Any]] = []
    for finding in result.get("findings", []):
        relative = str(finding.get("path") or "")
        is_verified_demo_media_finding = (
            finding.get("severity") == "ERROR"
            and finding.get("finding") == PUBLIC_MEDIA_SCAN_FINDING
            and Path(relative).suffix.casefold() in PUBLIC_DEMO_MEDIA_SUFFIXES
            and relative in verified_media
        )
        if not is_verified_demo_media_finding:
            findings.append(finding)

    result["schema"] = "PRAYCG_PublicPackageScan_v0_1_alpha_4"
    result["platform_version"] = PLATFORM_VERSION
    result["generated_utc"] = utc_now()
    result["findings"] = findings
    result["verified_demo_media_policy"] = {
        "relative_root": PUBLIC_DEMO_PACKS_RELATIVE_ROOT.as_posix(),
        "required_scientific_status": "DEMO_ONLY",
        "required_license_id": PUBLIC_DEMO_LICENSE_ID,
        "strict_manifest_and_file_ledger_validation": True,
        "allowed_media_count": len(verified_media),
        "allowed_media_paths": sorted(verified_media),
        "pack_audits": pack_audits,
        "boundary": (
            "Allowance means only that exact ledger-bound CC0 DEMO_ONLY media may be distributed in this "
            "software package. It is not scientific validation or participant-acquisition eligibility."
        ),
    }
    result["status"] = (
        "INELIGIBLE"
        if any(row.get("severity") == "ERROR" for row in findings)
        else ("CAUTION" if findings else "PASS")
    )
    return result


def _is_exact_carried_module_path(module_id: str, path: Path) -> bool:
    expected = LEGACY_CARRIED_HARDWARE_PATHS.get(module_id)
    return expected is not None and Path(path).resolve() == expected.resolve() and expected.is_file()


def _append_unique(target: list[str], values: Sequence[str]) -> None:
    for value in values:
        if value not in target:
            target.append(value)


def _admission_findings(module: Mapping[str, Any], *, intended_use: str | None = None) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    cautions: list[str] = []
    state = module.get("admission_state")
    physical = module.get("physical_validation")
    if state is None:
        module_id = str(module.get("module_id") or "")
        if module_id in LEGACY_CARRIED_HARDWARE_MODULE_IDS:
            cautions.append("Exact carried module ID has no alpha.4 admission state and is treated as LEGACY_CARRIED_UNGRADED.")
        else:
            errors.append("Module has no alpha.4 admission_state and is not on the exact carried-module allowlist.")
        return errors, cautions
    if state not in ADMISSION_STATES:
        errors.append(f"Unsupported hardware admission_state {state!r}.")
        return errors, cautions
    if physical not in PHYSICAL_VALIDATION_STATES:
        errors.append(f"Unsupported physical_validation {physical!r}.")
    if state in {"CATALOG_ONLY", "SIMULATOR_VERIFIED", "QUARANTINED"} and physical != "NOT_PERFORMED":
        errors.append(f"{state} cannot claim physical-device validation.")
    if state == "BENCH_VERIFIED" and physical != "BENCH_ONLY":
        errors.append("BENCH_VERIFIED requires physical_validation=BENCH_ONLY.")
    if state == "HUMAN_CONNECTED_APPROVED":
        if physical != "HUMAN_CONNECTED":
            errors.append("HUMAN_CONNECTED_APPROVED requires physical_validation=HUMAN_CONNECTED.")
        evidence = module.get("admission_evidence")
        if not isinstance(evidence, list) or not evidence:
            errors.append("Human-connected approval requires nonempty admission_evidence.")
        else:
            for item in evidence:
                if not isinstance(item, Mapping) or not str(item.get("sha256") or "").strip():
                    errors.append("Every human-connected admission evidence record requires a SHA-256 identity.")
    if state == "SIMULATOR_VERIFIED":
        if module.get("synthetic") is not True:
            errors.append("SIMULATOR_VERIFIED requires synthetic=true.")
        for stream in module.get("streams", []):
            if isinstance(stream, Mapping) and not str(stream.get("lsl_name") or "").startswith("SYNTHETIC_"):
                errors.append("Simulator-verified modules require SYNTHETIC_ LSL outlet names.")
    if intended_use:
        use = str(intended_use).upper()
        if state in {"CATALOG_ONLY", "QUARANTINED"}:
            errors.append(f"{state} modules cannot enter any reviewed hardware profile.")
        elif use == "HUMAN_CONNECTED" and state not in {"HUMAN_CONNECTED_APPROVED"}:
            errors.append(f"{state} is not eligible for a new human-connected hardware profile.")
        elif use == "SIMULATION" and state != "SIMULATOR_VERIFIED":
            errors.append(f"{state} is not eligible for a simulation-only profile.")
    return errors, cautions


def validate_hardware_module(module: Mapping[str, Any]) -> ValidationReport:
    """Validate the carried hardware contract plus optional alpha.4 admission fields."""
    report = alpha3.validate_hardware_module(module)
    admission_errors, admission_cautions = _admission_findings(module)
    _append_unique(report.errors, admission_errors)
    _append_unique(report.cautions, admission_cautions)
    for stream in module.get("streams", []):
        if not isinstance(stream, Mapping):
            continue
        assignment = stream.get("role_assignment_default")
        if assignment is not None and assignment not in ROLE_ASSIGNMENTS:
            report.errors.append(
                f"{stream.get('lsl_name') or '?'} has invalid role_assignment_default {assignment!r}."
            )
    if module.get("module_id") in GENERIC_EDA_PPG_MODULE_IDS:
        relative = str(module.get("driver_profile_relative_path") or "").strip()
        digest = str(module.get("driver_profile_sha256") or "").strip()
        if not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
            report.errors.append("Generic EDA/PPG modules require a contained driver_profile_relative_path.")
        if not LOWER_SHA256_RE.fullmatch(digest):
            report.errors.append("Generic EDA/PPG modules require a lowercase 64-hex driver_profile_sha256.")
    return report


def _driver_profile_binding(module: Mapping[str, Any], module_path: Path) -> tuple[dict[str, Any], list[str]]:
    """Resolve and hash-bind a promoted generic EDA/PPG driver profile."""
    if module.get("module_id") not in GENERIC_EDA_PPG_MODULE_IDS:
        return {}, []
    errors: list[str] = []
    relative = str(module.get("driver_profile_relative_path") or "").strip()
    expected = str(module.get("driver_profile_sha256") or "").strip()
    if not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        return {}, ["Driver profile path is absent, absolute, or escapes the module directory."]
    driver_path = (module_path.parent / relative).resolve()
    try:
        driver_path.relative_to(module_path.parent.resolve())
    except ValueError:
        return {}, ["Driver profile path escapes the module directory."]
    if not driver_path.is_file():
        errors.append("Bound driver profile file does not exist.")
        observed = None
    else:
        observed = sha256_file(driver_path)
        if not LOWER_SHA256_RE.fullmatch(expected) or observed != expected:
            errors.append("Bound driver profile SHA-256 is missing or does not match the selected file.")
    return {
        "driver_profile_path": str(driver_path),
        "driver_profile_relative_path": relative,
        "driver_profile_sha256": expected,
        "observed_driver_profile_sha256": observed,
    }, errors


def _source_ref(module_id: str, lsl_name: str) -> str:
    return f"{module_id}/{lsl_name}"


def build_hardware_profile(
    module_paths: Sequence[Path],
    output_path: Path,
    *,
    profile_id: str,
    reviewed_by: str = "UNRECORDED",
    role_assignments: Mapping[str, str] | None = None,
    intended_use: str = "HUMAN_CONNECTED",
) -> dict[str, Any]:
    """Build a reviewed profile with one explicit primary source per role.

    `role_assignments` maps canonical role to `module_id/lsl_name`. If a role
    has exactly one source, that source is primary by backward-compatible
    default. Multiple sources require an explicit override or unambiguous
    per-stream defaults. Other selected sources become supplemental.

    Existing alpha.1-alpha.3 module files have no admission metadata. They are
    retained as LEGACY_CARRIED_UNGRADED for compatibility and are surfaced as a
    caution. New modules that declare alpha.4 admission metadata must satisfy
    the requested intended use.
    """
    intended_use = str(intended_use or "HUMAN_CONNECTED").upper()
    if intended_use not in {"HUMAN_CONNECTED", "SIMULATION"}:
        raise ValueError("intended_use must be HUMAN_CONNECTED or SIMULATION")
    overrides = {str(role): str(source) for role, source in (role_assignments or {}).items()}
    modules: list[dict[str, Any]] = []
    errors: list[str] = []
    cautions: list[str] = []
    sources_by_role: dict[str, list[dict[str, Any]]] = {}
    all_lsl_names: dict[str, str] = {}
    for raw_path in module_paths:
        path = Path(raw_path).resolve()
        module = load_json(path)
        module_id = str(module.get("module_id") or "unknown")
        report = validate_hardware_module(module)
        errors.extend(f"{path.name}: {item}" for item in report.errors)
        cautions.extend(f"{path.name}: {item}" for item in report.cautions)
        state = str(module.get("admission_state") or "LEGACY_CARRIED_UNGRADED")
        if state != "LEGACY_CARRIED_UNGRADED":
            admission_errors, admission_cautions = _admission_findings(module, intended_use=intended_use)
            errors.extend(f"{path.name}: {item}" for item in admission_errors)
            cautions.extend(f"{path.name}: {item}" for item in admission_cautions)
        elif not _is_exact_carried_module_path(module_id, path):
            errors.append(
                f"{path.name}: missing-state legacy compatibility is restricted to the exact packaged config/hardware file for {module_id}."
            )
        driver_binding, driver_errors = _driver_profile_binding(module, path)
        errors.extend(f"{path.name}: {item}" for item in driver_errors)
        selected_streams = deepcopy(module.get("streams", []))
        selected = {
            "module_id": module.get("module_id"),
            "module_version": module.get("module_version"),
            "path": str(path),
            "module_file_sha256": sha256_file(path),
            "module_canonical_sha256": sha256_json(module),
            "sha256": sha256_file(path),
            "trust_level": module.get("trust_level"),
            "admission_state": state,
            "physical_validation": module.get("physical_validation", "UNRECORDED_LEGACY"),
            "admission_evidence": deepcopy(module.get("admission_evidence", [])),
            "synthetic": bool(module.get("synthetic", False)),
            **driver_binding,
            "streams": selected_streams,
        }
        modules.append(selected)
        for stream in selected_streams:
            if not isinstance(stream, Mapping):
                continue
            name = str(stream.get("lsl_name") or "")
            if name in all_lsl_names:
                errors.append(f"LSL outlet name collision: {name!r} appears in {all_lsl_names[name]} and {module_id}.")
            else:
                all_lsl_names[name] = module_id
            roles = [str(stream.get("canonical_role") or "")]
            roles.extend(str(role) for role in stream.get("embedded_roles", []))
            for role in roles:
                if not role:
                    continue
                sources_by_role.setdefault(role, []).append({
                    "source_ref": _source_ref(module_id, name),
                    "module_id": module_id,
                    "lsl_name": name,
                    "stream": stream,
                    "declared_default": stream.get("role_assignment_default"),
                })
    primary: dict[str, dict[str, str]] = {}
    supplemental: dict[str, list[dict[str, str]]] = {}
    unassigned: dict[str, list[dict[str, str]]] = {}
    resolved_roles: dict[str, list[str]] = {}
    for role, sources in sorted(sources_by_role.items()):
        resolved_roles[role] = [str(row["lsl_name"]) for row in sources]
        override = overrides.get(role)
        available = {str(row["source_ref"]) for row in sources}
        if override and override not in available:
            errors.append(f"Primary override for {role!r} is not a selected source: {override!r}.")
        decisions: list[tuple[dict[str, Any], str]] = []
        for row in sources:
            if override:
                assignment = "PRIMARY" if row["source_ref"] == override else "SUPPLEMENTAL"
            elif len(sources) == 1:
                assignment = "PRIMARY" if role != "markers" else "SUPPLEMENTAL"
            else:
                assignment = str(row.get("declared_default") or "UNASSIGNED")
            decisions.append((row, assignment))
        primaries = [row for row, assignment in decisions if assignment == "PRIMARY"]
        if role != "markers" and len(primaries) != 1:
            errors.append(
                f"Canonical role {role!r} requires exactly one primary source; found {len(primaries)}. "
                "Provide role_assignments={role: 'module_id/lsl_name'} to resolve it."
            )
        for row, assignment in decisions:
            stream = row["stream"]
            stream["role_assignment"] = assignment
            stream["source_ref"] = row["source_ref"]
            compact = {
                "source_ref": str(row["source_ref"]),
                "module_id": str(row["module_id"]),
                "lsl_name": str(row["lsl_name"]),
            }
            if assignment == "PRIMARY" and role not in primary:
                primary[role] = compact
            elif assignment == "SUPPLEMENTAL":
                supplemental.setdefault(role, []).append(compact)
            else:
                unassigned.setdefault(role, []).append(compact)
                if role != "markers":
                    errors.append(f"Source {row['source_ref']} for role {role!r} remains UNASSIGNED.")
    unknown_overrides = sorted(set(overrides) - set(sources_by_role))
    if unknown_overrides:
        errors.append("Primary overrides refer to absent canonical roles: " + ", ".join(unknown_overrides))
    profile = {
        "schema": PROFILE_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "artifact_type": "REVIEWED_HARDWARE_PROFILE",
        "profile_id": safe_slug(profile_id),
        "created_utc": utc_now(),
        "reviewed_by": reviewed_by,
        "intended_use": intended_use,
        "status": "APPROVED" if not errors and alpha3._recorded_identity(reviewed_by) else "DRAFT_NOT_APPROVED",
        "legacy_status": "LOCKABLE" if not errors and alpha3._recorded_identity(reviewed_by) else "DRAFT_NOT_LOCKABLE",
        "modules": modules,
        "resolved_roles": resolved_roles,
        "primary_role_sources": primary,
        "supplemental_role_sources": supplemental,
        "unassigned_role_sources": unassigned,
        "role_assignment_policy": "Exactly one primary per non-marker canonical role; additional reviewed sources are supplemental.",
        "admission_policy": "New human-connected modules require HUMAN_CONNECTED_APPROVED; legacy modules remain carried with an explicit caution.",
        "errors": errors,
        "cautions": cautions,
    }
    profile["canonical_sha256"] = alpha3._canonical_stored_hash(profile)
    write_json(Path(output_path).resolve(), profile)
    return profile


def _role_assignment_findings(profile: Mapping[str, Any]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    cautions: list[str] = []
    if "primary_role_sources" not in profile:
        # Alpha.1-alpha.3 profiles rejected same-role collisions at build time,
        # so a sole carried outlet can be inferred as that role's primary
        # source without changing the historical PASS/CAUTION result.
        for role, names in profile.get("resolved_roles", {}).items():
            if str(role) != "markers" and isinstance(names, list) and len(names) > 1:
                errors.append(f"Legacy profile has an unresolved collision for canonical role {role!r}.")
        return errors, cautions
    sources: dict[str, set[str]] = {}
    assignments: dict[str, list[tuple[str, str]]] = {}
    for module in profile.get("modules", []):
        if not isinstance(module, Mapping):
            continue
        module_id = str(module.get("module_id") or "unknown")
        state = str(module.get("admission_state") or "LEGACY_CARRIED_UNGRADED")
        intended_use = str(profile.get("intended_use") or "HUMAN_CONNECTED")
        if state != "LEGACY_CARRIED_UNGRADED":
            pseudo_module = {
                "admission_state": state,
                "physical_validation": module.get("physical_validation"),
                "synthetic": module.get("synthetic"),
                "streams": module.get("streams", []),
                "admission_evidence": module.get("admission_evidence"),
            }
            admission_errors, admission_cautions = _admission_findings(pseudo_module, intended_use=intended_use)
            errors.extend(f"{module_id}: {item}" for item in admission_errors)
            cautions.extend(f"{module_id}: {item}" for item in admission_cautions)
        for stream in module.get("streams", []):
            if not isinstance(stream, Mapping):
                continue
            role = str(stream.get("canonical_role") or "")
            ref = str(stream.get("source_ref") or _source_ref(module_id, str(stream.get("lsl_name") or "")))
            assignment = str(stream.get("role_assignment") or "UNASSIGNED")
            sources.setdefault(role, set()).add(ref)
            assignments.setdefault(role, []).append((ref, assignment))
    ledger = profile.get("primary_role_sources", {})
    for role, rows in assignments.items():
        primaries = [ref for ref, assignment in rows if assignment == "PRIMARY"]
        if role != "markers" and len(primaries) != 1:
            errors.append(f"Canonical role {role!r} does not have exactly one primary source.")
        recorded = ledger.get(role) if isinstance(ledger, Mapping) else None
        recorded_ref = str(recorded.get("source_ref") or "") if isinstance(recorded, Mapping) else ""
        if role != "markers" and (not primaries or recorded_ref != primaries[0]):
            errors.append(f"Primary-source ledger does not match stream assignments for role {role!r}.")
    return errors, cautions


def validate_hardware_profile_identity(
    profile: Mapping[str, Any],
    *,
    profile_path: Path | None = None,
) -> ValidationReport:
    report = alpha3.validate_hardware_profile_identity(profile, profile_path=profile_path)
    assignment_errors, assignment_cautions = _role_assignment_findings(profile)
    _append_unique(report.errors, assignment_errors)
    _append_unique(report.cautions, assignment_cautions)
    for selected in profile.get("modules", []):
        if not isinstance(selected, Mapping):
            continue
        path = Path(str(selected.get("path") or ""))
        if path.is_file():
            try:
                module = load_json(path)
            except Exception:
                continue
            if module.get("admission_state") is not None:
                admission_errors, admission_cautions = _admission_findings(
                    module,
                    intended_use=str(profile.get("intended_use") or "HUMAN_CONNECTED"),
                )
                _append_unique(report.errors, [f"{selected.get('module_id')}: {item}" for item in admission_errors])
                _append_unique(report.cautions, [f"{selected.get('module_id')}: {item}" for item in admission_cautions])
            else:
                module_id = str(module.get("module_id") or "")
                if module_id not in LEGACY_CARRIED_HARDWARE_MODULE_IDS:
                    report.errors.append(f"{selected.get('module_id')}: missing admission_state is not eligible for legacy compatibility.")
                elif not _is_exact_carried_module_path(module_id, path):
                    report.errors.append(
                        f"{selected.get('module_id')}: missing-state compatibility is not bound to the exact packaged carried module path."
                    )
            driver_binding, driver_errors = _driver_profile_binding(module, path)
            _append_unique(report.errors, [f"{selected.get('module_id')}: {item}" for item in driver_errors])
            if driver_binding:
                for field in ("driver_profile_path", "driver_profile_relative_path", "driver_profile_sha256"):
                    if selected.get(field) != driver_binding.get(field):
                        report.errors.append(f"{selected.get('module_id')}: selected {field} does not match the bound module driver profile.")
    return report


def build_session_draft(
    template: Mapping[str, Any],
    protocol_snapshot: Mapping[str, Any],
    hardware_profile: Mapping[str, Any],
    output_path: Path,
    *,
    protocol_snapshot_path: Path | None = None,
    hardware_profile_path: Path | None = None,
) -> dict[str, Any]:
    """Delegate draft construction, then enforce alpha.4 hardware invariants."""
    draft = alpha3.build_session_draft(
        template,
        protocol_snapshot,
        hardware_profile,
        output_path,
        protocol_snapshot_path=protocol_snapshot_path,
        hardware_profile_path=hardware_profile_path,
    )
    extra = validate_hardware_profile_identity(hardware_profile, profile_path=hardware_profile_path)
    validation = draft.setdefault("validation", {"errors": [], "cautions": []})
    _append_unique(validation.setdefault("errors", []), extra.errors)
    _append_unique(validation.setdefault("cautions", []), extra.cautions)
    validation["status"] = "INELIGIBLE" if validation["errors"] else ("CAUTION" if validation["cautions"] else "PASS")
    if validation["errors"]:
        draft["status"] = "INVALID_SELECTION"
        draft["current_stage"] = "UNSET"
        draft["gate_status"] = {stage: "PENDING" for stage in alpha3.SESSION_STAGES}
    draft["platform_version"] = PLATFORM_VERSION
    write_json(Path(output_path), draft)
    return draft


def runtime_lock_reuse_reasons(output_path: Path | str) -> list[str]:
    """Explain why a run-local lock path may no longer be replaced.

    Reconfirming a lock before ACQUIRE is supported. Once a one-use runner
    lease or ACQUIRE claim exists, the UUID directory is immutable history and
    the operator must allocate a new run UUID.
    """
    path = Path(output_path).expanduser().resolve(strict=False)
    reasons: list[str] = []
    lease_path = path.parent / alpha3.RUNTIME_RUNNER_LEASE_FILENAME
    if lease_path.exists():
        reasons.append("the run UUID already contains a one-use authorized-runner lease")
    acquire_claims = sorted(path.parent.glob(f"{path.name}.*.acquire.transition_claim.json"))
    if acquire_claims:
        reasons.append("the run UUID already contains an ACQUIRE transition claim")
    if path.is_file():
        try:
            existing = alpha3.load_json(path)
            report = alpha3.validate_session_lock_identity(existing)
            stage = str(existing.get("current_stage") or "")
            if report.status != "INELIGIBLE" and stage in alpha3.SESSION_STAGES[alpha3.SESSION_STAGES.index("ACQUIRE"):]:
                reasons.append(f"the existing runtime lock has already reached {stage}")
        except Exception:
            # A malformed current file is already handled by the normal lock
            # validator. Historical one-use evidence remains decisive here.
            pass
    return list(dict.fromkeys(reasons))


def _matching_transition_claim(path: Path, lock_identity: str, target_stage: str) -> Mapping[str, Any]:
    claim_path = path.with_name(
        f"{path.name}.{lock_identity[:12]}.{target_stage.lower()}.transition_claim.json"
    )
    if not claim_path.is_file():
        raise RuntimeError(f"The superseded owner lacks its exact {target_stage} transition claim.")
    claim = alpha3.load_json(claim_path)
    errors: list[str] = []
    if claim.get("schema") != "PRAYCG_RuntimeGateTransitionClaim_v0_1":
        errors.append("schema is not recognized")
    if str(claim.get("lock_identity_sha256") or "") != lock_identity:
        errors.append("lock identity differs")
    if str(claim.get("target_stage") or "") != target_stage:
        errors.append("target stage differs")
    if not alpha3._SHA256_HEX_RE.fullmatch(str(claim.get("input_state_sha256") or "").lower()):
        errors.append("input state identity is malformed")
    if not isinstance(claim.get("operator"), str) or not str(claim.get("operator") or "").strip():
        errors.append("operator is missing")
    if not isinstance(claim.get("claimed_utc"), str) or not str(claim.get("claimed_utc") or "").strip():
        errors.append("claim time is missing")
    if errors:
        raise RuntimeError(
            f"The superseded owner's {target_stage} transition claim is invalid: " + "; ".join(errors)
        )
    return claim


def recover_superseded_terminal_owner(
    owner_path: Path | str,
    *,
    operator: str,
    reason: str,
) -> dict[str, Any]:
    """Release only the alpha.8.5.3 stale-owner shape proven by immutable evidence.

    This narrow recovery exists for a terminal run whose valid lock was
    mistakenly replaced in the same UUID directory. It never releases a live,
    uncertain, nonterminal, or identity-mismatched runner.
    """
    path = Path(owner_path).expanduser().resolve(strict=False)
    operator_text = str(operator or "").strip()
    reason_text = str(reason or "").strip()
    if not reason_text:
        raise RuntimeError("Superseded-owner recovery requires a recorded reason.")
    with alpha3._active_acquisition_owner_guard(path.parent):
        owner = alpha3.load_json(path)
        errors = alpha3._validate_active_owner(owner)
        errors.extend(alpha3._active_owner_location_errors(owner, path))
        if errors:
            raise RuntimeError("The superseded active-acquisition owner is invalid: " + "; ".join(errors))
        core = owner["owner_core"]
        marker_path = Path(str(core.get("terminal_marker_path") or "")).expanduser().resolve(strict=False)
        if marker_path.is_file():
            marker = alpha3.load_json(marker_path)
            marker_errors = alpha3._active_owner_terminal_errors(marker, owner)
            if marker_errors:
                raise RuntimeError("The existing owner terminal record is invalid: " + "; ".join(marker_errors))
            return dict(owner)
        if str(owner.get("status") or "") != "LEASE_BOUND" or not isinstance(owner.get("lease_binding"), Mapping):
            raise RuntimeError("Superseded-owner recovery requires an exact LEASE_BOUND owner.")
        controller_state = alpha3._process_identity_state(
            int(core.get("controller_pid") or 0),
            str(core.get("controller_process_start_identity") or ""),
        )
        if controller_state != "DEAD":
            raise RuntimeError(
                "Superseded-owner recovery requires the exact owning Control Center process to be proven dead."
            )

        lock_path = Path(str(core.get("session_lock_path") or "")).expanduser().resolve(strict=False)
        current_lock = alpha3.load_json(lock_path)
        current_report = alpha3.validate_session_lock_identity(current_lock)
        if current_report.status == "INELIGIBLE":
            raise RuntimeError("The replacement runtime lock is invalid: " + "; ".join(current_report.errors))
        old_identity = str(core.get("lock_identity_sha256") or "")
        current_identity = str(current_lock.get("lock_identity_sha256") or "")
        if not current_identity or current_identity == old_identity:
            raise RuntimeError("The owner session lock was not superseded by a different valid lock identity.")
        current_session = current_lock.get("session", {})
        if not isinstance(current_session, Mapping) or str(current_session.get("session_id") or "") != str(core.get("run_uuid") or ""):
            raise RuntimeError("The replacement runtime lock is not bound to the owner's run UUID.")
        current_stage = str(current_lock.get("current_stage") or "")
        if current_stage not in {"PREFLIGHT", "ARM"}:
            raise RuntimeError("The replacement runtime lock is not a pre-ACQUIRE lock.")

        lease_path = Path(str(core.get("expected_lease_path") or "")).expanduser().resolve(strict=False)
        lease = alpha3.load_json(lease_path)
        lease_errors = alpha3._active_owner_lease_errors(owner, lease_path, lease)
        if lease_errors:
            raise RuntimeError("The superseded owner's runner lease is invalid: " + "; ".join(lease_errors))
        lease_activity = alpha3.runtime_runner_lease_activity(lease_path)
        if bool(lease_activity.get("active")):
            raise RuntimeError(
                "The superseded owner's runner remains active or uncertain: "
                + str(lease_activity.get("reason") or "")
            )
        if str(lease.get("status") or "") not in alpha3.RUNTIME_RUNNER_TERMINAL_STATES:
            raise RuntimeError("The superseded owner's runner lease is not terminal.")

        acquire_claim = _matching_transition_claim(lock_path, old_identity, "ACQUIRE")
        finalize_claim = _matching_transition_claim(lock_path, old_identity, "FINALIZE")
        recovery_operator = operator_text or str(finalize_claim.get("operator") or "").strip()
        if not recovery_operator:
            raise RuntimeError("Superseded-owner recovery has no recorded operator identity.")
        terminal_epoch = time.time()
        binding = owner["lease_binding"]
        marker = {
            "schema": alpha3.ACTIVE_ACQUISITION_OWNER_TERMINAL_SCHEMA,
            "owner_id": core.get("owner_id"),
            "owner_core_sha256": owner.get("owner_core_sha256"),
            "status": "RELEASED",
            "run_uuid": core.get("run_uuid"),
            "session_lock_path": core.get("session_lock_path"),
            "lock_stage": "FINALIZE",
            "lease_id": binding.get("lease_id"),
            "lease_core_sha256": binding.get("lease_core_sha256"),
            "terminal_epoch": terminal_epoch,
            "terminal_utc": alpha3.utc_now(),
            "reason": reason_text,
            "recovery": {
                "schema": "PRAYCG_SupersededTerminalOwnerRecovery_v1_0_alpha_8_5_3",
                "operator": recovery_operator,
                "old_lock_identity_sha256": old_identity,
                "replacement_lock_identity_sha256": current_identity,
                "replacement_lock_stage": current_stage,
                "runner_lease_status": lease.get("status"),
                "runner_activity_status": lease_activity.get("status"),
                "acquire_claim": dict(acquire_claim),
                "finalize_claim": dict(finalize_claim),
            },
        }
        marker["canonical_sha256"] = alpha3.sha256_json(marker)
        try:
            descriptor = os.open(str(marker_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
        except FileExistsError as exc:
            raise RuntimeError("Another process wrote the owner terminal record during recovery.") from exc
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(alpha3.canonical_json_bytes(marker) + b"\n")
            handle.flush()
            os.fsync(handle.fileno())
        owner.update({
            "status": "RELEASED",
            "terminal_epoch": terminal_epoch,
            "terminal_utc": marker["terminal_utc"],
            "terminal_reason": marker["reason"],
        })
        return alpha3._write_active_owner(path, owner)


def build_session_lock(
    session_draft: Mapping[str, Any],
    preflight_report: Mapping[str, Any],
    output_path: Path,
    *,
    operator: str,
    allow_caution_override: bool = False,
    override_reason: str = "",
) -> dict[str, Any]:
    """Build a lock and contain the alpha.8.5.3 bench bypass to BENCH_TEST sessions."""
    reuse_reasons = runtime_lock_reuse_reasons(output_path)
    if reuse_reasons:
        raise RuntimeError(
            "This acquisition UUID has already been used and its runtime lock cannot be replaced: "
            + "; ".join(reuse_reasons)
            + ". Start Another Equipment Session to allocate a fresh UUID."
        )
    lock = alpha3.build_session_lock(
        session_draft,
        preflight_report,
        output_path,
        operator=operator,
        allow_caution_override=allow_caution_override,
        override_reason=override_reason,
    )
    session = session_draft.get("session", {})
    session = session if isinstance(session, Mapping) else {}
    bypass_artifact = (
        preflight_report.get("artifact_type") == "BENCH_TEST_READINESS_BYPASS_PREFLIGHT"
        or preflight_report.get("bench_readiness_bypass_active") is True
    )
    bypass_errors: list[str] = []
    if bypass_artifact:
        if preflight_report.get("artifact_type") != "BENCH_TEST_READINESS_BYPASS_PREFLIGHT":
            bypass_errors.append("Bench readiness-bypass preflight has the wrong artifact type.")
        if preflight_report.get("bench_test_mode") is not True:
            bypass_errors.append("Bench readiness-bypass preflight is not labeled BENCH_TEST.")
        if preflight_report.get("participant_data_eligible") is not False:
            bypass_errors.append("Bench readiness-bypass preflight must be ineligible as participant data.")
        if session.get("bench_test_mode") is not True:
            bypass_errors.append("Participant sessions cannot use bench readiness-bypass preflight evidence.")
        if session.get("session_purpose") != "BENCH_TEST":
            bypass_errors.append("Bench readiness bypass requires session_purpose BENCH_TEST.")
        if session.get("participant_data_eligible") is not False:
            bypass_errors.append("Bench readiness bypass requires participant_data_eligible false.")
        if session.get("bench_readiness_bypass_active") is not True:
            bypass_errors.append("Bench readiness bypass must be explicit in the locked session metadata.")
    elif session.get("bench_readiness_bypass_active") is True:
        bypass_errors.append("Bench readiness-bypass session metadata is not backed by the dedicated bypass preflight artifact.")

    if bypass_errors:
        validation = lock.setdefault("validation", {"errors": [], "cautions": []})
        _append_unique(validation.setdefault("errors", []), bypass_errors)
        validation["status"] = "INELIGIBLE"
        lock["status"] = "NOT_LOCKABLE"
        lock["current_stage"] = "PREFLIGHT"
        lock["gate_status"] = {stage: "PENDING" for stage in alpha3.SESSION_STAGES}
        lock["runtime_history"] = []
        lock["state_sha256"] = alpha3._session_state_sha256(lock)
        write_json(Path(output_path), lock)
    return lock


def aggregate_hardware_preflight(
    hardware_profile: Mapping[str, Any],
    module_reports: Sequence[Mapping[str, Any]],
    *,
    expected_run_uuid: str = "",
) -> dict[str, Any]:
    report = alpha3.aggregate_hardware_preflight(
        hardware_profile,
        module_reports,
        expected_run_uuid=expected_run_uuid,
    )
    extra = validate_hardware_profile_identity(hardware_profile)
    _append_unique(report.setdefault("errors", []), extra.errors)
    _append_unique(report.setdefault("cautions", []), extra.cautions)
    report["status"] = "INELIGIBLE" if report["errors"] else ("CAUTION" if report["cautions"] else "PASS")
    report["platform_version"] = PLATFORM_VERSION
    report["canonical_sha256"] = alpha3._canonical_stored_hash(report)
    return report
