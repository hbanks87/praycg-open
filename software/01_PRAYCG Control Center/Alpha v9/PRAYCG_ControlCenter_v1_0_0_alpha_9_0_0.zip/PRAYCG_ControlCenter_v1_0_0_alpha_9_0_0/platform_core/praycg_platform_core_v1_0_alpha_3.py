#!/usr/bin/env python3
"""Canonical platform contracts and staged session gates for PRAYCG alpha.3.

Alpha.3 preserves the alpha.2 design-time/runtime authority contracts and adds
the declarative Protocol Atlas as a second, hardware-independent protocol
family. A runtime lock is not created until the complete selected
hardware profile has supplied acceptable live preflight evidence.  The module
uses only the Python standard library and keeps the alpha.1 API available in
its original module for carried tools.
"""
from __future__ import annotations

from copy import deepcopy
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
import csv
import hashlib
import os
import re
import sys
import time
import uuid
import zipfile

import praycg_platform_core_v1_0_alpha_1 as legacy
from praycg_platform_core_v1_0_alpha_1 import (  # compatibility re-exports
    ABSOLUTE_USER_PATH_RE,
    CANONICAL_ROLES,
    CLAIM_CLASSES,
    EMAIL_RE,
    HARDWARE_SCHEMA,
    PROTOCOL_SCHEMA,
    UNSAFE_TEXT_PATTERNS,
    ValidationReport,
    atomic_write_text,
    canonical_json_bytes,
    inventory_hashes,
    load_json,
    optional_dependency_status,
    protocol_timeline,
    resolved_within,
    safe_slug,
    scan_public_package,
    sha256_file,
    sha256_json,
    utc_now,
    validate_hardware_module,
    validate_protocol,
    write_json,
)

ATLAS_PROTOCOL_SCHEMA = "PRAYCG_ProtocolAtlasModule_v2_0"
ATLAS_CORE_DIR = Path(__file__).resolve().parents[1] / "tools" / "ProtocolAtlas_ModuleLibrary_v2_0" / "scripts"
if str(ATLAS_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(ATLAS_CORE_DIR))
try:
    from praycg_protocol_atlas_core_v2_0 import (  # type: ignore
        AtlasValidationError as AtlasProtocolValidationError,
        validate_protocol_module as validate_atlas_protocol_module,
    )
    ATLAS_CORE_IMPORT_ERROR = ""
except Exception as exc:  # pragma: no cover - operator-visible validation failure
    AtlasProtocolValidationError = ValueError  # type: ignore[assignment,misc]
    validate_atlas_protocol_module = None  # type: ignore[assignment]
    ATLAS_CORE_IMPORT_ERROR = f"{type(exc).__name__}: {exc}"


PLATFORM_VERSION = "1.0.0-alpha.3"
MODULE_REGISTRY_SCHEMA = "PRAYCG_ModuleRegistry_v1_0_alpha_3"
PROFILE_SCHEMA = "PRAYCG_HardwareProfile_v0_2"
LEGACY_PROFILE_SCHEMA = legacy.PROFILE_SCHEMA
SESSION_SCHEMA = "PRAYCG_StudySession_v0_2"
SESSION_TEMPLATE_SCHEMAS = {legacy.SESSION_SCHEMA, SESSION_SCHEMA}
PROTOCOL_SNAPSHOT_SCHEMA = "PRAYCG_ApprovedProtocolSnapshot_v0_2"
LEGACY_PROTOCOL_LOCK_SCHEMA = "PRAYCG_CompiledProtocolLock_v0_1"
SESSION_DRAFT_SCHEMA = "PRAYCG_RuntimeSessionDraft_v0_2"
SESSION_LOCK_SCHEMA = "PRAYCG_RuntimeSessionLock_v0_2"
LOCK_SCHEMA = SESSION_LOCK_SCHEMA

SESSION_STAGES = (
    "SELECT",
    "CONNECT",
    "PREFLIGHT",
    "SESSION_LOCK",
    "ARM",
    "ACQUIRE",
    "FINALIZE",
    "QC",
    "ANALYZE",
    "EXPORT",
    "VERIFY",
)
STAGES = SESSION_STAGES

_POST_LOCK_STAGE_PREDECESSOR = {
    "ARM": "SESSION_LOCK",
    "ACQUIRE": "ARM",
    "FINALIZE": "ACQUIRE",
    "QC": "FINALIZE",
    "ANALYZE": "QC",
    "EXPORT": "ANALYZE",
    "VERIFY": "EXPORT",
}

_STATUS_BY_STAGE = {
    "SESSION_LOCK": "LOCKED_READY_TO_ARM",
    "ARM": "ARMED",
    "ACQUIRE": "ACQUIRING",
    "FINALIZE": "FINALIZED",
    "QC": "QC_COMPLETE",
    "ANALYZE": "ANALYSIS_COMPLETE",
    "EXPORT": "EXPORT_COMPLETE",
    "VERIFY": "VERIFIED_COMPLETE",
}

AUTHORIZED_ACQUIRE_EVENT = "AUTHORIZED_RUNNER_PROCESS_CLAIMED_BEFORE_SPAWN"
SUPPORTED_DIRECT_RUNNER_LAUNCH_MODES = frozenset({"psychopy_python", "regular_python"})
_SHA256_HEX_RE = re.compile(r"^[0-9a-f]{64}$")
RUNTIME_RUNNER_LEASE_SCHEMA = "PRAYCG_AuthorizedRunnerLease_v1_0_alpha_2"
RUNTIME_RUNNER_LEASE_FILENAME = "authorized_runner_lease.json"
RUNTIME_RUNNER_CLAIM_MARKER_FILENAME = "authorized_runner_lease.claim_consumed.json"
RUNTIME_RUNNER_PROCESS_BINDING_FILENAME = "authorized_runner_lease.process_binding.json"
RUNTIME_RUNNER_EXIT_MARKER_FILENAME = "authorized_runner_lease.exit.json"
RUNTIME_RUNNER_TERMINAL_STATES = frozenset({"EXITED", "LAUNCH_FAILED", "CANCELLED"})
DEFAULT_RUNNER_CLAIM_TTL_SEC = 60.0
DEFAULT_RUNNER_HEARTBEAT_TIMEOUT_SEC = 15.0
ACTIVE_ACQUISITION_OWNER_SCHEMA = "PRAYCG_ActiveAcquisitionOwner_v1_0_alpha_2"
ACTIVE_ACQUISITION_OWNER_TERMINAL_SCHEMA = "PRAYCG_ActiveAcquisitionOwnerTerminal_v1_0_alpha_2"
ACTIVE_ACQUISITION_OWNER_FILENAME = "active_acquisition_owner.json"
ACTIVE_ACQUISITION_OWNER_GUARD_FILENAME = "active_acquisition_owner.guard.lock"
ACTIVE_ACQUISITION_OWNER_HISTORY_DIRNAME = "active_acquisition_owner_history"
ACTIVE_ACQUISITION_OWNER_TERMINAL_STATES = frozenset({"RELEASED", "CANCELLED"})


def normalized_path_identity(value: Path | str) -> str:
    """Return one cross-platform identity string for a possibly absent path."""
    path = Path(str(value)).expanduser().resolve(strict=False)
    return os.path.normcase(os.path.normpath(str(path)))


def paths_equivalent(left: Path | str, right: Path | str, *, require_existing: bool = False) -> bool:
    """Compare paths by filesystem identity first and normalized spelling second."""
    left_path = Path(str(left)).expanduser()
    right_path = Path(str(right)).expanduser()
    try:
        if left_path.exists() and right_path.exists():
            return os.path.samefile(left_path, right_path)
        if require_existing:
            return False
        return normalized_path_identity(left_path) == normalized_path_identity(right_path)
    except OSError:
        return False if require_existing else normalized_path_identity(left_path) == normalized_path_identity(right_path)


def runtime_claim_token_sha256(token: str) -> str:
    """Hash a raw, process-local launch token without persisting the token."""
    return hashlib.sha256(str(token).encode("utf-8")).hexdigest()


def active_acquisition_owner_path(log_root: Path | str) -> Path:
    """Return the one filesystem-wide owner-claim path for a Control Center log root."""
    return Path(log_root).expanduser().resolve(strict=False) / "protocol_runs" / ACTIVE_ACQUISITION_OWNER_FILENAME


@contextmanager
def _active_acquisition_owner_guard(protocol_runs_root: Path):
    """Serialize owner inspect/archive/create with an OS lock released on crash."""
    protocol_runs_root.mkdir(parents=True, exist_ok=True)
    guard_path = protocol_runs_root / ACTIVE_ACQUISITION_OWNER_GUARD_FILENAME
    handle = open(guard_path, "a+b")
    try:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(b"\0")
            handle.flush()
            os.fsync(handle.fileno())
        handle.seek(0)
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    finally:
        handle.close()


def process_start_identity(pid: int | None = None) -> str:
    """Return an OS process-start identity when the host exposes one safely."""
    process_id = int(pid if pid is not None else os.getpid())
    if process_id <= 0:
        return ""
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            process_query_limited_information = 0x1000
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.GetProcessTimes.argtypes = [
                wintypes.HANDLE,
                ctypes.POINTER(wintypes.FILETIME),
                ctypes.POINTER(wintypes.FILETIME),
                ctypes.POINTER(wintypes.FILETIME),
                ctypes.POINTER(wintypes.FILETIME),
            ]
            kernel32.GetProcessTimes.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL
            handle = kernel32.OpenProcess(
                process_query_limited_information, False, process_id
            )
            if not handle:
                return ""
            creation = wintypes.FILETIME()
            exit_time = wintypes.FILETIME()
            kernel = wintypes.FILETIME()
            user = wintypes.FILETIME()
            try:
                ok = kernel32.GetProcessTimes(
                    handle,
                    ctypes.byref(creation),
                    ctypes.byref(exit_time),
                    ctypes.byref(kernel),
                    ctypes.byref(user),
                )
                if not ok:
                    return ""
                value = (int(creation.dwHighDateTime) << 32) | int(creation.dwLowDateTime)
                return f"windows_filetime:{value}"
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return ""
    proc_stat = Path(f"/proc/{process_id}/stat")
    try:
        raw = proc_stat.read_text(encoding="utf-8")
        # Field 2 may contain spaces and parentheses.  Field 22 (starttime) is
        # index 19 after the final ')' that terminates the command field.
        fields_after_command = raw[raw.rfind(")") + 2:].split()
        if len(fields_after_command) > 19:
            return f"proc_start_ticks:{fields_after_command[19]}"
    except Exception:
        pass
    return ""


def _pid_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        # Python's os.kill(pid, 0) is not a reliable existence probe on
        # Windows.  Some supported Python builds raise SystemError with a
        # pending WinError 87 for a stale PID, which previously escaped this
        # function and broke every runtime-authority check in the GUI.  Query
        # the process handle directly and fail closed for indeterminate
        # Windows errors.
        try:
            import ctypes
            from ctypes import wintypes

            process_query_limited_information = 0x1000
            still_active = 259
            error_access_denied = 5
            dead_process_errors = {6, 87, 1168}
            kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
            kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
            kernel32.OpenProcess.restype = wintypes.HANDLE
            kernel32.GetExitCodeProcess.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
            kernel32.GetExitCodeProcess.restype = wintypes.BOOL
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL
            ctypes.set_last_error(0)
            handle = kernel32.OpenProcess(
                process_query_limited_information, False, int(pid)
            )
            if not handle:
                error = int(ctypes.get_last_error())
                if error == error_access_denied:
                    return True
                if error in dead_process_errors:
                    return False
                return True
            try:
                exit_code = wintypes.DWORD()
                if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                    return True
                return int(exit_code.value) == still_active
            finally:
                kernel32.CloseHandle(handle)
        except Exception:
            return True
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except (OSError, SystemError):
        return False
    return True


def _process_identity_state(pid: int, expected_start_identity: str) -> str:
    """Return LIVE, DEAD, MISMATCH, or UNKNOWN for one persisted process identity."""
    if not _pid_exists(int(pid)):
        return "DEAD"
    expected = str(expected_start_identity or "")
    if not expected:
        return "UNKNOWN"
    observed = process_start_identity(int(pid))
    if not observed:
        return "UNKNOWN"
    return "LIVE" if observed == expected else "MISMATCH"


def _runner_lease_state_sha256(lease: Mapping[str, Any]) -> str:
    return sha256_json({key: deepcopy(value) for key, value in lease.items() if key != "lease_state_sha256"})


def _validate_runner_lease(lease: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    if lease.get("schema") != RUNTIME_RUNNER_LEASE_SCHEMA:
        errors.append("authorized-runner lease schema is not recognized")
        return errors
    core = lease.get("lease_core")
    if not isinstance(core, Mapping):
        errors.append("authorized-runner lease core is malformed")
    elif lease.get("lease_core_sha256") != sha256_json(core):
        errors.append("authorized-runner lease core identity changed")
    else:
        required_text = (
            "lease_id", "run_uuid", "session_lock_path", "lock_identity_sha256",
            "armed_state_sha256", "controller_instance_id", "protocol_id",
            "protocol_version", "protocol_module_file_sha256", "runner_file_sha256",
            "engine_file_sha256", "stimulus_id", "stimulus_folder",
            "media_selection_sha256", "launch_mode", "launch_executable_path",
            "process_binding_path", "claim_token_sha256",
        )
        for field in required_text:
            if not isinstance(core.get(field), str) or not str(core.get(field)).strip():
                errors.append(f"authorized-runner lease core has missing or malformed {field}")
        for field in (
            "lock_identity_sha256", "armed_state_sha256", "protocol_module_file_sha256",
            "runner_file_sha256", "engine_file_sha256", "media_selection_sha256",
            "claim_token_sha256",
        ):
            value = str(core.get(field) or "").lower()
            if value and not _SHA256_HEX_RE.fullmatch(value):
                errors.append(f"authorized-runner lease core {field} is not a SHA-256 digest")
        if str(core.get("launch_mode") or "") not in SUPPORTED_DIRECT_RUNNER_LAUNCH_MODES:
            errors.append("authorized-runner lease core launch_mode is unsupported")
        if not isinstance(core.get("launch_command"), list) or not core.get("launch_command"):
            errors.append("authorized-runner lease core launch_command is malformed")
        try:
            if float(core.get("claim_expires_epoch")) <= float(core.get("issued_epoch")):
                errors.append("authorized-runner lease claim expiry is not after issue time")
            if float(core.get("heartbeat_timeout_sec")) < 3.0:
                errors.append("authorized-runner lease heartbeat timeout is invalid")
            if int(core.get("controller_pid")) <= 0:
                errors.append("authorized-runner lease controller PID is invalid")
        except (TypeError, ValueError):
            errors.append("authorized-runner lease timing or controller identity is malformed")
    status = str(lease.get("status") or "")
    if status not in {"CLAIM_ISSUED", "ACTIVE", *RUNTIME_RUNNER_TERMINAL_STATES}:
        errors.append("authorized-runner lease status is not recognized")
    if status == "ACTIVE":
        try:
            if int(lease.get("pid") or 0) <= 0 or float(lease.get("heartbeat_epoch") or 0.0) <= 0:
                errors.append("ACTIVE authorized-runner lease lacks PID or heartbeat evidence")
        except (TypeError, ValueError):
            errors.append("ACTIVE authorized-runner lease PID or heartbeat is malformed")
    stored_state = str(lease.get("lease_state_sha256") or "")
    if not _SHA256_HEX_RE.fullmatch(stored_state) or stored_state != _runner_lease_state_sha256(lease):
        errors.append("authorized-runner lease state identity changed")
    return errors


def _write_runner_lease(path: Path, lease: Mapping[str, Any]) -> dict[str, Any]:
    payload = deepcopy(dict(lease))
    payload["lease_state_sha256"] = _runner_lease_state_sha256(payload)
    write_json(path, payload)
    return payload


def _canonical_record_errors(
    record: Mapping[str, Any],
    *,
    schema: str,
    label: str,
) -> list[str]:
    errors: list[str] = []
    if record.get("schema") != schema:
        errors.append(f"{label} schema is not recognized")
    stored = str(record.get("canonical_sha256") or "")
    calculated = sha256_json({key: value for key, value in record.items() if key != "canonical_sha256"})
    if not _SHA256_HEX_RE.fullmatch(stored) or stored != calculated:
        errors.append(f"{label} canonical identity changed")
    return errors


def _load_runner_process_binding(
    lease_path: Path,
    lease: Mapping[str, Any],
) -> tuple[dict[str, Any] | None, list[str]]:
    core = lease.get("lease_core", {})
    expected_path = lease_path.with_name(RUNTIME_RUNNER_PROCESS_BINDING_FILENAME)
    configured_path = Path(str(core.get("process_binding_path") or "")).expanduser().resolve(strict=False) if isinstance(core, Mapping) else Path()
    if not paths_equivalent(configured_path, expected_path, require_existing=False):
        return None, ["runner process-binding path is not the run-local canonical path"]
    if not expected_path.is_file():
        return None, []
    try:
        binding = load_json(expected_path)
    except Exception as exc:
        return None, [f"runner process binding is unreadable: {exc}"]
    if not isinstance(binding, Mapping):
        return None, ["runner process binding is malformed"]
    errors = _canonical_record_errors(
        binding,
        schema="PRAYCG_AuthorizedRunnerProcessBinding_v1_0_alpha_2",
        label="runner process binding",
    )
    if binding.get("lease_id") != core.get("lease_id") or binding.get("lease_core_sha256") != lease.get("lease_core_sha256"):
        errors.append("runner process binding belongs to another lease")
    try:
        if int(binding.get("pid") or 0) <= 0:
            errors.append("runner process binding PID is invalid")
    except (TypeError, ValueError):
        errors.append("runner process binding PID is malformed")
    if not isinstance(binding.get("process_start_identity"), str):
        errors.append("runner process binding start identity is malformed")
    return dict(binding), errors


def _load_runner_consumption_marker(
    lease_path: Path,
    lease: Mapping[str, Any],
    binding: Mapping[str, Any] | None,
) -> tuple[dict[str, Any] | None, list[str]]:
    marker_path = lease_path.with_name(RUNTIME_RUNNER_CLAIM_MARKER_FILENAME)
    if not marker_path.is_file():
        return None, []
    try:
        marker = load_json(marker_path)
    except Exception as exc:
        return None, [f"runner claim-consumption marker is unreadable: {exc}"]
    if not isinstance(marker, Mapping):
        return None, ["runner claim-consumption marker is malformed"]
    errors = _canonical_record_errors(
        marker,
        schema="PRAYCG_AuthorizedRunnerLeaseClaimConsumption_v1_0_alpha_2",
        label="runner claim-consumption marker",
    )
    core = lease.get("lease_core", {})
    exact = {
        "lease_core_sha256": (marker.get("lease_core_sha256"), lease.get("lease_core_sha256")),
        "claim_token_sha256": (marker.get("claim_token_sha256"), core.get("claim_token_sha256") if isinstance(core, Mapping) else None),
        "process_binding_sha256": (marker.get("process_binding_sha256"), binding.get("canonical_sha256") if isinstance(binding, Mapping) else None),
        "pid": (marker.get("pid"), binding.get("pid") if isinstance(binding, Mapping) else None),
        "process_start_identity": (
            marker.get("process_start_identity"),
            binding.get("process_start_identity") if isinstance(binding, Mapping) else None,
        ),
    }
    for field, (observed, expected) in exact.items():
        if observed != expected:
            errors.append(f"runner claim-consumption marker {field} does not match its binding")
    try:
        if int(marker.get("pid") or 0) <= 0:
            errors.append("runner claim-consumption marker PID is invalid")
    except (TypeError, ValueError):
        errors.append("runner claim-consumption marker PID is malformed")
    return dict(marker), errors


def _runner_exit_record_errors(
    record: Mapping[str, Any],
    lease: Mapping[str, Any],
) -> list[str]:
    errors = _canonical_record_errors(
        record,
        schema="PRAYCG_AuthorizedRunnerLeaseExit_v1_0_alpha_2",
        label="runner lease exit record",
    )
    core = lease.get("lease_core", {})
    if record.get("lease_core_sha256") != lease.get("lease_core_sha256"):
        errors.append("runner lease exit record core identity mismatch")
    expected_lease_id = core.get("lease_id") if isinstance(core, Mapping) else None
    if record.get("lease_id") != expected_lease_id:
        errors.append("runner lease exit record lease_id mismatch")
    terminal = str(record.get("status") or "")
    if terminal not in RUNTIME_RUNNER_TERMINAL_STATES:
        errors.append("runner lease exit record status is not terminal")
    try:
        if float(record.get("exit_epoch") or 0.0) <= 0.0:
            errors.append("runner lease exit record timestamp is invalid")
    except (TypeError, ValueError):
        errors.append("runner lease exit record timestamp is malformed")
    if not isinstance(record.get("exit_utc"), str) or not str(record.get("exit_utc") or "").strip():
        errors.append("runner lease exit record UTC time is missing")
    if not isinstance(record.get("exit_reason"), str) or not str(record.get("exit_reason") or "").strip():
        errors.append("runner lease exit record reason is missing")
    pid_value = record.get("pid")
    if pid_value is not None:
        try:
            if int(pid_value) <= 0:
                errors.append("runner lease exit record PID is invalid")
        except (TypeError, ValueError):
            errors.append("runner lease exit record PID is malformed")
    return errors


def issue_authorized_runner_lease(
    session_lock: Mapping[str, Any],
    session_lock_path: Path | str,
    claim_token: str,
    *,
    launch_mode: str,
    launch_command: Sequence[str],
    controller_instance_id: str,
    controller_pid: int,
    claim_ttl_sec: float = DEFAULT_RUNNER_CLAIM_TTL_SEC,
    heartbeat_timeout_sec: float = DEFAULT_RUNNER_HEARTBEAT_TIMEOUT_SEC,
) -> tuple[Path, dict[str, Any]]:
    """Exclusively issue the one-use, run-local lease for an authorized child."""
    validation = validate_session_lock_identity(session_lock)
    if validation.status == "INELIGIBLE":
        raise ValueError("Cannot issue runner lease for an invalid session lock: " + "; ".join(validation.errors))
    if str(session_lock.get("current_stage") or "") != "ARM":
        raise ValueError("An authorized-runner lease may be issued only from the ARM stage.")
    token = str(claim_token or "")
    if len(token) < 32:
        raise ValueError("Authorized-runner claim token must contain at least 32 characters.")
    if str(launch_mode or "") not in SUPPORTED_DIRECT_RUNNER_LAUNCH_MODES:
        raise ValueError("Authorized-runner lease launch mode is not a supported direct execution mode.")
    if int(controller_pid) <= 0:
        raise ValueError("Authorized-runner lease requires a valid issuing Control Center PID.")
    session = session_lock.get("session", {})
    run_uuid = str(session.get("session_id") or "").strip() if isinstance(session, Mapping) else ""
    session_log_dir = str(session.get("private_output_locations", {}).get("session_log_dir") or "") if isinstance(session, Mapping) else ""
    if not run_uuid or not session_log_dir:
        raise ValueError("The runtime session lock lacks its run UUID or run-local artifact directory.")
    artifact_root = Path(session_log_dir).expanduser().resolve(strict=False)
    lock_path = Path(session_lock_path).expanduser().resolve(strict=False)
    if not paths_equivalent(lock_path.parent, artifact_root, require_existing=True):
        raise ValueError("The runtime session lock and authorized-runner lease must share the locked run-local artifact directory.")
    lease_path = artifact_root / RUNTIME_RUNNER_LEASE_FILENAME
    if lease_path.exists():
        activity = runtime_runner_lease_activity(lease_path)
        raise ValueError(
            "This run already has an authorized-runner lease "
            f"({activity.get('status')}: {activity.get('reason')}). A claim token is one-use."
        )
    now_epoch = time.time()
    protocol = session_lock.get("lock_core", {}).get("selection_identity", {}).get("protocol", {})
    if not isinstance(protocol, Mapping):
        raise ValueError("The runtime session lock lacks its approved protocol identity.")
    command = [str(value) for value in launch_command]
    if not command:
        raise ValueError("The authorized-runner lease requires the exact launch command.")
    executable_path = Path(command[0]).expanduser().resolve(strict=False)
    executable_sha256 = sha256_file(executable_path) if executable_path.is_file() else ""
    media_selection = session.get("media_selection_snapshot", {})
    stimulus_folder = str(session.get("stimulus_folder") or "")
    if not isinstance(media_selection, Mapping) or not media_selection or not stimulus_folder:
        raise ValueError("The runtime session lock lacks its exact stimulus/media selection.")
    process_binding_path = artifact_root / RUNTIME_RUNNER_PROCESS_BINDING_FILENAME
    lease_core = {
        "lease_id": str(uuid.uuid4()),
        "run_uuid": run_uuid,
        "session_lock_path": normalized_path_identity(lock_path),
        "lock_identity_sha256": str(session_lock.get("lock_identity_sha256") or ""),
        "armed_state_sha256": str(session_lock.get("state_sha256") or ""),
        "controller_instance_id": str(controller_instance_id or ""),
        "controller_pid": int(controller_pid),
        "controller_process_start_identity": process_start_identity(int(controller_pid)),
        "protocol_id": str(protocol.get("protocol_id") or ""),
        "protocol_version": str(protocol.get("protocol_version") or ""),
        "protocol_module_file_sha256": str(protocol.get("protocol_module_file_sha256") or ""),
        "runner_file_sha256": str(protocol.get("runner_file_sha256") or ""),
        "engine_file_sha256": str(protocol.get("engine_file_sha256") or ""),
        "stimulus_id": str(session.get("stimulus_id") or ""),
        "stimulus_folder": normalized_path_identity(stimulus_folder),
        "media_selection_sha256": sha256_json(media_selection),
        "launch_mode": str(launch_mode or ""),
        "launch_command": command,
        "launch_executable_path": normalized_path_identity(executable_path),
        "launch_executable_sha256": executable_sha256,
        "process_binding_path": normalized_path_identity(process_binding_path),
        "claim_token_sha256": runtime_claim_token_sha256(token),
        "issued_epoch": now_epoch,
        "issued_utc": utc_now(),
        "claim_expires_epoch": now_epoch + max(5.0, float(claim_ttl_sec)),
        "heartbeat_timeout_sec": max(3.0, float(heartbeat_timeout_sec)),
    }
    required_core_text = (
        "controller_instance_id", "protocol_id", "protocol_version",
        "protocol_module_file_sha256", "runner_file_sha256", "engine_file_sha256",
        "stimulus_id", "launch_mode",
    )
    missing_core = [key for key in required_core_text if not str(lease_core.get(key) or "").strip()]
    if missing_core:
        raise ValueError("The authorized-runner lease cannot bind missing fields: " + ", ".join(missing_core) + ".")
    lease: dict[str, Any] = {
        "schema": RUNTIME_RUNNER_LEASE_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "lease_core": lease_core,
        "lease_core_sha256": sha256_json(lease_core),
        "status": "CLAIM_ISSUED",
        "pid": None,
        "process_start_identity": "",
        "consumed_epoch": None,
        "consumed_utc": None,
        "heartbeat_epoch": None,
        "heartbeat_utc": None,
        "exit_epoch": None,
        "exit_utc": None,
        "exit_reason": "",
        "exit_code": None,
    }
    lease["lease_state_sha256"] = _runner_lease_state_sha256(lease)
    artifact_root.mkdir(parents=True, exist_ok=True)
    try:
        descriptor = os.open(str(lease_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError as exc:
        raise ValueError("This run already has an authorized-runner lease; do not launch it twice.") from exc
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(canonical_json_bytes(lease) + b"\n")
        handle.flush()
        os.fsync(handle.fileno())
    return lease_path, lease


def bind_authorized_runner_lease_process(
    lease_path: Path | str,
    *,
    pid: int,
) -> dict[str, Any]:
    """Exclusively bind the issued bearer capability to the spawned child."""
    path = Path(lease_path).expanduser().resolve(strict=False)
    lease = load_json(path)
    errors = _validate_runner_lease(lease)
    if errors:
        raise RuntimeError("The authorized-runner lease is invalid: " + "; ".join(errors))
    if str(lease.get("status") or "") != "CLAIM_ISSUED":
        raise RuntimeError("The authorized-runner process may be bound only while its claim is unconsumed.")
    core = lease["lease_core"]
    binding_path = Path(str(core.get("process_binding_path") or "")).expanduser().resolve(strict=False)
    expected = path.with_name(RUNTIME_RUNNER_PROCESS_BINDING_FILENAME)
    if normalized_path_identity(binding_path) != normalized_path_identity(expected):
        raise RuntimeError("The authorized-runner process-binding path is not run-local.")
    binding = {
        "schema": "PRAYCG_AuthorizedRunnerProcessBinding_v1_0_alpha_2",
        "lease_id": core.get("lease_id"),
        "lease_core_sha256": lease.get("lease_core_sha256"),
        "pid": int(pid),
        "process_start_identity": process_start_identity(int(pid)),
        "bound_epoch": time.time(),
        "bound_utc": utc_now(),
    }
    binding["canonical_sha256"] = sha256_json(binding)
    try:
        descriptor = os.open(str(binding_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError as exc:
        raise RuntimeError("The authorized-runner process was already bound; do not spawn a second child.") from exc
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(canonical_json_bytes(binding) + b"\n")
        handle.flush()
        os.fsync(handle.fileno())
    return binding


def consume_authorized_runner_lease(
    lease_path: Path | str,
    claim_token: str,
    *,
    expected_lock_path: Path | str,
    expected_run_uuid: str,
) -> dict[str, Any]:
    """Atomically consume the launch token and bind the lease to this process."""
    path = Path(lease_path).expanduser().resolve(strict=False)
    lease = load_json(path)
    errors = _validate_runner_lease(lease)
    if errors:
        raise RuntimeError("The authorized-runner lease is invalid: " + "; ".join(errors))
    core = lease["lease_core"]
    if str(lease.get("status") or "") != "CLAIM_ISSUED":
        raise RuntimeError("The authorized-runner claim token has already been consumed or closed.")
    if time.time() > float(core.get("claim_expires_epoch") or 0.0):
        raise RuntimeError("The authorized-runner claim token expired before the child consumed it.")
    if runtime_claim_token_sha256(str(claim_token or "")) != str(core.get("claim_token_sha256") or ""):
        raise RuntimeError("The authorized-runner claim token does not match the issued lease.")
    if str(expected_run_uuid or "") != str(core.get("run_uuid") or ""):
        raise RuntimeError("The authorized-runner lease belongs to a different run UUID.")
    if not paths_equivalent(expected_lock_path, str(core.get("session_lock_path") or ""), require_existing=True):
        raise RuntimeError("The authorized-runner lease belongs to a different runtime session lock.")
    canonical_lease_path = Path(expected_lock_path).expanduser().resolve(strict=False).parent / RUNTIME_RUNNER_LEASE_FILENAME
    if not paths_equivalent(path, canonical_lease_path, require_existing=True):
        raise RuntimeError("The authorized-runner lease is not the canonical run-local lease bound to the session lock.")
    binding_path = Path(str(core.get("process_binding_path") or "")).expanduser().resolve(strict=False)
    wait_deadline = min(float(core.get("claim_expires_epoch") or 0.0), time.time() + 10.0)
    while not binding_path.is_file() and time.time() < wait_deadline:
        time.sleep(0.02)
    if not binding_path.is_file():
        raise RuntimeError("The issuing Control Center did not bind the authorized runner to a child process.")
    binding = load_json(binding_path)
    binding_hash = str(binding.get("canonical_sha256") or "")
    if binding_hash != sha256_json({key: value for key, value in binding.items() if key != "canonical_sha256"}):
        raise RuntimeError("The authorized-runner process binding identity changed.")
    if binding.get("lease_id") != core.get("lease_id") or binding.get("lease_core_sha256") != lease.get("lease_core_sha256"):
        raise RuntimeError("The authorized-runner process binding belongs to another lease.")
    marker_path = path.with_name(RUNTIME_RUNNER_CLAIM_MARKER_FILENAME)
    pid = os.getpid()
    start_identity = process_start_identity(pid)
    if int(binding.get("pid") or 0) != pid:
        raise RuntimeError("This process is not the child PID selected by the issuing Control Center.")
    bound_start = str(binding.get("process_start_identity") or "")
    if bound_start and start_identity and bound_start != start_identity:
        raise RuntimeError("This process start identity does not match the issuing Control Center binding.")
    consumed_epoch = time.time()
    marker = {
        "schema": "PRAYCG_AuthorizedRunnerLeaseClaimConsumption_v1_0_alpha_2",
        "lease_core_sha256": lease.get("lease_core_sha256"),
        "process_binding_sha256": binding_hash,
        "claim_token_sha256": core.get("claim_token_sha256"),
        "pid": pid,
        "process_start_identity": start_identity,
        "consumed_epoch": consumed_epoch,
        "consumed_utc": utc_now(),
    }
    marker["canonical_sha256"] = sha256_json(marker)
    try:
        descriptor = os.open(str(marker_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError as exc:
        raise RuntimeError("The authorized-runner claim token was already consumed by another process.") from exc
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(canonical_json_bytes(marker) + b"\n")
        handle.flush()
        os.fsync(handle.fileno())
    lease.update({
        "status": "ACTIVE",
        "pid": pid,
        "process_start_identity": start_identity,
        "consumed_epoch": consumed_epoch,
        "consumed_utc": marker["consumed_utc"],
        "heartbeat_epoch": consumed_epoch,
        "heartbeat_utc": marker["consumed_utc"],
    })
    return _write_runner_lease(path, lease)


def refresh_authorized_runner_lease(
    lease_path: Path | str,
    *,
    pid: int,
    start_identity: str,
) -> dict[str, Any]:
    """Refresh an ACTIVE lease only for the process that consumed its token."""
    path = Path(lease_path).expanduser().resolve(strict=False)
    lease = load_json(path)
    errors = _validate_runner_lease(lease)
    if errors:
        raise RuntimeError("The authorized-runner lease is invalid: " + "; ".join(errors))
    if str(lease.get("status") or "") != "ACTIVE":
        raise RuntimeError("Only an ACTIVE authorized-runner lease can be refreshed.")
    if int(lease.get("pid") or 0) != int(pid):
        raise RuntimeError("Authorized-runner lease PID does not match the heartbeat process.")
    recorded_start = str(lease.get("process_start_identity") or "")
    if recorded_start and str(start_identity or "") != recorded_start:
        raise RuntimeError("Authorized-runner process-start identity changed.")
    lease["heartbeat_epoch"] = time.time()
    lease["heartbeat_utc"] = utc_now()
    return _write_runner_lease(path, lease)


def finish_authorized_runner_lease(
    lease_path: Path | str,
    *,
    status: str = "EXITED",
    reason: str,
    exit_code: int | None = None,
    pid: int | None = None,
    start_identity: str = "",
    allow_unconsumed: bool = False,
) -> dict[str, Any]:
    """Persist a terminal lease state after child exit or failed process spawn."""
    terminal = str(status).upper()
    if terminal not in RUNTIME_RUNNER_TERMINAL_STATES:
        raise ValueError("Runner lease terminal status must be EXITED, LAUNCH_FAILED, or CANCELLED.")
    path = Path(lease_path).expanduser().resolve(strict=False)
    lease = load_json(path)
    errors = _validate_runner_lease(lease)
    if errors:
        raise RuntimeError("The authorized-runner lease is invalid: " + "; ".join(errors))
    current = str(lease.get("status") or "")
    exit_marker_path = path.with_name(RUNTIME_RUNNER_EXIT_MARKER_FILENAME)
    if current in RUNTIME_RUNNER_TERMINAL_STATES:
        if current != terminal:
            raise RuntimeError(f"Runner lease already ended as {current}; it cannot be overwritten as {terminal}.")
        if not exit_marker_path.is_file():
            raise RuntimeError("Runner lease terminal state lacks its immutable exit record.")
        existing = load_json(exit_marker_path)
        existing_errors = _runner_exit_record_errors(existing, lease)
        if existing_errors:
            raise RuntimeError("Runner lease terminal record is invalid: " + "; ".join(existing_errors))
        if str(existing.get("status") or "") != terminal:
            raise RuntimeError("Runner lease terminal record conflicts with its mutable state.")
        return lease
    if current == "CLAIM_ISSUED" and not allow_unconsumed:
        raise RuntimeError("An unconsumed runner lease may be closed only by the issuing Control Center.")
    if current not in {"CLAIM_ISSUED", "ACTIVE"}:
        raise RuntimeError(f"Runner lease has unsupported state {current!r}.")
    if current == "ACTIVE":
        if pid is None or int(pid) <= 0:
            raise RuntimeError("Closing an ACTIVE runner lease requires the exact exiting process PID.")
        if int(lease.get("pid") or 0) != int(pid):
            raise RuntimeError("Runner lease PID does not match the exiting process.")
        recorded_start = str(lease.get("process_start_identity") or "")
        if recorded_start:
            if not str(start_identity or ""):
                raise RuntimeError("Closing an ACTIVE runner lease requires its nonblank process-start identity.")
            if recorded_start != str(start_identity):
                raise RuntimeError("Runner lease process-start identity does not match the exiting process.")
    elif allow_unconsumed:
        binding, binding_errors = _load_runner_process_binding(path, lease)
        if binding_errors:
            raise RuntimeError("Unconsumed runner process binding is invalid: " + "; ".join(binding_errors))
        if binding is not None:
            identity_state = _process_identity_state(
                int(binding.get("pid") or 0),
                str(binding.get("process_start_identity") or ""),
            )
            if identity_state in {"LIVE", "UNKNOWN"}:
                raise RuntimeError("The bound runner child may still be active; its unconsumed lease cannot be closed.")
            if pid is None:
                pid = int(binding.get("pid") or 0)
            if not start_identity:
                start_identity = str(binding.get("process_start_identity") or "")
    exit_epoch = time.time()
    exit_marker = {
        "schema": "PRAYCG_AuthorizedRunnerLeaseExit_v1_0_alpha_2",
        "lease_id": lease.get("lease_core", {}).get("lease_id"),
        "lease_core_sha256": lease.get("lease_core_sha256"),
        "status": terminal,
        "pid": int(pid) if pid is not None else lease.get("pid"),
        "process_start_identity": str(start_identity or lease.get("process_start_identity") or ""),
        "exit_epoch": exit_epoch,
        "exit_utc": utc_now(),
        "exit_reason": str(reason or "unspecified"),
        "exit_code": exit_code,
    }
    exit_marker["canonical_sha256"] = sha256_json(exit_marker)
    try:
        descriptor = os.open(str(exit_marker_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError as exc:
        try:
            existing = load_json(exit_marker_path)
        except Exception:
            existing = {}
        existing_errors = _runner_exit_record_errors(existing, lease) if isinstance(existing, Mapping) else ["exit record is malformed"]
        if not existing_errors and existing.get("status") == terminal:
            if current == "ACTIVE":
                if int(existing.get("pid") or 0) != int(pid or 0):
                    raise RuntimeError("Existing runner exit record PID conflicts with the ACTIVE lease.") from exc
                recorded_start = str(lease.get("process_start_identity") or "")
                if recorded_start and str(existing.get("process_start_identity") or "") != recorded_start:
                    raise RuntimeError("Existing runner exit record start identity conflicts with the ACTIVE lease.") from exc
            lease.update({
                "status": terminal,
                "exit_epoch": existing.get("exit_epoch"),
                "exit_utc": existing.get("exit_utc"),
                "exit_reason": existing.get("exit_reason"),
                "exit_code": existing.get("exit_code"),
            })
            return _write_runner_lease(path, lease)
        raise RuntimeError("A conflicting authorized-runner exit record already exists.") from exc
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(canonical_json_bytes(exit_marker) + b"\n")
        handle.flush()
        os.fsync(handle.fileno())
    lease.update({
        "status": terminal,
        "exit_epoch": exit_epoch,
        "exit_utc": exit_marker["exit_utc"],
        "exit_reason": exit_marker["exit_reason"],
        "exit_code": exit_code,
    })
    return _write_runner_lease(path, lease)


def runtime_runner_lease_activity(
    lease_path: Path | str,
    *,
    now_epoch: float | None = None,
) -> dict[str, Any]:
    """Classify persistent authority conservatively for overlap/recovery gates."""
    path = Path(lease_path).expanduser().resolve(strict=False)
    if not path.is_file():
        return {"active": False, "status": "MISSING", "reason": "lease file is absent", "path": str(path)}
    try:
        lease = load_json(path)
    except Exception as exc:
        return {"active": True, "status": "INVALID", "reason": f"lease is unreadable: {exc}", "path": str(path)}
    errors = _validate_runner_lease(lease)
    if errors:
        return {"active": True, "status": "INVALID", "reason": "; ".join(errors), "path": str(path)}
    status = str(lease.get("status") or "UNKNOWN")
    now_value = float(time.time() if now_epoch is None else now_epoch)
    exit_marker_path = path.with_name(RUNTIME_RUNNER_EXIT_MARKER_FILENAME)
    if exit_marker_path.is_file():
        try:
            exit_marker = load_json(exit_marker_path)
            record_errors = _runner_exit_record_errors(exit_marker, lease)
            if record_errors:
                raise ValueError("; ".join(record_errors))
            if status == "ACTIVE":
                if int(exit_marker.get("pid") or 0) != int(lease.get("pid") or 0):
                    raise ValueError("exit marker PID does not match the ACTIVE lease")
                recorded_start = str(lease.get("process_start_identity") or "")
                if recorded_start and str(exit_marker.get("process_start_identity") or "") != recorded_start:
                    raise ValueError("exit marker process-start identity does not match the ACTIVE lease")
            marker_pid = int(exit_marker.get("pid") or 0)
            marker_start = str(exit_marker.get("process_start_identity") or "")
            marker_identity_state = _process_identity_state(marker_pid, marker_start) if marker_pid > 0 else "DEAD"
            if marker_identity_state == "LIVE":
                return {"active": True, "status": str(exit_marker.get("status") or status), "reason": "terminal record exists but its matching runner process is still alive", "path": str(path)}
            if marker_identity_state == "UNKNOWN":
                return {"active": True, "status": "IDENTITY_UNCERTAIN", "reason": "terminal record exists but its runner process identity cannot be verified", "path": str(path)}
            # A hash-valid terminal record is written by the exact bound child.
            # Once that PID/start identity is proved dead, an earlier heartbeat
            # cannot represent continuing authority. Keeping the heartbeat grace
            # here created a cleanup race: the Control Center observed the child
            # exit but could not release the global owner until a later retry.
        except Exception as exc:
            return {"active": True, "status": "INVALID", "reason": f"lease exit record is invalid: {exc}", "path": str(path)}
        return {"active": False, "status": str(exit_marker.get("status") or "EXITED"), "reason": "lease has an immutable terminal exit record", "path": str(path)}
    if status in RUNTIME_RUNNER_TERMINAL_STATES:
        return {"active": True, "status": "INVALID", "reason": "terminal lease state lacks its immutable exit record", "path": str(path)}
    core = lease.get("lease_core", {})
    binding, binding_errors = _load_runner_process_binding(path, lease)
    if binding_errors:
        return {"active": True, "status": "INVALID", "reason": "; ".join(binding_errors), "path": str(path)}
    marker, marker_errors = _load_runner_consumption_marker(path, lease, binding)
    if marker_errors:
        return {"active": True, "status": "CLAIM_CONSUMPTION_UNCERTAIN", "reason": "; ".join(marker_errors), "path": str(path)}
    if status == "ACTIVE" and (binding is None or marker is None):
        return {"active": True, "status": "INVALID", "reason": "ACTIVE lease lacks its process binding or claim-consumption record", "path": str(path)}
    identity_record = marker or binding
    pid = int(identity_record.get("pid") or 0) if isinstance(identity_record, Mapping) else int(lease.get("pid") or 0)
    start_identity = str(identity_record.get("process_start_identity") or "") if isinstance(identity_record, Mapping) else str(lease.get("process_start_identity") or "")
    identity_state = _process_identity_state(pid, start_identity) if pid > 0 else "DEAD"
    try:
        heartbeat_epoch = float(lease.get("heartbeat_epoch") or lease.get("consumed_epoch") or 0.0)
        heartbeat_timeout = float(core.get("heartbeat_timeout_sec") or DEFAULT_RUNNER_HEARTBEAT_TIMEOUT_SEC)
    except (TypeError, ValueError) as exc:
        return {"active": True, "status": "INVALID", "reason": f"runner heartbeat metadata is malformed: {exc}", "path": str(path)}
    if heartbeat_epoch > now_value + 2.0:
        return {"active": True, "status": "INVALID", "reason": "runner heartbeat timestamp is implausibly in the future", "path": str(path)}
    heartbeat_fresh = heartbeat_epoch > 0 and 0.0 <= now_value - heartbeat_epoch <= heartbeat_timeout
    if identity_state == "LIVE":
        return {"active": True, "status": status, "reason": "matching runner PID/process-start identity is alive", "path": str(path)}
    if identity_state == "UNKNOWN":
        return {"active": True, "status": "IDENTITY_UNCERTAIN", "reason": "runner PID exists but process-start identity cannot be verified", "path": str(path)}
    if heartbeat_fresh:
        return {"active": True, "status": status, "reason": "runner heartbeat is still fresh", "path": str(path)}
    if status == "CLAIM_ISSUED" and marker is None:
        expires = float(core.get("claim_expires_epoch") or 0.0)
        if now_value <= expires:
            reason = "bound child is no longer the recorded process; claim remains within its consumption window" if binding is not None else "one-use child claim is awaiting process binding and consumption"
            return {"active": True, "status": status, "reason": reason, "path": str(path)}
        reason = "bound child is dead or its PID was reused, and the unconsumed claim expired" if binding is not None else "unbound child claim expired"
        return {"active": False, "status": "EXPIRED", "reason": reason, "path": str(path)}
    return {"active": False, "status": "EXPIRED", "reason": "heartbeat expired and no matching live process remains", "path": str(path)}


def _active_owner_state_sha256(owner: Mapping[str, Any]) -> str:
    return sha256_json({key: deepcopy(value) for key, value in owner.items() if key != "owner_state_sha256"})


def _validate_active_owner(owner: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    if owner.get("schema") != ACTIVE_ACQUISITION_OWNER_SCHEMA:
        return ["active-acquisition owner schema is not recognized"]
    core = owner.get("owner_core")
    if not isinstance(core, Mapping):
        errors.append("active-acquisition owner core is malformed")
    elif owner.get("owner_core_sha256") != sha256_json(core):
        errors.append("active-acquisition owner core identity changed")
    else:
        required_text = (
            "owner_id", "protocol_runs_root", "run_uuid", "session_lock_path",
            "lock_identity_sha256", "armed_state_sha256", "expected_lease_path",
            "controller_instance_id", "terminal_marker_path", "claimed_utc",
        )
        for field in required_text:
            if not isinstance(core.get(field), str) or not str(core.get(field) or "").strip():
                errors.append(f"active-acquisition owner core has missing or malformed {field}")
        if not isinstance(core.get("controller_process_start_identity"), str):
            errors.append("active-acquisition owner controller process-start identity is malformed")
        for field in ("lock_identity_sha256", "armed_state_sha256"):
            if not _SHA256_HEX_RE.fullmatch(str(core.get(field) or "").lower()):
                errors.append(f"active-acquisition owner core {field} is not a SHA-256 digest")
        try:
            if int(core.get("controller_pid") or 0) <= 0:
                errors.append("active-acquisition owner controller PID is invalid")
            if float(core.get("claimed_epoch") or 0.0) <= 0.0:
                errors.append("active-acquisition owner issue time is invalid")
        except (TypeError, ValueError):
            errors.append("active-acquisition owner controller or timing identity is malformed")
    status = str(owner.get("status") or "")
    if status not in {"CLAIMED", "LEASE_BOUND", *ACTIVE_ACQUISITION_OWNER_TERMINAL_STATES}:
        errors.append("active-acquisition owner status is not recognized")
    binding = owner.get("lease_binding")
    if status == "LEASE_BOUND" and not isinstance(binding, Mapping):
        errors.append("LEASE_BOUND active-acquisition owner lacks its lease binding")
    if binding is not None and not isinstance(binding, Mapping):
        errors.append("active-acquisition owner lease binding is malformed")
    stored_state = str(owner.get("owner_state_sha256") or "")
    if not _SHA256_HEX_RE.fullmatch(stored_state) or stored_state != _active_owner_state_sha256(owner):
        errors.append("active-acquisition owner state identity changed")
    return errors


def _write_active_owner(path: Path, owner: Mapping[str, Any]) -> dict[str, Any]:
    payload = deepcopy(dict(owner))
    payload["owner_state_sha256"] = _active_owner_state_sha256(payload)
    write_json(path, payload)
    return payload


def _active_owner_location_errors(owner: Mapping[str, Any], canonical_owner_path: Path) -> list[str]:
    core = owner.get("owner_core", {})
    if not isinstance(core, Mapping):
        return ["active-acquisition owner core is malformed"]
    errors: list[str] = []
    if not paths_equivalent(str(core.get("protocol_runs_root") or ""), canonical_owner_path.parent, require_existing=True):
        errors.append("active-acquisition owner protocol-runs root is not canonical")
    run_root = canonical_owner_path.parent / str(core.get("run_uuid") or "")
    lock_path = Path(str(core.get("session_lock_path") or "")).expanduser().resolve(strict=False)
    if not paths_equivalent(lock_path.parent, run_root, require_existing=True):
        errors.append("active-acquisition owner session lock is outside its canonical run directory")
    expected_lease = lock_path.parent / RUNTIME_RUNNER_LEASE_FILENAME
    if not paths_equivalent(str(core.get("expected_lease_path") or ""), expected_lease, require_existing=False):
        errors.append("active-acquisition owner expected runner-lease path is not canonical")
    expected_marker = canonical_owner_path.parent / f"active_acquisition_owner.{core.get('owner_id')}.terminal.json"
    if not paths_equivalent(str(core.get("terminal_marker_path") or ""), expected_marker, require_existing=False):
        errors.append("active-acquisition owner terminal-marker path is not canonical")
    return errors


def _active_owner_binding_errors(
    binding: Mapping[str, Any],
    owner: Mapping[str, Any],
    lease: Mapping[str, Any] | None,
) -> list[str]:
    errors = _canonical_record_errors(
        binding,
        schema="PRAYCG_ActiveAcquisitionOwnerLeaseBinding_v1_0_alpha_2",
        label="active-acquisition owner lease binding",
    )
    core = owner.get("owner_core", {})
    expected = {
        "owner_id": core.get("owner_id") if isinstance(core, Mapping) else None,
        "owner_core_sha256": owner.get("owner_core_sha256"),
        "lease_path": core.get("expected_lease_path") if isinstance(core, Mapping) else None,
        "run_uuid": core.get("run_uuid") if isinstance(core, Mapping) else None,
    }
    if isinstance(lease, Mapping):
        lease_core = lease.get("lease_core", {})
        expected.update({
            "lease_id": lease_core.get("lease_id") if isinstance(lease_core, Mapping) else None,
            "lease_core_sha256": lease.get("lease_core_sha256"),
            "lease_claim_token_sha256": lease_core.get("claim_token_sha256") if isinstance(lease_core, Mapping) else None,
            "armed_state_sha256": lease_core.get("armed_state_sha256") if isinstance(lease_core, Mapping) else None,
        })
    for field, value in expected.items():
        observed = binding.get(field)
        if field.endswith("_path"):
            if not paths_equivalent(str(observed or ""), str(value or ""), require_existing=True):
                errors.append(f"active-acquisition owner lease binding {field} changed")
        elif observed != value:
            errors.append(f"active-acquisition owner lease binding {field} changed")
    return errors


def _active_owner_lease_errors(
    owner: Mapping[str, Any],
    lease_path: Path,
    lease: Mapping[str, Any],
) -> list[str]:
    errors = _validate_runner_lease(lease)
    core = owner.get("owner_core", {})
    lease_core = lease.get("lease_core", {})
    if not isinstance(core, Mapping) or not isinstance(lease_core, Mapping):
        return errors + ["active-acquisition owner or runner lease core is malformed"]
    if not paths_equivalent(lease_path, str(core.get("expected_lease_path") or ""), require_existing=True):
        errors.append("active-acquisition owner runner lease path changed")
    exact = {
        "run UUID": (lease_core.get("run_uuid"), core.get("run_uuid")),
        "session lock path": (normalized_path_identity(str(lease_core.get("session_lock_path") or "")), normalized_path_identity(str(core.get("session_lock_path") or ""))),
        "lock identity": (lease_core.get("lock_identity_sha256"), core.get("lock_identity_sha256")),
        "ARM state": (lease_core.get("armed_state_sha256"), core.get("armed_state_sha256")),
        "controller instance": (lease_core.get("controller_instance_id"), core.get("controller_instance_id")),
        "controller PID": (lease_core.get("controller_pid"), core.get("controller_pid")),
    }
    for label, (observed, expected) in exact.items():
        if observed != expected:
            errors.append(f"active-acquisition owner and runner lease {label} differ")
    binding = owner.get("lease_binding")
    if binding is not None:
        errors.extend(_active_owner_binding_errors(binding, owner, lease))
    return errors


def _active_owner_terminal_errors(record: Mapping[str, Any], owner: Mapping[str, Any]) -> list[str]:
    errors = _canonical_record_errors(
        record,
        schema=ACTIVE_ACQUISITION_OWNER_TERMINAL_SCHEMA,
        label="active-acquisition owner terminal record",
    )
    core = owner.get("owner_core", {})
    if record.get("owner_id") != (core.get("owner_id") if isinstance(core, Mapping) else None):
        errors.append("active-acquisition owner terminal record owner_id mismatch")
    if record.get("owner_core_sha256") != owner.get("owner_core_sha256"):
        errors.append("active-acquisition owner terminal record core identity mismatch")
    if str(record.get("status") or "") not in ACTIVE_ACQUISITION_OWNER_TERMINAL_STATES:
        errors.append("active-acquisition owner terminal status is not recognized")
    if record.get("run_uuid") != (core.get("run_uuid") if isinstance(core, Mapping) else None):
        errors.append("active-acquisition owner terminal record run UUID mismatch")
    if not paths_equivalent(
        str(record.get("session_lock_path") or ""),
        str(core.get("session_lock_path") or "") if isinstance(core, Mapping) else "",
        require_existing=True,
    ):
        errors.append("active-acquisition owner terminal record session-lock path mismatch")
    terminal_status = str(record.get("status") or "")
    lock_stage = str(record.get("lock_stage") or "")
    if terminal_status == "CANCELLED" and lock_stage != "ARM":
        errors.append("cancelled active-acquisition owner terminal record is not bound to ARM")
    if terminal_status == "RELEASED" and lock_stage not in SESSION_STAGES[SESSION_STAGES.index("FINALIZE"):]:
        errors.append("released active-acquisition owner terminal record is not bound to FINALIZE-or-later")
    binding = owner.get("lease_binding")
    if isinstance(binding, Mapping):
        if record.get("lease_id") != binding.get("lease_id"):
            errors.append("active-acquisition owner terminal record lease_id mismatch")
        if record.get("lease_core_sha256") != binding.get("lease_core_sha256"):
            errors.append("active-acquisition owner terminal record lease core mismatch")
    elif record.get("lease_id") is not None or record.get("lease_core_sha256") is not None:
        errors.append("unbound active-acquisition owner terminal record unexpectedly names a lease")
    try:
        if float(record.get("terminal_epoch") or 0.0) <= 0.0:
            errors.append("active-acquisition owner terminal timestamp is invalid")
    except (TypeError, ValueError):
        errors.append("active-acquisition owner terminal timestamp is malformed")
    if not isinstance(record.get("terminal_utc"), str) or not str(record.get("terminal_utc") or "").strip():
        errors.append("active-acquisition owner terminal UTC time is missing")
    if not isinstance(record.get("reason"), str) or not str(record.get("reason") or "").strip():
        errors.append("active-acquisition owner terminal reason is missing")
    return errors


def claim_active_acquisition_owner(
    log_root: Path | str,
    session_lock: Mapping[str, Any],
    session_lock_path: Path | str,
    *,
    controller_instance_id: str,
    controller_pid: int,
) -> tuple[Path, dict[str, Any]]:
    """Atomically claim one acquisition owner across all Control Centers using a log root."""
    validation = validate_session_lock_identity(session_lock)
    if validation.status == "INELIGIBLE":
        raise ValueError("Cannot claim acquisition ownership for an invalid session lock: " + "; ".join(validation.errors))
    if str(session_lock.get("current_stage") or "") != "ARM":
        raise ValueError("The active-acquisition owner may be claimed only for an ARM-stage session.")
    instance_id = str(controller_instance_id or "").strip()
    if not instance_id or int(controller_pid) <= 0:
        raise ValueError("The active-acquisition owner requires the exact Control Center instance and PID.")
    session = session_lock.get("session", {})
    run_uuid = str(session.get("session_id") or "") if isinstance(session, Mapping) else ""
    if not run_uuid:
        raise ValueError("The runtime session lock lacks its run UUID.")
    locked_controller_instance = str(session.get("control_center_process_id") or "") if isinstance(session, Mapping) else ""
    if locked_controller_instance != instance_id:
        raise ValueError("The active-acquisition owner Control Center instance does not match the armed session lock.")
    owner_path = active_acquisition_owner_path(log_root)
    protocol_runs_root = owner_path.parent
    lock_path = Path(session_lock_path).expanduser().resolve(strict=False)
    expected_run_root = protocol_runs_root / run_uuid
    if not paths_equivalent(lock_path.parent, expected_run_root, require_existing=True):
        raise ValueError("The owner claim lock is not in its canonical log-root run directory.")
    expected_lease_path = lock_path.parent / RUNTIME_RUNNER_LEASE_FILENAME
    owner_id = str(uuid.uuid4())
    terminal_marker_path = protocol_runs_root / f"active_acquisition_owner.{owner_id}.terminal.json"
    owner_core = {
        "owner_id": owner_id,
        "protocol_runs_root": normalized_path_identity(protocol_runs_root),
        "run_uuid": run_uuid,
        "session_lock_path": normalized_path_identity(lock_path),
        "lock_identity_sha256": str(session_lock.get("lock_identity_sha256") or ""),
        "armed_state_sha256": str(session_lock.get("state_sha256") or ""),
        "expected_lease_path": normalized_path_identity(expected_lease_path),
        "controller_instance_id": instance_id,
        "controller_pid": int(controller_pid),
        "controller_process_start_identity": process_start_identity(int(controller_pid)),
        "terminal_marker_path": normalized_path_identity(terminal_marker_path),
        "claimed_epoch": time.time(),
        "claimed_utc": utc_now(),
    }
    owner: dict[str, Any] = {
        "schema": ACTIVE_ACQUISITION_OWNER_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "owner_core": owner_core,
        "owner_core_sha256": sha256_json(owner_core),
        "status": "CLAIMED",
        "lease_binding": None,
        "terminal_epoch": None,
        "terminal_utc": None,
        "terminal_reason": "",
    }
    owner["owner_state_sha256"] = _active_owner_state_sha256(owner)
    protocol_runs_root.mkdir(parents=True, exist_ok=True)
    with _active_acquisition_owner_guard(protocol_runs_root):
        if owner_path.exists():
            activity = active_acquisition_owner_activity(owner_path)
            if bool(activity.get("active")):
                raise RuntimeError(
                    "Another acquisition owner is active or unresolved "
                    f"({activity.get('status')}: {activity.get('reason')})."
                )
            history_root = protocol_runs_root / ACTIVE_ACQUISITION_OWNER_HISTORY_DIRNAME
            history_root.mkdir(parents=True, exist_ok=True)
            archive_path = history_root / f"{time.time_ns()}_{uuid.uuid4().hex}.json"
            os.replace(owner_path, archive_path)
        try:
            descriptor = os.open(str(owner_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
        except FileExistsError as exc:
            raise RuntimeError("Another Control Center won the atomic active-acquisition owner claim.") from exc
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(canonical_json_bytes(owner) + b"\n")
            handle.flush()
            os.fsync(handle.fileno())
        return owner_path, owner


def bind_active_acquisition_owner_lease(
    owner_path: Path | str,
    lease_path: Path | str,
    *,
    controller_instance_id: str,
    controller_pid: int,
) -> dict[str, Any]:
    """Bind the global owner claim to the exact run-local lease before ACQUIRE."""
    path = Path(owner_path).expanduser().resolve(strict=False)
    owner = load_json(path)
    errors = _validate_active_owner(owner)
    errors.extend(_active_owner_location_errors(owner, path))
    if errors:
        raise RuntimeError("The active-acquisition owner is invalid: " + "; ".join(errors))
    if str(owner.get("status") or "") != "CLAIMED":
        raise RuntimeError("The active-acquisition owner may bind exactly one runner lease.")
    core = owner["owner_core"]
    if str(core.get("controller_instance_id") or "") != str(controller_instance_id or "") or int(core.get("controller_pid") or 0) != int(controller_pid):
        raise RuntimeError("A different Control Center owns this acquisition claim.")
    recorded_start = str(core.get("controller_process_start_identity") or "")
    observed_start = process_start_identity(int(controller_pid))
    if recorded_start and observed_start != recorded_start:
        raise RuntimeError("The Control Center process-start identity changed before lease binding.")
    runner_path = Path(lease_path).expanduser().resolve(strict=False)
    if not paths_equivalent(runner_path, str(core.get("expected_lease_path") or ""), require_existing=True):
        raise RuntimeError("The runner lease path does not match the owner claim.")
    lease = load_json(runner_path)
    lease_errors = _active_owner_lease_errors(owner, runner_path, lease)
    if lease_errors:
        raise RuntimeError("The owner cannot bind this runner lease: " + "; ".join(lease_errors))
    lease_core = lease["lease_core"]
    binding = {
        "schema": "PRAYCG_ActiveAcquisitionOwnerLeaseBinding_v1_0_alpha_2",
        "owner_id": core.get("owner_id"),
        "owner_core_sha256": owner.get("owner_core_sha256"),
        "run_uuid": core.get("run_uuid"),
        "lease_path": normalized_path_identity(runner_path),
        "lease_id": lease_core.get("lease_id"),
        "lease_core_sha256": lease.get("lease_core_sha256"),
        "lease_claim_token_sha256": lease_core.get("claim_token_sha256"),
        "armed_state_sha256": lease_core.get("armed_state_sha256"),
        "bound_epoch": time.time(),
        "bound_utc": utc_now(),
    }
    binding["canonical_sha256"] = sha256_json(binding)
    owner["lease_binding"] = binding
    owner["status"] = "LEASE_BOUND"
    return _write_active_owner(path, owner)


def load_active_acquisition_owner_identity(
    owner_path: Path | str,
    *,
    owner_id: str,
    owner_core_sha256: str,
) -> tuple[Path, dict[str, Any]]:
    """Resolve one current or archived owner by immutable identity."""
    canonical_path = Path(owner_path).expanduser().resolve(strict=False)
    candidates: list[Path] = []
    if canonical_path.is_file():
        candidates.append(canonical_path)
    history_root = canonical_path.parent / ACTIVE_ACQUISITION_OWNER_HISTORY_DIRNAME
    if history_root.is_dir():
        candidates.extend(history_root.glob("*.json"))
    matches: list[tuple[Path, dict[str, Any]]] = []
    for candidate in candidates:
        try:
            owner = load_json(candidate)
        except Exception:
            continue
        core = owner.get("owner_core", {}) if isinstance(owner, Mapping) else {}
        if (
            isinstance(core, Mapping)
            and str(core.get("owner_id") or "") == str(owner_id or "")
            and str(owner.get("owner_core_sha256") or "") == str(owner_core_sha256 or "")
        ):
            errors = _validate_active_owner(owner)
            errors.extend(_active_owner_location_errors(owner, canonical_path))
            if errors:
                raise RuntimeError("The identified active-acquisition owner is invalid: " + "; ".join(errors))
            matches.append((candidate.resolve(strict=False), dict(owner)))
    if len(matches) != 1:
        raise RuntimeError(
            "The ACQUIRE owner identity did not resolve uniquely in the current owner or immutable owner history."
        )
    return matches[0]


def active_acquisition_owner_activity(owner_path: Path | str) -> dict[str, Any]:
    """Classify the log-root owner conservatively for begin, launch, and restart recovery."""
    path = Path(owner_path).expanduser().resolve(strict=False)
    if not path.is_file():
        return {"active": False, "status": "MISSING", "reason": "owner claim is absent", "path": str(path)}
    try:
        owner = load_json(path)
    except Exception as exc:
        return {"active": True, "status": "INVALID", "reason": f"owner claim is unreadable: {exc}", "path": str(path)}
    errors = _validate_active_owner(owner)
    errors.extend(_active_owner_location_errors(owner, path))
    if errors:
        return {"active": True, "status": "INVALID", "reason": "; ".join(errors), "path": str(path)}
    core = owner["owner_core"]
    marker_path = Path(str(core.get("terminal_marker_path") or "")).expanduser().resolve(strict=False)
    expected_marker_path = path.parent / f"active_acquisition_owner.{core.get('owner_id')}.terminal.json"
    if not paths_equivalent(marker_path, expected_marker_path, require_existing=False):
        return {"active": True, "status": "INVALID", "reason": "owner terminal-marker path is not canonical", "path": str(path)}
    if marker_path.is_file():
        try:
            marker = load_json(marker_path)
            marker_errors = _active_owner_terminal_errors(marker, owner)
            if marker_errors:
                raise ValueError("; ".join(marker_errors))
        except Exception as exc:
            return {"active": True, "status": "INVALID", "reason": f"owner terminal record is invalid: {exc}", "path": str(path)}
        return {"active": False, "status": str(marker.get("status") or "RELEASED"), "reason": "owner has an immutable terminal record", "path": str(path)}
    status = str(owner.get("status") or "")
    if status in ACTIVE_ACQUISITION_OWNER_TERMINAL_STATES:
        return {"active": True, "status": "INVALID", "reason": "terminal owner state lacks its immutable terminal record", "path": str(path)}
    controller_state = _process_identity_state(
        int(core.get("controller_pid") or 0),
        str(core.get("controller_process_start_identity") or ""),
    )
    if controller_state == "LIVE":
        return {"active": True, "status": status, "reason": "the owning Control Center process is alive", "path": str(path)}
    if controller_state == "UNKNOWN":
        return {"active": True, "status": "OWNER_IDENTITY_UNCERTAIN", "reason": "the owning Control Center process identity cannot be verified", "path": str(path)}
    try:
        lock_path = Path(str(core.get("session_lock_path") or "")).expanduser().resolve(strict=False)
        lock = load_json(lock_path)
        lock_report = validate_session_lock_identity(lock)
        if lock_report.status == "INELIGIBLE":
            raise ValueError("; ".join(lock_report.errors))
        if str(lock.get("lock_identity_sha256") or "") != str(core.get("lock_identity_sha256") or ""):
            raise ValueError("owner session-lock identity changed")
        if str(lock.get("session", {}).get("session_id") or "") != str(core.get("run_uuid") or ""):
            raise ValueError("owner session-lock run UUID changed")
    except Exception as exc:
        return {"active": True, "status": "INVALID", "reason": f"owner session lock cannot be verified: {exc}", "path": str(path)}
    stage = str(lock.get("current_stage") or "")
    lease_path = Path(str(core.get("expected_lease_path") or "")).expanduser().resolve(strict=False)
    lease: Mapping[str, Any] | None = None
    lease_activity: dict[str, Any] | None = None
    if lease_path.is_file():
        try:
            lease = load_json(lease_path)
            lease_errors = _active_owner_lease_errors(owner, lease_path, lease)
            if lease_errors:
                raise ValueError("; ".join(lease_errors))
            lease_activity = runtime_runner_lease_activity(lease_path)
        except Exception as exc:
            return {"active": True, "status": "INVALID", "reason": f"owner runner lease cannot be verified: {exc}", "path": str(path)}
        if bool(lease_activity.get("active")):
            return {"active": True, "status": str(lease_activity.get("status") or status), "reason": f"owner-bound runner lease remains active or uncertain: {lease_activity.get('reason')}", "path": str(path)}
    elif owner.get("lease_binding") is not None:
        return {"active": True, "status": "INVALID", "reason": "owner-bound runner lease is missing", "path": str(path)}
    if stage == "ACQUIRE":
        return {"active": True, "status": "UNRESOLVED_ACQUIRE", "reason": "owner session remains at ACQUIRE and requires reviewed interrupted finalization", "path": str(path)}
    if stage == "ARM":
        return {"active": False, "status": "STALE_RECLAIMABLE", "reason": "owner process is gone and no live runner authority remains before ACQUIRE", "path": str(path)}
    if stage in SESSION_STAGES[SESSION_STAGES.index("FINALIZE"):]:
        if not isinstance(lease, Mapping) or str(lease.get("status") or "") not in RUNTIME_RUNNER_TERMINAL_STATES:
            return {"active": True, "status": "INVALID", "reason": "finalized owner lacks a valid terminal runner lease", "path": str(path)}
        return {"active": False, "status": "STALE_RECLAIMABLE", "reason": "owner process is gone and the bound run is terminal", "path": str(path)}
    return {"active": True, "status": "INVALID", "reason": f"owner session has unsupported stage {stage!r}", "path": str(path)}


def finish_active_acquisition_owner(
    owner_path: Path | str,
    *,
    reason: str,
    allow_preacquire_cancel: bool = False,
    controller_instance_id: str = "",
    controller_pid: int | None = None,
) -> dict[str, Any]:
    """Terminalize an owner only after safe prelaunch cancellation or a terminal run."""
    path = Path(owner_path).expanduser().resolve(strict=False)
    owner = load_json(path)
    errors = _validate_active_owner(owner)
    errors.extend(_active_owner_location_errors(owner, path))
    if errors:
        raise RuntimeError("The active-acquisition owner is invalid: " + "; ".join(errors))
    core = owner["owner_core"]
    marker_path = Path(str(core.get("terminal_marker_path") or "")).expanduser().resolve(strict=False)
    if marker_path.is_file():
        marker = load_json(marker_path)
        marker_errors = _active_owner_terminal_errors(marker, owner)
        if marker_errors:
            raise RuntimeError("The active-acquisition owner terminal record is invalid: " + "; ".join(marker_errors))
        marker_status = str(marker.get("status") or "")
        if str(owner.get("status") or "") != marker_status:
            owner.update({
                "status": marker_status,
                "terminal_epoch": marker.get("terminal_epoch"),
                "terminal_utc": marker.get("terminal_utc"),
                "terminal_reason": marker.get("reason"),
            })
            return _write_active_owner(path, owner)
        return owner
    if str(owner.get("status") or "") in ACTIVE_ACQUISITION_OWNER_TERMINAL_STATES:
        raise RuntimeError("The terminal active-acquisition owner lacks its immutable terminal record.")
    lock_path = Path(str(core.get("session_lock_path") or "")).expanduser().resolve(strict=False)
    lock = load_json(lock_path)
    lock_report = validate_session_lock_identity(lock)
    if lock_report.status == "INELIGIBLE":
        raise RuntimeError("The owner session lock is invalid: " + "; ".join(lock_report.errors))
    if str(lock.get("lock_identity_sha256") or "") != str(core.get("lock_identity_sha256") or ""):
        raise RuntimeError("The owner session-lock identity changed.")
    stage = str(lock.get("current_stage") or "")
    lease_path = Path(str(core.get("expected_lease_path") or "")).expanduser().resolve(strict=False)
    lease: Mapping[str, Any] | None = None
    if lease_path.is_file():
        lease = load_json(lease_path)
        lease_errors = _active_owner_lease_errors(owner, lease_path, lease)
        if lease_errors:
            raise RuntimeError("The owner-bound runner lease is invalid: " + "; ".join(lease_errors))
        lease_activity = runtime_runner_lease_activity(lease_path)
        if bool(lease_activity.get("active")):
            raise RuntimeError("The owner-bound runner lease remains active or uncertain: " + str(lease_activity.get("reason") or ""))
        if str(lease.get("status") or "") not in RUNTIME_RUNNER_TERMINAL_STATES:
            raise RuntimeError("The owner-bound runner lease lacks a valid terminal state.")
    elif owner.get("lease_binding") is not None:
        raise RuntimeError("The owner-bound runner lease is missing.")
    if allow_preacquire_cancel:
        if stage != "ARM":
            raise RuntimeError("Pre-ACQUIRE owner cancellation requires the session to remain at ARM.")
        if str(core.get("controller_instance_id") or "") != str(controller_instance_id or "") or int(core.get("controller_pid") or 0) != int(controller_pid or 0):
            raise RuntimeError("Only the owning Control Center may cancel a pre-ACQUIRE owner claim.")
        recorded_start = str(core.get("controller_process_start_identity") or "")
        observed_start = process_start_identity(int(controller_pid or 0))
        if recorded_start and observed_start != recorded_start:
            raise RuntimeError("The owning Control Center process-start identity changed.")
        terminal = "CANCELLED"
    else:
        if stage not in SESSION_STAGES[SESSION_STAGES.index("FINALIZE"):]:
            raise RuntimeError("Owner release requires a FINALIZE-or-later lock; unresolved ACQUIRE remains blocked.")
        if not isinstance(lease, Mapping):
            raise RuntimeError("Owner release requires its terminal bound runner lease.")
        if not isinstance(owner.get("lease_binding"), Mapping):
            raise RuntimeError("Owner release requires the exact immutable runner-lease binding.")
        terminal = "RELEASED"
    terminal_epoch = time.time()
    marker = {
        "schema": ACTIVE_ACQUISITION_OWNER_TERMINAL_SCHEMA,
        "owner_id": core.get("owner_id"),
        "owner_core_sha256": owner.get("owner_core_sha256"),
        "status": terminal,
        "run_uuid": core.get("run_uuid"),
        "session_lock_path": core.get("session_lock_path"),
        "lock_stage": stage,
        "lease_id": lease.get("lease_core", {}).get("lease_id") if isinstance(lease, Mapping) else None,
        "lease_core_sha256": lease.get("lease_core_sha256") if isinstance(lease, Mapping) else None,
        "terminal_epoch": terminal_epoch,
        "terminal_utc": utc_now(),
        "reason": str(reason or "unspecified"),
    }
    marker["canonical_sha256"] = sha256_json(marker)
    try:
        descriptor = os.open(str(marker_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL)
    except FileExistsError as exc:
        existing = load_json(marker_path)
        marker_errors = _active_owner_terminal_errors(existing, owner)
        if not marker_errors and str(existing.get("status") or "") == terminal:
            return owner
        raise RuntimeError("A conflicting active-acquisition owner terminal record already exists.") from exc
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(canonical_json_bytes(marker) + b"\n")
        handle.flush()
        os.fsync(handle.fileno())
    owner.update({
        "status": terminal,
        "terminal_epoch": terminal_epoch,
        "terminal_utc": marker["terminal_utc"],
        "terminal_reason": marker["reason"],
    })
    return _write_active_owner(path, owner)


def _session_state_payload(lock: Mapping[str, Any]) -> dict[str, Any]:
    """Return every mutable runtime-state field covered by state_sha256."""
    return {
        "lock_identity_sha256": lock.get("lock_identity_sha256"),
        "status": lock.get("status"),
        "current_stage": lock.get("current_stage"),
        "gate_status": deepcopy(lock.get("gate_status")),
        "runtime_history": deepcopy(lock.get("runtime_history")),
        "validation": deepcopy(lock.get("validation")),
    }


def _session_state_sha256(lock: Mapping[str, Any]) -> str:
    return sha256_json(_session_state_payload(lock))


class ValidationReport(legacy.ValidationReport):
    """Validation report carrying the alpha.3 platform identity."""

    def as_dict(self) -> dict[str, Any]:
        value = super().as_dict()
        value["platform_version"] = PLATFORM_VERSION
        return value


def _promote_validation_report(source: legacy.ValidationReport) -> ValidationReport:
    return ValidationReport(
        subject=source.subject,
        errors=list(source.errors),
        cautions=list(source.cautions),
        information=list(source.information),
    )


def validate_protocol(module: Mapping[str, Any], *, library_root: Path | None = None) -> ValidationReport:
    """Validate either a native PRAYCG module or a declarative Atlas module."""
    if module.get("schema") != ATLAS_PROTOCOL_SCHEMA:
        return _promote_validation_report(legacy.validate_protocol(module, library_root=library_root))
    report = ValidationReport(subject=str(module.get("display_name") or module.get("protocol_id") or "Atlas protocol"))
    if library_root is None:
        report.errors.append("Atlas validation requires its packaged library root.")
        return report
    if validate_atlas_protocol_module is None:
        report.errors.append(f"Protocol Atlas validator is unavailable: {ATLAS_CORE_IMPORT_ERROR}")
        return report
    try:
        record = validate_atlas_protocol_module(module, Path(library_root))  # type: ignore[misc]
    except AtlasProtocolValidationError as exc:  # type: ignore[misc]
        details = getattr(exc, "errors", None)
        report.errors.extend(str(item) for item in details) if details else report.errors.append(str(exc))
    except Exception as exc:
        report.errors.append(f"Atlas validation failed safely: {type(exc).__name__}: {exc}")
    else:
        report.information.append(f"Atlas engine family: {record.engine_family}")
        report.information.append("The protocol has no authority to select or modify the independent Acquisition hardware profile.")
    return report


def protocol_timeline(module: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Return a compact design-time timeline for either supported protocol schema."""
    if module.get("schema") != ATLAS_PROTOCOL_SCHEMA:
        return legacy.protocol_timeline(module)
    rows: list[dict[str, Any]] = []

    def append_nodes(nodes: Any, parent: str = "") -> None:
        if not isinstance(nodes, list):
            return
        for index, node in enumerate(nodes, start=1):
            if not isinstance(node, Mapping):
                continue
            node_id = str(node.get("id") or node.get("node_id") or f"NODE_{len(rows) + 1}")
            rows.append({
                "sequence": len(rows) + 1,
                "event": node_id if not parent else f"{parent}/{node_id}",
                "kind": str(node.get("type") or "event"),
            })
            append_nodes(node.get("children"), node_id if not parent else f"{parent}/{node_id}")

    append_nodes(module.get("timeline"))
    return rows


def validate_hardware_module(module: Mapping[str, Any]) -> ValidationReport:
    """Validate carried fields plus alpha.2 dynamic LSL identity policies."""
    report = _promote_validation_report(legacy.validate_hardware_module(module))
    for stream in module.get("streams", []):
        if not isinstance(stream, Mapping):
            continue
        name = str(stream.get("lsl_name") or "?")
        policy = str(stream.get("source_id_policy") or "").lower()
        has_static = bool(str(stream.get("source_id") or "").strip())
        identity_declared = has_static
        if policy == "dynamic_run_bound":
            identity_declared = bool(str(stream.get("source_id_prefix") or "").strip() or str(stream.get("source_id_suffix") or "").strip())
            if not identity_declared:
                report.errors.append(f"{name} dynamic_run_bound identity requires a source_id prefix or suffix.")
        elif policy == "connection_specific":
            identity_declared = bool(stream.get("source_id_examples"))
            if not identity_declared:
                report.errors.append(f"{name} connection_specific identity requires source_id_examples.")
        elif policy and policy != "fixed":
            report.errors.append(f"{name} has unsupported source_id_policy {policy!r}.")
        if identity_declared:
            report.cautions = [
                item for item in report.cautions
                if item != f"{name} lacks source_id; LSL recovery identity is weaker."
            ]
    return report


def scan_public_package(root: Path, *, allowed_emails: Iterable[str] = ()) -> dict[str, Any]:
    """Extend the public scan with source-aware credential and document checks.

    The alpha.1 scanner deliberately used a broad assignment expression.  That
    expression also classified ordinary source such as ``token = str(...)`` as
    an embedded credential.  Alpha.2 keeps the conservative private-key check,
    but only treats quoted, static values assigned to credential-like names as
    possible secrets.  Computed values, environment lookups, and concatenated
    synthetic fixtures are code rather than embedded credentials.
    """
    root = Path(root).resolve()
    allowed = {value.lower() for value in allowed_emails}
    result = legacy.scan_public_package(root, allowed_emails=allowed)
    findings = [
        row for row in result.get("findings", [])
        if row.get("finding") != "possible credential or private key"
    ]
    seen = {(row.get("severity"), row.get("path"), row.get("finding")) for row in findings}
    extra_user_paths = (
        re.compile(r"(?i)[A-Z]:/Users/[^/\s]+/"),
        re.compile(r"(?i)[A-Z]:\\\\Users\\\\[^\\\s]+\\\\"),
    )
    private_key_block = re.compile(r"(?i)-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----")
    static_credential = re.compile(
        r"(?ix)\b(?:api[_-]?key|secret|token|password)\b\s*[:=]\s*"
        r"(?P<quote>['\"])(?P<value>[^'\"\r\n]{8,})(?P=quote)(?!\s*[+*])"
    )
    obvious_placeholders = (
        "synthetic", "placeholder", "example", "dummy", "redacted",
        "replace-me", "replace_me", "change-me", "change_me", "not-a-secret",
    )
    text_suffixes = {
        ".py", ".json", ".md", ".txt", ".csv", ".yml", ".yaml",
        ".toml", ".bat", ".ps1", ".dockerfile", "",
    }

    def add(severity: str, rel: str, finding: str) -> None:
        key = (severity, rel, finding)
        if key not in seen:
            findings.append({"severity": severity, "path": rel, "finding": finding})
            seen.add(key)

    def inspect_text(rel: str, text: str) -> None:
        if private_key_block.search(text):
            add("ERROR", rel, "possible credential or private key")
        else:
            for match in static_credential.finditer(text):
                candidate = match.group("value").strip().lower()
                if any(marker in candidate for marker in obvious_placeholders):
                    continue
                add("ERROR", rel, "possible credential or private key")
                break
        if ABSOLUTE_USER_PATH_RE.search(text) or any(regex.search(text) for regex in extra_user_paths):
            add("ERROR", rel, "absolute Windows user path")
        for email in EMAIL_RE.findall(text):
            if email.lower() not in allowed:
                add("CAUTION", rel, f"unapproved email address: {email}")

    for path in sorted(root.rglob("*")):
        if not path.is_file() or ".git" in path.parts:
            continue
        rel = path.relative_to(root).as_posix()
        if path.suffix.lower() == ".pyc" or "__pycache__" in path.parts:
            add("ERROR", rel, "compiled Python bytecode is not permitted in the public release")
            continue
        if path.suffix.lower() in text_suffixes:
            try:
                inspect_text(rel, path.read_text(encoding="utf-8", errors="replace"))
            except OSError:
                pass
        if path.suffix.lower() == ".docx":
            try:
                with zipfile.ZipFile(path) as archive:
                    for name in archive.namelist():
                        if name.endswith((".xml", ".rels")):
                            inspect_text(rel, archive.read(name).decode("utf-8", errors="replace"))
            except (OSError, zipfile.BadZipFile, KeyError) as exc:
                add("ERROR", rel, f"DOCX content could not be inspected: {type(exc).__name__}")
    result["platform_version"] = PLATFORM_VERSION
    result["generated_utc"] = utc_now()
    result["findings"] = findings
    result["status"] = "INELIGIBLE" if any(row["severity"] == "ERROR" for row in findings) else ("CAUTION" if findings else "PASS")
    return result


def _without(mapping: Mapping[str, Any], *keys: str) -> dict[str, Any]:
    return {key: deepcopy(value) for key, value in mapping.items() if key not in keys}


def _canonical_stored_hash(mapping: Mapping[str, Any], field: str = "canonical_sha256") -> str:
    return sha256_json(_without(mapping, field))


def _nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _recorded_identity(value: Any) -> bool:
    return _nonempty(value) and str(value).strip().upper() not in {
        "UNRECORDED", "EDIT_ME", "UNKNOWN", "N/A", "NONE",
    }


def _approved_protocol(snapshot: Mapping[str, Any]) -> bool:
    if snapshot.get("schema") == PROTOCOL_SNAPSHOT_SCHEMA:
        envelope_hash = snapshot.get("approval_envelope_sha256")
        return (
            snapshot.get("status") == "APPROVED"
            and snapshot.get("validation_status") == "PASS"
            and _recorded_identity(snapshot.get("human_reviewed_by"))
            and _nonempty(envelope_hash)
            and envelope_hash == sha256_json(_without(snapshot, "approval_envelope_sha256"))
        )
    return (
        snapshot.get("schema") == LEGACY_PROTOCOL_LOCK_SCHEMA
        and snapshot.get("status") == "LOCKABLE"
        and snapshot.get("validation_status") == "PASS"
        and _recorded_identity(snapshot.get("human_reviewed_by"))
    )


def _protocol_snapshot_identity(snapshot: Mapping[str, Any]) -> str:
    if snapshot.get("schema") == PROTOCOL_SNAPSHOT_SCHEMA:
        core = snapshot.get("snapshot_core")
        stored = snapshot.get("snapshot_sha256")
        envelope_hash = snapshot.get("approval_envelope_sha256")
        if not isinstance(core, Mapping) or not _nonempty(stored):
            raise ValueError("Approved protocol snapshot is missing its canonical snapshot identity.")
        calculated = sha256_json(core)
        if calculated != stored:
            raise ValueError("Approved protocol snapshot content does not match snapshot_sha256.")
        if not _nonempty(envelope_hash) or envelope_hash != sha256_json(_without(snapshot, "approval_envelope_sha256")):
            raise ValueError("Approved protocol snapshot approval envelope is missing or has changed.")
        return str(envelope_hash)
    if snapshot.get("schema") == LEGACY_PROTOCOL_LOCK_SCHEMA:
        # Legacy locks had no independent envelope hash.  Bind their complete
        # canonical content into the alpha.2 session draft instead.
        return sha256_json(snapshot)
    raise ValueError("Protocol input is not a recognized approved snapshot or legacy compiled lock.")


def compile_protocol(
    module_path: Path,
    library_root: Path,
    output_root: Path,
    *,
    human_reviewed_by: str = "UNRECORDED",
) -> tuple[Path, dict[str, Any]]:
    """Compile and, when eligible, create a design-time protocol snapshot.

    The resulting artifact is deliberately not called a session lock.  It
    states which protocol module and fixed runner were reviewed and approved.
    """
    module_path = Path(module_path).resolve()
    library_root = Path(library_root).resolve()
    module = load_json(module_path)
    if not resolved_within(module_path, library_root):
        raise ValueError("Protocol module must be inside the selected packaged library.")
    if module.get("schema") == ATLAS_PROTOCOL_SCHEMA:
        report = validate_protocol(module, library_root=library_root)
        build_id = f"{safe_slug(module.get('protocol_id', 'protocol'))}_{safe_slug(module.get('protocol_version', '0'))}_{sha256_json(module)[:12]}"
        out = Path(output_root).resolve() / build_id
        out.mkdir(parents=True, exist_ok=True)
        write_json(out / "source_protocol_module.json", module)
        write_json(out / "validation_report.json", report.as_dict())
        timeline = protocol_timeline(module)
        with (out / "compiled_timeline.csv").open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=("sequence", "event", "kind"))
            writer.writeheader()
            writer.writerows(timeline)
        write_json(out / "event_dictionary.json", {
            "schema": "PRAYCG_EventDictionary_v0_2",
            "marker_contract": "Runner events use immutable UTF-8 names, local monotonic time, and LSL time when available.",
            "events": timeline,
        })
        validation_status = report.status
    else:
        out, legacy_lock = legacy.compile_protocol(
            module_path,
            library_root,
            output_root,
            human_reviewed_by=human_reviewed_by,
        )
        validation_status = str(legacy_lock.get("validation_status") or "INELIGIBLE")
    runner_path = (library_root / str(module.get("runner_entry", ""))).resolve()
    engine_entry = str(module.get("engine_entry") or "scripts/praycg_protocol_engine_v3_0.py")
    engine_path = (library_root / engine_entry).resolve()
    snapshot_core = {
        "protocol_id": module.get("protocol_id"),
        "protocol_version": module.get("protocol_version"),
        "protocol_module_sha256": sha256_file(module_path),
        "canonical_protocol_sha256": sha256_json(module),
        "runner_entry": module.get("runner_entry"),
        "runner_sha256": sha256_file(runner_path) if runner_path.is_file() else None,
        "engine_entry": engine_entry,
        "engine_sha256": sha256_file(engine_path) if engine_path.is_file() else None,
        "engine_version": module.get("engine_version") or module.get("engine", {}).get("version"),
        "scientific_boundary": module.get("scientific_boundary") or module.get("safety_and_claim_boundaries"),
        "protocol_schema": module.get("schema"),
        "hardware_stack_effect": module.get("hardware_stack_effect", "INDEPENDENT_PROFILE_ONLY"),
    }
    approved = (
        validation_status == "PASS"
        and _recorded_identity(human_reviewed_by)
        and runner_path.is_file()
        and engine_path.is_file()
    )
    snapshot = {
        "schema": PROTOCOL_SNAPSHOT_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "artifact_type": "DESIGN_TIME_APPROVED_PROTOCOL_SNAPSHOT",
        "created_utc": utc_now(),
        "human_reviewed_by": human_reviewed_by,
        "status": "APPROVED" if approved else "DRAFT_NOT_APPROVED",
        "legacy_status": "LOCKABLE" if approved else "DRAFT_NOT_LOCKABLE",
        "validation_status": validation_status,
        "source_protocol_path": str(module_path),
        "library_root": str(library_root),
        "snapshot_core": snapshot_core,
    }
    snapshot["snapshot_sha256"] = sha256_json(snapshot_core)
    snapshot["approval_envelope_sha256"] = sha256_json(snapshot)
    # Preserve an immutable approval-envelope-specific file for runtime
    # sessions.  The fixed filenames remain compatibility pointers for older
    # callers and may be refreshed by a later approval.
    write_json(
        out / f"approved_protocol_snapshot_{snapshot['approval_envelope_sha256'][:12]}.json",
        snapshot,
    )
    write_json(out / "approved_protocol_snapshot.json", snapshot)
    write_json(out / "compiled_protocol_lock.json", snapshot)
    return out, snapshot


def build_hardware_profile(
    module_paths: Sequence[Path],
    output_path: Path,
    *,
    profile_id: str,
    reviewed_by: str = "UNRECORDED",
) -> dict[str, Any]:
    """Build a reviewed profile with file and canonical module identities."""
    modules: list[dict[str, Any]] = []
    errors: list[str] = []
    roles: dict[str, list[str]] = {}
    for raw_path in module_paths:
        path = Path(raw_path).resolve()
        module = load_json(path)
        report = validate_hardware_module(module)
        errors.extend(f"{path.name}: {item}" for item in report.errors)
        modules.append({
            "module_id": module.get("module_id"),
            "module_version": module.get("module_version"),
            "path": str(path),
            "module_file_sha256": sha256_file(path),
            "module_canonical_sha256": sha256_json(module),
            # Carried readers used this field.
            "sha256": sha256_file(path),
            "trust_level": module.get("trust_level"),
            "streams": deepcopy(module.get("streams", [])),
        })
        for stream in module.get("streams", []):
            role = str(stream.get("canonical_role", ""))
            roles.setdefault(role, []).append(str(stream.get("lsl_name", "")))
            for embedded_role in stream.get("embedded_roles", []):
                roles.setdefault(str(embedded_role), []).append(str(stream.get("lsl_name", "")))
    collisions = {
        role: names
        for role, names in roles.items()
        if role not in {"markers"} and len(names) > 1
    }
    if collisions:
        errors.append(f"Canonical-role collisions require explicit selection: {collisions}")
    output_path = Path(output_path).resolve()
    profile = {
        "schema": PROFILE_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "artifact_type": "REVIEWED_HARDWARE_PROFILE",
        "profile_id": safe_slug(profile_id),
        "created_utc": utc_now(),
        "reviewed_by": reviewed_by,
        "status": "APPROVED" if not errors and _recorded_identity(reviewed_by) else "DRAFT_NOT_APPROVED",
        "legacy_status": "LOCKABLE" if not errors and _recorded_identity(reviewed_by) else "DRAFT_NOT_LOCKABLE",
        "modules": modules,
        "resolved_roles": roles,
        "errors": errors,
    }
    profile["canonical_sha256"] = _canonical_stored_hash(profile)
    write_json(output_path, profile)
    return profile


def validate_hardware_profile_identity(
    profile: Mapping[str, Any],
    *,
    profile_path: Path | None = None,
) -> ValidationReport:
    """Validate approval plus the content selected from an optional path."""
    report = ValidationReport(subject=str(profile.get("profile_id") or "hardware profile"))
    if profile.get("schema") not in {PROFILE_SCHEMA, LEGACY_PROFILE_SCHEMA}:
        report.errors.append("Hardware profile schema is not recognized.")
    approved = (
        profile.get("status") in {"APPROVED", "LOCKABLE"}
        or profile.get("legacy_status") == "LOCKABLE"
    ) and _recorded_identity(profile.get("reviewed_by"))
    if not approved:
        report.errors.append("Hardware profile is not human-reviewed and approved.")
    if profile.get("errors"):
        report.errors.append("Hardware profile contains unresolved validation errors.")
    stored = profile.get("canonical_sha256")
    if not _nonempty(stored) or stored != _canonical_stored_hash(profile):
        report.errors.append("Hardware profile canonical hash is missing or invalid.")
    for selected in profile.get("modules", []):
        if not isinstance(selected, Mapping):
            report.errors.append("Hardware profile contains a malformed module selection.")
            continue
        module_id = str(selected.get("module_id") or "unknown")
        module_path = Path(str(selected.get("path", "")))
        if not module_path.is_file():
            report.errors.append(f"Selected hardware module path does not exist for {module_id}.")
            continue
        expected_file = selected.get("module_file_sha256") or selected.get("sha256")
        if not _nonempty(expected_file) or sha256_file(module_path) != expected_file:
            report.errors.append(f"Hardware module file identity changed for {module_id}.")
        expected_canonical = selected.get("module_canonical_sha256")
        if expected_canonical:
            try:
                observed_canonical = sha256_json(load_json(module_path))
            except Exception as exc:
                report.errors.append(f"Hardware module cannot be read for {module_id}: {type(exc).__name__}.")
            else:
                if observed_canonical != expected_canonical:
                    report.errors.append(f"Hardware module canonical identity changed for {module_id}.")
    if profile_path is not None:
        path = Path(profile_path)
        if not path.is_file():
            report.errors.append(f"Selected hardware profile path does not exist: {path}")
        else:
            try:
                on_disk = load_json(path)
            except Exception as exc:
                report.errors.append(f"Selected hardware profile cannot be read: {type(exc).__name__}")
            else:
                if sha256_json(on_disk) != sha256_json(profile):
                    report.errors.append("Selected hardware profile path does not contain the supplied profile content.")
    return report


def _normalize_preflight_status(value: Any) -> str:
    status = str(value or "").upper()
    return status if status in {"PASS", "CAUTION", "INELIGIBLE"} else "INELIGIBLE"


def aggregate_hardware_preflight(
    hardware_profile: Mapping[str, Any],
    module_reports: Sequence[Mapping[str, Any]],
    *,
    expected_run_uuid: str = "",
) -> dict[str, Any]:
    """Aggregate live evidence for every module and stream in a profile.

    Missing modules, mismatched identities, missing expected streams, and
    ineligible module evidence make the whole profile ineligible.  Cautions
    propagate only when no ineligible condition exists.
    """
    errors: list[str] = []
    cautions: list[str] = []
    identity = validate_hardware_profile_identity(hardware_profile)
    errors.extend(identity.errors)
    cautions.extend(identity.cautions)
    expected_modules = {
        str(module.get("module_id")): module
        for module in hardware_profile.get("modules", [])
        if isinstance(module, Mapping)
    }
    reports_by_id: dict[str, Mapping[str, Any]] = {}
    run_uuid = str(expected_run_uuid or "").strip()
    if not run_uuid:
        reported_run_uuids = {
            str(report.get("expected_run_uuid") or report.get("run_uuid") or "").strip()
            for report in module_reports
            if str(report.get("expected_run_uuid") or report.get("run_uuid") or "").strip()
        }
        if len(reported_run_uuids) == 1:
            run_uuid = reported_run_uuids.pop()
        elif len(reported_run_uuids) > 1:
            errors.append("Module preflight reports disagree about the bound run UUID.")
    for report in module_reports:
        module_id = str(report.get("module_id", ""))
        if not module_id:
            errors.append("A module preflight report has no module_id.")
        elif module_id in reports_by_id:
            errors.append(f"Duplicate preflight evidence for module {module_id}.")
        else:
            reports_by_id[module_id] = report
        if report.get("schema") != "PRAYCG_HardwareModulePreflight_v1_0_alpha_2":
            errors.append(f"Preflight for {module_id or 'an unknown module'} has an unsupported schema.")
        observed_run_uuid = str(report.get("expected_run_uuid") or report.get("run_uuid") or "").strip()
        if run_uuid and observed_run_uuid != run_uuid:
            errors.append(f"Preflight for {module_id or 'an unknown module'} is not bound to the expected run UUID.")
    unexpected = sorted(set(reports_by_id) - set(expected_modules))
    if unexpected:
        errors.append("Preflight contains modules outside the selected profile: " + ", ".join(unexpected))
    evidence: list[dict[str, Any]] = []
    for module_id, expected in expected_modules.items():
        report = reports_by_id.get(module_id)
        if report is None:
            errors.append(f"Selected module has no preflight evidence: {module_id}.")
            continue
        expected_file_hash = expected.get("module_file_sha256") or expected.get("sha256")
        expected_canonical_hash = expected.get("module_canonical_sha256")
        observed_file_hash = report.get("module_file_sha256") or report.get("module_sha256")
        observed_canonical_hash = report.get("module_canonical_sha256")
        if expected_file_hash and observed_file_hash != expected_file_hash:
            errors.append(f"Preflight file hash does not match selected module {module_id}.")
        if expected_canonical_hash and observed_canonical_hash != expected_canonical_hash:
            errors.append(f"Preflight canonical hash does not match selected module {module_id}.")
        expected_streams = {
            str(stream.get("lsl_name"))
            for stream in expected.get("streams", [])
            if isinstance(stream, Mapping) and stream.get("lsl_name")
        }
        reported_stream_rows = [
            stream for stream in report.get("streams", [])
            if isinstance(stream, Mapping) and stream.get("lsl_name")
        ]
        reported_stream_names = [str(stream.get("lsl_name")) for stream in reported_stream_rows]
        reported_streams = set(reported_stream_names)
        if len(reported_stream_names) != len(reported_streams):
            errors.append(f"Preflight for {module_id} repeats stream evidence.")
        missing_streams = sorted(expected_streams - reported_streams)
        if missing_streams:
            errors.append(f"Preflight for {module_id} omits expected streams: {', '.join(missing_streams)}.")
        unexpected_streams = sorted(reported_streams - expected_streams)
        if unexpected_streams:
            errors.append(f"Preflight for {module_id} includes undeclared streams: {', '.join(unexpected_streams)}.")
        expected_stream_rows = {
            str(stream.get("lsl_name")): stream
            for stream in expected.get("streams", [])
            if isinstance(stream, Mapping) and stream.get("lsl_name")
        }
        for stream in reported_stream_rows:
            stream_name = str(stream.get("lsl_name"))
            declared_stream = expected_stream_rows.get(stream_name, {})
            if stream.get("status") == "INELIGIBLE":
                continue
            if stream.get("resolved_candidate_count") != 1:
                errors.append(f"Preflight for {module_id}/{stream_name} does not prove a unique resolved outlet.")
            observed_source_id = str(stream.get("observed_source_id") or "").strip()
            if not observed_source_id:
                errors.append(f"Preflight for {module_id}/{stream_name} omits the observed source_id.")
                continue
            policy = str(declared_stream.get("source_id_policy") or ("fixed" if declared_stream.get("source_id") else "unspecified")).lower()
            declared_source_id = str(declared_stream.get("source_id") or "").strip()
            prefix = str(declared_stream.get("source_id_prefix") or "").strip()
            suffix = str(declared_stream.get("source_id_suffix") or "").strip()
            run_identity_fragment = run_uuid.replace("-", "")[:12]
            if policy == "fixed" and declared_source_id and observed_source_id != declared_source_id:
                errors.append(f"Preflight source_id mismatch for {module_id}/{stream_name}.")
            elif policy == "dynamic_run_bound":
                if prefix and not observed_source_id.startswith(prefix):
                    errors.append(f"Preflight source_id prefix mismatch for {module_id}/{stream_name}.")
                if suffix and not observed_source_id.endswith(suffix):
                    errors.append(f"Preflight source_id suffix mismatch for {module_id}/{stream_name}.")
                if run_identity_fragment and run_identity_fragment not in observed_source_id.replace("-", ""):
                    errors.append(f"Preflight source_id is not run-bound for {module_id}/{stream_name}.")
            elif policy == "connection_specific":
                examples = {str(value) for value in declared_stream.get("source_id_examples", [])}
                if examples and observed_source_id not in examples:
                    errors.append(f"Preflight connection-specific source_id mismatch for {module_id}/{stream_name}.")
        stream_statuses = {_normalize_preflight_status(stream.get("status")) for stream in reported_stream_rows}
        if "INELIGIBLE" in stream_statuses:
            errors.append(f"At least one expected stream for {module_id} is INELIGIBLE.")
        elif "CAUTION" in stream_statuses:
            cautions.append(f"At least one expected stream for {module_id} requires review.")
        status = _normalize_preflight_status(report.get("status"))
        if status == "INELIGIBLE":
            errors.append(f"Preflight for {module_id} is INELIGIBLE.")
        elif status == "CAUTION":
            cautions.append(f"Preflight for {module_id} requires review.")
        child_report = deepcopy(dict(report))
        child_report_sha256 = sha256_json(child_report)
        evidence.append({
            "module_id": module_id,
            "module_file_sha256": observed_file_hash,
            "module_canonical_sha256": observed_canonical_hash,
            "status": status,
            "report_sha256": child_report_sha256,
            "report": child_report,
        })
    status = "INELIGIBLE" if errors else ("CAUTION" if cautions else "PASS")
    report = {
        "schema": "PRAYCG_HardwareProfilePreflight_v1_0_alpha_2",
        "platform_version": PLATFORM_VERSION,
        "generated_utc": utc_now(),
        "hardware_profile_id": hardware_profile.get("profile_id"),
        "hardware_profile_canonical_sha256": hardware_profile.get("canonical_sha256"),
        "run_uuid": run_uuid,
        "status": status,
        "errors": errors,
        "cautions": cautions,
        "module_evidence": evidence,
        "boundary": "This is a transport and signal-health gate. It does not establish cortical origin, construct validity, or exact timing alignment.",
    }
    report["canonical_sha256"] = _canonical_stored_hash(report)
    return report


def resolve_analysis_capabilities(
    protocol: Mapping[str, Any],
    hardware_profile: Mapping[str, Any],
) -> dict[str, Any]:
    if protocol.get("schema") == ATLAS_PROTOCOL_SCHEMA:
        handoff = protocol.get("analysis_handoff", {})
        roles = sorted(str(role) for role in hardware_profile.get("resolved_roles", {}))
        conditions = sorted(str(value) for value in handoff.get("condition_labels", []) if str(value).strip()) if isinstance(handoff, Mapping) else []
        return {
            "schema": "PRAYCG_AnalysisCapabilityResolution_v0_2",
            "platform_version": PLATFORM_VERSION,
            "generated_utc": utc_now(),
            "conditions": conditions,
            "roles": roles,
            "capabilities": {
                "Protocol_Specific_Analysis_Handoff": {
                    "status": "AVAILABLE" if isinstance(handoff, Mapping) and bool(handoff.get("expected_events")) else "UNAVAILABLE",
                    "reason": "Uses only the Atlas module's declared event and response contract; no construct-equivalence alias is inferred.",
                    "classification": "PROTOCOL_SPECIFIC_UNVALIDATED_UNLESS_SEPARATELY_REGISTERED",
                },
                "Master_Comprehensive_Suite": {
                    "status": "UNAVAILABLE",
                    "reason": "Atlas adaptations do not inherit PRAYCG3/PRAYCG4 analysis eligibility unless a separate reviewed adapter establishes it.",
                    "classification": "NOT_APPLICABLE_BY_DEFAULT",
                },
            },
        }
    result = legacy.resolve_analysis_capabilities(protocol, hardware_profile)
    result["platform_version"] = PLATFORM_VERSION
    return result


def _validate_protocol_selection(
    template: Mapping[str, Any],
    protocol_snapshot: Mapping[str, Any],
    report: ValidationReport,
) -> tuple[dict[str, Any] | None, Path | None]:
    if not _approved_protocol(protocol_snapshot):
        report.errors.append("Protocol input is not an approved design-time snapshot.")
        return None, None
    try:
        snapshot_identity = _protocol_snapshot_identity(protocol_snapshot)
    except ValueError as exc:
        report.errors.append(str(exc))
        return None, None
    path_value = template.get("protocol_module")
    path = Path(str(path_value)).resolve() if path_value else None
    if path is None or not path.is_file():
        report.errors.append("Selected protocol_module path does not exist.")
        return None, path
    try:
        module = load_json(path)
    except Exception as exc:
        report.errors.append(f"Selected protocol module cannot be read: {type(exc).__name__}.")
        return None, path
    if protocol_snapshot.get("schema") == PROTOCOL_SNAPSHOT_SCHEMA:
        core = protocol_snapshot.get("snapshot_core", {})
        expected_file = core.get("protocol_module_sha256")
        expected_canonical = core.get("canonical_protocol_sha256")
        expected_runner = core.get("runner_sha256")
        runner_entry = core.get("runner_entry")
        expected_engine = core.get("engine_sha256")
        engine_entry = core.get("engine_entry")
        source_path = protocol_snapshot.get("source_protocol_path")
        library_root_value = protocol_snapshot.get("library_root")
    else:
        expected_file = protocol_snapshot.get("protocol_module_sha256")
        expected_canonical = protocol_snapshot.get("canonical_protocol_sha256")
        expected_runner = protocol_snapshot.get("runner_sha256")
        runner_entry = protocol_snapshot.get("runner_entry")
        expected_engine = None
        engine_entry = None
        source_path = None
        library_root_value = None
    if expected_file and sha256_file(path) != expected_file:
        report.errors.append("Selected protocol file hash does not match the approved protocol snapshot.")
    if expected_canonical and sha256_json(module) != expected_canonical:
        report.errors.append("Selected protocol content does not match the approved protocol snapshot.")
    if source_path and Path(str(source_path)).resolve() != path:
        report.errors.append("Selected protocol path differs from the path recorded in the approved snapshot.")
    library_root = Path(str(library_root_value)).resolve() if library_root_value else path.parent.parent
    runner_path = (library_root / str(runner_entry or "")).resolve()
    if not runner_entry or not resolved_within(runner_path, library_root):
        report.errors.append("Approved protocol runner path is missing or resolves outside its library.")
    elif not runner_path.is_file():
        report.errors.append("Approved protocol runner path no longer exists.")
    elif not expected_runner or sha256_file(runner_path) != expected_runner:
        report.errors.append("Approved protocol runner file identity has changed.")
    engine_path = (library_root / str(engine_entry or "")).resolve()
    if protocol_snapshot.get("schema") == PROTOCOL_SNAPSHOT_SCHEMA:
        if not engine_entry or not resolved_within(engine_path, library_root):
            report.errors.append("Approved shared protocol engine path is missing or resolves outside its library.")
        elif not engine_path.is_file():
            report.errors.append("Approved shared protocol engine file no longer exists.")
        elif not expected_engine or sha256_file(engine_path) != expected_engine:
            report.errors.append("Approved shared protocol engine identity has changed.")
    return {
        "protocol_id": module.get("protocol_id"),
        "protocol_version": module.get("protocol_version"),
        "protocol_snapshot_sha256": snapshot_identity,
        "protocol_snapshot_core_sha256": protocol_snapshot.get("snapshot_sha256"),
        "protocol_module_file_sha256": sha256_file(path),
        "protocol_module_canonical_sha256": sha256_json(module),
        "runner_file_sha256": sha256_file(runner_path) if runner_path.is_file() else None,
        "engine_file_sha256": sha256_file(engine_path) if engine_path.is_file() else None,
    }, path


def build_session_draft(
    template: Mapping[str, Any],
    protocol_snapshot: Mapping[str, Any],
    hardware_profile: Mapping[str, Any],
    output_path: Path,
    *,
    protocol_snapshot_path: Path | None = None,
    hardware_profile_path: Path | None = None,
) -> dict[str, Any]:
    """Validate selections and create a pre-lock runtime session draft."""
    validation = ValidationReport(subject=str(template.get("study_id") or "study session"))
    if template.get("schema") not in SESSION_TEMPLATE_SCHEMAS:
        validation.errors.append("Session template schema is not recognized.")
    for key in ("study_id", "session_id", "participant_pseudonym", "protocol_module", "hardware_profile"):
        if not template.get(key):
            validation.errors.append(f"Session template is missing {key}.")
    protocol_identity, module_path = _validate_protocol_selection(template, protocol_snapshot, validation)
    selected_profile_path = Path(str(template.get("hardware_profile", ""))).resolve() if template.get("hardware_profile") else None
    if hardware_profile_path is not None and selected_profile_path is not None:
        if Path(hardware_profile_path).resolve() != selected_profile_path:
            validation.errors.append("Selected hardware profile path differs from the path in the session template.")
    profile_validation = validate_hardware_profile_identity(
        hardware_profile,
        profile_path=selected_profile_path,
    )
    validation.errors.extend(profile_validation.errors)
    validation.cautions.extend(profile_validation.cautions)
    if protocol_snapshot_path is not None:
        path = Path(protocol_snapshot_path)
        if not path.is_file():
            validation.errors.append("Selected approved protocol snapshot path does not exist.")
        else:
            try:
                disk_snapshot = load_json(path)
            except Exception as exc:
                validation.errors.append(f"Approved protocol snapshot cannot be read: {type(exc).__name__}.")
            else:
                if sha256_json(disk_snapshot) != sha256_json(protocol_snapshot):
                    validation.errors.append("Approved protocol snapshot path does not contain the supplied snapshot content.")
    protocol_module = load_json(module_path) if module_path and module_path.is_file() else {}
    capability = resolve_analysis_capabilities(protocol_module, hardware_profile) if protocol_module else {"capabilities": {}}
    identity = {
        "study_id": template.get("study_id"),
        "session_id": template.get("session_id"),
        "participant_pseudonym": template.get("participant_pseudonym"),
        "protocol": protocol_identity,
        "hardware_profile_canonical_sha256": hardware_profile.get("canonical_sha256"),
    }
    draft = {
        "schema": SESSION_DRAFT_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "artifact_type": "RUNTIME_SESSION_DRAFT_NOT_A_LOCK",
        "created_utc": utc_now(),
        "status": "READY_TO_CONNECT" if validation.status != "INELIGIBLE" else "INVALID_SELECTION",
        "current_stage": "SELECT" if validation.status != "INELIGIBLE" else "UNSET",
        "gate_status": {
            stage: ("PASS" if stage == "SELECT" and validation.status != "INELIGIBLE" else "PENDING")
            for stage in SESSION_STAGES
        },
        "session": deepcopy(dict(template)),
        "selection_identity": identity,
        "protocol_snapshot": deepcopy(dict(protocol_snapshot)),
        "hardware_profile": deepcopy(dict(hardware_profile)),
        "analysis_capability_resolution": capability,
        "validation": validation.as_dict(),
    }
    draft["draft_identity_sha256"] = sha256_json({
        "session": draft["session"],
        "selection_identity": draft["selection_identity"],
        "protocol_snapshot": draft["protocol_snapshot"],
        "hardware_profile": draft["hardware_profile"],
    })
    write_json(Path(output_path), draft)
    return draft


def validate_session_draft_identity(draft: Mapping[str, Any]) -> ValidationReport:
    report = ValidationReport(subject="runtime session draft")
    if draft.get("schema") != SESSION_DRAFT_SCHEMA:
        report.errors.append("Session draft schema is not recognized.")
        return report
    expected = sha256_json({
        "session": draft.get("session"),
        "selection_identity": draft.get("selection_identity"),
        "protocol_snapshot": draft.get("protocol_snapshot"),
        "hardware_profile": draft.get("hardware_profile"),
    })
    if draft.get("draft_identity_sha256") != expected:
        report.errors.append("Session draft identity changed after selection validation.")
    if draft.get("gate_status", {}).get("SELECT") != "PASS":
        report.errors.append("SELECT must pass before CONNECT or PREFLIGHT.")
    return report


def _runner_configuration_policy(
    session: Mapping[str, Any],
    hardware_profile: Mapping[str, Any],
) -> dict[str, Any]:
    """Freeze the research-critical runner controls used by the public alpha."""
    roles = {str(role) for role in hardware_profile.get("resolved_roles", {})}
    for module in hardware_profile.get("modules", []):
        if not isinstance(module, Mapping):
            continue
        for stream in module.get("streams", []):
            if not isinstance(stream, Mapping):
                continue
            if stream.get("canonical_role"):
                roles.add(str(stream.get("canonical_role")))
            roles.update(str(role) for role in stream.get("embedded_roles", []))
    phases = [str(value) for value in session.get("assigned_sequence", []) if str(value).strip()]
    private_outputs = session.get("private_output_locations", {})
    session_log_dir = ""
    if isinstance(private_outputs, Mapping):
        session_log_dir = str(private_outputs.get("session_log_dir") or "")
    return {
        "policy_version": "PRAYCG_RunnerConfigurationPolicy_v1_0_alpha_2",
        "baseline_seconds": 120.0,
        "washout_seconds": 120.0,
        "stillness_reset_seconds": 8.0,
        "enable_final_reflection_baseline": True,
        "final_reflection_baseline_seconds": 120.0,
        "enable_prerun_display_audio_calibration": True,
        "enable_per_phase_confound_reports": True,
        "enable_override_rsm_report": True,
        "use_standard_channel_map": True,
        "movie_display_mode": "safe_fit",
        "movie_safe_fit_fraction": 0.92,
        "movie_custom_width_px": 0,
        "movie_custom_height_px": 0,
        "enable_eeg_watchdog": "eeg" in roles,
        "eeg_watchdog_stream_name": "obci_eeg1",
        "eeg_watchdog_expected_rate_hz": 125.0,
        "eeg_watchdog_warning_gap_sec": 1.0,
        "eeg_watchdog_invalid_gap_sec": 3.0,
        "eeg_watchdog_rate_warn_hz": 115.0,
        "eeg_watchdog_rate_invalid_hz": 100.0,
        "enable_runner_als_barcode": "als" in roles,
        "als_barcode_source": "runner_overlay",
        "als_barcode_mode": "long_short",
        "als_barcode_position": "lower_right",
        "als_barcode_size_px": 180,
        "als_barcode_margin_px": 40,
        "als_barcode_black_pre_sec": 0.50,
        "als_barcode_white_a_sec": 2.00,
        "als_barcode_black_gap_sec": 0.50,
        "als_barcode_white_b_sec": 0.75,
        "als_barcode_black_post_sec": 1.00,
        "als_barcode_apply_phases": phases,
        "als_barcode_emit_alias_markers": True,
        "session_log_dir": session_log_dir,
    }


def _history_event(
    stage: str,
    operator: str,
    evidence: Mapping[str, Any] | None,
    previous_event_sha256: str | None,
) -> dict[str, Any]:
    event = {
        "stage": stage,
        "recorded_utc": utc_now(),
        "operator": operator,
        "evidence": deepcopy(dict(evidence)) if evidence is not None else None,
        "evidence_sha256": sha256_json(evidence) if evidence is not None else None,
        "previous_event_sha256": previous_event_sha256,
    }
    event["event_sha256"] = sha256_json(_without(event, "event_sha256"))
    return event


def acquire_claim_errors(
    session_lock: Mapping[str, Any],
    evidence: Mapping[str, Any] | None,
) -> list[str]:
    """Validate the one semantic claim that authorizes a runner process spawn.

    This evidence is intentionally stricter than a generic gate attachment.  It
    binds the atomic ARM -> ACQUIRE transition to the selected run, launch
    mechanism, protocol identity, and exact approved runner file.
    """
    errors: list[str] = []
    if not isinstance(evidence, Mapping):
        return ["ACQUIRE requires structured authorized-runner process-claim evidence."]

    def require_text(field: str) -> str:
        value = evidence.get(field)
        if not isinstance(value, str) or not value.strip():
            errors.append(f"ACQUIRE process claim has a missing or malformed {field}.")
            return ""
        return value.strip()

    event = require_text("event")
    run_uuid = require_text("run_uuid")
    launch_mode = require_text("launch_mode")
    protocol_id = require_text("protocol_id")
    protocol_version = require_text("protocol_version")
    runner_sha256 = require_text("runner_sha256").lower()
    lease_path_value = require_text("lease_path")
    lease_id = require_text("lease_id")
    lease_core_sha256 = require_text("lease_core_sha256").lower()
    lease_claim_token_sha256 = require_text("lease_claim_token_sha256").lower()
    armed_state_sha256 = require_text("armed_state_sha256").lower()
    active_owner_path_value = require_text("active_owner_path")
    active_owner_id = require_text("active_owner_id")
    active_owner_core_sha256 = require_text("active_owner_core_sha256").lower()

    if event and event != AUTHORIZED_ACQUIRE_EVENT:
        errors.append(
            f"ACQUIRE process claim event must be exactly {AUTHORIZED_ACQUIRE_EVENT}."
        )
    if launch_mode and launch_mode not in SUPPORTED_DIRECT_RUNNER_LAUNCH_MODES:
        errors.append(
            "ACQUIRE process claim launch_mode must be a supported direct mode: "
            + ", ".join(sorted(SUPPORTED_DIRECT_RUNNER_LAUNCH_MODES))
            + "."
        )
    if runner_sha256 and not _SHA256_HEX_RE.fullmatch(runner_sha256):
        errors.append("ACQUIRE process claim runner_sha256 is not a lowercase SHA-256 digest.")
    for field, digest in (
        ("lease_core_sha256", lease_core_sha256),
        ("lease_claim_token_sha256", lease_claim_token_sha256),
        ("armed_state_sha256", armed_state_sha256),
        ("active_owner_core_sha256", active_owner_core_sha256),
    ):
        if digest and not _SHA256_HEX_RE.fullmatch(digest):
            errors.append(f"ACQUIRE process claim {field} is not a lowercase SHA-256 digest.")

    session = session_lock.get("session")
    locked_run_uuid = str(session.get("session_id") or "").strip() if isinstance(session, Mapping) else ""
    protocol = session_lock.get("lock_core", {}).get("selection_identity", {}).get("protocol", {})
    if not isinstance(protocol, Mapping):
        protocol = {}
    locked_protocol_id = str(protocol.get("protocol_id") or "").strip()
    locked_protocol_version = str(protocol.get("protocol_version") or "").strip()
    locked_runner_sha256 = str(protocol.get("runner_file_sha256") or "").strip().lower()

    if not locked_run_uuid:
        errors.append("Runtime session lock has no run UUID for the ACQUIRE process claim.")
    elif run_uuid and run_uuid != locked_run_uuid:
        errors.append("ACQUIRE process claim run_uuid does not match the locked runtime session.")
    if not locked_protocol_id or not locked_protocol_version:
        errors.append("Runtime session lock lacks the selected protocol id/version for ACQUIRE.")
    else:
        if protocol_id and protocol_id != locked_protocol_id:
            errors.append("ACQUIRE process claim protocol_id does not match the locked selection.")
        if protocol_version and protocol_version != locked_protocol_version:
            errors.append("ACQUIRE process claim protocol_version does not match the locked selection.")
    if not _SHA256_HEX_RE.fullmatch(locked_runner_sha256):
        errors.append("Runtime session lock lacks a valid selected runner SHA-256 for ACQUIRE.")
    elif runner_sha256 and runner_sha256 != locked_runner_sha256:
        errors.append("ACQUIRE process claim runner_sha256 does not match the locked selection.")

    session_log_dir = str(session.get("private_output_locations", {}).get("session_log_dir") or "") if isinstance(session, Mapping) else ""
    expected_lease_path = Path(session_log_dir).expanduser().resolve(strict=False) / RUNTIME_RUNNER_LEASE_FILENAME if session_log_dir else None
    expected_session_lock_path = Path(session_log_dir).expanduser().resolve(strict=False) / "runtime_session_lock.json" if session_log_dir else None
    lease_path = Path(lease_path_value).expanduser().resolve(strict=False) if lease_path_value else None
    lease: Mapping[str, Any] = {}
    if expected_lease_path is None:
        errors.append("Runtime session lock lacks its run-local artifact directory for the runner lease.")
    elif lease_path is None or not paths_equivalent(lease_path, expected_lease_path, require_existing=True):
        errors.append("ACQUIRE process claim lease_path is not the locked run-local lease path.")
    elif not lease_path.is_file():
        errors.append("ACQUIRE process claim authorized-runner lease does not exist.")
    else:
        try:
            lease = load_json(lease_path)
            lease_errors = _validate_runner_lease(lease)
        except Exception as exc:
            errors.append(f"ACQUIRE process claim authorized-runner lease is unreadable: {exc}")
            lease = {}
            lease_errors = []
        errors.extend(f"ACQUIRE process claim {item}." for item in lease_errors)
        core = lease.get("lease_core", {}) if isinstance(lease, Mapping) else {}
        if isinstance(core, Mapping):
            lock_stage = str(session_lock.get("current_stage") or "")
            if lock_stage == "ARM":
                if str(lease.get("status") or "") != "CLAIM_ISSUED":
                    errors.append("ACQUIRE process claim lease is not an unconsumed CLAIM_ISSUED capability.")
                if str(core.get("armed_state_sha256") or "") != str(session_lock.get("state_sha256") or ""):
                    errors.append("ACQUIRE process claim lease is not bound to the current ARM state.")
                if time.time() > float(core.get("claim_expires_epoch") or 0.0):
                    errors.append("ACQUIRE process claim lease expired before the gate transition.")
            exact_matches = {
                "lease_id": (lease_id, str(core.get("lease_id") or "")),
                "lease_core_sha256": (lease_core_sha256, str(lease.get("lease_core_sha256") or "")),
                "lease_claim_token_sha256": (lease_claim_token_sha256, str(core.get("claim_token_sha256") or "")),
                "armed_state_sha256": (armed_state_sha256, str(core.get("armed_state_sha256") or "")),
                "run_uuid": (run_uuid, str(core.get("run_uuid") or "")),
                "session_lock_path": (
                    normalized_path_identity(str(expected_session_lock_path or "")),
                    normalized_path_identity(str(core.get("session_lock_path") or "")),
                ),
                "lock_identity_sha256": (str(session_lock.get("lock_identity_sha256") or ""), str(core.get("lock_identity_sha256") or "")),
                "launch_mode": (launch_mode, str(core.get("launch_mode") or "")),
                "protocol_id": (locked_protocol_id, str(core.get("protocol_id") or "")),
                "protocol_version": (locked_protocol_version, str(core.get("protocol_version") or "")),
                "runner_file_sha256": (locked_runner_sha256, str(core.get("runner_file_sha256") or "")),
                "protocol_module_file_sha256": (
                    str(protocol.get("protocol_module_file_sha256") or ""),
                    str(core.get("protocol_module_file_sha256") or ""),
                ),
                "engine_file_sha256": (
                    str(protocol.get("engine_file_sha256") or ""),
                    str(core.get("engine_file_sha256") or ""),
                ),
                "stimulus_id": (
                    str(session.get("stimulus_id") or "") if isinstance(session, Mapping) else "",
                    str(core.get("stimulus_id") or ""),
                ),
                "media_selection_sha256": (
                    sha256_json(session.get("media_selection_snapshot", {})) if isinstance(session, Mapping) else "",
                    str(core.get("media_selection_sha256") or ""),
                ),
                "controller_instance_id": (
                    str(session.get("control_center_process_id") or "") if isinstance(session, Mapping) else "",
                    str(core.get("controller_instance_id") or ""),
                ),
            }
            for field, (expected, observed) in exact_matches.items():
                if expected != observed:
                    errors.append(f"ACQUIRE process claim lease {field} does not match the armed runtime selection.")
            expected_folder = str(session.get("stimulus_folder") or "") if isinstance(session, Mapping) else ""
            if expected_folder and normalized_path_identity(expected_folder) != str(core.get("stimulus_folder") or ""):
                errors.append("ACQUIRE process claim lease stimulus_folder does not match the armed runtime selection.")
    expected_owner_path = expected_lease_path.parent.parent / ACTIVE_ACQUISITION_OWNER_FILENAME if expected_lease_path is not None else None
    supplied_owner_path = Path(active_owner_path_value).expanduser().resolve(strict=False) if active_owner_path_value else None
    if expected_owner_path is None:
        errors.append("Runtime session lock lacks its canonical log-root owner path.")
    elif supplied_owner_path is None or not paths_equivalent(supplied_owner_path, expected_owner_path, require_existing=False):
        errors.append("ACQUIRE process claim active_owner_path is not the canonical log-root owner path.")
    else:
        try:
            _resolved_owner_path, owner = load_active_acquisition_owner_identity(
                supplied_owner_path,
                owner_id=active_owner_id,
                owner_core_sha256=active_owner_core_sha256,
            )
        except Exception as exc:
            errors.append(f"ACQUIRE process claim active-acquisition owner cannot be resolved: {exc}")
            owner = {}
        if isinstance(owner, Mapping) and owner:
            owner_core = owner.get("owner_core", {})
            lock_stage = str(session_lock.get("current_stage") or "")
            owner_status = str(owner.get("status") or "")
            if lock_stage == "ARM" and owner_status != "LEASE_BOUND":
                errors.append("ACQUIRE process claim active-acquisition owner is not LEASE_BOUND before transition.")
            elif lock_stage != "ARM" and owner_status not in {"LEASE_BOUND", "RELEASED"}:
                errors.append("ACQUIRE process claim active-acquisition owner has no valid acquired or released state.")
            owner_exact = {
                "owner_id": (active_owner_id, str(owner_core.get("owner_id") or "")),
                "owner_core_sha256": (active_owner_core_sha256, str(owner.get("owner_core_sha256") or "")),
                "run_uuid": (locked_run_uuid, str(owner_core.get("run_uuid") or "")),
                "session_lock_path": (
                    normalized_path_identity(str(expected_session_lock_path or "")),
                    normalized_path_identity(str(owner_core.get("session_lock_path") or "")),
                ),
                "lock_identity_sha256": (
                    str(session_lock.get("lock_identity_sha256") or ""),
                    str(owner_core.get("lock_identity_sha256") or ""),
                ),
                "armed_state_sha256": (armed_state_sha256, str(owner_core.get("armed_state_sha256") or "")),
                "controller_instance_id": (
                    str(session.get("control_center_process_id") or "") if isinstance(session, Mapping) else "",
                    str(owner_core.get("controller_instance_id") or ""),
                ),
                "expected_lease_path": (
                    normalized_path_identity(str(expected_lease_path or "")),
                    normalized_path_identity(str(owner_core.get("expected_lease_path") or "")),
                ),
            }
            for field, (expected, observed) in owner_exact.items():
                if expected != observed:
                    errors.append(f"ACQUIRE process claim active-acquisition owner {field} does not match the armed runtime selection.")
            binding = owner.get("lease_binding")
            if not isinstance(binding, Mapping):
                errors.append("ACQUIRE process claim active-acquisition owner lacks its exact runner-lease binding.")
            elif not lease:
                errors.append("ACQUIRE process claim owner binding cannot be checked without its runner lease.")
            else:
                errors.extend(
                    "ACQUIRE process claim " + item + "."
                    for item in _active_owner_binding_errors(binding, owner, lease)
                )
            if owner_status == "RELEASED":
                marker_path = Path(str(owner_core.get("terminal_marker_path") or "")).expanduser().resolve(strict=False)
                try:
                    marker = load_json(marker_path)
                    marker_errors = _active_owner_terminal_errors(marker, owner)
                except Exception as exc:
                    marker_errors = [f"released owner terminal record is unreadable: {exc}"]
                errors.extend("ACQUIRE process claim " + item + "." for item in marker_errors)
    return errors


def build_session_lock(
    session_draft: Mapping[str, Any],
    preflight_report: Mapping[str, Any],
    output_path: Path,
    *,
    operator: str,
    allow_caution_override: bool = False,
    override_reason: str = "",
) -> dict[str, Any]:
    """Bind full-profile preflight evidence into the one runtime lock schema."""
    validation = validate_session_draft_identity(session_draft)
    profile = session_draft.get("hardware_profile", {})
    if preflight_report.get("schema") != "PRAYCG_HardwareProfilePreflight_v1_0_alpha_2":
        validation.errors.append("A full-profile alpha.2 preflight report is required.")
    stored_preflight_hash = preflight_report.get("canonical_sha256")
    if not _nonempty(stored_preflight_hash) or stored_preflight_hash != _canonical_stored_hash(preflight_report):
        validation.errors.append("Preflight report canonical hash is missing or invalid.")
    if preflight_report.get("hardware_profile_canonical_sha256") != profile.get("canonical_sha256"):
        validation.errors.append("Preflight evidence belongs to a different hardware profile.")
    preflight_run_uuid = str(preflight_report.get("run_uuid") or "").strip()
    session_run_uuid = str(session_draft.get("session", {}).get("session_id") or "").strip()
    if not preflight_run_uuid:
        validation.errors.append("Preflight evidence is not bound to a runtime session UUID.")
    elif preflight_run_uuid != session_run_uuid:
        validation.errors.append("Preflight evidence belongs to a different runtime session UUID.")
    profile_preflight_status = _normalize_preflight_status(preflight_report.get("status"))
    declared_readiness = str(session_draft.get("session", {}).get("control_center_readiness") or "").upper()
    if declared_readiness and declared_readiness not in {"PASS", "CAUTION", "INELIGIBLE"}:
        validation.errors.append("Control Center readiness has an unsupported status.")
    preflight_status = (
        "INELIGIBLE" if "INELIGIBLE" in {profile_preflight_status, declared_readiness}
        else "CAUTION" if "CAUTION" in {profile_preflight_status, declared_readiness}
        else profile_preflight_status
    )
    if preflight_report.get("errors") and profile_preflight_status != "INELIGIBLE":
        validation.errors.append("Preflight status conflicts with its recorded errors.")
    if preflight_report.get("cautions") and profile_preflight_status == "PASS":
        validation.errors.append("Preflight status conflicts with its recorded cautions.")
    expected_modules = {
        str(item.get("module_id")): item
        for item in profile.get("modules", [])
        if isinstance(item, Mapping)
    }
    observed_evidence: dict[str, Mapping[str, Any]] = {}
    for item in preflight_report.get("module_evidence", []):
        if not isinstance(item, Mapping) or not item.get("module_id"):
            validation.errors.append("Preflight has malformed module evidence.")
            continue
        module_id = str(item.get("module_id"))
        if module_id in observed_evidence:
            validation.errors.append(f"Preflight repeats module evidence for {module_id}.")
        observed_evidence[module_id] = item
        child_report = item.get("report")
        if not isinstance(child_report, Mapping):
            validation.errors.append(f"Preflight omits preserved child evidence for {module_id}.")
        elif item.get("report_sha256") != sha256_json(child_report):
            validation.errors.append(f"Preflight child evidence hash mismatch for {module_id}.")
    if set(observed_evidence) != set(expected_modules):
        validation.errors.append("Preflight module evidence does not exactly match the selected hardware profile.")
    for module_id, expected in expected_modules.items():
        observed = observed_evidence.get(module_id, {})
        expected_file = expected.get("module_file_sha256") or expected.get("sha256")
        if observed.get("module_file_sha256") != expected_file:
            validation.errors.append(f"Preflight evidence file hash mismatch for {module_id}.")
        expected_canonical = expected.get("module_canonical_sha256")
        if expected_canonical and observed.get("module_canonical_sha256") != expected_canonical:
            validation.errors.append(f"Preflight evidence canonical hash mismatch for {module_id}.")
    override: dict[str, Any] | None = None
    if preflight_status == "INELIGIBLE":
        validation.errors.append("INELIGIBLE preflight evidence cannot be overridden or session-locked.")
    elif preflight_status == "CAUTION":
        if not allow_caution_override:
            validation.errors.append("CAUTION requires an explicit documented operator override before session lock.")
        elif not _nonempty(override_reason) or not _recorded_identity(operator):
            validation.errors.append("CAUTION override requires both an operator and a non-empty reason.")
        else:
            override = {
                "type": "PREFLIGHT_CAUTION_ACCEPTED",
                "operator": operator,
                "reason": override_reason.strip(),
                "recorded_utc": utc_now(),
            }
    elif not _recorded_identity(operator):
        validation.errors.append("Session lock requires a recorded operator.")
    locked_session = deepcopy(session_draft.get("session", {}))
    if not isinstance(locked_session, dict):
        validation.errors.append("Runtime session metadata is malformed.")
        locked_session = {}
    locked_session["runner_configuration_policy"] = _runner_configuration_policy(locked_session, profile)
    lockable = validation.status != "INELIGIBLE"
    gate_status = {stage: "PENDING" for stage in SESSION_STAGES}
    if lockable:
        gate_status.update({
            "SELECT": "PASS",
            "CONNECT": "PASS",
            "PREFLIGHT": "CAUTION_ACCEPTED" if override else "PASS",
            "SESSION_LOCK": "PASS",
        })
    lock_core = {
        "session_draft_identity_sha256": session_draft.get("draft_identity_sha256"),
        "session_identity_sha256": sha256_json(locked_session),
        "analysis_capability_resolution_sha256": sha256_json(session_draft.get("analysis_capability_resolution", {})),
        "selection_identity": deepcopy(session_draft.get("selection_identity")),
        "protocol_snapshot_sha256": session_draft.get("selection_identity", {}).get("protocol", {}).get("protocol_snapshot_sha256"),
        "hardware_profile_canonical_sha256": profile.get("canonical_sha256"),
        "preflight_report_sha256": stored_preflight_hash,
        "profile_preflight_status": profile_preflight_status,
        "preflight_status": preflight_status,
        "caution_override": override,
        "operator": operator,
    }
    initial_evidence = {
        "session_draft_identity_sha256": session_draft.get("draft_identity_sha256"),
        "preflight_report_sha256": stored_preflight_hash,
    }
    lock = {
        "schema": SESSION_LOCK_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "artifact_type": "RUNTIME_SESSION_LOCK",
        "created_utc": utc_now(),
        "status": "LOCKED_READY_TO_ARM" if lockable else "NOT_LOCKABLE",
        "current_stage": "SESSION_LOCK" if lockable else "PREFLIGHT",
        "gate_status": gate_status,
        "lock_core": lock_core,
        "lock_identity_sha256": sha256_json(lock_core),
        "session": locked_session,
        "analysis_capability_resolution": deepcopy(session_draft.get("analysis_capability_resolution")),
        "validation": validation.as_dict(),
        "runtime_history": [_history_event("SESSION_LOCK", operator, initial_evidence, None)] if lockable else [],
    }
    lock["state_sha256"] = _session_state_sha256(lock)
    write_json(Path(output_path), lock)
    return lock


def validate_session_lock_identity(lock: Mapping[str, Any]) -> ValidationReport:
    report = ValidationReport(subject="runtime session lock")
    if lock.get("schema") != SESSION_LOCK_SCHEMA:
        report.errors.append("Runtime session lock schema is not recognized.")
        return report
    core = lock.get("lock_core")
    if not isinstance(core, Mapping) or lock.get("lock_identity_sha256") != sha256_json(core):
        report.errors.append("Runtime session lock identity is missing or has changed.")
    elif core.get("session_identity_sha256") != sha256_json(lock.get("session", {})):
        report.errors.append("Runtime session metadata changed after the session lock was created.")
    elif core.get("analysis_capability_resolution_sha256") != sha256_json(lock.get("analysis_capability_resolution", {})):
        report.errors.append("Analysis capability resolution changed after the session lock was created.")
    gates = lock.get("gate_status")
    if not isinstance(gates, Mapping) or set(gates) != set(SESSION_STAGES):
        report.errors.append("Runtime gate-status keys do not exactly match the canonical state machine.")
        gates = {}
    if gates.get("SESSION_LOCK") != "PASS":
        report.errors.append("SESSION_LOCK gate has not passed.")
    stage = str(lock.get("current_stage") or "")
    if stage not in SESSION_STAGES[SESSION_STAGES.index("SESSION_LOCK"):]:
        report.errors.append("Runtime current_stage is not a valid locked-session stage.")
    else:
        current_index = SESSION_STAGES.index(stage)
        for index, name in enumerate(SESSION_STAGES):
            observed = gates.get(name)
            if index <= current_index:
                allowed = {"PASS"}
                if name == "PREFLIGHT" and lock.get("lock_core", {}).get("caution_override"):
                    allowed.add("CAUTION_ACCEPTED")
                if observed not in allowed:
                    report.errors.append(f"Runtime gate {name} is inconsistent with current_stage {stage}.")
            elif observed != "PENDING":
                report.errors.append(f"Future runtime gate {name} must remain PENDING at stage {stage}.")
        if lock.get("status") != _STATUS_BY_STAGE.get(stage):
            report.errors.append("Runtime status is inconsistent with current_stage.")
        expected_history_stages = list(
            SESSION_STAGES[SESSION_STAGES.index("SESSION_LOCK"):current_index + 1]
        )
        history = lock.get("runtime_history")
        if not isinstance(history, list) or [row.get("stage") if isinstance(row, Mapping) else None for row in history] != expected_history_stages:
            report.errors.append("Runtime history does not exactly match the ordered completed gates.")
        else:
            previous_event_sha256: str | None = None
            for index, event in enumerate(history):
                if not isinstance(event, Mapping):
                    report.errors.append("Runtime history contains a malformed event.")
                    continue
                if not _recorded_identity(event.get("operator")):
                    report.errors.append(f"Runtime history event {index + 1} has no recorded operator.")
                if event.get("previous_event_sha256") != previous_event_sha256:
                    report.errors.append(f"Runtime history event {index + 1} breaks the event-hash chain.")
                calculated_event = sha256_json(_without(event, "event_sha256"))
                if event.get("event_sha256") != calculated_event:
                    report.errors.append(f"Runtime history event {index + 1} content has changed.")
                evidence = event.get("evidence")
                expected_evidence_hash = sha256_json(evidence) if isinstance(evidence, Mapping) else None
                if event.get("evidence_sha256") != expected_evidence_hash:
                    report.errors.append(f"Runtime history event {index + 1} evidence identity is invalid.")
                previous_event_sha256 = str(event.get("event_sha256") or "")
            if current_index >= SESSION_STAGES.index("ACQUIRE"):
                acquire_event = history[
                    SESSION_STAGES.index("ACQUIRE") - SESSION_STAGES.index("SESSION_LOCK")
                ]
                if isinstance(acquire_event, Mapping):
                    report.errors.extend(
                        acquire_claim_errors(lock, acquire_event.get("evidence"))
                    )
    stored_state = lock.get("state_sha256")
    if not _nonempty(stored_state) or stored_state != _session_state_sha256(lock):
        report.errors.append("Runtime session state hash is missing or has changed.")
    return report


def advance_session_gate(
    session_lock: Mapping[str, Any],
    target_stage: str,
    output_path: Path,
    *,
    operator: str,
    evidence: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Advance exactly one ordered runtime gate without mutating lock identity."""
    target = str(target_stage).upper()
    if target not in _POST_LOCK_STAGE_PREDECESSOR:
        raise ValueError(f"Unsupported post-lock target stage: {target}.")
    validation = validate_session_lock_identity(session_lock)
    if validation.status == "INELIGIBLE":
        raise ValueError("Runtime session lock identity is invalid: " + "; ".join(validation.errors))
    if not _recorded_identity(operator):
        raise ValueError(f"{target} requires a recorded operator.")
    predecessor = _POST_LOCK_STAGE_PREDECESSOR[target]
    if session_lock.get("current_stage") != predecessor:
        raise ValueError(
            f"Cannot advance to {target}; current stage is {session_lock.get('current_stage')!r}, "
            f"but the required immediately preceding stage is {predecessor}."
        )
    gates = dict(session_lock.get("gate_status", {}))
    if gates.get(predecessor) not in {"PASS", "CAUTION_ACCEPTED"}:
        raise ValueError(f"Cannot advance to {target}; predecessor {predecessor} has not passed.")
    earlier_target_index = SESSION_STAGES.index(target)
    incomplete = [
        stage for stage in SESSION_STAGES[:earlier_target_index]
        if gates.get(stage) not in {"PASS", "CAUTION_ACCEPTED"}
    ]
    if incomplete:
        raise ValueError(f"Cannot advance to {target}; earlier gates are incomplete: {', '.join(incomplete)}.")
    if target == "ACQUIRE":
        claim_errors = acquire_claim_errors(session_lock, evidence)
        if claim_errors:
            raise ValueError("ACQUIRE runner-process claim is invalid: " + "; ".join(claim_errors))
    output_path = Path(output_path).resolve()
    if output_path.is_file():
        on_disk = load_json(output_path)
        if on_disk.get("state_sha256") != session_lock.get("state_sha256"):
            raise ValueError(
                f"Cannot advance to {target}; the on-disk session state changed after it was read."
            )
    transition_claim = output_path.with_name(
        f"{output_path.name}.{str(session_lock.get('lock_identity_sha256') or '')[:12]}.{target.lower()}.transition_claim.json"
    )
    transition_claim.parent.mkdir(parents=True, exist_ok=True)
    claim_payload = {
        "schema": "PRAYCG_RuntimeGateTransitionClaim_v0_1",
        "lock_identity_sha256": session_lock.get("lock_identity_sha256"),
        "input_state_sha256": session_lock.get("state_sha256"),
        "target_stage": target,
        "operator": operator,
        "claimed_utc": utc_now(),
    }
    try:
        descriptor = os.open(
            str(transition_claim),
            os.O_WRONLY | os.O_CREAT | os.O_EXCL,
        )
    except FileExistsError as exc:
        raise ValueError(
            f"Cannot advance to {target}; this exact transition was already claimed. "
            "Do not launch or submit the same gate twice."
        ) from exc
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(canonical_json_bytes(claim_payload).decode("utf-8") + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    result = deepcopy(dict(session_lock))
    result["gate_status"] = gates
    result["gate_status"][target] = "PASS"
    result["current_stage"] = target
    result["status"] = _STATUS_BY_STAGE[target]
    history = result.setdefault("runtime_history", [])
    previous_event_sha256 = str(history[-1].get("event_sha256") or "") if history else None
    history.append(_history_event(target, operator, evidence, previous_event_sha256))
    result["state_sha256"] = _session_state_sha256(result)
    write_json(output_path, result)
    return result


def build_session_manifest(
    template: Mapping[str, Any],
    protocol_lock: Mapping[str, Any],
    hardware_profile: Mapping[str, Any],
    output_path: Path,
    *,
    preflight_report: Mapping[str, Any] | None = None,
    operator: str = "UNRECORDED",
    allow_caution_override: bool = False,
    override_reason: str = "",
    protocol_snapshot_path: Path | None = None,
    hardware_profile_path: Path | None = None,
) -> dict[str, Any]:
    """Compatibility facade: prepare a draft, or lock when evidence is supplied.

    Unlike alpha.1, calling this without preflight evidence never produces a
    runtime lock.  This is the intentional alpha.2 safety correction.
    """
    draft_path = Path(output_path)
    draft = build_session_draft(
        template,
        protocol_lock,
        hardware_profile,
        draft_path,
        protocol_snapshot_path=protocol_snapshot_path,
        hardware_profile_path=hardware_profile_path,
    )
    if preflight_report is None:
        return draft
    return build_session_lock(
        draft,
        preflight_report,
        output_path,
        operator=operator,
        allow_caution_override=allow_caution_override,
        override_reason=override_reason,
    )
