#!/usr/bin/env python3
"""Shared contracts, validators, locks, and export helpers for PRAYCG alpha.1.

The module deliberately uses the Python standard library. Optional integrations
(pylsl, pyxdf, MNE-BIDS, and the external BIDS Validator) are detected by the
calling tools and can never be silently treated as available.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


PLATFORM_VERSION = "1.0.0-alpha.1"
PROTOCOL_SCHEMA = "PRAYCG_ProtocolModule_v1_0"
HARDWARE_SCHEMA = "PRAYCG_HardwareModule_v0_1"
PROFILE_SCHEMA = "PRAYCG_HardwareProfile_v0_1"
SESSION_SCHEMA = "PRAYCG_StudySession_v0_1"
LOCK_SCHEMA = "PRAYCG_LockedSessionManifest_v0_1"
MODULE_REGISTRY_SCHEMA = "PRAYCG_ModuleRegistry_v1_0_alpha_1"
STAGES = (
    "DESIGN", "VALIDATE", "PREFLIGHT", "LOCK", "ARM", "ACQUIRE",
    "FINALIZE", "QC", "ANALYZE", "EXPORT", "VERIFY",
)
CANONICAL_ROLES = {
    "eeg", "eog", "emg", "ecg", "rr_intervals", "heart_rate",
    "respiration", "eda", "ppg", "analog_aux", "als", "markers", "video", "audio",
}
CLAIM_CLASSES = {
    "PRIMARY", "STANDARD_SECONDARY", "EXPLORATORY_SECONDARY",
    "EXPLORATORY_SECONDARY_CONFOUND_EXTENSION", "QC_ONLY", "EXPORT_ONLY",
}
UNSAFE_TEXT_PATTERNS = (
    re.compile(r"(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*['\"]?[^\s,'\"]{8,}"),
    re.compile(r"(?i)-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----"),
)
ABSOLUTE_USER_PATH_RE = re.compile(r"(?i)[A-Z]:\\Users\\[^\\\s]+\\")
EMAIL_RE = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def atomic_write_text(path: Path, text: str) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
        for attempt in range(5):
            try:
                os.replace(temp_name, path)
                break
            except PermissionError:
                if attempt == 4:
                    raise
                time.sleep(0.05 * (attempt + 1))
    finally:
        if os.path.exists(temp_name):
            for attempt in range(5):
                try:
                    os.unlink(temp_name)
                    break
                except PermissionError:
                    if attempt == 4:
                        raise
                    time.sleep(0.05 * (attempt + 1))


def write_json(path: Path, value: Any) -> None:
    atomic_write_text(Path(path), json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def safe_slug(value: str, fallback: str = "item") -> str:
    clean = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "")).strip("._-")
    return clean or fallback


def resolved_within(path: Path, root: Path) -> bool:
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (OSError, ValueError):
        return False


@dataclass
class ValidationReport:
    subject: str
    errors: list[str] = field(default_factory=list)
    cautions: list[str] = field(default_factory=list)
    information: list[str] = field(default_factory=list)

    @property
    def status(self) -> str:
        if self.errors:
            return "INELIGIBLE"
        if self.cautions:
            return "CAUTION"
        return "PASS"

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema": "PRAYCG_ValidationReport_v0_1",
            "platform_version": PLATFORM_VERSION,
            "generated_utc": utc_now(),
            "subject": self.subject,
            "status": self.status,
            "errors": self.errors,
            "cautions": self.cautions,
            "information": self.information,
        }


def _nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def validate_protocol(module: Mapping[str, Any], *, library_root: Path | None = None) -> ValidationReport:
    """Layer 1–3 validation for a fixed-engine protocol module.

    Layer 1 checks structure; layer 2 checks cross-field semantics; layer 3
    checks that the referenced runner remains inside the protocol library.
    """
    report = ValidationReport(subject=str(module.get("display_name") or module.get("protocol_id") or "protocol"))
    required = ("schema", "protocol_id", "protocol_version", "display_name", "runner_entry", "engine_version", "branches", "integrity_constraints", "scientific_boundary")
    for key in required:
        if key not in module:
            report.errors.append(f"Layer 1: required field is missing: {key}")
    if module.get("schema") != PROTOCOL_SCHEMA:
        report.errors.append(f"Layer 1: schema must be {PROTOCOL_SCHEMA}.")
    if str(module.get("engine_version")) != "3.0":
        report.errors.append("Layer 1: this alpha compiler accepts only the fixed Protocol Engine v3.0.")
    if not _nonempty_string(module.get("scientific_boundary")):
        report.errors.append("Layer 1: scientific_boundary must state the inference limits.")
    branches = module.get("branches")
    if not isinstance(branches, list) or not branches:
        report.errors.append("Layer 1: branches must be a non-empty list.")
        branches = []
    phases: set[str] = set()
    media_keys: list[str] = []
    for index, branch in enumerate(branches, start=1):
        if not isinstance(branch, Mapping):
            report.errors.append(f"Layer 1: branch {index} is not an object.")
            continue
        for key in ("phase", "condition_role", "media_key", "instruction", "cue_mode", "washout_phase", "report_phase", "branch_type", "rating_items"):
            if key not in branch:
                report.errors.append(f"Layer 1: branch {index} is missing {key}.")
        phase = str(branch.get("phase", ""))
        if not phase:
            continue
        if phase in phases:
            report.errors.append(f"Layer 2: duplicate phase identifier: {phase}.")
        phases.add(phase)
        media_key = str(branch.get("media_key", ""))
        if media_key:
            media_keys.append(media_key)
        if branch.get("cue_mode") not in {"none", "ignore", "working_memory_sum"}:
            report.errors.append(f"Layer 1: {phase} has unsupported cue_mode {branch.get('cue_mode')!r}.")
        ratings = branch.get("rating_items")
        if not isinstance(ratings, list) or not ratings or not all(_nonempty_string(x) for x in ratings):
            report.errors.append(f"Layer 1: {phase} needs at least one named rating item.")
    constraints = module.get("integrity_constraints", {})
    required_media = constraints.get("required_media_keys", []) if isinstance(constraints, Mapping) else []
    missing_media = sorted(set(media_keys) - set(required_media))
    if missing_media:
        report.errors.append("Layer 2: integrity_constraints.required_media_keys omits: " + ", ".join(missing_media))
    if not module.get("branch_order_fixed", False):
        report.cautions.append("Layer 2: branch order is not fixed; counterbalancing must be explicitly compiled and registered.")
    if not module.get("baseline_phase"):
        report.errors.append("Layer 2: Baseline 1 must be declared.")
    if not module.get("final_reflection_phase"):
        report.errors.append("Layer 2: Baseline 2/final reflection must be declared.")
    if any(branch.get("cue_mode") == "working_memory_sum" for branch in branches) and not constraints.get("cue_schedule_required"):
        report.errors.append("Layer 2: a working-memory cue branch requires a cue schedule.")
    runner_entry = str(module.get("runner_entry", ""))
    if not runner_entry.lower().endswith(".py"):
        report.errors.append("Layer 1: runner_entry must reference a Python file.")
    if ".." in Path(runner_entry).parts or Path(runner_entry).is_absolute():
        report.errors.append("Layer 3: runner_entry must be a relative path without traversal.")
    if library_root and runner_entry:
        target = Path(library_root) / runner_entry
        if not resolved_within(target, Path(library_root)):
            report.errors.append("Layer 3: runner_entry resolves outside the protocol library.")
        elif not target.is_file():
            report.errors.append(f"Layer 3: runner_entry does not exist: {target}")
    report.information.append(f"Branch order: {' -> '.join(str(b.get('phase', '?')) for b in branches)}")
    report.information.append("Baseline 1, per-branch washout/report, Baseline 2/final reflection, and final report remain engine responsibilities.")
    return report


def protocol_timeline(module: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    sequence = 1
    rows.append({"sequence": sequence, "event": module.get("baseline_phase", "BASELINE_1"), "kind": "baseline"})
    for branch in module.get("branches", []):
        for key, kind in (("phase", "stimulus"), ("washout_phase", "washout"), ("report_phase", "report")):
            sequence += 1
            rows.append({"sequence": sequence, "event": branch.get(key, ""), "kind": kind})
    sequence += 1
    rows.append({"sequence": sequence, "event": module.get("final_reflection_phase", "BASELINE_2_REFLECTION"), "kind": "baseline_final_reflection"})
    sequence += 1
    rows.append({"sequence": sequence, "event": "FINAL_REPORT", "kind": "report"})
    return rows


def compile_protocol(module_path: Path, library_root: Path, output_root: Path, *, human_reviewed_by: str = "UNRECORDED") -> tuple[Path, dict[str, Any]]:
    module_path = Path(module_path).resolve()
    library_root = Path(library_root).resolve()
    if not resolved_within(module_path, library_root):
        raise ValueError("Protocol module must be inside the selected library.")
    module = load_json(module_path)
    report = validate_protocol(module, library_root=library_root)
    build_id = f"{safe_slug(module.get('protocol_id', 'protocol'))}_{safe_slug(module.get('protocol_version', '0'))}_{sha256_json(module)[:12]}"
    out = Path(output_root).resolve() / build_id
    out.mkdir(parents=True, exist_ok=True)
    write_json(out / "source_protocol_module.json", module)
    write_json(out / "validation_report.json", report.as_dict())
    with (out / "compiled_timeline.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=("sequence", "event", "kind"))
        writer.writeheader()
        writer.writerows(protocol_timeline(module))
    event_dictionary = {
        "schema": "PRAYCG_EventDictionary_v0_1",
        "marker_contract": "markers are immutable UTF-8 strings with LSL timestamps; a runner event log records event_id, event_name, phase, block_instance_id, local_time, lsl_time, and payload",
        "events": protocol_timeline(module),
    }
    write_json(out / "event_dictionary.json", event_dictionary)
    runner_path = library_root / str(module["runner_entry"])
    lock = {
        "schema": "PRAYCG_CompiledProtocolLock_v0_1",
        "platform_version": PLATFORM_VERSION,
        "compiled_utc": utc_now(),
        "human_reviewed_by": human_reviewed_by,
        "status": "LOCKABLE" if report.status == "PASS" and human_reviewed_by != "UNRECORDED" else "DRAFT_NOT_LOCKABLE",
        "protocol_id": module.get("protocol_id"),
        "protocol_version": module.get("protocol_version"),
        "protocol_module_sha256": sha256_file(module_path),
        "canonical_protocol_sha256": sha256_json(module),
        "runner_entry": module.get("runner_entry"),
        "runner_sha256": sha256_file(runner_path) if runner_path.is_file() else None,
        "validation_status": report.status,
        "scientific_boundary": module.get("scientific_boundary"),
    }
    write_json(out / "compiled_protocol_lock.json", lock)
    return out, lock


def validate_hardware_module(module: Mapping[str, Any]) -> ValidationReport:
    report = ValidationReport(subject=str(module.get("display_name") or module.get("module_id") or "hardware"))
    for key in ("schema", "module_id", "module_version", "display_name", "transport", "streams", "trust_level", "preflight"):
        if key not in module:
            report.errors.append(f"Required hardware field is missing: {key}")
    if module.get("schema") != HARDWARE_SCHEMA:
        report.errors.append(f"schema must be {HARDWARE_SCHEMA}.")
    if module.get("trust_level") not in {"BUILT_IN_TESTED", "BUILT_IN_ALPHA", "COMMUNITY_UNVERIFIED"}:
        report.errors.append("trust_level is not recognized.")
    streams = module.get("streams", [])
    if not isinstance(streams, list) or not streams:
        report.errors.append("At least one stream is required.")
        streams = []
    seen: set[str] = set()
    for stream in streams:
        name = str(stream.get("lsl_name", "")) if isinstance(stream, Mapping) else ""
        role = str(stream.get("canonical_role", "")) if isinstance(stream, Mapping) else ""
        if not name:
            report.errors.append("Each stream requires lsl_name.")
        if name in seen:
            report.errors.append(f"Duplicate LSL stream name: {name}.")
        seen.add(name)
        if role not in CANONICAL_ROLES:
            report.errors.append(f"Unsupported canonical role {role!r} for stream {name or '?'}.")
        for embedded_role in stream.get("embedded_roles", []):
            if embedded_role not in CANONICAL_ROLES:
                report.errors.append(f"Unsupported embedded role {embedded_role!r} for stream {name or '?'}.")
        nominal = stream.get("nominal_srate", 0)
        try:
            nominal = float(nominal)
        except (TypeError, ValueError):
            report.errors.append(f"nominal_srate for {name or '?'} must be numeric.")
            nominal = 0
        if role == "rr_intervals" and nominal != 0:
            report.errors.append("RR intervals are irregular events and must use nominal_srate=0.")
        if role not in {"rr_intervals", "markers"} and nominal <= 0:
            report.cautions.append(f"{name or '?'} has no positive nominal sample rate.")
        if not stream.get("source_id"):
            report.cautions.append(f"{name or '?'} lacks source_id; LSL recovery identity is weaker.")
    preflight = module.get("preflight", {})
    if not isinstance(preflight, Mapping) or float(preflight.get("duration_seconds", 0) or 0) < 10:
        report.errors.append("Hardware preflight duration must be at least 10 seconds.")
    if module.get("managed_recovery", {}).get("enabled_by_default"):
        report.errors.append("Managed recovery must be disabled by default in alpha.1.")
    return report


def build_hardware_profile(module_paths: Sequence[Path], output_path: Path, *, profile_id: str, reviewed_by: str = "UNRECORDED") -> dict[str, Any]:
    modules: list[dict[str, Any]] = []
    errors: list[str] = []
    roles: dict[str, list[str]] = {}
    for path in module_paths:
        module = load_json(Path(path))
        report = validate_hardware_module(module)
        if report.errors:
            errors.extend(f"{Path(path).name}: {item}" for item in report.errors)
        modules.append({
            "module_id": module.get("module_id"),
            "module_version": module.get("module_version"),
            "path": str(Path(path).resolve()),
            "sha256": sha256_file(Path(path)),
            "trust_level": module.get("trust_level"),
            "streams": module.get("streams", []),
        })
        for stream in module.get("streams", []):
            roles.setdefault(str(stream.get("canonical_role")), []).append(str(stream.get("lsl_name")))
            for embedded_role in stream.get("embedded_roles", []):
                roles.setdefault(str(embedded_role), []).append(str(stream.get("lsl_name")))
    collisions = {role: names for role, names in roles.items() if role not in {"markers"} and len(names) > 1}
    if collisions:
        errors.append("Canonical-role collisions require explicit selection: " + json.dumps(collisions, sort_keys=True))
    profile = {
        "schema": PROFILE_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "profile_id": safe_slug(profile_id),
        "created_utc": utc_now(),
        "reviewed_by": reviewed_by,
        "status": "LOCKABLE" if not errors and reviewed_by != "UNRECORDED" else "DRAFT_NOT_LOCKABLE",
        "modules": modules,
        "resolved_roles": roles,
        "errors": errors,
    }
    profile["canonical_sha256"] = sha256_json({k: v for k, v in profile.items() if k != "canonical_sha256"})
    write_json(Path(output_path), profile)
    return profile


def resolve_analysis_capabilities(protocol: Mapping[str, Any], hardware_profile: Mapping[str, Any]) -> dict[str, Any]:
    conditions = set(protocol.get("analysis_contract", {}).get("expected_conditions", []))
    if not conditions:
        conditions = {str(branch.get("analysis_alias") or branch.get("phase")) for branch in protocol.get("branches", [])}
    roles = set(hardware_profile.get("resolved_roles", {}))
    capabilities: dict[str, dict[str, str]] = {}

    def add(name: str, available: bool, reason: str, classification: str) -> None:
        capabilities[name] = {"status": "AVAILABLE" if available else "UNAVAILABLE", "reason": reason, "classification": classification}

    add("Master_Comprehensive_Suite", "eeg" in roles and {"CONTROL_1", "TARGET_1", "CONTEXTUAL_OVERRIDE_1"}.issubset(conditions), "Requires EEG and canonical three-branch aliases.", "PRIMARY_PIPELINE")
    add("HOC_R_ShotOrder", "eeg" in roles and "SHOT_ORDER_SCRAMBLE_1" in conditions, "Requires EEG and ShotOrder condition.", "STANDARD_SECONDARY")
    add("Continuous_Autonomic_RespDualPath", bool({"rr_intervals", "heart_rate", "respiration"} & roles), "Requires cardiac or respiration stream; partial inputs yield partial outputs.", "EXPLORATORY_SECONDARY")
    add("CAI_SID_v0_2", "eeg" in roles, "Requires validated analysis features and independent readiness preflight.", "EXPLORATORY_SECONDARY")
    add("Micro_Handoff_v0_1", "eeg" in roles, "Requires adequate EEG sample rate and artifact-free fast/slow estimates.", "EXPLORATORY_SECONDARY")
    cue_condition = any(branch.get("cue_mode") == "working_memory_sum" for branch in protocol.get("branches", []))
    add("Cue_Locked_Gamma_Forensics_v0_1", "eeg" in roles and cue_condition, "Requires EEG plus runner-recorded cue markers; autonomic and topographic tests remain optional paths.", "EXPLORATORY_SECONDARY_CONFOUND_EXTENSION")
    return {
        "schema": "PRAYCG_AnalysisCapabilityResolution_v0_1",
        "platform_version": PLATFORM_VERSION,
        "generated_utc": utc_now(),
        "conditions": sorted(conditions),
        "roles": sorted(roles),
        "capabilities": capabilities,
    }


def build_session_manifest(template: Mapping[str, Any], protocol_lock: Mapping[str, Any], hardware_profile: Mapping[str, Any], output_path: Path) -> dict[str, Any]:
    report = ValidationReport(subject=str(template.get("study_id") or "study session"))
    if template.get("schema") != SESSION_SCHEMA:
        report.errors.append(f"Session template schema must be {SESSION_SCHEMA}.")
    for key in ("study_id", "session_id", "participant_pseudonym", "protocol_module", "hardware_profile"):
        if not template.get(key):
            report.errors.append(f"Session template is missing {key}.")
    if protocol_lock.get("status") != "LOCKABLE":
        report.errors.append("Protocol compilation is not human-reviewed and lockable.")
    if hardware_profile.get("status") != "LOCKABLE":
        report.errors.append("Hardware profile is not human-reviewed and lockable.")
    if protocol_lock.get("validation_status") != "PASS":
        report.errors.append("Protocol validation did not pass.")
    capability = resolve_analysis_capabilities(load_json(Path(template["protocol_module"])), hardware_profile) if template.get("protocol_module") and Path(str(template["protocol_module"])).is_file() else {"capabilities": {}}
    manifest = {
        "schema": LOCK_SCHEMA,
        "platform_version": PLATFORM_VERSION,
        "created_utc": utc_now(),
        "status": "LOCKED_READY_FOR_PREFLIGHT" if report.status == "PASS" else "NOT_LOCKABLE",
        "gate_status": {stage: ("PASS" if stage in {"DESIGN", "VALIDATE", "LOCK"} and report.status == "PASS" else "PENDING") for stage in STAGES},
        "session": dict(template),
        "protocol_lock": dict(protocol_lock),
        "hardware_profile": dict(hardware_profile),
        "analysis_capability_resolution": capability,
        "validation": report.as_dict(),
    }
    manifest["canonical_sha256"] = sha256_json({k: v for k, v in manifest.items() if k != "canonical_sha256"})
    write_json(Path(output_path), manifest)
    return manifest


def scan_public_package(root: Path, *, allowed_emails: Iterable[str] = ()) -> dict[str, Any]:
    root = Path(root).resolve()
    allowed = {value.lower() for value in allowed_emails}
    findings: list[dict[str, str]] = []
    forbidden_suffixes = {".xdf", ".edf", ".bdf", ".set", ".fif", ".vhdr", ".eeg", ".vmrk", ".mp4", ".mov", ".avi", ".mkv", ".wav"}
    skip_parts = {"__pycache__", ".git"}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or any(part in skip_parts for part in path.parts):
            continue
        rel = path.relative_to(root).as_posix()
        if path.suffix.lower() in forbidden_suffixes:
            findings.append({"severity": "ERROR", "path": rel, "finding": "raw recording or media file is not permitted in the public software package"})
            continue
        if path.stat().st_size > 10 * 1024 * 1024:
            findings.append({"severity": "CAUTION", "path": rel, "finding": "file exceeds 10 MiB; review for unintended data"})
        if path.suffix.lower() not in {".py", ".json", ".md", ".txt", ".csv", ".yml", ".yaml", ".toml", ".bat", ".ps1", ".dockerfile", ""}:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for regex in UNSAFE_TEXT_PATTERNS:
            if regex.search(text):
                findings.append({"severity": "ERROR", "path": rel, "finding": "possible credential or private key"})
                break
        if ABSOLUTE_USER_PATH_RE.search(text):
            findings.append({"severity": "ERROR", "path": rel, "finding": "absolute Windows user path"})
        for email in EMAIL_RE.findall(text):
            if email.lower() not in allowed:
                findings.append({"severity": "CAUTION", "path": rel, "finding": f"unapproved email address: {email}"})
    status = "INELIGIBLE" if any(x["severity"] == "ERROR" for x in findings) else ("CAUTION" if findings else "PASS")
    return {
        "schema": "PRAYCG_PublicPackageScan_v0_1",
        "platform_version": PLATFORM_VERSION,
        "generated_utc": utc_now(),
        "root": ".",
        "status": status,
        "findings": findings,
    }


def inventory_hashes(root: Path, *, exclude_names: Iterable[str] = ()) -> list[dict[str, Any]]:
    root = Path(root).resolve()
    excluded = set(exclude_names)
    rows: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name not in excluded and "__pycache__" not in path.parts:
            rows.append({"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    return rows


def optional_dependency_status() -> dict[str, Any]:
    packages = ("pylsl", "pyxdf", "mne", "mne_bids", "psychopy", "brainflow")
    result: dict[str, Any] = {}
    for name in packages:
        try:
            module = __import__(name)
            result[name] = {"available": True, "version": getattr(module, "__version__", "unknown")}
        except Exception as exc:
            result[name] = {
                "available": False,
                "reason_code": type(exc).__name__,
                "reason": "Import failed during release validation; inspect the local installation directly for details.",
            }
    result["bids_validator"] = {"available": shutil.which("bids-validator") is not None}
    return result
