# Mature Endpoint Atlas Extension v1.0

This extension is integrated into **PRAYCG Control Center v1.0.0-alpha.8.5.4**. The separate alpha.4-targeted installer from the source attachment is not used by this release.

In alpha.8, confirm a runner under **Choose Protocol** and bind any external inputs one-by-one under **Prepare Materials**. Protocols with runner-generated stimuli clearly skip that file step. **Confirm Session Setup** freezes the selected paths and SHA-256 hashes before **Mark Ready to Run**.

It contains **31 runnable protocol entries**:

- 3 preserved native PRAYCG protocols;
- 11 pre-existing Protocol Atlas adaptations; and
- 17 new mature PRAYCG endpoint runners.

Start here:

1. `docs/Mature_Endpoint_Atlas_v1_0/PRAYCG_Mature_Endpoint_Atlas_Overview_v1_0.md`
2. `docs/Mature_Endpoint_Atlas_v1_0/PRAYCG_Protocol_Runner_Matrix_v1_0.md`
3. `docs/Mature_Endpoint_Atlas_v1_0/PRAYCG_Mature_Endpoint_Atlas_Execution_Guide_v1_0.md`
4. `config/mature_endpoint_gate_templates/` and `config/mature_endpoint_analysis_templates/`
5. `tools/Mature_Endpoint_Evaluator_v1_0/README.md`

Inventory and evidence:

- `VERSION_MANIFEST_MATURE_ENDPOINT_ATLAS_v1_0.json`
- `BUILD_VALIDATION_MATURE_ENDPOINT_ATLAS_v1_0.json`
- `SHA256SUMS_v1_0_0_alpha_8.txt` (authoritative whole-package ledger)
- `TEST_EVIDENCE_MATURE_ENDPOINT_ATLAS_v1_0.json`
- `ATLAS_SMOKE_EVIDENCE_MATURE_ENDPOINT_ATLAS_v1_0.json`
- `RUN_MATURE_ENDPOINT_VALIDATION_v1_0.bat`

The extension is software-alpha/feasibility infrastructure. It is not apparatus, human-subject, clinical, construct, or scientific validation.
