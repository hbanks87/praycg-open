# Alpha 8.5.4 Windows PID Recovery Report

## Field failure

The supplied traceback showed Confirm Session Setup, profile preflight, and ALS barcode placement all failing in the same runtime-authority call. On Python 3.11 for Windows, `os.kill(stale_pid, 0)` produced WinError 87 and then surfaced as `SystemError: OSError returned a result with an exception set`.

This happened before Bench Mode readiness was evaluated, so changing readiness qualifiers could not fix it.

## Repair

Windows process existence is now checked with `OpenProcess` and `GetExitCodeProcess`. A nonexistent PID is dead, access denied is treated as existing, and an unexpected probe failure remains active/uncertain. POSIX retains the signal-zero probe and now also contains the exceptional wrapper shape.

The fix is present in both `praycg_platform_core_v1_0_alpha_2.py` and `praycg_platform_core_v1_0_alpha_3.py` so legacy and active runtime paths agree.

## Reported state

The persisted owner referenced Control Center PID 18020, which was no longer running. The authorized runner had a terminal exit record, and the runtime lock had been superseded by a valid ARM-stage lock in the same UUID. With the new probe, read-only owner evaluation completes without an exception and exposes this state to Alpha 8.5.3's narrow recovery contract.

No live process, owner file, lease, or session lock was modified during diagnosis.

## Regression

`control_center/tests/test_windows_pid_probe_alpha854.py` verifies live self-identification, stale-PID classification, exact start identity, and containment of the reported `SystemError` shape in both platform-core layers.
