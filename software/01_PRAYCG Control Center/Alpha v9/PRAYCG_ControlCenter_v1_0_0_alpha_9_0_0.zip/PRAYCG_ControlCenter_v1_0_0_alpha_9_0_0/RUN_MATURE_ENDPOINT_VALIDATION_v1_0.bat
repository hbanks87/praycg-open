@echo off
setlocal
cd /d "%~dp0"
set "PYEXE="
set "PYFLAG="
set "TEST_EVIDENCE=TEST_EVIDENCE_MATURE_ENDPOINT_ATLAS_v1_0.json"
set "SMOKE_EVIDENCE=ATLAS_SMOKE_EVIDENCE_MATURE_ENDPOINT_ATLAS_v1_0.json"

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
  set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
  goto python_ready
)
where py >nul 2>nul
if not errorlevel 1 (
  set "PYEXE=py"
  set "PYFLAG=-3.11"
  goto python_ready
)
where python >nul 2>nul
if errorlevel 1 goto no_python
python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)"
if errorlevel 1 goto no_python
set "PYEXE=python"

:python_ready

echo [1/3] Running bundled regression tests...
"%PYEXE%" %PYFLAG% tools\Release_Validation_v0_1\praycg_mature_endpoint_test_evidence_v1_0.py --package . --output "%TEST_EVIDENCE%"
if errorlevel 1 goto :fail

echo [2/3] Dry-running all Protocol Atlas launchers...
"%PYEXE%" %PYFLAG% tools\Release_Validation_v0_1\praycg_protocol_atlas_release_smoke_v0_1.py --package . > "%SMOKE_EVIDENCE%"
if errorlevel 1 goto :fail

echo [3/3] Combining structure, endpoint, hygiene, test, and smoke evidence...
"%PYEXE%" %PYFLAG% tools\Release_Validation_v0_1\praycg_mature_endpoint_extension_validator_v1_0.py --package . --test-evidence "%TEST_EVIDENCE%" --smoke-evidence "%SMOKE_EVIDENCE%"
if errorlevel 1 goto :fail

echo.
echo Validation completed. Review BUILD_VALIDATION_MATURE_ENDPOINT_ATLAS_v1_0.json.
exit /b 0

:no_python
echo.
echo ERROR: Python 3.11 was not found. Install Python 3.11 and run this validator again.
exit /b 2

:fail
echo.
echo Validation failed. Review the command output and evidence files.
exit /b 1
