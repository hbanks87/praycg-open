# PRAYCG Control Center v1.0.0-alpha.9.0.0

Release date: 2026-09-15

## Release purpose

Alpha 9.0.0 establishes the governed hardware-integration foundation for a broader plug-and-play neuroscience ecosystem. It makes heterogeneous acquisition routes discoverable and testable through a common LSL contract while preserving the existing Control Center as the only authority for session confirmation, ARM, acquisition, and evidence state.

## Added

- Hardware Forge v1.0 with a validated catalog of 11 adapter families and 14 routes.
- Adapter Doctor dependency checks and non-authoritative launch-plan generation.
- Generic Existing-LSL discovery with saved inventory snapshots and non-authoritative contract drafts.
- Canonical `PRAYCG_StreamContract_v1_0` definitions and JSON Schema.
- Exact stream matching across identity, sampling shape, ordered channels, source-ID policy, timing semantics, device metadata, verification state, quality expectations, and privacy class.
- Fail-closed rejection of absent and ambiguous matching outlets.
- Contract-bound long-duration acquisition observation with rate, drift, jitter, gap, timestamp-regression, clock-correction, disappearance, and UID-continuity evidence.
- A bench-verified Polar H10 RR stream contract. It is not human-connected approval.
- Alpha 9 Control Center launchers for Hardware Forge, Existing-LSL discovery, and the contract-bound observer.
- Alpha 9 configuration template, module registry, installer, launcher, requirements file, release manifest, checksums, and build validation.

## Catalog scope

The Alpha 9 catalog covers OpenBCI/BrainFlow EEG and EEG+ALS, Polar H10, Vernier respiration, generic EDA/PPG, Muse/MuseLSL/BlueMuse, Neurosity Crown, Emotiv, GazePoint GP3, Pupil Labs, Zephyr, and a generic existing-LSL route.

Cataloged external projects are not copied into PRAYCG and are not automatically trusted. Their publishers remain separately installed and operated unless a future reviewed PRAYCG adapter explicitly manages them. Alpha 9 validates their LSL-facing contract; it does not assert upstream hardware safety, driver reliability, licensing, signal validity, or source-study equivalence.

## Preserved safeguards

- Hardware Forge, Generic LSL discovery, and the acquisition observer have no session-confirmation, ARM, or acquisition authority.
- Participant sessions still require the existing reviewed hardware profile, current-session stream identities, live readiness evidence, immutable session lock, and one-use acquisition UUID.
- Bench Test Mode remains permanently labeled non-participant and cannot convert missing physical evidence into a PASS.
- No ambiguous LSL stream is selected by name alone.
- Observer reconnect is disabled; source disappearance or UID replacement is surfaced rather than hidden.
- Alpha 8.5.4's Windows process-identity correction and Alpha 8.5.3's terminal-owner recovery remain included.

## Deliberate limitations

- No new route is promoted to human-connected approval by this release.
- Physical hardware, electrical safety, wireless stability, signal fidelity, electrode/contact quality, and timing accuracy require device-specific bench and human-connected review.
- Third-party bridges and proprietary SDKs are not bundled by catalog membership.
- The generic LSL route creates drafts only; an operator must review and promote a contract through a governed process before participant use.
- The existing reviewed-profile workflow remains the participant acquisition gate. Alpha 9 does not yet automatically convert every catalog route into a reviewed hardware profile.
- Public DATA-repository publication, cross-lab package exchange, automated offline interpretation, and visualizer-video bundling remain later roadmap layers. The bundled Results Bundle Builder remains local-only and has no upload authority.
- Scientific, causal, diagnostic, clinical, treatment, consciousness, or reproducibility claims are not established by software validation.

## Validation boundary

The release validator compiles the package, executes the declared automated suites, removes generated caches, scans the public package, checks release identity, and produces a SHA-256 inventory. Passing software checks do not replace physical-device, interactive PsychoPy, display/photodiode, human-feasibility, privacy, licensing, or scientific-validity review.
