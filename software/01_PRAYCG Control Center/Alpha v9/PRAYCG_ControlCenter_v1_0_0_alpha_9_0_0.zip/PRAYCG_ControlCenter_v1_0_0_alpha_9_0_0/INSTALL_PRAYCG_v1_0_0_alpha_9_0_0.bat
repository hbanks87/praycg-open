@echo off
setlocal
cd /d "%~dp0"
set "PRAYCG_REQUIREMENTS=requirements_PRAYCG_v1_0_0_alpha_9_0_0.txt"
set "PRAYCG_ACQUISITION_CHECK=tools\Acquisition\praycg_check_acquisition_install_v1_0.py"
set "PRAYCG_ENV_CAPTURE=tools\Release_Validation_v0_1\praycg_capture_environment_lock_v0_1.py"

echo ============================================================
echo PRAYCG Control Center v1.0.0-alpha.9.0.0 dependency installer
echo ============================================================
echo Native Windows Python 3.11 is required for acquisition.
echo.

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" goto local_python311
where py >nul 2>nul
if not errorlevel 1 goto python_launcher
where python >nul 2>nul
if not errorlevel 1 goto path_python
echo ERROR: Python was not found. Install Python 3.11 and try again.
goto failed

:local_python311
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" -m pip install --upgrade pip "setuptools>=80.9,<82" wheel
if errorlevel 1 goto failed
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" -m pip install -r "%PRAYCG_REQUIREMENTS%"
if errorlevel 1 goto failed
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%PRAYCG_ACQUISITION_CHECK%"
if errorlevel 1 goto failed
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%PRAYCG_ENV_CAPTURE%"
if errorlevel 1 goto failed
goto success

:python_launcher
py -3.11 -m pip install --upgrade pip "setuptools>=80.9,<82" wheel
if errorlevel 1 goto failed
py -3.11 -m pip install -r "%PRAYCG_REQUIREMENTS%"
if errorlevel 1 goto failed
py -3.11 "%PRAYCG_ACQUISITION_CHECK%"
if errorlevel 1 goto failed
py -3.11 "%PRAYCG_ENV_CAPTURE%"
if errorlevel 1 goto failed
goto success

:path_python
python -c "import sys; raise SystemExit(0 if sys.version_info[:2] == (3, 11) else 1)"
if errorlevel 1 (
  echo ERROR: The python command is not Python 3.11. Install Python 3.11 or add it to PATH.
  goto failed
)
python -m pip install --upgrade pip "setuptools>=80.9,<82" wheel
if errorlevel 1 goto failed
python -m pip install -r "%PRAYCG_REQUIREMENTS%"
if errorlevel 1 goto failed
python "%PRAYCG_ACQUISITION_CHECK%"
if errorlevel 1 goto failed
python "%PRAYCG_ENV_CAPTURE%"
if errorlevel 1 goto failed
goto success

:success
echo SUCCESS. Run run_PRAYCG_ControlCenter_v1_0_0_alpha_9_0_0.bat.
echo A privacy-minimized resolved environment record was saved under %%LOCALAPPDATA%%\PRAYCG\environment_locks.
pause
endlocal & exit /b 0
:failed
echo INSTALL FAILED. Keep the visible error message for diagnosis.
pause
endlocal & exit /b 1
