# Analysis-only container

This container is for offline validation, analysis, and export. It is not approved for OpenBCI, Polar, Vernier, ALS, PsychoPy presentation, or LabRecorder acquisition. Those paths require native Windows testing so USB/BLE/display timing and local LSL behavior remain visible to the operator.
