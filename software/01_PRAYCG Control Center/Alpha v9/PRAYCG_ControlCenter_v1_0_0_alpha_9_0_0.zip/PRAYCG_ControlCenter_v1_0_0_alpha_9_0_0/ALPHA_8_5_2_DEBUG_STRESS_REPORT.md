# Alpha 8.5.2 Debug and Stress Report

## Outcome

Alpha 8.5.2 fixes the reproducible Bench Test Mode confirmation/ARM failure. The active logs showed `bench_test_mode: true` and correct `BENCH_TEST` / non-participant labels, but the readiness engine still combined an `INELIGIBLE` full-profile result, failed unbound EEG/ALS detail, and `BENCH_DISPLAY_ONLY` barcode into a hard block. A second independent lock-builder gate also rejected the failed profile report, so changing only the status line would not have repaired the workflow.

Bench mode is now an explicit non-participant readiness bypass across both layers. It produces a hash-bound `CAUTION` artifact, preserves available failed evidence, enables confirmation and ARM without connected equipment, and is rejected if any participant-eligible classification is attempted.

The software release gate covers every declared supported suite and all packaged Python/JSON source files. It does not claim that every physical, interactive, or human branch was executed: the packaging host had no serial port present after the stale bridge was stopped, so a physical ALS barcode PASS could not be completed.

## Bench confirmation/ARM root cause and repair

1. The live active-acquisition state was bound to run `e0156eca-9dd9-4dc7-8cfd-65466f391d9c` with `bench_test_mode: true`, `session_purpose: BENCH_TEST`, and `participant_data_eligible: false`.
2. The full-profile report was `INELIGIBLE`; the detailed report was `FAIL`/`UNBOUND_OR_INVALID` because `obci_eeg1` and ALS were absent; and the barcode report was correctly `BENCH_DISPLAY_ONLY` with `physical_als_evidence: false`.
3. The readiness engine still treated all of those results as hard blockers and additionally required a current full-profile and detailed check in Bench Test Mode.
4. The Confirm button independently required a PASS/CAUTION full-profile report, and the platform lock builder prohibited `INELIGIBLE` preflight evidence. This explains why running both requested checks did not enable confirmation or ARM.
5. Alpha 8.5.2 bypasses live equipment, stream, timing, signal-quality, ALS placement, and demo-only scientific-use qualifiers only when Bench Test Mode is active and the reviewed setup/protocol/material identities are intact.
6. Confirmation writes `bench_readiness_bypass_preflight.json`. Its top-level status is `CAUTION`, its module records say `BYPASSED_FOR_BENCH_TEST`, it records the original full-profile errors when available, and it declares `participant_data_eligible: false`.
7. The lower-level platform lock builder verifies the dedicated artifact and refuses it unless the immutable session also says `bench_test_mode: true`, `session_purpose: BENCH_TEST`, `participant_data_eligible: false`, and `bench_readiness_bypass_active: true`.
8. The active state, lock, ARM evidence, runtime environment, pseudonym, runner state, markers, and outputs retain the permanent non-participant classification. Mode changes and restarts revoke bench authority.

## Retained ALS bridge recovery repair

1. A live Alpha 8.2 EEG+ALS bridge remained on COM3 with run UUID `32d2b59e-978a-4748-b070-d4746b133c8c`, while the active equipment session was `426c9337-c532-47fa-be51-a37ee9bea5c9`.
2. Alpha 8.4.2 correctly discovered the exact process and offered recovery, but used a non-force Windows process-tree stop.
3. Windows refused that stop with: `This process can only be terminated forcefully (with /F option).`
4. Alpha 8.5.2 retains fresh PID, exact two-script allowlist, and full-command-line identity checks, then uses `taskkill /T /F` only after those checks pass.
5. The barcode button now reuses a unique current EEG+ALS bridge; replaces a consented stale or EEG-only packaged bridge on one unambiguous port; or offers to start a missing bridge. Ambiguity, changed identity, declined consent, failed stop, or an absent Windows serial device blocks without spawning a competitor.
6. LSL resolution retries through a lingering old advertisement and waits up to 20 seconds for the current run-bound outlet after restart.

## Bench Test Mode stress coverage

- 100 consecutive ON/OFF transitions: every transition disarmed authority, cleared the participant pseudonym, invalidated the prior lock/evidence boundary, cleared waiver state, and returned to `SELECT`.
- 520 corrupted transport/identity/quality evidence cases: none received a bench waiver.
- 144 combinations of bench flag, participant eligibility, waiver flag, purpose, pseudonym, and reason: only the exact participant and BENCH_TEST label contracts were accepted.
- Restart migration: bench mode, reason, waiver, ARM, and override authority always reset.
- Active `ACQUIRE` runner: mode change was refused without mutating its existing authority.
- The exact reported combination—full profile `INELIGIBLE`, detailed EEG/ALS `FAIL`, and barcode `BENCH_DISPLAY_ONLY`—now yields an audited Bench `CAUTION` and enables the Confirm button.
- The same combination remains `INELIGIBLE` and disabled in participant mode.
- A missing or unapproved hardware definition remains blocking because the immutable setup cannot otherwise identify what is being tested. Protocol/material and hash-integrity checks also remain blocking.
- A generated bypass artifact was built into a real runtime lock and advanced through the ARM gate; the resulting lock passed identity validation.
- A participant-classified draft using the identical bypass artifact was rejected as `NOT_LOCKABLE` by the platform core.
- 250 generated bypass artifacts retained `participant_data_eligible: false`, `bench_readiness_bypass_active: true`, `CAUTION`, and valid canonical hashes.
- With no packaged bridge and no detected serial port, the ALS button runs the visual sequence as `BENCH_DISPLAY_ONLY` without touching hardware. If other serial ports exist, Bench Mode offers an explicit physical/display-only choice. This remains informational and never claims a physical ALS PASS, while the separate bench readiness bypass allows the non-participant software session to continue.

## ALS recovery stress coverage

- Recovery planner order/permutation checks for no bridge, current ALS, stale ALS, current EEG-only, multiple ports, duplicate current bridges, and missing port metadata.
- Current-session ALS reuse without a stop, consent prompt, or duplicate launch.
- Stale bridge same-port stop and replacement.
- Failed identity revalidation/stop fails closed with no replacement.
- Ambiguous ports stop nothing.
- A ghost/non-present COM port blocks before bridge spawn.
- Detected COM port and active UUID are passed unchanged to the bridge.
- Barcode launch is blocked if bridge preparation fails and receives a bounded startup wait when preparation succeeds.
- Recorder resolution was tested against an old LSL advertisement followed by the current-session outlet.
- Timeout input is clamped to a safe 0.1–60 second range.
- Display-only execution was verified without importing LSL; its report contains `physical_als_evidence: false`, no stream identity, and the non-passing `BENCH_DISPLAY_ONLY` status.

## Package-wide audit

- 243 Python source files parsed successfully.
- 3,917 function definitions and 179 class definitions were inventoried by AST.
- 206 JSON files parsed successfully.
- No Python or JSON parse errors were found.
- Three same-scope names exist in the carried `praycg_master_sync_visualizer_v1_2.py`: `launch_gui`, `run_pipeline`, and `build_arg_parser`. They are the deliberate later compatibility implementation in that legacy module; the active Control Center launches v1.4.0, which imports only named v1.2 helper functions. The current visualizer and Master Comprehensive regression suites passed, so this historical shadowing was documented rather than riskily rewriting a hash-governed carried component.
- Final release validation targets Python 3.11 and runs 20 declared suites and 604 tests sequentially, including Control Center, platform gates, runtime authority, Protocol Atlas, all individualized runner dry-runs, stimulus/hardware/analysis catalogs, acquisition bridges, memory stability, Master Comprehensive Suite, and public-package hygiene.

## Live hardware recovery evidence

- The corrected guarded stop revalidated and terminated only PID 24244, the exact Alpha 8.2 EEG+ALS bridge on COM3. Unrelated Python processes were not targeted.
- The replacement bridge was launched for the active session, but BrainFlow returned `UNABLE_TO_OPEN_PORT_ERROR:2` and Windows/pyserial then reported no serial ports present.
- The failed bridge exited and wrote FAIL QC evidence under the active session. No bridge process was left running and no physical barcode result was promoted.
- Required operator action for the next physical run: reconnect or power-cycle the OpenBCI USB dongle, wait for its COM port to appear, open Alpha 8.5.2, and press **ALS Barcode Placement Test**. The new button will start/recover the current-session bridge itself.

## Declared limits

Automated passing tests and static inventory do not establish physical electrode contact, ALS optical placement, calibrated lux, electrical safety, human feasibility, full interactive PsychoPy behavior, third-party media rights, scientific validity, or clinical validity. Participant acquisition remains fail-closed.
