# PRAYCG Master Synchronization Visualizer v1.1

Condition-sliced synchronized playback for PR-AYC-G runs.

This tool creates a review `.mp4` with the selected stimulus video on top and rolling data panels below. Version 1.1 adds a branch selector so you can tell the visualizer whether the selected video is:

- Control
- Target
- Contextual Override
- Full session

When an `.xdf` with PR-AYC-G/Stasis markers is supplied, the script searches for the matching branch markers, such as `CONTROL_1_START/END`, `TARGET_1_START/END`, or `CONTEXTUAL_OVERRIDE_1_START/END`, then cuts the XDF-derived data to that interval. The selected branch video starts at t=0, and the physiological panels are rendered relative to that branch start.

## Why this matters

If you select the Contextual Override MP4, the visualizer should show only the physiological data recorded during the Contextual Override portion of the XDF. This prevents the stimulus video and data stream from being mismatched.

## Install

```bat
cd C:\PRAYCG\PRAYCG_MasterSync_Visualizer_v1_1_ConditionSlicer
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements_master_sync_visualizer_v1_1.txt
```

Python 3.12 is acceptable if 3.11 is unavailable.

## Run GUI

```bat
python scripts\praycg_master_sync_visualizer_v1_1.py --gui
```

Then select:

1. XDF file.
2. Matching branch MP4.
3. Optional feature CSV from the Master Comprehensive Suite.
4. Optional event files such as cue schedule JSON and state-locked anchor summary CSV.
5. Branch/condition: Control, Target, Contextual Override, or Full session.
6. Output MP4.

## CLI examples

### Render Target branch from XDF

```bat
python scripts\praycg_master_sync_visualizer_v1_1.py ^
  --xdf "C:\path\to\run.xdf" ^
  --video "C:\path\to\stimulus_target_cued.mp4" ^
  --condition target ^
  --events "C:\path\to\cue_schedule.json,C:\path\to\state_locked_anchor_summary.csv" ^
  --out "C:\path\to\target_review.mp4"
```

### Render Override branch from XDF

```bat
python scripts\praycg_master_sync_visualizer_v1_1.py ^
  --xdf "C:\path\to\run.xdf" ^
  --video "C:\path\to\stimulus_override_cued.mp4" ^
  --condition override ^
  --events "C:\path\to\cue_schedule.json,C:\path\to\state_locked_anchor_summary.csv" ^
  --out "C:\path\to\override_review.mp4"
```

### Render Control branch from XDF

```bat
python scripts\praycg_master_sync_visualizer_v1_1.py ^
  --xdf "C:\path\to\run.xdf" ^
  --video "C:\path\to\stimulus_control_cued_phase_scrambled.mp4" ^
  --condition control ^
  --events "C:\path\to\cue_schedule.json" ^
  --out "C:\path\to\control_review.mp4"
```

## Outputs

For each rendered video, sidecars are written:

- `<output>_features_used.csv`
- `<output>_events_used.csv`
- `<output>_render_report.json`

The render report records the selected condition, detected video branch, resolved START/END markers, warnings, stream selections, and output paths.

## Boundary

This is a visualization and audit tool. It does not certify PR-AYC-G endpoint validity, meaning, OSM, hidden-Y biology, task compliance, or human EEG mechanism.
