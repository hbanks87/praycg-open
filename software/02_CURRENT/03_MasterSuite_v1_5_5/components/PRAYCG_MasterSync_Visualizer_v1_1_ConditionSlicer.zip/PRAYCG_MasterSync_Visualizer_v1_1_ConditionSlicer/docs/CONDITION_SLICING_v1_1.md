# Condition Slicing in v1.1

Version 1.1 adds a branch/condition selector.

## What it does

If you choose `override`, the visualizer searches the XDF marker streams for a Contextual Override START/END interval. It then extracts only that section of the XDF-derived data and renders it against the selected override MP4.

The same logic applies to Target and Control.

## Marker patterns

The script searches for markers like:

```text
CONTROL_1_START / CONTROL_1_END
TARGET_1_START / TARGET_1_END
CONTEXTUAL_OVERRIDE_1_START / CONTEXTUAL_OVERRIDE_1_END
OVERRIDE_1_START / OVERRIDE_1_END
```

It intentionally ignores instruction, rating, setup, baseline, washout, load, and timeout markers when looking for branch boundaries.

## Correct use

```text
If you select stimulus_target_cued.mp4, choose condition = target.
If you select stimulus_override_cued.mp4, choose condition = override.
If you select stimulus_control_cued_phase_scrambled.mp4, choose condition = control.
```

The render report warns if the selected condition does not match the apparent filename branch.

## Boundary

Condition slicing improves review alignment. It does not prove that the condition was cognitively successful, that task compliance was adequate, or that the physiological endpoint is valid.
