# Usage and boundaries

## What this tool does

It turns PR-AYC-G data into a synchronized playback artifact. The intended viewer can press play and see the stimulus and biological traces move together.

## What this tool does not do

It does not prove PR-AYC-G, OSM, hidden-Y, consciousness, empathy, or biological mechanism. It also does not certify the control audio, task compliance, or artifact rejection.

## Best use

Use this to inspect and present:

- ALS timing pulse relative to video start
- theta/gamma changes during stimulus windows
- HR/HRV/API/respiration motion through the protocol
- state-locked events such as TSP, GammaScalpel, PostPeakPNCC, and G2Theta handoff
- cue schedules and protocol markers

## Event category keywords

The script maps event labels to categories by keyword.

- `tsp`: TSP, TemporalSemanticProxy
- `gamma_scalpel`: GammaScalpel, lower_gamma, MeaningGamma
- `g2theta`: G2Theta, gamma-to-theta, handoff
- `postpeak_pncc`: PostPeak, PNCC
- `annotation`: annotation, reveal, climax, threat, startle, dialogue, face, body
- `als`: ALS, photodiode, light, sensor_timing
- `artifact`: artifact, blink, jaw, EMG, EOG, motion
- `protocol`: baseline, control, target, override, washout, instruction, rating

Unknown events are shown as `other` if selected.
