# Feature CSV and State-Locked Anchor Summary Guide

## Feature CSV

A feature CSV is a time-resolved table of processed physiological or EEG features. It is not created by MediaPrep. MediaPrep creates videos, cue schedules, manifests, and media QC files.

A feature CSV usually comes from the Master Comprehensive Analysis Suite after it analyzes an XDF recording. Useful tables may include names like:

- `human_translation_kht_feature_frame.csv`
- `time_resolved_features.csv`
- `master_feature_frame.csv`
- `<render>_features_used.csv`

The visualizer expects a feature CSV to contain a time column plus some feature columns.

Recommended columns:

```text
time_sec
theta
gamma
hr
rmssd
api_a
resp
als
condition
```

The condition column is optional but helpful. If present, v1.1 can filter the table to `control`, `target`, or `override` before rendering.

## State-locked anchor summary

`state_locked_anchor_summary.csv` is not a raw physiology table. It is an event/summary table produced by the State-Locked Handoff module of the Master Comprehensive Suite. It may contain rows such as:

```text
run
state_anchor
anchor_source
peak_sec
taper_sec
theta_outcome_window
target_delta_theta_plv
target_minus_control
target_minus_override
state_locked_verdict
notes
```

The visualizer treats this as an event overlay source. It can draw anchor/peak/taper moments on top of the rolling data panels. It does not replace the feature CSV.

## Where files are found

### After MediaPrep

MediaPrep output folder contains files like:

```text
stimulus_target_cued_<project>.mp4
stimulus_override_cued_<project>.mp4
stimulus_control_cued_phase_scrambled_<project>.mp4
cue_schedule_<project>.json
cue_schedule_<project>.csv
media_prep_manifest_v1_6R.json
ALS_PT19_SENSOR_TIMING_QC_CHECKLIST_v1_6R.md
CONTROL_AUDIO_QC_CHECKLIST_v1_6R.md
VISUAL_SOURCE_STAMP_QC_CHECKLIST_v1_6R.md
```

It does not create `state_locked_anchor_summary.csv` or the main physiology feature CSV.

### After Master Comprehensive Analysis

The Master Comprehensive Analysis Suite creates an output folder, usually with a `tables/` subfolder. Look there for:

```text
tables/state_locked_anchor_summary.csv
tables/state_locked_epochs_long.csv
tables/state_locked_model_comparison.csv
tables/human_translation_kht_feature_frame.csv
tables/human_translation_kht_phasewise_summary.csv
tables/human_translation_kht_cv_model_losses.csv
```

For v1.1 visualizer use:

```text
Feature CSV: human_translation_kht_feature_frame.csv or another time-resolved feature table
Events: cue_schedule.json + state_locked_anchor_summary.csv
Video: matching control/target/override MP4
Condition selector: control/target/override
```
