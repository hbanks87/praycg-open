@echo off
cd /d %~dp0\..
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python scripts\praycg_master_sync_visualizer_v1_1.py ^
  --xdf "C:\path\to\run.xdf" ^
  --video "C:\path\to\stimulus_control_cued_phase_scrambled.mp4" ^
  --condition control ^
  --events "C:\path\to\cue_schedule.json" ^
  --out "C:\path\to\control_review.mp4"
pause
