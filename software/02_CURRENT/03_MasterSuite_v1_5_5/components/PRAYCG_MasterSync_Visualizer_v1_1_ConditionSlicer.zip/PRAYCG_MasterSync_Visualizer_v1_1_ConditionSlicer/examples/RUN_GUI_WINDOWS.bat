@echo off
cd /d %~dp0\..
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python scripts\praycg_master_sync_visualizer_v1_1.py --gui
pause
