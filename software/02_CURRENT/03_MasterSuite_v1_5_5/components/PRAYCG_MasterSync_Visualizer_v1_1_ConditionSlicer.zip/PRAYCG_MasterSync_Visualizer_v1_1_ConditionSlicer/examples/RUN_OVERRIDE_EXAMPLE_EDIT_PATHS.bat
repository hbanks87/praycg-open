@echo off
cd /d %~dp0\..
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python scripts\praycg_master_sync_visualizer_v1_1.py ^
  --xdf "C:\path\to\run.xdf" ^
  --video "C:\path\to\stimulus_override_cued.mp4" ^
  --condition override ^
  --events "C:\path\to\cue_schedule.json,C:\path\to\state_locked_anchor_summary.csv" ^
  --out "C:\path\to\override_review.mp4"
pause
