@echo off
cd /d %~dp0\..
if exist .venv\Scripts\activate.bat call .venv\Scripts\activate.bat
python scripts\praycg_master_sync_visualizer_v1_1.py --demo --condition target --duration 30 --out demo_master_sync_visualizer_v1_1.mp4 --fps 24 --width 1280 --video-height 0 --graph-height 620
pause
