# Verification notes v1.1

- Syntax checked with `python -m py_compile`.
- Demo render completed successfully using `--demo --condition target`.
- ZIP integrity tested after packaging.
- Condition slicing is marker-dependent. If START/END branch markers are not present in the XDF, the script reports a warning and falls back to the available timeline.
