# Runner, BrainFlow Acquisition, and ALS Improvements retained in v0.92

This document distinguishes what v0.92 includes from controls that remain future work. These runner/acquisition changes originated in v0.90 and are retained unchanged. It is an engineering record, not a claim that a passing check validates a scientific endpoint.

## Implemented in Protocol Runner PRAYCG2.2

1. One run UUID is generated once and shared by the marker-stream metadata, event rows, event filenames, run configuration, and lifecycle manifest.
2. A versioned event schema records event kind, condition, phase, scheduled time, observed flip time, timing delta, source clock, confidence, and the legacy marker/time fields used by existing analysis.
3. Critical visible transitions are flip-logged: baseline onset, instruction/questionnaire display and clear transitions, each ALS barcode segment, first video content frame, and content clear. Cue and locked-anchor rows retain scheduled and observed movie-clock times.
4. Required media, cue schedules, supplied locked-anchor files, supplied ALS placement profiles, Target/Override identity, and output writability are checked before the experimental sequence.
5. Stimuli and supplied sidecars are SHA-256 hashed. Fixed branch order and the complete run configuration are preserved in the run artifacts.
6. The runner writes explicit `PRECHECK`, `READY`, `RUNNING`, `ABORTING`, `COMPLETED`, and `INCOMPLETE` states. Safe abort retains partial data and a machine-readable reason.
7. Participant reports remain in dedicated report artifacts while all artifacts share the run UUID and event-log stem.

Display refresh measurement and PsychoPy dropped-frame counts are recorded when the environment exposes them. These observations reduce ambiguity; they are not a substitute for the external ALS timing channel.

## Implemented in BrainFlow EEG-only v1.1 and EEG+ALS v1.5

1. Reconstructed host/LSL timestamps and device/board timestamps are retained separately in chunk diagnostics.
2. Packet statistics distinguish missing samples, duplicates, out-of-order transitions, maximum inferred gaps, and cumulative totals.
3. EEG, raw AUX, ALS, and status data use distinct typed streams with unique source IDs, explicit channel metadata, nominal rate, board identity, port identity, timestamp mode, and run UUID.
4. The earlier proposed 30–60 second mandatory arming gate was **not** implemented. In v0.92 it remains a separate optional **Run Optional 30-Second Acquisition Validation** button. The fixed 30-second test writes a quick report and never changes runner arm state.
5. LSL buffers are bounded and BrainFlow backlog is recorded. The BrainFlow ring-buffer size is configurable.
6. Signal/device shutdown records a reason, releases the board session, restores Cyton’s default mode after ALS acquisition when requested, and writes a final QC summary even after an exception.
7. Each bridge manifest records software versions, board and port settings, sample rate, channel rows/map, timestamp configuration, source IDs, and optional calibration-profile hash.

Non-finite EEG values are preserved as missing instead of being replaced with zeros. The final QC status separates software/acquisition failure from warnings such as modest rate deviation, packet loss, missingness, or saturation-review crossings.

## ALS barcode placement/location test

The optional 30-second validation now doubles as a per-session barcode placement/location test. It presents repeated runner-like long/short pulses at the lower-right screen location and records:

- screen resolution and estimated physical dimensions;
- Tk-reported pixels per inch;
- exact barcode rectangle and pulse schedule;
- EEG and ALS stream names;
- saved holder/placement profile path and SHA-256 when present;
- robust black/white span, noise estimate, contrast-to-noise ratio, observed transition count, plateau fractions, and a candidate polarity label;
- explicit pulse-visible PASS/FAIL contribution.

The holder should still be physically inspected. A software report cannot prove that the aperture remained seated, that room light did not leak into the holder, or that the same monitor/scaling geometry will persist after the test.

## Remaining future hardening

- Add OS-native monitor EDID/serial identity and per-monitor desktop scaling rather than the current primary-screen identifier and Tk DPI estimate.
- Fit board-to-host clock offset and drift across the full run, with uncertainty intervals.
- Decode every ALS rising/falling edge against the exact versioned barcode specification and export bit-level residuals/confidence.
- Add controlled fault-injection tests for unplugged devices, disk-full conditions, packet duplication/reordering, clock discontinuities, inverted/clipped ALS signals, and aborts in every protocol phase.
- Where hardware permits, compare ALS edges with an independent TTL/photodiode reference.

## Interpretation boundary

The ALS channel measures the physical display input path. It is part of the external stimulus/timing vector, not a biological endpoint. The 0–100 contact-quality index is a transparent engineering heuristic and not true electrode impedance, a medical score, or endpoint certification.
