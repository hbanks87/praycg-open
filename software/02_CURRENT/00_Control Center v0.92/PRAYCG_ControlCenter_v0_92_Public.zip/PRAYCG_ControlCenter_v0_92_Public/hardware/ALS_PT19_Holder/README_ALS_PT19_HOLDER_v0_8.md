# PRAYCG ALS/PT19 Holder Profile v0.8

This folder contains the OpenSCAD source for the 3D-printed ALS/PT19 holder and a matching PRAYCG holder-profile scaffold.

The holder is a physical-timing accessory. It helps the ALS/PT19 sensor view the runner-level barcode overlay while reducing room-light contamination. It does not measure biology.

## Use with Control Center

1. Start BrainFlow EEG + ALS/PT19.
2. Open Control Center v0.92.
3. Go to `Acquisition -> ALS Holder Calibration Mode`.
4. Attach the holder to the intended screen location.
5. Move the white square until the live ALS channel responds strongly and does not clip.
6. Press `S` to save the profile.
7. Use that profile/coordinate for future PRAYCG2.2 runner barcode placement.

## Practical rule

The runner overlay should align to the sensor aperture, not to the center of the flange. Always verify empirically using LSL/ALS readings.
