# PRAYCG Control Center v0.92 Public

PRAYCG Control Center is a Windows dashboard for launching and monitoring the current PRAYCG research workflow. This public package contains the current supported tool set without historical launchers, superseded tool copies, duplicate patch notes, or private research data.

## Start here

1. Extract the complete ZIP to a normal folder. Do not run it from inside the ZIP preview.
2. Install Python 3.11 if it is not already installed.
3. Run `INSTALL_PRAYCG_REQUIREMENTS_v0_92.bat` once.
4. Run `run_PRAYCG_ControlCenter_v0_92.bat`.
5. In Settings, use **Use Bundled Paths**, select any external applications, and save.

LabRecorder and the PsychoPy application are external programs and are not included. The dashboard can locate common installations automatically, or their paths can be set in Settings.

## Current bundled tools

- Control Center v0.92 with Active Research Context v1.0
- Protocol Runner PRAYCG 2.2
- MediaPrep / Stimulus Fingerprint v1.9 ShotOrder
- Master Comprehensive Suite v1.6.1 chain with v1.6.0 canonical core
- MasterSync Visualizer v1.4.0
- Offline Master Interpreter v1.6.0
- Analysis Artifact Index v1.0
- BrainFlow EEG-only and EEG + ALS acquisition bridges
- Polar H10 and Vernier respiration LSL bridges
- ALS barcode, holder calibration, LSL, and signal-quality helpers
- Optional Acquisition Preflight v1.0 with a 30-second EEG/ALS validation and placement test

## Acquisition workflow

Start either BrainFlow bridge, then use **Run Optional 30-Second Acquisition Validation** on the Acquisition page. The test flashes repeated lower-right ALS pulses and writes a short validation report under the configured log root. It checks sample flow, timing, channel flatness/noise/saturation indicators, and ALS pulse visibility. It is intentionally independent of runner arming.

For timing-critical work, save an ALS holder profile with **ALS Holder Calibration Mode** first. The optional validation report records that profile's location and hash together with the tested screen geometry.

## v1.6.1 analysis and review workflow

First run **Launch Master Suite v1.6.0** to create the canonical analysis frame and run-eligibility files. Then use **Run Full v1.6.1 Chained Analysis** on that completed output. The chain preserves the core result, stages its own workspace, and reports missing inputs, non-applicable protocol branches, scientific-gate failures, exploratory completions, and software errors as distinct states.

The v1.4.0 Visualizer can open the completed chain directly. It provides an interactive timeline, event-source inspection, raw or robust-z scaling, a four-branch/HOC-R table, a visible inference-gate ribbon, and optional synchronized MP4 export. The v1.6.0 Interpreter validates the selected folder before writing a structured evidence ledger and technical, research, and public-safe reports.

Both tools consume the v1.0 artifact index. Registered exact filenames, module status, run eligibility, hashes, and duplicate warnings control artifact selection; a stale or partial table cannot override a failed or non-applicable module state.

See `RECOMMENDED_RUNNER_ACQUISITION_ALS_IMPROVEMENTS_v0_92.md` for the changes implemented in Runner 2.2 and the BrainFlow bridges, the per-session barcode placement/location test, and remaining future hardening.

## Active Research Context and automatic input population

The context bar remains visible across the Control Center. It records the selected stimulus, raw run, matching canonical core output, matching chained output, and readiness state for each downstream tool. The current context is saved outside the public package in the user's Control Center settings folder.

Selecting a registered stimulus prefills MediaPrep's master MP4, dedicated MediaPrep output root, and project name. Selecting a run folder resolves its XDF, preferred JSON event log, channel map, recorded cue schedule, locked anchor, and recorded branch videos. Master Suite receives the raw-run and selected-stimulus inputs. Chain, HOC-R, and confound tools receive only a matching canonical core output. Visualizer and Interpreter prefer a compatible completed chain and otherwise use the matching core output.

Resolution is provenance-aware. Multiple plausible XDFs, core outputs, or chains are reported as ambiguous rather than being chosen by modification time. The Analysis page provides explicit XDF/event/channel-map, core-output, and chain-output selection controls. Prefilling never starts processing; the user must still review the launched GUI and click its Run control.

Each new Master Suite output receives an immutable copy of `PRAYCG_ActiveResearchContext_v1_0.json` in its provenance folder. The chain carries that snapshot forward. Recent and pinned stimuli/runs remain available in their catalogs for faster switching.

## Running Tools dashboard

Launched tools appear in **Running Tools**. Every row has its own red **Close** button, so an individual tool can be stopped without finding a shared action panel. Selecting the tool name highlights it. **Open** shows its log, while **More** contains Force close, Open working folder, and Restart. A normal close is attempted first; if the process remains open, the Control Center offers force close.

Stopping a tool can interrupt acquisition or leave an output file incomplete. Confirm that important work has been saved before shutting it down.

## Public-release boundary

This ZIP contains software, configuration templates, hardware-holder documentation, and current component documentation. It intentionally excludes participant data, private biosignals, copyrighted stimulus media, credentials, local machine settings, generated logs, and historical build copies.

See `DISCLAIMER.md` before research use. Component-specific notes remain beside the component they describe.
