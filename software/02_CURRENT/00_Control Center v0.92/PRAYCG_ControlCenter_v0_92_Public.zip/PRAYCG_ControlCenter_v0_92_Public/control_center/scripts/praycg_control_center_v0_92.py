#!/usr/bin/env python3
"""
PRAYCG Control Center v0.92 - Public Build

A public-facing orchestration GUI for PRAYCG tools.
It launches existing tools as separate processes, manages stimulus/run folders,
checks LSL streams, and provides acquisition helper panels.

This is intentionally an orchestrator, not a monolithic replacement for MediaPrep,
PsychoPy, LabRecorder, BrainFlow, or the Master Comprehensive Suite.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import shlex
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from praycg_active_context_v1_0 import (
    CONTEXT_SCHEMA,
    empty_context,
    readiness,
    resolution,
    resolve_analysis_outputs,
    resolve_raw_run,
    summarize_context,
)

APP_NAME = "PRAYCG Control Center"
APP_VERSION = "0.92"
CONFIG_SCHEMA = "PRAYCG_ControlCenter_Config_v0_92"


def slugify(text: str, default: str = "item") -> str:
    text = str(text or "").strip().lower()
    text = re.sub(r"[^a-z0-9._-]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("._-")
    return text or default


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(chunk_size)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def now_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def open_path(path: Path) -> None:
    path = Path(path)
    if not path.exists():
        messagebox.showwarning("Path not found", f"Path does not exist:\n{path}")
        return
    if sys.platform.startswith("win"):
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path)])


def command_prefix_from_setting(value: str) -> List[str]:
    """Return a subprocess-safe command prefix from a GUI setting.

    v0.6 used shlex.split() on the Python executable setting. On Windows,
    shlex with POSIX behavior can corrupt backslash paths such as
    C:/Users/.../python.exe into invalid paths, causing WinError 2.

    This helper preserves real executable paths exactly. It still allows
    short launcher commands such as: py -3.11
    """
    raw = str(value or "").strip()
    if not raw:
        return []
    whole = raw.strip().strip('"')
    try:
        if Path(whole).is_file():
            return [whole]
    except Exception:
        pass
    try:
        parts = shlex.split(raw, posix=False)
        parts = [str(x).strip().strip('"') for x in parts if str(x).strip()]
        return parts
    except Exception:
        return raw.split()


def windows_bat_command(path: Path, args: Optional[List[str]] = None) -> List[str]:
    if sys.platform.startswith("win") and path.suffix.lower() in {".bat", ".cmd"}:
        return ["cmd.exe", "/c", str(path)] + (args or [])
    return [str(path)] + (args or [])


def package_root() -> Path:
    return Path(__file__).resolve().parents[1]


def normalized_path(value: str) -> Path:
    """Normalize a user-entered path without requiring it to exist."""
    raw = os.path.expandvars(str(value or "").strip().strip('"'))
    return Path(raw).expanduser() if raw else Path()


def command_is_available(cmd: List[str]) -> bool:
    """Return whether the first command token resolves to a launchable file."""
    if not cmd:
        return False
    executable = str(cmd[0]).strip().strip('"')
    if not executable:
        return False
    path = Path(executable).expanduser()
    if path.is_file():
        return True
    return shutil.which(executable) is not None


def path_is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (OSError, ValueError):
        return False


def bundled_tool_paths(root: Optional[Path] = None) -> Dict[str, str]:
    """Return paths that must follow the currently extracted package."""
    root = root or package_root()
    bundled = root.parent / "tools"
    return {
        "mediaprep_gui": str(root / "scripts" / "praycg_launch_mediaprep_gui_v0_92.py"),
        "protocol_runner_praycg2": str(bundled / "ProtocolRunner_PRAYCG2_2" / "scripts" / "run_PRAYCG2_2_ProvenanceSafe_ALSBarcode.py"),
        "master_suite_gui": str(root / "scripts" / "praycg_launch_master_suite_gui_v0_92.py"),
        "master_chain_gui": str(root / "scripts" / "praycg_launch_master_chain_gui_v0_92.py"),
        "visualizer_gui": str(bundled / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_master_sync_visualizer_v1_4_0.py"),
        "offline_interpreter_gui": str(bundled / "Offline_Master_Interpreter_v1_6_0" / "scripts" / "praycg_offline_interpretive_report_gui_v1_6_0.py"),
        "confound_expanded_gui": str(bundled / "MasterComprehensiveSuite_v1_6_1_CURRENT" / "scripts" / "praycg_confound_expanded_modules_v1_5_7.py"),
        "brainflow_eeg_only": str(bundled / "Acquisition" / "BrainFlow_EEGOnly_Home_Bridge_v1_1" / "scripts" / "praycg_openbci_brainflow_eeg_to_lsl_v1_1.py"),
        "brainflow_eeg_als": str(bundled / "Acquisition" / "BrainFlow_ALS_PT19_Bridge_v1_5" / "scripts" / "praycg_openbci_brainflow_als_pt19_bridge_v1_5.py"),
        "polar_h10": str(bundled / "Acquisition" / "Polar_H10_to_LSL" / "polar_to_lsl.py"),
        "vernier_resp": str(bundled / "Acquisition" / "Vernier_Respiration_to_LSL" / "vernier_respiration_belt_to_lsl.py"),
        "lsl_stream_checker": str(root / "scripts" / "praycg_lsl_stream_checker_v0_1.py"),
        "signal_quality_index": str(root / "scripts" / "praycg_signal_quality_index_v0_1.py"),
        "acquisition_preflight": str(root / "scripts" / "praycg_acquisition_preflight_v1_0.py"),
        "als_pulse_test": str(root / "scripts" / "praycg_als_barcode_live_test_v0_7.py"),
        "als_barcode_detector": str(root / "scripts" / "praycg_launch_als_barcode_detector_gui_v0_92.py"),
        "mediaprep_barcode_backup": str(root / "scripts" / "praycg_launch_embedded_barcode_backup_v0_92.py"),
        "shot_order_scramble": str(bundled / "MediaPrep_StimulusFingerprint_v1_9_SHOTORDER" / "scripts" / "praycg_shot_order_scramble_control_v1_9.py"),
        "als_holder_calibration": str(root / "scripts" / "praycg_als_holder_calibration_v0_8.py"),
        "hocr_shotorder": str(root / "scripts" / "praycg_launch_hocr_shotorder_gui_v0_92.py"),
    }


def detect_serial_ports() -> List[str]:
    """Find Windows COM ports without requiring pyserial."""
    found: List[str] = []
    try:
        from serial.tools import list_ports  # type: ignore
        found.extend(str(port.device) for port in list_ports.comports() if port.device)
    except Exception:
        pass
    if sys.platform.startswith("win"):
        try:
            import winreg
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM")
            try:
                idx = 0
                while True:
                    try:
                        _name, value, _kind = winreg.EnumValue(key, idx)
                    except OSError:
                        break
                    if value:
                        found.append(str(value))
                    idx += 1
            finally:
                winreg.CloseKey(key)
        except Exception:
            pass
    return sorted(set(found), key=lambda value: (len(value), value.lower()))


def user_config_dir() -> Path:
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or str(Path.home())
        return Path(base) / "PRAYCG_ControlCenter"
    return Path.home() / ".praycg_control_center"


def default_config() -> Dict[str, Any]:
    root = package_root()
    home = Path("C:/PRAYCG") if sys.platform.startswith("win") else Path.home() / "PRAYCG"
    py = sys.executable
    return {
        "schema": CONFIG_SCHEMA,
        "version": APP_VERSION,
        "praycg_home": str(home),
        "python_executable": py,
        "stimulus_root": str(home / "stimuli"),
        "run_root": str(home / "runs"),
        "analysis_root": str(home / "analysis"),
        "log_root": str(home / "logs"),
        "lsl": {
            "expected_streams": ["obci_eeg1", "OpenBCIStatusMarkers", "PolarHRV", "VernierRespirationBelt", "praycg_stasismarkers"],
            "eeg_stream_name": "obci_eeg1",
            "eeg_expected_rate_hz": 125.0,
            "als_channel_index_1based": -1
        },
        "acquisition": {
            "openbci_serial_port": ""
        },
        "tools": {
            **bundled_tool_paths(root),
            "psychopy_app": "",
            "psychopy_coder": "",
            "psychopy_python": "",
            "labrecorder": ""
        },
        "runner_launch_mode": "open_psychopy_coder_then_open_runner_file",
        "stimulus_registry": str(home / "config" / "stimulus_registry.json"),
        "run_registry": str(home / "config" / "run_registry.json")
    }


def merge_defaults(cfg: Dict[str, Any], defaults: Dict[str, Any]) -> Dict[str, Any]:
    out = defaults.copy()
    for k, v in cfg.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            d = out[k].copy(); d.update(v); out[k] = d
        else:
            out[k] = v
    return out


def migrate_saved_config(cfg: Dict[str, Any], defaults: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    """Move bundled paths to this extraction while preserving external app choices."""
    out = merge_defaults(cfg, defaults)
    notes: List[str] = []
    current_root = package_root().parent
    saved_tools = cfg.get("tools", {}) if isinstance(cfg.get("tools"), dict) else {}
    current_bundled = bundled_tool_paths()
    out.setdefault("tools", {})
    for key, current_value in current_bundled.items():
        saved_value = str(saved_tools.get(key, "") or "").strip()
        saved_path = normalized_path(saved_value)
        references_other_bundle = bool(
            saved_value
            and re.search(r"PRAYCG_ControlCenter_v\d", saved_value, flags=re.IGNORECASE)
            and not path_is_within(saved_path, current_root)
        )
        if not saved_value or not saved_path.is_file() or references_other_bundle:
            if saved_value != current_value:
                notes.append(f"Rebased bundled tool path: {key}")
            out["tools"][key] = current_value
    out["schema"] = CONFIG_SCHEMA
    out["version"] = APP_VERSION
    python_cmd = command_prefix_from_setting(str(out.get("python_executable", "")))
    if not command_is_available(python_cmd):
        out["python_executable"] = sys.executable
        notes.append("Replaced unavailable Python executable with the current interpreter")
    if cfg.get("schema") != CONFIG_SCHEMA or str(cfg.get("version", "")) != APP_VERSION:
        notes.append(f"Updated saved settings to {CONFIG_SCHEMA}")
    return out, notes


@dataclass
class RunningProcess:
    label: str
    process: subprocess.Popen
    log_path: Path
    started: float
    cmd: List[str]
    cwd: Optional[Path] = None
    shutdown_requested: bool = False
    completion_handled: bool = False


class ScrollText(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.text = tk.Text(self, wrap="word", height=6)
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.text.yview)
        self.text.configure(yscrollcommand=scroll.set)
        self.text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def write(self, msg: str) -> None:
        self.text.insert("end", msg)
        self.text.see("end")
        self.text.update_idletasks()

    def clear(self) -> None:
        self.text.delete("1.0", "end")


class PRAYCGControlCenter(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("1180x820")
        self.minsize(1000, 700)
        self.pkg = package_root()
        self.config_path = user_config_dir() / "config.json"
        self.config_migration_notes: List[str] = []
        self.cfg = self.load_config()
        self.context_path = user_config_dir() / "active_context_v1_0.json"
        self.active_context = self.load_active_context()
        self.processes: Dict[str, RunningProcess] = {}
        self.last_context_scan = 0.0
        self.active_run_uuid: Optional[str] = None
        self.selected_stimulus_id: Optional[str] = str(self.active_context.get("stimulus", {}).get("id") or "") or None
        saved_run_folder = str(self.active_context.get("run", {}).get("folder") or "")
        self.selected_run_folder: Optional[Path] = Path(saved_run_folder) if saved_run_folder else None
        self.create_dirs()
        self.build_ui()
        for note in self.config_migration_notes:
            self.log(f"Settings migration: {note}\n")
        self.refresh_dashboard()
        self.refresh_active_context_ui()
        self.after(250, self.refresh_all_context)
        self.after(1500, self.periodic_update)

    def load_config(self) -> Dict[str, Any]:
        defaults = default_config()
        if self.config_path.exists():
            try:
                cfg = json.loads(self.config_path.read_text(encoding="utf-8"))
                migrated, notes = migrate_saved_config(cfg, defaults)
                self.config_migration_notes = notes
                if notes:
                    user_config_dir().mkdir(parents=True, exist_ok=True)
                    self.config_path.write_text(json.dumps(migrated, indent=2), encoding="utf-8")
                return migrated
            except Exception:
                traceback.print_exc()
        user_config_dir().mkdir(parents=True, exist_ok=True)
        self.config_path.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
        return defaults

    def save_config(self) -> None:
        user_config_dir().mkdir(parents=True, exist_ok=True)
        self.config_path.write_text(json.dumps(self.cfg, indent=2), encoding="utf-8")
        self.log(f"Saved config: {self.config_path}\n")

    def load_active_context(self) -> Dict[str, Any]:
        try:
            payload = json.loads(self.context_path.read_text(encoding="utf-8"))
            if isinstance(payload, dict) and payload.get("schema") == CONTEXT_SCHEMA:
                return payload
        except Exception:
            pass
        return empty_context()

    def save_active_context(self) -> None:
        self.active_context["schema"] = CONTEXT_SCHEMA
        self.active_context["version"] = "1.0"
        self.active_context["updated_local"] = datetime.now().isoformat(timespec="seconds")
        self.active_context["readiness"] = readiness(self.active_context)
        self.context_path.parent.mkdir(parents=True, exist_ok=True)
        self.context_path.write_text(json.dumps(self.active_context, indent=2), encoding="utf-8")
        self.refresh_active_context_ui()

    def create_dirs(self) -> None:
        for key in ["praycg_home", "stimulus_root", "run_root", "analysis_root", "log_root"]:
            Path(self.cfg[key]).mkdir(parents=True, exist_ok=True)
        Path(self.cfg["stimulus_registry"]).parent.mkdir(parents=True, exist_ok=True)
        if not Path(self.cfg["stimulus_registry"]).exists():
            Path(self.cfg["stimulus_registry"]).write_text(json.dumps({"schema":"PRAYCG_StimulusRegistry_v0_1", "stimuli": []}, indent=2), encoding="utf-8")
        if not Path(self.cfg["run_registry"]).exists():
            Path(self.cfg["run_registry"]).write_text(json.dumps({"schema":"PRAYCG_RunRegistry_v0_2", "runs": []}, indent=2), encoding="utf-8")

    def build_ui(self) -> None:
        top = ttk.Frame(self)
        top.pack(side="top", fill="x", padx=8, pady=6)
        ttk.Label(top, text="PRAYCG Control Center", font=("Segoe UI", 18, "bold")).pack(side="left")
        ttk.Label(top, text="  Orchestrator / launcher / folder manager — not a replacement for PsychoPy or LabRecorder", foreground="#555").pack(side="left")
        ttk.Button(top, text="Open PRAYCG Home", command=lambda: open_path(Path(self.cfg["praycg_home"]))).pack(side="right", padx=4)
        ttk.Button(top, text="Save Settings", command=self.save_settings_from_ui).pack(side="right", padx=4)

        self.build_active_context_bar()

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=8, pady=4)
        self.dashboard_tab = ttk.Frame(self.nb); self.nb.add(self.dashboard_tab, text="Dashboard")
        self.stim_tab = ttk.Frame(self.nb); self.nb.add(self.stim_tab, text="Stimulus Library")
        self.acq_tab = ttk.Frame(self.nb); self.nb.add(self.acq_tab, text="Acquisition")
        self.runner_tab = ttk.Frame(self.nb); self.nb.add(self.runner_tab, text="Runner / PsychoPy")
        self.analysis_tab = ttk.Frame(self.nb); self.nb.add(self.analysis_tab, text="Analysis")
        self.settings_tab = ttk.Frame(self.nb); self.nb.add(self.settings_tab, text="Settings")

        self.build_dashboard_tab()
        self.build_stimulus_tab()
        self.build_acquisition_tab()
        self.build_runner_tab()
        self.build_analysis_tab()
        self.build_settings_tab()

        bottom = ttk.LabelFrame(self, text="Control Center Log")
        bottom.pack(fill="both", expand=False, padx=8, pady=4)
        self.logbox = ScrollText(bottom)
        self.logbox.pack(fill="both", expand=True)
        self.log(f"{APP_NAME} v{APP_VERSION} started. Config: {self.config_path}\n")

    def build_active_context_bar(self) -> None:
        bar = ttk.LabelFrame(self, text="Active Research Context")
        bar.pack(side="top", fill="x", padx=8, pady=(0, 4))
        self.context_stimulus_var = tk.StringVar(value="Stimulus: none")
        self.context_run_var = tk.StringVar(value="Run: none")
        self.context_analysis_var = tk.StringVar(value="Analysis: none")
        self.context_workflow_var = tk.StringVar(value="Media -- Run -- Core -- Chain -- Review")
        ttk.Label(bar, textvariable=self.context_stimulus_var, width=30).pack(side="left", padx=6, pady=4)
        ttk.Label(bar, textvariable=self.context_run_var, width=34).pack(side="left", padx=6, pady=4)
        ttk.Label(bar, textvariable=self.context_analysis_var, width=34).pack(side="left", padx=6, pady=4)
        ttk.Label(bar, textvariable=self.context_workflow_var, foreground="#1f4e79").pack(side="left", fill="x", expand=True, padx=6, pady=4)
        ttk.Button(bar, text="Refresh", command=self.refresh_all_context).pack(side="right", padx=3, pady=3)
        ttk.Button(bar, text="Clear Run", command=self.clear_run_context).pack(side="right", padx=3, pady=3)
        ttk.Button(bar, text="Clear Stimulus", command=self.clear_stimulus_context).pack(side="right", padx=3, pady=3)

    def refresh_active_context_ui(self) -> None:
        if not hasattr(self, "context_stimulus_var"):
            return
        stimulus = self.active_context.get("stimulus", {})
        run = self.active_context.get("run", {})
        analysis = self.active_context.get("analysis", {})
        core = analysis.get("core", {})
        chain = analysis.get("chain", {})
        self.context_stimulus_var.set(f"Stimulus: {stimulus.get('id') or 'none'}")
        self.context_run_var.set(f"Run: {run.get('label') or 'none'}")
        if chain.get("status") == "RESOLVED":
            analysis_label = "chain ready"
        elif core.get("status") == "RESOLVED":
            analysis_label = "core ready"
        elif core.get("status") == "AMBIGUOUS":
            analysis_label = "core ambiguous"
        else:
            analysis_label = "none"
        self.context_analysis_var.set(f"Analysis: {analysis_label}")
        media_ok = stimulus.get("master_mp4", {}).get("status") == "RESOLVED"
        run_ok = run.get("xdf", {}).get("status") == "RESOLVED"
        core_ok = core.get("status") == "RESOLVED"
        chain_ok = chain.get("status") == "RESOLVED"
        review_ok = bool(analysis.get("preferred_review_folder"))
        mark = lambda ok: "READY" if ok else "--"
        self.context_workflow_var.set(
            f"Media {mark(media_ok)}  ->  Run {mark(run_ok)}  ->  Core {mark(core_ok)}  ->  Chain {mark(chain_ok)}  ->  Review {mark(review_ok)}"
        )
        self.update_analysis_button_states()

    def tool_is_ready(self, name: str) -> bool:
        return self.active_context.get("readiness", {}).get(name, {}).get("status") == "READY"

    def require_tool_ready(self, name: str, title: str) -> bool:
        record = self.active_context.get("readiness", {}).get(name, {})
        if record.get("status") == "READY":
            return True
        messagebox.showwarning(title, record.get("message") or "The active research context is not ready for this tool.")
        return False

    def log(self, msg: str) -> None:
        if hasattr(self, "logbox"):
            self.logbox.write(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
        else:
            print(msg, end="")

    def build_dashboard_tab(self) -> None:
        f = self.dashboard_tab
        procs = ttk.LabelFrame(f, text="Running Tools - each row controls only that launched tool")
        procs.pack(side="bottom", fill="x", padx=8, pady=8)
        overview = ttk.Panedwindow(f, orient="horizontal")
        overview.pack(side="top", fill="both", expand=True, padx=8, pady=8)
        left = ttk.Frame(overview); right = ttk.Frame(overview)
        overview.add(left, weight=1); overview.add(right, weight=1)
        ttk.Label(left, text="Workflow", font=("Segoe UI", 14, "bold")).pack(anchor="w")
        buttons = [
            ("1. Add / Validate Master Stimulus", lambda: self.nb.select(self.stim_tab)),
            ("2. Launch MediaPrep Suite", self.launch_mediaprep),
            ("2b. Generate Shot-Order Structural Control", self.launch_shot_order_scramble),
            ("3. Open Acquisition Panel", lambda: self.nb.select(self.acq_tab)),
            ("4. Open LabRecorder", self.launch_labrecorder),
            ("5. Open PsychoPy Runner", lambda: self.nb.select(self.runner_tab)),
            ("6. Run Master Comprehensive Suite", lambda: self.nb.select(self.analysis_tab)),
            ("7. Run Visualizer", self.launch_visualizer),
            ("8. Run Offline Interpreter", self.launch_offline_interpreter),
        ]
        for txt, cmd in buttons:
            ttk.Button(left, text=txt, command=cmd).pack(fill="x", pady=4)

        ttk.Label(right, text="Current Status", font=("Segoe UI", 14, "bold")).pack(anchor="w")
        self.status_text = tk.Text(right, height=20, wrap="word")
        self.status_text.pack(fill="both", expand=True)
        ttk.Button(right, text="Refresh Status", command=self.refresh_dashboard).pack(fill="x", pady=4)

        header = ttk.Frame(procs)
        header.pack(fill="x", padx=4, pady=(4, 0))
        for col, text, weight in [(0, "Tool", 4), (1, "PID", 1), (2, "Status", 1), (3, "Runtime", 1), (4, "Log", 1), (5, "Close", 1), (6, "More", 1)]:
            header.columnconfigure(col, weight=weight)
            ttk.Label(header, text=text, font=("Segoe UI", 9, "bold")).grid(row=0, column=col, sticky="w", padx=3)
        body = ttk.Frame(procs)
        body.pack(fill="both", expand=True, padx=4, pady=3)
        self.proc_canvas = tk.Canvas(body, height=165, highlightthickness=0)
        proc_scroll = ttk.Scrollbar(body, orient="vertical", command=self.proc_canvas.yview)
        self.proc_canvas.configure(yscrollcommand=proc_scroll.set)
        self.proc_canvas.pack(side="left", fill="both", expand=True)
        proc_scroll.pack(side="right", fill="y")
        self.proc_rows_frame = ttk.Frame(self.proc_canvas)
        self.proc_rows_window = self.proc_canvas.create_window((0, 0), window=self.proc_rows_frame, anchor="nw")
        self.proc_rows_frame.bind("<Configure>", lambda _event: self.proc_canvas.configure(scrollregion=self.proc_canvas.bbox("all")))
        self.proc_canvas.bind("<Configure>", lambda event: self.proc_canvas.itemconfigure(self.proc_rows_window, width=event.width))
        self.selected_proc_key_var = tk.StringVar(value="")
        self.selected_tool_var = tk.StringVar(value="No tool selected")
        footer = ttk.Frame(procs); footer.pack(fill="x", padx=4, pady=(0, 4))
        ttk.Label(footer, textvariable=self.selected_tool_var).pack(side="left", fill="x", expand=True)
        ttk.Button(footer, text="Clear Exited", command=self.clear_exited_processes).pack(side="right", padx=3)
        ttk.Button(footer, text="Refresh Tools", command=self.update_process_tree).pack(side="right", padx=3)
        self.update_process_tree()

    def build_stimulus_tab(self) -> None:
        f = self.stim_tab
        top = ttk.Frame(f); top.pack(fill="x", padx=8, pady=8)
        ttk.Button(top, text="Add Master Stimulus (.mp4)", command=self.add_master_stimulus).pack(side="left", padx=4)
        ttk.Button(top, text="Refresh Stimulus Registry", command=self.refresh_stimulus_registry).pack(side="left", padx=4)
        ttk.Button(top, text="Pin / Unpin Selected", command=self.toggle_pin_selected_stimulus).pack(side="left", padx=4)
        ttk.Button(top, text="Open Stimulus Root", command=lambda: open_path(Path(self.cfg["stimulus_root"]))).pack(side="left", padx=4)
        ttk.Button(top, text="Launch MediaPrep", command=self.launch_mediaprep).pack(side="left", padx=4)
        ttk.Button(top, text="Launch MP4 Barcode Backup Tool", command=self.launch_mediaprep_barcode_backup).pack(side="left", padx=4)
        ttk.Button(top, text="Shot-Order Scramble Control", command=self.launch_shot_order_scramble).pack(side="left", padx=4)

        mid = ttk.Panedwindow(f, orient="horizontal"); mid.pack(fill="both", expand=True, padx=8, pady=4)
        lframe = ttk.LabelFrame(mid, text="Stimuli")
        rframe = ttk.LabelFrame(mid, text="Detected Files for Selected Stimulus")
        mid.add(lframe, weight=1); mid.add(rframe, weight=2)
        self.stim_tree = ttk.Treeview(lframe, columns=("pin","id","duration","created","path"), show="headings")
        for col, width in [("pin",45),("id",180),("duration",90),("created",150),("path",360)]:
            self.stim_tree.heading(col, text=col); self.stim_tree.column(col, width=width)
        self.stim_tree.pack(fill="both", expand=True)
        self.stim_tree.bind("<<TreeviewSelect>>", self.on_stim_select)
        self.stim_detail = tk.Text(rframe, wrap="word")
        self.stim_detail.pack(fill="both", expand=True)
        self.refresh_stimulus_registry()

    def build_acquisition_tab(self) -> None:
        f = self.acq_tab
        left = ttk.LabelFrame(f, text="Start / Stop Streams")
        left.pack(side="left", fill="y", padx=8, pady=8)
        ttk.Button(left, text="Start Polar H10 RR -> LSL", command=self.launch_polar).pack(fill="x", pady=3)
        ttk.Button(left, text="Start Vernier Respiration USB -> LSL", command=lambda: self.launch_vernier("usb")).pack(fill="x", pady=3)
        ttk.Button(left, text="Start Vernier Respiration BLE -> LSL", command=lambda: self.launch_vernier("ble")).pack(fill="x", pady=3)
        ttk.Separator(left).pack(fill="x", pady=6)
        ttk.Button(left, text="Start BrainFlow EEG Only", command=self.launch_brainflow_eeg_only).pack(fill="x", pady=3)
        ttk.Button(left, text="Start BrainFlow EEG + ALS", command=self.launch_brainflow_eeg_als).pack(fill="x", pady=3)
        ttk.Separator(left).pack(fill="x", pady=6)
        ttk.Button(left, text="Check Visible LSL Streams", command=self.check_lsl_streams).pack(fill="x", pady=3)
        ttk.Button(left, text="Signal Quality / Contact Index 0-100", command=self.run_signal_quality).pack(fill="x", pady=3)
        ttk.Button(left, text="Run Optional 30-Second Acquisition Validation", command=self.run_acquisition_preflight).pack(fill="x", pady=3)
        ttk.Button(left, text="ALS Screen Pulse Barcode Test", command=self.run_als_test).pack(fill="x", pady=3)
        ttk.Button(left, text="ALS Holder Calibration Mode", command=self.run_als_holder_calibration).pack(fill="x", pady=3)
        ttk.Button(left, text="Open LabRecorder", command=self.launch_labrecorder).pack(fill="x", pady=3)

        right = ttk.LabelFrame(f, text="LSL Stream Monitor")
        right.pack(side="right", fill="both", expand=True, padx=8, pady=8)
        self.lsl_tree = ttk.Treeview(right, columns=("name","type","ch","srate","source"), show="headings", height=14)
        for col, width in [("name",220),("type",120),("ch",60),("srate",100),("source",400)]:
            self.lsl_tree.heading(col, text=col); self.lsl_tree.column(col, width=width)
        self.lsl_tree.pack(fill="both", expand=True)
        ttk.Button(right, text="Refresh LSL Stream List", command=self.populate_lsl_tree).pack(fill="x", pady=4)
        note = tk.Text(right, height=7, wrap="word")
        note.pack(fill="x")
        note.insert("end", "Notes:\n- Polar script streams RR intervals as LSL stream 'PolarHRV'.\n- Vernier script streams raw force as 'VernierRespirationBelt'. USB is recommended first.\n- Signal Quality Index is a contact-quality proxy, not true Cyton impedance.\n- The optional 30-second validation records a short EEG/ALS sample, flashes a barcode, and writes a quick validation report. It does not arm or block the runner.\n- ALS test uses a black/white barcode. v0.92 retains holder calibration and reliable launch/status controls to align the runner overlay to the 3D-printed ALS/PT19 aperture.\n")
        note.config(state="disabled")

    def build_runner_tab(self) -> None:
        f = self.runner_tab
        top = ttk.LabelFrame(f, text="PsychoPy-safe Runner Launch")
        top.pack(fill="x", padx=8, pady=8)
        ttk.Label(top, text="The recommended mode opens the PRAYCG2.2 script directly in PsychoPy Coder through PsychoPy's bundled Python interpreter. This bypasses Windows PsychoPy launcher failures and avoids forcing direct experiment execution.", wraplength=1000).pack(anchor="w", pady=4)
        self.runner_mode_var = tk.StringVar(value=self.cfg.get("runner_launch_mode", "open_psychopy_coder_then_open_runner_file"))
        modes = [
            ("Open PRAYCG2.2 script directly in PsychoPy Coder (recommended)", "open_psychopy_coder_then_open_runner_file"),
            ("Launch runner with PsychoPy application and file argument (experimental)", "psychopy_app_file_arg"),
            ("Launch runner with PsychoPy Python interpreter (experimental)", "psychopy_python"),
            ("Launch runner with regular Python (least recommended for your current setup)", "regular_python"),
        ]
        for text, val in modes:
            ttk.Radiobutton(top, text=text, value=val, variable=self.runner_mode_var).pack(anchor="w")
        ttk.Button(top, text="Launch PRAYCG2.2 Runner Using Selected Mode", command=self.launch_praycg_runner).pack(fill="x", pady=6)
        ttk.Button(top, text="Open Runner Script Location", command=self.open_runner_location).pack(fill="x", pady=2)
        ttk.Button(top, text="Open PsychoPy Coder Only", command=self.launch_psychopy_coder_only).pack(fill="x", pady=2)
        ttk.Button(top, text="Auto-find PsychoPy / LabRecorder / Runner", command=self.autofind_common_tools).pack(fill="x", pady=6)

        media = ttk.LabelFrame(f, text="Auto-detected PRAYCG2.2 Input Files for Selected Stimulus")
        media.pack(fill="both", expand=True, padx=8, pady=8)
        self.runner_detect_text = tk.Text(media, wrap="word")
        self.runner_detect_text.pack(fill="both", expand=True)
        ttk.Button(media, text="Refresh Detected Stimulus Files", command=self.refresh_runner_detect_text).pack(fill="x", pady=4)

    def build_analysis_tab(self) -> None:
        f = self.analysis_tab
        selection = ttk.LabelFrame(f, text="Selected Run and Analysis Outputs")
        selection.pack(fill="x", padx=8, pady=(8, 4))
        self.analysis_run_var = tk.StringVar(value="Run: none")
        self.analysis_core_var = tk.StringVar(value="Core: none")
        self.analysis_chain_var = tk.StringVar(value="Chain: none")
        rows = [
            (self.analysis_run_var, "Select Run Folder", self.select_run_folder),
            (self.analysis_core_var, "Select Core Output", self.select_core_analysis_folder),
            (self.analysis_chain_var, "Select Chain Output", self.select_chain_analysis_folder),
        ]
        for row_index, (variable, text, command) in enumerate(rows):
            ttk.Label(selection, textvariable=variable).grid(row=row_index, column=0, sticky="ew", padx=6, pady=2)
            ttk.Button(selection, text=text, command=command).grid(row=row_index, column=1, sticky="ew", padx=3, pady=2)
        resolve_row = ttk.Frame(selection); resolve_row.grid(row=3, column=0, columnspan=2, sticky="ew", padx=6, pady=2)
        ttk.Label(resolve_row, text="Resolve ambiguous raw inputs:").pack(side="left")
        ttk.Button(resolve_row, text="Choose XDF", command=lambda: self.select_run_artifact("xdf", "Select XDF", (("XDF", "*.xdf"), ("All", "*.*")))).pack(side="left", padx=3)
        ttk.Button(resolve_row, text="Choose Event Log", command=lambda: self.select_run_artifact("events", "Select event JSON/CSV", (("Events", "*.json *.csv"), ("All", "*.*")))).pack(side="left", padx=3)
        ttk.Button(resolve_row, text="Choose Channel Map", command=lambda: self.select_run_artifact("channel_map", "Select channel map", (("CSV", "*.csv"), ("All", "*.*")))).pack(side="left", padx=3)
        catalog = ttk.Frame(selection); catalog.grid(row=4, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        ttk.Label(catalog, text="Recent / pinned runs:").pack(side="left")
        self.run_catalog_var = tk.StringVar()
        self.run_catalog_combo = ttk.Combobox(catalog, textvariable=self.run_catalog_var, state="readonly")
        self.run_catalog_combo.pack(side="left", fill="x", expand=True, padx=4)
        ttk.Button(catalog, text="Use Run", command=self.use_run_catalog_selection).pack(side="left", padx=2)
        ttk.Button(catalog, text="Pin / Unpin", command=self.toggle_pin_catalog_run).pack(side="left", padx=2)
        selection.columnconfigure(0, weight=1)
        actions = ttk.LabelFrame(f, text="Context-Aware Workflow")
        actions.pack(fill="x", padx=8, pady=4)
        self.analysis_buttons: Dict[str, ttk.Button] = {}
        definitions = [
            ("master_suite", "1. Open Master Suite", self.launch_master_suite),
            ("chain", "2. Run Full Chain", self.launch_master_chain),
            ("hocr", "HOC-R", self.launch_hocr_shotorder),
            ("confounds", "Confound Expansion", self.launch_confound_expanded),
            ("als_barcode", "ALS Barcode", self.launch_als_barcode_detector),
            ("visualizer", "Visualizer", self.launch_visualizer),
            ("interpreter", "Interpreter", self.launch_offline_interpreter),
        ]
        for index, (key, text, command) in enumerate(definitions):
            button = ttk.Button(actions, text=text, command=command)
            button.grid(row=index // 4, column=index % 4, sticky="ew", padx=4, pady=4)
            actions.columnconfigure(index % 4, weight=1)
            self.analysis_buttons[key] = button
        utility = ttk.Frame(f); utility.pack(fill="x", padx=8, pady=(0, 4))
        ttk.Button(utility, text="Refresh Resolution", command=self.scan_selected_run_folder).pack(side="left", padx=4)
        ttk.Button(utility, text="Open Source Run", command=lambda: open_path(self.selected_run_folder) if self.selected_run_folder else messagebox.showinfo("No run", "Select a run folder first.")).pack(side="left", padx=4)
        ttk.Button(utility, text="Open Analysis Root", command=lambda: open_path(Path(self.cfg["analysis_root"]))).pack(side="left", padx=4)
        ttk.Button(utility, text="Open Preferred Review Folder", command=self.open_preferred_review_folder).pack(side="left", padx=4)
        ttk.Label(utility, text="Prefills only; no analysis starts until you click Run inside the launched tool.", foreground="#555555").pack(side="right", padx=4)
        preview = ttk.LabelFrame(f, text="Resolved Inputs, Provenance, and Readiness")
        preview.pack(fill="both", expand=True, padx=8, pady=4)
        self.analysis_text = tk.Text(preview, wrap="word")
        self.analysis_text.pack(fill="both", expand=True, padx=8, pady=4)
        self.refresh_run_catalog()
        self.refresh_active_context_ui()

    def build_settings_tab(self) -> None:
        f = self.settings_tab
        canvas = tk.Canvas(f)
        scroll = ttk.Scrollbar(f, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="both", expand=True); scroll.pack(side="right", fill="y")
        self.setting_vars: Dict[str, tk.StringVar] = {}

        def add_path_row(label: str, key_path: Tuple[str, Optional[str]], folder=False):
            row = ttk.Frame(inner); row.pack(fill="x", padx=8, pady=3)
            ttk.Label(row, text=label, width=32).pack(side="left")
            key, subkey = key_path
            val = self.cfg.get(key, {}).get(subkey, "") if subkey else self.cfg.get(key, "")
            var = tk.StringVar(value=str(val))
            name = key if subkey is None else f"{key}.{subkey}"
            self.setting_vars[name] = var
            ttk.Entry(row, textvariable=var).pack(side="left", fill="x", expand=True, padx=4)
            def browse():
                if folder:
                    p = filedialog.askdirectory(title=f"Select {label}")
                else:
                    p = filedialog.askopenfilename(title=f"Select {label}")
                if p: var.set(p)
            ttk.Button(row, text="Browse", command=browse).pack(side="left")

        ttk.Label(inner, text="Core Folders", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=8, pady=6)
        add_path_row("PRAYCG Home", ("praycg_home", None), folder=True)
        add_path_row("Stimulus Root", ("stimulus_root", None), folder=True)
        add_path_row("Run Root", ("run_root", None), folder=True)
        add_path_row("Analysis Root", ("analysis_root", None), folder=True)
        add_path_row("Log Root", ("log_root", None), folder=True)
        ttk.Label(inner, text="Tool Paths", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=8, pady=8)
        auto_frame = ttk.LabelFrame(inner, text="Bundled/current paths + Auto-find external tools v0.92")
        auto_frame.pack(fill="x", padx=8, pady=6)
        ttk.Label(auto_frame, text="Searches common Windows locations, PRAYCG_HOME, Desktop, Downloads, Program Files, and PATH. Review results before launching.", wraplength=900).pack(anchor="w", padx=6, pady=4)
        btnrow = ttk.Frame(auto_frame); btnrow.pack(fill="x", padx=6, pady=4)
        ttk.Button(btnrow, text="Use Bundled Paths", command=self.use_bundled_paths).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Use Current Python", command=self.use_current_python).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Auto-find ALL", command=self.autofind_common_tools).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Find LabRecorder", command=self.autofind_labrecorder).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Find PsychoPy", command=self.autofind_psychopy).pack(side="left", padx=3)
        ttk.Button(btnrow, text="Find PRAYCG2.2 Runner", command=self.autofind_runner).pack(side="left", padx=3)
        tool_labels = [
            ("Python executable", ("python_executable", None)),
            ("MediaPrep GUI", ("tools", "mediaprep_gui")),
            ("PRAYCG2.2 Runner Script", ("tools", "protocol_runner_praycg2")),
            ("PsychoPy App", ("tools", "psychopy_app")),
            ("PsychoPy Coder", ("tools", "psychopy_coder")),
            ("PsychoPy Python", ("tools", "psychopy_python")),
            ("LabRecorder exe", ("tools", "labrecorder")),
            ("Master Suite GUI", ("tools", "master_suite_gui")),
            ("Full v1.6.1 Chain GUI", ("tools", "master_chain_gui")),
            ("Visualizer GUI", ("tools", "visualizer_gui")),
            ("Offline Interpreter GUI", ("tools", "offline_interpreter_gui")),
            ("Confound Expansion Module", ("tools", "confound_expanded_gui")),
            ("ALS Barcode Detector", ("tools", "als_barcode_detector")),
            ("MediaPrep Embedded Barcode Backup", ("tools", "mediaprep_barcode_backup")),
            ("Shot-Order Scramble Generator", ("tools", "shot_order_scramble")),
            ("ALS Holder Calibration", ("tools", "als_holder_calibration")),
            ("HOC-R ShotOrder Module", ("tools", "hocr_shotorder")),
            ("BrainFlow EEG Only", ("tools", "brainflow_eeg_only")),
            ("BrainFlow EEG + ALS", ("tools", "brainflow_eeg_als")),
            ("30-Second Acquisition Validation", ("tools", "acquisition_preflight")),
            ("Polar H10 script", ("tools", "polar_h10")),
            ("Vernier Resp script", ("tools", "vernier_resp")),
        ]
        for label, kp in tool_labels:
            add_path_row(label, kp, folder=False)
        ttk.Button(inner, text="Save Settings", command=self.save_settings_from_ui).pack(fill="x", padx=8, pady=10)
        ttk.Button(inner, text="Open Config JSON", command=lambda: open_path(self.config_path)).pack(fill="x", padx=8, pady=4)

    # Settings and process handling
    def save_settings_from_ui(self) -> None:
        if not hasattr(self, "setting_vars"):
            return self.save_config()
        for name, var in self.setting_vars.items():
            if "." in name:
                key, sub = name.split(".", 1)
                self.cfg.setdefault(key, {})[sub] = var.get().strip()
            else:
                self.cfg[name] = var.get().strip()
        self.cfg["runner_launch_mode"] = self.runner_mode_var.get() if hasattr(self, "runner_mode_var") else self.cfg.get("runner_launch_mode")
        self.create_dirs()
        self.save_config()
        self.refresh_dashboard()
        self.refresh_stimulus_registry()

    def launch_process(self, label: str, cmd: List[str], cwd: Optional[Path] = None) -> None:
        cmd = [str(x) for x in cmd if str(x) != ""]
        if not cmd:
            messagebox.showerror("Cannot launch", "Empty command.")
            return
        if not command_is_available(cmd):
            messagebox.showerror(
                "Cannot launch - executable not found",
                f"Could not find the program needed to launch {label}:\n\n{cmd[0]}\n\n"
                "Review Settings, then use Auto-find or Use Current Python."
            )
            return
        log_dir = Path(self.cfg["log_root"]) / "control_center"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / f"{now_stamp()}_{slugify(label)}.log"
        self.log(f"Launching {label}: {' '.join(cmd)}\n  log: {log_path}\n")
        try:
            f = open(log_path, "w", encoding="utf-8", errors="replace")
            f.write(f"{label}\n{' '.join(cmd)}\nStarted {datetime.now().isoformat()}\n\n")
            f.flush()
            creationflags = 0
            if sys.platform.startswith("win"):
                creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            try:
                p = subprocess.Popen(cmd, cwd=str(cwd) if cwd else None, stdout=f, stderr=subprocess.STDOUT, creationflags=creationflags)
            finally:
                f.close()
            # Make duplicate launches visible instead of overwriting prior rows.
            proc_key = f"{label} [{p.pid}]"
            self.processes[proc_key] = RunningProcess(label=label, process=p, log_path=log_path, started=time.time(), cmd=cmd, cwd=cwd)
            self.update_process_tree()
            self.after(1600, lambda key=proc_key: self.check_quick_exit(key))
        except FileNotFoundError as exc:
            detail = " ".join(cmd)
            messagebox.showerror("Launch failed - file not found", f"Could not launch {label}.\n\nWindows could not find the executable in this command:\n{detail}\n\nMost common fix: Settings -> Use Current Python, then try again.\n\nRaw error:\n{exc}")
            self.log(f"FAILED {label}: {exc}\nCommand: {detail}\n")
        except Exception as exc:
            messagebox.showerror("Launch failed", f"Could not launch {label}:\n{exc}")
            self.log(f"FAILED {label}: {exc}\n")

    def check_quick_exit(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if not rp:
            return
        rc = rp.process.poll()
        if rc is not None:
            self.update_process_tree()
            messagebox.showwarning(
                "Tool exited quickly",
                f"{rp.label} exited shortly after launch with code {rc}.\n\n"
                "If no window appeared, the launch did not complete. Use Open in that tool's "
                f"Dashboard row to inspect its log.\n\nLog:\n{rp.log_path}"
            )

    def get_python_cmd(self) -> List[str]:
        py_setting = self.cfg.get("python_executable") or sys.executable
        cmd = command_prefix_from_setting(str(py_setting))
        if not command_is_available(cmd):
            cmd = [sys.executable]
            self.cfg["python_executable"] = sys.executable
            if hasattr(self, "setting_vars") and "python_executable" in self.setting_vars:
                self.setting_vars["python_executable"].set(sys.executable)
            self.save_config()
            self.log(f"Unavailable Python setting repaired to current interpreter: {sys.executable}\n")
        return cmd

    def use_current_python(self) -> None:
        self.cfg["python_executable"] = sys.executable
        if hasattr(self, "setting_vars") and "python_executable" in self.setting_vars:
            self.setting_vars["python_executable"].set(sys.executable)
        self.save_config()
        self.log(f"Python executable reset to current interpreter: {sys.executable}\n")
        messagebox.showinfo("Python path updated", f"Python executable set to:\n{sys.executable}")

    def launch_python_tool(self, label: str, script_key: str, args: Optional[List[str]]=None) -> None:
        script = normalized_path(self.cfg["tools"].get(script_key, ""))
        if not script.is_file():
            messagebox.showerror("Script not found", f"Set the path for {script_key} in Settings.\n\nCurrent path:\n{script}")
            return
        self.launch_process(label, self.get_python_cmd() + [str(script)] + (args or []), cwd=script.parent)

    def update_process_tree(self) -> None:
        if not hasattr(self, "proc_rows_frame"):
            return
        for child in self.proc_rows_frame.winfo_children():
            child.destroy()
        if not self.processes:
            ttk.Label(self.proc_rows_frame, text="No tools launched from this Control Center session.").pack(anchor="w", padx=6, pady=10)
            self.on_process_select()
            return
        refresh_context = False
        for proc_key, rp in self.processes.items():
            rc = rp.process.poll()
            status = "stopping" if rc is None and rp.shutdown_requested else "running" if rc is None else f"exited {rc}"
            runtime = time.strftime("%H:%M:%S", time.gmtime(time.time() - rp.started))
            row = ttk.Frame(self.proc_rows_frame)
            row.pack(fill="x", pady=1)
            for col, weight in [(0, 4), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1)]:
                row.columnconfigure(col, weight=weight)
            selector = tk.Radiobutton(
                row,
                text=rp.label,
                variable=self.selected_proc_key_var,
                value=proc_key,
                indicatoron=False,
                anchor="w",
                command=self.on_process_select,
                selectcolor="#dbeafe",
                relief="flat",
            )
            selector.grid(row=0, column=0, sticky="ew", padx=2)
            ttk.Label(row, text=str(rp.process.pid)).grid(row=0, column=1, sticky="w", padx=3)
            ttk.Label(row, text=status).grid(row=0, column=2, sticky="w", padx=3)
            ttk.Label(row, text=runtime).grid(row=0, column=3, sticky="w", padx=3)
            ttk.Button(row, text="Open", command=lambda key=proc_key: self.open_process_log(key)).grid(row=0, column=4, sticky="ew", padx=2)
            close_btn = tk.Button(
                row,
                text="Close",
                command=lambda key=proc_key: self.shutdown_process(key),
                bg="#9b1c1c",
                fg="white",
                activebackground="#6f1111",
                activeforeground="white",
                padx=7,
                pady=2,
            )
            if rc is not None:
                close_btn.configure(state="disabled", bg="#999999")
            close_btn.grid(row=0, column=5, sticky="ew", padx=2)
            more = ttk.Menubutton(row, text="More")
            menu = tk.Menu(more, tearoff=False)
            menu.add_command(label="Force close", command=lambda key=proc_key: self.force_kill_process(key))
            menu.add_command(label="Open log", command=lambda key=proc_key: self.open_process_log(key))
            menu.add_command(label="Open working folder", command=lambda key=proc_key: self.open_process_working_folder(key))
            menu.add_separator()
            menu.add_command(label="Restart", command=lambda key=proc_key: self.restart_process(key))
            more.configure(menu=menu)
            more.grid(row=0, column=6, sticky="ew", padx=2)
            if rc is not None and not rp.completion_handled:
                rp.completion_handled = True
                refresh_context = True
        self.on_process_select()
        if refresh_context:
            self.after(100, self.refresh_analysis_context)

    def periodic_update(self) -> None:
        self.update_process_tree()
        if self.selected_run_folder and time.time() - self.last_context_scan >= 12.0:
            self.last_context_scan = time.time()
            self.refresh_analysis_context()
        self.after(1500, self.periodic_update)

    def on_process_select(self, _event=None) -> None:
        if not hasattr(self, "selected_tool_var"):
            return
        proc_key = self.selected_proc_key_var.get() if hasattr(self, "selected_proc_key_var") else ""
        if not proc_key:
            self.selected_tool_var.set("No tool selected")
            return
        rp = self.processes.get(proc_key)
        if not rp:
            self.selected_tool_var.set("Selected entry is unavailable")
            self.selected_proc_key_var.set("")
            return
        state = "running" if rp.process.poll() is None else f"exited {rp.process.poll()}"
        self.selected_tool_var.set(f"Selected: {rp.label} | PID {rp.process.pid} | {state}")

    def selected_process(self, show_warning: bool = True) -> Optional[Tuple[str, RunningProcess]]:
        proc_key = self.selected_proc_key_var.get() if hasattr(self, "selected_proc_key_var") else ""
        if not proc_key:
            if show_warning:
                messagebox.showwarning("No tool selected", "Select a Running Tools row first.")
            return None
        rp = self.processes.get(proc_key)
        if rp is None and show_warning:
            messagebox.showwarning("Tool unavailable", "The selected tool is no longer available in the process list.")
        return (proc_key, rp) if rp is not None else None

    def terminate_process_tree(self, rp: RunningProcess, force: bool = False) -> Tuple[bool, str]:
        """Terminate a launched tool and its child processes when supported."""
        if rp.process.poll() is not None:
            return True, f"already exited with code {rp.process.poll()}"
        try:
            if sys.platform.startswith("win"):
                cmd = ["taskkill", "/PID", str(rp.process.pid), "/T"]
                if force:
                    cmd.append("/F")
                completed = subprocess.run(cmd, capture_output=True, text=True, timeout=12)
                detail = (completed.stdout or completed.stderr or "").strip()
                if completed.returncode == 0:
                    return True, detail or "taskkill accepted the request"
                if force:
                    rp.process.kill()
                else:
                    rp.process.terminate()
                return True, detail or f"taskkill returned {completed.returncode}; used process fallback"
            if force:
                rp.process.kill()
            else:
                rp.process.terminate()
            return True, "process signal sent"
        except Exception as exc:
            return False, str(exc)

    def shutdown_selected_process(self) -> None:
        selected = self.selected_process()
        if selected is None:
            return
        self.shutdown_process(selected[0])

    def shutdown_process(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            messagebox.showwarning("Tool unavailable", "That tool is no longer available in the process list.")
            return
        self.selected_proc_key_var.set(proc_key)
        self.on_process_select()
        if rp.process.poll() is not None:
            messagebox.showinfo("Tool already stopped", f"{rp.label} has already exited with code {rp.process.poll()}.")
            self.update_process_tree()
            return
        if not messagebox.askyesno(
            "Shut down selected tool?",
            f"Shut down this tool and child processes?\n\n{rp.label}\nPID {rp.process.pid}",
        ):
            return
        rp.shutdown_requested = True
        ok, detail = self.terminate_process_tree(rp, force=False)
        self.log(f"Shutdown requested for {rp.label} PID {rp.process.pid}: {detail}\n")
        if not ok:
            messagebox.showerror("Shutdown failed", f"Could not request shutdown for {rp.label}.\n\n{detail}")
            rp.shutdown_requested = False
        self.update_process_tree()
        if ok:
            self.after(1600, lambda key=proc_key: self.check_shutdown_result(key))

    def check_shutdown_result(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            return
        rc = rp.process.poll()
        if rc is None:
            if messagebox.askyesno(
                "Tool is still running",
                f"{rp.label} did not stop after the normal shutdown request.\n\nForce close it and its child processes?",
            ):
                ok, detail = self.terminate_process_tree(rp, force=True)
                self.log(f"Force-close requested for {rp.label} PID {rp.process.pid}: {detail}\n")
                if not ok:
                    messagebox.showerror("Force close failed", detail)
            else:
                rp.shutdown_requested = False
        else:
            self.log(f"Stopped {rp.label} PID {rp.process.pid}; exit code {rc}.\n")
        self.update_process_tree()

    def stop_selected_process(self) -> None:
        """Backward-compatible alias retained for internal callers."""
        self.shutdown_selected_process()

    def force_kill_selected_process(self) -> None:
        selected = self.selected_process()
        if selected is None:
            return
        self.force_kill_process(selected[0])

    def force_kill_process(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            messagebox.showwarning("Tool unavailable", "That tool is no longer available in the process list.")
            return
        self.selected_proc_key_var.set(proc_key)
        self.on_process_select()
        if rp.process.poll() is not None:
            messagebox.showinfo("Tool already stopped", f"{rp.label} has already exited with code {rp.process.poll()}.")
            return
        if not messagebox.askyesno("Force close selected tool?", f"Force close this tool and child processes?\n\n{rp.label}\nPID {rp.process.pid}"):
            return
        rp.shutdown_requested = True
        ok, detail = self.terminate_process_tree(rp, force=True)
        self.log(f"Force-close requested for {rp.label} PID {rp.process.pid}: {detail}\n")
        if not ok:
            messagebox.showerror("Force close failed", detail)
            rp.shutdown_requested = False
        self.update_process_tree()

    def open_selected_process_log(self) -> None:
        selected = self.selected_process()
        if selected is not None:
            self.open_process_log(selected[0])

    def open_process_log(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp:
            open_path(rp.log_path)

    def open_process_working_folder(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp:
            open_path(rp.cwd or rp.log_path.parent)

    def restart_process(self, proc_key: str) -> None:
        rp = self.processes.get(proc_key)
        if rp is None:
            return
        if rp.process.poll() is None:
            messagebox.showinfo("Tool still running", "Close this tool before restarting it.")
            return
        self.launch_process(rp.label, list(rp.cmd), cwd=rp.cwd)

    def clear_exited_processes(self) -> None:
        exited = [key for key, rp in self.processes.items() if rp.process.poll() is not None]
        for key in exited:
            self.processes.pop(key, None)
        if self.selected_proc_key_var.get() in exited:
            self.selected_proc_key_var.set("")
        self.update_process_tree()

    # Dashboard/status
    def refresh_dashboard(self) -> None:
        if not hasattr(self, "status_text"): return
        self.status_text.config(state="normal")
        self.status_text.delete("1.0", "end")
        lines = []
        lines.append(f"Version: {APP_VERSION}")
        lines.append(f"PRAYCG_HOME: {self.cfg['praycg_home']}")
        lines.append(f"Stimulus root: {self.cfg['stimulus_root']}")
        lines.append(f"Run root: {self.cfg['run_root']}")
        lines.append(f"Analysis root: {self.cfg['analysis_root']}")
        lines.append(f"Active context: {self.context_path}")
        lines.append(f"Selected stimulus: {self.active_context.get('stimulus', {}).get('id') or 'none'}")
        lines.append(f"Selected run: {self.active_context.get('run', {}).get('folder') or 'none'}")
        lines.append(f"Preferred review output: {self.active_context.get('analysis', {}).get('preferred_review_folder') or 'none'}")
        lines.append("")
        lines.append("Current recommended workflow:")
        lines.append("1. Add master stimulus and validate MP4.")
        lines.append("2. Launch MediaPrep v1.9 and generate Target / Override / Control / cue schedule / QC.")
        lines.append("3. Frame-lock anchors and load LOCKED JSON in PRAYCG2.2.")
        lines.append("4. Start Polar / Vernier / BrainFlow streams.")
        lines.append("5. Open LabRecorder and verify streams.")
        lines.append("6. Launch PRAYCG2.2 from PsychoPy Coder if direct launch fails.")
        lines.append("7. Select the run folder; review resolved inputs and run the Master Suite.")
        lines.append("8. Use the matching core output for the dependency-aware chain, HOC-R, and confound modules.")
        lines.append("9. Use the preferred compatible output for the Visualizer and Offline Interpreter.")
        lines.append("")
        lines.append("Important boundary: this Control Center launches and organizes tools; it does not certify endpoints.")
        self.status_text.insert("end", "\n".join(lines))
        self.status_text.config(state="disabled")

    # Stimulus library
    def read_registry(self) -> Dict[str, Any]:
        p = Path(self.cfg["stimulus_registry"])
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return {"schema":"PRAYCG_StimulusRegistry_v0_1", "stimuli": []}

    def write_registry(self, reg: Dict[str, Any]) -> None:
        Path(self.cfg["stimulus_registry"]).write_text(json.dumps(reg, indent=2), encoding="utf-8")

    def refresh_stimulus_registry(self) -> None:
        if not hasattr(self, "stim_tree"): return
        self.stim_tree.delete(*self.stim_tree.get_children())
        reg = self.read_registry()
        items = sorted(reg.get("stimuli", []), key=lambda s: str(s.get("last_selected_local") or s.get("created_local") or ""), reverse=True)
        items.sort(key=lambda s: bool(s.get("pinned")), reverse=True)
        for s in items:
            self.stim_tree.insert("", "end", iid=s.get("stimulus_id"), values=("PIN" if s.get("pinned") else "", s.get("stimulus_id"), s.get("duration_sec", ""), s.get("created_local", ""), s.get("folder", "")))
        if self.selected_stimulus_id and self.stim_tree.exists(self.selected_stimulus_id):
            self.stim_tree.selection_set(self.selected_stimulus_id)
            self.stim_tree.focus(self.selected_stimulus_id)
            self.stim_tree.see(self.selected_stimulus_id)

    def add_master_stimulus(self) -> None:
        path_str = filedialog.askopenfilename(title="Select master stimulus MP4", filetypes=[("MP4", "*.mp4"), ("All files", "*.*")])
        if not path_str: return
        src = Path(path_str)
        stim_id = simpledialog.askstring("Stimulus ID", "Enter a short stimulus ID (letters/numbers/underscore):", initialvalue=slugify(src.stem))
        if not stim_id: return
        stim_id = slugify(stim_id)
        stim_dir = Path(self.cfg["stimulus_root"]) / stim_id
        master_dir = stim_dir / "master"
        master_dir.mkdir(parents=True, exist_ok=True)
        dst = master_dir / "stimulus_master.mp4"
        if dst.exists() and not messagebox.askyesno("Overwrite?", f"{dst} already exists. Overwrite?"):
            return
        self.log(f"Copying master stimulus to {dst}\n")
        shutil.copy2(src, dst)
        report = self.validate_mp4(dst)
        report["original_source_path"] = str(src)
        report["stimulus_id"] = stim_id
        report["copied_to"] = str(dst)
        report["created_local"] = datetime.now().isoformat(timespec="seconds")
        report["sha256"] = sha256_file(dst)
        (master_dir / "master_sha256.txt").write_text(report["sha256"] + "\n", encoding="utf-8")
        (master_dir / "master_media_validation_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
        reg = self.read_registry()
        reg["stimuli"] = [s for s in reg.get("stimuli", []) if s.get("stimulus_id") != stim_id]
        reg["stimuli"].append({
            "stimulus_id": stim_id,
            "folder": str(stim_dir),
            "master_mp4": str(dst),
            "duration_sec": report.get("duration_sec"),
            "created_local": report["created_local"],
            "sha256": report["sha256"],
            "validation_status": report.get("status", "UNKNOWN"),
            "pinned": False,
            "last_selected_local": report["created_local"],
        })
        self.write_registry(reg)
        self.refresh_stimulus_registry()
        self.selected_stimulus_id = stim_id
        self.update_stimulus_context(stim_id)
        self.display_stimulus_detail(stim_id)
        messagebox.showinfo("Stimulus added", f"Added {stim_id}\n\nValidation status: {report.get('status')}")

    def validate_mp4(self, path: Path) -> Dict[str, Any]:
        rep: Dict[str, Any] = {"schema":"PRAYCG_MasterStimulus_Validation_v0_1", "file": str(path), "status":"PILOT_UNVALIDATED"}
        rep["size_bytes"] = path.stat().st_size
        rep["extension_ok"] = path.suffix.lower() == ".mp4"
        warnings = []
        # Try ffprobe first
        ffprobe = shutil.which("ffprobe")
        if ffprobe:
            try:
                cmd = [ffprobe, "-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", str(path)]
                out = subprocess.check_output(cmd, text=True, errors="replace")
                info = json.loads(out)
                rep["ffprobe"] = info
                fmt = info.get("format", {})
                rep["duration_sec"] = float(fmt.get("duration")) if fmt.get("duration") else None
                video_streams = [s for s in info.get("streams", []) if s.get("codec_type") == "video"]
                audio_streams = [s for s in info.get("streams", []) if s.get("codec_type") == "audio"]
                rep["has_video"] = bool(video_streams); rep["has_audio"] = bool(audio_streams)
                if video_streams:
                    vs = video_streams[0]
                    rep["width"] = vs.get("width"); rep["height"] = vs.get("height")
                    rep["avg_frame_rate"] = vs.get("avg_frame_rate")
                if not audio_streams: warnings.append("No audio stream detected.")
            except Exception as exc:
                rep["ffprobe_error"] = str(exc)
        else:
            warnings.append("ffprobe not found; validation limited. Install FFmpeg for stronger checks.")
        # Try OpenCV if useful
        try:
            import cv2  # type: ignore
            cap = cv2.VideoCapture(str(path))
            if cap.isOpened():
                fps = cap.get(cv2.CAP_PROP_FPS)
                frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
                w = cap.get(cv2.CAP_PROP_FRAME_WIDTH); h = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
                rep.setdefault("fps", fps); rep.setdefault("frame_count", frames)
                rep.setdefault("width", w); rep.setdefault("height", h)
                if not rep.get("duration_sec") and fps and frames:
                    rep["duration_sec"] = float(frames / fps)
                cap.release()
            else:
                warnings.append("OpenCV could not open MP4.")
        except Exception as exc:
            rep["opencv_error"] = str(exc)
        dur = rep.get("duration_sec")
        if dur is not None:
            if dur < 120: warnings.append("Duration < 2 min; acceptable for tests, weak for standard PRAYCG.")
            if dur > 360: warnings.append("Duration > 6 min; may be long for standard PRAYCG.")
        rep["warnings"] = warnings
        rep["status"] = "PASS_WITH_WARNINGS" if warnings else "PASS_BASIC_VALIDATION"
        return rep

    def on_stim_select(self, event=None) -> None:
        sel = self.stim_tree.selection()
        if not sel: return
        stim_id = sel[0]
        self.selected_stimulus_id = stim_id
        self.record_stimulus_access(stim_id)
        self.update_stimulus_context(stim_id)
        self.display_stimulus_detail(stim_id)

    def record_stimulus_access(self, stim_id: str) -> None:
        reg = self.read_registry()
        changed = False
        for item in reg.get("stimuli", []):
            if item.get("stimulus_id") == stim_id:
                item["last_selected_local"] = datetime.now().isoformat(timespec="seconds")
                item.setdefault("pinned", False)
                changed = True
                break
        if changed:
            self.write_registry(reg)

    def toggle_pin_selected_stimulus(self) -> None:
        if not self.selected_stimulus_id:
            messagebox.showinfo("No stimulus selected", "Select a stimulus first.")
            return
        reg = self.read_registry()
        for item in reg.get("stimuli", []):
            if item.get("stimulus_id") == self.selected_stimulus_id:
                item["pinned"] = not bool(item.get("pinned"))
                self.write_registry(reg)
                self.refresh_stimulus_registry()
                return

    def selected_stimulus_folder(self) -> Optional[Path]:
        if not self.selected_stimulus_id:
            return None
        return Path(self.cfg["stimulus_root"]) / self.selected_stimulus_id

    def display_stimulus_detail(self, stim_id: str) -> None:
        if not hasattr(self, "stim_detail"): return
        folder = Path(self.cfg["stimulus_root"]) / stim_id
        detections = self.detect_stimulus_files(folder)
        self.stim_detail.delete("1.0", "end")
        self.stim_detail.insert("end", json.dumps(detections, indent=2))
        self.refresh_runner_detect_text()

    def detect_stimulus_files(self, folder: Path) -> Dict[str, Any]:
        patterns = {
            "master_mp4": ["master/stimulus_master.mp4", "**/stimulus_master.mp4"],
            "target_video": ["**/stimulus_target_cued*.mp4"],
            "override_video": ["**/stimulus_override_cued*.mp4"],
            "control_video": ["**/stimulus_control*cued*phase*scrambled*.mp4", "**/stimulus_control*.mp4"],
            "cue_schedule_json": ["**/cue_schedule*.json"],
            "cue_schedule_csv": ["**/cue_schedule*.csv"],
            "locked_anchor_json": ["**/*LOCKED*.json"],
            "draft_anchor_json": ["**/*DRAFT*.json", "**/*ESTIMATED*.json"],
            "stimulus_fingerprint_all": ["**/stimulus_exogenous_regressor_frame_all_conditions.csv"],
            "cet_regressors_all": ["**/cet_regressors_all_conditions.csv"],
            "mediaprep_manifest": ["**/*manifest*.json", "**/*MediaPrep*report*.json"],
        }
        out = {"folder": str(folder), "exists": folder.exists(), "files": {}}
        for key, pats in patterns.items():
            matches: List[str] = []
            for pat in pats:
                matches += [str(p) for p in folder.glob(pat) if p.is_file()]
            # de-duplicate, shortest newest-ish: preserve sorted
            matches = sorted(set(matches), key=lambda x: (len(x), x))
            out["files"][key] = matches[:10]
        # convenience recommended files
        rec = {}
        for key in ["master_mp4", "target_video", "override_video", "control_video", "cue_schedule_json", "cue_schedule_csv", "locked_anchor_json", "draft_anchor_json", "stimulus_fingerprint_all", "mediaprep_manifest"]:
            vals = out["files"].get(key, [])
            rec[key] = vals[0] if len(vals) == 1 else None
            rec[f"{key}_status"] = "FOUND" if len(vals) == 1 else "MISSING" if not vals else "AMBIGUOUS"
        out["recommended"] = rec
        status = []
        for key in ["target_video","override_video","control_video","cue_schedule_json"]:
            status.append(f"{key}: {'FOUND' if rec.get(key) else 'MISSING'}")
        status.append(f"anchor: {'LOCKED' if rec.get('locked_anchor_json') else 'DRAFT/ESTIMATED' if rec.get('draft_anchor_json') else 'MISSING'}")
        status.append(f"stimulus_fingerprint: {'FOUND' if rec.get('stimulus_fingerprint_all') else 'MISSING'}")
        out["status_lines"] = status
        return out

    def update_stimulus_context(self, stim_id: str) -> None:
        folder = Path(self.cfg["stimulus_root"]) / stim_id
        detections = self.detect_stimulus_files(folder)
        files = detections.get("files", {})
        registry_entry: Dict[str, Any] = {}
        for item in self.read_registry().get("stimuli", []):
            if item.get("stimulus_id") == stim_id:
                registry_entry = item
                break

        def record(key: str, preferred: str = "") -> Dict[str, Any]:
            candidates = [Path(value) for value in files.get(key, [])]
            preferred_paths = [Path(preferred)] if preferred else []
            return resolution(candidates, source="STIMULUS_LIBRARY_SCAN", preferred_paths=preferred_paths)

        master = record("master_mp4", str(registry_entry.get("master_mp4") or ""))
        fingerprint_file = record("stimulus_fingerprint_all")
        manifest = record("mediaprep_manifest")
        stimulus_context = {
            "id": stim_id,
            "folder": str(folder.resolve()),
            "master_sha256": str(registry_entry.get("sha256") or ""),
            "master_mp4": master,
            "mediaprep_output_root": str((folder / "mediaprep").resolve()),
            "target_video": record("target_video"),
            "override_video": record("override_video"),
            "control_video": record("control_video"),
            "cue_schedule_json": record("cue_schedule_json"),
            "cue_schedule_csv": record("cue_schedule_csv"),
            "locked_anchor_json": record("locked_anchor_json"),
            "draft_anchor_json": record("draft_anchor_json"),
            "stimulus_fingerprint_file": fingerprint_file,
            "stimulus_fingerprint_folder": str(Path(fingerprint_file["path"]).parent) if fingerprint_file.get("path") else "",
            "media_manifest_json": manifest,
        }
        self.active_context["stimulus"] = stimulus_context
        self.save_active_context()

    def clear_stimulus_context(self) -> None:
        self.selected_stimulus_id = None
        self.active_context["stimulus"] = {}
        if hasattr(self, "stim_tree"):
            self.stim_tree.selection_remove(*self.stim_tree.selection())
        self.save_active_context()
        self.refresh_runner_detect_text()

    def clear_run_context(self) -> None:
        self.selected_run_folder = None
        self.active_context["run"] = {}
        self.active_context["analysis"] = {}
        self.save_active_context()
        if hasattr(self, "analysis_text"):
            self.analysis_text.delete("1.0", "end")
            self.analysis_text.insert("end", "No run folder selected.\n")

    def refresh_all_context(self) -> None:
        if self.selected_stimulus_id and self.selected_stimulus_folder() and self.selected_stimulus_folder().is_dir():
            self.update_stimulus_context(self.selected_stimulus_id)
        if self.selected_run_folder and self.selected_run_folder.is_dir():
            self.scan_selected_run_folder()
        else:
            if self.selected_run_folder:
                self.selected_run_folder = None
                self.active_context["run"] = {}
                self.active_context["analysis"] = {}
            self.save_active_context()

    def refresh_runner_detect_text(self) -> None:
        if not hasattr(self, "runner_detect_text"): return
        self.runner_detect_text.delete("1.0", "end")
        folder = self.selected_stimulus_folder()
        if not folder:
            self.runner_detect_text.insert("end", "No stimulus selected. Select one in Stimulus Library.\n")
            return
        det = self.detect_stimulus_files(folder)
        self.runner_detect_text.insert("end", "\n".join(det["status_lines"]) + "\n\n")
        self.runner_detect_text.insert("end", json.dumps(det["recommended"], indent=2))
        self.runner_detect_text.insert("end", "\n\nRecommended: PRAYCG2.2 should load Control, Target, Override, cue schedule JSON, and preferably a frame-verified LOCKED anchor JSON.\n")

    # Launchers
    @staticmethod
    def context_record_path(section: Dict[str, Any], key: str) -> str:
        record = section.get(key, {})
        return str(record.get("path") or "") if isinstance(record, dict) and record.get("status") == "RESOLVED" else ""

    @staticmethod
    def add_arg(args: List[str], flag: str, value: Any) -> None:
        raw = str(value or "").strip()
        if raw:
            args.extend([flag, raw])

    def launch_mediaprep(self) -> None:
        if not self.require_tool_ready("mediaprep", "MediaPrep is not ready"):
            return
        path = self.cfg["tools"].get("mediaprep_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set MediaPrep GUI path in Settings.")
            return
        stimulus = self.active_context.get("stimulus", {})
        args: List[str] = []
        self.add_arg(args, "--master", self.context_record_path(stimulus, "master_mp4"))
        self.add_arg(args, "--out-root", stimulus.get("mediaprep_output_root"))
        self.add_arg(args, "--project-name", stimulus.get("id"))
        self.launch_python_or_exe("MediaPrep Suite", path, args=args)

    def launch_master_suite(self) -> None:
        if not self.require_tool_ready("master_suite", "Master Suite is not ready"):
            return
        path = self.cfg["tools"].get("master_suite_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Master Suite GUI path in Settings.")
            return
        run = self.active_context.get("run", {})
        stimulus = self.active_context.get("stimulus", {})
        args: List[str] = []
        self.add_arg(args, "--project-name", run.get("label"))
        self.add_arg(args, "--xdf", self.context_record_path(run, "xdf"))
        self.add_arg(args, "--event-log", self.context_record_path(run, "events"))
        self.add_arg(args, "--channel-map", self.context_record_path(run, "channel_map"))
        cue_json = self.context_record_path(run, "cue_schedule_json") or self.context_record_path(stimulus, "cue_schedule_json")
        anchor = self.context_record_path(run, "predeclared_anchor_file") or self.context_record_path(stimulus, "locked_anchor_json")
        self.add_arg(args, "--cue-schedule-json", cue_json)
        self.add_arg(args, "--cue-schedule-csv", self.context_record_path(stimulus, "cue_schedule_csv"))
        self.add_arg(args, "--media-manifest-json", self.context_record_path(stimulus, "media_manifest_json"))
        self.add_arg(args, "--predeclared-anchor-file", anchor)
        self.add_arg(args, "--stimulus-fingerprint-folder", stimulus.get("stimulus_fingerprint_folder"))
        self.add_arg(args, "--out-root", self.cfg.get("analysis_root"))
        self.add_arg(args, "--control-context-file", self.context_path)
        self.launch_python_or_exe("Master Comprehensive Suite", path, args=args)

    def launch_master_chain(self) -> None:
        if not self.require_tool_ready("chain", "Full chained analysis is not ready"):
            return
        path = self.cfg["tools"].get("master_chain_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Full v1.6.1 Chain GUI path in Settings.")
            return
        core = self.active_context.get("analysis", {}).get("core", {}).get("path", "")
        run_label = self.active_context.get("run", {}).get("label", "")
        args: List[str] = []
        self.add_arg(args, "--analysis-folder", core)
        self.add_arg(args, "--run-label", run_label)
        self.launch_python_or_exe("Master Comprehensive Chained Analysis v1.6.1", path, args=args)




    def launch_als_barcode_detector(self) -> None:
        if not self.require_tool_ready("als_barcode", "ALS Barcode Detector is not ready"):
            return
        run = self.active_context.get("run", {})
        args: List[str] = []
        self.add_arg(args, "--folder", run.get("folder"))
        self.add_arg(args, "--xdf", self.context_record_path(run, "xdf"))
        events_path = self.context_record_path(run, "events")
        if events_path.lower().endswith(".json"):
            self.add_arg(args, "--events-json", events_path)
        self.launch_python_tool("ALS Barcode Detector GUI v0.92", "als_barcode_detector", args)

    def launch_mediaprep_barcode_backup(self) -> None:
        path = self.cfg["tools"].get("mediaprep_barcode_backup", "")
        if not path or not Path(path).expanduser().exists():
            messagebox.showwarning("Path missing", "Set MediaPrep barcode backup script path in Settings or click Use Bundled Paths.")
            return
        self.launch_python_or_exe("MediaPrep ALS Barcode Backup", path)

    def launch_confound_expanded(self) -> None:
        if not self.require_tool_ready("confounds", "Confound modules are not ready"):
            return
        path = self.cfg["tools"].get("confound_expanded_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Confound Expansion Module path in Settings.")
            return
        analysis = self.active_context.get("analysis", {})
        run = self.active_context.get("run", {})
        stimulus = self.active_context.get("stimulus", {})
        args = ["--gui"]
        self.add_arg(args, "--analysis-folder", analysis.get("core", {}).get("path", ""))
        self.add_arg(args, "--run-log-folder", run.get("folder"))
        self.add_arg(args, "--stimulus-fingerprint-folder", stimulus.get("stimulus_fingerprint_folder"))
        self.launch_python_or_exe("Confound Expansion Modules", path, args=args)

    def launch_shot_order_scramble(self) -> None:
        path = self.cfg["tools"].get("shot_order_scramble", "")
        if not path or not Path(path).expanduser().exists():
            messagebox.showwarning("Path missing", "Set Shot-Order Scramble script path in Settings or click Use Bundled Paths.")
            return
        self.launch_python_or_exe("Shot-Order Scramble Generator v1.9", path)

    def run_als_holder_calibration(self) -> None:
        args = ["--stream-name", self.cfg.get("lsl", {}).get("eeg_stream_name", "obci_eeg1"),
                "--channel-index", str(self.cfg.get("lsl", {}).get("als_channel_index_1based", -1)),
                "--out", str(Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json")]
        self.launch_python_tool("ALS Holder Calibration v0.8", "als_holder_calibration", args)

    def launch_hocr_shotorder(self) -> None:
        if not self.require_tool_ready("hocr", "HOC-R is not ready"):
            return
        core = self.active_context.get("analysis", {}).get("core", {}).get("path", "")
        self.launch_python_tool("HOC-R ShotOrder GUI v0.92", "hocr_shotorder", ["--analysis-folder", core])

    def launch_visualizer(self) -> None:
        if not self.require_tool_ready("visualizer", "Visualizer is not ready"):
            return
        path = self.cfg["tools"].get("visualizer_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Visualizer GUI/script path in Settings.")
            return
        analysis = self.active_context.get("analysis", {})
        run = self.active_context.get("run", {})
        stimulus = self.active_context.get("stimulus", {})
        args = ["--gui"]
        self.add_arg(args, "--analysis-out", analysis.get("preferred_review_folder"))
        self.add_arg(args, "--xdf", self.context_record_path(run, "xdf"))
        self.add_arg(args, "--events", self.context_record_path(run, "events"))
        video = self.context_record_path(run, "target_video") or self.context_record_path(stimulus, "target_video")
        self.add_arg(args, "--video", video)
        export_name = f"{slugify(run.get('label') or 'PRAYCG_Run')}_MasterSync_v1_4_0.mp4"
        self.add_arg(args, "--out", Path(self.cfg["analysis_root"]) / "visualizer_exports" / export_name)
        self.launch_python_or_exe("Master Sync Visualizer", path, args=args)

    def launch_offline_interpreter(self) -> None:
        if not self.require_tool_ready("interpreter", "Interpreter is not ready"):
            return
        path = self.cfg["tools"].get("offline_interpreter_gui", "")
        if not path:
            messagebox.showwarning("Path missing", "Set Offline Interpreter GUI path in Settings.")
            return
        analysis = self.active_context.get("analysis", {})
        args: List[str] = []
        self.add_arg(args, "--analysis-folder", analysis.get("preferred_review_folder"))
        self.add_arg(args, "--run-label", self.active_context.get("run", {}).get("label"))
        self.launch_python_or_exe("Offline Interpreter", path, args=args)

    def launch_python_or_exe(self, label: str, path: str, args: Optional[List[str]]=None) -> None:
        p = normalized_path(path)
        if not p.is_file():
            messagebox.showerror("Path not found", f"Path not found for {label}:\n{p}")
            return
        if p.suffix.lower() in {".py", ".pyw"}:
            self.launch_process(label, self.get_python_cmd() + [str(p)] + (args or []), cwd=p.parent)
        else:
            self.launch_process(label, windows_bat_command(p, args), cwd=p.parent)

    def launch_polar(self) -> None:
        self.launch_python_tool("Polar H10 RR -> LSL", "polar_h10")

    def launch_vernier(self, connection: str) -> None:
        self.launch_python_tool(f"Vernier Respiration {connection.upper()} -> LSL", "vernier_resp", ["--connection", connection])

    def launch_brainflow_eeg_only(self) -> None:
        path = self.cfg["tools"].get("brainflow_eeg_only", "")
        if not path:
            messagebox.showwarning("Path missing", "Set BrainFlow EEG-only script path in Settings.")
            return
        port = self.prompt_openbci_serial_port("BrainFlow EEG Only")
        if not port:
            return
        run_uuid = self.begin_acquisition_session()
        self.launch_python_or_exe("BrainFlow EEG Only", path, ["--serial-port", port, "--run-uuid", run_uuid, "--log-dir", str(Path(self.cfg["log_root"]) / "brainflow_eeg_only")])

    def launch_brainflow_eeg_als(self) -> None:
        path = self.cfg["tools"].get("brainflow_eeg_als", "")
        if not path:
            messagebox.showwarning("Path missing", "Set BrainFlow EEG+ALS script path in Settings.")
            return
        port = self.prompt_openbci_serial_port("BrainFlow EEG + ALS")
        if not port:
            return
        run_uuid = self.begin_acquisition_session()
        self.launch_python_or_exe(
            "BrainFlow EEG + ALS",
            path,
            ["--serial-port", port, "--enable-analog-aux", "--publish-als-stream", "--run-uuid", run_uuid, "--log-dir", str(Path(self.cfg["log_root"]) / "brainflow_eeg_als"), "--calibration-profile", str(Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json")],
        )

    def begin_acquisition_session(self) -> str:
        """Create the UUID inherited by a subsequently launched PsychoPy runner."""
        self.active_run_uuid = str(uuid.uuid4())
        os.environ["PRAYCG_RUN_UUID"] = self.active_run_uuid
        self.log(f"New acquisition/run UUID: {self.active_run_uuid}\n")
        return self.active_run_uuid

    def prompt_openbci_serial_port(self, label: str) -> Optional[str]:
        ports = detect_serial_ports()
        saved = str(self.cfg.get("acquisition", {}).get("openbci_serial_port", "") or "").strip()
        initial = saved or (ports[0] if len(ports) == 1 else "")
        detected = ", ".join(ports) if ports else "none detected automatically"
        port = simpledialog.askstring(
            f"{label} - serial port",
            "Enter the OpenBCI serial port (for example COM3).\n\n"
            f"Detected ports: {detected}\n\n"
            "Close the OpenBCI GUI first; only one program can use the port.",
            initialvalue=initial,
            parent=self,
        )
        if port is None:
            self.log(f"{label} launch canceled before serial-port selection.\n")
            return None
        port = port.strip().upper()
        if not re.fullmatch(r"COM\d+", port, flags=re.IGNORECASE):
            messagebox.showerror("Invalid serial port", f"Enter a Windows COM port such as COM3.\n\nReceived: {port or '<blank>'}")
            return None
        self.cfg.setdefault("acquisition", {})["openbci_serial_port"] = port
        self.save_config()
        return port

    def launch_labrecorder(self) -> None:
        path = self.cfg["tools"].get("labrecorder", "")
        if not path:
            messagebox.showwarning("Path missing", "Set LabRecorder executable path in Settings.")
            return
        self.launch_python_or_exe("LabRecorder", path)

    def check_lsl_streams(self) -> None:
        args = ["--duration", "5", "--out-dir", str(Path(self.cfg["log_root"]) / "lsl_stream_checks")]
        expected = self.cfg.get("lsl", {}).get("expected_streams", [])
        if expected:
            args += ["--required"] + expected
        self.launch_python_tool("LSL Stream Checker", "lsl_stream_checker", args)
        self.after(1000, self.populate_lsl_tree)

    def run_signal_quality(self) -> None:
        lsl = self.cfg.get("lsl", {})
        args = [
            "--stream-name", lsl.get("eeg_stream_name", "obci_eeg1"),
            "--duration", "20",
            "--expected-rate", str(lsl.get("eeg_expected_rate_hz", 125.0)),
            "--out-dir", str(Path(self.cfg["log_root"]) / "signal_quality")
        ]
        self.launch_python_tool("Signal Quality / Contact Index", "signal_quality_index", args)

    def run_acquisition_preflight(self) -> None:
        """Launch the optional preflight as a separate report tool, never as a runner gate."""
        lsl = self.cfg.get("lsl", {})
        args = [
            "--gui",
            "--eeg-stream", str(lsl.get("eeg_stream_name", "obci_eeg1")),
            "--als-stream", "ALS_PT19_Timing",
            "--expected-rate", str(lsl.get("eeg_expected_rate_hz", 125.0)),
            "--out-dir", str(Path(self.cfg["log_root"]) / "acquisition_preflight"),
            "--placement-profile", str(Path(self.cfg["praycg_home"]) / "config" / "als_holder_profile_v0_8.json"),
            "--require-als",
        ]
        self.launch_python_tool("Optional 30-Second Acquisition Validation", "acquisition_preflight", args)

    def run_als_test(self) -> None:
        lsl = self.cfg.get("lsl", {})
        args = [
            "--stream-name", lsl.get("eeg_stream_name", "obci_eeg1"),
            "--channel-index", str(lsl.get("als_channel_index_1based", -1)),
            "--out-dir", str(Path(self.cfg["log_root"]) / "als_pulse_tests"),
            "--fullscreen",
            "--pulse-position", "lower_right",
            "--size-px", "180",
            "--margin-px", "40"
        ]
        self.launch_python_tool("ALS Screen Pulse Barcode Test", "als_pulse_test", args)

    def populate_lsl_tree(self) -> None:
        if not hasattr(self, "lsl_tree"): return
        self.lsl_tree.delete(*self.lsl_tree.get_children())
        try:
            from pylsl import resolve_streams
            streams = resolve_streams(wait_time=1.0)
            for idx, s in enumerate(streams):
                self.lsl_tree.insert("", "end", iid=str(idx), values=(s.name(), s.type(), s.channel_count(), s.nominal_srate(), s.source_id()))
            self.log(f"LSL monitor found {len(streams)} stream(s).\n")
        except Exception as exc:
            self.log(f"LSL monitor unavailable/error: {exc}\n")
            messagebox.showwarning("LSL monitor", f"Could not resolve LSL streams. Install pylsl or check network.\n\n{exc}")

    # Runner launch modes
    def psychopy_coder_command(self, runner: Optional[Path] = None) -> List[str]:
        """Build a PsychoPy Coder command that bypasses broken console launchers."""
        psychopy_python = normalized_path(self.cfg["tools"].get("psychopy_python", ""))
        if psychopy_python.is_file():
            cmd = [str(psychopy_python), "-m", "psychopy.app.psychopyApp", "--coder"]
            if runner is not None:
                cmd.append(str(runner))
            return cmd
        coder = normalized_path(
            self.cfg["tools"].get("psychopy_coder", "")
            or self.cfg["tools"].get("psychopy_app", "")
        )
        if coder.is_file():
            cmd = windows_bat_command(coder, ["--coder"] + ([str(runner)] if runner is not None else []))
            return cmd
        return []

    def launch_praycg_runner(self) -> None:
        if not self.active_run_uuid:
            self.begin_acquisition_session()
        mode = self.runner_mode_var.get()
        self.cfg["runner_launch_mode"] = mode
        runner = self.cfg["tools"].get("protocol_runner_praycg2", "")
        if not runner:
            messagebox.showwarning("Runner path missing", "Set PRAYCG2.2 runner script path in Settings.")
            return
        rp = normalized_path(runner)
        if not rp.is_file():
            messagebox.showerror("Runner not found", f"PRAYCG2.2 runner script not found:\n\n{rp}\n\nUse Settings -> Use Bundled Paths.")
            return
        if mode == "open_psychopy_coder_then_open_runner_file":
            cmd = self.psychopy_coder_command(rp)
            if not cmd:
                messagebox.showwarning("PsychoPy path missing", "Set PsychoPy Python, Coder, or app path in Settings, then run Auto-find PsychoPy.")
                return
            self.launch_process("PRAYCG2.2 Runner in PsychoPy Coder", cmd, cwd=rp.parent)
            self.log(f"Opening PRAYCG2.2 runner directly in PsychoPy Coder: {rp}\n")
        elif mode == "psychopy_app_file_arg":
            app = self.cfg["tools"].get("psychopy_app", "")
            if not app:
                messagebox.showwarning("PsychoPy app missing", "Set PsychoPy app path in Settings.")
                return
            self.launch_process("PRAYCG2.2 Runner via PsychoPy app", [app, "--coder", str(rp)], cwd=rp.parent)
        elif mode == "psychopy_python":
            py = self.cfg["tools"].get("psychopy_python", "")
            if not py:
                messagebox.showwarning("PsychoPy Python missing", "Set PsychoPy Python interpreter path in Settings.")
                return
            self.launch_process("PRAYCG2.2 Runner via PsychoPy Python", [py, str(rp)], cwd=rp.parent)
        else:
            self.launch_process("PRAYCG2.2 Runner via regular Python", self.get_python_cmd() + [str(rp)], cwd=rp.parent)

    def launch_psychopy_coder_only(self, show_warning=True) -> None:
        cmd = self.psychopy_coder_command()
        if not cmd:
            if show_warning:
                messagebox.showwarning("PsychoPy path missing", "Set PsychoPy Python, Coder, or app path in Settings, then run Auto-find PsychoPy.")
            return
        self.launch_process("PsychoPy Coder", cmd)

    def open_runner_location(self) -> None:
        runner = self.cfg["tools"].get("protocol_runner_praycg2", "")
        if not runner:
            messagebox.showwarning("Runner path missing", "Set PRAYCG2.2 runner path in Settings.")
            return
        p = normalized_path(runner)
        open_path(p.parent if p.parent.exists() else p)




    def use_bundled_paths(self) -> None:
        """Reset tool paths to the software bundled inside this v0.92 package."""
        root = package_root()
        # Also reset Python to the interpreter running this Control Center.
        # This clears stale v0.5 configs where a Windows path may have been corrupted by shlex.
        self.cfg["python_executable"] = sys.executable
        self.cfg.setdefault("tools", {})
        self.cfg["tools"].update(bundled_tool_paths(root))
        self.cfg["schema"] = CONFIG_SCHEMA
        self.cfg["version"] = APP_VERSION
        self.save_config()
        if hasattr(self, "setting_vars"):
            for name, var in self.setting_vars.items():
                try:
                    if "." in name:
                        key, sub = name.split(".", 1)
                        var.set(str(self.cfg.get(key, {}).get(sub, "")))
                    else:
                        var.set(str(self.cfg.get(name, "")))
                except Exception:
                    pass
        self.log("Bundled v0.92 software paths loaded. Python executable reset to current interpreter. LabRecorder and PsychoPy remain external and can be auto-found or set manually.\n")
        messagebox.showinfo("Bundled paths loaded", "Control Center paths now point to the bundled v0.92 public package. Python executable was reset to the current interpreter. LabRecorder and PsychoPy are external apps and still need auto-find or manual selection.")

    # Auto-find helpers v0.4
    def _autofind_roots(self) -> List[Path]:
        roots: List[Path] = []
        def add(x):
            if not x: return
            try:
                p = Path(x).expanduser()
                if p.exists() and p.is_dir() and p not in roots:
                    roots.append(p)
            except Exception:
                pass
        add(self.cfg.get("praycg_home"))
        add(self.cfg.get("stimulus_root"))
        add(self.cfg.get("run_root"))
        add(self.pkg)
        add(Path.home() / "Desktop")
        add(Path.home() / "Downloads")
        add(Path.home() / "Documents")
        for env in ["PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA", "APPDATA"]:
            add(os.environ.get(env))
        for x in ["C:/PRAYCG", "C:/Program Files/PsychoPy", "C:/Program Files/LabRecorder", "C:/LabRecorder", "C:/PsychoPy"]:
            add(x)
        return roots

    def _bounded_find(self, patterns: List[str], roots: Optional[List[Path]]=None, max_depth: int=7, max_hits: int=40, time_budget_sec: float=9.0) -> List[Path]:
        """Fast bounded recursive finder for public Windows users. Avoids full C:\ sweeps."""
        start = time.time()
        roots = roots or self._autofind_roots()
        hits: List[Path] = []
        seen = set()
        lower_patterns = [p.lower() for p in patterns]
        for root in roots:
            if time.time() - start > time_budget_sec or len(hits) >= max_hits:
                break
            try:
                root = root.resolve()
            except Exception:
                continue
            if not root.exists():
                continue
            stack = [(root, 0)]
            while stack and time.time() - start <= time_budget_sec and len(hits) < max_hits:
                cur, depth = stack.pop()
                try:
                    entries = list(cur.iterdir())
                except Exception:
                    continue
                for e in entries:
                    if len(hits) >= max_hits or time.time() - start > time_budget_sec:
                        break
                    name = e.name.lower()
                    if e.is_file():
                        for pat in lower_patterns:
                            if self._wild_match(name, pat) or self._wild_match(str(e).lower(), pat):
                                try:
                                    r = e.resolve()
                                except Exception:
                                    r = e
                                if str(r).lower() not in seen:
                                    hits.append(r); seen.add(str(r).lower())
                                break
                    elif e.is_dir() and depth < max_depth:
                        # Skip noisy folders.
                        if name in {".git", "__pycache__", "node_modules", "windows", "winsxs", "appdata"} and depth > 0:
                            continue
                        stack.append((e, depth + 1))
        return hits

    def _wild_match(self, text: str, pattern: str) -> bool:
        # small wildcard matcher for names/paths; pattern is lowercase.
        if "*" not in pattern:
            return pattern in text
        rx = re.escape(pattern).replace(r"\*", ".*")
        return re.search(rx, text) is not None

    def _score_candidate(self, path: Path, kind: str) -> int:
        txt = str(path).lower()
        score = 0
        if kind == "runner":
            for token, pts in [("praycg2_0", 50), ("2_0", 30), ("consolidated", 30), ("selfreport", 25), ("runner", 10), ("scripts", 5), ("current", 10)]:
                if token in txt: score += pts
            if path.name == "run_PRAYCG2_0_ConsolidatedSelfReport.py": score += 80
        elif kind == "labrecorder":
            if path.name.lower() == "labrecorder.exe": score += 80
            if "program files" in txt: score += 10
        elif kind == "psychopy":
            if path.name.lower() in {"psychopy.exe", "psychopyapp.exe"}: score += 80
            if "program files" in txt: score += 10
        elif kind == "psychopy_python":
            if path.name.lower() in {"python.exe", "pythonw.exe"}: score += 30
            if "psychopy" in txt: score += 50
        # prefer shorter paths after scoring.
        score -= min(len(txt) // 80, 5)
        return score

    def _choose_best(self, candidates: List[Path], kind: str) -> Optional[Path]:
        if not candidates:
            return None
        return sorted(candidates, key=lambda p: (self._score_candidate(p, kind), -len(str(p))), reverse=True)[0]

    def _set_tool_path(self, key: str, path: Optional[Path]) -> None:
        if not path:
            return
        self.cfg.setdefault("tools", {})[key] = str(path)
        if hasattr(self, "setting_vars"):
            var = self.setting_vars.get(f"tools.{key}")
            if var is not None:
                var.set(str(path))

    def _set_core_path(self, key: str, path: Optional[Path]) -> None:
        if not path:
            return
        self.cfg[key] = str(path)
        if hasattr(self, "setting_vars"):
            var = self.setting_vars.get(key)
            if var is not None:
                var.set(str(path))

    def autofind_labrecorder(self, save: bool=True) -> Dict[str, Any]:
        report: Dict[str, Any] = {"tool": "labrecorder", "found": False, "candidates": []}
        which = shutil.which("LabRecorder") or shutil.which("LabRecorder.exe")
        cands = [Path(which)] if which else []
        cands += self._bounded_find(["labrecorder.exe", "*LabRecorder*.exe"], max_depth=6, time_budget_sec=7.0)
        best = self._choose_best(cands, "labrecorder")
        report["candidates"] = [str(p) for p in cands[:20]]
        if best:
            report.update({"found": True, "selected": str(best)})
            self._set_tool_path("labrecorder", best)
            self.log(f"Auto-find LabRecorder: {best}\n")
        else:
            self.log("Auto-find LabRecorder: not found. Set manually in Settings.\n")
        if save: self.save_config()
        return report

    def autofind_psychopy(self, save: bool=True) -> Dict[str, Any]:
        report: Dict[str, Any] = {"tool": "psychopy", "found": False, "candidates": []}
        cands: List[Path] = []
        for name in ["psychopy", "psychopy.exe"]:
            w = shutil.which(name)
            if w: cands.append(Path(w))
        cands += self._bounded_find(["psychopy.exe", "*PsychoPy*.exe"], max_depth=7, time_budget_sec=9.0)
        best = self._choose_best(cands, "psychopy")
        report["candidates"] = [str(p) for p in cands[:20]]
        if best:
            report.update({"found": True, "selected_app": str(best), "selected_coder": str(best)})
            self._set_tool_path("psychopy_app", best)
            self._set_tool_path("psychopy_coder", best)
            # Look for PsychoPy-bundled Python near the app.
            py_cands = []
            for parent in [best.parent, best.parent.parent if best.parent.parent else best.parent]:
                for nm in ["python.exe", "pythonw.exe"]:
                    p = parent / nm
                    if p.exists(): py_cands.append(p)
                for sub in ["python", "Python", "resources", "Scripts"]:
                    d = parent / sub
                    if d.exists():
                        py_cands += [p for p in d.rglob("python*.exe") if p.is_file()][:10]
            py_best = self._choose_best(py_cands, "psychopy_python")
            if py_best:
                self._set_tool_path("psychopy_python", py_best)
                report["selected_python"] = str(py_best)
            self.log(f"Auto-find PsychoPy: {best}\n")
        else:
            self.log("Auto-find PsychoPy: not found. Set manually in Settings.\n")
        if save: self.save_config()
        return report

    def autofind_runner(self, save: bool=True) -> Dict[str, Any]:
        report: Dict[str, Any] = {"tool": "praycg_runner", "found": False, "candidates": []}
        # Favor PRAYCG home/current-tools locations and the user Desktop.
        roots = self._autofind_roots()
        cands = self._bounded_find([
            "run_praycg2_0_consolidatedselfreport.py",
            "*praycg2*consolidated*selfreport*.py",
            "*praycg*2_0*runner*.py",
            "*run*praycg*2*.py"
        ], roots=roots, max_depth=10, max_hits=80, time_budget_sec=12.0)
        best = self._choose_best(cands, "runner")
        report["candidates"] = [str(p) for p in cands[:30]]
        if best:
            report.update({"found": True, "selected": str(best)})
            self._set_tool_path("protocol_runner_praycg2", best)
            self.log(f"Auto-find PRAYCG2.2 runner: {best}\n")
        else:
            self.log("Auto-find PRAYCG2.2 runner: not found. Set manually in Settings.\n")
        if save: self.save_config()
        return report

    def autofind_common_tools(self) -> None:
        report = {
            "schema": "PRAYCG_ControlCenter_AutoFind_Report_v0_4",
            "created_local": datetime.now().isoformat(timespec="seconds"),
            "labrecorder": self.autofind_labrecorder(save=False),
            "psychopy": self.autofind_psychopy(save=False),
            "runner": self.autofind_runner(save=False),
        }
        # Save after all updates so the Settings GUI gets all values.
        self.save_config()
        out_dir = Path(self.cfg["log_root"]) / "control_center" / "autofind"
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"autofind_report_{now_stamp()}.json"
        out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
        self.log(f"Auto-find report written: {out_path}\n")
        if hasattr(self, "runner_detect_text"):
            self.refresh_runner_detect_text()
        messagebox.showinfo("Auto-find complete", "Auto-find finished. Review Settings paths before launching tools.\n\nReport:\n" + str(out_path))

    # Analysis tab
    def read_run_registry(self) -> Dict[str, Any]:
        try:
            payload = json.loads(Path(self.cfg["run_registry"]).read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else {"schema": "PRAYCG_RunRegistry_v0_2", "runs": []}
        except Exception:
            return {"schema": "PRAYCG_RunRegistry_v0_2", "runs": []}

    def write_run_registry(self, registry: Dict[str, Any]) -> None:
        registry["schema"] = "PRAYCG_RunRegistry_v0_2"
        Path(self.cfg["run_registry"]).write_text(json.dumps(registry, indent=2), encoding="utf-8")

    def record_selected_run(self) -> None:
        run = self.active_context.get("run", {})
        folder = str(run.get("folder") or "")
        if not folder:
            return
        registry = self.read_run_registry()
        previous = next((item for item in registry.get("runs", []) if str(item.get("folder", "")).casefold() == folder.casefold()), {})
        entry = {
            "folder": folder,
            "label": run.get("label") or Path(folder).name,
            "run_uuid": run.get("run_uuid") or "",
            "protocol_schema": run.get("protocol_schema") or "",
            "stimulus_id": self.active_context.get("stimulus", {}).get("id") or "",
            "xdf": self.context_record_path(run, "xdf"),
            "events": self.context_record_path(run, "events"),
            "last_selected_local": datetime.now().isoformat(timespec="seconds"),
            "pinned": bool(previous.get("pinned", False)),
        }
        runs = [item for item in registry.get("runs", []) if str(item.get("folder", "")).casefold() != folder.casefold()]
        runs.append(entry)
        registry["runs"] = runs
        self.write_run_registry(registry)
        self.refresh_run_catalog()

    def refresh_run_catalog(self) -> None:
        if not hasattr(self, "run_catalog_combo"):
            return
        runs = self.read_run_registry().get("runs", [])
        runs = [item for item in runs if str(item.get("folder") or "")]
        runs.sort(key=lambda item: str(item.get("last_selected_local") or ""), reverse=True)
        runs.sort(key=lambda item: bool(item.get("pinned")), reverse=True)
        self.run_catalog_paths: Dict[str, str] = {}
        values = []
        for item in runs:
            prefix = "PIN | " if item.get("pinned") else ""
            label = f"{prefix}{item.get('label') or Path(item['folder']).name} | {item.get('run_uuid') or 'no UUID'} | {item['folder']}"
            values.append(label)
            self.run_catalog_paths[label] = str(item["folder"])
        self.run_catalog_combo["values"] = values
        if values and self.run_catalog_var.get() not in values:
            self.run_catalog_var.set(values[0])

    def use_run_catalog_selection(self) -> None:
        folder = self.run_catalog_paths.get(self.run_catalog_var.get(), "") if hasattr(self, "run_catalog_paths") else ""
        if not folder or not Path(folder).is_dir():
            messagebox.showwarning("Run unavailable", "The selected catalog entry no longer points to an existing folder.")
            return
        self.selected_run_folder = Path(folder)
        self.active_context["analysis"] = {}
        self.scan_selected_run_folder()

    def toggle_pin_catalog_run(self) -> None:
        folder = self.run_catalog_paths.get(self.run_catalog_var.get(), "") if hasattr(self, "run_catalog_paths") else ""
        if not folder:
            return
        registry = self.read_run_registry()
        for item in registry.get("runs", []):
            if str(item.get("folder", "")).casefold() == folder.casefold():
                item["pinned"] = not bool(item.get("pinned"))
                break
        self.write_run_registry(registry)
        self.refresh_run_catalog()

    def select_run_folder(self) -> None:
        d = filedialog.askdirectory(title="Select PRAYCG run folder")
        if d:
            self.selected_run_folder = Path(d)
            self.active_context["analysis"] = {}
            self.scan_selected_run_folder()

    def scan_selected_run_folder(self) -> None:
        folder = self.selected_run_folder
        if not folder:
            if hasattr(self, "analysis_text"):
                self.analysis_text.delete("1.0", "end")
                self.analysis_text.insert("end", "No run folder selected.\n")
            return
        if not folder.is_dir():
            messagebox.showwarning("Run folder missing", f"The selected run folder no longer exists:\n{folder}")
            return
        self.active_context["run"] = resolve_raw_run(folder)
        self.active_run_uuid = self.active_context["run"].get("run_uuid") or None
        self.link_stimulus_from_run_context()
        self.record_selected_run()
        self.refresh_analysis_context()

    def link_stimulus_from_run_context(self) -> None:
        """Use recorded media paths to link a run to exactly one registered stimulus."""
        run = self.active_context.get("run", {})
        recorded_paths = []
        for key in ("target_video", "override_video", "control_video", "cue_schedule_json"):
            value = self.context_record_path(run, key)
            if value:
                recorded_paths.append(Path(value))
        if not recorded_paths:
            return
        matches = []
        for item in self.read_registry().get("stimuli", []):
            folder_value = str(item.get("folder") or "")
            if not folder_value:
                continue
            stimulus_folder = Path(folder_value)
            if any(path_is_within(path, stimulus_folder) for path in recorded_paths):
                matches.append(str(item.get("stimulus_id") or ""))
        matches = sorted(set(value for value in matches if value))
        if len(matches) == 1 and matches[0] != self.selected_stimulus_id:
            self.selected_stimulus_id = matches[0]
            self.update_stimulus_context(matches[0])
            if hasattr(self, "stim_tree") and self.stim_tree.exists(matches[0]):
                self.stim_tree.selection_set(matches[0])
                self.stim_tree.focus(matches[0])
            self.log(f"Linked selected run to registered stimulus {matches[0]} using recorded media paths.\n")

    def refresh_analysis_context(self) -> None:
        run = self.active_context.get("run", {})
        run_folder_value = str(run.get("folder") or "")
        if not run_folder_value:
            self.active_context["analysis"] = {}
            self.save_active_context()
            return
        run_folder = Path(run_folder_value)
        existing = self.active_context.get("analysis", {})
        core_override = None
        chain_override = None
        if existing.get("core", {}).get("source") == "MANUAL_SELECTION" and existing.get("core", {}).get("path"):
            core_override = Path(existing["core"]["path"])
        if existing.get("chain", {}).get("source") == "MANUAL_SELECTION" and existing.get("chain", {}).get("path"):
            chain_override = Path(existing["chain"]["path"])
        self.active_context["analysis"] = resolve_analysis_outputs(
            Path(self.cfg["analysis_root"]),
            run,
            run_folder=run_folder,
            core_override=core_override,
            chain_override=chain_override,
        )
        self.save_active_context()
        self.render_analysis_context()

    def select_core_analysis_folder(self) -> None:
        d = filedialog.askdirectory(title="Select completed Master Suite v1.6.0 core output")
        if not d:
            return
        folder = Path(d).resolve()
        canonical = folder / "tables" / "praycg_analysis_frame_v1_6_0.csv"
        if not canonical.is_file():
            messagebox.showerror("Not a canonical core output", f"Missing:\n{canonical}")
            return
        self.active_context.setdefault("analysis", {})["core"] = {
            "status": "RESOLVED",
            "path": str(folder),
            "source": "MANUAL_SELECTION",
            "message": "Manually selected canonical core output",
            "candidates": [str(folder)],
        }
        self.active_context["analysis"]["chain"] = {}
        self.refresh_analysis_context()

    def select_run_artifact(self, key: str, title: str, filetypes) -> None:
        value = filedialog.askopenfilename(title=title, filetypes=filetypes)
        if not value:
            return
        path = Path(value).resolve()
        self.active_context.setdefault("run", {})[key] = {
            "status": "RESOLVED",
            "path": str(path),
            "source": "MANUAL_SELECTION",
            "message": "Manually selected raw-run artifact",
            "candidates": [str(path)],
        }
        self.active_context["analysis"] = {}
        self.record_selected_run()
        self.refresh_analysis_context()

    def select_chain_analysis_folder(self) -> None:
        d = filedialog.askdirectory(title="Select completed v1.6.1 chained-analysis output")
        if not d:
            return
        folder = Path(d).resolve()
        if not (folder / "chain_manifest.json").is_file():
            messagebox.showerror("Not a chained output", f"Missing chain_manifest.json in:\n{folder}")
            return
        self.active_context.setdefault("analysis", {})["chain"] = {
            "status": "RESOLVED",
            "path": str(folder),
            "source": "MANUAL_SELECTION",
            "message": "Manually selected chained-analysis output",
            "candidates": [str(folder)],
        }
        self.refresh_analysis_context()

    def render_analysis_context(self) -> None:
        if not hasattr(self, "analysis_text"):
            return
        run = self.active_context.get("run", {})
        analysis = self.active_context.get("analysis", {})
        self.analysis_run_var.set(f"Run: {run.get('folder') or 'none'}")
        self.analysis_core_var.set(f"Core: {analysis.get('core', {}).get('status', 'MISSING')} | {analysis.get('core', {}).get('path', '')}")
        self.analysis_chain_var.set(f"Chain: {analysis.get('chain', {}).get('status', 'MISSING')} | {analysis.get('chain', {}).get('path', '')}")
        self.analysis_text.delete("1.0", "end")
        self.analysis_text.insert("end", summarize_context(self.active_context))

    def update_analysis_button_states(self) -> None:
        if not hasattr(self, "analysis_buttons"):
            return
        for key, button in self.analysis_buttons.items():
            button.configure(state="normal" if self.tool_is_ready(key) else "disabled")
        self.render_analysis_context()

    def open_preferred_review_folder(self) -> None:
        preferred = str(self.active_context.get("analysis", {}).get("preferred_review_folder") or "")
        if not preferred:
            messagebox.showinfo("No review folder", "Complete or select a matching core/chained analysis output first.")
            return
        open_path(Path(preferred))


def main() -> int:
    app = PRAYCGControlCenter()
    app.mainloop()
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
