# PRAYCG Control Center v0.92 Public Release Notes

Release date: 2026-08-29

v0.92 focuses on workflow continuity, exact provenance, and visible process control. It does not change the mathematical or scientific methods of Master Suite v1.6.0, chain v1.6.1, Visualizer v1.4.0, Interpreter v1.6.0, HOC-R v1.6.0, or the acquisition bridges.

## Running Tools

- Replaces the oversized Running Tools table and off-screen shared shutdown panel with a scrollable row layout.
- Gives every launched tool its own visible red **Close** button.
- Adds per-tool Open Log and More actions. More provides Force close, Open working folder, and Restart.
- Retains process-tree shutdown so a launcher and the child process it created are handled together.
- Refreshes the active analysis context once a launched analysis tool exits.
- Adds Clear Exited without deleting the retained log files.

## Active Research Context v1.0

- Adds a persistent cross-tab context bar for the selected stimulus, raw run, canonical core output, chain output, and review readiness.
- Stores the current selection in `active_context_v1_0.json` under the user's Control Center settings folder rather than inside the public package or raw data.
- Uses explicit `RESOLVED`, `MISSING`, `AMBIGUOUS`, `INCOMPATIBLE`, and manual-selection states.
- Never selects the newest artifact merely because it has the latest modification time.
- Adds a visible workflow strip: Media -> Run -> Core -> Chain -> Review.
- Adds recent/pinned stimulus and run catalogs.

## Automatic input population

- Selecting a stimulus prefills MediaPrep with the registered master MP4, a dedicated MediaPrep output root, and the stimulus/project name.
- Selecting a raw run resolves its XDF, preferred JSON event log, channel map, run UUID, protocol schema, cue schedule, locked anchor, and recorded condition videos.
- The Master Suite GUI receives all available raw-run and selected-stimulus inputs plus the configured analysis output root.
- The chain, HOC-R, and confound GUIs receive only a validated canonical core v1.6.0 output.
- The Visualizer receives the compatible review folder plus available XDF, event log, and Target video.
- The Interpreter receives the preferred compatible chain or core folder and run label.
- The ALS Barcode Detector receives the selected raw run, exact XDF, and JSON event log.
- All launches remain review-first: input population never clicks Run or begins analysis automatically.

## Provenance and ambiguity safeguards

- Core outputs are associated with the selected run by exact XDF/event paths recorded in `config/run_config.json`.
- Chained outputs are associated with the active core through `chain_manifest.json`.
- Multiple XDFs, event logs, core outputs, or chain outputs are surfaced for explicit resolution.
- The Analysis page includes manual selectors for XDF, event log, channel map, canonical core output, and chain output.
- A selected run can link to exactly one registered stimulus through the media paths written by the PRAYCG2.2 run configuration.
- New core analyses copy `PRAYCG_ActiveResearchContext_v1_0.json` into provenance; chained analyses carry the snapshot forward.

## Launcher and GUI corrections

- MediaPrep's GUI now uses its parsed master, output-root, and project-name values instead of reopening with blank fields.
- The Master Suite launcher preserves Control Center arguments and the GUI initializes from them.
- Corrects a Master Suite GUI omission where the visible Feature Table CSV field was not transferred into `SuiteConfig` when Run was clicked.
- Chain, HOC-R, ALS Barcode, Visualizer, Interpreter, and confound GUIs now accept and display prefilled launch values.
- Explicit launch values override the Interpreter's remembered analysis folder for that launch.

## Organization

- Reorganizes the Analysis page as a run workspace with selected run/core/chain paths, context-aware workflow buttons, readiness details, and direct Open Source Run/Open Analysis Root/Open Preferred Review Folder actions.
- Disables analysis buttons whose prerequisites are not resolved; the readiness preview explains why.
- Keeps raw-run, core-analysis, chained-analysis, and preferred-review paths visibly distinct.

## Verification performed

- All bundled Python files parsed successfully.
- Thirteen focused unit/regression tests passed, including inherited Master Suite and review-tool tests plus the new context resolver tests.
- CLI help/argument contracts passed for Master Suite, chain, HOC-R, ALS Barcode, Visualizer, Interpreter, and confound launch paths.
- A visible-interface construction smoke test confirmed a genuine per-row Close button is created for a launched process.
- Public-package privacy scan excludes XDF, audio/video, generated logs, caches, and local settings.

## Scientific boundary

These changes reduce folder-selection and software-orchestration errors. They do not establish that the selected inputs are scientifically adequate, that an acquisition is artifact-free, or that a reported endpoint has a particular biological or narrative interpretation. Existing timing, eligibility, artifact, confound, multiplicity, and interpretation gates remain authoritative.
