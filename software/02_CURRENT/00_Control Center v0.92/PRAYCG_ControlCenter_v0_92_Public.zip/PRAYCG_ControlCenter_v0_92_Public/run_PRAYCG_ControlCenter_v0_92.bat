@echo off
setlocal
cd /d "%~dp0"
set "PRAYCG_SCRIPT=control_center\scripts\praycg_control_center_v0_92.py"

echo Starting PRAYCG Control Center v0.92 Public ...

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" goto local_python311

where py >nul 2>nul
if not errorlevel 1 goto python_launcher

where python >nul 2>nul
if not errorlevel 1 goto path_python

echo.
echo ERROR: No usable Python installation was found.
echo Install Python 3.11, then run this starter again.
pause
exit /b 2

:local_python311
"%LOCALAPPDATA%\Programs\Python\Python311\python.exe" "%PRAYCG_SCRIPT%"
goto finished

:python_launcher
py -3.11 "%PRAYCG_SCRIPT%"
goto finished

:path_python
python "%PRAYCG_SCRIPT%"

:finished
if errorlevel 1 (
  echo.
  echo Control Center exited with an error. Review the message above.
  pause
)
endlocal
