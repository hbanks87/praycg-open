# PRAYCG2.2 Runner — Runner-Level ALS Barcode

PRAYCG2.2 is a patch of the PRAYCG2.0 consolidated self-report runner.

In addition to the barcode overlay, v2.2 adds an immutable run UUID, a versioned event schema with scheduled/observed timing fields, critical flip logging, input hashes, output-writability checks, and a durable run-state manifest. An aborted or failed run is marked `INCOMPLETE` rather than being left ambiguous.

## Main change

Before each analyzable video branch, the runner draws a physical-screen ALS/PT19 barcode overlay using PsychoPy. This is independent of the MP4 frame and therefore is not shifted by `safe_fit`, letterboxing, or video aspect ratio.

Default barcode:

```text
black pre-guard: 0.50 s
white pulse A:   2.00 s
black gap:       0.50 s
white pulse B:   0.75 s
black post:      1.00 s
```

Default branches:

```text
CONTROL_1
TARGET_1
CONTEXTUAL_OVERRIDE_1
```

The runner also emits `OVERRIDE_1_*` alias markers for the Contextual Override branch when aliasing is enabled.

## Runner script

```text
scripts/run_PRAYCG2_2_ProvenanceSafe_ALSBarcode.py
```

## Marker families

For each branch, the runner emits:

```text
<BRANCH>_ALS_BARCODE_START
<BRANCH>_ALS_PULSE_A_START
<BRANCH>_ALS_PULSE_A_END
<BRANCH>_ALS_PULSE_B_START
<BRANCH>_ALS_PULSE_B_END
<BRANCH>_ALS_BARCODE_END
<BRANCH>_ALS_CONTENT_START
<BRANCH>_START
```

`<BRANCH>_START` remains the backward-compatible video-content start marker. `<BRANCH>_ALS_CONTENT_START` is the new explicit barcode-to-content transition marker.

## Boundary

The ALS/PT19 signal is a physical display-timing channel. It validates visual onset timing in the external input stream. It is not a biological signal and does not certify MRED, A-MRED, meaning, OSM biology, consciousness, or mechanism.

Use Control Center v0.92's optional 30-second acquisition validation before a session to test the physical barcode location and save the observed screen geometry, profile hash, EEG quality indicators, and ALS pulse visibility. That separate report does not arm or block this runner.
