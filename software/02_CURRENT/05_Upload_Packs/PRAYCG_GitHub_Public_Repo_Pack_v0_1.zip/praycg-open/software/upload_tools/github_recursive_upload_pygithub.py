#!/usr/bin/env python3
"""
Recursively upload a local folder to a GitHub repository using PyGithub.

Requirements:
  pip install PyGithub
  set GITHUB_TOKEN=...   (Windows PowerShell: $env:GITHUB_TOKEN="..." )

Example:
  python github_recursive_upload_pygithub.py ^
    --local-folder C:\PRAYCG\praycg-open ^
    --repo owner/repo ^
    --branch main ^
    --remote-prefix "" ^
    --commit-message "Initial PRAYCG open release" ^
    --dry-run

Notes:
  - Uses GitHub Contents API via PyGithub create_file/update_file.
  - Skips files larger than --max-mb because GitHub's regular file API is not meant for large files.
  - For large media/datasets, use OSF or Git LFS.
"""
from __future__ import annotations
import argparse, os, sys, time
from pathlib import Path, PurePosixPath
from github import Github, GithubException

DEFAULT_SKIP_DIRS = {".git", "__pycache__", ".venv", "venv", ".cache"}
DEFAULT_SKIP_SUFFIXES = {".pyc", ".pyo", ".DS_Store"}

def iter_files(root: Path, include_hidden: bool):
    for p in root.rglob("*"):
        if p.is_dir():
            continue
        parts = set(p.relative_to(root).parts)
        if parts & DEFAULT_SKIP_DIRS:
            continue
        if not include_hidden and any(part.startswith('.') for part in p.relative_to(root).parts):
            if p.name not in {'.gitignore'}:
                continue
        if p.suffix in DEFAULT_SKIP_SUFFIXES:
            continue
        yield p

def remote_path(local: Path, root: Path, prefix: str) -> str:
    rel = PurePosixPath(*local.relative_to(root).parts)
    return str(PurePosixPath(prefix) / rel) if prefix else str(rel)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--local-folder', required=True)
    ap.add_argument('--repo', required=True, help='owner/repository')
    ap.add_argument('--branch', default='main')
    ap.add_argument('--remote-prefix', default='')
    ap.add_argument('--commit-message', default='Recursive upload')
    ap.add_argument('--token-env', default='GITHUB_TOKEN')
    ap.add_argument('--max-mb', type=float, default=90.0)
    ap.add_argument('--sleep-sec', type=float, default=0.2)
    ap.add_argument('--include-hidden', action='store_true')
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()

    root = Path(args.local_folder).resolve()
    if not root.exists():
        raise SystemExit(f'Local folder not found: {root}')
    token = os.environ.get(args.token_env)
    if not token and not args.dry_run:
        raise SystemExit(f'Missing token env var {args.token_env}')

    files = list(iter_files(root, args.include_hidden))
    print(f'Found {len(files)} files under {root}')
    if args.dry_run:
        for f in files:
            print('DRY', f, '->', remote_path(f, root, args.remote_prefix))
        return

    gh = Github(token)
    repo = gh.get_repo(args.repo)

    uploaded = updated = skipped = failed = 0
    for f in files:
        size_mb = f.stat().st_size / (1024*1024)
        rp = remote_path(f, root, args.remote_prefix)
        if size_mb > args.max_mb:
            print(f'SKIP >{args.max_mb}MB: {rp} ({size_mb:.1f} MB)')
            skipped += 1
            continue
        data = f.read_bytes()
        msg = f'{args.commit_message}: {rp}'
        try:
            try:
                existing = repo.get_contents(rp, ref=args.branch)
                repo.update_file(rp, msg, data, existing.sha, branch=args.branch)
                print('UPDATED', rp)
                updated += 1
            except GithubException as e:
                if e.status == 404:
                    repo.create_file(rp, msg, data, branch=args.branch)
                    print('CREATED', rp)
                    uploaded += 1
                else:
                    raise
        except Exception as e:
            print('FAILED', rp, repr(e), file=sys.stderr)
            failed += 1
        time.sleep(args.sleep_sec)

    print({'created': uploaded, 'updated': updated, 'skipped': skipped, 'failed': failed})
    if failed:
        raise SystemExit(2)

if __name__ == '__main__':
    main()
