#!/usr/bin/env python3
"""
Recursively upload a local folder to OSF using the osfclient CLI.

Requirements:
  pip install osfclient
  set OSF_TOKEN=...       (recommended)

Example:
  python osf_recursive_upload_osfclient.py ^
    --local-folder C:\PRAYCG\PRAYCG_Open_Science_Hub_OSF_v0_1 ^
    --project-id abc12 ^
    --remote-prefix PRAYCG_Open_Science_Hub ^
    --dry-run

Then remove --dry-run.

This wrapper calls:
  osf -p <project_id> upload <local_file> <remote_path>

It uploads files one-by-one so failures are visible and resumable.
"""
from __future__ import annotations
import argparse, os, subprocess, sys, time
from pathlib import Path, PurePosixPath

SKIP_DIRS = {'.git', '__pycache__', '.venv', 'venv', '.cache'}
SKIP_SUFFIXES = {'.pyc', '.pyo', '.DS_Store'}

def iter_files(root: Path, include_hidden: bool):
    for p in root.rglob('*'):
        if p.is_dir():
            continue
        rel_parts = p.relative_to(root).parts
        if set(rel_parts) & SKIP_DIRS:
            continue
        if not include_hidden and any(part.startswith('.') for part in rel_parts):
            continue
        if p.suffix in SKIP_SUFFIXES:
            continue
        yield p

def remote_path(local: Path, root: Path, prefix: str) -> str:
    rel = PurePosixPath(*local.relative_to(root).parts)
    return str(PurePosixPath(prefix) / rel) if prefix else str(rel)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--local-folder', required=True)
    ap.add_argument('--project-id', required=True, help='OSF project/component short id, e.g. abc12')
    ap.add_argument('--remote-prefix', default='')
    ap.add_argument('--username', default=os.environ.get('OSF_USERNAME',''))
    ap.add_argument('--sleep-sec', type=float, default=0.1)
    ap.add_argument('--include-hidden', action='store_true')
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--force', action='store_true', help='pass -f to osf upload')
    args = ap.parse_args()

    root = Path(args.local_folder).resolve()
    if not root.exists():
        raise SystemExit(f'Local folder not found: {root}')

    files = list(iter_files(root, args.include_hidden))
    print(f'Found {len(files)} files under {root}')

    ok = fail = 0
    for f in files:
        rp = remote_path(f, root, args.remote_prefix)
        cmd = ['osf', '-p', args.project_id]
        if args.username:
            cmd += ['-u', args.username]
        cmd += ['upload']
        if args.force:
            cmd += ['-f']
        cmd += [str(f), rp]
        if args.dry_run:
            print('DRY', ' '.join(cmd))
            continue
        print('UPLOAD', f, '->', rp)
        proc = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        print(proc.stdout)
        if proc.returncode == 0:
            ok += 1
        else:
            fail += 1
            print('FAILED', rp, file=sys.stderr)
        time.sleep(args.sleep_sec)

    print({'uploaded_ok': ok, 'failed': fail})
    if fail:
        raise SystemExit(2)

if __name__ == '__main__':
    main()
