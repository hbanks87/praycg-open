@echo off
setlocal
cd /d "%~dp0"
echo Starting PRAYCG Control Center v0.5 self-contained...
py -3.11 control_center\scripts\praycg_control_center_v0_5.py
if errorlevel 1 (
  echo.
  echo If py -3.11 failed, try: python control_center\scripts\praycg_control_center_v0_5.py
  pause
)
