# OSF Upload Map

This file maps the public hub structure into OSF components.

| OSF component | Purpose | Public status |
|---|---|---|
| 00_START_HERE | Orientation, boundaries, licenses, AI-use disclosure | Public |
| 01_PROTOCOL_PRAYCG | PR-AYC-G protocol, v1.8B anchors, reflection baseline, self-report | Public |
| 02_THE_BOX_OPEN_HARDWARE | Build guide, bill of materials, safety, testing | Public with safety caveats |
| 03_SOFTWARE_RELEASES | GitHub snapshots and release ZIPs | Public |
| 04_ANALYSIS_SUITE_METHODS | Deep analysis methods and formulas | Public |
| 05_QC_METROLOGY_AND_TIMING | ALS, control audio, visual QC, LSL checks | Public |
| 06_OPTOPING_OSM_SYNTHETIC_REPRODUCIBILITY | Rung 0J-O synthetic reproducibility | Public |
| 07_EXAMPLE_DATA_PUBLIC_DEMO | Synthetic-only demo data; no copyrighted media | Public |
| 08_RESULTS_AND_PILOT_REPORTS | Self-run reports if deidentified and claim-bounded | Review before public |
| 09_TSC_2026_POSTER_HANDOUTS | TSC public handouts, abstracts, QR landing text | Public |
| 10_BONUS_THEORY_AND_CULTURE | Philosophical companion materials | Public if clearly labeled non-empirical |
| 11_DEPRECATED_HISTORICAL_NOTES_PRIVATE_OR_WARNED | Historical overclaiming drafts | Prefer private/quarantined |
