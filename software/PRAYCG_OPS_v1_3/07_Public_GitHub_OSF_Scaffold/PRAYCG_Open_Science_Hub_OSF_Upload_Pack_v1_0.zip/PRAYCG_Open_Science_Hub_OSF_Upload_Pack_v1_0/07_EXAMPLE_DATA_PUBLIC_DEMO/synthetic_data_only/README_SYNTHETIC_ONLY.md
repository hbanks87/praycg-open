# Synthetic Data Only

This folder is for synthetic data that can be redistributed freely. Do not place raw participant data here.
