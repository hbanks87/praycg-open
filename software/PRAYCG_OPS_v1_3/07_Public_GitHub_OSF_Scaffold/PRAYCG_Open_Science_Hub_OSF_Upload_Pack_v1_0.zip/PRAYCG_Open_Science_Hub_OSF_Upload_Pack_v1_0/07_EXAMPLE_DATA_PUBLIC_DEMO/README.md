# 07 - Example Public Demo Data

This folder contains synthetic demo placeholders only. It does not contain copyrighted video, copyrighted audio, or raw participant XDF recordings.
