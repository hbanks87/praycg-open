# Public Release Audit Checklist

Complete this before making the OSF project public.

## Remove or avoid

- [ ] Copyrighted stimulus videos, audio, screenshots, or film stills.
- [ ] Raw XDF recordings from any participant without explicit public-consent documentation.
- [ ] Private emails, conference logistics, hotel links, or personal correspondence.
- [ ] API keys, passwords, tokens, virtual environments, or local machine credentials.
- [ ] GPS/EXIF location metadata from photos.
- [ ] Home/barn/location identifiers that should not be public.
- [ ] Participant names, family details, dates of birth, addresses, or identifying notes.
- [ ] Claims that PR-AYC-G proves consciousness, OSM biology, microtubular memory, biophotons, souls, or clinical efficacy.

## Verify included docs

- [ ] Every folder has a README.
- [ ] Every code ZIP has a version and license note.
- [ ] Every pilot report is marked exploratory unless it was preregistered and independently replicated.
- [ ] All PR-AYC-G analysis outputs distinguish confirmatory, secondary, exploratory, and future-freeze anchors.
- [ ] All OSM / Opto-PING results are labeled synthetic identifiability/reproducibility unless direct biological data are present.
- [ ] The ALS-PT19 timing channel is described only as a display-timing/metrology channel in external input `u(t)`, not biological `Y(t)`.
