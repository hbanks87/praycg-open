# Independent Verifier Instructions - Rung 0O

Goal: run the unchanged Rung 0O package and return the output files.

## Rules

Do not change:

- locked specification;
- model equations;
- random-seed policy;
- thresholds;
- model alternatives;
- complexity penalty;
- reporting template.

If any file is edited, the run becomes a new variant, not a reproduction.

## Return packet

Please return:

- operating system;
- Python version;
- hardware description;
- whether any files were modified;
- pass summary JSON;
- trial results CSV;
- CV model losses CSV;
- stdout/stderr log;
- notes on any failure.
