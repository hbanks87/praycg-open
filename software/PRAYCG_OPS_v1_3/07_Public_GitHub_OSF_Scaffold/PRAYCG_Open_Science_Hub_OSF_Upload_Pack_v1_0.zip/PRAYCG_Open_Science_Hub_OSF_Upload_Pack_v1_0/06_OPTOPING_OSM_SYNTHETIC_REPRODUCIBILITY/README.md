# 06 - Opto-PING / OSM Synthetic Reproducibility

This folder contains the synthetic reproducibility ladder. These results are computational identifiability and specificity tests only. They do not prove OSM biology, microtubular memory, biophotons, human EEG mechanism, or cellular hidden-Y.
