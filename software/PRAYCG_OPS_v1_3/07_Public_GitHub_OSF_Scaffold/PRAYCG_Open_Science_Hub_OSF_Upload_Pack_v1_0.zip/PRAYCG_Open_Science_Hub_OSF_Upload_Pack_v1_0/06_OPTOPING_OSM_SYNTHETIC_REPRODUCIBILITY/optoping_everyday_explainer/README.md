# 06_OPTOPING_OSM_SYNTHETIC_REPRODUCIBILITY/optoping_everyday_explainer

This folder is part of the PR-AYC-G Open Science Hub OSF Upload Pack. See the parent README and OSF upload map for purpose and publication status.
