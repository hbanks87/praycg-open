# Stimulus Selection Rules

Use legally obtained or open media only. Do not upload copyrighted stimulus media to GitHub or OSF.

Good PR-AYC-G stimuli should have:

- a coherent short narrative;
- identifiable scene-level anchors;
- manageable duration, ideally <=5 minutes for home feasibility;
- low flash risk and tolerable sensory intensity;
- a strong semantic or affective reveal;
- ability to create a phase-scrambled control that destroys recognizable meaning;
- ability to embed fixed upper-right number cues for Contextual Override.

Media-prep outputs must be followed by manual control-audio QC, visual-source-stamp QC, StimulusFingerprint QC where available, protocol acquisition, and Master Comprehensive Suite analysis.
