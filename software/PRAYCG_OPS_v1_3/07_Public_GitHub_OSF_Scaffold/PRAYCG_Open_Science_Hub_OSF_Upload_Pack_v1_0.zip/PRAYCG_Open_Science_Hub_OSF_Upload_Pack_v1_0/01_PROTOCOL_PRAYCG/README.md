# 01 - PR-AYC-G Protocol

This folder contains the public PR-AYC-G protocol map, the v1.8B predeclared-anchor doctrine, the final reflection baseline concept, self-report instruments, and stimulus selection rules.

The core three-arm design is:

1. Phase-scrambled Control: source video scrambled to reduce recognizable meaning while preserving low-level audiovisual structure.
2. Target: intact narrative watched naturally.
3. Contextual Override: same intact narrative under analytic task stance.

Target and Contextual Override should be the same cue-embedded stimulus. Only the instructions differ.
