# Final Reflection Baseline

PRAYCG1.8 adds a post-Washout 3 reflection baseline.

This is not a neutral baseline. It is a delayed comparative-reflection state after the participant has experienced Control, Target, and Contextual Override.

## Sequence

1. Override ratings after Washout 3.
2. Instruction screen asking the participant to reflect on all three branches.
3. Spacebar to proceed.
4. Stillness settle countdown.
5. Two-minute `BASELINE_2_REFLECTION`.
6. Final master subjective report and typed scene-level frozen notes.

## Interpretation

Compare `BASELINE_2_REFLECTION` to `BASELINE_1` only with caveats: it contains memory, comparison, fatigue, relief, task aftereffect, residual story activity, and integration.
