# Final Frozen Scene Notes Template

Do not estimate exact timestamps. Describe the scene, line, image, sound, object, or felt moment.

## Control

Did any scrambled/static portion feel meaningful? If yes, describe the visual or audio fragment.

## Target

What specific scene, image, line, or moment felt meaningful? Describe it without estimating the timestamp.

## Contextual Override

Did any part of the story break through the analytic task? Describe the scene or moment, not the timestamp.
