# 01_PROTOCOL_PRAYCG/current_protocol

This folder is part of the PR-AYC-G Open Science Hub OSF Upload Pack. See the parent README and OSF upload map for purpose and publication status.
