# PR-AYC-G Current Protocol - Public Summary

## Core question

Does narrative meaning change measurable body-brain state beyond low-level audiovisual input and analytic task stance?

## Core sequence

1. Setup / stream check.
2. Baseline 1.
3. Phase-scrambled Control.
4. Washout 1 and Control ratings.
5. Target narrative.
6. Washout 2 and Target ratings.
7. Contextual Override of the same intact narrative.
8. Washout 3 and Override ratings.
9. Reflection baseline and final master subjective report in v1.8+.

## Main measures

- EEG lower-gamma and theta features.
- TemporalSemanticProxy.
- PostPeak PNCC theta.
- Gamma/TSP-to-theta handoff.
- HR/RMSSD/API-A.
- Respiration.
- ALS display-timing if used.
- Self-report and typed scene-level frozen notes.
