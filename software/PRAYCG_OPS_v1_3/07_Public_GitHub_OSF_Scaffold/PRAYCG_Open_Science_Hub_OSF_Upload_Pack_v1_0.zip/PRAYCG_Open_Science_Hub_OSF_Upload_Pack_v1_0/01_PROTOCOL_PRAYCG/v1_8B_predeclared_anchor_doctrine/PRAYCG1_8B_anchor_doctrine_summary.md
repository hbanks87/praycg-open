# PRAYCG1.8B - Predeclared Anchor / Chronometric Humility Doctrine

The v1.8B correction removes retrospective human timestamping as a primary confirmatory anchor.

## Rule

Freeze the scene before analysis. Let physiology answer. Let the subject describe meaning without pretending to be a clock.

## Anchor types

- media-structural: exact scene/timecode defined before analysis;
- algorithmic-predeclared: locked physiological rule defined before analysis;
- subjective-scene: post-run scene/line/image description, not exact second;
- physiology-exploratory: discovered after looking at data; future-freeze only.

## Claim boundary

Physiology-discovered anchors are not confirmatory in the same run. They may become future predeclared anchors.
