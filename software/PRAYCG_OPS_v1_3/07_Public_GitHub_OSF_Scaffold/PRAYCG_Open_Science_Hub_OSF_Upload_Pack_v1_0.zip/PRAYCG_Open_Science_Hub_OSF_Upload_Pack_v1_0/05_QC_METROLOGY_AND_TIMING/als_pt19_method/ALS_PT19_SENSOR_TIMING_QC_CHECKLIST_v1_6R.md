# PRAYCG v1.6R ALS-PT19 / Photodiode Timing QC Checklist

Project: `Her_cued_sensor`
Sensor timing enabled: `True`
Sensor square position: `lower_right`
Pulse mode: `video_start`

## Hardware placement

- Tape the ALS-PT19 directly over the timing square.
- Use black electrical tape / opaque shroud around the sensor so the participant does not see the pulse.
- Confirm the square does not cover the upper-right number cue.
- Confirm the sensor signal is recorded in the OpenBCI analog AUX / Analog Read LSL stream.

## Required test before real run

1. Play the generated Target video for at least 10 seconds.
2. Confirm a strong analog rise during the video-start pulse.
3. Confirm the signal returns to baseline after the pulse.
4. Repeat on Control and Override.

## Pass criteria

- Pulse visible in AUX stream.
- No clipping at maximum ADC value for the full pulse duration.
- No pulse missed at video start.
- Target, Override, and Control all contain the timing square.

Boundary: this timing square validates physical display timing. It belongs to the external input vector u(t), not to any biological hidden variable Y(t).
