# StimulusFingerprint QC

StimulusFingerprint QC estimates low-level media properties such as luminance dynamics, visual change, cut rate, flash risk, audio envelope, and other stimulus features.

Use it to support, not replace, manual review. It cannot certify meaning, empathy, audio unintelligibility, or task validity.
