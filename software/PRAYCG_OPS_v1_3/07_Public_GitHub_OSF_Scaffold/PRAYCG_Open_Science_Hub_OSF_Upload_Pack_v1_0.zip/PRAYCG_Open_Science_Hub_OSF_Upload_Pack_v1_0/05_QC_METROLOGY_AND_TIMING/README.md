# 05 - QC, Metrology, and Timing

This folder contains the metrology and media-quality checks required before interpreting PR-AYC-G physiology.

Key rule: the ALS/photodiode channel validates physical display timing and belongs to external input `u(t)`, not biological hidden `Y(t)`.
