# Fullscreen ALS Start-Pulse Method

The v1.6S MediaPrep upgrade replaces the tiny corner pulse with a robust full-screen white prefix followed by a black guard interval.

Recommended pattern:

```text
black settle screen -> full-screen white pulse -> black guard -> movie content
```

The pulse improves sensor placement tolerance and creates a strong luminance transition for the ALS-PT19 or equivalent light sensor. The white/black prefix is an instrumentation event and should be excluded from biological interpretation.
