# 05_QC_METROLOGY_AND_TIMING/control_audio_qc

This folder is part of the PR-AYC-G Open Science Hub OSF Upload Pack. See the parent README and OSF upload map for purpose and publication status.
