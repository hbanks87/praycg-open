# LabRecorder / LSL Stream Checklist

Before each run, confirm expected streams in LabRecorder.

Minimum EEG-only home version:

- `obci_eeg1`
- `OpenBCIStatusMarkers`
- `StasisMarkers`
- optional `PolarHRV`
- optional `VernierRespirationBelt`

Higher-rigor ALS version:

- `obci_eeg1`
- `OpenBCIAnalogAux`
- `ALS_PT19_Timing`
- `OpenBCIStatusMarkers`
- `StasisMarkers`
- `PolarHRV`
- `VernierRespirationBelt`

Record stream inventory and run a short watchdog/smoke test before real acquisition.
