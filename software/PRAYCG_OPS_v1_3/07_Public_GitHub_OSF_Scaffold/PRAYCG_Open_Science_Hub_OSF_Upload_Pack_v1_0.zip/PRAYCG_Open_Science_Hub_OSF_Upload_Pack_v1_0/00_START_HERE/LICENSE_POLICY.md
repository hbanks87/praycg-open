# License Policy

Recommended licensing for the public hub:

- Code: Apache-2.0 or MIT.
- Protocols, hardware guides, QC templates, and scientific documentation: CC BY 4.0.
- Synthetic demo data: CC0 or CC BY 4.0.
- Philosophical/cultural essays: CC BY 4.0 for maximal openness, or CC BY-NC-ND 4.0 only if intentionally using a more protective literary/artistic release.

No copyrighted stimulus videos or film/audio excerpts are included in this pack. Users must supply lawful media or use synthetic/open demo stimuli.
