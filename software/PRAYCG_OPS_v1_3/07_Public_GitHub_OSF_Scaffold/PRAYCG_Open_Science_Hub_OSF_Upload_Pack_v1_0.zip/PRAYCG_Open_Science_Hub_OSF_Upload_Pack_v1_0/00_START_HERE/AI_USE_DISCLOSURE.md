# AI Use Disclosure

This project was developed with substantial AI-assisted drafting, coding, critique, and document assembly.

The human author supplied the research direction, conceptual framework, experimental constraints, acceptance/rejection decisions, revision goals, and final publication choices. AI outputs should be treated as assisted drafts, engineering artifacts, or analysis support, not as independent scientific validation.

Public release should disclose AI assistance plainly. Human review remains required for scientific, ethical, legal, safety, and claims-boundary accuracy.
