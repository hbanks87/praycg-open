# Claims Boundary Statement

## PR-AYC-G empirical boundary

PR-AYC-G asks whether meaning has measurable timing, shape, and physiological consequence. It does not claim to solve consciousness or convert love into a number.

Permitted claim language:

- exploratory psychophysiology;
- feasibility protocol;
- state-trajectory analysis;
- candidate human-translation proxy;
- artifact-sensitive work signal;
- hypothesis-generating result unless preregistered and replicated.

Disallowed claim language:

- PR-AYC-G proves consciousness;
- EEG proves love or souls;
- scalp gamma proves STS/MTG or OSM;
- ALS-PT19 detects biological hidden-Y;
- Rung 0 proves microtubules or biophotons.

## OSM / Opto-PING boundary

OSM is a conditional mechanism hypothesis. Opto-PING Rung 0J-O is synthetic identifiability/specificity/reproducibility work. It proves the pipeline can recover or reject a known synthetic structure under locked assumptions; it does not prove that structure exists in human biology.
