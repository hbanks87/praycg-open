# What This Is and Is Not

## What this is

PR-AYC-G is an exploratory research protocol and open-source software/hardware ecosystem for testing whether narrative meaning has measurable timing, shape, and physiological consequence beyond matched audiovisual stimulation and analytic task stance.

It includes:

- media preparation and QC tools;
- synchronized acquisition using LSL and BrainFlow;
- an optional physical display-timing channel using ALS-PT19 or equivalent photodiode/light sensor;
- structured self-report and final reflection notes;
- a Master Comprehensive Analysis Suite;
- a synchronized visual review tool;
- synthetic Opto-PING reproducibility gates.

## What this is not

This project does not prove consciousness, soul, love as a force, clinical efficacy, OSM biology, microtubular memory, biophotonic memory, or human EEG access to a molecular hidden variable.

Current human data are exploratory. Synthetic Rung 0 results are synthetic identifiability, specificity, and reproducibility results only.
