# Start Here - PR-AYC-G Open Science Hub

PR-AYC-G is an open, exploratory psychophysiology protocol for studying narrative meaning under controlled stimulus and task-stance contrasts.

The hub contains:

- the PR-AYC-G protocol and runner documentation;
- MediaPrep tools for creating Target, Control, and Contextual Override branches;
- The Box open-hardware build documentation;
- BrainFlow acquisition scripts, including ALS-PT19 timing and EEG-only paths;
- the Master Comprehensive Analysis Suite and MasterSync Visualizer;
- Opto-PING / OSM synthetic reproducibility gates;
- QC checklists and public demo templates;
- TSC-facing handouts and philosophical companion documents.

Read `WHAT_THIS_IS_AND_IS_NOT.md` and `CLAIMS_BOUNDARY_STATEMENT.md` before reading any technical or philosophical material.
