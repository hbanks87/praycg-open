# Not-Current Claims

Current public position:

- PR-AYC-G is exploratory psychophysiology.
- OSM is a conditional mechanism hypothesis.
- Rung 0J-O are synthetic reproducibility gates.
- Human data do not yet prove biological hidden-Y, microtubules, biophotons, or OSM.
