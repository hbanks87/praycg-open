# Do Not Publicly Cite as Current

Use this folder only if you intentionally want to preserve historical drafts with a visible warning. Prefer keeping this folder private until after legal/scientific review.
