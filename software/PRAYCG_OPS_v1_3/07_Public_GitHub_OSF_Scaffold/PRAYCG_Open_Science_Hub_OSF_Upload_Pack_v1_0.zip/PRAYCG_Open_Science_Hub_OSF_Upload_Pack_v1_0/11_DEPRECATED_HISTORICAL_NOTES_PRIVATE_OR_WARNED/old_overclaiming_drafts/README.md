# 11_DEPRECATED_HISTORICAL_NOTES_PRIVATE_OR_WARNED/old_overclaiming_drafts

This folder is part of the PR-AYC-G Open Science Hub OSF Upload Pack. See the parent README and OSF upload map for purpose and publication status.
