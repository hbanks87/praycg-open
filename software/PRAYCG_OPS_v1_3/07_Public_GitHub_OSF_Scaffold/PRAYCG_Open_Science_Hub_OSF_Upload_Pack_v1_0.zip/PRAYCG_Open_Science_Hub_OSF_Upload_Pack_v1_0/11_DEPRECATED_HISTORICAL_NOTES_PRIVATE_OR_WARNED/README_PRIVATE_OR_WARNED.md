# Deprecated / Historical Notes - Private or Warned

This folder is intentionally a warning zone.

Do not upload old drafts that make stronger claims than the current boundary unless they are clearly labeled as historical, not-current, and not scientific claim language.

Examples of language to quarantine:

- human EEG proves OSM;
- love is a fundamental thermodynamic force;
- PR-AYC-G proves consciousness;
- microtubular or biophotonic mechanisms are established from scalp EEG;
- clinical healing claims.
