# API_A_v1 Method

API_A is an autonomic availability proxy. It is not a clinical diagnostic score and not an emotion detector.

Default concept:

```text
API_A = [ z(RMSSD) + z(SDNN) - z(HR) - z(|dHR/dt|) ] / available_feature_count
```

Higher API_A suggests lower heart strain, higher variability, and less acceleration instability. It must be interpreted with respiration, task context, posture, arousal, motion, and artifact controls.
