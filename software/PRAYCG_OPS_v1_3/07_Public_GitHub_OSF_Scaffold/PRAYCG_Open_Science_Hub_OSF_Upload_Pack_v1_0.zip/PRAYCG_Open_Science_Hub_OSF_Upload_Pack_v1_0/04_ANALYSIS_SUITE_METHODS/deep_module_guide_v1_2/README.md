# 04_ANALYSIS_SUITE_METHODS/deep_module_guide_v1_2

This folder is part of the PR-AYC-G Open Science Hub OSF Upload Pack. See the parent README and OSF upload map for purpose and publication status.
