# GammaScalpel Method

GammaScalpel does not treat gamma as one broad bucket. It scans smaller frequency bands, usually 5 Hz wide, to see whether meaning, task, or artifact patterns concentrate in a specific sub-band.

Example bands:

```text
20-25, 25-30, 30-35, 35-40, 40-45, 45-50, 50-55 Hz
```

For each band and region, the suite estimates log bandpower and compares Target, Control, and Contextual Override while applying artifact penalties and reporting caveats. Scalp gamma is artifact-sensitive; no gamma result should be interpreted alone.
