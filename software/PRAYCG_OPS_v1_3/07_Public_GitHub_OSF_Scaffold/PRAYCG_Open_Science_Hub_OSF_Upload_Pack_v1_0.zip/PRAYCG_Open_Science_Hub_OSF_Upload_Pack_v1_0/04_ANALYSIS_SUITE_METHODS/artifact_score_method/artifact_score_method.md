# artifact_score Method

The artifact score penalizes noisy windows before custom PR-AYC-G composites are interpreted.

Typical ingredients:

```text
P2P = robust peak-to-peak amplitude, such as Q95-Q5
HF_45_55 = high-frequency sentinel power proxy
ArtifactScore = 0.5 * positive_z(P2P) + 0.5 * positive_z(HF_45_55)
CleanFeature = RawFeature / (1 + lambda_A * ArtifactScore)
```

The exact implementation should be verified against the release version of the Master Suite before making confirmatory claims.
