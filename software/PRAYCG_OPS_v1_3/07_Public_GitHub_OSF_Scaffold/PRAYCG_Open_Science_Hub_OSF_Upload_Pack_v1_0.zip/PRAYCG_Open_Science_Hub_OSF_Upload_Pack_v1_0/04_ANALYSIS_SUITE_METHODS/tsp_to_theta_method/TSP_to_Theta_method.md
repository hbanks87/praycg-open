# TSP-to-Theta Method

TemporalSemanticProxy (TSP) is a posterior-temporal scalp-level semantic-load proxy, not anatomical proof of STS or MTG activity.

## TSP candidate detection

A candidate TSP peak is identified by a local maximum in the TSP trace after artifact penalty and refractory-window rules.

## Half-taper rule

After a peak, the taper point is the first time the TSP trace falls below the halfway point between the peak and baseline.

## Handoff test

The TSP-to-theta handoff test asks whether theta increases in a later non-overlapping window after the TSP peak/taper, relative to pre-event theta and relative to null/random-anchor windows.
