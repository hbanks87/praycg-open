# 04 - Analysis Suite Methods

This folder contains the TSC-facing analysis module guide and short reference materials. It emphasizes custom PR-AYC-G metrics and decision rules rather than textbook signal-processing derivations.
