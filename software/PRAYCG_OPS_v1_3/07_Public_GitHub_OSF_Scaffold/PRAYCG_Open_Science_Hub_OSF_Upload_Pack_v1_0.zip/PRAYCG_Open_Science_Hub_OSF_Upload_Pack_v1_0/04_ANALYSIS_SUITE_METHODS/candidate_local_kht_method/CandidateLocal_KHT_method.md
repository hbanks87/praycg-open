# CandidateLocal_KHT Method

CandidateLocal_KHT estimates event-level human-translation coupling around predeclared or exploratory anchors.

## Local model

Let `E(t)` be a gamma-like feature and `Y_HT(t)` be a TemporalSemanticProxy-like feature.

```text
E_{t+1} = a_E E_t + eta_j Y_HT,t + c_E Artifact_t + error_E,t
Y_HT,t+1 = a_Y Y_HT,t + zeta_j E_t + c_Y Artifact_t + error_Y,t
K_local,j = sqrt(abs(eta_j * zeta_j))
sign_j = sign(eta_j * zeta_j)
```

## Human-event lock rule

K alone is not enough. Theta handoff alone is not enough. Final human-event lock requires local coupling, theta carryover, condition specificity, artifact pass, and timing pass.
