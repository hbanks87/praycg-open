# Posters Placeholder

Place final poster PDFs here after design is complete. Do not include private acceptance emails or hotel/registration links.
