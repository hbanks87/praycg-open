# QR-Code Landing Page Copy

PR-AYC-G Open Science Hub

Open protocol, software, hardware documentation, synthetic reproducibility packages, QC checklists, and TSC handouts for an exploratory psychophysiology protocol studying narrative meaning.

Boundary: This project does not prove consciousness, OSM biology, microtubular memory, biophotons, clinical efficacy, or human EEG access to molecular hidden variables.
