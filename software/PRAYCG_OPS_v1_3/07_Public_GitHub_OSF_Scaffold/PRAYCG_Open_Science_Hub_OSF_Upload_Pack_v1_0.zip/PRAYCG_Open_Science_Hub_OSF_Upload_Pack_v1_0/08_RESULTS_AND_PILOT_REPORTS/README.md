# 08 - Results and Pilot Reports

Do not upload raw participant data or identifiable reports without explicit public-consent review.

Self-run reports may be uploaded if they are intentionally public, deidentified where appropriate, and clearly labeled as exploratory or pilot-only. Raw XDF recordings should remain private unless explicitly released with consent and a data dictionary.
