# Arrival / About Time Reports - Review Required

Do not upload these reports publicly until they have been checked for:

- private file paths;
- participant identifiers;
- copyrighted stimulus references beyond fair textual description;
- overclaiming language;
- raw data or metadata that should remain private.
