# 03 - Software Releases

This folder contains OSF snapshots of the public GitHub release packages. GitHub should remain the live code workspace; OSF should archive stable release ZIPs.

No copyrighted videos or raw private data should be included in software release folders.
