# 03_SOFTWARE_RELEASES/acquisition_brainflow_als_v1_4

This folder is part of the PR-AYC-G Open Science Hub OSF Upload Pack. See the parent README and OSF upload map for purpose and publication status.
