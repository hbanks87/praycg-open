# 03_SOFTWARE_RELEASES/acquisition_brainflow_eeg_only_v1_0

This folder is part of the PR-AYC-G Open Science Hub OSF Upload Pack. See the parent README and OSF upload map for purpose and publication status.
