# PR-AYC-G Open Science Hub - OSF Upload Pack v1.0

This package is a public-release scaffold for the PR-AYC-G Open Science Hub. It is organized as an OSF-ready folder map containing public-facing start-here documents, protocol documentation, open-hardware documentation for The Box, software release snapshots, analysis-suite methods, QC/metrology checklists, Opto-PING / OSM synthetic reproducibility packages, synthetic public-demo placeholders, TSC handouts, and optional philosophical companion materials.

## Core public claim

PR-AYC-G is an exploratory open psychophysiology protocol for testing whether narrative meaning has measurable timing, shape, and physiological consequence beyond matched audiovisual stimulation and analytic task stance.

## Core public non-claim

This project does not prove consciousness, souls, love as a force, clinical treatment, microtubular memory, biophotonic memory, OSM biology, or human EEG access to a molecular hidden variable.

## How to upload

Upload the folders to OSF in this order:

1. `00_START_HERE`
2. `01_PROTOCOL_PRAYCG`
3. `02_THE_BOX_OPEN_HARDWARE`
4. `03_SOFTWARE_RELEASES`
5. `04_ANALYSIS_SUITE_METHODS`
6. `05_QC_METROLOGY_AND_TIMING`
7. `06_OPTOPING_OSM_SYNTHETIC_REPRODUCIBILITY`
8. `07_EXAMPLE_DATA_PUBLIC_DEMO`
9. `08_RESULTS_AND_PILOT_REPORTS` only after de-identification review
10. `09_TSC_2026_POSTER_HANDOUTS`
11. `10_BONUS_THEORY_AND_CULTURE`
12. `11_DEPRECATED_HISTORICAL_NOTES_PRIVATE_OR_WARNED` only if you intentionally want an archival warning zone

Before making the OSF project public, complete `PUBLIC_RELEASE_AUDIT_CHECKLIST.md`.
