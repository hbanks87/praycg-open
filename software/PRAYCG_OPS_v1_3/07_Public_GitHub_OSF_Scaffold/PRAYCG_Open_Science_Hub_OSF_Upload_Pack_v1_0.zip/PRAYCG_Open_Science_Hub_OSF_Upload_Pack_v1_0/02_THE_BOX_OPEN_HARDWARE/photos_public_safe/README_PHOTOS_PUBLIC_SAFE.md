# Public-Safe Photos

Place only public-safe Box photos here.

Before upload:

- remove EXIF/GPS metadata;
- avoid revealing private addresses, license plates, family photos, mail, screens, or identifiable bystanders;
- avoid unsafe wiring or trip hazards unless clearly labeled as a non-use construction photo;
- do not imply certified shielding or clinical safety.
