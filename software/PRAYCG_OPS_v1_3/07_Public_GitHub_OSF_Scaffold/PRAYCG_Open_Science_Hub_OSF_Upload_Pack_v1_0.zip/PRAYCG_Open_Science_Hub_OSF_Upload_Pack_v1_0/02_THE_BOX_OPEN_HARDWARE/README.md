# 02 - The Box Open Hardware

The Box is an environmental-control and art/science apparatus for low-cost psychophysiology recording. It is not a medical device, therapeutic device, clinical device, or guaranteed electromagnetic shield.

Public documentation should include build steps, bill of materials, safety warnings, testing protocol, and public-safe photos with EXIF/location metadata removed.
