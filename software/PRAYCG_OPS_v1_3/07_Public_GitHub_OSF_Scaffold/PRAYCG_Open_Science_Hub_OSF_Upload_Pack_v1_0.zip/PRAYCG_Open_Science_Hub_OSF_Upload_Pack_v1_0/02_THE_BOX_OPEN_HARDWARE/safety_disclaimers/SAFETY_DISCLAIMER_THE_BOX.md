# Safety Disclaimer - The Box

The Box is an experimental apparatus, not a certified shielded room or clinical device.

Do not modify mains wiring. Do not assume grounding is safe without qualified review. Maintain ventilation, lighting, emergency egress, heat monitoring, trip-hazard control, and immediate exit access. Do not lock participants inside. Do not use the apparatus for medical diagnosis or treatment.

If in doubt, do not run a human session.
