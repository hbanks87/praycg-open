# Public Testing Protocol for The Box

Minimum public tests:

1. Physical inspection: stable frame, no sharp edges, no trip hazards.
2. Ventilation and emergency egress check.
3. AM-radio or signal attenuation demonstration, documented as informal only.
4. Wi-Fi/cell signal check, documented as informal only.
5. EEG noise-floor comparison inside vs outside, with same cap, participant posture, and acquisition settings.
6. Human-use stop rule: terminate immediately for distress, heat, breathing discomfort, claustrophobia, dizziness, equipment fault, or participant request.
