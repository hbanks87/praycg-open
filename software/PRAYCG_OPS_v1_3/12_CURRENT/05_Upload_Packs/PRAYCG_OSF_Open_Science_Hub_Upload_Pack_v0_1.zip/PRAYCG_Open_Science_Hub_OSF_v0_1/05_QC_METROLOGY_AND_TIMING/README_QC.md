# QC, metrology, and timing

ALS/PT19 validates physical display timing in external input vector u(t), not biological hidden-Y. Manual control-audio and visual QC remain required.
