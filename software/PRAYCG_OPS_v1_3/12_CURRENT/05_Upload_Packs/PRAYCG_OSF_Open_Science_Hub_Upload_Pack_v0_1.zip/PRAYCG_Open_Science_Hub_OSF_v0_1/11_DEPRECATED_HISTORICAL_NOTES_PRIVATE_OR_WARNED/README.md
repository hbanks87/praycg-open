# Deprecated / historical notes

Avoid public upload of obsolete overclaiming drafts unless explicitly labeled as historical/superseded.
